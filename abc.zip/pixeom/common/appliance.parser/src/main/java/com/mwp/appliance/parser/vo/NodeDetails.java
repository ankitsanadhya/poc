/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.mwp.appliance.parser.vo;

import com.google.gson.Gson;
import com.mwp.appliance.parser.common.Constants.NodeDeviceStatus;

/**
 * @author root
 *
 */
public class NodeDetails {

	private String nodeID = "";
	private String ringID = "";
	private String iPAddress = "";
	private String password = "";
	private String nodeType = "";
	private String MACAddress = "";
	private String deviceID = "";
	private String DeviceName = "";
	private DeviceInfo deviceInfo = new DeviceInfo();
	private long DeviceInfoUpdateTime = 0;
	private NodeDeviceStatus Status = NodeDeviceStatus.online;
	private int CNO = 0;
	private String RingType = "";

	public NodeDetails() {
	}

	public String getNodeID() {
		return nodeID;
	}

	public void setNodeID(String nodeID) {
		this.nodeID = nodeID;
	}

	public String getRingID() {
		return ringID;
	}

	public void setRingID(String ringID) {
		this.ringID = ringID;
	}

	public String getiPAddress() {
		return iPAddress;
	}

	public void setiPAddress(String iPAddress) {
		this.iPAddress = iPAddress;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getNodeType() {
		return nodeType;
	}

	public void setNodeType(String nodeType) {
		this.nodeType = nodeType;
	}

	public String getMACAddress() {
		return MACAddress;
	}

	public void setMACAddress(String mACAddress) {
		MACAddress = mACAddress;
	}

	public String getDeviceID() {
		return deviceID;
	}

	public void setDeviceID(String deviceID) {
		this.deviceID = deviceID;
	}

	public String getDeviceName() {
		return DeviceName;
	}

	public void setDeviceName(String deviceName) {
		DeviceName = deviceName;
	}
	public DeviceInfo getDeviceInfo() {
		return deviceInfo;
	}

	public String getDeviceInfoJSON() {
		return (new Gson()).toJson(deviceInfo);
	}

	public void setDeviceInfo(String deviceInfo) {
		if(!deviceInfo.trim().equals("")) {
			this.deviceInfo = (new Gson()).fromJson(deviceInfo, DeviceInfo.class);
		}
	}

	public long getDeviceInfoUpdateTime() {
		return DeviceInfoUpdateTime;
	}

	public void setDeviceInfoUpdateTime(long deviceInfoUpdateTime) {
		//		//Sat Feb 15 14:59:33 IST 2014
		//		Date date = new Date();
		//
		//		try {
		//			date = new SimpleDateFormat("E MMM dd HH:mm:ss zz yyyy", Locale.ENGLISH).parse(deviceInfoUpdateTime);
		//			/*
		//				G   Era designator       Text               AD
		//				y   Year                 Year               1996; 96
		//				M   Month in year        Month              July; Jul; 07
		//				w   Week in year         Number             27
		//				W   Week in month        Number             2
		//				D   Day in year          Number             189
		//				d   Day in month         Number             10
		//				F   Day of week in month Number             2
		//				E   Day in week          Text               Tuesday; Tue
		//				u   Day number of week   Number             1
		//				a   Am/pm marker         Text               PM
		//				H   Hour in day (0-23)   Number             0
		//				k   Hour in day (1-24)   Number             24
		//				K   Hour in am/pm (0-11) Number             0
		//				h   Hour in am/pm (1-12) Number             12
		//				m   Minute in hour       Number             30
		//				s   Second in minute     Number             55
		//				S   Millisecond          Number             978
		//				z   Time zone            General time zone  Pacific Standard Time; PST; GMT-08:00
		//				Z   Time zone            RFC 822 time zone  -0800
		//				X   Time zone            ISO 8601 time zone -08; -0800; -08:00
		//			 * */
		//		} catch (ParseException e) {
		//			PALogger.ERROR(e);
		//		}


		DeviceInfoUpdateTime = deviceInfoUpdateTime;
	}

	public NodeDeviceStatus getStatus() {
		return Status;
	}

	public void setStatus(NodeDeviceStatus status) {
		Status = status;
	}

	public int getCNO() {
		return CNO;
	}

	public void setCNO(int cNO) {
		CNO = cNO;
	}

	public String getRingType() {
		return RingType;
	}

	public void setRingType(String ringType) {
		RingType = ringType;
	}

	public void guid() {
		// TODO Auto-generated method stub
	}	
}
