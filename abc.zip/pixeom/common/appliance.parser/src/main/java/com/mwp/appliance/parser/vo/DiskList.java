/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.mwp.appliance.parser.vo;

import java.util.ArrayList;

public class DiskList
{
	public ArrayList<String> SystemDisks = new ArrayList<String>();
	public ArrayList<String> BackUpDisks = new ArrayList<String>();
	public ArrayList<String> SpareDisks = new ArrayList<String>();
	public ArrayList<String> VolumeGroupDisks = new ArrayList<String>();
	public ArrayList<VolumeGroups> VolumeGroups = new ArrayList<VolumeGroups>();

	public void addSystemDisks(String systemDisk) {
		SystemDisks.add(systemDisk.trim());
	}

	public void addBackUpDisks(String backUpDisk) {
		BackUpDisks.add(backUpDisk.trim());
	}

	public void addSpareDisks(String spareDisk) {
		SpareDisks.add(spareDisk.trim());
	}
	
	public void addVolumeGroupDisks(String volumeGroupDisk) {
		VolumeGroupDisks.add(volumeGroupDisk.trim());
	}
	
	public void addVolumeGroup(VolumeGroups volumeGroup) {
		VolumeGroups.add(volumeGroup);
	}

	public void guid() {
		// TODO Auto-generated method stub
		
	}
}
