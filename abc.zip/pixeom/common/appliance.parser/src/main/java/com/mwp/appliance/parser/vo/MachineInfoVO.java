/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.mwp.appliance.parser.vo;


public class MachineInfoVO {
	String ComputerModel;
	String MACAddress;
	String MachineName;
	String MotherBoardId;
	String MotherBoardManufacture;
	String CPUCore;
	String CPUModel;
	String NicSpeed;

	public String getComputerModel() {
		return ComputerModel;
	}
	public void setComputerModel(String computerModel) {
		ComputerModel = computerModel;
	}

	public String getMACAddress() {
		return MACAddress;
	}
	public void setMACAddress(String mACAddress) {
		MACAddress = mACAddress;
	}

	public String getMachineName() {
		return MachineName;
	}
	public void setMachineName(String machineName) {
		MachineName = machineName;
	}

	public String getMotherBoardId() {
		return MotherBoardId;
	}
	public void setMotherBoardId(String motherBoardId) {
		MotherBoardId = motherBoardId;
	}
	public String getMotherBoardManufacture() {
		return MotherBoardManufacture;
	}
	public void setMotherBoardManufacture(String motherBoardManufacture) {
		MotherBoardManufacture = motherBoardManufacture;
	}

	public String getCPUCore() {
		return CPUCore;
	}
	public void setCPUCore(String cPUCore) {
		CPUCore = cPUCore;
	}

	public String getCPUModel() {
		return CPUModel;
	}
	public void setCPUModel(String cPUModel) {
		CPUModel = cPUModel;
	}

	public String getNicSpeed() {
		return NicSpeed;
	}
	public void setNicSpeed(String nicSpeed) {
		NicSpeed = nicSpeed;
	}
	public void guid() {
		// TODO Auto-generated method stub

	}

}
