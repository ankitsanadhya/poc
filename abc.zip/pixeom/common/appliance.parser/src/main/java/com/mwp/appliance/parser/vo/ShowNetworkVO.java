/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.mwp.appliance.parser.vo;

import java.util.List;

import com.mwp.common.ISkipObfuscation;

public class ShowNetworkVO implements ISkipObfuscation {

	/*	0				1			2			3			4			5					6			7		8		9		
	 * Interface Name|MAC Address|Link State|IP Address|Subnet Mask|Broadcast Address|Gateway Address|Protocol|Speed|Admin State
	 * 			10			11					12					13
	 * (bond)~Bonding Mode|Bonded Interfaces|Currently Active Slave|Primary Slave
	 * 			10
	 * (Nic)~Master
	 */

	private String interfaceName;
	private String displayName;
	private String macAddress;
	private String iPAddress;
	private String subNetMask;
	private String broadcast;
	private String status;
	private String gateway;
	private String primaryDns;
	private String secondaryDns;
	private String tertiaryDns;
	private String adminState;
	private String bondingMode;
	private List<BondedNicVO> interfaces;
	private String slaveInterface;
	private String primarySlave;
	private String master;
	private String bootProtocol;
	private String hostName;
	private String domainName;
	private int speed;
	private Boolean isDHCP;
	private Boolean isEnabled;
	private Boolean isConnected;
	private Integer networkBlock;
	private boolean isInternetOn;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public String getInterfaceName() {
		return interfaceName;
	}

	public void setInterfaceName(String interfaceName) {
		this.interfaceName = interfaceName;
	}

	public String getPrimaryDns() {
		return primaryDns;
	}

	public void setPrimaryDns(String primaryDns) {
		this.primaryDns = primaryDns;
	}

	public String getSecondaryDns() {
		return secondaryDns;
	}

	public void setSecondaryDns(String secondaryDns) {
		this.secondaryDns = secondaryDns;
	}

	public String getMacAddress() {
		return macAddress;
	}

	public void setMacAddress(String macAddress) {
		this.macAddress = macAddress;
	}

	public String getiPAddress() {
		return iPAddress;
	}

	public void setiPAddress(String iPAddress) {
		this.iPAddress = iPAddress;
	}

	public String getSubNetMask() {
		return subNetMask;
	}

	public void setSubNetMask(String subNetMark) {
		this.subNetMask = subNetMark;
	}

	public String getBroadcast() {
		return broadcast;
	}

	public void setBroadcast(String broadcast) {
		this.broadcast = broadcast;
	}

	public String getGateway() {
		return gateway;
	}

	public void setGateway(String gateway) {
		this.gateway = gateway;
	}

	public String getAdminState() {
		return adminState;
	}

	public void setAdminState(String adminState) {
		this.adminState = adminState;
	}

	public String getBondingMode() {
		return bondingMode;
	}

	public void setBondingMode(String bondingMode) {
		this.bondingMode = bondingMode;
	}

	public List<BondedNicVO> getInterfaces() {
		return interfaces;
	}

	public void setInterfaces(List<BondedNicVO> interfaces) {
		this.interfaces = interfaces;
	}

	public String getBootProtocol() {
		return bootProtocol;
	}

	public void setBootProtocol(String bootProtocol) {
		this.bootProtocol = bootProtocol;
	}

	public String getHostName() {
		return hostName;
	}

	public void setHostName(String hostName) {
		this.hostName = hostName;
	}

	public String getDomainName() {
		return domainName;
	}

	public void setDomainName(String domainName) {
		this.domainName = domainName;
	}

	public Boolean getIsDHCP() {
		return isDHCP;
	}

	public void setIsDHCP(Boolean isDHCP) {
		this.isDHCP = isDHCP;
	}

	public Boolean getIsEnabled() {
		return isEnabled;
	}

	public void setIsEnabled(Boolean isEnabled) {
		this.isEnabled = isEnabled;
	}

	public Boolean getIsConnected() {
		return isConnected;
	}

	public void setIsConnected(Boolean isConnected) {
		this.isConnected = isConnected;
	}

	public Integer getNetworkBlock() {
		return networkBlock;
	}

	public void setNetworkBlock(Integer networkBlock) {
		this.networkBlock = networkBlock;
	}

	public String getTertiaryDns() {
		return tertiaryDns;
	}

	public void setTertiaryDns(String tertiaryDns) {
		this.tertiaryDns = tertiaryDns;
	}

	public String getSlaveInterface() {
		return slaveInterface;
	}

	public void setSlaveInterface(String slaveInterface) {
		this.slaveInterface = slaveInterface;
	}

	public String getPrimarySlave() {
		return primarySlave;
	}

	public void setPrimarySlave(String primarySlave) {
		this.primarySlave = primarySlave;
	}

	public String getMaster() {
		return master;
	}

	public void setMaster(String master) {
		this.master = master;
	}

	public int getSpeed() {
		return speed;
	}

	public void setSpeed(int speed) {
		this.speed = speed;
	}

	public boolean getIsInternetOn() {
		return isInternetOn;
	}

	public void setIsInternetOn(boolean isInternetOn) {
		this.isInternetOn = isInternetOn;
	}

	public void guid() {
	}
}