/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.mwp.appliance.parser.vo;

import java.util.Hashtable;

import com.mwp.common.ISkipObfuscation;

public class WifiDetails implements ISkipObfuscation {
		private String wifiName;
		private boolean isSecure;
		private boolean isConnected;
		private int signalStrength;
		private String macAddress;
		
		//	private static int num;
		static Hashtable<String, strength> _strengthList = new Hashtable<String, strength>();
		enum strength
		{
			poor("poor",0),
			weak("weak",1),
			fair("fair",2),
			good("good",3),
			excellent("excellent",4);
			int num;
			
			strength(String name, int n){
				num = n;
				_strengthList.put(name, this);
			}

			public  int getValue(){
				return num;
			}

			public static strength GetEnumValue(String strengthValue)
			{	
				return _strengthList.get(strengthValue);
			}

		}
		

		public int getSignalStrength() {
			return signalStrength;
		}
		/**
		 * This will inside change the String to enum value.
		 * @param signalStrength
		 */
		public void setSignalStrength(String signalStrength) {
			this.signalStrength = (strength.GetEnumValue(signalStrength.toLowerCase())).getValue();
		}
		public String getWifiName() {
			return wifiName;
		}
		public void setWifiName(String wifiName) {
			this.wifiName = wifiName;
		}
		public boolean isSecure() {
			return isSecure;
		}
		public void setSecure(boolean isSecure) {
			this.isSecure = isSecure;
		}
		public boolean isConnected() {
			return isConnected;
		}
		public void setConnected(boolean isConnected) {
			this.isConnected = isConnected;
		}
		public String getMacAddress() {
			return macAddress;
		}
		public void setMacAddress(String macAddress) {
			this.macAddress = macAddress;
		}
		@Override
		public void guid() {
			// TODO Auto-generated method stub
			
		}
		
	}

