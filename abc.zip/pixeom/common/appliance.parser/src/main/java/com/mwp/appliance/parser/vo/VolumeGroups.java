/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.mwp.appliance.parser.vo;

import java.util.ArrayList;

import com.mwp.common.Utils;

public class VolumeGroups {

	private String name;
	private ArrayList<String> disks = new ArrayList<String>();
	private String diskNames = "";
	private long size = 0;
	private String displaySizeValue = "";
	private String displaySizeUnit = "";

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public ArrayList<String> getDisks() {
		return disks;
	}
	/*public void setDisks(ArrayList<String> disks) {
		this.disks = disks;
	}*/
	public void addDisk(String disk) {
		this.disks.add(disk);

		try {
			String diskName = disk.trim().split("/")[2];

			if(diskNames.equals("")) {
				diskNames += diskName;
			} else {
				diskNames += ", " + diskName;	
			}
		}
		catch(Exception e) {

		}
	}
	public String getDiskNames() {
		return diskNames;
	}
	public long getSize() {
		return size;
	}
	public void setSize(long size) {
		this.size = size * 1024;
		String[] str= Utils.SizeConverter(this.size);
		setDisplaySizeValue(str[0]);
		setDisplaySizeUnit(str[1]);
	}
	public String getDisplaySizeValue() {
		return displaySizeValue;
	}
	private void setDisplaySizeValue(String displaySizeValue) {
		this.displaySizeValue = displaySizeValue;
	}
	public String getDisplaySizeUnit() {
		return displaySizeUnit;
	}
	private void setDisplaySizeUnit(String displaySizeUnit) {
		this.displaySizeUnit = displaySizeUnit;
	}
	public void guid() {
		// TODO Auto-generated method stub
		
	}
}
