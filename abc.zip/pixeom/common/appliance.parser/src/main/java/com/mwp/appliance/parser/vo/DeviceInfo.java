/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.mwp.appliance.parser.vo;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

public class DeviceInfo {

	public DeviceInfo() {
//		try {
//			MaxDisks = Integer.parseInt(BoxConfigurations.getInstance().getSettings().getMaxDisks());
//		} catch (Exception e) {
//			PALogger.ERROR(e);
//		}
	}

	Hashtable<String, String> version = new Hashtable<String, String>();
	int MaxDisks = 3;

	ArrayList<DiskInfo> diskInfos = new ArrayList<DiskInfo>();
	List<ShowNetworkVO> showNetworkStatus = new ArrayList<ShowNetworkVO>();

	public ArrayList<DiskInfo> getDiskInfos() {
		return diskInfos;
	}
	public void setDiskInfos(ArrayList<DiskInfo> diskInfos) {
		this.diskInfos = diskInfos;
	}

	public List<ShowNetworkVO> getShowNetworkStatus() {
		return showNetworkStatus;
	}
	public void setShowNetworkStatus(List<ShowNetworkVO> showNetworkStatus) {
		this.showNetworkStatus = showNetworkStatus;
	}

	public int getMaxDisks() {
		return MaxDisks;
	}
	public void setMaxDisks(int maxDisks) {
		MaxDisks = maxDisks;
	}

	public Hashtable<String, String> getVersion() {
		return version;
	}
	public void setVersion(Hashtable<String, String> version) {
		this.version = version;
	}
	public void guid() {
	}
}
