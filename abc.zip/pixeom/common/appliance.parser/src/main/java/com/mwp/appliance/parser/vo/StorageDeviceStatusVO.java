/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.mwp.appliance.parser.vo;

public class StorageDeviceStatusVO {
	//store3-Rxys|/dev/sdc|1|00:0C:29:44:BF:27|True|VMware|NONE|067d7440-8238-47b5-b63f-f5a9a9ad28d3
	//$Label|$DEV|$NoOfStorage|$MacAddress|$SameSystem|$Model|$Serial|$CloudID
	private String label;
	private String name;
	private int noOfStorage;
	private String MACAddress;
	private boolean isSameSystem;
	private String model;
	private String serial;
	private String cloudID;
	private String securityString;
	public String getLabel() {
		return label;
	}
	public void setLabel(String label) {
		this.label = label;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getNoOfStorage() {
		return noOfStorage;
	}
	public void setNoOfStorage(int noOfStorage) {
		this.noOfStorage = noOfStorage;
	}
	public String getMACAddress() {
		return MACAddress;
	}
	public void setMACAddress(String mACAddress) {
		MACAddress = mACAddress;
	}
	public boolean isSameSystem() {
		return isSameSystem;
	}
	public void setSameSystem(boolean isSameSystem) {
		this.isSameSystem = isSameSystem;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getSerial() {
		return serial;
	}
	public void setSerial(String serial) {
		this.serial = serial;
	}
	public String getCloudID() {
		return cloudID;
	}
	public void setCloudID(String cloudID) {
		this.cloudID = cloudID;
	}
	public String getSecurityString() {
		return securityString;
	}
	public void setSecurityString(String securityString) {
		this.securityString = securityString;
	}
	public void guid() {
		// TODO Auto-generated method stub
		
	}
}
