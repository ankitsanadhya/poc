/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.mwp.appliance.parser.vo;

import com.mwp.common.Utils;

public class AppVolumeVO {

	private String repoName;
	private String volumePath;
	private String appBasePath;
	private long total;
	private long used;
	private long free;
	private String totalDisplay;
	private String usedDisplay;
	private String freeDisplay;
	private String usedPercentage;

	public AppVolumeVO(String repoName, String volumePath, String appBasePath, long total, long free, long used, String usedPercentage) {
		this.setRepoName(repoName);
		this.setVolumePath(volumePath);
		this.setAppBasePath(appBasePath);
		this.setTotal(total);
		this.setFree(free);
		this.setUsed(used);		
		this.setUsedPercentage(usedPercentage);
	}

	public String getRepoName() {
		return repoName;
	}
	public void setRepoName(String repoName) {
		this.repoName = repoName;
	}
	public String getVolumePath() {
		return volumePath;
	}
	public void setVolumePath(String volumePath) {
		this.volumePath = volumePath;
	}
	public String getAppBasePath() {
		return appBasePath;
	}
	public void setAppBasePath(String appBasePath) {
		this.appBasePath = appBasePath;
	}
	public long getTotal() {
		return total;
	}
	public void setTotal(long total) {
		this.total = total;
		String[] totalArr = Utils.SizeConverter(total);
		this.totalDisplay = totalArr[0] + " " + totalArr[1];
	}
	public long getUsed() {
		return used;
	}
	public void setUsed(long used) {
		this.used = used;
		String[] usedArr = Utils.SizeConverter(used);
		this.usedDisplay = usedArr[0] + " " + usedArr[1];
	}
	public long getFree() {
		return free;
	}
	public void setFree(long free) {
		this.free = free;
		String[] freeArr = Utils.SizeConverter(free);
		this.freeDisplay = freeArr[0] + " " + freeArr[1];
	}
	public String getUsedPercentage() {
		return usedPercentage;
	}
	public void setUsedPercentage(String usedPercentage) {
		this.usedPercentage = usedPercentage;
	}
	public String getTotalDisplay() {
		return totalDisplay;
	}
	public String getUsedDisplay() {
		return usedDisplay;
	}
	public String getFreeDisplay() {
		return freeDisplay;
	}
}