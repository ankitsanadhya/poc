/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.mwp.appliance.parser.vo;

import com.mwp.common.Utils;

public class StorageInfoVO
{
	private long diskCount;
	private String partition;
	private String type;
	private String displayType;
	private String status;
	private String rebuildStatus;
	private long rebuildProg1,rebuildProg2,rebuildProg3;
	private double rebuildProgress;
	private long total,used,free;
	private String formattedTotal,formattedUsed,formattedFree;
	
	private String formattedTotalValue, formattedUsedValue, formattedFreeValue;
	private String formattedTotalUnit, formattedUsedUnit, formattedFreeUnit;

	public long getDiskCount()
	{
		return diskCount;
	}
	public void setDiskCount(String diskCount)
	{
		this.diskCount=Long.parseLong(diskCount);
	}
	public void setDiskCount(long diskCount)
	{
		this.diskCount=diskCount;
	}
	public String getPartition()
	{
		return partition;
	}
	public void setPartition(String partition) {
		this.partition = partition;
	}
	public void setType(String type) {
		this.type = type.trim();
		setDisplayType();
	}
	public String getType() {
		return type;
	}
	public String getDisplayType() {
		return displayType;
	}
	private void setDisplayType() {
		if(this.type.equalsIgnoreCase("Raid0"))
			this.displayType = "RAID 0";
		else if(this.type.equalsIgnoreCase("Raid1"))
			this.displayType = "RAID 1";
		else if(this.type.equalsIgnoreCase("Raid5"))
			this.displayType = "RAID 5";
		else if(this.type.equalsIgnoreCase("Raid6"))
			this.displayType = "RAID 6";
		else
			this.displayType = "Spanned";
	}
	
	public void setStatus(String status) {
		if(status.equals(""))
			status = "Missing";
		this.status = status;
	}
	public String getStatus() {
		return status;
	}
	public void setRebuildStatus(String rebuildStatus) {
		if(rebuildStatus.equals(""))
			rebuildStatus = "Missing";
		this.rebuildStatus = rebuildStatus;
	}
	public String getRebuildStatus() {
		return rebuildStatus;
	}
	public void setRebuildProg1(String rebuildProg1) {
		if(rebuildProg1.equals("") || rebuildProg1.equals("delayed"))
			this.rebuildProg1 = 0;
		else
			this.rebuildProg1 = Long.parseLong(rebuildProg1);
	}
	public long getRebuildProg1() {
		return rebuildProg1;
	}
	public void setRebuildProg2(String rebuildProg2) {
		if(rebuildProg2.equals(""))
			this.rebuildProg2 = 0;
		else
			this.rebuildProg2 = Long.parseLong(rebuildProg2);
	}
	public long getRebuildProg2() {
		return rebuildProg2;
	}
	public void setRebuildProg3(String rebuildProg3) {
		if(rebuildProg3.equals(""))
			this.rebuildProg3 = 0;
		else
			this.rebuildProg3 = Long.parseLong(rebuildProg3);
	}
	public long getRebuildProg3() {
		return rebuildProg3;
	}
	
	public double getRebuildProgress() {
		if(rebuildProg2 != 0)
			rebuildProgress = ((float)rebuildProg1 * 100)/rebuildProg2;
		else
			rebuildProgress = 0;
		
		rebuildProgress = Double.parseDouble(String.format("%.1f", rebuildProgress));
		
		return rebuildProgress;
	}
	
	public void setTotal(String total)
	{
		if(total.equals(""))
			this.total = 0;
		else
			this.total = Long.parseLong(total);

		//this.total = this.total - 104857600; // 100 MB margin
		
		//long totalInByts = Long.parseLong(total) ;
		String[] formattedTotalStrs = Utils.SizeConverter(this.total);
		formattedTotal = formattedTotalStrs[0] + " " + formattedTotalStrs[1];
		formattedTotalValue = formattedTotalStrs[0];
		formattedTotalUnit = formattedTotalStrs[1];
	}
	public void setTotal(long total) {
		this.total = total;
		
		//this.total = this.total - 104857600; // 100 MB margin
		
		long totalInByts = total;
		String[] formattedTotalStrs = Utils.SizeConverter(totalInByts);
		formattedTotal = formattedTotalStrs[0] + " " + formattedTotalStrs[1];
		formattedTotalValue = formattedTotalStrs[0];
		formattedTotalUnit = formattedTotalStrs[1];
	}
	public long getTotal() {
		return total;
	}
	public void setUsed(String used) {
		
		if(used.equals(""))
			this.used = 0;
		else
			this.used = Long.parseLong(used);

		//long totalInByts = Long.parseLong(used);
		String[] formattedTotalStrs = Utils.SizeConverter(this.used);
		formattedUsed = formattedTotalStrs[0] + " " + formattedTotalStrs[1];
		formattedUsedValue = formattedTotalStrs[0];
		formattedUsedUnit = formattedTotalStrs[1];
	}
	public void setUsed(long used) {
		this.used = used;
		long totalInByts = used;
		String[] formattedTotalStrs = Utils.SizeConverter(totalInByts);
		formattedUsed = formattedTotalStrs[0] + " " + formattedTotalStrs[1];
		formattedUsedValue = formattedTotalStrs[0];
		formattedUsedUnit = formattedTotalStrs[1];
	}
	public long getUsed() {
		return used;
	}
	public void setFree(String free) {
		if(free.equals(""))
			this.free = 0;
		else
			this.free = Long.parseLong(free);

		//this.free = this.total - this.used;
		
		//long totalInByts = Long.parseLong(free);
		String[] formattedTotalStrs = Utils.SizeConverter(this.free);
		formattedFree = formattedTotalStrs[0] + " " + formattedTotalStrs[1];
		formattedFreeValue = formattedTotalStrs[0];
		formattedFreeUnit = formattedTotalStrs[1];
	}
	public void setFree(long free) {
		this.free = free;
		
		//this.free = this.total - this.used;
		
		long totalInByts = free;
		String[] formattedTotalStrs = Utils.SizeConverter(totalInByts);
		formattedFree = formattedTotalStrs[0] + " " + formattedTotalStrs[1];
		formattedFreeValue = formattedTotalStrs[0];
		formattedFreeUnit = formattedTotalStrs[1];
	}
	public long getFree() {
		return free;
	}
	public String getFormattedTotal() {
		return formattedTotal;
	}
	public String getFormattedUsed() {
		return formattedUsed;
	}
	public String getFormattedFree() {
		return formattedFree;
	}
	public String getFormattedTotalValue() {
		return formattedTotalValue;
	}
	public String getFormattedUsedValue() {
		return formattedUsedValue;
	}
	public String getFormattedFreeValue() {
		return formattedFreeValue;
	}
	public String getFormattedTotalUnit() {
		return formattedTotalUnit;
	}
	public String getFormattedUsedUnit() {
		return formattedUsedUnit;
	}
	public String getFormattedFreeUnit() {
		return formattedFreeUnit;
	}
	public void guid() {
		// TODO Auto-generated method stub
		
	}
}
