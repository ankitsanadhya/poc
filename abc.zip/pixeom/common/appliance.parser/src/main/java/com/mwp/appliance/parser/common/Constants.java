/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.mwp.appliance.parser.common;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

import com.mwp.appliance.parser.vo.ForwaredPorts;

public class Constants {
	
	public static String DefaultTomcatPort = "443";//""8888";


	public static ForwaredPorts currentlyForwaredPorts = null;
	public  static ForwaredPorts getCurrentlyForwaredPorts() {
		return currentlyForwaredPorts;				
	}
	
	public final static String LOCAL_PNF_SERVICE_PATH = "https://localhost/com.pixeom.pnf.restservice/api/";

	public static String LoginServiceJar = "LoginService.jar";
	public static String TaskManagerServiceJar = "TaskManagerService.jar";
	public static String UDPServerJar = "UDPServer.jar";

	public static String Disk_Type_System = "System Disks";
	public static String Disk_Type_Backup = "Backup Disks";
	public static String Disk_Type_Spare = "Spare Disks";
	public static String Disk_Type_VolumeGroups = "Volume Groups";

	public static String LISTING_SERVER_IP = "mypixeom.com";

	public static String DB_Backup_Path = "/etc/pixeom/";

	public static String OPT_PATH = "/opt/app_engine/";

	public static boolean FormattingDevice = false;
	public static String FormattingDeviceMsg = "";
	
	public static boolean RunCheckService = true;
	public static boolean RunManualService = false;
	
	/**
	 * This variable value is used to break the sleep for UpdateDiscoveryDetails so that DiscoveryDetails and state are updated instantly
	 * @author DB 
	 */
	public static boolean BreakDiscoveryDetailsSleep = false;
	
	/*
	 * Default path where temporary ring file created by SHELL Scripts.
	 * Also, Ring file should be placed here before Apply Temp Ring File 
	 */
	public static String TempRingFilePath = DB_Backup_Path + "SwiftTempRing/SwiftTempRing.tar.gz";
	
	public static String UpdateFileFilePath = "";
	public static String getTempPath() {
		String tempPath = "/data/temp/";
		File f = new File(OPT_PATH + "TempPath");
		if(f.exists()) {
			try {
				BufferedReader br = new BufferedReader(new FileReader(OPT_PATH + "TempPath"));
				try {
					tempPath = br.readLine().trim();
				} finally {
					br.close();
				}
			} catch(Exception e) {
			}
		}
		return tempPath;
	}

	public static String MasterNode = "MasterNode";
	public static String SlaveNode = "SlaveNode";
	public static String StorageNode = "StorageNode";
	public static String StandAloneNode = "StandAloneNode";

	public static String Command_UpdateRing = "AddDisk";
	public static String Command_AddDisk = "AddDisk";
	public static String Command_RemoveDisk = "RemoveDisk";
	public static String Command_ReAddOSDrive = "ReAddOSDrive";
	public static String Command_AddNode = "AddNode";
	public static String Command_RemoveNode = "RemoveNode";
	public static String Command_FileReplication = "FileReplication";
	public static String Command_EditNetwork = "EditNetwork";
	public static String Command_ReplaceHead = "Replace Head";

	public static String Rebalancing = "rebalancing";
	public static String Failed = "failed";
	public static String Adding = "adding";
	public static String Formatting = "formatting";
	public static String Removing = "removing";
	public static String Completed = "completed";
	public static String Online = "online";
	public static String Offline = "offline";
	public static String Spare = "spare";

	public static String RebalancingRingMSG = "Rebalancing data - please try later.";
	public static String RingFileNotAppliedMSG = "Cloud configuration check in progress - please try later.";

	public static final String QUORUM_MAJORITY = "Majority";
	public static final String QUORUM_SPLITBRAIN = "SplitBrain";
	public static final String QUORUM_MINORITY = "Minority";
	
	public static final String SECURITY_STRING = "EncryptMe";

	public enum NodeDeviceStatus {
		online(0),
		away(1),
		offline(2);

		private int num;

		NodeDeviceStatus(int n) {
			num = n;
		}

		public int getValue() {
			return num;
		}
	}
}
