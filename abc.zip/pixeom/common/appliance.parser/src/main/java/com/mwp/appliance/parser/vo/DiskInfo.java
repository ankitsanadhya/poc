/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.mwp.appliance.parser.vo;


public class DiskInfo {

	private String Label;
	private String Name;
	private String Type="New";
	private String Status;
	private long Total;
	private long Used;
	private long Free;
	private String Model = "";
	private String SerialNo = "";
	private String OEM = "";
	private boolean IsAvailable = true;
	private boolean IsEncrypted = false;
	private boolean IsSpare = false;

	private String fileSystem = "";
	private boolean isMounted = false;
	private String mountPoint = "";
	
	private String diskHealth = "";

	public String getLabel() {
		return Label;
	}
	public void setLabel(String label) {
		Label = label;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getType() {
		return Type;
	}
	public void setType(String type) {
		Type = type;
	}
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	public long getTotal() {
		return Total;
	}
	public void setTotal(long total) {
		Total = total;
	}
	public long getUsed() {
		return Used;
	}
	public void setUsed(long used) {
		Used = used;
	}
	public long getFree() {
		return Free;
	}
	public void setFree(long free) {
		Free = free;
	}
	public String getModel() {
		return Model;
	}
	public void setModel(String model) {
		Model = model;
	}
	public String getSerialNo() {
		return SerialNo;
	}
	public void setSerialNo(String serialNo) {
		SerialNo = serialNo;
	}
	public boolean isIsAvailable() {
		return IsAvailable;
	}
	public void setIsAvailable(boolean isAvailable) {
		IsAvailable = isAvailable;
	}
	public void guid() {
		// TODO Auto-generated method stub

	}
	public String getOEM() {
		return OEM;
	}
	public void setOEM(String oEM) {
		OEM = oEM;
	}
	public boolean isIsEncrypted() {
		return IsEncrypted;
	}
	public void setIsEncrypted(boolean isEncrypted) {
		IsEncrypted = isEncrypted;
	}
	public String getFileSystem() {
		return fileSystem;
	}
	public void setFileSystem(String fileSystem) {
		this.fileSystem = fileSystem;
	}
	public boolean isMounted() {
		return isMounted;
	}
	public void setMounted(boolean isMounted) {
		this.isMounted = isMounted;
	}
	public String getMountPoint() {
		return mountPoint;
	}
	public void setMountPoint(String mountPoint) {
		this.mountPoint = mountPoint;
		if(mountPoint != null && !"".equals(mountPoint)) {
			this.isMounted = true;
		}
	}
	public String getDiskHealth() {
		return diskHealth;
	}
	public void setDiskHealth(String diskHealth) {
		this.diskHealth = diskHealth;
	}
	public boolean isIsSpare() {
		return IsSpare;
	}
	public void setIsSpare(boolean isSpare) {
		IsSpare = isSpare;
	}
}
