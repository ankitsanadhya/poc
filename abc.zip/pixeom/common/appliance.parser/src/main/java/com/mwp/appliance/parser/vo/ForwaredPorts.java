/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.mwp.appliance.parser.vo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.mwp.appliance.parser.common.Constants;
import com.mwp.appliance.parser.common.PortalNetworkInterface;
import com.mwp.common.enums.RelayEnum.NetworkTypeEnum;

public class ForwaredPorts implements Serializable 
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private NetworkTypeEnum NetworkType = NetworkTypeEnum.LAN;

	private String RouterIP = "";

	private String RelayServerID = "";

	private String RelayServerAddress = "";

	private String CurrentConnectedIP="";

	private String CurrentConnectedPort="";
	
	private String currentConnectedKeystonePort ="";

	private String RelayServerUsername = "";

	private String RelayServerPassword = "";

	private String RelayServerPort = "";

	private String RURLAddress = "";

	private Boolean isRelaySet = false;

	private String hostName = "";

	public String getHostName() {
		return hostName;
	}
	public void setHostName(String hostName) {
		this.hostName = hostName;
	}

	String ipReal="";
	public String getIpReal() {
		return ipReal;
	}
	public void setIpReal(String ipReal) {
		this.ipReal = ipReal;
	}
	String connectURL="";
	public String getConnectURL() {
		return connectURL;
	}
	public void setConnectURL(String connectURL) {
		this.connectURL = connectURL;
	}

	public Boolean getIsRelaySet() {
		return isRelaySet;
	}
	public void setIsRelaySet(Boolean isRelaySet) {
		this.isRelaySet = isRelaySet;
	}
	public void setRURLAddress(String rURLAddress){
		RURLAddress = rURLAddress;
	}
	public String getRURLAddress(){
		return RURLAddress;
	}

	private String RURLTomcatPort="";
	public String getRURLTomcatPort() {
		return RURLTomcatPort;
	}
	//private String RURLKeystonePort="";
	public void setRURLTomcatPort(String rURLTomcatPort) {
		RURLTomcatPort = rURLTomcatPort;
	}
//
//	public String getRURLKeystonePort() {
//		return RURLKeystonePort;
//	}
//
//	public void setRURLKeystonePort(String rURLKeystonePort) {
//		RURLKeystonePort = rURLKeystonePort;
//	}

	private boolean isRURLSet = false;

	public void setisRURLSet(boolean isRURLSet){
		this.isRURLSet = isRURLSet;
		if(!isRURLSet){
		//	RURLKeystonePort = "";
			RURLTomcatPort = "";
			RURLAddress = "";
		}
	}

	public boolean getisRURLSet(){
		return isRURLSet;
	}

	//private String CurrentOpenstackPort="";

	private List<String> LanIPAddresses =  new ArrayList<String>();

	private List<String> ExternalIPaddress = new ArrayList<String>();

	private String BoxID = "";

	//private String DefaultChatInputChannel = Constants.DefaultChatInputChannel;

	//private String DefaultChatOutputChannel = Constants.DefaultChatOutputChannel;

	//private String DefaultChatSubscriptionChannel = Constants.DefaultChatSubscriptionChannel;

	private String DefaultTomcatPort = Constants.DefaultTomcatPort;

	//private String DefaultOpecStackePort = Constants.DefaultOpenstackPort;

	//private String DefaultKeyStonePOrt = Constants.DefaultKeyStonePort;

	//private String DefaultNodeCommunicationPort = Constants.DefaultNodeCommunicationPort;

	//private String DefaultHTTPPort = Constants.DefaultHTTPPort;

	//	private String ChatInputChannel = "";
	//
	//	private String ChatOutputChannel = "";
	//
	//	private String ChatSubscriptionChannel = "";

	private String TomcatPort = "";

	//	private String OpenStackPort = "";

//	private String KeyStonePort = "";

	//	private String NodeCommunicationPort = "";

	//	private String HTTPPort = Constants.DefaultHTTPPort;

	public String getRouterIP() {
		return RouterIP;
	}

	public void setRouterIP(String routerIP) {
		RouterIP = routerIP;
	}

	public NetworkTypeEnum getNetworkType()
	{
		return NetworkType;		
	}

	public void setNetworkType(NetworkTypeEnum networkType)
	{
		NetworkType = networkType;
	}

	public String getRelayServerID() {
		return RelayServerID;
	}

	public void setRelayServerID(String relayServerID) {
		RelayServerID = relayServerID;
	}

	public String getRelayServerAddress() {
		return RelayServerAddress;
	}

	public void setRelayServerAddress(String relayServerAddress) {
		RelayServerAddress = relayServerAddress;
	}

	public List<String> getLanIPAddresses() 
	{
		if(LanIPAddresses.size()==0)
		{
			LanIPAddresses.addAll(PortalNetworkInterface.GetIpAddress());
		}
		return LanIPAddresses;
	}

	public void setLanIPAddresses(List<String> lanIPAddresses) {
		LanIPAddresses = lanIPAddresses;
	}

	public List<String> getExternalIPaddress() {
		return ExternalIPaddress;
	}

	public void setExternalIPaddress(List<String> extrnalIPaddress) {
		ExternalIPaddress = extrnalIPaddress;
	}

	public String getBoxID() 
	{
		try
		{
//			if(StringFunctions.isNullOrWhitespace(BoxID))
//				return BoxConfigurations.getInstance().getBoxDetails().getDeviceID();
//			else
				return BoxID;
		} catch (Exception e)
		{
			// TODO Auto-generated catch block
//			PALogger.ERROR(e);
		}
		return "";
	}

	public void setBoxID(String boxID) {
		BoxID = boxID;
	}

	//	public String getDefaultChatInputChannel() {
	//		return DefaultChatInputChannel;
	//	}
	//
	//	public String getDefaultChatOutputChannel() {
	//		return DefaultChatOutputChannel;
	//	}
	//
	//	public String getDefaultChatSubscriptionChannel() {
	//		return DefaultChatSubscriptionChannel;
	//	}

	public String getDefaultTomcatPort() {
		return DefaultTomcatPort;
	}

	//	public String getDefaultOpecStackePort() {
	//		return DefaultOpecStackePort;
	//	}

//	public String getDefaultKeyStonePOrt() {
//		return DefaultKeyStonePOrt;
//	}

	//	public String getDefaultNodeCommunicationPort() {
	//		return DefaultNodeCommunicationPort;
	//	}
	//	
	//	public String getDefaultHTTPPort() {
	//		return DefaultHTTPPort;
	//	}

	//	public String getChatInputChannel() {
	//		return ChatInputChannel;
	//	}
	//
	//	public void setChatInputChannel(String chatInputChannel) {
	//		ChatInputChannel = chatInputChannel;
	//	}
	//
	//	public String getChatOutputChannel() {
	//		return ChatOutputChannel;
	//	}
	//
	//	public void setChatOutputChannel(String chatOutputChannel) {
	//		ChatOutputChannel = chatOutputChannel;
	//	}
	//
	//	public String getChatSubscriptionChannel() {
	//		return ChatSubscriptionChannel;
	//	}
	//
	//	public void setChatSubscriptionChannel(String chatSubscriptionChannel) {
	//		ChatSubscriptionChannel = chatSubscriptionChannel;
	//	}

	public String getTomcatPort() {
		return TomcatPort;
	}

	public void setTomcatPort(String tomcatPort) {
		TomcatPort = tomcatPort;
		//OpenStackPort = tomcatPort;
		//NodeCommunicationPort = tomcatPort;
	}

	//	public String getOpenStackPort() {
	//		return OpenStackPort;
	//	}

	/*public void setOpenStackPort(String openStackPort) {
		OpenStackPort = openStackPort;
	}*/

//	public String getKeyStonePort() {
//		return KeyStonePort;
//	}
//
//	public void setKeyStonePort(String keyStonePort) {
//		KeyStonePort = keyStonePort;
//	}

	//	public String getNodeCommunicationPort() {
	//		return NodeCommunicationPort;
	//	}

	/*public void setNodeCommunicationPort(String nodeCommunicationPort) {
		NodeCommunicationPort = nodeCommunicationPort;
	}*/

	public String getCurrentConnectedIP() {
		return CurrentConnectedIP;
	}

	public void setCurrentConnectedIP(String currentConnectedIP) {
		CurrentConnectedIP = currentConnectedIP;
	}

	public String getCurrentConnectedPort() {
		return CurrentConnectedPort;
	}

	public void setCurrentConnectedPort(String currentConnectedPort) {
		CurrentConnectedPort = currentConnectedPort;
	}

	public String getCurrentConnectedKeystonePort() {
		return currentConnectedKeystonePort;
	}

	public void setCurrentConnectedKeystonePort(String keystonePort) {
		currentConnectedKeystonePort = keystonePort;
	}


	//	public String getHTTPPort() {
	//		return HTTPPort;
	//	}
	//
	//	public void setHTTPPort(String hTTPPort) {
	//		HTTPPort = hTTPPort;
	//	}

	public String getRelayServerUsername() {
		return RelayServerUsername;
	}
	public void setRelayServerUsername(String relayServerUsername) {
		RelayServerUsername = relayServerUsername;
	}
	public String getRelayServerPassword() {
		return RelayServerPassword;
	}
	public void setRelayServerPassword(String relayServerPassword) {
		RelayServerPassword = relayServerPassword;
	}
	public String getRelayServerPort() {
		return RelayServerPort;
	}
	public void setRelayServerPort(String relayServerPort) {
		RelayServerPort = relayServerPort;
	}
	public boolean isRURLSet() {
		return isRURLSet;
	}
	public void setRURLSet(boolean isRURLSet) {
		this.isRURLSet = isRURLSet;
	}
	public void setDefaultTomcatPort(String defaultTomcatPort) {
		DefaultTomcatPort = defaultTomcatPort;
	}
//	public void setDefaultKeyStonePOrt(String defaultKeyStonePOrt) {
//		DefaultKeyStonePOrt = defaultKeyStonePOrt;
//	}




}