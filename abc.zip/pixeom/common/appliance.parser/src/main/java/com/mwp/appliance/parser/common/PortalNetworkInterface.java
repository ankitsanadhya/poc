/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.mwp.appliance.parser.common;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.List;

import com.mwp.logger.PALogger;

public class PortalNetworkInterface 
{

	public static List<String> GetIpAddress() 
	{
		List<String> ipList = new ArrayList<String>();
		try
		{
			Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces();
			while (interfaces.hasMoreElements()) 
			{
				try
				{
					NetworkInterface iface = interfaces.nextElement();
					// filters out 127.0.0.1 and inactive interfaces
					if (iface.isLoopback() || !iface.isUp())
						continue;

					Enumeration<InetAddress> addresses = iface.getInetAddresses();
					while(addresses.hasMoreElements()) 
					{
						InetAddress addr = addresses.nextElement();

						if(addr.isLoopbackAddress())
							continue;

						if (addr instanceof Inet4Address) 
						{
							String ip = addr.getHostAddress();
							if(ip != null && !ip.equals(""))
							{
								ipList.add(ip);
							}
						}
					}
				}
				catch (Exception e)
				{
//					PALogger.ERROR(e);
				}
			}
		}
		catch(Exception e)
		{
//			PALogger.ERROR(e);
		}

		return ipList;	
	}

	 /**
	 * This method is used to used to get machine information
	 * @throws Exception
	 */
	private static String getMachineInfo() throws IOException, InterruptedException {
		String machineInfo="";
		try {
			Process ps1 = Runtime.getRuntime().exec(Constants.OPT_PATH + "utils/system_command GetMachineInfo");
			InputStream in = ps1.getInputStream(); 
			BufferedReader reader = new BufferedReader(new InputStreamReader(in)); 
			in = ps1.getInputStream(); 
			reader = new BufferedReader(new InputStreamReader(in)); 

			String line = null;
			while( (line=reader.readLine())!=null) { 
				machineInfo=line; 
				machineInfo=machineInfo.trim();
			}
			reader.close();
		} catch(Exception e) {
		}
		return machineInfo;
	}
	
	 /**
	 * This method is used to used to parse machine information
	 * @throws Exception
	 */
	private static Hashtable<String, String> parsingMachineInfo(String machineInfo) {
		Hashtable<String, String> commands = new Hashtable<String, String>();

		if(machineInfo != null &&  !machineInfo.equals("")) {
			String[] machineInfoArr = machineInfo.split(",");

			/*
			 * VMwareVirtualPlatform,
			 * 00:0C:29:EF:25:2B,
			 * VMware-564d7f5de275622e-e0a12429edef252b,
			 * 564D7F5D-E275-622E-E0A1-2429EDEF252B,
			 * VMwareInc.,
			 * 2,
			 * Intel(R)Core(TM)2E8400@3.00GHz Intel(R)Core(TM)2E8400@3.00GHz,
			 * eth1:1000Mb/s,*/
			if(machineInfoArr.length > 2) {
				commands.put("ComputerModel", machineInfoArr[0].trim());
				commands.put("MacAddress", machineInfoArr[1].trim());
				//commands.put("MachineName", machineInfoArr[2]);
				//commands.put("MotherBoardId", machineInfoArr[3]);
				//commands.put("MotherBoardManufacturer", machineInfoArr[4]);
				//commands.put("CPUCORES", machineInfoArr[5]);
				//commands.put("CPUMODEL", machineInfoArr[6]);
				//commands.put("NICSpeed", machineInfoArr[7]);
			}			
		}

		return commands;
	}
	
	 /**
	 * This method is used to used to get MAC address
	 * @throws Exception
	 */
	public static String GetMacAddress() {
		String macaddress="";

		try {
//			if(BoxConfigurations.getInstance().getBoxDetails().getMWFSID().equals("")) {
				String machineInfo = getMachineInfo();
				Hashtable<String, String> machineInfoHash = parsingMachineInfo(machineInfo);

				if(machineInfoHash.containsKey("MacAddress")) {
					macaddress = machineInfoHash.get("MacAddress");
					macaddress = macaddress.replace(":", "-");
				} 

//			} else {
//				macaddress = BoxConfigurations.getInstance().getBoxDetails().getMWFSID();
//			}
		} catch (Exception e) {
//			PALogger.ERROR(e);
			PALogger.ERROR(e.getMessage());
		}



		/*try
		{
			Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces();
			while (interfaces.hasMoreElements()) 
			{
				try
				{
					NetworkInterface iface = interfaces.nextElement();
					// filters out 127.0.0.1 and inactive interfaces
					if (iface.isLoopback() || !iface.isUp())
						continue;

					byte[] mac = iface.getHardwareAddress();

					StringBuilder sb = new StringBuilder();
					for (int i = 0; i < mac.length; i++) {
						sb.append(String.format("%02X%s", mac[i], (i < mac.length - 1) ? "-" : ""));		
					}
					macaddress = sb.toString();

					if(macaddress.length() == 17) {
						break;
					}
				}
				catch (Exception e)
				{
					PALogger.ERROR(e);
				}
			}
		}
		catch(Exception e)
		{
			PALogger.ERROR(e);
		}*/

		return macaddress;	
	}
}
