/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.mwp.appliance.parser.vo;

import com.mwp.common.Utils;

public class ManageStorageVO {

	private String name;
	private long total;
	private long used;
	private long free;
	private String totalDisplay;
	private String usedDisplay;
	private String freeDisplay;

	public ManageStorageVO(String name, long total, long used, long free) {
		this.setName(name);
		this.setTotal(total);
		this.setUsed(used);
		this.setFree(free);
	}

	public ManageStorageVO(String name, String totalDisplay, String usedDisplay, String freeDisplay) {
		this.setName(name);
		this.setTotalDisplay(totalDisplay);
		this.setUsedDisplay(usedDisplay);
		this.setFreeDisplay(freeDisplay);
	}

	public String getName() {
		return name;
	}
	private void setName(String name) {
		this.name = name;
	}
	public long getTotal() {
		return total;
	}
	private void setTotal(long total) {
		this.total = total;
		String[] totalArr = Utils.SizeConverter(total);
		this.totalDisplay = totalArr[0] + " " + totalArr[1];
	}
	public long getUsed() {
		return used;
	}
	private void setUsed(long used) {
		this.used = used;
		String[] usedArr = Utils.SizeConverter(used);
		this.usedDisplay = usedArr[0] + " " + usedArr[1];
	}
	public long getFree() {
		return free;
	}
	private void setFree(long free) {
		this.free = free;
		String[] freeArr = Utils.SizeConverter(free);
		this.freeDisplay = freeArr[0] + " " + freeArr[1];
	}
	public String getTotalDisplay() {
		return totalDisplay;
	}
	private void setTotalDisplay(String totalDisplay) {
		this.totalDisplay = totalDisplay;
		this.total = Utils.SizeReverseConverter(totalDisplay);
	}
	public String getUsedDisplay() {
		return usedDisplay;
	}
	private void setUsedDisplay(String usedDisplay) {
		this.usedDisplay = usedDisplay;
		this.used = Utils.SizeReverseConverter(usedDisplay);
	}
	public String getFreeDisplay() {
		return freeDisplay;
	}
	private void setFreeDisplay(String freeDisplay) {
		this.freeDisplay = freeDisplay;
		this.free = Utils.SizeReverseConverter(freeDisplay);
	}
}