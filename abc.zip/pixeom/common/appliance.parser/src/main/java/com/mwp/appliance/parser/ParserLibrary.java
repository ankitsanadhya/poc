/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.mwp.appliance.parser;

import java.net.InetAddress;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang3.StringUtils;

import com.google.gson.Gson;
import com.mwp.appliance.parser.common.Constants;
import com.mwp.appliance.parser.vo.AppVolumeVO;
import com.mwp.appliance.parser.vo.BondedNicVO;
import com.mwp.appliance.parser.vo.DeviceVO;
import com.mwp.appliance.parser.vo.DiskInfo;
import com.mwp.appliance.parser.vo.DriveInfoVO;
import com.mwp.appliance.parser.vo.ForwaredPorts;
import com.mwp.appliance.parser.vo.HotspotClientDetails;
import com.mwp.appliance.parser.vo.MachineInfoVO;
import com.mwp.appliance.parser.vo.ManageStorageVO;
import com.mwp.appliance.parser.vo.ShowNetworkVO;
import com.mwp.appliance.parser.vo.ShowVersionVO;
import com.mwp.appliance.parser.vo.StorageInfoVO;
import com.mwp.appliance.parser.vo.TempPathVO;
import com.mwp.appliance.parser.vo.WifiDetails;
import com.mwp.common.StringFunctions;
import com.mwp.logger.PALogger;

public class ParserLibrary {

	public static final String PUBLIC_NETWORK = "Public Network";
	public static final String CLUSTER_NETWORK = "Cluster Network";

	@SuppressWarnings("serial")
	static ArrayList<String> badCharacters = new ArrayList<String>()
	{{
		add("[0;39m");
		add("[0;33m");
		add("[0;32m");
		add("[0;31m");
		add("");
	}};

	private ParserLibrary() { }

	private static ParserLibrary instance;
	public static ParserLibrary getInstance() {
		if(instance == null)
			instance = new ParserLibrary();
		return instance;
	}

	/**
	 * This method is used to used to trim and clean parser library
	 * @throws Exception
	 */
	public String trimAndClean(String value) {
		String returnValue = "";
		if (value == null) {
			return value;
		} else {
			returnValue = value.trim();
		}

		for (String remove : badCharacters) {
			returnValue = returnValue.replace(remove, "");
		}
		return 	returnValue; 
	}

	/**
	 * This method is used to used to change bytes to MB
	 * @throws Exception
	 */
	public long ChangeBytesToMB(long bytes) {
		long mb = 0;
		if (bytes < 1024 * 1024) {
			mb = 0;
		} else {
			mb = (long) (bytes >> 20);
		}
		return mb;
	}

	public String GetHostName(String result) {
		return GetHostName(result, false);
	}

	/**
	 * This method is used to used to get Host Name
	 * @throws Exception
	 */
	public String GetHostName(String result, boolean includeFqdn) {
		String[] str1 = result.split("\n");	
		String hostname=str1[1].split("\\|")[0];

		if(includeFqdn) {
			String domainname = "." + str1[1].split("\\|")[1];

			return hostname+domainname;
		} else {
			return hostname;
		}
	}

	/**
	 * This method is used to used to get Domain name
	 * @throws Exception
	 */
	public String GetDomainName(String result) {
		String[] str1 = result.split("\n");	
		String[] domainNameArr = str1[1].split("\\|");
		if(domainNameArr.length > 1) {
			return domainNameArr[1];
		} else {
			return StringUtils.EMPTY;
		}
	}

	/**
	 * This method is used to used to set values as started, stopped, disabled and enabled
	 * @throws Exception
	 */
	public String setValues(String res) {
		if(res.trim().equalsIgnoreCase("OK") || res.trim().equalsIgnoreCase("Started")) {
			return "Started";
		} else if(res.trim().equalsIgnoreCase("STOPPED") || res.trim().equalsIgnoreCase("Stopped")) {
			return "Stopped";
		} else if(res.trim().equalsIgnoreCase("DISABLED") || res.trim().equalsIgnoreCase("Disabled")) {
			return "Disabled";
		} else {
			return "Enabled";
		}
	}

	public ArrayList<String> ntpList(String responce) {
		ArrayList<String> NtpList = new ArrayList<String>();
		//   0.centos.pool.ntp.org: 1.centos.pool.ntp.org:2.centos.pool.ntp.org
		//		String r= responce.replace(":"," ");
		String listntp[] = responce.split(":");

		for (String string : listntp) {
			NtpList.add(string.trim());
		}

		return NtpList;
	}

	public ForwaredPorts ParseGetPortMapperList(String responseString, String MACAddress, List<String> IPAddresses) {
		ForwaredPorts fp = new ForwaredPorts();

		//		Ports forwarded by MeghaWare ...
		//		4800 192.168.11.96 8888 MeghaWareCloud-00:0C:29:03:95:1E 0 
		//		4801 192.168.11.96 4000 MeghaWareCloud-00:0C:29:03:95:1E 0 
		//		4801 192.168.11.96 4000 miniupnpd 0 
		//		4801 192.168.11.96 4000 libminiupnpc 0 

		String[] res = responseString.trim().split("\n");
		if(res!=null) {
			if(res.length>0) {
				for(int i=0;i<res.length;i++) {
					String[] result = res[i].trim().split(" ");
					if(result.length == 5) {
						String IPaddress = result[1].trim();
						if(IPAddresses.contains(IPaddress)) {
							String serverStr = result[3].trim();
							serverStr = serverStr.replace(":", "-");
							if(serverStr.toLowerCase().contains("miniupnp")) //serverStr.toLowerCase().startsWith(MWFSConstant.PRODUCT_NAME) ||
							{
								//if(result[2].trim().equals(Constants.DefaultOpenstackPort)) {
								//	fp.setOpenStackPort(result[0].trim());
								//} else
								//if(result[2].trim().equals(Constants.DefaultChatInputChannel)) {
								//	fp.setChatInputChannel(result[0].trim());
								//} else if(result[2].trim().equals(Constants.DefaultChatOutputChannel)) {
								//fp.setChatOutputChannel(result[0].trim());
								//} else if(result[2].trim().equals(Constants.DefaultChatSubscriptionChannel)) {
								//	fp.setChatSubscriptionChannel(result[0].trim());
								/*} else if(result[2].trim().equals(Constants.DefaultNodeCommunicationPort)) {
									fp.setNodeCommunicationPort(result[0].trim()); */
								//} else 
								if(result[2].trim().equals(Constants.DefaultTomcatPort)) {
									fp.setTomcatPort(result[0].trim());
								} 
								//									else if(result[2].trim().equals(Constants.DefaultKeyStonePort)) {
								//									fp.setKeyStonePort(result[0].trim());
								//								} 
								//else if(result[2].trim().equals(Constants.DefaultHTTPPort)) {
								//	fp.setHTTPPort(result[0].trim());
								//}
							}
						}
					}
				}
			}
		}

		return fp;
	}

	public ForwaredPorts ParseSetPortMapAuto(String responseString) {
		ForwaredPorts fp = new ForwaredPorts();

		//4800:8888:Done
		//4801:4000:Failed

		String[] res = responseString.trim().split("\n");
		if(res!=null) {
			if(res.length>0) {
				for(int i=0;i<res.length;i++) {
					String[] result = res[i].trim().split(":");
					if(result.length == 3) {
						if(result[2].trim().equals("Done")) {
							/*if(result[1].trim().equals(Constants.DefaultOpenstackPort)) {
								fp.setOpenStackPort(result[0].trim());
							} else*/
							//if(result[1].trim().equals(Constants.DefaultChatInputChannel)) {
							//fp.setChatInputChannel(result[0].trim());
							//} else if(result[1].trim().equals(Constants.DefaultChatOutputChannel)) {
							//fp.setChatOutputChannel(result[0].trim());
							//} else if(result[1].trim().equals(Constants.DefaultChatSubscriptionChannel)) {
							//fp.setChatSubscriptionChannel(result[0].trim());
							/*} else if(result[1].trim().equals(Constants.DefaultNodeCommunicationPort)) {
								fp.setNodeCommunicationPort(result[0].trim());*/
							//} else
							if(result[1].trim().equals(Constants.DefaultTomcatPort)) {
								fp.setTomcatPort(result[0].trim());
							}
							//							else if(result[1].trim().equals(Constants.DefaultKeyStonePort)) {
							//								fp.setKeyStonePort(result[0].trim());
							//								//} else if(result[1].trim().equals(Constants.DefaultHTTPPort)) {
							//								//fp.setHTTPPort(result[0].trim());
							//							}
						}
					}
				}
			}
		}

		return fp;
	}

	/**
	 * This method is used to used to parse show network response
	 * @throws Exception
	 */
	public List<ShowNetworkVO> ParseShowNetworkResponse(String result) throws Exception {
		List<ShowNetworkVO> networkVOs = new ArrayList<ShowNetworkVO>();
		Map<String, ShowNetworkVO> ifaceList = new HashMap<>();

		/*
		 *	0				1			2			3			4			5					6			7		8		9		
		 * Interface Name|MAC Address|Link State|IP Address|Subnet Mask|Broadcast Address|Gateway Address|Protocol|Speed|Admin State
		 * 			10			11					12					13
		 * (bond)~Bonding Mode|Bonded Interfaces|Currently Active Slave|Primary Slave
		 * 			10
		 * (Nic)~Master
		 *
		 * 7
		 * px-aaee6a2cfa41||8.8.8.8|8.8.4.4|2001:4860:4860::8888
		 * 0		1				2		3			4			5				6			7		8		9		10				11				12	13	
		 * cluster|aa:ee:b2:e9:db:8a|UP|192.168.14.63|255.255.0.0|192.168.255.255|192.168.0.254|STATIC|1000|connected|Active-Backup|ens34:ens37:ens39|ens34|
		 * public|aa:ee:1a:01:92:fd|UP|192.168.14.61|255.255.255.0|192.168.14.255|192.168.0.254|STATIC|1000|connected|Link Aggregation|ens33:ens34:ens35
		 * 0		1				2			8		9			10
		 * ens33|aa:ee:fd:23:40:49|UP|3|4|5|6|7|1000|disconnected
		 * 0		1				2			8		9		10
		 * ens34|aa:ee:b2:e9:db:8a|UP|3|4|5|6|7|1000|connected|cluster
		 * 
		 * 
		 * 4
		 * px-aaee04ba70db|px-aaee04ba70db.com|8.8.8.8|4.2.2.2|8.8.8.8
		 * ens18|aa:ee:04:ba:70:db|UP|192.168.11.51|255.255.0.0|192.168.255.255|192.168.0.254|STATIC|-1|UP
		 * ens19|aa:ee:2a:0f:41:26|UP|192.168.11.55|255.255.0.0|192.168.255.255|192.168.0.254|STATIC|-1|UP
		 * ens20|aa:ee:e2:1c:af:86|DOWN|||||DHCP|0|DOWN
		 * 
		 * 
		 * 
		 * 7
		 * px-aaee5c4fc058|localdomain|8.8.8.8|8.8.4.4|1.1.1.1
		 * cluster|aa:ee:9b:8d:ff:1b|DOWN|||||DHCP|-1||Active-Backup|ens35||
		 * public|aa:ee:39:be:7f:d3|UP|192.168.11.51|255.255.0.0|192.168.255.255|192.168.0.254|STATIC|1000|connected|Active-Backup|ens33:ens34|ens33|
		 * ens33|aa:ee:39:be:7f:d3|UP|||||NONE|1000|connected|public
		 * ens34|aa:ee:39:be:7f:d3|UP|||||NONE|1000|connected|public
		 * ens35|aa:ee:9b:8d:ff:1b|UP|||||NONE|1000|connected|cluster
		 * ens36|aa:ee:a3:cd:86:02|UP|192.168.20.67|255.255.0.0|192.168.255.255|192.168.0.254|DHCP|1000|connected
		 * 
		 * 
		 * 6
		 * px-aaee5c4fc058|localdomain|8.8.8.8|8.8.4.4|1.1.1.1
		 * public|aa:ee:39:be:7f:d3|UP|192.168.11.51|255.255.0.0|192.168.255.255|192.168.0.254|STATIC|1000|connected|Active-Backup|ens33:ens34|ens33|
		 * ens33|aa:ee:39:be:7f:d3|UP|||||NONE|1000|connected|public
		 * ens34|aa:ee:39:be:7f:d3|UP|||||NONE|1000|connected|public
		 * ens35|aa:ee:d7:67:d3:b4|UP|||||NONE|1000|disconnected|cluster
		 * ens36|aa:ee:3a:04:83:fc|UP|||||NONE|1000|disconnected|cluster
		 * 
		 * 4
		 * SmnsY203EK|localdomain|8.8.8.8|4.2.2.2|
		 * ens33|aa:ee:5c:b2:a1:5d|UP|192.168.20.89|255.255.0.0|192.168.255.255|192.168.0.254|DHCP|1000|connected
		 * ens34|aa:ee:3e:20:e5:25|UP|||||DHCP|1000|disconnected
		 * wls32u2u1|70:62:b8:b2:89:d8|DOWN|||||DHCP|0|disconnected
		 * 
		 * */

		String dummmyIp = "xxx.xxx.xxx.xxx";

		String[] resultArr = result.split("\n");
		String[] split;
		String hostName = "";
		String domainName = "";
		String primaryDns = "";
		String secondaryDns = "";
		String tertiaryDns = "";
		PALogger.INFO("##### ParseShowNetworkResponse " + result);
		for(int i = 1; i < resultArr.length; i++) {

			if(i == 1) {
				// retrieve DNS details
				//px-aaeec68be518|fios-router.home|192.168.100.1|8.8.4.4|4.4.2.2
				String[] dns = resultArr[i].split("\\|");
				hostName = dns[0];
				domainName = dns[1];

				if(dns.length >= 5) {
					primaryDns = dns[2].trim();
					secondaryDns = dns[3].trim();
					if(dns[4].trim().contains(":")){
						tertiaryDns = "0.0.0.0";
					}else{
						tertiaryDns = dns[4].trim();
					}
				} else if(dns.length >= 4) {
					primaryDns = dns[2].trim();
					secondaryDns = dns[3].trim();
				} else if(dns.length >= 3) {
					primaryDns = dns[2].trim();
				}
			} else {

				split = resultArr[i].split("\\|");
				//length 13 is bond
				//length 9 is Iface
				//bond1|aa:ee:7d:05:15:e1|UP|192.168.100.59|255.255.255.0|192.168.100.255|192.168.100.1|DHCP|1000|Active-Backup|ens38:ens39|ens38|
				//ens33|aa:ee:c6:8b:e5:18|UP||||||1000

				ShowNetworkVO obj = new ShowNetworkVO();
				obj.setHostName(hostName);
				obj.setDomainName(domainName);
				obj.setPrimaryDns(primaryDns);
				obj.setSecondaryDns(secondaryDns);
				obj.setTertiaryDns(tertiaryDns);

				obj.setInterfaceName(split[0].trim());
				obj.setMacAddress(split[1].trim());

				if(split[2].trim().equalsIgnoreCase("up")) {

					//If IP address is empty do not set any other value, beside speed
					if(!StringFunctions.isNullOrWhitespace(split[3].trim())) {
						obj.setStatus("Enabled");
						obj.setIsEnabled(true);
						obj.setiPAddress(split[3].trim());
						String subNet = split[4].trim();
						obj.setSubNetMask(subNet);
						obj.setNetworkBlock(convertNetmaskToCIDR(InetAddress.getByName(subNet)));
						obj.setBroadcast(split[5].trim());
						obj.setGateway(split[6].trim());
						obj.setBootProtocol(split[7].trim());
						if("dhcp".equalsIgnoreCase( obj.getBootProtocol())) {
							obj.setIsDHCP(true);
						}
					} else if(split.length > 10 && !StringFunctions.isNullOrWhitespace(split[10].trim()) && split.length < 12) { //Bonded NICs
						obj.setStatus("Enabled");
						obj.setIsEnabled(true);
						obj.setiPAddress("");
						obj.setSubNetMask("");
						obj.setNetworkBlock(0);
						obj.setBroadcast("");
						obj.setGateway("");
						obj.setBootProtocol("DHCP");
						obj.setIsDHCP(true);

					} else {
						obj.setStatus("Disabled");
						obj.setIsEnabled(false);
						obj.setiPAddress(dummmyIp);
						obj.setSubNetMask(dummmyIp);
						obj.setNetworkBlock(0);
						obj.setBroadcast(dummmyIp);
						obj.setGateway(dummmyIp);

						if(!StringFunctions.isNullOrWhitespace(split[7].trim())) {
							obj.setBootProtocol(split[7].trim());
							if("dhcp".equalsIgnoreCase( obj.getBootProtocol())) {
								obj.setIsDHCP(true);
							}
						} else {
							obj.setBootProtocol("DHCP");
							obj.setIsDHCP(true);
						}
					}

					if(split.length > 8) {
						obj.setSpeed(Integer.parseInt(split[8].trim()));
					}

					if(split.length > 9) {
						obj.setAdminState(split[9].trim());
						obj.setIsConnected("connected".equalsIgnoreCase(obj.getAdminState()));
					}
				} else {
					obj.setStatus("Disabled");
					obj.setIsEnabled(false);
					obj.setIsConnected(false);
					obj.setiPAddress(dummmyIp);
					obj.setSubNetMask(dummmyIp);
					obj.setBroadcast(dummmyIp);
					obj.setGateway(dummmyIp);
					obj.setBootProtocol("xxxx");
				}

				if(split.length > 11) {
					//Bond
					//		10				11			12		13
					//~|Active-Backup|ens34:ens37:ens39|ens34|ens37
					//~|Link Aggregation|ens33:ens34:ens35 

					obj.setBondingMode(split[10].trim());   

					String[] ifaces = split[11].trim().split(":");
					obj.setInterfaces(new ArrayList<>());
					for (String iface : ifaces) {
						BondedNicVO bondedNicVO = new BondedNicVO();
						bondedNicVO.setInterfaceName(iface);
						obj.getInterfaces().add(bondedNicVO);	
					}

					if(split.length > 12) {
						obj.setSlaveInterface(split[12].trim());
					}
					if(split.length > 13) {
						obj.setPrimarySlave(split[13].trim());
					}
				} else {
					//nic
					if(split.length > 10) {
						obj.setMaster(split[10].trim());
					}

					obj.setDisplayName(obj.getInterfaceName());
					ifaceList.put(obj.getInterfaceName(), obj);
				}

				if(StringFunctions.isNullOrWhitespace(obj.getBondingMode())) {
					PALogger.INFO("ParseShowNetworkResponse Skipping: " + resultArr[i]);	
				} else {
					networkVOs.add(obj);
				}
			}
		}

		for (ShowNetworkVO networkVO : networkVOs) {
			if(!StringFunctions.isNullOrWhitespace(networkVO.getBondingMode())) {
				if(networkVO.getInterfaceName().equalsIgnoreCase("public")) {
					networkVO.setDisplayName(PUBLIC_NETWORK);
				} else {
					networkVO.setDisplayName(CLUSTER_NETWORK);
				}

				for (BondedNicVO bondedNicVO : networkVO.getInterfaces()) {
					ShowNetworkVO iface = ifaceList.remove(bondedNicVO.getInterfaceName());
					if(iface != null) {
						bondedNicVO.setIsEnabled(iface.getIsEnabled());
						bondedNicVO.setIsConnected(iface.getIsConnected());
						bondedNicVO.setSpeed(iface.getSpeed());
						bondedNicVO.setStatus(iface.getStatus());
						bondedNicVO.setAdminState(iface.getAdminState());
					}
				}
			}
		}

		if(ifaceList.size() > 0) {

			for(Entry<String, ShowNetworkVO> iface : ifaceList.entrySet()) {
				if(StringUtils.isEmpty(iface.getValue().getMaster())) {
					networkVOs.add(iface.getValue());
				}
			}
		}
		return networkVOs;
	}

	private int convertNetmaskToCIDR(InetAddress netmask){
		byte[] netmaskBytes = netmask.getAddress();
		int cidr = 0;
		boolean zero = false;
		for(byte b : netmaskBytes){
			int mask = 0x80;
			for(int i = 0; i < 8; i++){
				int result = b & mask;
				if(result == 0){
					zero = true;
				}else if(zero){
					throw new IllegalArgumentException("Invalid netmask.");
				} else {
					cidr++;
				}
				mask >>>= 1;
			}
		}
		return cidr;
	}

	/**
	 * This method is used to used to parse display storage response
	 */
	public List<StorageInfoVO> ParseDisplayStorageResponse(String string, boolean returnAll) 
	{
		ArrayList<StorageInfoVO> result = new ArrayList<>(); 
		StorageInfoVO obj=null;
		String[] response=string.split("\n");
		/*
		6


		Data:Missing::::::::
		Boot:Raid1:clean:idle::::111465472:41551872:64158720
		Root:Raid1:clean:idle::::51611582464:14735167488:34254663680
		Swap:Raid1:clean:idle::::1084669952:0:1084669952
		 */
		if(response!=null)
		{
			if(response.length>=2)
			{
				int diskCnt = response[1].split(":").length;

				for (int i =0 ;i < response.length; i++) {

					if(response[i].startsWith("Data") ||
							response[i].startsWith("Boot") ||
							response[i].startsWith("Root") ||
							response[i].startsWith("Swap") ||
							response[i].startsWith("Services"))
					{
						obj=new StorageInfoVO();

						String s = response[i];
						String[] TotalBytes=s.split(":", 10);

						obj.setDiskCount(Integer.toString(diskCnt));
						obj.setPartition(TotalBytes[0]);
						obj.setType(TotalBytes[1]);
						obj.setStatus(TotalBytes[2]);
						obj.setRebuildStatus(TotalBytes[3]);
						obj.setRebuildProg1(TotalBytes[4]);
						obj.setRebuildProg2(TotalBytes[5]);
						obj.setRebuildProg3(TotalBytes[6]);
						obj.setTotal(TotalBytes[7]);
						obj.setUsed(TotalBytes[8]);
						obj.setFree(TotalBytes[9]);

						result.add(obj);
					}
				}
			}
		}
		return result;
	}

	/**
	 * This method is used to used to get spare device
	 */
	public ArrayList<DiskInfo> GetSpareDevice(String SpareDisks) {
		ArrayList<DiskInfo> disks = new ArrayList<DiskInfo>();
		if(SpareDisks != null) {
			/*
			 *	/dev/sdd|20971520|MODEL|SERIALNO
			 */

			SpareDisks = trimAndClean(SpareDisks);

			String[] SpareDisksArr = SpareDisks.split("\n");
			for (String spareDisk : SpareDisksArr) {
				String[] spareDiskParts = spareDisk.split("\\|");
				if(spareDiskParts.length >= 2) {
					if(!spareDiskParts[1].trim().equals("")) {
						DiskInfo di = new DiskInfo();

						di.setLabel("spare");
						di.setIsSpare(true);
						di.setName(spareDiskParts[0]);
						di.setStatus("spare");

						di.setTotal(Long.parseLong(spareDiskParts[1]));
						di.setUsed(0);
						di.setFree(Long.parseLong(spareDiskParts[1]));

						if(spareDiskParts[2].equals("NONE"))
							di.setModel("-");
						else
							di.setModel(spareDiskParts[2]);

						if(spareDiskParts[3].equals("NONE"))
							di.setSerialNo("-");
						else
							di.setSerialNo(spareDiskParts[3]);

						disks.add(di);
					}
				}
			}
		}
		return disks;
	}

	/**
	 * This method is used to used to parse show version response
	 */
	public ShowVersionVO PareseShowVersionResponse(String ResponseString)
	{
		/*
		 	Software Versions:
			Pixeom      : 2.0.0.607-1
			CentOS      : 6.5
			Kernel      : 2.6.32-431.29.2.el6.x86_64
			Tomcat      : 6.0.24-78.el6_5
			Swift       : 1.13.1-1.el6
			Samba       : 3.6.9-169.el6_5
			Nginx       : 1.6.2-1.el6.ngx
------------------------------------------------
            ntkk8stest:
                13
                Pixeom_Edge_IoT_Core:1.0.0.82-1
                Fedora:26
                kernel:4.13.13-200.fc26.x86_64
                avahi:0.6.32-7.fc26
                crond:1.5.1-5.fc26
                docker:1.13.1-40.git877b6df.fc26
                docker-compose:1.16.1-1.fc26
                mariadb:10.1.26-2.fc26
                nginx:1.12.1-1.fc26
                chrony:3.1-4.fc26
                openssh:7.5p1-3.fc26
                rsyslog:8.30.0-3.fc26
                tomcat:8.5.15-1.git.33.7f345f5.fc26
		 *
		 */

		ShowVersionVO obj=new ShowVersionVO();

		String[] response = ResponseString.split("\n");
		if (response != null && response.length > 0)
		{

			for(int i=1;i<response.length;i++) {
				if(response[i].contains(":")) {
					String str[]=response[i].split(":");
					String s=str[0].trim();
					String data=str[1].trim();
					if(i == 1){
						obj.setPixeom(data);
					}
					if(s.equals("Pixeom"))
						obj.setPixeom(data);
					if(s.equals("CentOS"))
						obj.setCentos(data);
					if(s.equals("Kernel"))
						obj.setKernel(data);
					if(s.equals("Tomcat"))
						obj.setTomcat(data);
					if(s.equals("Swift"))
						obj.setSwift(data);
					if(s.equals("Samba"))
						obj.setSamba(data);
					if(s.equals("Nginx"))
						obj.setNginx(data);
				}
			}

		}
		return obj;
	}

	/**
	 * This method is used to used to show temp path
	 */
	public TempPathVO ShowTempPath(String result) {
		/*
		 * TempPath:TotalSpace:UsedSpace:FreeSpace
		 * /data/temp/:15509504:231280:15278224
		 */
		result = trimAndClean(result);
		TempPathVO  tempPathVO = null;
		if(result != null) {
			String[] resultArr = result.split(":");
			if(resultArr.length == 4) {
				tempPathVO = new TempPathVO();
				tempPathVO.setTempPath(resultArr[0]);
				tempPathVO.setTotalSpace(Long.parseLong(resultArr[1]));
				tempPathVO.setUsedSpace(Long.parseLong(resultArr[2]));
				tempPathVO.setFreeSpace(Long.parseLong(resultArr[3]));
			}
		}
		return tempPathVO;
	}

	/**
	 * This method is used to used to get machine information
	 */
	public MachineInfoVO GetMachineInfo(String result){
		// VMwareVirtualPlatform,00:0C:29:59:E8:7E,VMware-564d65b536e22d4a-6a02c07c3459e87e,564D65B5-36E2-2D4A-6A02-C07C3459E87E,VMwareInc.,1,Intel(R)Core(TM)2E8500@3.16GHz,eth1:1000Mb/s,
		result = trimAndClean(result);

		MachineInfoVO machineInfoVO = new MachineInfoVO();
		String[] resultArr = result.split(",");
		if(resultArr.length > 7){
			machineInfoVO.setComputerModel(resultArr[0]);
			machineInfoVO.setMACAddress(resultArr[1]);
			machineInfoVO.setMachineName(resultArr[2]);
			machineInfoVO.setMotherBoardId(resultArr[3]);
			machineInfoVO.setMotherBoardManufacture(resultArr[4]);
			machineInfoVO.setCPUCore(resultArr[5]);
			machineInfoVO.setCPUModel(resultArr[6]);
			machineInfoVO.setNicSpeed(resultArr[7]);
		}
		return machineInfoVO;
	}

	/**
	 * This method is used to used to parse mountable devices
	 */
	public ArrayList<DriveInfoVO> ParseMountableDevices(String result){
		ArrayList<DriveInfoVO> mountedDevices = new ArrayList<DriveInfoVO>();

		if(result != null) {
			// /dev/sdc|3910656|SanDisk|NONE|vfat|
			///dev/sdb1|1953513559|BUPSlimBK|NA7QQKFB|ntfs||ata|false
			result = trimAndClean(result);



			String[] resultArr =  result.split("\n");
			DriveInfoVO driveInfo = null;
			for (String resultPart : resultArr) {
				driveInfo = new DriveInfoVO();
				resultPart = resultPart.trim();
				String[] info1 = resultPart.split("\\|");

				if(info1.length >= 5) {
					driveInfo.setDrivePath(info1[0]);
					driveInfo.setDriveSize(Long.parseLong( info1[1]));
					driveInfo.setDriveModel(info1[2]);
					driveInfo.setDriveSerial(info1[3]);
					String driveType = info1[4].toLowerCase();

					if(!driveType.equals("none")) //Case when we do not recognize some partition on DAS
					{	
						driveInfo.setDriveFileSystem(driveType);	

						if(info1.length > 5)
							driveInfo.setDriveVolumeLabel(info1[5]);
						if(info1.length > 6)//on 6th index have drive type (USB etc) PCH
							driveInfo.setDriveType(info1[6]);
						if(info1.length > 7)////on 7th index have Boolean value for Is removable disk or not. PCH
							driveInfo.setIsRemovableDisk(Boolean.valueOf(info1[7]));
					}

					mountedDevices.add(driveInfo);
				}
			}
		}
		return mountedDevices;
	}

	/**
	 * This method is used to used to parse mounted storage
	 */
	public ArrayList<DiskInfo> ParseMountedStorage(String result){
		ArrayList<DiskInfo> mountableDevices = new ArrayList<DiskInfo>();
		if(result != null) {

			// /dev/sdb|/MWDAS/sdb|7816704|55616|7744704|SanDisk|NONE|vfat
			result = trimAndClean(result);

			String[] resultArr =  result.split("\n");
			DiskInfo dasDevice = null;
			for (String resultPart : resultArr) {
				resultPart = resultPart.trim();
				String[] resultPartArr = resultPart.split("\\|");

				if(resultPartArr.length >= 8) {
					dasDevice = new DiskInfo();
					dasDevice.setLabel("spare");
					dasDevice.setStatus("spare");
					dasDevice.setIsSpare(true);

					dasDevice.setName(resultPartArr[0].trim());
					dasDevice.setMountPoint(resultPartArr[1].trim());

					dasDevice.setTotal(Long.parseLong(resultPartArr[2].trim()));
					dasDevice.setUsed(Long.parseLong(resultPartArr[3].trim()));
					dasDevice.setFree(Long.parseLong(resultPartArr[4]));

					if(resultPartArr[5].equals("NONE"))
						dasDevice.setModel("-");
					else
						dasDevice.setModel(resultPartArr[5]);

					if(resultPartArr[6].equals("NONE"))
						dasDevice.setSerialNo("-");
					else
						dasDevice.setSerialNo(resultPartArr[6]);

					dasDevice.setFileSystem(resultPartArr[7].trim());
					dasDevice.setLabel("");

					mountableDevices.add(dasDevice);
				}
			}
		}

		return mountableDevices;
	}

	/**
	 * This method is used to used to return list of apps
	 */
	public String listOfApps() {
		String applications = "";//ProcessCommand.listApp();
		return applications;
	}

	/**
	 * This method is used to used to return list of running apps
	 */
	public String listOfRunningApps() {
		String ruunningApplications = "";
		return ruunningApplications;
	}

	/**
	 * This method is used to used to get memory percentage
	 */
	public int getMemoryPercentage(String memoryUsed) {		 
		int memoryPercentage=0;		
		if(!StringFunctions.isNullOrWhitespace(memoryUsed)){
			String[] memoryValues=memoryUsed.split("\\|");			
			long numerator =Long.parseLong(memoryValues[1]);
			long denominator =Long.parseLong(memoryValues[0]);
			memoryPercentage = (int)(numerator *100/denominator);
		}
		return memoryPercentage;
	}	

	/**
	 * This method is used to used to get up time
	 */
	public String getUpTime(String time) {		
		if(time.contains("up"))//taking whole string comes after "up" from GetUptime's script result.
			return StringUtils.substringAfter(time, "up").trim();
		else
			return "";			  
	}

	/**
	 * This method is used to used to get applications
	 */
	public List<String> getApplications(String applicationresult)
	{		 
		if(applicationresult.contains("No Apps Installed."))
			return new ArrayList<String>();
		else{
			return Arrays.asList(applicationresult.split("\n"));
			//return str.length;
		}
	}

	/**
	 * This method is used to used to get list of wireless
	 * @throws Exception
	 */
	public ArrayList<WifiDetails> getListWireless(String result) throws Exception {		 
		ArrayList<WifiDetails> wifiDetailsLst = new ArrayList<WifiDetails>();
		String [] wifiNetworks ={};
		if(result.contains("No wlan interface found.")){
			throw new Exception("No wlan interface found.");
		}
		if(result.contains("No WLAN utility found.")){		
			throw new Exception("No WLAN utility found.");
		}
		if(result.contains("Hotspot is enabled.")){
			throw new Exception("Hotspot is enabled.");
		}
		if(!StringFunctions.isNullOrWhitespace(result))
		{
			wifiNetworks = result.split("\n");
			for(String network : wifiNetworks)
			{
				WifiDetails wifidetail = new WifiDetails();
				String [] networkDetail = network.split(":");
				wifidetail.setWifiName(networkDetail[0]);
				wifidetail.setSecure(networkDetail[1].equalsIgnoreCase("on") ? true : false);
				wifidetail.setConnected(networkDetail[2].equalsIgnoreCase("NotConnected") ? false : true);
				wifidetail.setSignalStrength(networkDetail[3]);
				wifidetail.setMacAddress(networkDetail[4]);
				wifiDetailsLst.add(wifidetail);
			}
		}
		return wifiDetailsLst;		
	}

	/**
	 * This method is used to used to get name from result
	 * @throws Exception
	 */
	public String getNameFromResult(String result, String regex)
	{
		String [] nameArr = result.split(regex);
		String name = "";
		for(int i=1; i< nameArr.length -1; i++){
			name += nameArr[i] + " ";
		}
		return name.trim();
	}

	/**
	 * This method is used to used to get hotspot client details
	 * @throws Exception
	 */
	public ArrayList<HotspotClientDetails> getHotspotClientDetails(String result,boolean isNoClients) throws Exception {		 

		ArrayList<HotspotClientDetails> hotspotClientList = new ArrayList<HotspotClientDetails>();
		String [] tempHotspotClients ={};		
		if(result.contains("Wireless is enabled.")) {
			throw new Exception("wifi already enabled.");
		}
		if(result.contains("No wlan interface found.")){
			throw new Exception("No wlan interface found.");
		}
		if(result.contains("Hotspot is disabled.")){
			return null;
		}

		if(!isNoClients && !StringFunctions.isNullOrWhitespace(result))
		{
			tempHotspotClients = result.split("\n");
			for(String client : tempHotspotClients)
			{
				String [] Details = client.split(" ");  //eg - b8:b4:2e:7c:e6:d3 10.0.0.13 android-1d19a2748ad425c1   
				HotspotClientDetails clientdetails = new HotspotClientDetails();
				clientdetails.setMacAddress(Details[0]); //MAC Addr
				clientdetails.setIpAddress(Details[1]); //IP
				clientdetails.setDeviceName(Details[2].equalsIgnoreCase("none")? "" : Details[2]); //DeviceName
				clientdetails.setBlocked(false);
				hotspotClientList.add(clientdetails);
			}	
		}
		return hotspotClientList;
	}

	/**
	 * This method is used to used to parse deviceVO
	 * @throws Exception
	 */
	public List<DeviceVO> parseDeviceVO(String result){
		List<DeviceVO> listDevices = new ArrayList<DeviceVO>();
		result = result.trim();
		if(!StringFunctions.isNullOrWhitespace(result) && !"No Apps Installed.".contains(result) &&   !"No devices found.".contains(result)){
			//		result = "fedoraapachephp mywebapp|/dev/sdb|/App_Volume/fedoraapachephp/mywebapp/Storage/sdb|8149925888|8149921792|4096|0%|/Storage/dev/sd\n"
			//				+ "fedoraapachephp mywebapp|/dev/sdb|/App_Volume/fedoraapachephp/mywebapp/Storage/sdb|8149925888|8149921792|4096|0%|/Storage/dev/sd";
			// AppName ServiceName|DeviceName|Device-Volume-On-Host-System|TotalSizeInBytes|UsedSizeInBytes|USE%|Device-Volume-On-Container
			result = trimAndClean(result);
			String[] resultArr =  result.split("\n");
			for (String output : resultArr) {
				DeviceVO device = new DeviceVO();
				String[] outputArr = output.split("\\|");

				String[] outputArr1 = outputArr[0].split(" ");
				device.setAppName(outputArr1[0]);
				if(outputArr1.length == 2){
					device.setServiceName(outputArr1[1]);
				} else {
					device.setServiceName(outputArr1[0]);
				}

				device.setDeviceName(outputArr[1]);
				device.setDevice_Volume_On_Host_System(outputArr[2]);
				device.setTotalSizeInBytes(outputArr[3]);
				device.setUsedSizeInBytes(outputArr[4]);
				device.setUsedSizeInPercentage(outputArr[5]);
				device.setDevice_Volume_On_Container(outputArr[6]);

				listDevices.add(device);
			}
		}
		return listDevices;
	}

	/**
	 * This method is used to used to parse manage storage
	 * @throws Exception
	 */
	public ArrayList<ManageStorageVO> parseManageStorage(String result) {
		ArrayList<ManageStorageVO> manageStorageList = new ArrayList<ManageStorageVO>();

		/*
		 * App_Engine_VG-Docker_Thinpool|46.83 GB|3.13 GB|43.7 GB
		 * App_Engine_VG-App_Volume|16722690048|101814272|16620875776
		 */

		if(result != null) {
			result = result.trim();

			String[] resultArr = result.split("\n");

			for(int i = 0; i < resultArr.length; i++) {
				String[] resultStrArr = resultArr[i].split("\\|");
				if(resultStrArr.length >= 4) {
					if(i == 0) {
						ManageStorageVO manageStorageVO = new ManageStorageVO(resultStrArr[0], resultStrArr[1], resultStrArr[2], resultStrArr[3]);
						manageStorageList.add(manageStorageVO);
					} else if(i == 1) {
						long total = 0;//Long.parseLong(resultStrArr[1]);
						long used = 0;//Long.parseLong(resultStrArr[2]);
						long free = 0;//Long.parseLong(resultStrArr[3]);

						if(!StringFunctions.isNullOrWhitespace(resultStrArr[1]))
							total = Long.parseLong(resultStrArr[1]);
						if(!StringFunctions.isNullOrWhitespace(resultStrArr[2]))
							used = Long.parseLong(resultStrArr[2]);
						if(!StringFunctions.isNullOrWhitespace(resultStrArr[3]))
							free = Long.parseLong(resultStrArr[3]);

						ManageStorageVO manageStorageVO = new ManageStorageVO(resultStrArr[0], total, used, free);
						manageStorageList.add(manageStorageVO);
					}
				}
			}
		}
		return manageStorageList;
	}

	/**
	 * This method is used to used to parse app volume status
	 * @throws Exception
	 */
	public Hashtable<String, AppVolumeVO> parseAppVolumeStatus(String result) {
		/*
		 * 57fde0aee73f5|/dev/mapper/App_Engine_VG-App_Volume__57fde0aee73f5|/App_Volume/57fde0aee73f5|1070071808|1036136448|33935360|3%
		 * 5800c88c33dcd|/dev/mapper/App_Engine_VG-App_Volume__5800c88c33dcd|/App_Volume/5800c88c33dcd|1070071808|1036132352|33939456|3%
		 * 5801fb2133e1b|/dev/mapper/App_Engine_VG-App_Volume__5801fb2133e1b|/App_Volume/5801fb2133e1b|1070071808|1036132352|33939456|3%
		 */

		Hashtable<String, AppVolumeVO> appVolumes = new Hashtable<String, AppVolumeVO>();

		if(result != null) {
			result = result.trim();

			String[] resultArr = result.split("\n");

			for (String resultString : resultArr) {
				String[] resultStrArr = resultString.split("\\|");
				if(resultStrArr.length >= 7) {
					AppVolumeVO appVolumeVO = new AppVolumeVO(resultStrArr[0], resultStrArr[1], resultStrArr[2], Long.parseLong(resultStrArr[3]), Long.parseLong(resultStrArr[4]), Long.parseLong(resultStrArr[5]), resultStrArr[6]);
					appVolumes.put(resultStrArr[0], appVolumeVO);
				}
			}
		}

		return appVolumes;
	}

	/**
	 * Check command output and tellis IP in used or not 
	 * @param cmdOutput - arping command output
	 * @return true is in Use else false
	 */
	public boolean isIpInUse(String cmdOutput) {
		return (!StringUtils.isEmpty(cmdOutput) && !cmdOutput.contains("Done"));
	}
}