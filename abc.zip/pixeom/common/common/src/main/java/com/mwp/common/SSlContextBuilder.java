package com.mwp.common;

import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

import javax.net.ssl.SSLContext;

import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.ssl.TrustStrategy;

public class SSlContextBuilder {

	private static final SSlContextBuilder INSTNACE = new SSlContextBuilder();
	private SSLContext sslContext;
	private boolean isIntialized = false;

	private SSlContextBuilder() {
	}

	public static SSlContextBuilder getInstance() throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException {
		synchronized(INSTNACE){
			INSTNACE.initializeSslContext();
		}		
		return INSTNACE;
	}

	public SSLContext getSslContext() throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException {
		return sslContext;
	}

	private void initializeSslContext() throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException {
		if(!isIntialized){
			sslContext = new SSLContextBuilder().loadTrustMaterial(null, new TrustStrategy() {			
				public boolean isTrusted(X509Certificate[] arg0, String arg1) throws CertificateException {					
					return true;
				}
			}).build();
			isIntialized = true;
		}
	}
}
