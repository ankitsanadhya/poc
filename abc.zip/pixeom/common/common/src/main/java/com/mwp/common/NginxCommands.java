/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */ 
package com.mwp.common;

import java.util.ArrayList;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;

import com.mwp.logger.PALogger;

/**
 * Common commands for nginx server 
 * 
 *
 */
public class NginxCommands {

	/**
	 * Check and tells the type of configuration file is it virtualhost type or just path based redirect   
	 * @param nginxFilePath
	 * @return true if is it virtualhost config
	 * @throws TimeoutException 
	 * @throws ExecutionException 
	 * @throws InterruptedException 
	 * @throws Exception
	 */
	public boolean isNginxFileTypeServer(String nginxFilePath) throws InterruptedException, ExecutionException, TimeoutException{

		String grepCommandFormat = "grep '^[[:blank:]]*[^[:blank:]#;]' " + nginxFilePath + " | grep [[:blank:]]*%s";
		String lineSeperator = System.getProperty("line.separator");

		ArrayList<String> command = new ArrayList<String>();
		command.add("/bin/bash");
		command.add("-c");		

		/**
		 * Check for "server    {" in other than commented code
		 */		 
		//"grep '^[[:blank:]]*[^[:blank:]#;]' " + nginxFilePath + " | grep [[:blank:]]*server[[:blank:]]*{"		
		command.add(String.format(grepCommandFormat , "server[[:blank:]]*{"));
		String javaRegex =  "server\\s+\\{";		
		Pattern p = Pattern.compile(javaRegex);

		boolean isServerFound = false;
		String result = new CommandExecutor().Execute(command);
		if(StringUtils.isNotEmpty(result)){
			String[] lines = result.split(lineSeperator);
			for (String string : lines) {
				Matcher matcher = p.matcher(string);
				if(matcher.find()) {
					int startIndexOfMatch = matcher.start();
					if(!StringUtils.substring(string, 0, startIndexOfMatch).contains("#")){
						isServerFound = true;
						break;
					}						
				}
			}
		}
		if(!isServerFound) 
			return false;

		/**
		 * Check for "server_name " in other than commented code 
		 */

		boolean isListenFound = false;
		command.remove(2);
//		"grep '^[[:blank:]]*[^[:blank:]#;]' " + nginxFilePath + " | grep [[:blank:]]*listen "
		command.add(String.format(grepCommandFormat , "listen "));

		result = new CommandExecutor().Execute(command);
		if(StringUtils.isNotEmpty(result)){
			String[] lines = result.split(lineSeperator);
			for (String string : lines) {
				if(!StringUtils.substringBefore(string, "listen ").contains("#")){
					isListenFound = true;
					break;
				}			
			}			
		}
		if(!isListenFound) 
			return false;


		/**
		 * Check for "server_name " in other than commented code 
		 */
		boolean isserverNameFound = false;

		command.remove(2);
//		"grep '^[[:blank:]]*[^[:blank:]#;]' " + nginxFilePath + " | grep [[:blank:]]*server_name ")
		command.add(String.format(grepCommandFormat , "server_name "));

		result = new CommandExecutor().Execute(command);
		if(StringUtils.isNotEmpty(result)){
			String[] lines = result.split(lineSeperator);
			for (String string : lines) {
				if(!StringUtils.substringBefore(string, "server_name ").contains("#")){
					isserverNameFound = true;
					break;
				}			
			}			
		}
		if(!isserverNameFound) 
			return false;

		/**
		 * Repo name should not be in file
		 */
		boolean isrootFound = false;

		command.remove(2);
		command.add(String.format(grepCommandFormat , "root "));

		result = new CommandExecutor().Execute(command);
		if(StringUtils.isNotEmpty(result)){
			String[] lines = result.split(System.getProperty("line.separator"));
			for (String string : lines) {
				if(!StringUtils.substringBefore(string, "root ").contains("#")){
					isrootFound = true;
					break;
				}			
			}			
		}
		/**
		 * if root found then this is not server file
		 */
		if(isrootFound) 
			return false;

		return true;

	}

	/**
	 * Checks if the nginx configs are ok before reloading the server
	 * @return
	 * @throws Exception
	 */
	public boolean checkNginxService() throws Exception{
		String output = runCommand("/usr/sbin/nginx -t");
		if(output.contains("test is successful"))
			return true;
		return false;
	}

	/**
	 * Reloads nginx with new config files
	 * @throws Exception
	 */
	public void reloadNginxService() throws Exception {
		CredProvider credProvider = new CredProvider();
		credProvider.getCerts();
		Thread.sleep(1000);

		if(checkNginxService()) {
			runCommand("systemctl reload nginx");
		}
		// Reloading nginx take time
		// check for nginx status - that will be more deterministic than
		// relying on a fixed interval, For this we need RB's help. He
		// needs to provide some state command to verify. because in
		// nginx reload the nginx server's PID or State does not chaged.
		// Current sleep 10 second is from RB's script.
		(new Thread() {
			@Override
			public void run() {
				
					try {
						Thread.sleep(10000);
					} catch (InterruptedException e) {
						PALogger.ERROR(e);
						//Thread.currentThread().interrupt();
					}
				
				credProvider.removeCerts();
			}
		}).start();
	}

	private String runCommand(String commandToRun) throws InterruptedException, ExecutionException, TimeoutException {
		ArrayList<String> command = new ArrayList<String>();
		command.add("/bin/bash");
		command.add("-c");
		command.add(commandToRun);

		String result = new CommandExecutor().Execute(command);
		return result.trim();
	}
}