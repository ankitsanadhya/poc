/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */ 

package com.mwp.common.yamlparser;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.yaml.snakeyaml.DumperOptions;
import org.yaml.snakeyaml.DumperOptions.FlowStyle;
import org.yaml.snakeyaml.Yaml;
import org.yaml.snakeyaml.introspector.Property;
import org.yaml.snakeyaml.nodes.MappingNode;
import org.yaml.snakeyaml.nodes.Node;
import org.yaml.snakeyaml.nodes.NodeTuple;
import org.yaml.snakeyaml.nodes.ScalarNode;
import org.yaml.snakeyaml.nodes.SequenceNode;
import org.yaml.snakeyaml.nodes.Tag;
import org.yaml.snakeyaml.representer.Representer;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import com.mwp.common.Client;
import com.mwp.common.ISkipObfuscation;
import com.mwp.common.StringFunctions;
import com.mwp.logger.PALogger;

public class YamlParser implements ISkipObfuscation 
{
	private final static String ENTRYPOINT = "entrypoint";
	private final static String COMMAND = "command";
	private final static String SERVICES = "services";
	private final static String EXTERNAL = "external";
	private final static String COM_MWP_CONF_SERVICES = "com_mwp_conf_services";
	private final static String SOURCE = "source";
	private final static String TARGET = "target";
	
	private final static String REPLACEME = "###REPLACEME###";

	public static ComposeVO parse(String yamlFilePath) throws IOException
	{
		ComposeVO compose = null;
		//		Create Input stream of YAML file
		try (InputStream input = new FileInputStream(new File(yamlFilePath))){
			//Init Yaml Reader
			Yaml yaml = new Yaml();

			//Load YAML file in to Java object
			Object composeObj = yaml.load(input);

			//Parse Java Object in to json, to convert it into Our ComposeVO Object
			//use Gson builder to parse field with null values
			GsonBuilder gsonBuilder = new GsonBuilder();  
			gsonBuilder.serializeNulls();  
			Gson gson = gsonBuilder.create();

			String obj = gson.toJson(composeObj);
			compose = gson.fromJson(obj, ComposeVO.class);
		}
		return compose;
	}

	public static ComposeVO parseData(String composeFileData) {
		Yaml yaml = new Yaml();
		Object composeObj = yaml.load(composeFileData);

		Gson gson = new Gson();
		String obj = gson.toJson(composeObj);
		System.out.println("parseData#########################################################################################"+obj);
		ComposeVO compose = gson.fromJson(obj, ComposeVO.class);

		return compose;
	}

	public static String createData(ComposeVO compose) 
	{

		ComposerRepresenter representer = new ComposerRepresenter();
		representer.addClassTag(ComposeVO.class, Tag.MAP);
		representer.addClassTag(SectionVO.class, Tag.MAP);

		DumperOptions options = new DumperOptions();
		options.setDefaultScalarStyle(DumperOptions.ScalarStyle.PLAIN);
		options.setDefaultFlowStyle(DumperOptions.FlowStyle.BLOCK);
		options.setSplitLines(false);

		Yaml yaml  = new Yaml(representer, options);
		String output = yaml.dump(compose);
		output = output.replaceAll(REPLACEME, "");

		return output;
	}


	public static void create(ComposeVO compose,String outputPath) throws FileNotFoundException
	{

		String output = createData(compose);

		try (PrintStream out = new PrintStream(new FileOutputStream(outputPath))) {
			out.print(output);
		}
	}

	public static <T> T parseData(String yamlFileData, Class<T> classOf) {
		Yaml yaml = new Yaml();
		Object composeObj = yaml.load(yamlFileData);

		Gson gson = new Gson();
		String obj = gson.toJson(composeObj);
		System.out.println("parseData#########################################################################################"+obj);
		return gson.fromJson(obj, classOf);
	}

	public static String createData(Object object, Class classOf) {
		ComposerRepresenter representer = new ComposerRepresenter();
		representer.addClassTag(classOf, Tag.MAP);

		DumperOptions options = new DumperOptions();
		options.setDefaultScalarStyle(DumperOptions.ScalarStyle.PLAIN);
		options.setDefaultFlowStyle(DumperOptions.FlowStyle.BLOCK);
		options.setSplitLines(false);

		Yaml yaml  = new Yaml(representer, options);
		String output = yaml.dump(object);

		return output;
	}

	public static String createData(Object object) {
		ComposerRepresenter representer = new ComposerRepresenter();

		DumperOptions options = new DumperOptions();
		options.setDefaultScalarStyle(DumperOptions.ScalarStyle.PLAIN);
		options.setDefaultFlowStyle(DumperOptions.FlowStyle.BLOCK);
		options.setSplitLines(false);

		Yaml yaml  = new Yaml(representer, options);
		String output = yaml.dump(object);
		output = output.replaceAll(REPLACEME, "");
		return output;
	}

	private static class ComposerRepresenter extends Representer { 	



		@Override
		protected Node representMapping(Tag tag, Map<?, ?> mapping, Boolean flowStyle) {
			if(mapping.containsKey(COMMAND) || mapping.containsKey(ENTRYPOINT)) {
				List<NodeTuple> value = new ArrayList<NodeTuple>(mapping.size());
				MappingNode node = new MappingNode(tag, value, flowStyle);
				representedObjects.put(objectToRepresent, node);
				boolean bestStyle = true;
				for (Map.Entry<?, ?> entry : mapping.entrySet()) {
					Node nodeKey = representData(entry.getKey());
					Node nodeValue = representData(entry.getValue());

					System.out.println("----------");
					System.out.println(nodeKey.toString());
					System.out.println(nodeValue.toString());
					System.out.println("----------");

					if(nodeKey instanceof ScalarNode) {
						if(COMMAND.equals(((ScalarNode)nodeKey).getValue()) || ENTRYPOINT.equals(((ScalarNode)nodeKey).getValue())) {

							if(nodeValue instanceof SequenceNode) {
								//String newValue = REPLACEME + ((SequenceNode)nodeValue).getValue() + REPLACEME;

								List<Node> nodes = new ArrayList<>();
								for (Node nodeInList : ((SequenceNode) nodeValue).getValue()) {
									String newValue = REPLACEME + ((ScalarNode)nodeInList).getValue() + REPLACEME;
									ScalarNode nodeValue2 = new ScalarNode(nodeInList.getTag(), newValue, nodeInList.getStartMark(), nodeInList.getEndMark(), ((ScalarNode)nodeInList).getStyle());
									nodes.add(nodeValue2);
								}

								((SequenceNode)nodeValue).getValue().clear();
								((SequenceNode)nodeValue).getValue().addAll(nodes);

								SequenceNode nodeValue2 = new SequenceNode(nodeValue.getTag(), nodeValue.isResolved(), ((SequenceNode)nodeValue).getValue(), nodeValue.getStartMark(), nodeValue.getEndMark(), ((SequenceNode) nodeValue).getFlowStyle());
								nodeValue = nodeValue2;
							} else {
								String newValue = REPLACEME + ((ScalarNode)nodeValue).getValue() + REPLACEME;
								ScalarNode nodeValue2 = new ScalarNode(nodeValue.getTag(), newValue, nodeValue.getStartMark(), nodeValue.getEndMark(), ((ScalarNode)nodeValue).getStyle());
								nodeValue = nodeValue2;
							}
						}
					}

					if (!(nodeKey instanceof ScalarNode && ((ScalarNode) nodeKey).getStyle() == null)) {
						bestStyle = false;
					}
					if (!(nodeValue instanceof ScalarNode && ((ScalarNode) nodeValue).getStyle() == null)) {
						bestStyle = false;
					}
					value.add(new NodeTuple(nodeKey, nodeValue));
				}
				if (flowStyle == null) {
					if (defaultFlowStyle != FlowStyle.AUTO) {
						node.setFlowStyle(defaultFlowStyle.getStyleBoolean());
					} else {
						node.setFlowStyle(bestStyle);
					}
				}
				return node;
			} else {
				return super.representMapping(tag, mapping, flowStyle);
			}
		}


		@Override
		protected NodeTuple representJavaBeanProperty(Object javaBean, Property property, Object propertyValue, Tag customTag) {
			if (propertyValue == null || propertyValue.equals("null") || propertyValue.toString().equals("0")) {
				if(propertyValue != null && property.getName().equals("cpuset") &&  propertyValue.toString().equals("0")) {
					return super.representJavaBeanProperty(javaBean, property, propertyValue, customTag);
				} else {
					return null;
				}
			} else if(propertyValue instanceof HashMap && ((HashMap)propertyValue).size() == 0) {
				return null;
			} else if(propertyValue instanceof Hashtable && ((Hashtable)propertyValue).size() == 0) {
				return null;
			} else if(propertyValue instanceof List && ((List)propertyValue).size() == 0) {
				return null;
			} else if(propertyValue instanceof LinkedTreeMap && ((LinkedTreeMap)propertyValue).size() == 0) {
				return null;
			} else {
				if(property.getName().equals(COMMAND) || property.getName().equals(ENTRYPOINT)) {
					if(propertyValue.toString() == null || propertyValue.equals("null") || propertyValue.equals("")) {
						return null;
					} else {
						propertyValue = REPLACEME + propertyValue.toString() + REPLACEME;
						return super.representJavaBeanProperty(javaBean, property, propertyValue, customTag);
					}
					/*} else if(property.getName().equals("volumes")) {
					ArrayList<HashMap<String, Object>> propertyValues = (ArrayList<HashMap<String, Object>>) propertyValue; 

					ArrayList<String> propertyValuesNew = new ArrayList<>();
					for (HashMap<String, Object> hashMap : propertyValues) {
						for (Entry<String, Object> iterable_element : hashMap.entrySet()) {
							propertyValuesNew.add(iterable_element.getKey() + ":" + iterable_element.getValue());
						}
					}
					return super.representJavaBeanProperty(javaBean, property, propertyValuesNew, customTag);*/
				}  else {				
					return super.representJavaBeanProperty(javaBean, property, propertyValue, customTag);
				}
			}
		}
	}

	@Override
	public void guid() {
		// TODO Auto-generated method stub

	}



	public static void updatePorts(String ymlPath ,String sectionName, List<String> portsUpdate ) throws JsonProcessingException, IOException{

		if(portsUpdate.size() >0){

			InputStream input = new FileInputStream(new File(ymlPath));
			Yaml yaml = new Yaml();
			Object composeObj = yaml.load(input);

			HashMap<String, Object> composeMap = (HashMap<String, Object>) composeObj;

			HashMap<String, Object> serviceMap = (HashMap<String, Object>)composeMap.get(SERVICES);

			HashMap<String, Object> sectionMap = (HashMap<String, Object>)serviceMap.get(sectionName);

			ArrayList<String> portsList = (ArrayList<String>)sectionMap.get("ports");
			portsList.clear();

			for (String  ports : portsUpdate) {
				portsList.add(ports);
			}
			//portsList.add("8080:80");

			//ObjectMapper mapper = new ObjectMapper(new YAMLFactory());
			//ObjectNode composeObj = (ObjectNode) mapper.readTree(new File(yamlFilePath));

			//System.out.println(composeObj.toString());

			String yamldata = createData(composeObj);

			//yamldata = yamldata.replaceAll(REPLACEME, "");

			FileUtils.writeStringToFile(new File(ymlPath), yamldata);

			//System.out.println(yamldata);

			//==================

		}


	}



	/**
	 *
	 * @return
	 */
	public static String GetSecretFolderName(String secretKey, String serviceName){
		//		Change this method when need to create folder of following naame in secret path 
		//	secretKey_servicename/
		return secretKey + "/";
		//return "";
	}


	/**
	 * Updates yml secrets at global declaration , compose lable and in sectionvo
	 * @param ymlPath
	 * @param secretVoToUpdate
	 * @throws JsonProcessingException
	 * @throws IOException
	 */
	public static void updateSecrets(String ymlPath ,SecretVo secretVoToUpdate,String repoName) throws JsonProcessingException, IOException{

		InputStream input = new FileInputStream(new File(ymlPath));
		Yaml yaml = new Yaml();
		Object composeObj = yaml.load(input);

		HashMap<String, Object> composeMap = (HashMap<String, Object>) composeObj;

		HashMap<String, Object> secretMap = (HashMap<String, Object>)composeMap.get("secrets");

		//split only when repo name is attached
		String oldKey =secretVoToUpdate.getKey();
		if(oldKey.startsWith(repoName+"_"))
			oldKey =secretVoToUpdate.getKey().substring(secretVoToUpdate.getKey().indexOf("_")+1);


		//====================================== Update Global Secret ======================================
		for (String	 secretKey : secretMap.keySet()) 
		{
			String oldYmlKey =secretKey;
			if(oldYmlKey.startsWith(repoName+"_"))
				oldYmlKey=secretKey.substring(secretKey.indexOf("_")+1);


			if(oldYmlKey.equals(oldKey)){
				HashMap<String, Object> hashtable =  (HashMap<String, Object>) secretMap.get(secretKey);

				if(hashtable != null)
				{
					secretMap.remove(secretKey);

					HashMap<String, Object> hashSecretKey =new HashMap<String, Object>();

					HashMap<String, Object> hashMapToPut =new HashMap<String, Object>();
					hashMapToPut.put(EXTERNAL, true);

					hashSecretKey.put(secretVoToUpdate.getKey(), hashMapToPut);
					secretMap.put(secretVoToUpdate.getKey(), hashMapToPut);
					break;

				}

			}


		}


		//====================================== Update Global Secret End======================================

		HashMap<String, Object> servicesMap = (HashMap<String, Object>)composeMap.get(SERVICES);

		for (String	 serviceKey : servicesMap.keySet()) 
		{

			HashMap<String, Object> service = (HashMap<String, Object>)servicesMap.get(serviceKey);

			HashMap<String, Object> sectionMap = (HashMap<String, Object>)service.get("labels");

			if(sectionMap == null)
				continue;


			String lablesValue = (String)sectionMap.get(COM_MWP_CONF_SERVICES);

			if(lablesValue == null)
				continue;

			YmlAuthConfig authConfig = new Gson().fromJson(lablesValue,YmlAuthConfig.class);

			if(authConfig == null)
				continue;

			//====================================== Update SecretVo======================================
			if(authConfig.isSecret())
			{

				for (SecretVo secretVo : authConfig.getSecrets())
				{
					String oldYmlKey =secretVo.getKey();
					if(oldYmlKey.startsWith(repoName+"_"))
						oldYmlKey =secretVo.getKey().substring(secretVo.getKey().indexOf("_")+1);

					if(oldYmlKey.equals(oldKey))
					{
						authConfig.getSecrets().remove(secretVo);
						authConfig.getSecrets().add(secretVoToUpdate);
						break;
					}

				}
				//====================================== Update SecretVo End======================================


				//====================================== Update Service Secret======================================
				List<Object> secrets = (List<Object>)service.get("secrets");

				if(secrets == null)
					continue;

				for (int i = 0; i < secrets.size(); i++) {

					Object object = secrets.get(i);
					if(object instanceof String)
					{
						System.out.println(object);
						String oldYmlKey =((String) object);
						if(oldYmlKey.startsWith(repoName+"_"))
							oldYmlKey =((String) object).substring(((String) object).indexOf("_")+1);

						if (oldYmlKey.equals(oldKey)) {
							HashMap<String, Object> secrethash = new HashMap<>();
							secrethash.put(SOURCE,secretVoToUpdate.getKey() );
							secrethash.put(TARGET,oldKey );
							secrets.set(i, secrethash);
						}

					}
					else
					{
						System.out.println(object);
						HashMap<String, Object> secretobj = (HashMap<String, Object>) object;

						if(secretobj.containsKey(SOURCE) ){

							String oldYmlKey =((String) secretobj.get(SOURCE));
							if(oldYmlKey.startsWith(repoName+"_"))
								oldYmlKey =((String) secretobj.get(SOURCE)).substring(((String) secretobj.get(SOURCE)).indexOf("_")+1);

							if(oldYmlKey.equals(oldKey)){

								System.out.println(secretobj.get(SOURCE));
								secretobj.put(SOURCE, secretVoToUpdate.getKey());

								if(secretobj.containsKey(TARGET) && StringFunctions.isNullOrWhitespace(secretobj.get(TARGET))){
									secretobj.put(TARGET, oldKey);
								}
							}

						}


					}


				}
			}
			//====================================== Update Service Secret End======================================



			sectionMap.put(COM_MWP_CONF_SERVICES, new Gson().toJson(authConfig));
			String yamldata = createData(composeObj);
			FileUtils.writeStringToFile(new File(ymlPath), yamldata);
		}


	}

	/**
	 * Updates yml config at global declaration , compose lable and in sectionvo
	 * @param ymlPath
	 * @param configVoToUpdate
	 * @throws JsonProcessingException
	 * @throws IOException
	 */
	public static void updateConfigs(String ymlPath ,ConfigVo configVoToUpdate,String repoName) throws JsonProcessingException, IOException{



		InputStream input = new FileInputStream(new File(ymlPath));
		Yaml yaml = new Yaml();
		Object composeObj = yaml.load(input);

		HashMap<String, Object> composeMap = (HashMap<String, Object>) composeObj;

		HashMap<String, Object> configMap = (HashMap<String, Object>)composeMap.get("configs");

		//split only when repo name is attached
		String oldKey =configVoToUpdate.getKey();
		if(oldKey.startsWith(repoName+"_"))
			oldKey =configVoToUpdate.getKey().substring(configVoToUpdate.getKey().indexOf("_")+1);


		for (String	 configKey : configMap.keySet()) 
		{
			String oldYmlKey =configKey;
			if(oldYmlKey.startsWith(repoName+"_"))
				oldYmlKey=configKey.substring(configKey.indexOf("_")+1);

			if(oldYmlKey.equals(oldKey)){

				HashMap<String, Object> hashtable =  (HashMap<String, Object>) configMap.get(configKey);
				//===========================================================================================================================================
				if(hashtable != null)
				{

					hashtable.remove("file");
					hashtable.put(EXTERNAL, true);

					configMap.remove(configKey);

					HashMap<String, Object> hashConfigKey =new HashMap<String, Object>();

					HashMap<String, Object> hashMapToPut =new HashMap<String, Object>();
					hashMapToPut.put(EXTERNAL, true);

					hashConfigKey.put(configVoToUpdate.getKey(), hashMapToPut);
					configMap.put(configVoToUpdate.getKey(), hashMapToPut);
					break;
				}
			}
		}

		//====================================================

		HashMap<String, Object> servicesMap = (HashMap<String, Object>)composeMap.get(SERVICES);

		for (String	 serviceKey : servicesMap.keySet()) 
		{

			HashMap<String, Object> service = (HashMap<String, Object>)servicesMap.get(serviceKey);

			HashMap<String, Object> sectionMap = (HashMap<String, Object>)service.get("labels");

			if(sectionMap ==null)
				continue;

			String lablesValue = (String)sectionMap.get(COM_MWP_CONF_SERVICES);

			if(lablesValue ==null)
				continue;

			YmlAuthConfig authConfig = new Gson().fromJson(lablesValue,YmlAuthConfig.class);
			if(authConfig ==null)
				continue;

			if(authConfig.isConfig())
			{

				for (ConfigVo configVo : authConfig.getConfig())
				{

					String oldYmlKey =configVo.getKey();
					if(oldYmlKey.startsWith(repoName+"_"))
						oldYmlKey =configVo.getKey().substring(configVo.getKey().indexOf("_")+1);

					if(oldYmlKey.equals(oldKey))
					{
						//if(configVo.getType().equals("file")){

						//if(configVoToUpdate.getType().equals(EXTERNAL))
						//{
						authConfig.getConfig().remove(configVo);
						authConfig.getConfig().add(configVoToUpdate);
						//}

						//}

						break;

					}

				}


				//====================================== Update Service Secret======================================
				List<Object> secrets = (List<Object>)service.get("configs");

				if(secrets == null)
					continue;

				for (int i = 0; i < secrets.size(); i++) {

					Object object = secrets.get(i);
					if(object instanceof String)
					{
						System.out.println(object);

						String oldYmlKey =((String) object);
						if(oldYmlKey.startsWith(repoName+"_"))
							oldYmlKey =((String) object).substring(((String) object).indexOf("_")+1);

						if(oldYmlKey.equals(oldKey)){
							HashMap<String, Object> secrethash = new HashMap<>();
							secrethash.put(SOURCE, configVoToUpdate.getKey());
							secrethash.put(TARGET, oldKey);


							secrets.set(i, secrethash);
						}

					}
					else
					{
						System.out.println(object);
						HashMap<String, Object> secretobj = (HashMap<String, Object>) object;
						if(secretobj.containsKey(SOURCE))
						{
							String oldYmlKey =((String) secretobj.get(SOURCE));
							if(oldYmlKey.startsWith(repoName+"_"))
								oldYmlKey =((String) secretobj.get(SOURCE)).substring(((String) secretobj.get(SOURCE)).indexOf("_")+1);

							if(oldYmlKey.equals(oldKey)){
								System.out.println(secretobj.get(SOURCE));
								secretobj.put(SOURCE, configVoToUpdate.getKey());

								if(secretobj.containsKey(TARGET) && StringFunctions.isNullOrWhitespace(secretobj.get(TARGET))){
									secretobj.put(TARGET, oldKey);
								}

							}
						}



					}


				}
			}
			//====================================== Update Service Secret End======================================

			sectionMap.put(COM_MWP_CONF_SERVICES, new Gson().toJson(authConfig));
			//====================================================
			String yamldata = createData(composeObj);

			FileUtils.writeStringToFile(new File(ymlPath), yamldata);
		}

		//==================================================

	}
	/**
	 * This method get labels parsed object into hashmap.
	 * @param labels Object of labels which need to parsed.
	 * @return {@link HashMap}
	 */
	@SuppressWarnings("unchecked")
	protected static HashMap<String, String> getLabelsParsed(Object labels) {
		//Labels parsing
		HashMap<String, String> hashMap = new HashMap<>();
		if(labels != null){
			if(labels instanceof ArrayList<?>){
				List<String> labelsList = (List<String>) labels;

				for (String lable : labelsList) {
					String[] strings = lable.split("=");
					hashMap.put(strings[0], strings[1]);
				}
			} else {
				LinkedTreeMap<String, String> treeMap = Client.getGson().fromJson(Client.getGson().toJson(labels), LinkedTreeMap.class);
				hashMap.putAll(treeMap);
			}
		}
		return hashMap;
	} 

	/**
	 * This method parse Long and short syntax object into ArrayList<String>.
	 * @param ports which comes in Long and short syntax both.
	 * @return {@link ArrayList} of string.
	 */
	@SuppressWarnings("unchecked")
	protected static ArrayList<String> getPortsParsed(Object ports){
		ArrayList<String> portsAsList = new ArrayList<>();
		if(ports != null){
			List<?> portsList = (List<?>) ports;
			for (Object port : portsList) {
				if(port instanceof LinkedTreeMap<?, ?>){
					LinkedTreeMap<String, Object> p = Client.getGson().fromJson(Client.getGson().toJson(port), LinkedTreeMap.class);
					String target = p.get(TARGET).toString();
					String published = p.get("published").toString();

					portsAsList.add(String.valueOf(new Double(published).intValue()) + ":" + String.valueOf(new Double(target).intValue()));
				} else {
					portsAsList.add(port.toString());
				}
			}
		}

		return portsAsList;
	}

	/**
	 * This method parse Long and short syntax object into ArrayList<String>.
	 * @param volumes which comes in Long and short syntax both.
	 * @return {@link ArrayList} of string.
	 */
	@SuppressWarnings("unchecked")
	protected static ArrayList<String> getVolumesParsed(Object volumes){
		ArrayList<String> volumesAsList = new ArrayList<>();
		if(volumes != null) {
			List<?> volumesList = (List<?>) volumes;
			for (Object vol : volumesList) {
				if(vol instanceof String){
					String VolString = vol.toString(); 
					PALogger.INFO(VolString);
					volumesAsList.add(VolString);
				} else {
					LinkedTreeMap<String, Object> s = Client.getGson().fromJson(Client.getGson().toJson(vol), LinkedTreeMap.class);
					if(s.get(SOURCE) != null){
						String source = s.get(SOURCE).toString();
						PALogger.INFO(source);
						volumesAsList.add(source);
					}
				}
			}
		}

		return volumesAsList;
	}

}

