/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */ 

package com.mwp.common.constant;

public class NotificationConstant 
{

	// Notification Constant which include default Topics for KAFKA server and RMQ Server.

	private NotificationConstant(){
		// Utility constant class 
	}
	/**
	 * SYSTEM_UPDATES= "systemUpdate";
	 * Used for OS update to boxes. 
	 */
	public final static String SYSTEM_UPDATES= "systemUpdate"; 

	/**
	 * DEVICE_ID="deviceId";
	 * Device Id Constant describes BoxID.
	 */
	public final static String DEVICE_ID="deviceId";

	/**
	 * SUBSCRIBE_NOTIFICATION="subscribeNotification";
	 * Describes that APP is Used Notification service for recieving notification.
	 */
	public final static String SUBSCRIBE_NOTIFICATION="subscribeNotification";

	/**
	 * SEND_NOTIFICATION="sendNotification";
	 * Describes that APP is Used Notification service for sending notification.
	 */
	public final static String SEND_NOTIFICATION="sendNotification";

	/**
	 * APP_NOIFICATIONS="appNotifications" ;
	 * Describes that App get Notification from Portal.
	 */
	public final static String APP_NOIFICATIONS="appNotifications" ;

	/**
	 * APP_ID="appId";
	 * Describes the Application ID.
	 */
	public final static String APP_ID="appId";

	/**
	 * IS_START_PRODUCER="isStartProducer";
	 * Describes the end(wheather it is producer or consumer)
	 */
	public final static String IS_START_PRODUCER="isStartProducer";

	/**
	 * IS_START_CONSUMER="isStartConsumer";
	 * Describes the end(wheather it is producer or consumer)
	 */
	public final static String IS_START_CONSUMER="isStartConsumer";

	/**
	 * INSTALLAPPLICATION="InstallApplication";
	 * Describes Opeartion Name (install app or application update). 
	 */
	public final static String INSTALLAPPLICATION="InstallApplication";

	/**
	 * UPDATEAPPLICATION="UpdateApplication";
	 * Describes Opeartion Name (install app or application update). 
	 */
	public final static String UPDATEAPPLICATION="UpdateApplication";

	/**
	 * Manage_NOIFICATIONS="manageNotifications" ;
	 * Used to subscribe notification in notification manager.
	 */
	public final static String MANAGE_NOIFICATIONS="manageNotifications" ;

	/**
	 * Manage_NOIFICATIONS="manageNotifications" ;
	 * Used to subscribe notification in notification manager.
	 */
	public final static String DAS_SERVICE_NOTIFICATION = "dasServiceNotification" ;


}
