/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */ 

package com.mwp.common.constant;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.google.gson.Gson;
import com.mwp.common.ISkipObfuscation;
import com.mwp.common.vo.MinioVO;
import com.mwp.logger.PALogger;

public class Constant implements ISkipObfuscation {

	
	public static final ArrayList<String> listMemSize = new ArrayList<String>();
	public static final Set<String> CpuInfoSet = new HashSet<String>();
	public static final Set<String> MemInfoSet = new HashSet<String>();
	
	static{		
		listMemSize.add("4K");
		listMemSize.add("128K");
		listMemSize.add("1M");
		
		CpuInfoSet.add("model name");
		CpuInfoSet.add("cpu cores");
		
		MemInfoSet.add("MemTotal");
		MemInfoSet.add("MemAvailable");
	}
	

	public static String PROXY_PATH ="/etc/profile.d/proxy-conf.sh";
	public static String DOCKER_PROXY_FOLDER_PATH ="/etc/systemd/system/docker.service.d/";

	public static final String CONTANIER_PROXY_PATH = "/host-system/etc/profile.d/";
	public static final String CONTANIER_DOCKER_PROXY_FOLDER_PATH = "/host-system" + DOCKER_PROXY_FOLDER_PATH;

	/**
	 * localFileSeparator = "/";
	 */
	public static String localFileSeparator = "/";

	/**
	 * Grant type for JWT tokens
	 */
	public static final String JWT_BEARER = "jwt-bearer";

	/**
	 * System Configurations file path : /etc/app_engine/Configurations/
	 */
	public static final String SYSTEM_CONFIGURATIONS_PATH = "/etc/app_engine/Configuration/";

	/**
	 * Private key of the platform - needed for server to server (EDGE or portal) JWT token creation and verification   
	 */
	public static final String SYSTEM_PRIVATE_KEY = "/etc/pki/tls/private/MW_Cloud.key";
	/**
	 * Private key of the platform - needed for server to server (EDGE or portal) JWT token creation and verification   
	 */
	public static final String SYSTEM_CERT = "/etc/pki/tls/certs/MW_Cloud.crt";

	/**
	 * Paths and file name of the DER files required for JWT on server (EDGE or portal)
	 */
	public static final String SYSTEM_DER_BASE_PATH = SYSTEM_CONFIGURATIONS_PATH + ".der/";
	public static final String PUBLIC_DER_NAME = "public.der";
	public static final String PRIVATE_DER_NAME = "private.der";
	public static final String SYSTEM_PUBLIC_DER = SYSTEM_DER_BASE_PATH + PUBLIC_DER_NAME;
	public static final String SYSTEM_PRIVATE_DER = SYSTEM_DER_BASE_PATH + PRIVATE_DER_NAME;
	/**
	 * Public key of device to generate and verify JWT Token of the device on device it self
	 */
	public static final String EDGE_JWT_KEYS_PATH = SYSTEM_DER_BASE_PATH + "/jwtDeviceKeys/";
	/**
	 * Public key of device to verify JWT Token of the device on portal
	 */
	public static final String  EDGE_JWT_PUBLIC_KEY_PATH = Constant.localFileSeparator+"data"+Constant.localFileSeparator+"jwtkeys"+Constant.localFileSeparator+ "%s" + Constant.localFileSeparator + "jwtPublicKey.base64";

	public static String RANCHEROS_FILE_PATH = "/host-system/var/lib/rancher/conf/cloud-config.d/";
	public static String RANCHEROS_PROXY_FILE_PATH = RANCHEROS_FILE_PATH + "user.yml";
	public static String RANCHEROS_NETWORK_FILE_PATH = RANCHEROS_FILE_PATH + "network.yml";

	/**
	 * Added new file path in case of rancher os we need environment file path - PSH.
	 * 	Path: "/var/lib/rancher/conf/cloud-config.yml"
	 */
	public static String RANCHEROS_ENVIRONMENT_FILE_PATH = "/var/lib/rancher/conf/cloud-config.yml";//"/opt/rancherProxy/cloud-config.yml";

	/**
	 * This file is made by rancher os only, we just need to remove file on delete proxy - PSH.
	 * Path: "/etc/profile.d/proxy.sh"
	 */
	public static String RANCHEROS_SYSTEM_PROXY_FILE_PATH = "/etc/profile.d/proxy.sh";

	public static String RANCHEROS_WEBINF_FILE_PATH = "";
	public static String RANCHEROS_PROXY_TEMPLET_FILE_PATH() {
		return RANCHEROS_WEBINF_FILE_PATH + "rancherProxy/user.yml";
	}
	public static String RANCHEROS_NETWORK_TEMPLET_FILE_PATH() {
		return RANCHEROS_WEBINF_FILE_PATH + "rancherProxy/network.yml";	
	}

	public final static String  SUCCESS = "Success";
	/**
	 * Failure
	 */
	public final static String  FAILURE = "Failure";

	/**
	 *  QUERYSTRING = "QueryString";
	 */
	public final static String QUERYSTRING = "QueryString";

	/**
	 * Auth token time to expires in seconds.
	 */
	public final static long TOKENEXPIRYSECONDS = 1209600;

	/**
	 * Auth token time to expires in milliseconds.
	 */
	public final static long TOKENEXPIRYMILLIS = TOKENEXPIRYSECONDS * 1000;

	/**
	 * This DATA is key of return hash table.
	 */
	public final static String DATA = "data";

	/**
	 *  SIGN_IN_TYPE = "signInType";
	 */
	public final static String SIGN_IN_TYPE = "signInType";

	/**
	 *  UNAUTHORIZED = "Unauthorized";
	 */
	public final static String UNAUTHORIZED = "Unauthorized.";

	/**
	 *  UNAUTHORIZED = "Unauthorized";
	 */
	public final static String INCORRECTLOGIN = "Incorrect credential.";

	/**
	 *  NOTPERMITTED= "Access denied.";
	 */
	public final static String NOTPERMITTED= "Access denied.";

	/**
	 *  NOTFOUND = "Details not found";
	 */
	public final static String NOTFOUND = "Notfound.";

	/**
	 * portal application id	
	 */
	public final static String PORTAL_APPLICATION_ID = "41ff73c9719a42bdb0348355114ceb82";

	/**
	 * PORTAL_DATA_FOLDER_NAME = "PortalCache"
	 */
	public final static String PORTAL_DATA_FOLDER_NAME = "PortalCache";

	/**
	 * PORTAL_UI_FOLDER_NAME = "pp"
	 */
	public final static String PORTAL_UI_FOLDER_NAME = "pp";

	/**
	 * BOX_DATA_FOLDER_NAME = "BoxCache"
	 */
	public final static String BOX_DATA_FOLDER_NAME = "BoxCache";

	/**
	 * BOX_UI_FOLDER_NAME = "pb"
	 */
	public final static String BOX_UI_FOLDER_NAME = "pb";

	/**
	 * USER_ID = "userId"
	 */
	public final static String USER_ID = "userId";

	/**
	 * APP_USER_ID = "appUserId"
	 */
	public final static String APP_USER_ID = "appUserId";

	/**
	 * EMAIL = "email"
	 */
	public final static String EMAIL = "email";

	/**
	 * CODE = "code"
	 */
	public final static String CODE = "code";

	/**
	 * LISTING_SERVER_FILE = "/opt/app_engine/ListingServer"
	 */
	public final static String LISTING_SERVER_FILE = "/opt/app_engine/ListingServer";


	/**
	 * LISTING_SERVER_FILE = "/opt/app_engine/softwareupdate"
	 */
	public final static String SOFTWAREUPDATES_FILE = "/opt/app_engine/softwareupdate";


	/**
	 * UPDATE_STATE_FILE_PATH = "/opt/app_engine/stateinfo.txt"
	 */
	public final static String UPDATE_STATE_FILE_PATH = "/opt/app_engine/stateinfo.txt";

	/**
	 * LICENSE_EXPIERY_FILE = "/opt/app_engine/licenseExpired"
	 */
	//public final static String LICENSE_EXPIERY_FILE = "/opt/app_engine/licenseExpired";

	/**
	 * IS_PORTAL_FILE = "/root/authportal"
	 */
	public final static String IS_PORTAL_FILE = "/root/authportal";

	/**
	 * DB_SERVER_FILE_PATH = "/root/dbserver"
	 */
	public final static String DB_SERVER_FILE = "/root/dbserver";

	/**
	 * UPDATEINPROGRESS = "UPDATE IN PROGRESS"
	 */
	public final static String UPDATEINPROGRESS = "UPDATE IN PROGRESS";

	/**
	 * ADD/DELETE node in progress = "ADD/DELETE NODE IN PROGRESS"
	 */
	public final static String ADD_DELTE_NODE_INPROGRESS = "ADD/DELETE NODE IN PROGRESS";

	/**
	 * LICENSE_EXPIRED = "LICENSE EXPIRED"
	 */
	public final static String LICENSE_EXPIRED = "LICENSE EXPIRED";

	/**
	 * FACTORY_RESET_IN_PROGRESS = "LICENSE EXPIRED"
	 */
	public final static String FACTORY_RESET_IN_PROGRESS = "Factory reset is in progress.";
	
	/**
	 * CONNECT_URI = "connect_uri"
	 */
	public final static String CONNECT_URI = "connect_uri";


	/**
	 * CONNECT_URI = "connect_uri"
	 */
	public final static String PORT = "8008";
	
	/**
	 * Default name of root label = "All Appliances" 
	 */
	public final static String ROOT_LABEL_NAME = "All Appliances";

	public final static String EDGECORE_SYSTEM_UPDATE_APPNAME = "Appliance";

	public final static String EDGE_SERVICES = "edge-services";

	public final static String EDGE_LOGGER = "edge-logger";

	public final static String EDGE_OPEN_HAB = "edge-openhab";

	public final static String EDGE_EVENT = "edge-event";

	public final static String EDGE_APPS = "pixeom-apps";

	/**
	 * Id of root label = "0" 
	 */
	public final static String ROOT_PARENT_LABEL_ID = "-1";
	public final static String ROOT_LABEL_ID = "0";

	public final static String TIMERS = "/opt/timers";
	public final static String ETCD_FOLDER_PATH = "/etc/etcd/pki/";
	public final static int DEFAULT_BATCHSIZE = 50; // launch 50 jobs if there are jobs > 50 at the same time
	public final static long DEFAULT_INTERVAL = 3000;// 3 seconds
	public final static long DEFALUT_SIZE_FACTOR = 104857600; // 100 MB
	public final static int DEFALUT_SERVER_COUNT = 1; // 1 registry server

	/**
	 * Application assignedPort default external port range.
	 */
	public final static int SERVICE_PORT_START_RANGE = 1;//55000;
	public final static int SERVICE_PORT_END_RANGE = 65535;//60000;



	public final static String DOCUMENT_ALREADY_EXISTS = "Document already exists.";

	public final static String PROJECT_ALREADY_EXISTS = "Project already exists.";

	//#HDV_01_1
	public final static String VERSIONNOTAVAILABLE= "App version is no longer available.";
	public final static String APPISNOTAVAILABLE= "App is no longer available.";
	//#HDV_01_2
	public final static String SUPPORTTOKENDETAILS= "SupportTokenDetails";


	public final static String MAX_POOL_CONNECTIONS = "maxPoolConnections";
	public final static String MAXPER_ROUTE_CONNECTIONS = "maxPerRouteConnections";
	public final static int DEFAULT_MAX_POOL_CONNECTIONS = 500;
	public final static int DEFAULT_MAX_PER_ROUTE_CONNECTIONS = 100;
	public final static String BEARER = "bearer ";
	public static final String NOT_ALLOWED = "Not allowed.";
	public static final String REQUEST_REQUIRES_HTTP_AUTHENTICATION = "Request requires HTTP authentication.";


	@Override
	public void guid() {
		// TODO Auto-generated method stub

	}

	public static String configFilePath = "/opt/app_engine/pxconfig.json";

	private static JSONObject pxConfig = null;

	public static JSONObject getPxConfig(){
		if(pxConfig == null){						
			loadConfig();			
		}
		return pxConfig;
	}

	private synchronized static void  loadConfig(){
		if(pxConfig == null) //DB - Corrected as this will load so many configurations and open files observed on portal having thousands of live boxes
		{
			File configFile = new File(configFilePath);
			if(configFile.exists()){
				JSONParser parser = new JSONParser();
				try {
					pxConfig = (JSONObject) parser.parse(new FileReader(configFile));
				} catch (IOException | ParseException e) {
					PALogger.ERROR(e);
				}
				//finally {
					
				//}
			}
		}
	}

	public static String getPartner(){
		getPxConfig();

		String partner = "px";
		if(pxConfig != null && pxConfig.containsKey("partner"))
			partner = pxConfig.get("partner").toString();
		return partner;
	}

	public static MinioVO getMinio(){
		getPxConfig();

		MinioVO minio = null;
		if(pxConfig != null && pxConfig.containsKey("minio"))
			minio = new Gson().fromJson(pxConfig.get("minio").toString(), MinioVO.class);
		return minio;
	}

	public static boolean isWholePortalAccess()
	{
		getPxConfig();
		boolean restrictPortalAccess= false;
		if(pxConfig != null &&  pxConfig.containsKey("restrictPortalAccess"))
			restrictPortalAccess= Boolean.parseBoolean(pxConfig.get("restrictPortalAccess").toString());
		return !restrictPortalAccess;
	}
	public static String getProduct(){
		getPxConfig();

		String product = "";
		if(pxConfig != null && pxConfig.containsKey("product"))
			product = pxConfig.get("product").toString();

		return product;
	}

	/**
	 * @return partner Copyrights text from pxconfig.json file 
	 * 
	 */
	public static String getPartnerCopyrights(){
		getPxConfig();

		String partnercopyrights = "";
		if(pxConfig != null && pxConfig.containsKey("partnercopyrights"))
			partnercopyrights = pxConfig.get("partnercopyrights").toString();

		return partnercopyrights;
	}

	public static boolean toLogActivity()
	{
		getPxConfig();
		boolean logActivity= false;
		if(pxConfig != null &&  pxConfig.containsKey("logActivity"))
			logActivity= Boolean.parseBoolean(pxConfig.get("logActivity").toString());
		return logActivity;
	}


	public static List<String> getDefaultAppCategories(){
		getPxConfig();

		List<String>  lstCategories = new ArrayList<>();
		if(pxConfig != null && pxConfig.containsKey("categories"))
			lstCategories = (List<String>)pxConfig.get("categories");
		return lstCategories;
	}

	public static String getDNSDomainID(){
		return getPxConfigValue("dns-domainid");
	}
	public static String getDNSRegion(){
		return getPxConfigValue("dns-region");
	}
	public static String getDNSAccessKey(){
		return getPxConfigValue("dns-accesskey");
	}
	public static String getDNSSecretKey(){
		return getPxConfigValue("dns-secretkey");
	}

	private static Boolean isRunnigOnContainer = null;

	/**
	 * Check is EdgeCore is running on container.
	 * 
	 * @return
	 * @throws Exception
	 */
	public static boolean isRunnigOnContainer() {
		if (isRunnigOnContainer == null) {
			isRunnigOnContainer = new File("/etc/os-release-container").exists();
		}
		PALogger.TRACE(isRunnigOnContainer);
		return isRunnigOnContainer;
	}

	/**
	 * This method read max pool connection from config file.
	 * @return 
	 */
	public static int getMaxPoolConnections(){
		String maxPoolConnections = getPxConfigValue(MAX_POOL_CONNECTIONS);
		if(maxPoolConnections.equals("")) {
			return DEFAULT_MAX_POOL_CONNECTIONS;
		} else {
			return Integer.valueOf(maxPoolConnections);
		}
	}

	/**
	 * This method read heap dump interval
	 * @return 
	 */
	public static long getHeapDumpInterval(){
		String heapDumpInterval = getPxConfigValue("heapDumpInterval");
		if(heapDumpInterval.equals("")) {
			return 3600000l; // 60 * 60000
		} else {
			return Long.valueOf(heapDumpInterval);
		}
	}
	
	/**
	 * This method read heap dump files to keep
	 * @return 
	 */
	public static int getHeapDumpsToKeep(){
		String heapDumpsToKeep = getPxConfigValue("heapDumpsToKeep");
		if(heapDumpsToKeep.equals("")) {
			return 2;
		} else {
			return Integer.valueOf(heapDumpsToKeep);
		}
	}

	
	/**
	 * This method read max per route connections from config file.
	 * @return 
	 */
	public static int getMaxPerRouteConnections(){
		String maxPerRouteConnections = getPxConfigValue(MAXPER_ROUTE_CONNECTIONS);
		if(maxPerRouteConnections.equals("")) {
			return DEFAULT_MAX_PER_ROUTE_CONNECTIONS;
		} else {
			return Integer.valueOf(maxPerRouteConnections);
		}
	}
	

	private static String getPxConfigValue(String key){
		getPxConfig();
		String value = "";
		if(pxConfig != null && pxConfig.containsKey(key))
			value = pxConfig.get(key).toString();
		return value;
	}

	/**
	 * List of ports reserved by edge core appliance
	 */
	public static final ArrayList<Integer> RESERVED_PORTS = new ArrayList<Integer>() {
		private static final long serialVersionUID = 1L;

		{ 
			add(8400); 
			add(5050); 
			add(443); 
			add(2375); 
			add(2020); 
			add(8880); 
			add(8009); 
			add(8005); 
			add(3306); 
			add(4000); 
			add(123); 
			add(323); 
			add(7946); 
			add(4789); 
			add(2377); 
			add(3375); 
			add(50); 
			add(5671); 
			add(5672); 
			add(15671); 
			add(15672); 
			add(4369); 
			add(25672); 
			add(5140); 
			add(24224); 
			add(68);
		}
	};

}

/**
 * History of check-in or issue resolved 
 * 01 - 1-08-2018 
 * HDV_01_1
 * Add constant for required error messages.#Bug Id 1830.  
 * HDV_01_2
 * Add constant for support token details.  
 */