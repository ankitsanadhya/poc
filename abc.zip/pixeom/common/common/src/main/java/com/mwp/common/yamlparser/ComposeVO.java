/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */ 

package com.mwp.common.yamlparser;

import java.util.HashMap;
import java.util.Hashtable;

import com.mwp.common.ISkipObfuscation;

/*
 * The Compose file is a YAML file defining services, networks and volumes
 * */
public class ComposeVO implements ISkipObfuscation {
	/*
	 * Compose files using the version 2 syntax must indicate the version number at the root of the document. All services must be declared under the services key.
	 * */
	private String version = "2";
	//Collection of services
	private Hashtable<String, SectionVO> services;

	private HashMap<String, Object> networks;

	private Hashtable<String, Object> secrets;

	private HashMap<String, Object> volumes;
	
	private Hashtable<String, Object> configs;

	public Hashtable<String, Object> getSecrets() {
		if(secrets == null){
			return new Hashtable<>();
		}
		return secrets;
	}
	public void setSecrets(Hashtable<String, Object> secrets) {
		this.secrets = secrets;
	}
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	public Hashtable<String, SectionVO> getServices() {
		return services;
	}
	public void setServices(Hashtable<String, SectionVO> services) {
		this.services = services;
	}
	public HashMap<String, Object> getNetworks() {
		if(networks == null){
			return new HashMap<>();
		}
		return networks;
	}
	public void setNetworks(HashMap<String, Object> networks) {
		this.networks = networks;
	}
	public HashMap<String, Object> getVolumes() {
		if(volumes == null){
			return new HashMap<>();
		}
		return volumes;
	}
	public void setVolumes(HashMap<String, Object> volumes) {
		this.volumes = volumes;
	}
	
	public Hashtable<String, Object> getConfigs() {
		if(configs == null){
			return new Hashtable<>();
		}
		return configs;
	}
	public void setConfigs(Hashtable<String, Object> configs) {
		this.configs = configs;
	}
	
	@Override
	public void guid() {
		// TODO Auto-generated method stub

	}
}