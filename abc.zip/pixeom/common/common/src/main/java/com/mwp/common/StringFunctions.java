/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */ 

package com.mwp.common;

/**
 * 
 * This class is used to check whether given object is NullOrWhitespace
 *
 */
public class StringFunctions {
	
	private StringFunctions(){
		//	Utility class having only static members, Should not instantiated
	}
	/**
	 * Checks whether given object is NullOrWhitespace
	 * @param inputObject 
	 * @return when object is null or empty it will give you true
	 */
	public static boolean isNullOrWhitespace(Object inputObject) {
		if (inputObject == null) {
			return true;
		} else if (inputObject.equals("")) {
			return true; 
		} else {
			return false;
		}
	}
	
	public static boolean isNullOrEmpty(String string) {
        return (string == null || string.isEmpty());
    }

	
	public static String Trimend(String NewString , char ch)
	{
		int i = NewString.length() - 1; 
		for (; i >= 0 && NewString.charAt(i) == ch ; i--); 

		if(i < NewString.length() - 1)
			NewString = NewString.substring(0 , i + 1);
		return NewString;

	}

	/**
	 * Trim the "Char" from the end of the string
	 * @param NewString
	 * @param Char
	 * @return
	 */
	public static String Trimend(String NewString , String Char) {
		NewString = NewString.endsWith(Char)?NewString.substring(0, NewString.length()-1):NewString;
		return NewString;

	}

	/**
	 * Trim the "Char" from start of the String
	 * @param NewString
	 * @param Char
	 * @return
	 */
	public static String Trimstart(String NewString, String Char) {
		NewString = (NewString.startsWith(Char))?NewString.substring(1):NewString;
		return NewString;
	}
	
	/**
	 * Trim the end of the string with provided trim char
	 * @param PathToTrimEnd
	 * @param TrimChar
	 * @return
	 */
	public static String TrimEndString(String PathToTrimEnd,String TrimChar) {
		String _strRetVal=PathToTrimEnd;
		if(PathToTrimEnd.endsWith(TrimChar))	
			_strRetVal=PathToTrimEnd.substring(0, PathToTrimEnd.lastIndexOf(TrimChar));	
		return _strRetVal;				
	}
}
