/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.common;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.commons.io.FileUtils;

import com.mwp.common.constant.Constant;
import com.mwp.logger.PALogger;

public class CredProvider {

	/**
	 * Flag to raise when vault need to get only from host machine vault
	 * We have two vault one on host machine and another one in POD when cluster is created.
	 * In case of docker-compose only one vault is there, it will by default pick it from there.
	 * But in case of Kubernetes, when cluster is not in place, each node has its own local Vault
	 * But when cluster is created then we have two vaults.
	 * While setting up vault, We set active master's local vault values in POD vault.
	 * So this is check to tell in special cases when we have to access local vault not pod vault.
	 * Like in LocalDatabaseEngine, it needs MySql password from local Vault not from POD 
	 */
	private boolean useLocalVaultOnly = false;


	/**
	 * This lock insures that only one command goes in execution   
	 */
	private static Object lockMeghaInit = new Object();
	
	/**
	 * Default constructor
	 */
	public CredProvider() { }

	/**
	 * Use this Constructor to use local vault only 
	 * @param useLocalVaultOnly
	 */
	public CredProvider(boolean useLocalVaultOnly) {
		this.useLocalVaultOnly = useLocalVaultOnly;
	}

	private static boolean runningAsBox = !new File(Constant.IS_PORTAL_FILE).exists();

	/*
	 * # Grab the values - from vault
	 * --9fd2c89a-0e7b-4974-be84-7b7bb9042537 # Will return MEGHA_OPT_MYSQL_DATA   
	 * --e7c23d09d46966b91dce18f30042721017abb598c95a15d911ae09a94c7697570662f7f6d55ae9454134ad6e7d55d60995a7a8213c4ad6baf37f169534733dc5 # Will return MEGHA_OPT_MYSQL_DATA_DUMMY
	 * --6aa7dbc9-c774-46a2-aecf-e127384ae05d # Will return MEGHA_OPT_ENC_DATA
	 * --d22ca131-dedc-4b85-9d1e-07ec381678d3 # Will return MEGHA_OPT_RMQ_DATA
	 * --fc305656-607f-4941-896a-9b51899cdc53 # Will return MEGHA_OPT_PORTAL_APP_DATA
	 * --accc8d40-799b-42cd-af20-b44824319882 # Will return MEGHA_OPT_BOX_APP_DATA
	 * --4d74a8c3-aa16-4c15-b8f8-ae2e872a5e1a # Will return MEGHA_OPT_HUB_DATA
	 * --27fc0d99-a340-4710-a8db-46d49f2be32a # Will return MEGHA_OPT_BOX_DATA
	 * --0e7dc5ee-c73d-42df-947e-233fc5f75ed7 # Will return MEGHA_OPT_UPDATE_DATA
	 * --836da261-db53-47e0-809f-a29d077483e6 # Will return MEGHA_OPT_ALL_DATA
	 * --9681eab1a57648eef405ce001323aa4e2939cc686e03faa080b481e8f24b8738e846aeacc33323588c3f0eb0b5d0dd7117654644fd74d4f3c1701a6c9d3fb06d # Will create certificate files, Need to run it on every bootup or nginx service start/restart.
	 * 
	 * */

	/**
	 * MEGHA_OPT_RMQ_DATA
	 */
	private final byte[] r = new byte[] {100, 50, 50, 99, 97, 49, 51, 49, 45, 100, 101, 100, 99, 45, 52, 98, 56, 53, 45, 57, 100, 49, 101, 45, 48, 55, 101, 99, 51, 56, 49, 54, 55, 56, 100, 51};
	/**
	 * MEGHA_OPT_MYSQL_DATA
	 */
	private final byte[] m = new byte[] {57, 102, 100, 50, 99, 56, 57, 97, 45, 48, 101, 55, 98, 45, 52, 57, 55, 52, 45, 98, 101, 56, 52, 45, 55, 98, 55, 98, 98, 57, 48, 52, 50, 53, 51, 55};
	/**
	 * MEGHA_OPT_ENC_DATA
	 */
	private final byte[] e = new byte[] {54, 97, 97, 55, 100, 98, 99, 57, 45, 99, 55, 55, 52, 45, 52, 54, 97, 50, 45, 97, 101, 99, 102, 45, 101, 49, 50, 55, 51, 56, 52, 97, 101, 48, 53, 100};
	/**
	 * MEGHA_OPT_BOX_DATA
	 */
	private final byte[] h = new byte[] {50, 55, 102, 99, 48, 100, 57, 57, 45, 97, 51, 52, 48, 45, 52, 55, 49, 48, 45, 97, 56, 100, 98, 45, 52, 54, 100, 52, 57, 102, 50, 98, 101, 51, 50, 97};
	/**
	 * MEGHA_OPT_PORTAL_APP_DATA
	 */
	private final byte[] p = new byte[] {102, 99, 51, 48, 53, 54, 53, 54, 45, 54, 48, 55, 102, 45, 52, 57, 52, 49, 45, 56, 57, 54, 97, 45, 57, 98, 53, 49, 56, 57, 57, 99, 100, 99, 53, 51};
	/**
	 * MEGHA_OPT_BOX_APP_DATA
	 */
	private final byte[] b = new byte[] {97, 99, 99, 99, 56, 100, 52, 48, 45, 55, 57, 57, 98, 45, 52, 50, 99, 100, 45, 97, 102, 50, 48, 45, 98, 52, 52, 56, 50, 52, 51, 49, 57, 56, 56, 50};
	/**
	 * MEGHA_OPT_HUB_DATA
	 */
	private final byte[] d = new byte[] {52, 100, 55, 52, 97, 56, 99, 51, 45, 97, 97, 49, 54, 45, 52, 99, 49, 53, 45, 98, 56, 102, 56, 45, 97, 101, 50, 101, 56, 55, 50, 97, 53, 101, 49, 97};
	/**
	 * System certificate files 
	 */
	private final byte[] c = new byte[] {57, 54, 56, 49, 101, 97, 98, 49, 97, 53, 55, 54, 52, 56, 101, 101, 102, 52, 48, 53, 99, 101, 48, 48, 49, 51, 50, 51, 97, 97, 52, 101, 50, 57, 51, 57, 99, 99, 54, 56, 54, 101, 48, 51, 102, 97, 97, 48, 56, 48, 98, 52, 56, 49, 101, 56, 102, 50, 52, 98, 56, 55, 51, 56, 101, 56, 52, 54, 97, 101, 97, 99, 99, 51, 51, 51, 50, 51, 53, 56, 56, 99, 51, 102, 48, 101, 98, 48, 98, 53, 100, 48, 100, 100, 55, 49, 49, 55, 54, 53, 52, 54, 52, 52, 102, 100, 55, 52, 100, 52, 102, 51, 99, 49, 55, 48, 49, 97, 54, 99, 57, 100, 51, 102, 98, 48, 54, 100};

	private enum VaultInstance {
		POD,
		LOCAL
	}

	private static Map<VaultInstance, String> MEGHA_OPT_RMQ_DATA = new HashMap<>();
	private static Map<VaultInstance, String> MEGHA_OPT_MYSQL_DATA = new HashMap<>();
	private static Map<VaultInstance, String> MEGHA_OPT_ENC_DATA = new HashMap<>();
	private static Map<VaultInstance, String> MEGHA_OPT_BOX_DATA = new HashMap<>();
	private static Map<VaultInstance, String> MEGHA_OPT_PORTAL_APP_DATA = new HashMap<>();
	private static Map<VaultInstance, String> MEGHA_OPT_BOX_APP_DATA = new HashMap<>();
	private static Map<VaultInstance, String> MEGHA_OPT_HUB_DATA = new HashMap<>();

	public void clearMemory() {
		MEGHA_OPT_RMQ_DATA.clear();        
		MEGHA_OPT_MYSQL_DATA.clear();      
		MEGHA_OPT_ENC_DATA.clear();        
		MEGHA_OPT_BOX_DATA.clear();        
		MEGHA_OPT_PORTAL_APP_DATA.clear(); 
		MEGHA_OPT_BOX_APP_DATA.clear();    
		MEGHA_OPT_HUB_DATA.clear();        
	}

	public byte[] getR() {
		return r;
	}
	public byte[] getM() {
		return m;
	}
	public byte[] getE() {
		return e;
	}
	public byte[] getH() {
		return h;
	}
	public byte[] getP() {
		return p;
	}
	public byte[] getB() {
		return b;
	}
	public byte[] getD() {
		return d;
	}
	public byte[] getC() {
		return c;
	}

	public String getRmqUser() {
		return "pixeom";
	}
	public String getMysqUser() {
		return "root";
	}

	public String getRMQPwd() {
		return mGetRmqPwd();
	}

	public String getMysqlPwd() {
		return mGetMysqPwd(0);
	}

	public String getMysqlPwd(int retries) {
		return mGetMysqPwd(retries);
	}

	public String getEcnKey(){
		return mGetEncKey();
	}

	public String getHostPwd() {
		return mGetHostPwd();
	}

	public String getPortalAppSecKey() {
		return mGetPortalAppSecKey();
	}

	public String getBoxAppSecKey() {
		return mGetBoxAppSecKey();
	}

	public String getDockerRegPwd() {
		return mGetDockerRegPwd();
	}

	public void getCerts() {
		mGetCerts();
	}

	public void removeCerts() {
		mRemoveCerts();
	}

	private String mGetRmqPwd() {
		return getData(new String(r), MEGHA_OPT_RMQ_DATA);		
	}

	private String mGetMysqPwd(int retries) {
		return getData(new String(m), MEGHA_OPT_MYSQL_DATA, retries);
	}

	private String mGetEncKey() {
		return getData(new String(e), MEGHA_OPT_ENC_DATA);
	}

	private String mGetHostPwd() {
		return getData(new String(h), MEGHA_OPT_BOX_DATA);
	}

	private String mGetPortalAppSecKey() {

		String data = getData(new String(p), MEGHA_OPT_PORTAL_APP_DATA);
		return data.replaceAll("-", "");
	}

	private String mGetBoxAppSecKey() {
		String data = getData(new String(b), MEGHA_OPT_BOX_APP_DATA);
		return data.replaceAll("-", "");
	}

	private String mGetDockerRegPwd() {
		return getData(new String(d), MEGHA_OPT_HUB_DATA);	
	}

	private static AtomicInteger weight = new AtomicInteger(0);
	private void mGetCerts() {
		int weightVal = weight.incrementAndGet();
		PALogger.INFO("Get Certs Weight: " + weightVal);

		File sysPrivKey = new File(Constant.SYSTEM_PRIVATE_KEY);
		while(!sysPrivKey.exists()) {
			PALogger.TRACE("private key does not exists on host getting from Vault.");
			try {
				CommandExecutor commandExecutor = new CommandExecutor();
				ArrayList<String> commands = new ArrayList<>();
				commands.add("/usr/sbin/megha-init");
				commands.add("--" + new String(c));
				commandExecutor.Execute(commands).trim();
			} catch (Exception ex) {
				PALogger.ERROR(ex);
			}

			if(!sysPrivKey.exists()) {

				try {
					Thread.sleep(250);
				} catch (InterruptedException ex) {
					PALogger.ERROR(ex);
					// Thread.currentThread().interrupt();
				}

				PALogger.TRACE("Unable get private key from Vault - retrying");
			}
		}
	}

	private void mRemoveCerts() {
		int weightVal = weight.decrementAndGet();
		PALogger.INFO("Remove Certs Weight: " + weightVal);
		if(weightVal <= 0) {
			File sysPrivKey = new File(Constant.SYSTEM_PRIVATE_KEY);
			File sysCert = new File(Constant.SYSTEM_CERT);

			FileUtils.deleteQuietly(sysPrivKey);
			FileUtils.deleteQuietly(sysCert);
		}
	}

	/**
	 * get data from vault,
	 * 
	 * if flag useLocalVaultOnly is raised than get from local vault only
	 * if running as box than check if cluster is created (by simply checking the existence of DB_SERVER_FILE)
	 * 	than get value from POD vault. 
	 * 
	 * @param queryString
	 * @return
	 */
	private String getData(String queryString, Map<VaultInstance, String> dataHolder) {
		return getData(queryString, dataHolder, 0);
	}
	private String getData(String queryString, Map<VaultInstance, String> dataHolder, int retries) {
		if(!useLocalVaultOnly && runningAsBox && new File(Constant.DB_SERVER_FILE).exists()) {
			//PALogger.INFO("Getting data from POD vault.");

			if(!dataHolder.containsKey(VaultInstance.POD) || StringFunctions.isNullOrWhitespace(dataHolder.get(VaultInstance.POD))) {

				synchronized (dataHolder) {
					if(!dataHolder.containsKey(VaultInstance.POD) || StringFunctions.isNullOrWhitespace(dataHolder.get(VaultInstance.POD))) {

						PALogger.INFO("Getting data from POD vault - New.");

						if(retries == 0) {
							dataHolder.put(VaultInstance.POD, getDataFromPOD(queryString));	
						} else {
							dataHolder.put(VaultInstance.POD, getDataFromPOD(queryString, retries));
						}
					}
				}
			}
			return dataHolder.get(VaultInstance.POD);
		} else {
			//PALogger.INFO("Getting data from local vault.");
			if(!dataHolder.containsKey(VaultInstance.LOCAL)) {

				synchronized (dataHolder) {
					if(!dataHolder.containsKey(VaultInstance.LOCAL)) {
						PALogger.INFO("Getting data from local vault - New.");


						dataHolder.put(VaultInstance.LOCAL, getDataFromCommand("--" + queryString));
					}
				}
			}
			return dataHolder.get(VaultInstance.LOCAL);
		}
	}

	private String getDataFromPOD(String queryString) {
		VaultCommands vaultCommands = new VaultCommands();
		String data = "";
		while("".equals(data)) {
			try {
				data = vaultCommands.getValue(queryString);
			} catch (Exception ex) {
				PALogger.ERROR(ex);
			}
			if(StringFunctions.isNullOrWhitespace(data)) {
				data = "";
				PALogger.TRACE("No DATA FROM POD VAULT!!!");				

				try {
					Thread.sleep(250);
				} catch (InterruptedException ex) {
					PALogger.ERROR(ex);			
					// Thread.currentThread().interrupt();
				}

			}
		}
		return data;
	}

	private static String getDataFromPOD(String queryString, int retries) {
		VaultCommands vaultCommands = new VaultCommands();
		String data = "";

		int tries = 0;

		while(tries < retries) {
			tries++;
			try {
				synchronized (lockMeghaInit) 
				{
					data = vaultCommands.getValue(queryString);
				}
			} catch (Exception e) {
				PALogger.ERROR(e);
			}
			if(StringFunctions.isNullOrWhitespace(data)) {
				data = "";
				PALogger.TRACE("No DATA FROM POD VAULT!!!");				

				try {
					Thread.sleep(250);
				} catch (InterruptedException ex) {
					PALogger.ERROR(ex);
					// Thread.currentThread().interrupt();
				}
			} else {
				tries = retries;
			}
		}
		return data;
	}

	private static String getDataFromCommand(String queryString) {
		String data = "";
		while("".equals(data)) {
			try {

				synchronized (lockMeghaInit) 
				{
					CommandExecutor commandExecutor = new CommandExecutor();
					ArrayList<String> commands = new ArrayList<>();
					commands.add("/usr/sbin/megha-init");
					commands.add(queryString);
					data = commandExecutor.Execute(commands).trim();
				}

			} catch (Exception e) {
				PALogger.ERROR(e);
			}
			if("".equals(data)) {
				PALogger.TRACE("No DATA FROM VAULT!!!");				

				try {
					Thread.sleep(250);
				} catch (InterruptedException e) {
					PALogger.ERROR(e);
					// Thread.currentThread().interrupt();
				}
			}
		}
		return data;
	}
}
