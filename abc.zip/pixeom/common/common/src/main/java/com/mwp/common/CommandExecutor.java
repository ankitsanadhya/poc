/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */ 

package com.mwp.common;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.commons.io.IOUtils;

import com.mwp.logger.PALogger;

/**
 * 
 * This class is used to execute system commands
 *
 */
public class CommandExecutor {

	/**
	 * This method is used to execute List of system commands
	 * @param Command : command to execute
	 * @return
	 * @throws Exception
	 */
	public  String Execute(List<String> Command) throws InterruptedException, ExecutionException, TimeoutException {
		return Execute(Command, 0, false);
	}

	/**
	 * This method is used to execute List of system commands with a boolean to print result
	 * @param Command : command to execute
	 * @param printResult : true to print result and false for not to print result
	 * @return
	 * @throws Exception
	 */
	public  String Execute(List<String> Command, boolean printResult) throws InterruptedException, ExecutionException, TimeoutException {
		return Execute(Command, 0, printResult);
	}

	/**
	 * This method is used to execute List of system commands with a boolean to print result
	 * @param Command : command to execute
	 * @param atomicInteger : this value return process exit value.
	 * @return
	 * @throws Exception
	 */
	public String Execute(List<String> Command, AtomicInteger atomicInteger) throws InterruptedException, ExecutionException, TimeoutException {
		return Execute(Command, 0, false, atomicInteger);
	}

	/**
	 * This method is used to execute List of system commands with a extra value to wait for the command to finish
	 * @param Command : command to execute
	 * @param wait : long value to wait for a command to finish
	 * @return
	 * @throws Exception
	 */
	public String Execute(List<String> Command, long wait) throws InterruptedException, ExecutionException, TimeoutException	{
		return Execute(Command, wait, false);
	}

	/**
	 * This method is used to execute List of system commands with both wait and print result option
	 * @param Command : command to execute
	 * @param wait : long value to wait for a command to finish
	 * @param printResult : true to print result and false for not to print result
	 * @return
	 * @throws Exception
	 */
	public String Execute(List<String> command, long wait, boolean printResult) throws InterruptedException, ExecutionException, TimeoutException {	
		return executeCommand(command, wait, printResult);
	}

	private String executeCommand(List<String> command, long wait, boolean printResult) throws InterruptedException, ExecutionException, TimeoutException {
		String result = "";
		ExecutorService executers = null;
		try {
			executers = Executors.newSingleThreadExecutor();
			Future<String> taskResult = executers.submit(new Callable<String>() {

				@Override
				public String call() throws Exception {

					return processor(command);
				}
			});

			if(wait > 0) {
				try {
					result = taskResult.get(wait, TimeUnit.SECONDS);
				} catch (TimeoutException e) {
					PALogger.TRACE(String.join(" ", command));
					PALogger.ERROR(e);
					taskResult.cancel(true);
					throw e;
				}
			} else {
				result = taskResult.get();
			}

			if(printResult) {
				PALogger.INFO(result);
			}

		} finally {
			if(executers != null) {
				executers.shutdown();
			}
		}
		return result;
	}

	/**
	 * This method is used to execute List of system commands with both wait and print result option
	 * @param Command : command to execute
	 * @param wait : long value to wait for a command to finish
	 * @param printResult : true to print result and false for not to print result
	 * @param atomicInteger : this value return process exit value.
	 * @return
	 * @throws Exception
	 */
	public String Execute(List<String> command, long wait, boolean printResult, AtomicInteger atomicInteger) throws InterruptedException, ExecutionException, TimeoutException {	
		return executeCommand(command, wait, printResult, atomicInteger);
	}

	private String executeCommand(List<String> command, long wait, boolean printResult, AtomicInteger atomicInteger) throws InterruptedException, ExecutionException, TimeoutException {
		String result = "";
		ExecutorService executers = null;
		try {
			executers = Executors.newSingleThreadExecutor();
			Future<String> taskResult = executers.submit(new Callable<String>() {

				@Override
				public String call() throws Exception {

					return processor(command, atomicInteger);
				}
			});

			if(wait > 0) {
				try {
					result = taskResult.get(wait, TimeUnit.SECONDS);
				} catch (TimeoutException e) {
					PALogger.TRACE(String.join(" ", command));
					PALogger.ERROR(e);
					taskResult.cancel(true);
					throw e;
				}
			} else {
				result = taskResult.get();
			}

			if(printResult) {
				PALogger.INFO(result);
			}

		} finally {
			if(executers != null) {
				executers.shutdown();
			}
		}
		return result;
	}

	/**
	 * This method is used to init kubeadm
	 * @param command : command to execute
	 * @return
	 * @throws IOException
	 */
	public String processorCmdInitKube(List<String> command) throws IOException {
		Process p = null;
		String returnVal ="";
		try {
			ProcessBuilder pb = new ProcessBuilder(command);
			pb.redirectErrorStream(true);
			p = pb.start();

			try(BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()))){
				String str = "";

				String result = "";
				while ((str = br.readLine()) != null) {
					result += "\n" + str;
					PALogger.INFO(str);
					if(str.trim().startsWith("kubeadm join")){
						returnVal = str.trim();
					}
				}
				PALogger.INFO(result);
				IOUtils.closeQuietly(p.getOutputStream());
				IOUtils.closeQuietly(p.getInputStream());
			}
		} finally {
			if(p != null) {
				p.destroy();
			}
		}
		return returnVal;
	}

	private String processor(List<String> command) throws IOException {
		Process p = null;
		String returnVal ="";
		try {
			ProcessBuilder pb = new ProcessBuilder(command);
			pb.redirectErrorStream(true);
			p = pb.start();

			try(BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()))){
				String str = "";

				while ((str = br.readLine()) != null)
				{
					returnVal += str + "\n";
				}
				IOUtils.closeQuietly(p.getOutputStream());
				IOUtils.closeQuietly(p.getInputStream());
			}
		} finally {
			if(p != null) {
				p.destroy();
			}
		}
		return returnVal;
	}

	private String processor(List<String> command, AtomicInteger integer) throws IOException {
		Process p = null;
		String returnVal ="";
		try {
			ProcessBuilder pb = new ProcessBuilder(command);
			pb.redirectErrorStream(true);
			p = pb.start();

			try(BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()))){
				String str = "";

				while ((str = br.readLine()) != null)
				{
					returnVal += str + "\n";
				}

				IOUtils.closeQuietly(p.getOutputStream());
				IOUtils.closeQuietly(p.getInputStream());
			}
		} finally {
			if(p != null) {
				try {
					p.waitFor();
				} catch (InterruptedException e) {
					PALogger.ERROR(e);
					Thread.currentThread().interrupt();
				}
				integer.set(p.exitValue());
				p.destroy();
			}
		}
		return returnVal;
	}

	/**
	 * This method is used to execute command in execute command with a option to kill process
	 * @param Command : List<String> command to execute
	 * @param killProcess : boolean
	 * @return
	 * @throws InterruptedException
	 * @throws IOException
	 */
	public String ExecuteBgProcess(List<String> Command, boolean killProcess) throws InterruptedException, IOException {	
		Process p = null;
		String returnVal = "";

		try {
			ProcessBuilder pb = new ProcessBuilder(Command);
			pb.redirectErrorStream(true);
			p = pb.start();
			if(!p.waitFor(5, TimeUnit.SECONDS)){
				return returnVal;
			}

			try(BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()))){

				String str = "";
				while ((str = br.readLine()) != null) {
					returnVal += str + "\n";
				}

				killProcess = true;

				IOUtils.closeQuietly(p.getOutputStream());
				IOUtils.closeQuietly(p.getInputStream());
			}
		} finally {
			if(p != null && killProcess) {
					p.destroy();
			}
		}
		return returnVal;
	}

}
