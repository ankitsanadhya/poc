/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */ 

package com.mwp.common.enums;

import java.util.HashMap;
import java.util.Map;

/**
 * This class provides enum values for  all type of resources that can be embedded with application at the time of installation
 *  
 * @author PS
 *
 */
public enum ResourceKindEnum {
	appYaml(0, "yaml", "", ""),
	nginxConfig(1, "nginx configuration", "nginx/", "resourceNginxConfig"),
	nginxCertificate(2, "SSL certificate", "nginx/", "resourceNginxCertificate"),
	nginxCertificateKey(3, "SSL certificate key", "nginx/", "resourceNginxCertificateKey"),
	nginxDhParam(4, "DH parameters", "nginx/", "resourceNginxDhParam"),
	dockerBuildFile(5, "docker build", "build/", "resourceDockerBuildFile"),
	dockerEnvFile(6, "docker environment file ", "env/", "resourceDockerEnvFile");

	private int num;
	private String displayName;
	private String folderName;
	private String installDetailKeyName;

	/**
	 * 
	 * @param n - The numerical value of enum to use in Database
	 * @param displayName - Display name to show in error messages 
	 * @param folderName - Folder name in which the resources are kept on portal  
	 * @param installDetailKeyName - Key name of the map, submitted with install/update job from portal 
	 */
	private ResourceKindEnum(int n, String displayName, String folderName, String installDetailKeyName) {
		num = n;
		this.displayName = displayName;
		this.folderName = folderName;
		this.installDetailKeyName = installDetailKeyName;
		ResourceKindEnumList.map.put(n, this);
	}

	public int getValue() {
		return num;
	}
	public String getDisplayName() {
		return displayName;
	} 
	public String getFolderName() {
		return folderName;
	}
	public String getInstallDetailKeyName() {
		return installDetailKeyName;
	}
	public static ResourceKindEnum GetEnum(int num) {
		return ResourceKindEnumList.map.get(num);	
	}

	static class ResourceKindEnumList {
		static Map<Integer, ResourceKindEnum> map = new HashMap<>();
	}
}