/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.mwp.common.yamlparser;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.mwp.common.ISkipObfuscation;
import com.mwp.common.enums.SecretTypeEnum;

public class SecretVersionVO implements ISkipObfuscation {

	private String appSecretVersionId;
	private String appSecretId;
	private String appUserId;
	private String versionSecretValue;
	private String versionPath;
	private String versionFileName;
	private SecretTypeEnum secretType;
	
	public SecretTypeEnum getType() {
		return secretType;
	}

	public void setType(SecretTypeEnum secretType) {
		this.secretType = secretType;
	}
	@Size(min = 2, max = 100, message = "The length of display name should be between 2 to 100")
	@Pattern( regexp = "^[a-zA-Z0-9](?:[-._]*[A-Za-z0-9]+)*$" ,message = "Display name must start with a letter or a number followed by 1 - 64 letters, numbers or underscores and cannot end with an underscore.")
	private String displayName;//secret key's display name

	
	public String getValue() {
		return versionSecretValue;
	}

	public void setValue(String value) {
		this.versionSecretValue = value;
	}
	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public String getAppSecretVersionId() {
		return appSecretVersionId;
	}

	public void setAppSecretVersionId(String appSecretVersionId) {
		this.appSecretVersionId = appSecretVersionId;
	}
	
	public String getAppSecretId() {
		return appSecretId;
	}

	public void setAppSecretId(String appSecretId) {
		this.appSecretId = appSecretId;
	}

	public String getAppUserId() {
		return appUserId;
	}

	public void setAppUserId(String appUserId) {
		this.appUserId = appUserId;
	}
	
	public String getFileName() {
		return versionFileName;
	}

	public void setFileName(String fileName) {
		this.versionFileName = fileName;
	}

	public String getPath() {
		return versionPath;
	}

	public void setPath(String path) {
		this.versionPath = path;
	}
	@Override
	public void guid() {
	}
}