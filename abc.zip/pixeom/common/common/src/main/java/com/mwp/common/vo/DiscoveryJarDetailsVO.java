/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */ 

package com.mwp.common.vo;

import com.mwp.common.ISkipObfuscation;
import com.mwp.common.enums.RelayEnum.NetworkTypeEnum;

public class DiscoveryJarDetailsVO implements ISkipObfuscation {

	private String sMACAddress;
	private String sHostName;
	private String sIPAddress;
	private String sLocalIPAddress;
//	private String sKeyStonePort;
	private String sTomcatPort;
	private String sPort1;
	private String sPort5;
	private String sRURLTomcatPort;
	//private String sRURLKeystonePort;
	private String sRAddress;
	private String sRelayServerID;
	private NetworkTypeEnum sNetworkType;
	private String sConnectURL;
	private int nStatus;
	private String sRelayServerAddress;
	private String sRUserName;
	private int nRPort;
	private String sRPassword;
	//added property for ssh host key
		private String sHostKey;
	
	private String nNodeStatus;
	private String sRingID;
	private String sMasterID;
	private String sChatInputChannel;
	private String sChatOutputChannel;
	private String sChatSubscriptionChannel;
	private String sNodeCommunicationPort;
	private String sOpenStackPort;
	private String sPort2;
	private String sPort3;
	private String sPort4;
	private String nIsDeleted;
	private String nAdult;
	private long dHBRdate;
	private String sDeviceId;
	private String isSetRURL;
	private String IPReal;
	/**
	 * @return the sMACAddress
	 */
	public String getsMACAddress() {
		return sMACAddress;
	}
	/**
	 * @param sMACAddress the sMACAddress to set
	 */
	public void setsMACAddress(String sMACAddress) {
		this.sMACAddress = sMACAddress;
	}
	/**
	 * @return the sHostName
	 */
	public String getsHostName() {
		return sHostName;
	}
	/**
	 * @param sHostName the sHostName to set
	 */
	public void setsHostName(String sHostName) {
		this.sHostName = sHostName;
	}
	/**
	 * @return the sIPAddress
	 */
	public String getsIPAddress() {
		return sIPAddress;
	}
	/**
	 * @param sIPAddress the sIPAddress to set
	 */
	public void setsIPAddress(String sIPAddress) {
		this.sIPAddress = sIPAddress;
	}
	/**
	 * @return the sLocalIPAddress
	 */
	public String getsLocalIPAddress() {
		return sLocalIPAddress;
	}
	/**
	 * @param sLocalIPAddress the sLocalIPAddress to set
	 */
	public void setsLocalIPAddress(String sLocalIPAddress) {
		this.sLocalIPAddress = sLocalIPAddress;
	}
//	/**
//	 * @return the sKeyStonePort
//	 */
//	public String getsKeyStonePort() {
//		return sKeyStonePort;
//	}
//	/**
//	 * @param sKeyStonePort the sKeyStonePort to set
//	 */
//	public void setsKeyStonePort(String sKeyStonePort) {
//		this.sKeyStonePort = sKeyStonePort;
//	}
	/**
	 * @return the sTomcatPort
	 */
	public String getsTomcatPort() {
		return sTomcatPort;
	}
	/**
	 * @param sTomcatPort the sTomcatPort to set
	 */
	public void setsTomcatPort(String sTomcatPort) {
		this.sTomcatPort = sTomcatPort;
	}
	/**
	 * @return the sPort1
	 */
	public String getsPort1() {
		return sPort1;
	}
	/**
	 * @param sPort1 the sPort1 to set
	 */
	public void setsPort1(String sPort1) {
		this.sPort1 = sPort1;
	}
	/**
	 * @return the sPort5
	 */
	public String getsPort5() {
		return sPort5;
	}
	/**
	 * @param sPort5 the sPort5 to set
	 */
	public void setsPort5(String sPort5) {
		this.sPort5 = sPort5;
	}
	/**
	 * @return the sRURLTomcatPort
	 */
	public String getsRURLTomcatPort() {
		return sRURLTomcatPort;
	}
	/**
	 * @param sRURLTomcatPort the sRURLTomcatPort to set
	 */
	public void setsRURLTomcatPort(String sRURLTomcatPort) {
		this.sRURLTomcatPort = sRURLTomcatPort;
	}
//	/**
//	 * @return the sRURLKeystonePort
//	 */
//	public String getsRURLKeystonePort() {
//		return sRURLKeystonePort;
//	}
//	/**
//	 * @param sRURLKeystonePort the sRURLKeystonePort to set
//	 */
//	public void setsRURLKeystonePort(String sRURLKeystonePort) {
//		this.sRURLKeystonePort = sRURLKeystonePort;
//	}
	/**
	 * @return the sRAddress
	 */
	public String getsRAddress() {
		return sRAddress;
	}
	/**
	 * @param sRAddress the sRAddress to set
	 */
	public void setsRAddress(String sRAddress) {
		this.sRAddress = sRAddress;
	}
	/**
	 * @return the sRelayServerID
	 */
	public String getsRelayServerID() {
		return sRelayServerID;
	}
	/**
	 * @param sRelayServerID the sRelayServerID to set
	 */
	public void setsRelayServerID(String sRelayServerID) {
		this.sRelayServerID = sRelayServerID;
	}
	/**
	 * @return the sNetworkType
	 */
	public NetworkTypeEnum getsNetworkType() {
		return sNetworkType;
	}
	/**
	 * @param sNetworkType the sNetworkType to set
	 */
	public void setsNetworkType(NetworkTypeEnum sNetworkType) {
		this.sNetworkType = sNetworkType;
	}
	/**
	 * @return the sConnectURL
	 */
	public String getsConnectURL() {
		return sConnectURL;
	}
	/**
	 * @param sConnectURL the sConnectURL to set
	 */
	public void setsConnectURL(String sConnectURL) {
		this.sConnectURL = sConnectURL;
	}
	/**
	 * @return the nStatus
	 */
	public int getnStatus() {
		return nStatus;
	}
	/**
	 * @param nStatus the nStatus to set
	 */
	public void setnStatus(int nStatus) {
		this.nStatus = nStatus;
	}
	/**
	 * @return the sRelayServerAddress
	 */
	public String getsRelayServerAddress() {
		return sRelayServerAddress;
	}
	/**
	 * @param sRelayServerAddress the sRelayServerAddress to set
	 */
	public void setsRelayServerAddress(String sRelayServerAddress) {
		this.sRelayServerAddress = sRelayServerAddress;
	}
	/**
	 * @return the sRUserName
	 */
	public String getsRUserName() {
		return sRUserName;
	}
	/**
	 * @param sRUserName the sRUserName to set
	 */
	public void setsRUserName(String sRUserName) {
		this.sRUserName = sRUserName;
	}
	/**
	 * @return the nRPort
	 */
	public int getnRPort() {
		return nRPort;
	}
	/**
	 * @param nRPort the nRPort to set
	 */
	public void setnRPort(int nRPort) {
		this.nRPort = nRPort;
	}
	/**
	 * @return the sRPassword
	 */
	public String getsRPassword() {
		return sRPassword;
	}
	/**
	 * @param sRPassword the sRPassword to set
	 */
	public void setsRPassword(String sRPassword) {
		this.sRPassword = sRPassword;
	}
	/**
	 * @return the nNodeStatus
	 */
	public String getnNodeStatus() {
		return nNodeStatus;
	}
	/**
	 * @param nNodeStatus the nNodeStatus to set
	 */
	public void setnNodeStatus(String nNodeStatus) {
		this.nNodeStatus = nNodeStatus;
	}
	/**
	 * @return the sRingID
	 */
	public String getsRingID() {
		return sRingID;
	}
	/**
	 * @param sRingID the sRingID to set
	 */
	public void setsRingID(String sRingID) {
		this.sRingID = sRingID;
	}
	/**
	 * @return the sMasterID
	 */
	public String getsMasterID() {
		return sMasterID;
	}
	/**
	 * @param sMasterID the sMasterID to set
	 */
	public void setsMasterID(String sMasterID) {
		this.sMasterID = sMasterID;
	}
	/**
	 * @return the sChatInputChannel
	 */
	public String getsChatInputChannel() {
		return sChatInputChannel;
	}
	/**
	 * @param sChatInputChannel the sChatInputChannel to set
	 */
	public void setsChatInputChannel(String sChatInputChannel) {
		this.sChatInputChannel = sChatInputChannel;
	}
	/**
	 * @return the sChatOutputChannel
	 */
	public String getsChatOutputChannel() {
		return sChatOutputChannel;
	}
	/**
	 * @param sChatOutputChannel the sChatOutputChannel to set
	 */
	public void setsChatOutputChannel(String sChatOutputChannel) {
		this.sChatOutputChannel = sChatOutputChannel;
	}
	/**
	 * @return the sChatSubscriptionChannel
	 */
	public String getsChatSubscriptionChannel() {
		return sChatSubscriptionChannel;
	}
	/**
	 * @param sChatSubscriptionChannel the sChatSubscriptionChannel to set
	 */
	public void setsChatSubscriptionChannel(String sChatSubscriptionChannel) {
		this.sChatSubscriptionChannel = sChatSubscriptionChannel;
	}
	/**
	 * @return the sNodeCommunicationPort
	 */
	public String getsNodeCommunicationPort() {
		return sNodeCommunicationPort;
	}
	/**
	 * @param sNodeCommunicationPort the sNodeCommunicationPort to set
	 */
	public void setsNodeCommunicationPort(String sNodeCommunicationPort) {
		this.sNodeCommunicationPort = sNodeCommunicationPort;
	}
	/**
	 * @return the sOpenStackPort
	 */
	public String getsOpenStackPort() {
		return sOpenStackPort;
	}
	/**
	 * @param sOpenStackPort the sOpenStackPort to set
	 */
	public void setsOpenStackPort(String sOpenStackPort) {
		this.sOpenStackPort = sOpenStackPort;
	}
	/**
	 * @return the sPort2
	 */
	public String getsPort2() {
		return sPort2;
	}
	/**
	 * @param sPort2 the sPort2 to set
	 */
	public void setsPort2(String sPort2) {
		this.sPort2 = sPort2;
	}
	/**
	 * @return the sPort3
	 */
	public String getsPort3() {
		return sPort3;
	}
	/**
	 * @param sPort3 the sPort3 to set
	 */
	public void setsPort3(String sPort3) {
		this.sPort3 = sPort3;
	}
	/**
	 * @return the sPort4
	 */
	public String getsPort4() {
		return sPort4;
	}
	/**
	 * @param sPort4 the sPort4 to set
	 */
	public void setsPort4(String sPort4) {
		this.sPort4 = sPort4;
	}
	/**
	 * @return the nIsDeleted
	 */
	public String getnIsDeleted() {
		return nIsDeleted;
	}
	/**
	 * @param nIsDeleted the nIsDeleted to set
	 */
	public void setnIsDeleted(String nIsDeleted) {
		this.nIsDeleted = nIsDeleted;
	}
	/**
	 * @return the nAdult
	 */
	public String getnAdult() {
		return nAdult;
	}
	/**
	 * @param nAdult the nAdult to set
	 */
	public void setnAdult(String nAdult) {
		this.nAdult = nAdult;
	}
	/**
	 * @return the dHBRdate
	 */
	public long getdHBRdate() {
		return dHBRdate;
	}
	/**
	 * @param dHBRdate the dHBRdate to set
	 */
	public void setdHBRdate(long dHBRdate) {
		this.dHBRdate = dHBRdate;
	}
	/**
	 * @return the previousTimeStamp
	 */
	public String getsDeviceId() {
		return sDeviceId;
	}
	/**
	 * @param previousTimeStamp the previousTimeStamp to set
	 */
	public void setsDeviceId(String deviceId) {
		this.sDeviceId = deviceId;
	}
	/**
	 * @return the isSetRURL
	 */
	public String getIsSetRURL() {
		return isSetRURL;
	}
	/**
	 * @param isSetRURL the isSetRURL to set
	 */
	public void setIsSetRURL(String isSetRURL) {
		this.isSetRURL = isSetRURL;
	}
	
	public String getIPReal() {
		return IPReal;
	}
	public void setIPReal(String iPReal) {
		IPReal = iPReal;
	}
	@Override
	public void guid() {
		// TODO Auto-generated method stub
		
	}
	public String getsHostKey() {
		return sHostKey;
	}
	public void setsHostKey(String sHostKey) {
		this.sHostKey = sHostKey;
	}
	
	
}
