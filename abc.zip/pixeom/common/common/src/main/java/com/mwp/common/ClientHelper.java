/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */ 

package com.mwp.common;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.rmi.ServerException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTime;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.mwp.common.constant.Constant;
import com.mwp.common.constant.ErrorMessage;
import com.mwp.common.enums.DeviceTypeEnum;
import com.mwp.common.enums.FilterKeysEnum;
import com.mwp.common.enums.FilterType;
import com.mwp.common.enums.Operator;
import com.mwp.common.enums.OwnershipEnum;
import com.mwp.common.enums.RelayEnum.NetworkTypeEnum;
import com.mwp.common.enums.SW_PLATFORMS;
import com.mwp.common.enums.SortKeysEnum;
import com.mwp.common.enums.ValueType;
import com.mwp.common.vo.DiscoveryDetailsVO;
import com.mwp.common.vo.DiscoveryJarDetailsVO;
import com.mwp.common.vo.FilterObject;
import com.mwp.common.vo.PlatformVO;
import com.mwp.common.vo.ValidationInfoVO;
import com.mwp.logger.PALogger;
import com.pa.crypto.FileEncryptionDecryption;

/**
 * 
 * This is a helper class for HTTP and HTTPS requests  
 *
 */
public class ClientHelper
{


	public static final String DEVICE_DISCOVERY_CLASSNAME = "discovery";
	public static final String PORTAL_SERVICE_NAME="p.service/api";
	private static String portalAuthUrl = "";
	private static String portalUrl = ""; 
	public static String serverAddress = "";

	/**
	 *  DEVICE_ID = "deviceId";
	 */
	private final static String DEVICE_ID = "deviceId";

	/**
	 *  DEVICE_ID = "deviceId";
	 */
	private final static String BACK_CALLER_RESTPATH = "backCallerRestPath";

	/**
	 *  DETAILS_VO = "DetailsVO"
	 */
	private static final String DETAILS_VO = "DetailsVO";

	private static final String VALIDATION_INFO_VO = "ValidationInfoVO";

	/**
	 *  BEARER = "bearer "
	 */
	private static final String BEARER = Constant.BEARER;

	/**
	 * invalidParameters = "Invalid Parameters"
	 */
	private static final String INVALID_PARAMETERS = "Invalid Parameters";

	/**
	 * devices = "devices"
	 */
	private static final String DEVICES = "devices";

	static {
		// Get portal server ip address from file.

		try {
			JSONParser parser = new JSONParser();
			JSONObject obj = (JSONObject) parser.parse(new FileReader("/opt/app_engine/ListingServer"));

			portalAuthUrl = "https://" + obj.get("portalAuthUrl").toString() + Constant.localFileSeparator;
			portalUrl = "https://" + obj.get("portalUrl").toString() + Constant.localFileSeparator;

			serverAddress = obj.get("domainName").toString();
		} catch (Exception e) {
			PALogger.ERROR(e);
		}
	}	

	/**
	 * This method update discovery detail- connectURL, networkType and other details.
	 * @param boxID
	 * @param isActive true if current device is active master
	 * @param ip
	 * @param networkType
	 * @param relayServerId
	 * @param tomcatPort
	 * @param port1
	 * @param port2
	 * @param port3
	 * @param port4
	 * @param port5
	 * @param rurlTomcatPort
	 * @param rurlAddress
	 * @param authToken
	 * @return
	 * @throws Exception
	 */
	public String updateDeviceHeartbeat(String boxID, boolean isActive, String productId) throws Exception{
		try
		{
			String jwtToken = getJwtToken(productId, boxID);
			if(StringFunctions.isNullOrWhitespace(boxID)){
				return Client.callServer(portalAuthUrl, PORTAL_SERVICE_NAME, DEVICE_DISCOVERY_CLASSNAME, "POST", "updateheartbeatinactive", null, productId, jwtToken);
			}else{
				Map<Object, Object> queryParam = null;
				/** PS_1
				 * if the current node is active device then it sending query parameter to update current active master 
				 */
				if(isActive)
				{
					queryParam = new HashMap<>();
					queryParam.put("isActive", true);
				}

			
				return Client.callServer(portalAuthUrl, PORTAL_SERVICE_NAME, DEVICE_DISCOVERY_CLASSNAME, "POST", "updateheartbeat", queryParam, boxID, jwtToken);
			}
		}
		catch(Exception ex)
		{
			PALogger.ERROR(ex);
			throw ex;
		}
	}
	
	/**
	 * This method update discovery detail- connectURL, networkType and other details.
	 * @param boxID
	 * @param ip
	 * @param networkType
	 * @param relayServerId
	 * @param tomcatPort
	 * @param port1
	 * @param port2
	 * @param port3
	 * @param port4
	 * @param port5
	 * @param rurlTomcatPort
	 * @param rurlAddress
	 * @param authToken
	 * @return
	 * @throws Exception
	 */
	public String setConnectURL(String macAddress, String boxID, String ip, NetworkTypeEnum networkType,
			String relayServerId, String tomcatPort,String port1,
			String port2, String port3, String port4, String port5,
			String rurlTomcatPort,
			String rurlAddress) throws Exception
	{
		try
		{
			DiscoveryDetailsVO discoveryDetails = new DiscoveryDetailsVO();
			discoveryDetails.setsIPAddress(ip);
			discoveryDetails.setsNetworkType(networkType);
			discoveryDetails.setsRelayServerID(relayServerId);
			discoveryDetails.setsTomcatPort(tomcatPort);
			discoveryDetails.setsPort1(port1);
			discoveryDetails.setsPort2(port2);
			discoveryDetails.setsPort3(port3);
			discoveryDetails.setsPort4(port4);
			discoveryDetails.setsPort5(port5);
			discoveryDetails.setsRURLTomcatPort(rurlTomcatPort);
			discoveryDetails.setsRAddress(rurlAddress);
			discoveryDetails.setsDeviceID(boxID);
			return Client.callServer(portalAuthUrl, PORTAL_SERVICE_NAME, DEVICE_DISCOVERY_CLASSNAME, "POST", "setconnecturl", null, discoveryDetails, getJwtToken(macAddress, boxID));
		}
		catch(Exception ex)
		{
			PALogger.ERROR(ex);
			throw ex;
		}
	}

	/**
	 *  This method return internet router ip 
	 * @param authToken
	 * @return
	 * @throws Exception 
	 */
	public String getInternetRouterIP(String macAddress, String deviceId) throws Exception
	{
		try
		{	
			
			return Client.callServer(portalUrl, PORTAL_SERVICE_NAME, DEVICE_DISCOVERY_CLASSNAME, "GET", "routerip", null, null, getJwtToken(macAddress, deviceId));
		}
		catch(Exception ex)
		{
			PALogger.ERROR(ex);
			throw ex;
		}
	}
	/**
	 * This method update discovery details with new connect ip url.
	 * @param ipAddress
	 * @param tomcatPort
	 * @param deviceID
	 * @param deviceName
	 * @param port5
	 * @param backCallerRestPath
	 * @param authToken
	 * @return
	 * @throws Exception
	 */
	public String canConnect(String ipAddress, String tomcatPort, String macAddress,
			String deviceID, String deviceName, String port5, String backCallerRestPath) throws Exception 
	{
		try
		{
			HashMap<String, Object> deviceDetails = new HashMap<String, Object>();
			deviceDetails.put("ipAddress", ipAddress);
			deviceDetails.put("port", tomcatPort);
			deviceDetails.put(DEVICE_ID, deviceID);
			deviceDetails.put("deviceName", deviceName);
			deviceDetails.put("port5", port5);
			deviceDetails.put(BACK_CALLER_RESTPATH, backCallerRestPath);
			return Client.callServer(portalAuthUrl, PORTAL_SERVICE_NAME, DEVICE_DISCOVERY_CLASSNAME, "POST", "canconnect", null, deviceDetails, getJwtToken(macAddress, deviceID));
		}
		catch(Exception ex)
		{
			PALogger.ERROR(ex);
			throw ex;
		}
	}

	/**
	 * check if url is accessible
	 * @param externalIP
	 * @param port
	 * @param deviceId
	 * @param backCallerRestPath
	 * @param authToken
	 * @return
	 * @throws Exception
	 */
	public String checkIfURLAccessibleFromInternet(String macAddress, String externalIP,
			String port, String deviceId, String backCallerRestPath) throws Exception 
	{
		try
		{
			HashMap<String, Object> deviceDetails = new HashMap<String, Object>();
			deviceDetails.put("ipAddress", externalIP);
			deviceDetails.put("port", port);
			deviceDetails.put(DEVICE_ID, deviceId);
			deviceDetails.put(BACK_CALLER_RESTPATH, backCallerRestPath);
			return Client.callServer(portalAuthUrl, PORTAL_SERVICE_NAME, DEVICE_DISCOVERY_CLASSNAME, "POST", "checkurlaccessible", null, deviceDetails, getJwtToken(macAddress, deviceId));
		}
		catch(Exception ex)
		{
			PALogger.ERROR(ex);
			Map<String, String> param1 = new HashMap<>();
			param1.put("Status", "Failure");
			return new Gson().toJson(param1);
		}
	}

	/**
	 * Check if the product id or hostname are already registered on the listing server or not.
	 * @param productID
	 * @return : hashmap (if status is True then both ids are unique,if product id is unique, DuplicateProductID is true if some other device has already registered on listing server with the same product id, DuplicateHostName is true, if some other device has already registered on listing server with the same hostname
	 * @throws Exception
	 */
	public Map<String, String> IsProductIDUnique(String productID, String hostName) throws Exception {
		Map<Object,Object> queryParam = new HashMap<Object, Object>();
		queryParam.put("productId", productID);
		queryParam.put("hostName",hostName);
		String result = Client.callServer(portalAuthUrl, PORTAL_SERVICE_NAME, DEVICE_DISCOVERY_CLASSNAME, "GET", "checkuniqueid", queryParam, null, getJwtToken(productID, null));
		Gson gson =  new Gson();
		TypeToken<Map<String, String>> token = new TypeToken <Map<String, String>>(){};

		Map<String, String> param = gson.fromJson(result, token.getType());
		return param;
	} 

	/**
	 *  This method add details in discoveryDetails db.
	 * @param boxID
	 * @param externalIPaddress
	 * @param lanIPAddresses
	 * @param tomcatPort
	 * @param port1
	 * @param port2
	 * @param port3
	 * @param port4
	 * @param port5
	 * @param status
	 * @param relayServerID
	 * @param snetworkType
	 * @param rurlTomcatPort
	 * @param rurlAddress
	 * @param macAddress
	 * @param status2
	 * @param guid
	 * @param timestamp
	 * @param internetAddress
	 * @param email
	 * @param hostName
	 * @param swLicense
	 * @param hwConfig
	 * @param authToken
	 * @return
	 * @throws Exception
	 */
	public String publishDiscoveryDetails(String boxID,
			List<String> externalIPaddress, List<String> lanIPAddresses, String tomcatPort, String port1, String port2,
			String port3, String port4, String port5,
			String relayServerID, NetworkTypeEnum snetworkType, String rurlTomcatPort,
			String rurlAddress, String macAddress,
			int status2, String guid, long timestamp,
			String email, String hostName, String swLicense, String hwConfig) throws Exception 
	{
		try
		{
			String externalIP =  StringUtils.join(externalIPaddress, ", ");
			String lanIP =  StringUtils.join(lanIPAddresses, ", ");
			DiscoveryJarDetailsVO detailsVO = new DiscoveryJarDetailsVO();
			detailsVO.setsDeviceId(boxID);
			detailsVO.setsMACAddress(macAddress);
			detailsVO.setsIPAddress(externalIP);
			detailsVO.setsLocalIPAddress(lanIP);
			detailsVO.setsTomcatPort(tomcatPort);
			detailsVO.setsPort1(port1);
			detailsVO.setsPort2(port2);
			detailsVO.setsPort3(port3);
			detailsVO.setsPort4(port4);
			detailsVO.setsPort5(port5);
			detailsVO.setsRURLTomcatPort(rurlTomcatPort);
			detailsVO.setsRAddress(rurlAddress);
			detailsVO.setnStatus(status2);
			detailsVO.setsRelayServerID(relayServerID);
			detailsVO.setsNetworkType(snetworkType);

			ValidationInfoVO infoVO = new ValidationInfoVO();
			infoVO.setsMACAddress(macAddress);
			infoVO.setnStatus(status2);
			infoVO.setsGUID(guid);																   
			infoVO.setnTimestamp(timestamp);
			infoVO.setsInternetAddress(externalIP);
			infoVO.setEmail(email);
			infoVO.setHostName(hostName);
			infoVO.setSwLicense(swLicense);
			infoVO.setHwConfig(hwConfig);
			HashMap<String, Object> map = new HashMap<String, Object>();
			map.put(DETAILS_VO, detailsVO);
			map.put(VALIDATION_INFO_VO, infoVO);
			return Client.callServer(portalAuthUrl, PORTAL_SERVICE_NAME, DEVICE_DISCOVERY_CLASSNAME, "POST", "publish", null, map, getJwtToken(macAddress, boxID),0,180000,180000);
		}
		catch(Exception ex)
		{
			PALogger.ERROR(ex);
			throw ex;
		}

	}

	/**
	 * 
	 * @param boxID
	 * @param externalIPaddress
	 * @param lanIPAddresses
	 * @param tomcatPort
	 * @param port1
	 * @param port2
	 * @param port3
	 * @param port4
	 * @param port5
	 * @param status
	 * @param rurlTomcatPort
	 * @param rurlAddress
	 * @param isSetRURL
	 * @param status2
	 * @param guid
	 * @param timestamp
	 * @param internetAddress
	 * @param email
	 * @param hostName
	 * @param swLicense
	 * @param hwConfig
	 * @param macAddress
	 * @param authToken
	 * @return
	 * @throws Exception
	 */
	public String setupRelayDiscoveryDetails(String boxID,
			List<String> externalIPaddress, List<String> lanIPAddresses,
			String tomcatPort, String port1, String port2,
			String port3, String port4, String port5, int status,
			String rurlTomcatPort, String rurlAddress,
			String isSetRURL, int statusValidation, String guid, long timestamp,
			String internetAddress, String email, String hostName,
			String swLicense, String hwConfig, String macAddress)throws Exception
	{
		try
		{	
			String externalIP =  StringUtils.join(externalIPaddress, ", ");
			String lanIP =  StringUtils.join(lanIPAddresses, ", ");
			DiscoveryJarDetailsVO detailsVO = new DiscoveryJarDetailsVO();
			detailsVO.setsDeviceId(boxID);
			detailsVO.setsMACAddress(macAddress);
			detailsVO.setsIPAddress(externalIP);
			detailsVO.setsLocalIPAddress(lanIP);
			detailsVO.setsTomcatPort(tomcatPort);
			detailsVO.setsPort1(port1);
			detailsVO.setsPort2(port2);
			detailsVO.setsPort3(port3);
			detailsVO.setsPort4(port4);
			detailsVO.setsPort5(port5);
			detailsVO.setsRURLTomcatPort(rurlTomcatPort);
			detailsVO.setsRAddress(rurlAddress);
			detailsVO.setnStatus(status);
			detailsVO.setIsSetRURL(isSetRURL);


			ValidationInfoVO infoVO = new ValidationInfoVO();
			infoVO.setsMACAddress(macAddress);
			infoVO.setnStatus(statusValidation);
			infoVO.setsGUID(guid);																   
			infoVO.setnTimestamp(timestamp);
			infoVO.setsInternetAddress(internetAddress);
			infoVO.setEmail(email);
			infoVO.setHostName(hostName);
			infoVO.setSwLicense(swLicense);
			infoVO.setHwConfig(hwConfig);
			HashMap<String, Object> map = new HashMap<String, Object>();
			map.put(DETAILS_VO, detailsVO);
			map.put(VALIDATION_INFO_VO, infoVO);

			return Client.callServer(portalAuthUrl, PORTAL_SERVICE_NAME, DEVICE_DISCOVERY_CLASSNAME, "POST", "setuprelaydetails", null, map, getJwtToken(macAddress, boxID),0,180000,180000);
		}
		catch(Exception ex)
		{
			PALogger.ERROR(ex);
			throw ex;
		}
	}

	/**
	 * This method add device details in discoverJarDetails db.
	 * @param macAddress
	 * @param externalIPaddress
	 * @param lanIPAddresses
	 * @param tomcatPort
	 * @param port1
	 * @param port2
	 * @param port3
	 * @param port4
	 * @param port5
	 * @param status
	 * @param rurlTomcatPort
	 * @param rurlAddress
	 * @param isSetRURL
	 * @param hostName
	 * @param status2
	 * @param guid
	 * @param timeStamp
	 * @param internetAddress
	 * @param email
	 * @param swLicense
	 * @param hwConfig
	 * @param authToken
	 * @return
	 * @throws Exception
	 */
	public String setupRelayDiscoveryDetailsMACAddressParams(String macAddress,
			List<String> externalIPaddress, List<String> lanIPAddresses,
			String tomcatPort, String port1, String port2,
			String port3, String port4, String port5, int status,
			String rurlTomcatPort,  String rurlAddress,
			String isSetRURL, String hostName, int statusValidation, String guid,
			long timeStamp, String email,
			String swLicense, String hwConfig) throws Exception
	{
		try
		{
			String externalIP =  StringUtils.join(externalIPaddress, ", ");
			String lanIP =  StringUtils.join(lanIPAddresses, ", ");
			DiscoveryJarDetailsVO detailsVO = new DiscoveryJarDetailsVO();
			detailsVO.setsMACAddress(macAddress);
			detailsVO.setsIPAddress(externalIP);
			detailsVO.setsLocalIPAddress(lanIP);
			detailsVO.setsTomcatPort(tomcatPort);
			detailsVO.setsPort1(port1);
			detailsVO.setsPort2(port2);
			detailsVO.setsPort3(port3);
			detailsVO.setsPort4(port4);
			detailsVO.setsPort5(port5);
			detailsVO.setsRURLTomcatPort(rurlTomcatPort);
			detailsVO.setsRAddress(rurlAddress);
			detailsVO.setIsSetRURL(isSetRURL);
			detailsVO.setnStatus(status);

			ValidationInfoVO infoVO = new ValidationInfoVO();
			infoVO.setsMACAddress(macAddress);
			infoVO.setnStatus(statusValidation);
			infoVO.setsGUID(guid);																   
			infoVO.setnTimestamp(timeStamp);
			infoVO.setsInternetAddress(externalIP);
			infoVO.setEmail(email);
			infoVO.setHostName(hostName);
			infoVO.setSwLicense(swLicense);
			infoVO.setHwConfig(hwConfig);
			HashMap<String, Object> map = new HashMap<String, Object>();
			map.put(DETAILS_VO, detailsVO);
			map.put(VALIDATION_INFO_VO, infoVO);

			return Client.callServer(portalAuthUrl, PORTAL_SERVICE_NAME, DEVICE_DISCOVERY_CLASSNAME, "POST", "setuprelaydetailsmacaddress", null, map, getJwtToken(macAddress, null),0,180000,180000);
		}
		catch(Exception ex)
		{
			PALogger.ERROR(ex);
			throw ex;
		}
	}

	/**
	 * 
	 * @param macAddress
	 * @param boxId
	 * @param rurlTomcatPort
	 * @param isCheck
	 * @param rAddress
	 * @param backCallerRestPath
	 * @param deviceId
	 * @return
	 * @throws Exception
	 */
	public String setRURLDetails(String macAddress, String boxId, String rurlTomcatPort,
			boolean isCheck, String rAddress, String backCallerRestPath, String deviceId) throws Exception
	{
		try
		{
			HashMap<String, Object> deviceDetails = new HashMap<String, Object>();
			deviceDetails.put("RAddress", rAddress);
			deviceDetails.put("RURLTomcatPort", rurlTomcatPort);
			deviceDetails.put(DEVICE_ID, boxId);
			deviceDetails.put("isCheck", isCheck);
			deviceDetails.put(BACK_CALLER_RESTPATH, backCallerRestPath);
			return Client.callServer(portalAuthUrl, PORTAL_SERVICE_NAME, DEVICE_DISCOVERY_CLASSNAME, "PUT", "setrurldetails", null, deviceDetails, getJwtToken(macAddress, deviceId));
		}
		catch(Exception ex)
		{
			PALogger.ERROR(ex);
			throw ex;
		}
	}

	public String updateBoxStatics(HashMap<String, Object> hashMap, String deviceId, String token) throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException, IOException
	{
		try
		{
			return Client.callServer(portalUrl, PORTAL_SERVICE_NAME, "statics", "POST", deviceId, null, hashMap, token); //"bearer " + 
	
		} catch (KeyManagementException | NoSuchAlgorithmException | KeyStoreException | IOException ex) {
			PALogger.ERROR(ex);
			throw ex;
		}
	}

	/**
	 * This method delete row from discoveryJarDetails using MACAddress.
	 * @param macAddress
	 * @param authToken
	 * @return
	 * @throws Exception
	 */
	public String deleteNewDeviceDiscovery(String macAddress, String deviceId) throws Exception 
	{
		try
		{
			return Client.callServer(portalAuthUrl, PORTAL_SERVICE_NAME, DEVICE_DISCOVERY_CLASSNAME, "DELETE", macAddress, null, null, getJwtToken(macAddress, deviceId));
		}
		catch(Exception ex)
		{
			PALogger.ERROR(ex);
			throw ex;
		}
	}

	/**
	 * Gets Last Heart Beat updated time from listing server 
	 * @param boxID Id of the box whose heartbeat ticks are required 
	 * @param authToken 
	 * @return
	 * @author DB,RA
	 * @throws Exception
	 */
	public long getHeartbeatTicks(String boxID,  String authToken) throws Exception
	{
		try
		{
			if(StringFunctions.isNullOrWhitespace(boxID))
			{
				throw new Exception(INVALID_PARAMETERS);
			}
			else
			{	
				DiscoveryDetailsVO details = Client.parseResult( Client.callServer(portalAuthUrl, PORTAL_SERVICE_NAME, DEVICES, "GET", boxID+"/details/", null, boxID, BEARER + authToken), DiscoveryDetailsVO.class, "discoveryDetails");
				return details.getdHBRdate();
			}
		}
		catch(Exception ex)
		{
			PALogger.ERROR(ex);
			throw ex;
		}
	}

	/**
	 * Checks whether the specified node is part of the cluster or not from listing server 
	 * @param clusterId Id of the cluster
	 * @param nodeId Id of the node whose integration/relation is to be checked in cluster
	 * @param authToken 
	 * @return
	 * @author DB,RA
	 * @throws ServerException If server communication fails or server returns exception from call, where message may contain {@link ErrorMessage} ErrorMessage.DEVICE_NOT_FOUND or ErrorMessage.CLUSTER_NOT_FOUND or any other
	 * @throws Exception
	 */
	public void checkNodeInCluster(String clusterId, String nodeId, String authToken) throws ServerException, Exception
	{
		if(StringFunctions.isNullOrWhitespace(clusterId))
		{
			throw new Exception(INVALID_PARAMETERS);
		}
		else
		{	

			try
			{
				Client.callServer(portalAuthUrl, PORTAL_SERVICE_NAME, DEVICES, "GET", "check/" + clusterId +"/" + nodeId , null, null, BEARER + authToken);
			}
			catch(Exception ex)
			{
				PALogger.ERROR(ex);
				throw ex;
			}
		}
	}


	/**
	 * Checks whether the specified node is part of the cluster or not from listing server 
	 * @param deviceIdList Id of the cluster
	 * @param authToken 
	 * @return
	 * @author DB,RA
	 * @throws ServerException If server communication fails or server returns exception from call, where message may contain {@link ErrorMessage} ErrorMessage.DEVICE_NOT_FOUND or any other
	 * @throws Exception
	 */
	public void checkDeviceExists(ArrayList <String> deviceIdList, String authToken) throws ServerException, Exception
	{
		if(deviceIdList.isEmpty())
		{
			throw new Exception(INVALID_PARAMETERS);
		}
		else
		{	

			try
			{
				Map<Object, Object> queryParam = new HashMap<Object, Object>();
				queryParam.put("deviceids", new Gson().toJson(deviceIdList));
				Client.callServer(portalAuthUrl, PORTAL_SERVICE_NAME, DEVICES, "GET", "check/" , queryParam, null,  BEARER + authToken);

			}
			catch(Exception ex)
			{
				PALogger.ERROR(ex);
				throw ex;
			}
		}
	}

	/**
	 * Check if the product id or hostname are already registered on the listing server or not.
	 * @param productID
	 * @return : hashmap (if status is True then both ids are unique,if product id is unique, DuplicateProductID is true if some other device has already registered on listing server with the same product id, DuplicateHostName is true, if some other device has already registered on listing server with the same hostname
	 * @throws Exception
	 */
	public Map<String, Object> searchDevices(String hwPlatform, SW_PLATFORMS swPlatform, String authToken) throws Exception {
		Map<Object,Object> queryParam = new HashMap<Object, Object>();
		queryParam.put("pagesize", 1000);
		PALogger.INFO("############## searchDevices: hwPlatform: "+ hwPlatform + "swPlatform: "+ swPlatform.toString());
		ArrayList<FilterObject> filterObjects = new ArrayList<>();

		//Filter Object 1:
		FilterObject fo1 = new FilterObject();
		fo1.setFilterType(FilterType.FILTER);
		fo1.setOperator(Operator.EQUAL);
		fo1.setValueType(ValueType.List);
		fo1.setFilterkey(FilterKeysEnum.HWPlatform);
		List<String> hwList = new ArrayList<>();

		hwPlatform = getPlatformId(hwPlatform);

		hwList.add(hwPlatform);
		fo1.setValues(hwList);
		filterObjects.add(fo1);

		//Filter Object 2:
		FilterObject fo2 = new FilterObject();
		fo2.setFilterType(FilterType.FILTER);
		fo2.setOperator(Operator.EQUAL);
		fo2.setValueType(ValueType.List);
		fo2.setFilterkey(FilterKeysEnum.SWPlatform);
		List<String> swList = new ArrayList<>();
		if(swPlatform == SW_PLATFORMS.KUBERNETES){
			swList.add(String.valueOf(DeviceTypeEnum.KubernetesCluster.ordinal()));	
		}else{
			swList.add(String.valueOf(DeviceTypeEnum.DockerCompose.ordinal()));
		}

		fo2.setValues(swList);
		filterObjects.add(fo2);

		//Filter Object 3:
		FilterObject fo3 = new FilterObject();
		fo3.setFilterType(FilterType.SORT);
		fo3.setOperator(Operator.DESC);
		fo3.setValueType(ValueType.Single);
		fo3.setSortKey(SortKeysEnum.Status);
		fo3.setStartValue("");
		filterObjects.add(fo3);
		Gson gson =  new Gson();
		queryParam.put("filters", gson.toJson(filterObjects));

		int ownership = OwnershipEnum.Owner.ordinal();
		String result = Client.callServer(portalUrl, PORTAL_SERVICE_NAME, DEVICES, "GET", "searchdevice/pages/1/ownership/" + ownership, queryParam, null,   authToken); //BEARER +
		PALogger.INFO("############## searchDevices: "+ result);

		TypeToken<Map<String, Object>> token = new TypeToken <Map<String, Object>>(){};
		Map<String, Object> param = gson.fromJson(result, token.getType());
		return param;
	} 

	/**
	 * Check if the product id or hostname are already registered on the listing server or not.
	 * @param productID
	 * @return : hashmap (if status is True then both ids are unique,if product id is unique, DuplicateProductID is true if some other device has already registered on listing server with the same product id, DuplicateHostName is true, if some other device has already registered on listing server with the same hostname
	 * @throws IOException 
	 * @throws KeyStoreException 
	 * @throws NoSuchAlgorithmException 
	 * @throws KeyManagementException 
	 * @throws Exception
	 */
	public String getPlatformId(String hwPlatform) throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException, IOException {
		String platformId = "";
		PALogger.INFO("############## getPlatformId: "+ hwPlatform);
		String result = Client.callServer(portalUrl, PORTAL_SERVICE_NAME, "devapps", "GET", "platform", null, null, null);
		PALogger.INFO("############## getPlatformId result: "+ result);
		Gson gson =  new Gson();
		TypeToken<Map<String, Object>> token = new TypeToken <Map<String, Object>>(){};
		Map<String, Object> param = gson.fromJson(result, token.getType());
		String dataJson = gson.toJson(param.get(Constant.DATA));
		TypeToken<ArrayList<PlatformVO>> tokenPlatform = new TypeToken <ArrayList<PlatformVO>>(){};
		ArrayList<PlatformVO> platforms = gson.fromJson(dataJson, tokenPlatform.getType());
		for (PlatformVO platformVO : platforms) {
			if(platformVO.getPlatformActualName().equals(hwPlatform)){
				platformId = platformVO.getPlatformId();
				PALogger.INFO("getPlatformId: "+ platformId);
			}
		}
		return platformId;
	} 

	public String getSystemJwtToken(String tokenData) throws NoSuchAlgorithmException, InvalidKeySpecException, InterruptedException, ExecutionException, TimeoutException, IOException {
		return mGetJwtToken(tokenData, null, null);
	}

	public String getJwtToken(String macAddress, String deviceId) throws NoSuchAlgorithmException, InvalidKeySpecException, InterruptedException, ExecutionException, TimeoutException, IOException {
		return mGetJwtToken(macAddress, deviceId, null);
	}
	public String getJwtToken(String macAddress, String deviceId, String userId) throws NoSuchAlgorithmException, InvalidKeySpecException, InterruptedException, ExecutionException, TimeoutException, IOException {
		return mGetJwtToken(macAddress, deviceId, userId);
	}

	/**
	 * Map to put jwtTokens in memory with Expiration date
	 * Key is tokenGenerator {@linkplain JwtProvider.tokenGenerator} 
	 * Value is Entry with tokenExpiery as key and token as value
	 */
	private static Map<JwtProvider.tokenGenerator, Entry<Long, String>> jwtTokens = new HashMap<>();
	private String mGetJwtToken(String macAddress, String deviceId, String userId) throws InterruptedException, ExecutionException, TimeoutException, IOException, NoSuchAlgorithmException, InvalidKeySpecException {
		String jwtToken = "";

		//Is device is not activated generate system jwt token 
		if(StringFunctions.isNullOrWhitespace(deviceId)) {

			//Find in jwtTokens map: generate if not exists or token is older than 10 hours 
			if(jwtTokens.containsKey(JwtProvider.tokenGenerator.SYSTEM) && jwtTokens.get(JwtProvider.tokenGenerator.SYSTEM).getKey() > System.currentTimeMillis()) {
				jwtToken = jwtTokens.get(JwtProvider.tokenGenerator.SYSTEM).getValue();
			} else {

				String[] keys = Common.getSystemJwtKeys();
				JwtProvider jwtProvider = new JwtProvider();
				jwtToken = jwtProvider.createJwtRsa(JwtProvider.tokenGenerator.SYSTEM, macAddress, keys[0], userId);

				//Put token in jwtTokens map with tokenExpiery of 10 Hours
				long tokenExpiery = new DateTime().plusHours(10).toDate().getTime();
				Entry<Long, String> entry = new AbstractMap.SimpleEntry<Long, String>(tokenExpiery, jwtToken);
				jwtTokens.put(JwtProvider.tokenGenerator.SYSTEM, entry);
			}
		} else {
			String tempFolder = TempFiles.getTempFolderPath();
			try {
				//Find in jwtTokens list: generate if not exists or token is older than 10 hours 
				if(StringFunctions.isNullOrWhitespace(userId) && 
					jwtTokens.containsKey(JwtProvider.tokenGenerator.DEVICE) && 
					jwtTokens.get(JwtProvider.tokenGenerator.DEVICE).getKey() > System.currentTimeMillis()) {

					jwtToken = jwtTokens.get(JwtProvider.tokenGenerator.DEVICE).getValue();

				}else if(jwtTokens.containsKey(JwtProvider.tokenGenerator.DEVICEUSER) && 
					jwtTokens.get(JwtProvider.tokenGenerator.DEVICEUSER).getKey() > System.currentTimeMillis()) {
						
					jwtToken = jwtTokens.get(JwtProvider.tokenGenerator.DEVICEUSER).getValue();
				} else {

					String privateKeyPath = Constant.EDGE_JWT_KEYS_PATH + macAddress + "-" + Constant.PRIVATE_DER_NAME;

					String tempFilePath = tempFolder + Constant.PRIVATE_DER_NAME;

					FileEncryptionDecryption.Decrypt_File(privateKeyPath + ".enc", tempFilePath, new CredProvider(true).getEcnKey());

					JwtProvider jwtProvider = new JwtProvider();
					String privateKey = jwtProvider.readBinaryFile(tempFilePath);
					jwtToken = jwtProvider.createJwtRsa(JwtProvider.tokenGenerator.DEVICE, macAddress, privateKey, userId);

					//Put token in jwtTokens map with tokenExpiery of 10 Hours
					long tokenExpiery = new DateTime().plusHours(10).toDate().getTime();
					Entry<Long, String> entry = new AbstractMap.SimpleEntry<Long, String>(tokenExpiery, jwtToken);
					if(StringFunctions.isNullOrWhitespace(userId))
						jwtTokens.put(JwtProvider.tokenGenerator.DEVICE, entry);
					else
						jwtTokens.put(JwtProvider.tokenGenerator.DEVICEUSER, entry);
				}
			} finally {
				FileUtils.deleteQuietly(new File(tempFolder));	
			}

		}

		return Constant.JWT_BEARER + " " + jwtToken;
	}
}


/**
 * Change History :
 * PS start 
 * {
 * 		PS_1: if the current node is active device then it sending query parameter to update current active master 
 * } 
 * PS_End
 */
