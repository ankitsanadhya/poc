package com.mwp.common;

import javax.net.ssl.SSLContext;

import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;

public class ConnectionManagerBuilder {

	private static final ConnectionManagerBuilder INSTNACE = new ConnectionManagerBuilder();
	private PoolingHttpClientConnectionManager poolingHttpClientConnectionManager;
	private boolean isIntialized = false;

	private ConnectionManagerBuilder() {
	}

	public static ConnectionManagerBuilder getInstance(SSLContext sslContext){
		synchronized(INSTNACE){
			INSTNACE.initializeConnectionManager(sslContext);
		}		
		return INSTNACE;
	}

	public PoolingHttpClientConnectionManager getConnectionManager()  {
		return poolingHttpClientConnectionManager;
	}

	private void initializeConnectionManager(SSLContext sslContext) {
		if(!isIntialized){
			SSLConnectionSocketFactory sslSocketFactory = new SSLConnectionSocketFactory(sslContext, NoopHostnameVerifier.INSTANCE);

			Registry<ConnectionSocketFactory> socketFactoryRegistry = RegistryBuilder.<ConnectionSocketFactory> create().
					register("https", sslSocketFactory).
					register("http", new PlainConnectionSocketFactory()).
					build();

			poolingHttpClientConnectionManager = new PoolingHttpClientConnectionManager(socketFactoryRegistry);
			
			isIntialized = true;
		}
	}
}
