/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.mwp.common;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import com.mwp.logger.PALogger;

public class GCSSignUrl {
	// base url of google cloud storage objects
	private String BASE_GCS_URL = "https://storage.googleapis.com";

	public URL getGCSSignUrl(String filePath, String secretKey, String accessKey) throws UnsupportedEncodingException, MalformedURLException{

		// Set Url expiry to one minute from now!
		long expiryTime = setExpiryTimeInEpoch();
		// We sign the expiry time and bucket object path
		StringBuilder stringToSign = new StringBuilder().append("GET").append('\n').append('\n').append('\n').append(expiryTime).append('\n');
		stringToSign.append('/').append(GetParentPath(filePath).replace(" ", "+"));
		stringToSign.append(GetFileName(filePath));

		String signedUrl = Sign(secretKey, stringToSign.toString());
		signedUrl =  URLEncoder.encode(signedUrl, "UTF-8");

		/*
		 * The signed URL format as required by Google.
		 */
		signedUrl = BASE_GCS_URL + filePath + "?Signature=" + signedUrl + "&Expires=" + expiryTime + "&GoogleAccessId=" + accessKey;
		PALogger.INFO(signedUrl);
		URL url = new URL(signedUrl);
		return url;
	}

	// Set an expiry date for the signed url. Sets it at one minute ahead of
	// current time.
	// Represented as the epoch time (seconds since 1st January 1970)
	private long setExpiryTimeInEpoch() {
		long totalduration =  5L*1000*60*60*24 ;
		Date date= new Date(new Date().getTime() + totalduration);
		Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
		calendar.clear();
		calendar.setTime(date);
		long secondsSinceEpoch = calendar.getTimeInMillis()/1000;
		return secondsSinceEpoch;
	}


	private String GetParentPath(String virtualFilePath) 
	{
		int firstIndex = virtualFilePath.indexOf('/');
		int lastIndex = virtualFilePath.lastIndexOf('/');
		String prefix;
		if(lastIndex>firstIndex)
		{	
			prefix=virtualFilePath.substring((firstIndex+1),(lastIndex+1));	
		}
		else
			prefix="";
		return prefix;
	}

	private String GetFileName(String virtualFilePath) 
	{
		int lastIndex = virtualFilePath.lastIndexOf('/');
		if(lastIndex>0)
		{
			String filename = virtualFilePath.substring(lastIndex + 1);
			return filename;
		}
		return virtualFilePath;
	}
	/*
	 * Use SHA256withRSA to sign the request
	 */
	private String Sign(String secretKey, String stringToSign)
	{
		String	hmBytes="";
		try{
			String temp = secretKey;
			Mac sha = Mac.getInstance("HmacSHA1");
			SecretKeySpec signingKey = new SecretKeySpec(temp.getBytes(), "HmacSHA1");
			sha.init(signingKey);
			byte[] mac = sha.doFinal(stringToSign.getBytes("UTF-8"));
			byte[] encoded = org.apache.commons.codec.binary.Base64.encodeBase64(mac);  
			hmBytes= new String(encoded);
		}
		catch (Exception e) 
		{
			PALogger.ERROR(e);
		}
		return hmBytes;
	}
}
