/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */ 

package com.mwp.common;

import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;

import javax.net.ssl.SSLContext;

import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;

import com.mwp.common.constant.Constant;
import com.mwp.logger.PALogger;

/**
 * This class contains methods to allow ssl connection 
 *
 */
public class AllowSSL {

	private AllowSSL() { } 

	public static void allowAllSSL() {
		//	Do nothing
	}

	/**
	 * ************************
	 * below is code forHTTP Socket connection
	 * three methods 
	 * 		- getSSLContext
	 * 		- getClientConnectionManager
	 * 		- getClientConnection
	 * 
	 * 
	 * getSSLContext -> 
	 * 	Generates SSL context which verify the trust of the SSL certificate. 
	 *  This needs to be initialized only once. so put lock and null checks
	 * 
	 * getClientConnectionManager -> 
	 *  Generates Closeable connection pull. This has the host name verifier
	 *  of the caller. Along with SSL Socket factory for custom SSL context.  
	 *  This needs to be initialized only once. so put lock and null checks
	 *  
	 * getClientConnection -
	 *  returns the HttpClient to create requests. Although it generates closable
	 *  client(CloseableHttpClient), we are returning the HttpClient so that no one accidently kill the connection.
	 *  on closing the connection connection pull it self Closes. than we have to reinitialize the connection pool.
	 * 
	 * ************************
	 */


	private static HttpClient mGetClientConnection(int connectionTimeout, int requestTimeout, int socketTimeout, boolean useProxy) throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException {
		PALogger.TRACE("HTTP CLIENT CONNECTION parameters :" + connectionTimeout + " " + socketTimeout + " " + useProxy);
		SSLContext sslContext = SSlContextBuilder.getInstance().getSslContext();

		//Added timeouts for portal calls
		RequestConfig.Builder builder = RequestConfig.custom();
		builder =builder.setConnectTimeout(connectionTimeout);//20000
		builder = builder.setConnectionRequestTimeout(requestTimeout);//60000
		builder = builder.setSocketTimeout(socketTimeout);//20000
		HttpClientBuilder b = HttpClientBuilder.create();
		b.setDefaultRequestConfig(builder.build());
		b.setSSLContext(sslContext);

		PoolingHttpClientConnectionManager connMgr =  ConnectionManagerBuilder.getInstance(sslContext).getConnectionManager();		
		//Set max total opened connections in the pool, default is 20.
		connMgr.setMaxTotal(Constant.getMaxPoolConnections());
		//Set default max per route opened connections in the pool, default is 2.
		connMgr.setDefaultMaxPerRoute(Constant.getMaxPerRouteConnections());
		if(useProxy) {
			b.useSystemProperties();
		}

		b.setConnectionManager(connMgr);
		return b.build();
	}

	/**
	 * This method is used to get client connection 
	 * @param useProxy : true to use proxy , false to not use proxy  
	 * @return
	 * @throws KeyManagementException
	 * @throws NoSuchAlgorithmException
	 * @throws KeyStoreException
	 */
	public static HttpClient getClientConnection(boolean useProxy) throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException {
		return mGetClientConnection(20000,60000,60000,useProxy);
	}

	/**
	 * This method is used to get client connection with timeout settings
	 * @param connectionTimeout : integer connection timeout 
	 * @param requestTimeout : integer request timeout
	 * @param socketTimeout : integer socket timeout
	 * @param useProxy : true to use proxy , false to not use proxy
	 * @return
	 * @throws KeyManagementException
	 * @throws NoSuchAlgorithmException
	 * @throws KeyStoreException
	 */
	public static HttpClient getClientConnection(int connectionTimeout, int requestTimeout, int socketTimeout, boolean useProxy) throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException {
		if(connectionTimeout==0){
			connectionTimeout = 20000;
		}
		if(requestTimeout == 0){
			requestTimeout = 60000;
		}
		if(socketTimeout == 0){
			socketTimeout = 60000;
		}
		return mGetClientConnection(connectionTimeout, requestTimeout, socketTimeout, useProxy);
	}
}
