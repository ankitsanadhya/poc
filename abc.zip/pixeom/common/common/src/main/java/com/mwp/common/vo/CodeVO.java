/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */ 

package com.mwp.common.vo;

import java.util.List;

import javax.validation.constraints.Size;

import javax.validation.constraints.NotEmpty;

import com.mwp.common.ISkipObfuscation;
import com.mwp.common.enums.CodeStatusEnum;

public class CodeVO implements ISkipObfuscation 
{
	@Size(min = 3, max = 32, message = "The length of code should be between 3 to 32")
	private String code;
	
	//list of Email
	//changes according to new table CodeEmail
	private List<String> emails; 
	private String appId;
	/**
	 * No of user can access this code - PSH.
	 */
	private int maxUsage;
	@NotEmpty(message ="groupId cannot be Null.")
	private String groupId;
	private CodeStatusEnum codeStatus;
	private long createdDate;
	private long modifiedDate;
	
	public CodeVO(){}
	
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public  List<String> getEmails() {
		return emails;
	}
	public void setEmails( List<String> emails) {
		this.emails = emails;
	}
	public int getMaxUsage() {
		return maxUsage;
	}
	public void setMaxUsage(int maxUsage) {
		this.maxUsage = maxUsage;
	}
	public String getAppId() {
		return appId;
	}
	public void setAppId(String appId) {
		this.appId = appId;
	}
	public String getGroupId() {
		return groupId;
	}
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
	public CodeStatusEnum getCodeStatus() {
		return codeStatus;
	}
	public void setCodeStatus(CodeStatusEnum codeStatus) {
		this.codeStatus = codeStatus;
	}
	public long getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(long createdDate) {
		this.createdDate = createdDate;
	}
	public long getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(long modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	@Override
	public void guid() {
		// TODO Auto-generated method stub
		
	}

}
