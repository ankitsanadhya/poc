/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */ 

package com.mwp.common.vo;

import com.mwp.common.ISkipObfuscation;
import com.mwp.common.enums.ProxyServerEnum;

public class ProxyServerVO implements ISkipObfuscation
{

	private String protocol;
	private String IP;
	private int port;
	private String username;
	private String password;

	private ProxyServerEnum key;

	public String getProtocol() {
		return protocol;
	}
	public void setProtocol(String protocol) {
		this.protocol = protocol;
	}
	public String getIP() {
		return IP;
	}
	public void setIP(String iP) {
		IP = iP;
	}
	public int getPort() {
		return port;
	}
	public void setPort(int port) {
		this.port = port;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}

	public ProxyServerEnum getKey() {
		return key;
	}
	public void setKey(ProxyServerEnum key) {
		this.key = key;
	}

	public static ProxyServerVO parse(String line) {
		ProxyServerVO servervo = new ProxyServerVO();
		String[] str = line.split(" ");
		String[] proxyObj = str[1].split("=");
		ProxyServerEnum key = ProxyServerEnum.valueOf(proxyObj[0].trim().toLowerCase());
		if (ProxyServerEnum.no_proxy == key) {
			return null;
		} else {
			if (proxyObj[1].contains(proxyObj[0].trim().toLowerCase())) {
				return null;
			}

			servervo.setKey(key);
			String[] val = proxyObj[1].split(":");
			servervo.setProtocol(val[0].substring(1));// to skip "
			
			if (val.length == 4) {
				servervo.setUsername(val[1].substring(2));// to skip //
				String[] pwdandIP = val[2].split("@");
				servervo.setPassword(pwdandIP[0]);
				servervo.setIP(pwdandIP[1]);
				servervo.setPort(Integer.parseInt(val[3].substring(0, val[3].length() - 1)));
				// only protocal ip and port//export https_proxy="http://10.20.1.99:4040"
			} else if (val.length == 3) {
				servervo.setIP(val[1].substring(2));// to skip //
				servervo.setPort(Integer.parseInt(val[2].substring(0, val[2].length() - 1)));
			} else
				return null;
		}
		return servervo;
	}
	
	@Override
	public void guid() {
		// TODO Auto-generated method stub

	}


}
