/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */ 

package com.mwp.common.vo;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.mwp.common.ISkipObfuscation;

public class FunctionVersionVO implements ISkipObfuscation{

	private String functionVersionId;
	private String functionId;
	private String functionName;
	private int version;
	private String functionBody;
	@Pattern(regexp ="^[A-Za-z][A-Za-z0-9]*(?:_[A-Za-z0-9]+)*$",  message = "Entry point function name must start with a letter followed by up to 47 letters, numbers or hyphens, and cannot end with a hyphen.")
	@Size(min = 1, max = 47, message = "The length of entry point function name should be between 1 to 47")
	private String toExecute;
	private long modifiedDate;
	
	private String functionPath;

	public String getFunctionPath() {
		return functionPath;
	}

	public void setFunctionPath(String functionPath) {
		this.functionPath = functionPath;
	}

	public String getFunctionVersionId() {
		return functionVersionId;
	}
	public void setFunctionVersionId(String functionVersionId) {
		this.functionVersionId = functionVersionId;
	}
	public String getFunctionId() {
		return functionId;
	}
	public void setFunctionId(String functionId) {
		this.functionId = functionId;
	}
	public String getFunctionName() {
		return functionName;
	}
	public void setFunctionName(String functionName) {
		this.functionName = functionName;
	}
	public int getVersion() {
		return version;
	}
	public void setVersion(int version) {
		this.version = version;
	}
	public String getFunctionBody() {
		return functionBody;
	}
	public void setFunctionBody(String functionBody) {
		this.functionBody = functionBody;
	}
	public String getToExecute() {
		return toExecute;
	}
	public void setToExecute(String toExecute) {
		this.toExecute = toExecute;
	}
	public long getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(long modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	@Override
	public void guid() {
	}

}
