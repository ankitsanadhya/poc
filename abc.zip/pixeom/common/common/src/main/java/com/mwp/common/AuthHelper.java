/** 
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com) 
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL 
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC. 
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD 
 * IN STRICTEST CONFIDENCE. 
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */ 

package com.mwp.common;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.HashMap;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;

import com.google.gson.Gson;
import com.mwp.common.constant.Constant;
import com.mwp.common.enums.RoleEnum;
import com.mwp.common.vo.AuthorizationsVO;
import com.mwp.common.vo.ErrorVo;
import com.mwp.logger.PALogger;

import io.jsonwebtoken.Jwt;
import io.jsonwebtoken.impl.DefaultClaims;

/**
 * 
 * This class contains the logic of authorize a client request
 *
 */
public class AuthHelper {

	private String validAuthorizationHeaderMessage = "Please provide a valid authorization header - " ;
	
	/**
	 * This method is used to authorize client request
	 * @param token : client token 
	 * @param authServerUrl : url of authorization server 
	 * @return
	 * @throws Exception
	 */
	public String checkAuthorization(String token,String authServerUrl) throws Exception  {
		return mCheckAuthorization(token,authServerUrl);
	}

	/**
	 * This method is used to get {@link AuthorizationsVO} for a client request
	 * @param token : client token
	 * @param authServerUrl : url of authorization server 
	 * @return
	 * @throws Exception
	 */
	public AuthorizationsVO getAuthorizationsVO(String token, String authServerUrl) throws Exception  {
		return mGetAuthorizationsVO(token,authServerUrl);
	}

	/**
	 * This method is use to check headers
	 * @throws Exception
	 */
	public void checkHeaderExists() throws Exception 
	{
		mCheckHeaderExists();
	}

	public AuthorizationsVO checkJwtToken(String authorization, HttpServletResponse response) throws Exception {
		return mCheckJwtToken(authorization, response);
	}
	
	public Object checkJwtToken(String authorization) throws Exception {
		return mCheckJwtTokenObj(authorization, null);
	}

	private String mCheckAuthorization(String token,String authServerUrl) throws Exception {

		AuthorizationsVO authorizationsVO = mGetAuthorizationsVO(token, authServerUrl);
		return authorizationsVO.getUserId();

	}

	private AuthorizationsVO mGetAuthorizationsVO(String token, String authServerUrl) throws Exception {

		if(StringUtils.isEmpty(token))
			throw new Exception(Constant.UNAUTHORIZED);


		try {
			if(!token.toLowerCase().startsWith(Constant.BEARER) && !token.toLowerCase().startsWith("basic ") && !token.toLowerCase().startsWith("jwt ")){
						token = Constant.BEARER +token;
			}

			String result = Client.callServer(authServerUrl, "a.service/api", "token", "GET", "verify", null, null, token);
			return Client.parseResult(result, AuthorizationsVO.class);

		}  catch (Exception e) {
			ErrorVo err = new Gson().fromJson(e.getMessage(), ErrorVo.class);

			if(err.getCode() == HttpServletResponse.SC_INTERNAL_SERVER_ERROR) {
				throw new Exception(err.getMessage());
			} else {
				throw new Exception(Constant.UNAUTHORIZED);
			}
		}		

	}

	private void mCheckHeaderExists() throws Exception 
	{
		String stateInfoFilePath = Constant.UPDATE_STATE_FILE_PATH;

		if(new File(stateInfoFilePath).exists())
			throw new Exception(Constant.UPDATEINPROGRESS);
	}

	private AuthorizationsVO mCheckJwtToken(String authorization, HttpServletResponse response) throws Exception {
		
		Object obj  = mCheckJwtTokenObj(authorization, response);
		if(obj instanceof AuthorizationsVO)
			return (AuthorizationsVO)obj;
		
		return null;
	}
	
	private Object mCheckJwtTokenObj(String authorization, HttpServletResponse response) throws Exception {
		if(authorization.toLowerCase().startsWith(Constant.JWT_BEARER.toLowerCase())) {

			String[] authorizationArr = authorization.split("\\.");
			if(authorizationArr.length > 2) {

					String data = authorizationArr[1];
					String jwtBody = new String(Base64.getDecoder().decode(data));

					HashMap<String, String> payload = (HashMap<String, String>)new Gson().fromJson(jwtBody, HashMap.class);

					String aud = payload.get("aud");
					HashMap<String, Object> audience = (HashMap<String, Object>)new Gson().fromJson(aud, HashMap.class);

					if(audience.containsKey("tokenGenerator")) {

						Double tokenGenValue = (Double)audience.get("tokenGenerator");
						JwtProvider.tokenGenerator tokenGenerator = JwtProvider.tokenGenerator.get(tokenGenValue.intValue());

						String publicKey = "";
						String userId = null;
						switch (tokenGenerator) {
						case SYSTEM:
							String[] keys = Common.getSystemJwtKeys();
							publicKey = keys[1];
							break;
						case DEVICE:
							String tokenData = audience.get("tokenData").toString();
							if(audience.containsKey("userId"))
								userId = audience.get("userId").toString();

								String publicKeyFilePath = String.format(Constant.EDGE_JWT_PUBLIC_KEY_PATH, tokenData);
								File publicKeyFile = new File(publicKeyFilePath);
								if(publicKeyFile.exists()) { 
									publicKey = FileUtils.readFileToString(publicKeyFile,StandardCharsets.UTF_8);
								} else {
									ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED, "Please provide a valid authorization header - No public key found to verify device.", "No public key found to verify device");
									return ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
								}
							break;
						default:
							ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED, "Please provide a valid authorization header - Token generator is not valid.", "Token generator is not valid");
							return ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
						}

						AuthorizationsVO authvo = new AuthorizationsVO();
						authvo.setUserId(userId);

						if(!StringFunctions.isNullOrWhitespace(publicKey)) {
							return mParseJwtToken(authorization, publicKey, response, userId);
						}
					} else {
						ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED, "Please provide a valid authorization header - No token generator info found.", "No token generator info found");
						return ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
					}
			} else {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED, validAuthorizationHeaderMessage+ "Invalid authorization token.", "Length is invalid");
				return ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
		} else {
			ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED, validAuthorizationHeaderMessage+ "Missing authorization token.", "Bearer not found in authorization header.");
			return ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
		}
		return null;
	}


	private Object mParseJwtToken(String authorization, String publicKey, HttpServletResponse response, String userId) throws Exception {
		if(authorization.toLowerCase().startsWith(Constant.JWT_BEARER.toLowerCase())) {
			String bearer = authorization.replace(Constant.JWT_BEARER.toLowerCase(), "").trim();
			bearer = bearer.replace(Constant.JWT_BEARER.toUpperCase(), "").trim();
			bearer = bearer.replace(Constant.JWT_BEARER, "").trim();

			if(bearer != null && !"".equals(bearer)) {
				JwtProvider jwtProvider = new JwtProvider();
				Jwt jwt = jwtProvider.parseJwtRsa(bearer, publicKey);

				DefaultClaims jwtBody = (DefaultClaims)jwt.getBody();
				PALogger.INFO("JwtId " + jwtBody.getId());

				@SuppressWarnings("unchecked")
				HashMap<String, String> audience = (HashMap<String, String>)new Gson().fromJson(jwtBody.getAudience(), HashMap.class);

				String token = audience.get("token");
				String id = jwtProvider.reverseString(jwtBody.getId());

				if(token.equals(id)) {
					//Token verified successfully
					AuthorizationsVO auth = new AuthorizationsVO();
					auth.setUserId(userId);
					auth.setApplicationId(Constant.PORTAL_APPLICATION_ID);
					auth.setRole(RoleEnum.Admin);

					return auth;
				} else {
					PALogger.INFO("$$$ 6 jwt signature verification failed");
					ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_BAD_REQUEST, "Unauthorised token.", "Invalid request signature.");
					return ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
				}
			} else {
				PALogger.INFO("$$$ JWT-BEARER IS EMPTY ");
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED, "Please provide a valid authorization header - Missing authorization token.", "Jwt-Bearer can't be empty.");
				return ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
		} else {
			ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED, "Please provide a valid authorization header - Missing authorization token.", "Bearer not found in authorization header.");
			return ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
		}
	}
	
}

