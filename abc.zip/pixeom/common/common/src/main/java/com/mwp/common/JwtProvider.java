/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.common;

import java.io.File;
import java.io.IOException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;

import org.apache.commons.io.FileUtils;
import org.joda.time.DateTime;

import com.google.gson.Gson;
import com.mwp.common.constant.Constant;
import com.mwp.logger.PALogger;

import io.jsonwebtoken.Jwt;
import io.jsonwebtoken.JwtBuilder;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

public class JwtProvider {

	private static final String OPEN_SSL =  "openssl";
	private static final String JWT_TOKEN_COLON_SPACE =  "JWT-Token: ";
	private static final String HYPHEN_OUTFORM =  "-outform";
	private static Map<Integer, tokenGenerator> map = new HashMap<>();
	

	private static Jwt mparsersa(X509EncodedKeySpec keySpec, String publiceKey, String jwtToken) throws InvalidKeySpecException, NoSuchAlgorithmException {
		KeyFactory kf = KeyFactory.getInstance("RSA");
		PublicKey publicKey = kf.generatePublic(keySpec);
		return Jwts.parser().setSigningKey(publicKey).parse(jwtToken);		
	}

	public enum tokenGenerator {
		SYSTEM(0),
		DEVICE(1),
		USER(2),
		DEVICEUSER(3);


		private int value = 0;
		private tokenGenerator(int value) {
			this.value = value;
			map.put(value, this);
		}

		public int getValue() {
			return this.value;
		}

		public static tokenGenerator get(int value) {
			return map.get(value);
		}
	}

	public String createJwtRsa(tokenGenerator tokenGenerator, String tokenData, String privateKey) throws NoSuchAlgorithmException, InvalidKeySpecException {
		return mCreateJwtRsa(tokenGenerator, tokenData, privateKey, null);		
	}

	public String createJwtRsa(tokenGenerator tokenGenerator, String tokenData, String privateKey, String userId) throws NoSuchAlgorithmException, InvalidKeySpecException {
		return mCreateJwtRsa(tokenGenerator, tokenData, privateKey,userId);		
	}
	
	public Jwt parseJwtRsa(String jwtToken, String publiceKey) throws NoSuchAlgorithmException, InvalidKeySpecException {
		return mParseJwtRsa(jwtToken, publiceKey);
	}

	public String reverseString(String input) {
		return mReverseString(input);
	}

	private String mReverseString(String input) {
		char[] inp = input.toCharArray();
		int totallen = input.length() ;
		int itrCount= totallen/2;
			
		totallen--;
		
		for (int i = 0; i < itrCount; i++) {
			char temp = inp[i];
			inp[i] = inp[totallen - i];
			inp[totallen - i] = temp;
		}
		return new String(inp);
	}

	/**
	 * https://stackoverflow.com/questions/11410770/load-rsa-public-key-from-file
	 * @throws IOException 
	 * @throws TimeoutException 
	 * @throws ExecutionException 
	 * @throws InterruptedException 
	 * @throws Exception
	 */
	public String[] generatePublicPrivateKeys(String keyId, String keyPath, boolean preserveFiles) throws InterruptedException, ExecutionException, TimeoutException, IOException {
		return mGeneratePublicPrivateKeys(keyId, keyPath, preserveFiles);
	}

	public String[] generatePublicPrivateDer(String privateKeyPath, String outputPrivateDerPath, String outputPublicDerPath) throws InterruptedException, ExecutionException, TimeoutException, IOException  {
		return mGeneratePublicPrivateDer(privateKeyPath, outputPrivateDerPath, outputPublicDerPath);
	}

	public String readBinaryFile(String filePath) throws IOException {
		return mReadBinaryFile(filePath);
	}

	private String mCreateJwtRsa(tokenGenerator tokenGenerator, String tokenData, String privateKey, String userId) throws NoSuchAlgorithmException, InvalidKeySpecException  {
		String randomId = Common.getRandomId();
		String token = randomId;

		HashMap<String, Object> payloadMap = new HashMap<>();
		payloadMap.put("tokenGenerator", tokenGenerator.getValue());
		payloadMap.put("tokenData", tokenData);
		payloadMap.put("token", token);
		if(!StringFunctions.isNullOrWhitespace(userId))
			payloadMap.put("userId", userId);

		String payload = new Gson().toJson(payloadMap);

		DateTime now = new DateTime();
		// Create a JWT to authenticate this device. The device will be disconnected after the token
		// expires, and will have to reconnect with a new token. The audience field should always be set
		// to the GCP project id.
		JwtBuilder jwtBuilder = Jwts.builder()
				.setIssuedAt(now.toDate())
				.setExpiration(now.plusHours(12).toDate())
				.setAudience(payload)
				.setId(reverseString(randomId));

		byte[] keyBytes = Base64.getDecoder().decode(privateKey);
		PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(keyBytes);
		KeyFactory kf = KeyFactory.getInstance("RSA");

		PrivateKey privateRsaKey = kf.generatePrivate(spec);

		return jwtBuilder.signWith(SignatureAlgorithm.PS256 , privateRsaKey).compact();
	}

	private Jwt mParseJwtRsa(String jwtToken, String publiceKey) throws NoSuchAlgorithmException, InvalidKeySpecException{
		byte[] keyBytes = Base64.getDecoder().decode(publiceKey.trim());

		X509EncodedKeySpec keySpec = new X509EncodedKeySpec(keyBytes);



		return mparsersa(keySpec, publiceKey, jwtToken);
	}

	private String[] mGeneratePublicPrivateKeys(String keyId, String keyPath, boolean preserveFiles) throws IOException, InterruptedException, ExecutionException, TimeoutException {
		File file = new File(keyPath);
		if(!file.exists()) {
			file.mkdirs();
		}

		String privateKeyPath = keyPath + keyId + "-private.key";

		CommandExecutor commandExecutor = new CommandExecutor();

		ArrayList<String> command = new ArrayList<>();
		command.add(OPEN_SSL);
		command.add("genrsa");
		command.add("-out");
		command.add(privateKeyPath);
		command.add("4096");
		String result = commandExecutor.Execute(command);
		PALogger.INFO(JWT_TOKEN_COLON_SPACE + result);

		command.clear();
		command.add(OPEN_SSL);
		command.add("rsa");
		command.add("-in");
		command.add(privateKeyPath);
		command.add("-pubout");
		command.add(HYPHEN_OUTFORM);
		command.add("DER");
		command.add("-out");
		command.add(keyPath + keyId + "-" + Constant.PUBLIC_DER_NAME);
		String result2 = commandExecutor.Execute(command);
		PALogger.INFO(JWT_TOKEN_COLON_SPACE + result2);

		command.clear();
		command.add(OPEN_SSL);
		command.add("pkcs8");
		command.add("-topk8");
		command.add("-inform");
		command.add("PEM");
		command.add(HYPHEN_OUTFORM);
		command.add("DER");
		command.add("-in");
		command.add(privateKeyPath);
		command.add("-nocrypt");
		command.add("-out");
		command.add(keyPath + keyId + "-" + Constant.PRIVATE_DER_NAME);
		String result3 = commandExecutor.Execute(command);
		PALogger.INFO(JWT_TOKEN_COLON_SPACE + result3);

		String[] keys = new String[2];

			FileUtils.deleteQuietly(new File(privateKeyPath));

		keys[0] = readBinaryFile(keyPath + keyId + "-" + Constant.PRIVATE_DER_NAME);
		keys[1] = readBinaryFile(keyPath + keyId + "-" + Constant.PUBLIC_DER_NAME);

		if(!preserveFiles) {
			FileUtils.deleteQuietly(file);
		}

		return keys;
	}

	private String[] mGeneratePublicPrivateDer(String privateKeyPath, String outputPrivateDerPath, String outputPublicDerPath) throws InterruptedException, ExecutionException, TimeoutException, IOException {

		CommandExecutor commandExecutor = new CommandExecutor();

		ArrayList<String> command = new ArrayList<>();

		command.add(OPEN_SSL);
		command.add("rsa");
		command.add("-in");
		command.add(privateKeyPath);
		command.add("-pubout");
		command.add(HYPHEN_OUTFORM);
		command.add("DER");
		command.add("-out");
		command.add(outputPublicDerPath);
		String result2 = commandExecutor.Execute(command);
		PALogger.INFO(JWT_TOKEN_COLON_SPACE + result2);

		command.clear();
		command.add(OPEN_SSL);
		command.add("pkcs8");
		command.add("-topk8");
		command.add("-inform");
		command.add("PEM");
		command.add(HYPHEN_OUTFORM);
		command.add("DER");
		command.add("-in");
		command.add(privateKeyPath);
		command.add("-nocrypt");
		command.add("-out");
		command.add(outputPrivateDerPath);
		String result3 = commandExecutor.Execute(command);
		PALogger.INFO(JWT_TOKEN_COLON_SPACE + result3);

		String[] keys = new String[2];

		keys[0] = readBinaryFile(outputPrivateDerPath);
		keys[1] = readBinaryFile(outputPublicDerPath);

		return keys;
	}

	private String mReadBinaryFile(String filePath) throws IOException {
		File file = new File(filePath);
		return Base64.getEncoder().encodeToString(FileUtils.readFileToByteArray(file));		
	}
}