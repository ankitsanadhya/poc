package com.mwp.common.builder;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import com.mwp.common.CredProvider;
import com.mwp.common.Utils;
import com.mwp.common.vo.QueryVO;
import com.pa.crypto.StringEncryptionDecryption;

/**
 * Builder class for {@code Query} class.
 *
 */
public class SqlQueryBuilder {
	private final List<Object> parameters;
	private final StringBuilder query;
	private final String identifierQuoteString;

	public SqlQueryBuilder() {
		this.parameters = new ArrayList<>();
		this.query = new StringBuilder();
		this.identifierQuoteString = "";
	}

	public SqlQueryBuilder(final String identifierQuoteString) {
		this.parameters = new ArrayList<>();
		this.query = new StringBuilder();
		this.identifierQuoteString = identifierQuoteString;
	}

	public SqlQueryBuilder appendQuery(final String s) {
		this.query.append(s);
		return this;
	}

	public SqlQueryBuilder appendQuery(final Object o) {
		this.query.append(o);
		return this;
	}

	public SqlQueryBuilder appendQuery(final long l) {
		this.query.append("" + l);
		return this;
	}

	public SqlQueryBuilder appendIdentifier(final String identifier) {
		this.query.append(this.quoteIdentifier(identifier, identifierQuoteString));
		return this;
	}

	public SqlQueryBuilder append(final QueryVO q) {
		this.query.append(q.getSQL());
		this.parameters.addAll(q.getParameters());
		return this;
	}

	public SqlQueryBuilder addParameter(final Object o) {
		if (o instanceof List) {
			throw new IllegalArgumentException("Do not pass the List to here. You may want to use addParameters().");
		}
		if (o == null) {
			this.parameters.add("");
		} else {
			this.parameters.add(o);
		}
		return this;
	}

	public SqlQueryBuilder addParameterEncrypted(String s) {
		this.parameters.add(StringEncryptionDecryption.encrypt(s, new CredProvider().getEcnKey()));
		return this;
	}

	public SqlQueryBuilder addParameterForLike(Boolean startsWithAny, String s, Boolean endsWithAny) {

		this.parameters.add(Utils.getFormatStringForLike(startsWithAny, s, endsWithAny));
		return this;
	}

	public <T> SqlQueryBuilder addParameters(final Collection<T> o) {
		this.parameters.addAll(o);
		return this;
	}

	public QueryVO build() {
		return new QueryVO(new String(this.query), this.parameters);
	}

	public List<Object> getParameters() {
		return parameters;
	}

	public StringBuilder getQuery() {
		return query;
	}

	public SqlQueryBuilder appendQueryAndParameter(String s, Object o) {
		if (o instanceof Collection) {
			throw new IllegalArgumentException(
					"Do not pass the Collection to here. You may want to use appendQueryAndParameters().");
		}
		this.appendQuery(s);
		this.addParameter(o);
		return this;
	}

	public SqlQueryBuilder appendQueryAndParameters(String s, Collection<Object> o) {
		this.appendQuery(s);
		this.addParameters(o);
		return this;
	}

	public SqlQueryBuilder appendQueryIN(final Collection<?> objects) {
		this.appendQuery(" IN (" + objects.stream().map(it -> "?").collect(Collectors.joining(",")) + ")");
		return this;
	}

	public SqlQueryBuilder appendQueryIN(final int i) {
		StringBuilder formattedString = new StringBuilder();
		for (int j = 0; j < i; j++) {
			formattedString.append("?");
			formattedString.append(',');
		}
		formattedString.setLength(Math.max(formattedString.length() - 1, 0));
		this.appendQuery(" IN (" + formattedString.toString() + ")");

		return this;
	}

	public SqlQueryBuilder appendQueryNotIN(final int i) {
		StringBuilder formattedString = new StringBuilder();
		for (int j = 0; j < i; j++) {
			formattedString.append("?");
			formattedString.append(',');
		}
		formattedString.setLength(Math.max(formattedString.length() - 1, 0));
		this.appendQuery(" NOT IN (" + formattedString.toString() + ")");

		return this;
	}

	public SqlQueryBuilder notIn(Collection<?> objects) {
		this.appendQuery(" NOT IN (" + objects.stream().map(it -> "?").collect(Collectors.joining(",")) + ")");
		this.addParameters(objects);
		return this;
	}

	private String quoteIdentifier(final String identifier, final String identifierQuoteString) {
		return identifierQuoteString
				+ identifier.replace(identifierQuoteString, identifierQuoteString + identifierQuoteString)
				+ identifierQuoteString;
	}

}
