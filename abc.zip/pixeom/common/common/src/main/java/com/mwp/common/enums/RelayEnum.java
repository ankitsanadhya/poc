/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */ 

package com.mwp.common.enums;

import java.util.Hashtable;

public class RelayEnum {

	public enum NetworkTypeEnum {

		/*Direct WAN IP connection available*/
		 WAN(0),
		 /*DMZ*/
		 DMZ(1),
		 /*Ports are forwarded*/
		 PF(2),
		 /*Ports are forwarded but not accessible from Internet*/
		 RelayPF(3),
		 /*Router is blocking forwarded ports*/
		 RelayPFB(4),
		 // /*Router out of free ports*/
		 // RelayPFU,
		 /*Device is in nested routers*/
		 RelayNR(5),
		 /*WAN IP is not accessible from Internet*/
		 RelayWAN(6), 
		 /*LAN - No relay server available*/
		 LANNRS(7),
		 /*LAN - No relay ports available*/
		 LANNRP(8),
		 /*LAN - Could not open SSH connection*/
		 LAN(9),
		 None(10);
		
		private int num;
		NetworkTypeEnum(int n) {
			num = n;
			NetworkTypeRelayEnumList.map.put(num, this);
		}

		public int getValue() {
			return num;
		}

		public static NetworkTypeEnum GetEnum(int networkTypeRelay) {
			return NetworkTypeRelayEnumList.map.get(networkTypeRelay);
		}
	}

	static class NetworkTypeRelayEnumList {
		static Hashtable<Integer, NetworkTypeEnum> map = new Hashtable<Integer, NetworkTypeEnum>();
	}
	
	public enum DeviceStatusEnum {

		 NONE(0),
		 ENABLED(1),
		 DELETED(2),
		 DISABLED(3),
		 /*device not listing on portal*/
		 DO_NOT_ADVERTISE(4);
		
		private int num;
		DeviceStatusEnum(int n) {
			num = n;
			DeviceStatusEnumList.map.put(num, this);
		}

		public int getValue() {
			return num;
		}

		public static DeviceStatusEnum GetEnum(int networkTypeRelay) {
			return DeviceStatusEnumList.map.get(networkTypeRelay);
		}
	}

	static class DeviceStatusEnumList {
		static Hashtable<Integer, DeviceStatusEnum> map = new Hashtable<Integer, DeviceStatusEnum>();
	}
}
