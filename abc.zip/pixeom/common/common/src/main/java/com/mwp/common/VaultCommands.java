/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.mwp.common;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Random;

import javax.ws.rs.core.MediaType;

import org.apache.commons.io.FileUtils;

import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.mwp.logger.PALogger;
import com.sun.research.ws.wadl.HTTPMethods;

public class VaultCommands {

	private final String NAMESPACE = "kube-system";
	private final byte[] secretDataName = new byte[] { 100, 99, 100, 97, 55, 51, 55, 101, 45, 100, 102, 102, 101, 45, 52, 98, 51, 98, 45, 97, 54, 102, 56, 45, 98, 48, 51, 52, 102, 54, 49, 52, 97, 101, 57, 99 };
	public final String DATA_PATH = "/App_Volume/" + NAMESPACE + "/edge-vault/Data/";

	private final String KUBE_PIX_VAULT = "10.96.0.17";
	private final String KUBE_PIX_VAULT_PORT = "8200";

	private final MediaType MEDIA_TYPE = MediaType.APPLICATION_JSON_TYPE;

	private final String IP_PORT = "http://" + KUBE_PIX_VAULT + ":"+ KUBE_PIX_VAULT_PORT +"/";
	private final String SERVICE = "v1";
	private final String CLASS_SYS = "sys";
	private final String CLASS_SECRET = "secret";
	private final String CLASS_TOKEN = "auth/token";
	private final String GENERATE_ROOT_ATTEMPT = "generate-root/attempt";
	private final int connectionTimeout = 5000;
	private final int requestTimeout = 60000;
	private final int socketTimeout = 60000;
	private Random randomno = new Random();
	
	
	public void initVault(int shares, int threshold) throws Exception {
		mInitVault(shares, threshold);
	}

	public boolean isInitialized() throws Exception {
		return mIsInitialized();
	}

	public synchronized String getValue(String key) throws Exception {
		return mGetValue(key);
	}

	public static void main(String[] args) {
		try {
			VaultCommands vaultCommands = new VaultCommands();
			String value = vaultCommands.getValue(new String(new CredProvider().getM()));
			System.out.println(value);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void mInitVault(int shares, int threshold) throws Exception {

		String root_token = "";
		if(!isInitialized()) {

			Hashtable<String, Integer> payload = new Hashtable<>();
			payload.put("secret_shares", shares);
			payload.put("secret_threshold", threshold);

			String result = Client.callServer(IP_PORT, SERVICE, CLASS_SYS, HTTPMethods.PUT.toString(), "init", null, payload, getHeaders(null), MEDIA_TYPE, null, connectionTimeout, requestTimeout, socketTimeout, false);
			result = result.trim();

			Type keysType = new TypeToken<List<String>>(){
				private static final long serialVersionUID = 1L;
			}.getType();

			ArrayList<String> keys = Client.parseResult(result, keysType, "keys");
			root_token = Client.parseResult(result, String.class, "root_token");

			File dataPath = new File(DATA_PATH);
			if(!dataPath.exists()) {
				dataPath.mkdirs();
			}

			String filePath = DATA_PATH + new String(secretDataName);

			File file = new File(filePath);
			if(!file.exists()) {
				file.createNewFile();
			}

			FileUtils.writeStringToFile(file, new Gson().toJson(keys));
		} else {
			PALogger.INFO("InitVault: Already Initialized");
		}

		if(StringFunctions.isNullOrWhitespace(root_token)) {
			root_token = getToken();
		} else {
			unseal();
		}

		//Add vaules in vault
		CredProvider credProvider = new CredProvider(true);

		addValue(root_token, new String(credProvider.getR()), credProvider.getRMQPwd());
		addValue(root_token, new String(credProvider.getM()), credProvider.getMysqlPwd());
		addValue(root_token, new String(credProvider.getE()), credProvider.getEcnKey());
		addValue(root_token, new String(credProvider.getH()), credProvider.getHostPwd());
		addValue(root_token, new String(credProvider.getP()), credProvider.getPortalAppSecKey());
		addValue(root_token, new String(credProvider.getB()), credProvider.getBoxAppSecKey());
		addValue(root_token, new String(credProvider.getD()), credProvider.getDockerRegPwd());

		revokeToken(root_token);
	}

	private boolean mIsInitialized() throws Exception {
		String result = Client.callServer(IP_PORT, SERVICE, CLASS_SYS, HTTPMethods.GET.toString(), "init", null, null, getHeaders(null), MEDIA_TYPE, null, connectionTimeout, requestTimeout, socketTimeout, false);
		boolean isInitialized = Client.parseResult(result, Boolean.class, "initialized");
		return isInitialized;
	}

	private String mGetValue(String key) throws Exception {

		String root_token = getToken();

		String result = Client.callServer(IP_PORT, SERVICE, CLASS_SECRET, HTTPMethods.GET.toString(), "data/"+key, null, null, getHeaders(root_token), MEDIA_TYPE, null, connectionTimeout, requestTimeout, socketTimeout, false);

		Type dataType = new TypeToken<HashMap<String, String>>(){
			private static final long serialVersionUID = 1L;
		}.getType();

		HashMap<String, String> data = Client.parseResult(result, dataType, "data");

		revokeToken(root_token);

		return data.get("data").trim();
	}

	/******** Private for class ********/

	private HashMap<String, String> getHeaders(String token) {
		HashMap<String, String> headers = new HashMap<>();

		if(!StringFunctions.isNullOrWhitespace(token)) {
			headers.put("X-Vault-Token", token);	
		}

		return headers;
	}

	private boolean isSealed() throws Exception {
		String result = Client.callServer(IP_PORT, SERVICE, CLASS_SYS, HTTPMethods.GET.toString(), "seal-status", null, null, getHeaders(null), MEDIA_TYPE, null, connectionTimeout, requestTimeout, socketTimeout, false);

		boolean isSealed = Client.parseResult(result, Boolean.class, "sealed");

		return isSealed;
	}

	private boolean unseal() throws Exception {

		if(isSealed()) {
			ArrayList<String> keys = getSecrets();

			boolean isSealed = true;

			for (String key : keys) {
				Hashtable<String, String> body = new Hashtable<>();
				body.put("key", key);

				String result = Client.callServer(IP_PORT, SERVICE, CLASS_SYS, HTTPMethods.PUT.toString(), "unseal", null, body, getHeaders(null), MEDIA_TYPE, null, connectionTimeout, requestTimeout, socketTimeout, false);

				isSealed = Client.parseResult(result, Boolean.class, "sealed");
				if(!isSealed) {
					break;
				}
			}
			return !isSealed;
		} else {
			return true;
		}
	}

	/*private boolean seal(String token) throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException, IOException {

		String result = Client.callServer(IP_PORT, SERVICE, CLASS_SYS, HTTPMethods.PUT.toString(), "seal", null, null, getHeaders(token), MEDIA_TYPE, null, connectionTimeout, requestTimeout, socketTimeout);

		return "".equals(result);
	}*/

	private ArrayList<String> getSecrets() throws JsonSyntaxException, IOException {
		String filePath = DATA_PATH + new String(secretDataName);

		File file = new File(filePath);

		Type keysType = new TypeToken<List<String>>(){
			private static final long serialVersionUID = 1L;
		}.getType();

		ArrayList<String> keys = new Gson().fromJson(FileUtils.readFileToString(file), keysType);

		return keys;
	}

	private void revokeToken(String token) throws Exception {
		String result = Client.callServer(IP_PORT, SERVICE, CLASS_TOKEN, HTTPMethods.POST.toString(), "revoke-self", null, null, getHeaders(token), MEDIA_TYPE, null, connectionTimeout, requestTimeout, socketTimeout, false);
		if(!"".equals(result)) {
			throw new Exception(result);
		}
	}

	private String getToken() throws Exception {
		unseal();

		String resultStatus = Client.callServer(IP_PORT, SERVICE, CLASS_SYS, HTTPMethods.GET.toString(), GENERATE_ROOT_ATTEMPT, null, null, getHeaders(null), MEDIA_TYPE, null, connectionTimeout, requestTimeout, socketTimeout, false);

		boolean started = Client.parseResult(resultStatus, Boolean.class, "started");

		if(started) {
			Client.callServer(IP_PORT, SERVICE, CLASS_SYS, HTTPMethods.DELETE.toString(), GENERATE_ROOT_ATTEMPT, null, null, getHeaders(null), MEDIA_TYPE, null, connectionTimeout, requestTimeout, socketTimeout, false);
		}

		String otp = Base64.getEncoder().encodeToString(getOtp());

		Hashtable<String, String> body = new Hashtable<>();
		body.put("otp", otp);

		String result = Client.callServer(IP_PORT, SERVICE, CLASS_SYS, HTTPMethods.PUT.toString(), GENERATE_ROOT_ATTEMPT, null, body, getHeaders(null), MEDIA_TYPE, null, connectionTimeout, requestTimeout, socketTimeout, false);
		String nonce = Client.parseResult(result, String.class, "nonce");

		ArrayList<String> keys = getSecrets();
		String encoded_token = "";
		for (String key : keys) {
			body.clear();
			body.put("nonce", nonce);
			body.put("key", key);

			String resultUpdate = Client.callServer(IP_PORT, SERVICE, CLASS_SYS, HTTPMethods.PUT.toString(), "generate-root/update", null, body, getHeaders(null), MEDIA_TYPE, null, connectionTimeout, requestTimeout, socketTimeout, false);
			encoded_token = Client.parseResult(resultUpdate, String.class, "encoded_token");
			if(!"".equals(encoded_token)) {
				break;
			}
		}

		ArrayList<String> command = new ArrayList<String>();
		command.add("/bin/bash");
		command.add("-c");
		command.add("vault operator generate-root -decode="+ encoded_token +" -otp="+ otp);

		String resultCmd = new CommandExecutor().Execute(command);

		return resultCmd.trim();
	}

	private byte[] getOtp() {

		// create byte array
		byte[] nbyte = new byte[16];

		randomno.nextBytes(nbyte);

		return nbyte;
	}

	private void addValue(String token, String key, String value) throws Exception {
		HashMap<String, String> payload = new HashMap<>();
		payload.put("data", value);

		String result = Client.callServer(IP_PORT, SERVICE, CLASS_SECRET, HTTPMethods.PUT.toString(), "data/"+key, null, payload, getHeaders(token), MEDIA_TYPE, null, connectionTimeout, requestTimeout, socketTimeout, false);

		if(!"".equals(result)) {
			throw new Exception(result);
		}
	}
}