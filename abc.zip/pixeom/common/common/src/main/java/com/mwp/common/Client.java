/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */ 

package com.mwp.common;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Type;
import java.net.URLEncoder;
import java.net.UnknownHostException;
import java.rmi.ServerException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.ws.rs.core.MediaType;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpHead;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.util.EntityUtils;

import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.mwp.common.vo.ErrorVo;
import com.mwp.logger.PALogger;

/**
 * 
 * This class provides methods to perform HTTP and HTTPS requests
 *
 */	
public class Client {
	private static final String AUTHORIZATION = "Authorization";
	private static final String APPLICATION_JSON = "application/json";
	private static final String ACCEPT = "Accept";
	private static final String CONTENT_TYPE = "Content-Type"; 
	private static final String UTF8 = "UTF-8";
	private static final String ERROR = "error";
	private static final String NO_DATA = "no data";


	private static Gson gson = null;

	private Client(){

	}

	/**
	 * This method is used to get GSON object
	 * @return GSON object
	 */
	public static Gson getGson() {
		if(gson == null) {
			gson = new Gson();
		}
		return gson;
	}

	/**
	 * This method is used to make http and https requests
	 * @param ipPort : ip and port 
	 * @param serviceName : service name to which the request to made
	 * @param className : class name
	 * @param method : method name (eg GET, POST , DELETE, PUT)
	 * @param action : action
	 * @param queryParam : query parameters
	 * @param bodyParam : body parameters
	 * @param authorizationHeader : authorization headers
	 * @return
	 * @throws IOException 
	 * @throws KeyStoreException 
	 * @throws NoSuchAlgorithmException 
	 * @throws KeyManagementException 
	 */
	public static String callServer(String ipPort,String serviceName, String className, String method, String action, 
			Map<Object,Object> queryParam, Object bodyParam, String authorizationHeader) throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException, IOException {
		HashMap<String, String> headers = new HashMap<>();
		headers.put(AUTHORIZATION, authorizationHeader);
		headers.put(ACCEPT, APPLICATION_JSON);

		return callServer(ipPort, serviceName, className, method, action, queryParam, bodyParam, headers, MediaType.APPLICATION_JSON_TYPE, null,0,0,0);
	}

	/**
	 * This method is used to make http and https requests to google server
	 * @param ipPort : ip and port
	 * @param method : method name (eg GET, POST , DELETE, PUT)
	 * @param action : action 
	 * @param queryParam : query parameters
	 * @param bodyParam : body parameters
	 * @return
	 * @throws Exception
	 */
	public static String callGoogleServer(String ipPort, String method, String action, 
			Map<Object,Object> queryParam, Object bodyParam) throws Exception {
		HashMap<String, String> headers = new HashMap<>();

		return callGoogleServer(ipPort, method, action, queryParam, bodyParam, headers, MediaType.APPLICATION_JSON_TYPE, null,0,0,0);
	}

	/**
	 * This method is used to make HTTP and HTTPS requests with connectionTimeout, requestTimeout, socketTimeout settings
	 * @param ipPort : ip and port 
	 * @param serviceName : service name to which the request to made
	 * @param className : class name
	 * @param method : method name (eg GET, POST , DELETE, PUT)
	 * @param action : action
	 * @param queryParam : query parameters
	 * @param bodyParam : body parameters
	 * @param authorizationHeader : authorization headers
	 * @param connectionTimeout : connection timeout of request
	 * @param requestTimeout : request timeout of request
	 * @param socketTimeout : socket timeout of request
	 * @return
	 * @throws IOException 
	 * @throws KeyStoreException 
	 * @throws NoSuchAlgorithmException 
	 * @throws KeyManagementException 
	 */
	public static String callServer(String ipPort,String serviceName, String className, String method, String action, 
			Map<Object,Object> queryParam, Object bodyParam, String authorizationHeader,int connectionTimeout, int requestTimeout, int socketTimeout) throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException, IOException {
		HashMap<String, String> headers = new HashMap<>();
		headers.put(AUTHORIZATION, authorizationHeader);
		headers.put(ACCEPT, APPLICATION_JSON);

		return callServer(ipPort, serviceName, className, method, action, queryParam, bodyParam, headers, MediaType.APPLICATION_JSON_TYPE, null,
				connectionTimeout, requestTimeout, socketTimeout);
	}

	/**
	 * This method is used to make HTTP and HTTPS requests with media type
	 * @param ipPort : ip and port 
	 * @param serviceName : service name to which the request to made
	 * @param className : class name
	 * @param method : method name (eg GET, POST , DELETE, PUT)
	 * @param action : action
	 * @param queryParam : query parameters
	 * @param bodyParam : body parameters
	 * @param authorizationHeader : authorization headers
	 * @param mediaType : media type (eg: 'application/json')
	 * @return
	 * @throws IOException 
	 * @throws KeyStoreException 
	 * @throws NoSuchAlgorithmException 
	 * @throws KeyManagementException 
	 */
	public static String callServer(String ipPort,String serviceName, String className, String method, String action, Map<Object,Object> queryParam, Object bodyParam, String authorizationHeader, MediaType mediaType) throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException, IOException {
		HashMap<String, String> headers = new HashMap<>();
		headers.put(AUTHORIZATION, authorizationHeader);
		headers.put(ACCEPT, APPLICATION_JSON);

		return callServer(ipPort, serviceName, className, method, action, queryParam, bodyParam, headers, mediaType, null,0,0,0);
	}

	/**
	 * This method is used to make HTTP and HTTPS requests with media type
	 * @param ipPort : ip and port 
	 * @param serviceName : service name to which the request to made
	 * @param className : class name
	 * @param method : method name (eg GET, POST , DELETE, PUT)
	 * @param action : action 
	 * @param queryParam : query parameters
	 * @param bodyParam : body parameters
	 * @param authorizationHeader : authorization headers
	 * @param mediaType : media type (eg: 'application/json')
	 * @return
	 * @throws IOException 
	 * @throws KeyStoreException 
	 * @throws NoSuchAlgorithmException 
	 * @throws KeyManagementException 
	 */
	public static String callServer(String ipPort,String serviceName, String className, String method, String action, Map<Object,Object> queryParam, 
			Object bodyParam, String authorizationHeader, MediaType mediaType,boolean isProxy) throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException, IOException {
		HashMap<String, String> headers = new HashMap<>();
		headers.put(AUTHORIZATION, authorizationHeader);
		headers.put(ACCEPT, APPLICATION_JSON);

		return callServer(ipPort, serviceName, className, method, action, queryParam, bodyParam, headers, mediaType, null,0,0,0,isProxy);
	}

	/**
	 * 
	 * This method is used to make HTTP and HTTPS requests with responseHeader
	 * @param ipPort : ip and port 
	 * @param serviceName : service name to which the request to made
	 * @param className : class name
	 * @param method : method name (eg GET, POST , DELETE, PUT)
	 * @param action : action 
	 * @param queryParam : query parameters 
	 * @param bodyParam : body parameters
	 * @param authorizationHeader : authorization headers
	 * @param responseHeader : response header
	 * @return
	 * @throws IOException 
	 * @throws KeyStoreException 
	 * @throws NoSuchAlgorithmException 
	 * @throws KeyManagementException 
	 */
	public static String callServer(String ipPort,String serviceName, String className, String method, String action, Map<Object,Object> queryParam, Object bodyParam, String authorizationHeader, HashMap<String, Object> responseHeader) throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException, IOException {
		HashMap<String, String> headers = new HashMap<>();
		headers.put(AUTHORIZATION, authorizationHeader);
		headers.put(ACCEPT, APPLICATION_JSON);

		return callServer(ipPort, serviceName, className, method, action, queryParam, bodyParam, headers, null, responseHeader,0,0,0);
	}

	/**
	 * This method is used to make HTTP and HTTPS requests with mediaType, responseHeader, connectionTimeout, requestTimeout, socketTimeout settings
	 * @param ipPort : ip and port 
	 * @param serviceName : service name to which the request to made
	 * @param className : class name
	 * @param method : method name (eg GET, POST , DELETE, PUT)
	 * @param action : action
	 * @param queryParam : query parameters 
	 * @param bodyParam : body parameters
	 * @param headers : authorization headers
	 * @param mediaType : media type (eg: 'application/json')
	 * @param responseHeader : response header
	 * @param connectionTimeout : connection timeout of request
	 * @param requestTimeout : request timeout of request
	 * @param socketTimeout : socket timeout of request
	 * @return
	 * @throws IOException 
	 * @throws KeyManagementException 
	 * @throws NoSuchAlgorithmException 
	 * @throws KeyStoreException 
	 */
	public static String callServer(String ipPort,String serviceName, String className, String method, String action, 
			Map<Object,Object> queryParam, Object bodyParam, Map<String, String> headers, MediaType mediaType, 
			Map<String, Object> responseHeader, int connectionTimeout, int requestTimeout, int socketTimeout) throws IOException, KeyManagementException, NoSuchAlgorithmException, KeyStoreException {
		return callServer(ipPort, serviceName, className, method, action, queryParam, bodyParam, headers, mediaType, responseHeader, connectionTimeout, requestTimeout, socketTimeout, true);
	}

	/**
	 * Releases request and response resource
	 * @param  request
	 * @param response 
	 * */
	public static void releaseResponse(HttpRequestBase request, HttpResponse response){
		try{
			if(response != null){
				EntityUtils.consumeQuietly(response.getEntity());
			}
			if(request != null){
				request.releaseConnection();
			}
		}catch(Exception e){
			PALogger.TRACE(e);
		}
	}

	/**
	 * Function which makes a simple HEAD Http call to url being submitted 
	 * @param url
	 * @param connectionTimeout
	 * @param requestTimeout
	 * @param socketTimeout
	 * @param isProxy
	 * @return
	 * @throws IOException
	 * @throws KeyManagementException
	 * @throws NoSuchAlgorithmException
	 * @throws KeyStoreException
	 */
	public static String callHeadURI(String url,	int connectionTimeout, int requestTimeout, int socketTimeout, boolean isProxy) throws IOException, KeyManagementException, NoSuchAlgorithmException, KeyStoreException 
	{

		HttpResponse response = null;

		try {


			HttpClient client = null;
			if(url.contains("localhost")) {
				client = AllowSSL.getClientConnection(connectionTimeout, requestTimeout, socketTimeout, false);
			} else {
				client = AllowSSL.getClientConnection(connectionTimeout, requestTimeout, socketTimeout, isProxy);//ipPort must starts with http..
			}

			HttpHead head = null;
			try {
				head = new HttpHead(url);
				response = client.execute(head);
				return readResponse(response, null);

			} finally {
				//release resources acquired by request and response
				Client.releaseResponse(head, response);
				
			}

		} finally {
			response = null;
		}

	}
	public static String callServer(String ipPort,String serviceName, String className, String method, String action, 
			Map<Object,Object> queryParam, Object bodyParam, Map<String, String> headers, MediaType mediaType, 
			Map<String, Object> responseHeader, int connectionTimeout, int requestTimeout, int socketTimeout, boolean isProxy) throws IOException, KeyManagementException, NoSuchAlgorithmException, KeyStoreException {
		HttpResponse response = null;

		try {
			method = method.toUpperCase();

			String queryString = "";
			if(queryParam != null) {
				queryString = "?" + urlEncodeUTF8(queryParam);
			}

			String args = "";
			if (bodyParam != null && mediaType == MediaType.APPLICATION_JSON_TYPE) {
				if(bodyParam instanceof String){
					args = bodyParam.toString();
				}else{
					args = getGson().toJson(bodyParam);
				}
			} else if (bodyParam != null && mediaType == MediaType.MULTIPART_FORM_DATA_TYPE) {
				//Multipart form data can't be cast as string
				//This method accepts bodyParam for MULTIPART_FORM_DATA_TYPE as Hashtable<Object,Object>
				//If you want to upload image you has to pass "java.io.File" object in hash table 
			} else if (bodyParam != null && bodyParam instanceof Map)  {
				args = urlEncodeUTF8((Map<Object,Object>)bodyParam);
			} else if (bodyParam != null) {
				args = bodyParam.toString();
			}

			
			String ipCheckRegex = ".*[0-9]{1,3}.[0-9]{1,3}.[0-9]{1,3}.[0-9]{1,3}.*";
			
			Pattern pattern = Pattern.compile(ipCheckRegex);

	        Matcher matcher = pattern.matcher(ipPort);
	        boolean skipProxy = matcher.matches();
			
			HttpClient client = null;
			if(ipPort.contains("localhost") || skipProxy) {
				client = AllowSSL.getClientConnection(connectionTimeout, requestTimeout, socketTimeout, false);
			} else {
				client = AllowSSL.getClientConnection(connectionTimeout, requestTimeout, socketTimeout, isProxy);//ipPort must starts with http..
			}

			//ipPort must starts with http..			
			if((ipPort.startsWith("localhost")))
				ipPort = ("http://"+ipPort);
			else if(!ipPort.startsWith("http")){
				ipPort = "https://"+ipPort;
			}

			ipPort = ipPort.endsWith("/")?ipPort:(ipPort+"/");

			String url = ipPort + serviceName + (("".equals(className))?"":"/"+className) + (("".equals(action))?"":"/"+action) + queryString;

			PALogger.TRACE("isProxy->"  + isProxy + " url->" + url + " method->" + method);

			if("GET".equals(method)) {

				HttpGet get = null;
				try {
					get = new HttpGet(url);
					get.addHeader(ACCEPT, APPLICATION_JSON);

					for(Map.Entry<String, String> entry : headers.entrySet()) {
						get.setHeader(entry.getKey(), entry.getValue());
					}

					response = client.execute(get);

					return readResponse(response, responseHeader);

				} finally {
					//release resources acquired by request and response
					releaseResponse(get, response);

				}
			} else if ("POST".equals(method)) {

				HttpPost post = null;			
				try {
					post = new HttpPost(url);

					//If media type is MULTIPART_FORM_DATA_TYPE 
					//Each entity will be added as part in request
					//Using MultipartEntityBuilder
					if (bodyParam != null && mediaType == MediaType.MULTIPART_FORM_DATA_TYPE) {

						//Cast bodyParam as  Hashtable<Object,Object>
						HashMap<Object,Object> bodyParamMap = (HashMap<Object,Object>)bodyParam;

						MultipartEntityBuilder multipartBuilder = MultipartEntityBuilder.create();

						//loop each request param of bodyParam Object
						for (Entry<Object, Object> mapElement : bodyParamMap.entrySet()) {

							//If file; add as binary body, else add as Text body
							if(mapElement.getValue() instanceof File) {
								File fileObject = (File)mapElement.getValue();
								multipartBuilder.addBinaryBody(mapElement.getKey().toString(),fileObject, ContentType.DEFAULT_BINARY,  fileObject.getName());
							} else if(mapElement.getValue() instanceof String || mapElement.getValue() instanceof Number) {
								multipartBuilder.addTextBody(mapElement.getKey().toString(), mapElement.getValue().toString(), ContentType.TEXT_PLAIN);
							} else {
								multipartBuilder.addTextBody(mapElement.getKey().toString(), getGson().toJson(mapElement.getValue()), ContentType.APPLICATION_JSON);
							}
						}

						//Create http entity of the builder
						HttpEntity entity = multipartBuilder.build();

						//No need to set content type explicitly - each part has it's own content type assigned
						post.setEntity(entity);
					} else  {	
						post.setHeader(CONTENT_TYPE, mediaType.toString());
						if(bodyParam != null) {
							post.setEntity(new StringEntity(args, UTF8));
						}
					}

					for(Map.Entry<String, String> entry : headers.entrySet()) {
						post.setHeader(entry.getKey(), entry.getValue());
					}

					response = client.execute(post);

					return readResponse(response, responseHeader);
				} finally {
					//release resources acquired by request and response
					releaseResponse(post, response);					
				}
			} else if ("PUT".equals(method)) {

				HttpPut put = null;			
				try {
					put = new HttpPut(url);

					//If media type is MULTIPART_FORM_DATA_TYPE 
					//Each entity will be added as part in request
					//Using MultipartEntityBuilder
					if (bodyParam != null && mediaType == MediaType.MULTIPART_FORM_DATA_TYPE) {

						HashMap<Object,Object> bodyParamMap = (HashMap<Object,Object>)bodyParam;

						MultipartEntityBuilder multipartBuilder = MultipartEntityBuilder.create();

						//loop each request param of bodyParam Object
						for (Entry<Object, Object> mapElement : bodyParamMap.entrySet()) {

							//If file; add as binary body, else add as Text body
							if(mapElement.getValue() instanceof File) {
								File fileObject = (File)mapElement.getValue();
								multipartBuilder.addBinaryBody(mapElement.getKey().toString(), fileObject, ContentType.DEFAULT_BINARY, fileObject.getName());
							} else if(mapElement.getValue() instanceof String || mapElement.getValue() instanceof Number) {
								multipartBuilder.addTextBody(mapElement.getKey().toString(), mapElement.getValue().toString(), ContentType.TEXT_PLAIN);
							} else {
								multipartBuilder.addTextBody(mapElement.getKey().toString(), getGson().toJson(mapElement.getValue()), ContentType.APPLICATION_JSON);
							}
						}

						//Create http entity of the builder
						HttpEntity entity = multipartBuilder.build();

						//No need to set content type explicitly - each part has it's own content type assigned
						put.setEntity(entity);
					} else  {	
						put.setHeader(CONTENT_TYPE, mediaType.toString());
						if(bodyParam != null) {
							put.setEntity(new StringEntity(args, UTF8));
						}
					}

					for(Map.Entry<String, String> entry : headers.entrySet()) {
						put.setHeader(entry.getKey(), entry.getValue());
					}

					response = client.execute(put);
					return readResponse(response, responseHeader);
				} finally {
					//release resources acquired by request and response
					releaseResponse(put, response);				

				}
			} else if ("DELETE".equals(method)) {

				HttpDelete delete = null;
				try {
					delete = new HttpDelete(url);

					for(Map.Entry<String, String> entry : headers.entrySet()) {
						delete.setHeader(entry.getKey(), entry.getValue());
					}

					response = client.execute(delete);
					return readResponse(response, responseHeader);
				} finally {
					//release resources acquired by request and response  
					releaseResponse(delete, response);
				}
			} else {
				throw new ServerException("Invalid request method.");
			}
		}
		catch (UnknownHostException e) {
			//Suppressing the log being written - DB
			throw e;
		}
		catch (IOException | KeyManagementException | NoSuchAlgorithmException | KeyStoreException e) {
			PALogger.ERROR(e);
			throw e;
		} finally {
			response = null;
		}
	}

	private static String readResponse(HttpResponse response, Map<String, Object> responseHeader) throws IOException {
		String responseString = null;

		if(responseHeader != null) {
			responseHeader.put("Headers", response.getAllHeaders());
		}

		int code = response.getStatusLine().getStatusCode();
		if(code == 204) {
			responseString = "";
		} else if(code >= 200 && code < 300) {
			if(response.getEntity() != null) {
				//To support unicode encoding, converted entity content to byte array to preserve its charset.
				byte[] b =  EntityUtils.toByteArray(response.getEntity());
				responseString = new String(b);
			}
		}
		else {
			PALogger.TRACE("readResponse -> error data: " + code);
			if(response.getEntity() != null) {
				//To support unicode encoding, converted entity content to byte array to preserve its charset.
				byte[] b =  EntityUtils.toByteArray(response.getEntity());
				responseString = new String(b);
			} else {
				responseString = NO_DATA;
			}
			PALogger.TRACE("RESPONSE : " + responseString);
			throw new ServerException(responseString); 
		}
		return responseString;
	}

	//parsed response according to the class received in parameter
	/**
	 * This method is used to parse response of the request
	 * @param responseString : response of the request
	 * @param classOf : Class<T> to cast response
	 * @return
	 * @throws Exception
	 */
	public static <T> T parseResult(String responseString, Class<T> classOf) throws IOException {
		return parseResult(responseString, classOf, "data");
	}

	public static <T> T parseResult(String responseString, Class<T> classOf, String objectKey) throws IOException {

		if(responseString == null || NO_DATA.equals(responseString)) {
			throw new IOException(NO_DATA);
		} else {
			@SuppressWarnings("unchecked")
			HashMap<String, Object> responseMap = getGson().fromJson(responseString, HashMap.class);

			if(responseMap.containsKey(objectKey)) {

				Object dataObj =  responseMap.get(objectKey);

				String dataStr = getGson().toJson(dataObj);

				return getGson().fromJson(dataStr, classOf);

			} else if(responseMap.containsKey(ERROR)) {

				Object errorObj =  responseMap.get(ERROR);

				String errorString = getGson().toJson(errorObj);

				ErrorVo error = getGson().fromJson(errorString, ErrorVo.class);


				throw new IOException(error.getMessage()); 
			} else if(!"data".equals(objectKey)) {
				throw new IOException("Specified objectKey " + objectKey +" not found in response" );
			}
		}
		return null;
	}

	/**
	 * This method is used to parse response of the request
	 * @param responseString
	 * @param type : Type to cast response 
	 * @return
	 * @throws Exception
	 */
	public static <T> T parseResult(String responseString, Type type) throws Exception {
		return parseResult(responseString, type, "data");
	}

	/**
	 * This method is used to parse response of the request
	 * @param responseString
	 * @param type : Type to cast response 
	 * @param objectKey : key to find result in map
	 * @return
	 * @throws Exception
	 */
	public static <T> T parseResult(String responseString, Type type, String objectKey) throws Exception {

		if(responseString == null || NO_DATA.equals(responseString)) {
			throw new Exception(NO_DATA);
		} else {
			@SuppressWarnings("unchecked")
			HashMap<String, Object> responseMap = getGson().fromJson(responseString, HashMap.class);

			if(responseMap.containsKey(objectKey)) {

				Object dataObj =  responseMap.get(objectKey);

				String dataStr = getGson().toJson(dataObj);

				return getGson().fromJson(dataStr, type);

			} else if(responseMap.containsKey(ERROR)) {

				Object errorObj =  responseMap.get(ERROR);

				String errorString = getGson().toJson(errorObj);

				ErrorVo error = getGson().fromJson(errorString, ErrorVo.class);


				throw new Exception(error.getMessage()); 
			} else if(!"data".equals(objectKey)) {
				throw new Exception("Specified objectKey " + objectKey +" not found in response" );
			}
		}
		return null;
	}

	public static <T> T parseErrorVO(String responseString) throws Exception 
	{

		HashMap<String, Object> responseMap = null;
		try
		{
			responseMap = new Gson().fromJson(responseString, HashMap.class);
		}
		catch (JsonSyntaxException e) 
		{
			throw new Exception(responseString);
		}
		if(responseMap.containsKey(ERROR)) 
		{
			Object errorObj =  responseMap.get(ERROR);
			String errorString = new Gson().toJson(errorObj);
			ErrorVo error = new Gson().fromJson(errorString, ErrorVo.class);
			throw new Exception(error.getMessage());

		}
		else {
			throw new Exception(responseString);
		}

	}



	/**
	 * Encode string to UTF8 
	 * @param map : Map<?,?>
	 * @return
	 * @throws UnsupportedEncodingException
	 */
	public static String urlEncodeUTF8(Map<?,?> map) throws UnsupportedEncodingException {
		StringBuilder sb = new StringBuilder();
		for (Map.Entry<?,?> entry : map.entrySet()) {
			if (sb.length() > 0) {
				sb.append("&");
			}
			sb.append(String.format("%s=%s",
					URLEncoder.encode(entry.getKey().toString(), UTF8),
					URLEncoder.encode(entry.getValue().toString(), UTF8)
					));
		}
		return sb.toString();       
	}

	/**
	 * This method is used to make http and https requests to google server
	 * @param ipPort : ip and port 
	 * @param serviceName : service name to which the request to made
	 * @param className : class name
	 * @param method : method name
	 * @param action : action (eg GET, POST , DELETE, PUT)
	 * @param queryParam : query parameters 
	 * @param bodyParam : body parameters
	 * @param headers : authorization headers
	 * @param mediaType : media type (eg: 'application/json')
	 * @param responseHeader : response header
	 * @param connectionTimeout : connection timeout of request
	 * @param requestTimeout : request timeout of request
	 * @param socketTimeout : socket timeout of request
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public static String callGoogleServer(String ipPort, String method, String action, 
			Map<Object,Object> queryParam, Object bodyParam, HashMap<String, String> headers, MediaType mediaType, 
			HashMap<String, Object> responseHeader, int connectionTimeout, int requestTimeout, int socketTimeout) throws Exception {
		HttpResponse response = null;

		try {
			method = method.toUpperCase();

			String queryString = "";
			if(queryParam != null) {
				queryString = "?" + urlEncodeUTF8(queryParam);
			}

			String args = "";
			if (bodyParam != null && mediaType == MediaType.APPLICATION_JSON_TYPE) {
				args = getGson().toJson(bodyParam);
			} else if (bodyParam != null && mediaType == MediaType.MULTIPART_FORM_DATA_TYPE) {
				//Multipart form data can't be cast as string
				//This method accepts bodyParam for MULTIPART_FORM_DATA_TYPE as Hashtable<Object,Object>
				//If you want to upload image you has to pass "java.io.File" object in hash table 
			} else if(bodyParam instanceof Map)  {
				args = urlEncodeUTF8((Map<Object,Object>)bodyParam);
			} else if (bodyParam != null) {
				args = bodyParam.toString();
			}

			HttpClient client = AllowSSL.getClientConnection(connectionTimeout, requestTimeout, socketTimeout, false);

			String url = ipPort + (("".equals(action))?"":"/"+action) + queryString;

			if("GET".equals(method)) {

				HttpGet get = null;
				try {
					get = new HttpGet(url);
					get.addHeader(ACCEPT, APPLICATION_JSON);

					for(Map.Entry<String, String> entry : headers.entrySet()) {
						get.setHeader(entry.getKey(), entry.getValue());
					}

					response = client.execute(get);

					return readResponse(response, responseHeader);

				} finally {
					//DB -Possible leak solved. Release resources acquired by request and response
					releaseResponse(get, response);
				}
			} else if ("POST".equals(method)) {

				HttpPost post = null;
				try {
					post = new HttpPost(url);


					//If media type is MULTIPART_FORM_DATA_TYPE 
					//Each entity will be added as part in request
					//Using MultipartEntityBuilder
					if (bodyParam != null && mediaType == MediaType.MULTIPART_FORM_DATA_TYPE) {

						//Cast bodyParam as  Hashtable<Object,Object>
						HashMap<Object,Object> bodyParamMap = (HashMap<Object,Object>)bodyParam;

						MultipartEntityBuilder multipartBuilder = MultipartEntityBuilder.create();

						//loop each request param of bodyParam Object
						for (Entry<Object, Object> mapElement : bodyParamMap.entrySet()) {

							//If file; add as binary body, else add as Text body
							if(mapElement.getValue() instanceof File) {
								File fileObject = (File)mapElement.getValue();
								multipartBuilder.addBinaryBody(mapElement.getKey().toString(), fileObject, ContentType.DEFAULT_BINARY,  fileObject.getName());
							} else {
								multipartBuilder.addTextBody(mapElement.getKey().toString(), mapElement.getValue().toString(), ContentType.TEXT_PLAIN);
							}
						}

						//Create http entity of the builder
						HttpEntity entity = multipartBuilder.build();

						//No need to set content type explicitly - each part has it's own content type assigned
						post.setEntity(entity);
					} else  {	
						post.setHeader(CONTENT_TYPE, mediaType.toString());
						if(bodyParam != null) {
							post.setEntity(new StringEntity(args, UTF8));
						}
					}

					for(Map.Entry<String, String> entry : headers.entrySet()) {
						post.setHeader(entry.getKey(), entry.getValue());
					}

					response = client.execute(post);

					return readResponse(response, responseHeader);
				} finally {
					//DB -Possible leak solved. Release resources acquired by request and response
					releaseResponse(post, response);				
				}
			} else if ("PUT".equals(method)) {

				HttpPut put = null;
				try {
					put = new HttpPut(url);

					//If media type is MULTIPART_FORM_DATA_TYPE 
					//Each entity will be added as part in request
					//Using MultipartEntityBuilder
					if (bodyParam != null && mediaType == MediaType.MULTIPART_FORM_DATA_TYPE) {

						HashMap<Object,Object> bodyParamMap = (HashMap<Object,Object>)bodyParam;

						MultipartEntityBuilder multipartBuilder = MultipartEntityBuilder.create();

						//loop each request param of bodyParam Object
						for (Entry<Object, Object> mapElement : bodyParamMap.entrySet()) {
							//If file; add as binary body, else add as Text body
							if(mapElement.getValue() instanceof File) {
								File fileObject = (File)mapElement.getValue();
								multipartBuilder.addBinaryBody(mapElement.getKey().toString(), fileObject , ContentType.DEFAULT_BINARY, fileObject.getName());
							} else {
								multipartBuilder.addTextBody(mapElement.getKey().toString(), mapElement.getValue().toString(), ContentType.TEXT_PLAIN);
							}
						}

						//Create http entity of the builder
						HttpEntity entity = multipartBuilder.build();

						//No need to set content type explicitly - each part has it's own content type assigned
						put.setEntity(entity);
					} else  {	
						put.setHeader(CONTENT_TYPE, mediaType.toString());
						if(bodyParam != null) {
							put.setEntity(new StringEntity(args, UTF8));
						}
					}

					for(Map.Entry<String, String> entry : headers.entrySet()) {
						put.setHeader(entry.getKey(), entry.getValue());
					}
					
					response = client.execute(put);
					return readResponse(response, responseHeader);
				} finally {
					//DB -Possible leak solved. Release resources acquired by request and response
					releaseResponse(put, response);
				}
			} else if ("DELETE".equals(method)) {

				HttpDelete delete = null;
				try {
					delete = new HttpDelete(url);

					for(Entry<String, String> entry : headers.entrySet()) {
						delete.setHeader(entry.getKey(), entry.getValue());
					}
					

					response = client.execute(delete);
					return readResponse(response, responseHeader);
				} finally {
					//DB - Possible leak solved. Release resources acquired by request and response
					releaseResponse(delete, response);
				}
			} else {
				throw new Exception("Invalid request method.");
			}
		} catch (Exception e) {
			PALogger.ERROR(e);
			throw e;
		} finally {
			response = null;
		}
	}
}