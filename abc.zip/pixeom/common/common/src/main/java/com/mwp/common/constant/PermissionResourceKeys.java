/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.mwp.common.constant;

public class PermissionResourceKeys
{
	//*************permission*****************
	public static final String SERVER_ADD  = "Permission.SERVER_ADD";
	public static final String SERVER_EDIT = "Permission.SERVER_EDIT";
	public static final String SERVER_DELETE = "Permission.SERVER_DELETE";
	public static final String SERVER_LIST = "Permission.SERVER_LIST";

	public static final String SERVER_RULE_LIST = "Permission.SERVER_RULE_LIST";
	public static final String SERVER_RULE_ADD = "Permission.SERVER_RULE_ADD";
	public static final String SERVER_RULE_EDIT = "Permission.SERVER_RULE_EDIT";
	public static final String SERVER_RULE_DELETE = "Permission.SERVER_RULE_DELETE";

	public static final String APP_LIST = "Permission.PORTAL_ADMIN_APP_LIST";
	public static final String APP_USAGE_LIST = "Permission.PORTAL_ADMIN_APP_USAGE"; 
	public static final String APP_VERSION_LIST = "Permission.APP_VERSION_LIST";

	public static final String USER_LIST = "Permission.USER_LIST"; 
	public static final String USER_SUSPEND = "Permission.USER_SUSPEND"; 
	public static final String USER_RESUME = "Permission.USER_RESUME";
	public static final String USER_USAGE_LIST = "Permission.USER_USAGE_LIST";

	public static final String SETTINGS_LIST = "Permission.SETTINGS_LIST";
	public static final String SETTINGS_UPDATE = "Permission.SETTINGS_UPDATE";

	//SUPPORT
	public static final String SUPPORT_TOKEN_GENERATE  = "Permission.SUPPORT_TOKEN_GENERATE";
	public static final String SUPPORT_TOKEN_LIST = "Permission.SUPPORT_TOKEN_LIST";
	public static final String SUPPORT_TOKEN_DELETE = "Permission.SUPPORT_TOKEN_DELETE";

	//UPDATE_MANAGER
	public static final String UPDATE_APP_LIST = "Permission.UPDATE_APP_LIST";
	public static final String UPDATE_APP_ADD = "Permission.UPDATE_APP_ADD";
	public static final String UPDATE_APP_EDIT = "Permission.UPDATE_APP_EDIT";
	public static final String UPDATE_APP_DELETE = "Permission.UPDATE_APP_DELETE";

	public static final String UPDATE_GROUP_LIST = "Permission.UPDATE_GROUP_LIST";
	public static final String UPDATE_GROUP_ADD = "Permission.UPDATE_GROUP_ADD";
	public static final String UPDATE_GROUP_EDIT = "Permission.UPDATE_GROUP_EDIT"; 
	public static final String UPDATE_GROUP_DELETE = "Permission.UPDATE_GROUP_DELETE";

	public static final String UPDATE_GROUP_USER_LIST = "Permission.UPDATE_GROUP_USER_LIST";
	public static final String UPDATE_GROUP_USER_ADD = "Permission.UPDATE_GROUP_USER_ADD";
	public static final String UPDATE_GROUP_USER_EDIT = "Permission.UPDATE_GROUP_USER_EDIT"; 
	public static final String UPDATE_GROUP_USER_DELETE = "Permission.UPDATE_GROUP_USER_DELETE";

	public static final String UPDATE_GROUP_RELEASES_LIST = "Permission.UPDATE_GROUP_RELEASES_LIST";
	public static final String UPDATE_GROUP_RELEASES_RELEASE = "Permission.UPDATE_GROUP_RELEASES_RELEASE";

	//CO_OWNER
	public static final String APPLIANCES_LIST = "Permission.APPLIANCES_LIST";
	public static final String APPLIANCES_APP_INSTALL = "Permission.APPLIANCES_APP_INSTALL";
	public static final String APPLIANCES_APP_UNINSTALL = "Permission.APPLIANCES_APP_UNINSTALL";
	public static final String APPLIANCES_SYSTEM_UPDATE = "Permission.APPLIANCES_SYSTEM_UPDATE";
	public static final String APPLIANCES_DELETEOFFLINE = "Permission.APPLIANCES_DELETEOFFLINE";

	//Device management permission
	public static final String APPLIANCES_APP_START = "Permission.APPLIANCES_APP_START";
	public static final String APPLIANCES_APP_STOP = "Permission.APPLIANCES_APP_STOP";
	public static final String APPLIANCES_APP_RESTART = "Permission.APPLIANCES_APP_RESTART";
	
	public static final String APPLIANCES_SYSTEM_REBOOT = "Permission.APPLIANCES_SYSTEM_REBOOT";
	public static final String APPLIANCES_SYSTEM_SHUTDOWN = "Permission.APPLIANCES_SYSTEM_SHUTDOWN";
	public static final String APPLIANCES_SYSTEM_FACTORYRESET = "Permission.APPLIANCES_SYSTEM_FACTORYRESET";
	public static final String APPLIANCES_SYSTEM_RESET = "Permission.APPLIANCES_SYSTEM_RESET";

	//Developer
	public static final String APP_VERSION_CREATE = "Permission.APP_VERSION_CREATE";
	public static final String APP_VERSION_INSTALL = "Permission.APP_VERSION_INSTALL";
	public static final String APP_VERSION_PUBLISH = "Permission.APP_VERSION_PUBLISH";
	public static final String APP_VERSION_UNPUBLISH = "Permission.APP_VERSION_UNPUBLISH";
	public static final String APP_SECRET_CREATE = "Permission.APP_SECRET_CREATE";
	public static final String APP_SECRET_EDIT = "Permission.APP_SECRET_EDIT";
	public static final String APP_SECRET_DELETE = "Permission.APP_SECRET_DELETE";
	public static final String APP_SECRET_LIST = "Permission.APP_SECRET_LIST";
	
	public static final String PORTAL_PROJECTS = "Permission.PORTAL_PROJECTS";
	public static final String PORTAL_FUNCTIONS = "Permission.PORTAL_FUNCTIONS";
	public static final String PORTAL_APPLIANCES = "Permission.PORTAL_APPLIANCES";
	public static final String PORTAL_SOFTWARE = "Permission.PORTAL_SOFTWARE";
	public static final String PORTAL_DOCS = "Permission.PORTAL_DOCS";
	public static final String PORTAL_MODELS = "Permission.PORTAL_MODELS";

	public static final String APP_RESOURCES_CREATE = "Permission.APP_RESOURCES_CREATE";
	public static final String APP_RESOURCES_DELETE = "Permission.APP_RESOURCES_DELETE"; 
	public static final String APP_RESOURCES_LIST = "Permission.APP_RESOURCES_LIST";

	//box permission
	public static final String APP_UNINSTALL = "Permission.APP_UNINSTALL";
	public static final String APP_UPDATE = "Permission.APP_UPDATE";
	public static final String APP_START = "Permission.APP_START";
	public static final String APP_STOP = "Permission.APP_STOP";

	//******************roles************************

	
	public static final String CO_ADMIN  =  "Roles.PORTAL_ADMIN_CO_ADMIN";
	public static final String SUPPORT  = "Roles.PORTAL_ADMIN_SUPPORT";
	public static final String UPDATE_MANAGER  = "Roles.PORTAL_ADMIN_UPDATE_MANAGER";
	
	public static final String PROJECT_APP_DEVELOPER = "Roles.PROJECT_APP_DEVELOPER";
	public static final String PROJECT_APP_PUBLISHER = "Roles.PROJECT_APP_PUBLISHER";
	public static final String PROJECT_APP_USER = "Roles.PROJECT_APP_USER";
	public static final String PROJECT_APP_CO_OWNER = "Roles.PROJECT_APP_CO_OWNER";

	public static final String APPLIANCE_CO_ADMIN = "Roles.APPLIANCE_CO_ADMIN";
	public static final String APPLIANCE_APP_MANAGER = "Roles.APPLIANCE_APP_MANAGER";
	public static final String APPLIANCE_MANAGER = "Roles.APPLIANCE_MANAGER";
			
	public static final String PORTAL_USER = "Roles.PORTAL_USER";
	public static final String PORTAL_DEVELOPER = "Roles.PORTAL_DEVELOPER";
	public static final String PORTAL_DEVELOPER_X = "Roles.PORTAL_DEVELOPER_X";
	
	//box set
	public static final String APP_CO_ADMIN = "Roles.APP_CO_ADMIN";
	public static final String APP_USER = "Roles.APP_USER";
	public static final String APP_MANAGER = "Roles.APP_MANAGER";
	
	//*****************Permission description*********************
	public static final String SERVER_ADD_DESC  = "Permission.SERVER_ADD_DESC";
	public static final String SERVER_EDIT_DESC = "Permission.SERVER_EDIT_DESC";
	public static final String SERVER_DELETE_DESC = "Permission.SERVER_DELETE_DESC";
	public static final String SERVER_LIST_DESC = "Permission.SERVER_LIST_DESC";

	public static final String SERVER_RULE_LIST_DESC = "Permission.SERVER_RULE_LIST_DESC";
	public static final String SERVER_RULE_ADD_DESC = "Permission.SERVER_RULE_ADD_DESC";
	public static final String SERVER_RULE_EDIT_DESC = "Permission.SERVER_RULE_EDIT_DESC";
	public static final String SERVER_RULE_DELETE_DESC = "Permission.SERVER_RULE_DELETE_DESC";

	public static final String APP_LIST_DESC = "Permission.PORTAL_APPS_Desc";
	public static final String APP_USAGE_LIST_DESC= "Permission.PORTAL_ADMIN_APP_USAGE_DESC"; 
	public static final String APP_VERSION_LIST_DESC = "Permission.APP_VERSION_LIST_DESC";

	public static final String USER_LIST_DESC = "Permission.USER_LIST_DESC";
	public static final String USER_SUSPEND_DESC = "Permission.USER_SUSPEND_DESC"; 
	public static final String USER_RESUME_DESC = "Permission.USER_RESUME_DESC"; 
	public static final String USER_USAGE_LIST_DESC = "Permission.USER_USAGE_LIST_DESC";

	public static final String SETTINGS_LIST_DESC = "Permission.SETTINGS_LIST_DESC";
	public static final String SETTINGS_UPDATE_DESC = "Permission.SETTINGS_UPDATE_DESC";

	//SUPPORT
	public static final String SUPPORT_TOKEN_GENERATE_DESC  = "Permission.SUPPORT_TOKEN_GENERATE_DESC";
	public static final String SUPPORT_TOKEN_LIST_DESC = "Permission.SUPPORT_TOKEN_LIST_DESC";
	public static final String SUPPORT_TOKEN_DELETE_DESC = "Permission.SUPPORT_TOKEN_DELETE_DESC";

	//UPDATE_MANAGER
	public static final String UPDATE_APP_LIST_DESC = "Permission.UPDATE_APP_LIST_DESC";
	public static final String UPDATE_APP_ADD_DESC = "Permission.UPDATE_APP_ADD_DESC";
	public static final String UPDATE_APP_EDIT_DESC = "Permission.UPDATE_APP_EDIT_DESC";
	public static final String UPDATE_APP_DELETE_DESC= "Permission.UPDATE_APP_DELETE_DESC";

	public static final String UPDATE_GROUP_LIST_DESC = "Permission.UPDATE_GROUP_LIST_DESC";
	public static final String UPDATE_GROUP_ADD_DESC = "Permission.UPDATE_GROUP_ADD_DESC";
	public static final String UPDATE_GROUP_EDIT_DESC = "Permission.UPDATE_GROUP_EDIT_DESC"; 
	public static final String UPDATE_GROUP_DELETE_DESC = "Permission.UPDATE_GROUP_DELETE_DESC";

	public static final String UPDATE_GROUP_USER_LIST_DESC = "Permission.UPDATE_GROUP_USER_LIST_DESC";
	public static final String UPDATE_GROUP_USER_ADD_DESC = "Permission.UPDATE_GROUP_USER_ADD_DESC";
	public static final String UPDATE_GROUP_USER_EDIT_DESC = "Permission.UPDATE_GROUP_USER_EDIT_DESC";
	public static final String UPDATE_GROUP_USER_DELETE_DESC = "Permission.UPDATE_GROUP_USER_DELETE_DESC";

	public static final String UPDATE_GROUP_RELEASES_LIST_DESC = "Permission.UPDATE_GROUP_RELEASES_LIST_DESC";
	public static final String UPDATE_GROUP_RELEASES_RELEASE_DESC = "Permission.UPDATE_GROUP_RELEASES_RELEASE_DESC";

	//CO_OWNER
	public static final String APPLIANCES_LIST_DESC = "Permission.APPLIANCES_LIST_DESC";
	public static final String APPLIANCES_APP_INSTALL_DESC = "Permission.APPLIANCES_APP_INSTALL_DESC";
	public static final String APPLIANCES_APP_UNINSTALL_DESC = "Permission.APPLIANCES_APP_UNINSTALL_DESC";
	public static final String APPLIANCES_SYSTEM_UPDATE_DESC ="Permission.APPLIANCES_SYSTEM_UPDATE_DESC";
	public static final String APPLIANCES_DELETEOFFLINE_DESC = "Permission.APPLIANCES_DELETEOFFLINE_DESC";

	
	public static final String APPLIANCES_APP_START_DESC ="Permission.APPLIANCES_APP_START_DESC";
	public static final String APPLIANCES_APP_STOP_DESC ="Permission.APPLIANCES_APP_STOP_DESC";
	public static final String APPLIANCES_APP_RESTART_DESC ="Permission.APPLIANCES_APP_RESTART_DESC"; 
	public static final String APPLIANCES_SYSTEM_REBOOT_DESC ="Permission.APPLIANCES_SYSTEM_REBOOT_DESC";
	public static final String APPLIANCES_SYSTEM_SHUTDOWN_DESC ="Permission.APPLIANCES_SYSTEM_SHUTDOWN_DESC";
	public static final String APPLIANCES_SYSTEM_FACTORYRESET_DESC ="Permission.APPLIANCES_SYSTEM_FACTORYRESET_DESC";
	public static final String APPLIANCES_SYSTEM_RESET_DESC = "Permission.APPLIANCES_SYSTEM_RESET_DESC";

	//Developer
	public static final String APP_VERSION_CREATE_DESC = "Permission.APP_VERSION_CREATE_DESC";
	public static final String APP_VERSION_INSTALL_DESC = "Permission.APP_VERSION_INSTALL_DESC";
	public static final String APP_VERSION_PUBLISH_DESC= "Permission.APP_VERSION_PUBLISH_DESC";
	public static final String APP_VERSION_UNPUBLISH_DESC = "Permission.APP_VERSION_UNPUBLISH_DESC";
	public static final String APP_SECRET_CREATE_DESC = "Permission.APP_SECRET_CREATE_DESC";
	public static final String APP_SECRET_EDIT_DESC = "Permission.APP_SECRET_EDIT_DESC";
	public static final String APP_SECRET_DELETE_DESC = "Permission.APP_SECRET_DELETE_DESC";
	public static final String APP_SECRET_LIST_DESC = "Permission.APP_SECRET_LIST_DESC";
	
	public static final String PORTAL_PROJECTS_DESC = "Permission.PORTAL_PROJECTS_DESC";
	public static final String PORTAL_FUNCTIONS_DESC = "Permission.PORTAL_FUNCTIONS_DESC";
	public static final String PORTAL_APPLIANCES_DESC = "Permission.PORTAL_APPLIANCES_DESC";
	public static final String PORTAL_SOFTWARE_DESC = "Permission.PORTAL_SOFTWARE_DESC";
	public static final String PORTAL_DOCS_DESC = "Permission.PORTAL_DOCS_DESC";
	public static final String PORTAL_MODELS_DESC = "Permission.PORTAL_MODELS_DESC";

	public static final String APP_RESOURCES_CREATE_DESC = "Permission.APP_RESOURCES_CREATE";
	public static final String APP_RESOURCES_DELETE_DESC = "Permission.APP_RESOURCES_DELETE"; 
	public static final String APP_RESOURCES_LIST_DESC = "Permission.APP_RESOURCES_LIST";

	//box permission
	public static final String APP_UNINSTALL_DESC = "Permission.APP_UNINSTALL_DESC";
	public static final String APP_UPDATE_DESC = "Permission.APP_UPDATE_DESC";
	public static final String APP_START_DESC = "Permission.APP_START_DESC";
	public static final String APP_STOP_DESC = "Permission.APP_STOP_DESC";



	//***************Role Description*****************
	public static final String CO_ADMIN_DESC  = "Roles.PORTAL_ADMIN_CO_ADMIN_DESC";
	public static final String SUPPORT_DESC  = "Roles.PORTAL_ADMIN_SUPPORT_DESC";
	public static final String UPDATE_MANAGER_DESC  = "Roles.PORTAL_ADMIN_UPDATE_MANAGER_DESC";

	public static final String PROJECT_APP_DEVELOPER_DESC = "Roles.PROJECT_APP_DEVELOPER_DESC";
	public static final String PROJECT_APP_PUBLISHER_DESC = "Roles.PROJECT_APP_PUBLISHER_DESC";
	public static final String PROJECT_APP_USER_DESC = "Roles.PROJECT_APP_USER_DESC";
	public static final String PROJECT_APP_CO_OWNER_DESC = "Roles.PROJECT_APP_CO_OWNER_DESC";

	public static final String APPLIANCE_CO_ADMIN_DESC = "Roles.APPLIANCE_CO_ADMIN_DESC";
	public static final String APPLIANCE_APP_MANAGER_DESC = "Roles.APPLIANCE_APP_MANAGER_DESC";
	public static final String APPLIANCE_MANAGER_DESC = "Roles.APPLIANCE_MANAGER_DESC";
	
	public static final String PORTAL_USER_DESC = "Roles.PORTAL_USER_DESC";
	public static final String PORTAL_DEVELOPER_DESC = "Roles.PORTAL_DEVELOPER_DESC";
	public static final String PORTAL_DEVELOPER_X_DESC = "Roles.PORTAL_DEVELOPER_X_DESC";

	//box set
	public static final String APP_CO_ADMIN_DESC = "Roles.APP_CO_ADMIN_DESC";
	public static final String APP_USER_DESC = "Roles.APP_USER_DESC";
	public static final String APP_MANAGER_DESC = "Roles.APP_MANAGER_DESC";
	
	//***********************labels***********************
	
	public static final String ROLE_LABEL_KEY = "Roles.LABEL_KEY";
	public static final String ROLE_LABEL_VALUE_APP = "Roles.LABEL_VALUE_APP";
	public static final String ROLE_LABEL_VALUE_APPLIANCE = "Roles.LABEL_VALUE_APPLIANCE";
	public static final String ROLE_LABEL_VALUE_ADMIN = "Roles.LABEL_VALUE_ADMIN";
	public static final String ROLE_LABEL_VALUE_PORTAL = "Roles.LABEL_VALUE_PORTAL";
	
	public static final String PERMISSION_LABEL_KEY = "Permission.LABEL_KEY";
	public static final String PERMISSION_LABEL_VALUE_APP = "Permission.LABEL_VALUE_APP";
	public static final String PERMISSION_LABEL_VALUE_APPLIANCE = "Permission.LABEL_VALUE_APPLIANCE";
	public static final String PERMISSION_LABEL_VALUE_ADMIN = "Permission.LABEL_VALUE_ADMIN";
	public static final String PERMISSION_LABEL_VALUE_PORTAL = "Permission.LABEL_VALUE_PORTAL";

		
}
