/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */ 

package com.mwp.common.vo;

import javax.servlet.http.HttpServletResponse;

import com.mwp.common.ISkipObfuscation;
import com.mwp.common.Utils;

public class ErrorVo implements ISkipObfuscation {

	private int code;
	private String message;
	private String errorExplanation;

	/**
	 * This error object contain code, message and its explanation.
	 * @param code is integer {@link HttpServletResponse} this error code. 
	 * @param message is a string which is only shown on UI.
	 * @param errorExplanation if any other explanation.
	 */
	public ErrorVo(int code, String message, String errorExplanation) {
		this.code = code;
		this.message = Utils.capitalizeFirstLetter(message);
		this.errorExplanation = "";
	}

	/**
	 * This error object contain code, message and its explanation.
	 * @param code is integer {@link HttpServletResponse} this error code. 
	 * @param message is a string which is only shown on UI.
	 * @param errorExplanation if any other explanation.
	 */
	public ErrorVo(int code, String message, Exception error) {
		this.code = code;
		this.message = Utils.capitalizeFirstLetter(message);

		/*StringBuilder sb = new StringBuilder();
		if(error != null && error.getMessage() != null) {
			sb.append(error.getMessage());
			sb.append(ExceptionUtils.getStackTrace(error));
		}
		String errorExplanation = sb.toString();*/

		this.errorExplanation = "";
	}

	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	public String getMessage() {
		return message;
	}
	/*public void setMessage(String message) {
		this.message = message;
	}*/
	public String getErrorExplanation() {
		return errorExplanation;
	}
	public void setErrorExplanation(String errorExplanation) {
		this.errorExplanation = errorExplanation;
	}

	@Override
	public void guid() {
		// TODO Auto-generated method stub

	}
}
