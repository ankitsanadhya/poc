/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */ 

package com.mwp.common;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.nio.charset.Charset;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.mwp.logger.PALogger;

import eu.medsea.mimeutil.MimeUtil;

/**
 * 
 * This class contains utility methods
 *
 */
public class Utils {

	private final static String BYTES = "Bytes";
	/**
	 * This method is used to construct base uri from the request
	 * @param request
	 * @return base uri
	 */
	public static String constructBaseUri(HttpServletRequest request) 
	{
		String scheme  = request.getHeader("x-forwarded-protocol");
		String ipaddress  = request.getHeader("x-forwarded-server");
		String port  = request.getHeader("x-forwarded-port");
		StringBuilder sb = new StringBuilder();
		sb.append(scheme).append("://").append(ipaddress).append(":").append(port);
		return sb.toString() + "/";
	}

	/**
	 * This method is used to convert double size(removing decimal) into string array with size at the 0th position and size unit at 1st position
	 * @param size
	 * @return String[]
	 */
	public static String[] SizeConverterWithoudDecimal(double size)
	{
		String[] _return = new String[2];
		String ParameterString;
		double ReturnSize = 0;
		if(size>0L)
		{
			int unit = 1024;
			if (size < unit)
			{
				if(size>999.99)
				{
					_return[0] = "0.99";
					_return[1] = "KB";
				}
				else
				{
					_return[0] = Double.toString(size);
					_return[1] = BYTES;
				}
				return _return;
			}
			else 
			{
				int exp = (int) (Math.log(size) / Math.log(unit));
				ParameterString = ("KMGTPE").charAt(exp-1) + "B";


				ReturnSize = size / Math.pow(unit, exp);

				if(ReturnSize>999.99)
				{
					ReturnSize = 0.99;
					if(ParameterString.equals("KB"))
						ParameterString = "MB";
					else if(ParameterString.equals("MB"))
						ParameterString = "GB";
					else if(ParameterString.equals("GB"))
						ParameterString = "TB";
					else if(ParameterString.equals("TB"))
						ParameterString = "PB";
					else if(ParameterString.equals("PB"))
						ParameterString = "EB";
				}
				String s = Double.toString(ReturnSize);
				String _rsize= "";
				if(s.contains("."))
				{
					String[] val = s.split("\\.");
					_rsize = val[0];
				}
				_return[0] = _rsize;
				_return[1] = ParameterString;

				return _return;
			}
		}
		else
		{
			_return[0] = "0";
			_return[1] = "GB";
			return _return;
		}
	}

	public static String sizeConverterForYaml(long sizeBytes) {
		int unit = 1024;
		int exp = (int) (Math.log(sizeBytes) / Math.log(unit));
		char parameterString = ("kmgtpe").charAt(exp-1);
		double returnSize = sizeBytes / Math.pow(unit, exp);
		String s = Double.toString(returnSize);
		String _rsize= "";
		if(s.contains(".")) {
			String[] val = s.split("\\.");
			_rsize = val[0];
		}

		return _rsize + parameterString;
	}

	/**
	 * This method is used to convert double size into string array with size at the 0th position and size unit at 1st position
	 * @param size
	 * @return String[]
	 */

	public static String[] SizeConverter(double size)
	{
		String[] _return = new String[2];
		String ParameterString;
		double ReturnSize = 0;
		if(size>0L)
		{
			int unit = 1024;
			if (size < unit)
			{
				if(size>999.99)
				{
					_return[0] = "0.99";
					_return[1] = "KB";
				}
				else
				{
					_return[0] = Double.toString(size);
					_return[1] = BYTES;
				}
				return _return;
			}
			else 
			{
				int exp = (int) (Math.log(size) / Math.log(unit));
				ParameterString = ("KMGTPE").charAt(exp-1) + "B";


				ReturnSize = size / Math.pow(unit, exp);

				if(ReturnSize>999.99)
				{
					ReturnSize = 0.99;
					if(ParameterString.equals("KB"))
						ParameterString = "MB";
					else if(ParameterString.equals("MB"))
						ParameterString = "GB";
					else if(ParameterString.equals("GB"))
						ParameterString = "TB";
					else if(ParameterString.equals("TB"))
						ParameterString = "PB";
					else if(ParameterString.equals("PB"))
						ParameterString = "EB";
				}

				String _ReturnSize = Double.toString(ReturnSize).trim();

				if(_ReturnSize.contains(".00") || _ReturnSize.endsWith(".0"))
					_return[0] = String.format("%.0f", ReturnSize);
				else
					_return[0] = String.format("%.2f", ReturnSize);
				_return[1] = ParameterString;

				return _return;
			}
		}
		else
		{
			_return[0] = "0";
			_return[1] = "GB";
			return _return;
		}
	}

	/**
	 * This method is used to convert string size to long
	 * @param size
	 * @return size in long
	 */
	public static long SizeReverseConverter(String size)
	{	
		String[] sizeArr = size.trim().split(" ");
		if(sizeArr.length == 2) {
			return SizeReverseConverter(Double.parseDouble(sizeArr[0].trim()), sizeArr[1].trim());
		}		
		return 0;
	}

	/**
	 * This method is used to convert string size to long
	 * @param size
	 * @return size in long
	 */
	public static long SizeReverseConverterForYaml(String size)
	{
		System.out.println("SizeReverseConverterForYaml called for size " + size);
		long sizeToReturn = 0;

		if(size.contains("e") && !(size.endsWith("e") || size.endsWith("ei"))) //e to the power n
		{
			PALogger.INFO("SizeReverseConverterForYaml called case : e to the power n for" + size);

			String[] sizeArr =  size.split("e");

			if(sizeArr.length == 2) {
				sizeToReturn =  Long.parseLong(sizeArr[0]);
				sizeToReturn = sizeToReturn * Double.valueOf(Math.pow(10.0, Double.parseDouble(sizeArr[1]))).longValue();
			}
		}
		else
		{
			size = size.toLowerCase();

			if(size.endsWith("e") || size.endsWith("ei"))
			{
				sizeToReturn = Long.parseLong(size.substring(0, size.lastIndexOf('e')).trim());
				sizeToReturn =  sizeToReturn * Long.parseLong("1152921504606846976");//1024*1024*1024*1024*1024*1024
			}
			else if(size.endsWith("p") || size.endsWith("pi"))
			{
				sizeToReturn = Long.parseLong(size.substring(0, size.lastIndexOf('P')).trim());
				sizeToReturn =  sizeToReturn * Long.parseLong("1125899906842624");//1024*1024*1024*1024*1024
			}
			else if(size.endsWith("t") || size.endsWith("ti"))
			{
				sizeToReturn = Long.parseLong(size.substring(0, size.lastIndexOf('t')).trim());
				sizeToReturn =  sizeToReturn * Long.parseLong("1099511627776");//1024*1024*1024*1024
			}
			else if(size.endsWith("g") || size.endsWith("gi") || size.endsWith("gb"))
			{	
				sizeToReturn = Long.parseLong(size.substring(0, size.lastIndexOf('g')).trim());
				sizeToReturn =  sizeToReturn *  Long.parseLong("1073741824"); //1024*1024*1024
			}
			else if(size.endsWith("m") || size.endsWith("mi") || size.endsWith("mb"))
			{
				sizeToReturn = Long.parseLong(size.substring(0, size.lastIndexOf('m')).trim());
				sizeToReturn =  sizeToReturn *  Long.parseLong("1048576");//1024*1024
			}
			else if(size.endsWith("k") || size.endsWith("ki") || size.endsWith("kb"))
			{
				sizeToReturn = Long.parseLong(size.substring(0, size.lastIndexOf('K')).trim());
				sizeToReturn =  sizeToReturn * 1024;
			} 
			else//Parse directly size can be in bytes 
			{
				try {
					sizeToReturn = Long.parseLong(size);
				} catch (NumberFormatException e) { 
					//do nothing in case of NumberFormatException 
				}
			}
		}
		return sizeToReturn;
	}
	/**
	 * The method converts cpu exists in yaml file container request resource object
	 * The unit can be m or millicpu --> 1000 millicpu is equal to 1 cpu in kubernetes
	 * @param cpu_cores
	 * @return
	 */
	public static Double cpuMillisToCPUConverter(String cpu_cores)
	{
		//100m cpu, 100 millicpu, and 0.1 cpu

		Double cpuDouble;
		cpu_cores = cpu_cores.toLowerCase();
		if(cpu_cores.endsWith("m"))
		{
			cpuDouble =	Double.parseDouble(cpu_cores.substring(0,  cpu_cores.lastIndexOf('m')));
			cpuDouble = cpuDouble / 1000;
		}
		else if(cpu_cores.endsWith("millicpu"))
		{
			cpuDouble =	Double.parseDouble(cpu_cores.substring(0,  cpu_cores.lastIndexOf("millicpu")));
			cpuDouble = cpuDouble / 1000;
		}
		else
		{
			cpuDouble = Double.parseDouble(cpu_cores);
		}
		return cpuDouble;
	}

	/**
	 * This method is used to convert size to specific measurement
	 * @param size
	 * @param Measurement
	 * @return size in long
	 */
	public static long SizeReverseConverter(double size, String Measurement)
	{
		double sizeToReturn = size;
		if(Measurement.equals("EB"))
		{
			sizeToReturn =  size * Long.parseLong("1152921504606846976");//1024*1024*1024*1024*1024*1024
		}
		if(Measurement.equals("PB"))
		{
			sizeToReturn =  size * Long.parseLong("1125899906842624");//1024*1024*1024*1024*1024
		}
		if(Measurement.equals("TB"))
		{
			sizeToReturn =  size * Long.parseLong("1099511627776");//1024*1024*1024*1024
		}
		else if(Measurement.equals("GB"))
		{
			sizeToReturn =  size *  Long.parseLong("1073741824"); //1024*1024*1024
		}
		else if(Measurement.equals("MB"))
		{
			sizeToReturn =  size *  Long.parseLong("1048576");//1024*1024
		}
		else if(Measurement.equals("KB"))
		{
			sizeToReturn =  size * 1024;
		}
		else if(Measurement.equals(BYTES))
		{
			sizeToReturn =  size;
		}

		String returnsize = "0";
		try {
			returnsize = String.format("%.0f", sizeToReturn);
		} catch(Exception ex) {
			PALogger.ERROR(ex);
		}

		return Long.parseLong(returnsize);
	}
	/**
	 * This method is used to conver time to string in format of HH:MM:SS
	 * @param time
	 * @return
	 */
	public static String TimeConverter(long time)
	{
		String returnTime="";

		int hours;
		int mins;
		int secs;
		int remainder;

		hours = (int) time / 3600;		
		remainder = (int) time - hours * 3600;
		mins = remainder / 60;
		remainder = remainder - mins * 60;
		secs = remainder;
		String returnHours = "00";
		String returnMins = "00"; 
		String returnSecs = "00";

		if(String.valueOf(hours).length()==1&&hours!=0)
			returnHours = "0"+hours;
		if(String.valueOf(mins).length()==1)
			returnMins = "0"+mins;
		if(String.valueOf(secs).length()==1)
			returnSecs = "0"+secs;

		if(hours==0)
			returnTime = returnMins+":"+returnSecs;
		else
			returnTime = returnHours+":"+returnMins+":"+returnSecs;

		return returnTime;

	}

	/**
	 * This method is used to add right padding in string
	 * @param s : string to pad
	 * @param n : no of pad
	 * @return String after adding padding
	 */
	public static String padRight(String s, int n)
	{ 
		return String.format("%1$-" + n + "s", s);   
	} 

	/**
	 * This method is used to add left padding in string
	 * @param s : string to pad
	 * @param n : no of pad
	 * @return String after adding padding
	 */
	public static String padLeft(String s, int n)
	{ 
		return String.format("%1$#" + n + "s", s);   
	} 

	/**
	 * This mehtod returns server ip 
	 * @return server ip
	 * @throws SocketException
	 */
	public String getServerIp() throws SocketException
	{
		String ipadd="";
		for(int i=0;i<10;i++)
		{
			NetworkInterface ni = NetworkInterface.getByName("eth" +i+	"");


			if(ni!=null)
			{
				Enumeration<InetAddress> inetAddresses =  ni.getInetAddresses();
				while(inetAddresses.hasMoreElements()) {
					InetAddress ia = inetAddresses.nextElement();
					if(!ia.isLinkLocalAddress()) {
						ipadd= ia.getHostAddress();
					}	          
				}
			}
		}
		return ipadd;
	}

	/**
	 * This method is used to change bytes to MB
	 * @param bytes
	 * @return
	 */
	public static long ChangeBytesToMB(long bytes)
	{
		long mb = 0;
		if (bytes < 1024 * 1024) {
			mb = 0;
		} else {
			mb = (long) (bytes >> 20);
		}
		return mb;
	}

	/**
	 * This method is used to format decimal to two point 
	 * @param number
	 * @return formated number in string
	 */
	public static String DecimalFormatToTwo(double number)
	{
		if(Double.isNaN(number)) {
			return "0";
		} else {		
			DecimalFormat df = new DecimalFormat("#.##");
			String Decinumber = df.format(number);
			return Decinumber;
		}
	}

	/**
	 * This method is used to get current date time in format "EEE d MMM yyyy hh:mm:ss a"
	 * @return date in string
	 */
	public static String CurrentDateTimeWithFormat()
	{
		DateFormat dateFormat = new SimpleDateFormat("EEE d MMM yyyy hh:mm:ss a");
		Date date = new Date();

		return dateFormat.format(date).toString() ;
	}

	/**
	 * This method is used to format mysql date
	 * @param mysqlTimestamp
	 * @return formatted mysql date
	 */
	public static String FormatMysqlDate(String mysqlTimestamp)
	{

		/*
		 * Result Date Time Format :
		 * Wed, 4 Jul 2001 12:08 PM
		 * EEE, d MMM yyyy h:mm:ss a
		 * 
		 * Mysql TimeStamp
		 * 2012-10-19 04:22:01
		 */

		String dateFormatted = "";
		try
		{
			SimpleDateFormat mysqlDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

			Date dateTime = mysqlDateFormat.parse(mysqlTimestamp);

			SimpleDateFormat viewDateFormat = new SimpleDateFormat("EEE d MMM yyyy hh:mm:ss a");

			dateFormatted = viewDateFormat.format(dateTime);

		}
		catch (ParseException e)
		{
			PALogger.ERROR(e);
		}

		return dateFormatted ;
	}

	/**
	 * This method is used to get filename without extension
	 * @param fileName
	 * @return filename without extension
	 */
	public static String GetFileNameWithoutExtention(String fileName)
	{
		String[] splitFileName = null;
		if(fileName.contains("."))
		{
			splitFileName =  fileName.split("\\.");
			String newFileName = "";
			int len = splitFileName.length - 1;
			for(int i = 0; i < len; i++ ) {
				if(i > 0)
					newFileName += "."; 
				newFileName += splitFileName[i];
			}

			if(!newFileName.equals(""))
				fileName = newFileName;

		}
		return fileName;
	}

	/**
	 * This method is used to check the file is image or not
	 * @param title
	 * @return true is file is image and false if not
	 */
	public static boolean isImageFile(String title)
	{
		if(!title.contains("."))
			return false;
		else
		{
			String ext=title.substring(title.lastIndexOf('.')+1);
			if(ext.equalsIgnoreCase("bmp")||
					ext.equalsIgnoreCase("gif")||	
					ext.equalsIgnoreCase("jpeg")||
					ext.equalsIgnoreCase("png")||
					ext.equalsIgnoreCase("ico")||
					ext.equalsIgnoreCase("jpg"))
				return true;
			else
				return false;

		}
	}

	/**
	 * This mehtod is used to check for special image file (jpe,tif,dib,jfif)
	 * @param title
	 * @return true is file is special image and false if not
	 */
	public static boolean isSpecialFormatImageFile(String title)
	{
		if(!title.contains("."))
			return false;
		else
		{
			String ext=title.substring(title.lastIndexOf('.')+1);
			if(ext.equalsIgnoreCase("jpe")||
					ext.equalsIgnoreCase("tif")||	
					ext.equalsIgnoreCase("dib")||
					ext.equalsIgnoreCase("jfif"))
				return true;
			else
				return false;

		}
	}

	/**
	 * This method is used to delete temp file 
	 * @param file
	 */
	public static void DeleteTempFile(File file) {
		if(file.isDirectory()) {
			//directory is empty, then delete it
			if(file.list().length == 0) {
				FileUtils.deleteQuietly(file);
			} else {
				//list all the directory contents
				String files[] = file.list();
				for (String temp : files) {
					//construct the file structure
					if(!"Logo".equals(temp)){
						File fileDelete = new File(file, temp);
						//recursive delete
						DeleteTempFile(fileDelete);
					}
				}
				//check the directory again, if empty then delete it

				if(file.list().length==0 && !"DeviceCache".equals(file.getName())) {
					file.delete();
				}

			}
		} else {
			//if file, then delete it
			file.delete();
		}
	}

	/**
	 * This method is used to run system commands
	 * @param Command
	 * @return result of the command 
	 * @throws IOException
	 * @throws InterruptedException
	 */
	public static String doLinuxCommand(String Command) throws IOException, InterruptedException {
		String result = "";
		Runtime r = null;
		Process p = null;
		try {
			r = Runtime.getRuntime();
			p = r.exec(Command);
			try(BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream())))
			{
				String str = "";
				while ((str = br.readLine()) != null) {
					result += str;
				}
			}
		} finally {
			if(p != null){
				try {
					p.waitFor();
				} finally {
					p.destroy();
				}
			}
		}
		return result;
	}
	/**
	 * This method is used to extract tar at a specific destination 
	 * @param source
	 * @param tarFileName
	 * @param destination
	 * @throws InterruptedException 
	 * @throws IOException 
	 * @throws Exception
	 */
	public static void extarctTar(String source,String tarFileName, String destination) throws IOException, InterruptedException 
	{
		//		tar -czvf PixeomLoginService.tar.gz LoginService.jar
		//		tar -zxvf PixeomLoginService.tar.gz
		//		tar -zxvf PixeomLoginService.tar.gz -C /data/test/
		String cmd="tar -zxvf "+source+tarFileName+" -C "+destination;
		doLinuxCommand(cmd);
	}

	/**
	 * This method is used to get old version info by reading the xml 
	 * @return Hashtable<String, String>
	 * @throws Exception
	 */
	public static Hashtable<String, String> getOldVersionsMap() throws Exception{
		Hashtable<String, String> ht = new Hashtable<String, String>();
		String xmlName = "updateOld.xml";
		String downloadfilepath = "/opt/pixeom/"+ xmlName;
		Element eElement=null;
		Node nNode=null;
		NodeList nList=null;

		File fXmlFile = new File(downloadfilepath);
		if(fXmlFile.exists())
		{
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			dbFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();

			Document  doc = dBuilder.parse(fXmlFile);

			doc.getDocumentElement().normalize();

			nList = doc.getElementsByTagName("applianceInfo");
			nNode = nList.item(0);
			if (nNode.getNodeType() == Node.ELEMENT_NODE) 
			{
				eElement = (Element) nNode;

				ht.put("applianceOldVersionold", getTagValue("oldVersion", eElement));
				ht.put("applianceCurrentVersionold", getTagValue("currentVersion", eElement));
			}

			nList = doc.getElementsByTagName("pixeomInfo");
			nNode = nList.item(0);
			if (nNode.getNodeType() == Node.ELEMENT_NODE) 
			{
				eElement = (Element) nNode;
				if(eElement.getElementsByTagName("updateupgradewarVersion").item(0) == null){
					//					updateUpgradeWarVersionOld = "0.0.0.0";
					ht.put("updateUpgradeWarVersionOld", "0.0.0.0");
				} else {
					//					updateUpgradeWarVersionOld = getTagValue("updateupgradewarVersion", eElement);
					ht.put("updateUpgradeWarVersionOld", getTagValue("updateupgradewarVersion", eElement));
				}

				ht.put("loginServiceVersionOld", getTagValue("loginServiceVersion", eElement));
				ht.put("taskManagerVersionOld", getTagValue("taskManagerVersion", eElement));
				ht.put("restServiceVersionOld", getTagValue("restServiceVersion", eElement));
				ht.put("pixeomWebVersionOld", getTagValue("pixeomWebVersion", eElement));
			}

			// ===========getting appliance Update version.================
			nList = doc.getElementsByTagName("updateUpgrade");
			nNode = nList.item(0);
			if (nNode.getNodeType() == Node.ELEMENT_NODE) {
				eElement = (Element) nNode;
				ht.put("updateUpgradeVersionOld", getTagValue("version", eElement));
			}

			nList = doc.getElementsByTagName("log");
			nNode = nList.item(0);		
			eElement = (Element) nNode;	
		}

		return ht;
	}

	private static  String getTagValue(String sTag, Element eElement) {
		NodeList nlList = eElement.getElementsByTagName(sTag).item(0) .getChildNodes();
		Node nValue = (Node) nlList.item(0);
		return nValue.getNodeValue();
	}

	/**
	 * This method is used to generate random UUID 
	 * @return random uuid
	 */
	public static String randomUUID() {
		return UUID.randomUUID().toString().replaceAll("-", "");
	}

	static String format = "MMM-dd-yyyy hh:mm:ss.SSS a";

	/**
	 * This method is used to print stack trace of an exception
	 * @param ex
	 */
	public static void PrintStackTrace(Exception ex)
	{
		SimpleDateFormat dateFormat = new SimpleDateFormat(format);
		PALogger.INFO(dateFormat.format(new Date( System.currentTimeMillis())));
		PALogger.ERROR(ex);
	}

	/**
	 * This method is used to capitalize first character of a given string
	 * @param original
	 * @return string with first letter capital
	 */
	public static String capitalizeFirstLetter(String original) {
		if (original == null || original.length() == 0) {
			return original;
		}
		original = original.trim();

		if (original.length() == 0) {
			return original;
		}

		return original.substring(0, 1).toUpperCase() + original.substring(1);
	}


	/**
	 * This method is used to extract tar using tar command to a given destination
	 * @param sourcePath
	 * @param destinationPath
	 * @return output of extract command
	 * @throws Exception
	 */
	public static String extarctTar(String sourcePath, String destinationPath) throws Exception {

		/**
		 * extract tar			
		 */

		//tar -xvf 5a1e539ddbb4e.tar
		CommandExecutor commandExecutor = new CommandExecutor();
		ArrayList<String> commands = new ArrayList<String>();
		commands.add("tar");
		commands.add("-xvf");
		commands.add(sourcePath);
		commands.add("-C");
		commands.add(destinationPath);

		String output  = commandExecutor.Execute(commands);

		return output;

	}

	/**
	 * Writes a String to a file creating the file if it does not exist.
	 *
	 * @param file the file to write
	 * @param data the content to write to the file
	 * @throws IOException in case of an I/O error
	 */
	public static void write(final File file, final String data) throws IOException {
		writeStringToFile(file, data, false);
	}

	/**
	 * Writes a String to a file creating the file if it does not exist.
	 *
	 * @param file     the file to write
	 * @param data     the content to write to the file
	 * @param encoding the encoding to use, {@code null} means platform default
	 * @param append   if {@code true}, then the String will be added to the
	 *                 end of the file rather than overwriting
	 * @throws IOException in case of an I/O error
	 */
	private static void writeStringToFile(final File file, final String data, final boolean append) throws IOException {
		OutputStream out = null;
		try {
			out = openOutputStream(file, append);
			IOUtils.write(data, out, Charset.defaultCharset());
			out.close(); // don't swallow close Exception if copy completes normally
		} finally {
			IOUtils.closeQuietly(out);
		}
	}

	/**
	 * Opens a {@link FileOutputStream} for the specified file, checking and
	 * creating the parent directory if it does not exist.
	 * <p>
	 * At the end of the method either the stream will be successfully opened,
	 * or an exception will have been thrown.
	 * <p>
	 * The parent directory will be created if it does not exist.
	 * The file will be created if it does not exist.
	 * An exception is thrown if the file object exists but is a directory.
	 * An exception is thrown if the file exists but cannot be written to.
	 * An exception is thrown if the parent directory cannot be created.
	 *
	 * @param file   the file to open for output, must not be {@code null}
	 * @param append if {@code true}, then bytes will be added to the
	 *               end of the file rather than overwriting
	 * @return a new {@link FileOutputStream} for the specified file
	 * @throws IOException if the file object is a directory
	 * @throws IOException if the file cannot be written to
	 * @throws IOException if a parent directory needs creating but that fails
	 */
	private static FileOutputStream openOutputStream(final File file, final boolean append) throws IOException {
		if (file.exists()) {
			if (file.isDirectory()) {
				throw new IOException("File '" + file + "' exists but is a directory");
			}
			if (file.canWrite() == false) {
				throw new IOException("File '" + file + "' cannot be written to");
			}
		} else {
			final File parent = file.getParentFile();
			if (parent != null) {
				if (!parent.mkdirs() && !parent.isDirectory()) {
					throw new IOException("Directory '" + parent + "' could not be created");
				}
			}
		}
		return new FileOutputStream(file, append);
	}

	/**
	 * This method is used to check the file is image or not
	 * @param title
	 * @return true is file is image and false if not
	 */
	public static boolean checkImageMimeType(String imagePath)
	{
		MimeUtil.registerMimeDetector("eu.medsea.mimeutil.detector.MagicMimeMimeDetector");
		File f = new File (imagePath);
		Collection<?> mimeTypes = MimeUtil.getMimeTypes(f);
		PALogger.INFO(mimeTypes.toString());

		if(mimeTypes.contains("image/x-ms-bmp")||
				mimeTypes.contains("image/gif")||	
				mimeTypes.contains("image/jpeg")||
				mimeTypes.contains("image/png")||
				mimeTypes.contains("image/ico")||
				mimeTypes.contains("image/jpg"))
			return true;
		else
			return false;
	}
	
	/**
	 * 
	 * @param startsWithAny
	 * @param s
	 * @param endsWithAny
	 * @return
	 */
	public static String getFormatStringForLike(Boolean startsWithAny, String s, Boolean endsWithAny){
		if (startsWithAny) {
			s = '%' + s;
		}
		
		if (endsWithAny) {
			s += '%';
		}
		
		return s;
	}

}