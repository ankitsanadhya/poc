/** 
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com) 
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL 
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC. 
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD 
 * IN STRICTEST CONFIDENCE. 
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */ 

package com.mwp.common.yamlparser;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.mwp.common.ISkipObfuscation;
/*
 * contains a list of all configuration options supported by a service definition.
 * */
public class SectionVO implements ISkipObfuscation {
	
	//specify the image to start the container from. Can either be a repository/tag or a partial image ID.
	private String image;
	//Add metadata to containers using Docker labels. You can use either an array or a dictionary.
	private Object labels;

	private HashMap<String, String> parsedLabels;

	/*
	 * Logging configuration for the service.
	 * The driver name specifies a logging driver for the service�s containers, as with the --log-driver option for docker run.
	 * The default value is json-file.
			driver: "json-file"
			driver: "syslog"
			driver: "none"
		Only the json-file driver makes the logs available directly from docker-compose up and docker-compose logs. Using any other driver will not print any logs.
		Specify logging options for the logging driver with the options key, as with the --log-opt option for docker run.
		Logging options are key-value pairs.
	 */
	private LoggerVO logging;

	/*
	 *  Expose ports. Either specify both ports (HOST:CONTAINER), or just the container port (a random host port will be chosen).
		When mapping ports in the HOST:CONTAINER format, you may experience erroneous results when using a container port lower than 60, because YAML will parse numbers in the format xx:yy as sexagesimal (base 60). For this reason, we recommend always explicitly specifying your port mappings as strings.
	 * */
	private Object ports;

	private ArrayList<String> parsedPorts;

	//Mount paths or named volumes, optionally specifying a path on the host machine (HOST:CONTAINER), or an access mode (HOST:CONTAINER:ro)
	private Object volumes;

	private ArrayList<String> parsedVolumes;

	//Which CPU Core to use? [0,3,5], CPU Cores Range? [0-2]

	private HashMap<String,Object> deploy;
	private List<Object> secrets;


	private String cpuset;
	//RAM needed
	private String mem_limit;
	
	private String network_mode;// added new network mode property


	private String container_name;

	public String getContainerName() {
		return container_name;
	}
	public void setContainerName(String containername) {
		this.container_name = containername;
	}
	public List<Object> getSecrets() {
		if(secrets == null){
			return new ArrayList<>();
		}
		return secrets;
	}
	public void setSecrets(List<Object> secrets) {
		this.secrets = secrets;
	}
	public HashMap<String, Object> getDeploy() {
		if(deploy == null){
			return new HashMap<>();
		}
		return deploy;
	}
	public void setDeploy(HashMap<String, Object> policy) {
		this.deploy = policy;
	}
	public String getNetwork_mode() {
		return network_mode;
	}
	public void setNetwork_mode(String network_mode) {
		this.network_mode = network_mode;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}

	public void setLabels(Object labels) {
		this.labels = labels;
	}
	public LoggerVO getLogging() {
		return logging;
	}
	public void setLogging(LoggerVO logging) {
		this.logging = logging;
	}
	
	public void setPorts(Object ports) {
		this.ports = ports;
	}
	
	public void setVolumes(Object volumes) {
		this.volumes = volumes;
	}
	public String getCpuset() {
		return cpuset;
	}
	public void setCpuset(String cpuset) {
		this.cpuset = cpuset;
	}
	public String getMem_limit() {
		return mem_limit;
	}
	public void setMem_limit(String mem_limit) {
		this.mem_limit = mem_limit;
	}

	@Override
	public void guid() { }
	// PSH_01
	public HashMap<String, String> getParsedLabels() {
		if(parsedLabels == null){
			setParsedLabels(YamlParser.getLabelsParsed(labels));
		}
		return parsedLabels;
	}
	public void setParsedLabels(HashMap<String, String> parsedLabels) {
		this.parsedLabels = parsedLabels;
	}
	public ArrayList<String> getParsedPorts() {
		if(parsedPorts == null){
			setParsedPorts(YamlParser.getPortsParsed(ports));
		}
		return parsedPorts;
	}
	public void setParsedPorts(ArrayList<String> parsedPorts) {
		this.parsedPorts = parsedPorts;
	}
	public ArrayList<String> getParsedVolumes() {
		if(parsedVolumes == null){
			setParsedVolumes(YamlParser.getVolumesParsed(volumes));
		}
		return parsedVolumes;
	}
	public void setParsedVolumes(ArrayList<String> parsedVolumes) {
		this.parsedVolumes = parsedVolumes;
	}

}
/**
 * 7-1-2019 PSH_01
 * Added new properties in parsed labels and remove unwanted properties.
 */