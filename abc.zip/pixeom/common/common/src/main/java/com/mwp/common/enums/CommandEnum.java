/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */ 

package com.mwp.common.enums;

import java.util.HashMap;

public enum CommandEnum 
{
	//if make any change in this enum than make those changes in ActivityOperation enum also
		installApplication(0),
		updateApplication(1),
		uninstallApplication(2),
		systemUpdate(3),
		renameDevice(4),
		updateAppSecret(5),
		startApplication(6),
		restartApplication(7),
		stopApplication(8),
		systemReboot(9),
		systemShutdown(10),
		systemFactoryReset(11),
		systemReset(12),
		restoreApplicationBackup(13);
	
	private int num;
	
	private CommandEnum(int n)
	{
		num = n;		
	}
	
	public int getValue()
	{
		return num;
	}
	
	
	public CommandEnum GetEnum(int num)
	{
		return CommandEnumList._commandEnumList.get(num);	
	}
	
}

class CommandEnumList
{
	private CommandEnumList() {
		//	private ctor
	}
	static HashMap<Integer, CommandEnum> _commandEnumList = new HashMap<Integer, CommandEnum>();

}
