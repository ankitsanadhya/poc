/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */ 

package com.mwp.common.yamlparser;

import java.util.ArrayList;

import com.google.gson.annotations.SerializedName;
import com.mwp.common.ISkipObfuscation;


public class YmlAuthConfig implements ISkipObfuscation {

	//'{"authServer":true, "logger":true, "out-file":"file", "eventService":false, "cloudApis":["AmazonS3","HP"]}'

	private boolean authServer;
	private boolean logger;

	//Property name in YAML is "out-file" but java doesn't allow "-" in variable names
	@SerializedName("out-file")
	private String outFile;

	private boolean eventService;
	private boolean cloudApis;
	
	private boolean google_function;
	private ArrayList<String> function_ids;
	
	private boolean mDNS;
	
	private boolean secret;
	private boolean config;
	private ArrayList<SecretVo> secretList;
	private ArrayList<ConfigVo> configList;
	

	public boolean isConfig() {
		return config;
	}
	public void setConfig(boolean config) {
		this.config = config;
	}
	public ArrayList<ConfigVo> getConfig() {
		return configList;
	}
	public void setConfigList(ArrayList<ConfigVo> configList) {
		this.configList = configList;
	}
	public ArrayList<SecretVo> getSecrets() {
		return secretList;
	}
	public void setSecrets(ArrayList<SecretVo> secrets) {
		this.secretList = secrets;
	}
	public boolean isSecret() {
		return secret;
	}
	public void setSecret(boolean isSecret) {
		this.secret = isSecret;
	}
	public boolean ismDNS() {
		return mDNS;
	}
	public void setmDNS(boolean mDNS) {
		this.mDNS = mDNS;
	}
	public boolean isGoogle_function() {
		return google_function;
	}
	public void setGoogle_function(boolean google_function) {
		this.google_function = google_function;
	}
	public ArrayList<String> getFunction_ids() {
		return function_ids;
	}
	public void setFunction_ids(ArrayList<String> function_ids) {
		this.function_ids = function_ids;
	}
	public boolean isAuthServer() {
		return authServer;
	}
	public void setAuthServer(boolean authServer) {
		this.authServer = authServer;
	}
	public boolean isLogger() {
		return logger;
	}
	public void setLogger(boolean logger) {
		this.logger = logger;
	}
	public String getOutFile() {
		return outFile;
	}
	public void setOutFile(String outFile) {
		this.outFile = outFile;
	}
	public boolean isEventService() {
		return eventService;
	}
	public void setEventService(boolean eventService) {
		this.eventService = eventService;
	}
	public boolean getCloudApis() {
		return cloudApis;
	}
	public void setCloudApis(boolean cloudApis) {
		this.cloudApis = cloudApis;
	}
	@Override
	public void guid() {
		// TODO Auto-generated method stub
		
	}

}
