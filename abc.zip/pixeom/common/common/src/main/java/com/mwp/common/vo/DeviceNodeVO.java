/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */ 

package com.mwp.common.vo;

import com.mwp.common.ISkipObfuscation;
import com.mwp.common.enums.NodeType;
import com.mwp.common.enums.StateEnum;

public class DeviceNodeVO implements ISkipObfuscation
{	
	private String nodeId;
	private String deviceName;
	private String swVersion;
	private String hwProfile;
	private String macAddress;
	private String hostName;
	private String email="";
	private String supportToken;
	private String tags;
	private String description;
	private String machineId;
	private String nativeAppId;
	private String action;
	private NodeType deviceRole;
	
	/*
	 * Device State to keep the value of state enum.-PS
	 */
	private StateEnum deviceState;
	private String deviceId;
	private long   createdDate;
	private long   modifiedDate;
	private DiscoveryDetailsVO discoveryDetailsVO;

	public String getNodeId() {
		return nodeId;
	}
	public void setNodeId(String nodeId) {
		this.nodeId = nodeId;
	}
	public String getDeviceName() {
		return deviceName;
	}
	public void setDeviceName(String deviceName) {
		this.deviceName = deviceName;
	}
	public String getSwVersion() {
		return swVersion;
	}
	public void setSwVersion(String swVersion) {
		this.swVersion = swVersion;
	}
	public String getHwProfile() {
		return hwProfile;
	}
	public void setHwProfile(String hwProfile) {
		this.hwProfile = hwProfile;
	}
	public String getMacAddress() {
		return macAddress;
	}
	public void setMacAddress(String macAddress) {
		this.macAddress = macAddress;
	}
	public String getHostName() {
		return hostName;
	}
	public void setHostName(String hostName) {
		this.hostName = hostName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getSupportToken() {
		return supportToken;
	}
	public void setSupportToken(String supportToken) {
		this.supportToken = supportToken;
	}
	public String getTags() {
		return tags;
	}
	public void setTags(String tags) {
		this.tags = tags;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getMachineId() {
		return machineId;
	}
	public void setMachineId(String machineId) {
		this.machineId = machineId;
	}
	public String getNativeAppId() {
		return nativeAppId;
	}
	public void setNativeAppId(String nativeAppId) {
		this.nativeAppId = nativeAppId;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public NodeType getDeviceRole() {
		return deviceRole;
	}
	public void setDeviceRole(NodeType deviceRole) {
		this.deviceRole = deviceRole;
	}
	public StateEnum getDeviceState() {
		return deviceState;
	}
	public void setDeviceState(StateEnum deviceState) {
		this.deviceState = deviceState;
	}
	public String getDeviceId() {
		return deviceId;
	}
	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}
	public long getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(long createdDate) {
		this.createdDate = createdDate;
	}
	public long getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(long modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public DiscoveryDetailsVO getDiscoveryDetailsVO() {
		return discoveryDetailsVO;
	}

	public void setDiscoveryDetailsVO(DiscoveryDetailsVO discoveryDetailsVO) {
		this.discoveryDetailsVO = discoveryDetailsVO;
	}
	@Override
	public void guid() {
		// TODO Auto-generated method stub
		
	}
	
}
