/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */ 

package com.mwp.common;

import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.google.gson.Gson;
import com.mwp.common.constant.Constant;
import com.mwp.common.vo.ErrorVo;
import com.mwp.logger.PALogger;

/**
 * 
 * This class is used for creating response to a client request
 *
 */
public class ReturnObject {

	private ReturnObject(){
		//	Utility class having only static members, Should not instantiated
	}
	
	/**
	 * This method create response for SUCCESS and ERROR both.
	 * @param status this means query is {@link Constant.SUCCESS} or {@link Constant.FAILURE}
	 * @param dataObject if status is {@link Constant.SUCCESS} then only this parameter works, we can send any data in this object. It can be null.
	 * @param errorObject if status is {@link Constant.FAILURE} then only this parameter works, we have to return {@link ErrorVo} type of object. 
	 * @param response query response {@link HttpServletResponse} which is declare in class.
	 */
	public static String createResponse(String status, Object dataObject, ErrorVo errorObject, HttpServletResponse response) {
		final Gson gsonObject = new Gson();
		if(Constant.SUCCESS.equals(status)) {
			if(response == null) {
				return gsonObject.toJson(dataObject);
			} else {
				response.setContentType(MediaType.APPLICATION_JSON);
				int code = StringFunctions.isNullOrWhitespace(dataObject) ? HttpServletResponse.SC_NO_CONTENT : HttpServletResponse.SC_OK;
				response.setStatus(code);
				try {


					response.getOutputStream().write(gsonObject.toJson(dataObject).getBytes());
					response.getOutputStream().close();
				} catch (Exception e) {
					PALogger.ERROR(e);
				}
			}
		} else if(Constant.FAILURE.equals(status) && !StringFunctions.isNullOrWhitespace(errorObject)) {
			if(response == null) {
				return gsonObject.toJson(errorObject);
			} else {
				response.setContentType(MediaType.APPLICATION_JSON);
				response.setStatus(errorObject.getCode());
				try {
					response.getOutputStream().write(gsonObject.toJson(errorObject).getBytes());
					response.getOutputStream().close();
				} catch (Exception e) {
					PALogger.ERROR(e);					
				}
			}
		}
		return "";
	}
	
	/**
	 * This method is used to create rmq response 
	 * @param errorcode
	 * @param dataObject
	 * @param response
	 * @return
	 */
	public static Response createRMQResponse(int errorcode , Object dataObject,  HttpServletResponse response) {
		if(errorcode == 200){
			return javax.ws.rs.core.Response.ok().entity(dataObject).build();
		}else{
			return javax.ws.rs.core.Response.serverError().entity(dataObject).build();
		}


	}
}