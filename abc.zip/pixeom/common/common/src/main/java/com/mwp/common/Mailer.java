/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */ 

package com.mwp.common;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.json.simple.JSONObject;

import com.google.gson.Gson;
import com.mwp.common.constant.Constant;
import com.mwp.common.vo.EmailServersVO;
import com.mwp.logger.PALogger;

class RunnableThread implements Runnable 
{
	Thread runner;

	MimeMessage _message;	
	Transport _transport;
	List<EmailServersVO> _emailServerVOList = new ArrayList<>();
	HashMap<String, Object>  _emailInformationMap = new HashMap<String, Object>();

	public RunnableThread(List<EmailServersVO> emailServerVOList, HashMap<String, Object> emailInformationMap) 
	{
		_emailServerVOList =  emailServerVOList;
		_emailInformationMap = emailInformationMap;		
	}

	private void setConnection(EmailServersVO emailServerVO) throws MessagingException
	{
		// Get system properties
		Properties props = System.getProperties();

		props.put("mail.transport.protocol", "smtp");
		props.put("mail.smtp.socketFactory.fallback", "true"); 
		props.put("mail.smtp.host", emailServerVO.getServerAddress()); //host name
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.ssl.trust", emailServerVO.getServerAddress()); //host name

		// Get session
		Session session = Session.getInstance(props, null);
		session.setDebug(true);
		// Define message
		_message = new MimeMessage(session);
		_message.setFrom(new InternetAddress((String)_emailInformationMap.get("Sender")));

		if(_emailInformationMap.containsKey("Receivers"))
		{
			for (String receiver : (ArrayList<String>)_emailInformationMap.get("Receivers")) {
				_message.addRecipient(Message.RecipientType.TO, new InternetAddress(receiver));	
			}
		}

		if(_emailInformationMap.containsKey("CCReceivers"))
		{
			for (String receiver : (ArrayList<String>)_emailInformationMap.get("CCReceivers")) {
				_message.addRecipient(Message.RecipientType.CC, new InternetAddress(receiver));	
			}
		}

		if(_emailInformationMap.containsKey("BCCReceivers"))
		{
			for (String receiver :  (ArrayList<String>)_emailInformationMap.get("BCCReceivers")) {
				_message.addRecipient(Message.RecipientType.BCC, new InternetAddress(receiver));	
			}
		}
		_message.setSubject((String)_emailInformationMap.get("Subject"));
		// create the message part 
		MimeBodyPart messageBodyPart = new MimeBodyPart();		
		messageBodyPart.setContent(_emailInformationMap.get("Body"), (String)_emailInformationMap.get("contentType"));
		Multipart multipart = new MimeMultipart("related");
		multipart.addBodyPart(messageBodyPart);

		if(_emailInformationMap.containsKey("Attachments"))
		{
			ArrayList<String> Attachments = (ArrayList<String>)_emailInformationMap.get("Attachments");
			if(Attachments.size() > 0)
			{
				for (String Attachment : Attachments) {
					// Part two is attachment
					messageBodyPart = new MimeBodyPart();
					DataSource source = new FileDataSource(Attachment);
					messageBodyPart.setDataHandler(new DataHandler(source));
					String fileName = new File(Attachment).getName();
					messageBodyPart.setFileName(fileName);
					multipart.addBodyPart(messageBodyPart);

				}
			}
			// Put parts in message
		}
		_message.setContent(multipart);

		if(emailServerVO.getServerAddress().equals("smtp.gmail.com"))
		{
			if (emailServerVO.getisTLS()) 
			{
				_transport = session.getTransport();

			}
			else
			{
				_transport = session.getTransport("smtps");

			}
		}
		else
			_transport = session.getTransport();


		_transport.connect(emailServerVO.getServerAddress(), emailServerVO.getPort(),  emailServerVO.getUsername(), emailServerVO.getPassword());
	}

	public void run() 
	{	
		for (EmailServersVO emailServerVO : _emailServerVOList) 
		{
			try {
				setConnection(emailServerVO);
				_transport.sendMessage(_message, _message.getAllRecipients());
				break;
			}
			catch (MessagingException e)
			{
				PALogger.ERROR(e);
			}
			finally {
				try {
					_transport.close();
				} catch (MessagingException e) {
					PALogger.ERROR(e);
				}
			}
		}
	}
}

/**
 * 
 * This class is used to send email
 *
 */
@SuppressWarnings("unchecked")
public class Mailer 
{
	private List<EmailServersVO> _emailServerList;
	boolean isPrimaryHostnameRefussed = false;
	private static String sender = "";
	private static String partnercopyrights = "";
	private static ArrayList<String> bccTechReciverList = new ArrayList<String>();

	public Mailer(List<EmailServersVO> emailServerList) {	
		_emailServerList = emailServerList;
	}


	static {
		JSONObject pxconfig = Constant.getPxConfig();
		partnercopyrights = pxconfig.get("partnercopyrights").toString();
		sender = pxconfig.get("sender").toString();
		Object emailList = pxconfig.get("supportemaillist");

		Gson gson = new Gson();

		HashMap<?, ?> map = gson.fromJson(gson.toJson(emailList), HashMap.class);

		bccTechReciverList = (ArrayList<String>) map.get("bcc");
	}

	/**
	 * SendPlainMail Content type of mail is text/plain.
	 * @param Sender From which account mail to be sent.
	 * @param Receivers List of receivers who will get mail.
	 * @param Subject String value.
	 * @param Body Context of Email body.
	 * @param CCReceivers It can be null, in case when no CC Receivers.
	 * @param BCCReceivers It can be null, in case when no BCC Receivers.
	 * @param Attachments  It can be null, in case when no attachment.
	 * @throws Exception
	 */
	public void SendPlainMail(String Sender, List<String> Receivers, String Subject, String Body, List<String> CCReceivers, List<String> BCCReceivers, List<String> Attachments, String contentType) 
	{
		HashMap<String, Object> emailInformation = new HashMap<>();
		emailInformation.put("Receivers", Receivers);
		emailInformation.put("CCReceivers", CCReceivers);
		emailInformation.put("BCCReceivers", BCCReceivers);
		emailInformation.put("Sender", Sender);
		emailInformation.put("Subject", Subject);
		emailInformation.put("Body",  Body);
		emailInformation.put("contentType", contentType);
		emailInformation.put("Attachments", Attachments);

		Thread thread1 = new Thread(new RunnableThread(_emailServerList, emailInformation));
		thread1.start();
	}

	/**
	 * This method is used to get email content for forgot password
	 * @param productName
	 * @param tempPassword
	 * @return
	 */
	public String[] GetForgotPasswordEmail(String productName, String tempPassword){
		String[] result = getMessageAndCopyRightAccordingToProduct();
		String subject = productName + " password reset email";
		String email = "<!DOCTYPE html>"
				+ "<html lang=\"en\">"
				+ "<head>"
				+ "<meta charset=\"utf-8\">"
				+ "<meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge,chrome=1\">"
				+ "<title>Forgot Password</title>"
				+ "</head>"
				+ "<body>"
				+ "<table width='600' border='0' align='center' cellpadding='0' cellspacing='0' style='color: #666666; font-family: Arial; font-size: 11px;'>"
				+ "<tr>"
				+ "<td valign='top' class='border' style='border: 5px solid #8d8d8d; background-color: #FDFDFD; background-repeat: repeat-x; padding: 0px;'><table width='100%' border='0' cellspacing='0' cellpadding='0'>"
				+ "<tr>"
				+ "<td height='15' align='center' valign='top'><span style='background-color:#8d8d8d; padding:5px 10px 5px 10px; height:15px; color:#FFF;font-size: 18px;'>&nbsp;Forgot Password</span></td>"
				+ "</tr>"
				+ "<tr>"
				+ "<td height='15' valign='top' style='padding:5px;'><table width='100%' border='0' align='center' cellpadding='0' cellspacing='0'>"
				+ "<tr>"
				+ "<td align='center' valign='top' height='15'></td>"
				+ "</tr>"
				+ "<tr>"
				+"<td align='center' valign='top' style='font-size: 18px;' title='"+productName+"'><b>" + productName + "</b></td>"
				//+"<td align='center' valign='top'><img src='cid:LogoID' height='65px' /></td>"
				+ "</tr>"
				//				+"<tr>"
				//				+"<td align='center' valign='top'>"+hostName+"</td>"
				//				+"</tr>"
				+ "<tr>"
				+ "<td height='150' valign='top'><table width='100%' height='0' border='0' align='center'>"
				+ "<tr>"
				+ "<td></td>"
				+ "</tr>"
				+ "<tr>"
				+ "<td></td>"
				+ "</tr>"
				+ "<tr>"
				+ "<td valign='top' height='10'></td>"
				+ "</tr>"
				+ "<tr>"
				+ "<td valign='top' style='background-color: #F7F7F7; padding: 15px; border: 1px solid #8d8d8d; font-family:Verdana, Geneva, sans-serif; font-size:12px; line-height:18px;'><p>"
				//						+ "<:=Username:>,<br />"
				//				+ userName + ","
				//				+"<br/>"
				//				+"<br/>"
				+ "Use this reset password token to reset your new password."
				+"<br/>"
				//				+"<br/>"
				//				+"Please note:  Ignore this email if you have not made a request - your original password will continue to work until you click on the reset password using temporary token."
				+ "</p>"
				+ "<table width='100%' border='0' cellspacing='0' cellpadding='0' style='border: solid 1px #000;'>"
				+ "<tr>"
				+ "<td width='35%' align='center' style='background-color:#6c6c6c; color:#FFF; font-size:12px; font-family:Verdana, Geneva, sans-serif; padding:5px;'>Reset password token </td>"
				+ "<td width='55%' align='center' style='background-color:#fff; color:#000; font-size:12px; font-family:Verdana, Geneva, sans-serif; padding:5px;'>"
				//						+ "<:=temppwd:></td>"
				+ tempPassword +" </td>"
				+ "</tr>"
				+ "</table>"
				//				+ "<table width='100%' border='0' cellspacing='0' cellpadding='0'>"
				//				+ "<tr>"
				//				+ "<td width='100%' colspan='2' align='center' style='background-color:#fff; color:#000; font-size:12px; font-family:Verdana, Geneva, sans-serif; padding:5px;'>Double click on the temporary password and right click to copy.</td>"
				//				+ "</tr>"
				//				+ "</table>"
				//				+" <br/>"
				//				+ "Reset password using the temporary token, enter your new password and confirm to complete the reset process."
				//				+"<br/>"
				+ "<p><br/>"
				+ "PLEASE NOTE: Ignore this email if you did not make this request, in which case your password will remain the same and not be reset."
				//				+ "Best Regards,<br/>"
				//				+ "Admin"
				+"</p></td>"
				+"</tr>"
				+"<tr>"
				+"<td><p></p></td>"
				+"</tr>"
				+"</tbody>"
				+"</table>"
				+"</td>"
				+"</tr>"
				+"<tr>"
				+"<td valign='top' height='15'></td>"
				+"</tr>"
				+ result[1]
						+"</tbody>"
						+"</table>"
						+"</td>"
						+"</tr>"
						+"<tr>"
						+"<td valign='top' height='15'></td>"
						+"</tr>"
						+"<tr>"
						+"<td style='font-family: Verdana, Geneva, sans-serif; font-size: 11px; color: #6c6c6c; border-top: solid 1px #c8c8c8; padding-top: 5px;' align='center' valign='top' height='15'>&copy; " + result[0] + "</td>"
						+"</tr>"
						+"</tbody>"
						+"</table>"
						+"</td>"
						+"</tr>"
						+"</tbody>"
						+"</table>"
						+"</td>"
						+"</tr>"
						+"</tbody>"
						+"</table>"
						+"</td>"
						+"</tr>"
						+"</tbody>"
						+"</table>"
						+"</div>"
						+"</body>"
						+"</html>";

		return new String[] {subject, email };
	}

	/**
	 * Added new method to get message and copy right according to product.
	 * @return String[] contain message and copyright.
	 */
	private String[] getMessageAndCopyRightAccordingToProduct(){
		String copyRight = partnercopyrights;
		String fotterMsg = "";

		return new String[] {copyRight, fotterMsg};
	}


	/**
	 * This method is used to send technical email
	 * @param senderEmailId
	 * @param receiverEmailId
	 * @param subject
	 * @param message
	 * @param attachments
	 * @param sendMailCount
	 */
	public void sendTechMail(String senderEmailId, String receiverEmailId, String subject, String message, List<String> attachments, int sendMailCount)
	{
		List<String> receiverList = new ArrayList<String>();
		receiverList.add(sender);

		try {
			this.SendPlainMail(senderEmailId, receiverList, subject, message, new ArrayList<String>() , bccTechReciverList, attachments,"text/plain");
		} catch (Exception e) {
			PALogger.ERROR(e);
			if(sendMailCount < 3){
				sendMailCount++;
				sendTechMail(senderEmailId, receiverEmailId, subject, message, attachments, sendMailCount);
			}
		}
	}

	//new implementation not yet tested
	/**
	 * send email to sign up user to verify its email
	 * @throws Exception 
	 */
	public void sendMailForVerification(String emailId,String link, String productName) {
		List<String> receiverList= new ArrayList<String>();
		receiverList.add(emailId);
		String[] message = verifyEmailText(link, productName);
		try {
			this.SendPlainMail(sender, receiverList,message[0], message[1],new ArrayList<String>() , new ArrayList<String>(), new ArrayList<String>(),"text/html");
		} catch (Exception e) {
			PALogger.ERROR(e);

		}
	}

	/**
	 * send email when forget password request is received at auth server
	 * @param emailId
	 * @param temptoken
	 * @throws Exception
	 */
	public void sendforgetpasswordMail(String emailId,String tempToken,String productName) {
		List<String> receiverList= new ArrayList<String>();
		receiverList.add(emailId);

		String[] message = GetForgotPasswordEmail(productName, tempToken);
		try {
			this.SendPlainMail(sender, receiverList,message[0], message[1],new ArrayList<String>() , new ArrayList<String>(), new ArrayList<String>(),"text/html");
		} catch (Exception e) {
			PALogger.ERROR(e);
		}
	}

	/**
	 * This method is used to send support token email
	 * @param email
	 * @param supportToken
	 * @param supprotUrl
	 * @param logoPath
	 * @param technicalSupportUrl
	 */
	public void sendSupportTokenEmail(String email, String supportToken, String supprotUrl, String technicalSupportUrl){

		List<String> receiverList= new ArrayList<String>();
		receiverList.add(email);

		String productName = Constant.getProduct();
		String message = getSupportTokenEmailText(supportToken, supprotUrl, productName, technicalSupportUrl);
		try {
			this.SendPlainMail(sender, receiverList, "Support Token", message, new ArrayList<String>() , new ArrayList<String>(), new ArrayList<String>(),"text/html");
		} catch (Exception e) {
			PALogger.ERROR(e);
		}
	}

	/**
	 * This mehtod is used to send delete support token email
	 * @param email
	 * @param supportToken
	 * @param logoPath
	 * @param technicalSupportUrl
	 */
	public void sendDeleteSupportTokenEmail(String email, String supportToken, String technicalSupportUrl){
		List<String> receiverList= new ArrayList<String>();
		receiverList.add(email);
		String productName = Constant.getProduct();
		String message = getDeleteSupportTokenText( supportToken, productName, technicalSupportUrl);
		try {
			this.SendPlainMail(sender, receiverList, "Support Token", message, new ArrayList<String>() , new ArrayList<String>(), new ArrayList<String>(),"text/html");
		} catch (Exception e) {
			PALogger.ERROR(e);
		}
	}

	/**
	 * This mehtod is used to verify email text
	 * @param link
	 * @param productName
	 * @return
	 */
	public String[] verifyEmailText(String link, String productName)
	{
		String[] result = getMessageAndCopyRightAccordingToProduct();
		String subject = productName + " email verification.";
		String email = "<html>"
				+ "<head>"
				+ "<meta http-equiv='Content-Type' content='text/html; charset=iso-8859-1' />"
				+ "<title>Verify email</title>"
				+  "</head>"
				+ "<body>"
				+"<div style='width: 60%; margin-left: auto; margin-right: auto; text-align: center;'>"
				+"<table style='text-align: justify; color: #666666; font-family: Arial; font-size: 11px;' border='0' width='600' cellspacing='0' cellpadding='0' align='center'>"
				+"<tbody>"
				+"<tr>"
				+"<td class='border' style='border: 5px solid #8d8d8d; background-repeat: repeat-x; padding: 0px;' valign='top'>"
				+"<table border='0' width='100%' cellspacing='0' cellpadding='0'>"
				+"<tbody>"
				+"<tr>"
				+"<td align='center' valign='top' height='15'><span style='background-color: #8d8d8d; padding: 5px 10px 5px 10px; height: 15px; color: #fff; font-size: 18px; box-shadow: 2px 2px 2px #ccc;'>Verify email</span></td>"
				+"</tr>"
				+"<tr>"
				+"<td style='padding: 5px;' valign='top' height='15'>"
				+"<table border='0' width='100%' cellspacing='0' cellpadding='0' align='center'>"
				+"<tbody>"
				+"<tr>"
				+"<td align='center' valign='top' height='15'></td>"
				+"</tr>"
				+"<tr>"
				+"<td align='center' valign='top' style='font-size: 18px;' title='"+productName+"'><b>" + productName + "</b></td>"
				+"</tr>"
				+"<tr>"
				+"<td valign='top' height='150'>"
				+"<table border='0' width='100%' align='center'>"
				+"<tbody>"
				+"<tr>"
				+"<td></td>"
				+"</tr>"
				+"<tr>"
				+"<td></td>"
				+"</tr>"
				+"<tr>"
				+"<td valign='top' height='10'></td>"
				+"</tr>"
				+"<tr>"
				+"<td style='background-color: #f7f7f7; padding: 15px; border: 1px solid #8d8d8d; font-family: Verdana, Geneva, sans-serif; font-size: 12px; line-height: 18px;' valign='top'>"
				+"<table style='font-size: 12px;'>"
				+"<tbody>"
				//				+"<tr>"
				//				+"<td>"+ inviteeusername + ",</td>"
				//				+"</tr>"
				+"<tr>"
				+"<td></td>"
				+"</tr>"
				+"<tr>"
				+"<td></td>"
				+"</tr>"
				+"<tr>"
				+ "<td>"
				+ "<p>Please click on the following link to Sign in:</p>"
				+ "<a href='" + link + "' style='color: #0d7ab2;'>" +link + "</a></br>"

				//				+ "<p>Please do not hesitate to contact me with any questions.</p>" 
				+"</td>"
				+"</tr>"
				+"<tr>"
				+"<td><p></p></td>"
				+"</tr>"
				//				+"<tr>"
				//				+"<td>Best Regards,</td>"
				//				+"</tr>"
				//				+"<tr>"
				//				+"<td>"+ownerName+"</td>"
				//				+"</tr>"
				+"<tr>"
				+"<td><p></p></td>"
				+"</tr>"
				+"</tbody>"
				+"</table>"
				+"</td>"
				+"</tr>"
				+"<tr>"
				+"<td valign='top' height='15'></td>"
				+"</tr>"
				+result[1]
						+"</tbody>"
						+"</table>"
						+"</td>"
						+"</tr>"
						+"<tr>"
						+"<td valign='top' height='15'></td>"
						+"</tr>"
						+"<tr>"
						+"<td style='font-family: Verdana, Geneva, sans-serif; font-size: 11px; color: #6c6c6c; border-top: solid 1px #c8c8c8; padding-top: 5px;' align='center' valign='top' height='15'>&copy; " + result[0] + "</td>"
						+"</tr>"
						+"</tbody>"
						+"</table>"
						+"</td>"
						+"</tr>"
						+"</tbody>"
						+"</table>"
						+"</td>"
						+"</tr>"
						+"</tbody>"
						+"</table>"
						+"</td>"
						+"</tr>"
						+"</tbody>"
						+"</table>"
						+"</div>"
						+"</body>"
						+"</html>";
		return new String[] {subject, email };
	}

	private String getSupportTokenEmailText(String supportToken, String supprotUrl, String productName, String technicalSupportUrl){
		String[] result = getMessageAndCopyRightAccordingToProduct();
		String email = "<!DOCTYPE html>"
				+"<html lang='en'>"
				+"<head>"
				+"<title>Support Token Email</title>"
				+"</head>"
				+"<body>"
				+"<table width='600' border='0' align='center' cellpadding='0' cellspacing='0' style='color: #666666; font-family: Arial; font-size: 11px;'>"
				+"<tr>"
				+"<td valign='top' class='border' style='border: 5px solid #8d8d8d; background-color: #FDFDFD; background-repeat: repeat-x; padding: 0px;'><table width='100%' border='0' cellspacing='0' cellpadding='0'>"
				+"<tr>"
				+"<td height='15' align='center' valign='top'>"
				+"<span style='background-color:#8d8d8d; padding:5px 10px 5px 10px; height:15px; color:#FFF;font-size: 18px;'>&nbsp;Support Token</span></td>"
				+"</tr>"
				+"<tr>"
				+"<td height='15' valign='top' style='padding:5px;'><table width='100%' border='0' align='center' cellpadding='0' cellspacing='0'>"
				+"<tr>"
				+"<td align='center' valign='top' height='15'></td>"
				+"</tr>"
				+"<tr>"
				+"<td align='center' valign='top' style='font-size: 18px;' title='"+productName+"'><b>" + productName + "</b></td>"
				+"</tr>"
				+"<tr>"
				+"<td height='150' valign='top'><table width='100%' height='0' border='0' align='center'>"
				+"<tr>"
				+"<td></td>"
				+"</tr>"
				+"<tr>"                                                                                                                              
				+"<td></td>"
				+"</tr>"
				+"<tr>"
				+"<td valign='top' height='10'></td>"
				+"</tr>"
				+"<tr>"
				+"<td valign='top' style='background-color: #F7F7F7; padding: 15px; border: 1px solid #8d8d8d; font-family:Verdana, Geneva, sans-serif; font-size:12px; line-height:18px;'>"
				+"<br />"
				+"As per your support request, please copy and paste or manually enter the following support token on your support page."
				+"<br />"
				+"</p>"
				+"<table width='100%' border='0' cellspacing='0' cellpadding='0' style='border: solid 1px #000;'>"
				+"<tr>"
				+"<td width='35%' align='center' style='background-color:#6c6c6c; color:#FFF; font-size:12px; font-family:Verdana, Geneva, sans-serif; padding:5px;'>Support Token </td>"
				+"<td width='55%' align='center' style='background-color:#fff; color:#000; font-size:12px; font-family:Verdana, Geneva, sans-serif; padding:5px;'>"+ supportToken +"</td>"
				+"</tr>"
				+"</table>"
				+"<p><a target='_blank' href='"+ supprotUrl + "'>Support Page</a><br />"
				+"<br />"
				+"This support token will be valid for a single session. The support can be terminated by you at any time from your support page, or by the technical support team upon completion of session.<br />"
				+"<br />"
				+"<!--  PLEASE NOTE: Ignore this email if you did not make this request, in which case your password will remain the same and not be reset.<br />"
				+"<br /> -->"
				+"Note: After termination should you need additional support, please request another token.<br />"
				+"</p></td>"
				+"</tr>"
				+"<tr>"
				+"<td valign='top' height='15'></td>"
				+"</tr>"
				+"<tr>"
				+"<td align='center' valign='top' height='15'><i style='font-size:11px;'>Please do not reply to this email as this mailbox is not monitored. For assistance, contact <a style='color:#0d7ab2;' target='_blank' href='"+ technicalSupportUrl +"'>Technical Support.</a></i></td>"
				+"</tr>"
				+"<tr>"
				+"<td valign='top' height='15'></td>"
				+"</tr>"
				+"<tr>"
				+"<td height='15' align='center' valign='top' style='font-family:Verdana, Geneva, sans-serif;  font-size:11px; color:#6c6c6c; border-top: solid 1px #c8c8c8; padding-top:5px;'> &copy; " + result[0] + "</td>"
				+"</tr>"
				+"</table></td>"
				+"</tr>"
				+"</table></td>"
				+"</tr>"
				+"</table></td>"
				+"</tr>"
				+"</table>"
				+"</body>"
				+"</html>";
		return email;
	}

	private String getDeleteSupportTokenText(String supportToken, String productName, String technicalSupportUrl){
		String[] result = getMessageAndCopyRightAccordingToProduct();
		String email = "<!DOCTYPE html>"
				+"<html lang='en'>" 
				+"<head>"
				+"<meta charset='utf-8'>"
				+"<meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'>"
				+"<title>Support Token Email</title>"
				+"</head>"
				+"<body>"
				+"<table width='600' border='0' align='center' cellpadding='0' cellspacing='0' style='color: #666666; font-family: Arial; font-size: 11px;'>"
				+"<tr>"
				+"<td valign='top' class='border' style='border: 5px solid #8d8d8d; background-color: #FDFDFD; background-repeat: repeat-x; padding: 0px;'><table width='100%' border='0' cellspacing='0' cellpadding='0'>"
				+"<tr>"
				+"<td height='15' align='center' valign='top'>"
				+"<span style='background-color:#8d8d8d; padding:5px 10px 5px 10px; height:15px; color:#FFF;font-size: 18px;'>&nbsp;Support Token</span></td>"
				+"</tr>"
				+"<tr>"
				+"<td height='15' valign='top' style='padding:5px;'><table width='100%' border='0' align='center' cellpadding='0' cellspacing='0'>"
				+"<tr>"
				+"<td align='center' valign='top' height='15'></td>"
				+"</tr>"
				+"<tr>"
				+"<td align='center' valign='top' style='font-size: 18px;' title='"+productName+"'><b>" + productName + "</b></td>"
				+"</tr>"
				+"<tr>"
				+"<td height='150' valign='top'><table width='100%' height='0' border='0' align='center'>"
				+"<tr>"
				+"<td></td>"
				+"</tr>"
				+"<tr>"         
				+"<td></td>"
				+"</tr>"
				+"<tr>"
				+"<td valign='top' height='10'></td>"
				+"</tr>"
				+"<tr>"
				+"<td valign='top' style='background-color: #F7F7F7; padding: 15px; border: 1px solid #8d8d8d; font-family:Verdana, Geneva, sans-serif; font-size:12px; line-height:18px;'>"
				+"<br />"
				+"Your support session has been terminated."
				+"<br />"
				+"</p>"
				+"<table width='100%' border='0' cellspacing='0' cellpadding='0' style='border: solid 1px #000;'>"
				+"<tr>"
				+"<td width='35%' align='center' style='background-color:#6c6c6c; color:#FFF; font-size:12px; font-family:Verdana, Geneva, sans-serif; padding:5px;'>Support Token </td>"
				+"<td width='55%' align='center' style='background-color:#fff; color:#000; font-size:12px; font-family:Verdana, Geneva, sans-serif; padding:5px;'>"+ supportToken +"</td>"
				+"</tr>"
				+"</table>"
				+"<p>"
				+"<!--<br />"
				+"<table width='100%' border='0' cellspacing='0' cellpadding='0'>"
				+"<tr>"
				+"<td width='100%' colspan='2' align='center' style='background-color:#fff; color:#000; font-size:12px; font-family:Verdana, Geneva, sans-serif; padding:5px;'>Double click on the temporary password and right click to copy.</td>"
				+"</tr>"
				+"</table>-->"
				+"Should you need additional support, please request another token.<br />"
				+"<!-- <p><:=Resetpwdurl:><br /> -->"
				+"<!--  PLEASE NOTE: Ignore this email if you did not make this request, in which case your password will remain the same and not be reset.<br />"
				+"<br /> -->"
				+"</p></td>"
				+"</tr>"
				+"<tr>"
				+"<td valign='top' height='15'></td>"
				+"</tr>"
				+"<tr>"
				+"<td align='center' valign='top' height='15'><i style='font-size:11px;'>Please do not reply to this email as this mailbox is not monitored. For assistance, contact <a target='_blank' style='color:#0d7ab2;' href="+ technicalSupportUrl +"'>Technical Support.</a></i></td>"
				+"</tr>"
				+"<tr>"
				+"<td valign='top' height='15'></td>"
				+"</tr>"
				+"<tr>"
				+"<td height='15' align='center' valign='top' style='font-family:Verdana, Geneva, sans-serif;  font-size:11px; color:#6c6c6c; border-top: solid 1px #c8c8c8; padding-top:5px;'> &copy; " + result[0] + "</td>"
				+"</tr>"
				+"</table></td>"
				+"</tr>"
				+"</table></td>"
				+"</tr>"
				+"</table></td>"
				+"</tr>"
				+"</table>"
				+"</body>"
				+"</html>";
		return email;
	}

	public String[] getConfirmationMail(String code, String productName) {
		String[] result = getMessageAndCopyRightAccordingToProduct();
		String subject =  productName + " multi-factor authentication.";
		String email = "<html>"
				+ "<head>"
				+ "<meta http-equiv='Content-Type' content='text/html; charset=iso-8859-1' />"
				+ "<title>Multi-factor Authentication</title>"
				+  "</head>"
				+ "<body>"
				+"<div style='width: 60%; margin-left: auto; margin-right: auto; text-align: center;'>"
				+"<table style='text-align: justify; color: #666666; font-family: Arial; font-size: 11px;' border='0' width='600' cellspacing='0' cellpadding='0' align='center'>"
				+"<tbody>"
				+"<tr>"
				+"<td class='border' style='border: 5px solid #8d8d8d; background-repeat: repeat-x; padding: 0px;' valign='top'>"
				+"<table border='0' width='100%' cellspacing='0' cellpadding='0'>"
				+"<tbody>"
				+"<tr>"
				+"<td align='center' valign='top' height='15'><span style='background-color: #8d8d8d; padding: 5px 10px 5px 10px; height: 15px; color: #fff; font-size: 18px; box-shadow: 2px 2px 2px #ccc;'>Multi-factor Authentication</span></td>"
				+"</tr>"
				+"<tr>"
				+"<td style='padding: 5px;' valign='top' height='15'>"
				+"<table border='0' width='100%' cellspacing='0' cellpadding='0' align='center'>"
				+"<tbody>"
				+"<tr>"
				+"<td align='center' valign='top' height='15'></td>"
				+"</tr>"
				+"<tr>"
				+"<td align='center' valign='top' style='font-size: 18px;' title='"+productName+"'><b>" + productName + "</b></td>"
				+"</tr>"
				+"<tr>"
				+"<td valign='top' height='150'>"
				+"<table border='0' width='100%' align='center'>"
				+"<tbody>"
				+"<tr>"
				+"<td></td>"
				+"</tr>"
				+"<tr>"
				+"<td></td>"
				+"</tr>"
				+"<tr>"
				+"<td valign='top' height='10'></td>"
				+"</tr>"
				+"<tr>"
				+"<td style='background-color: #f7f7f7; padding: 15px; border: 1px solid #8d8d8d; font-family: Verdana, Geneva, sans-serif; font-size: 12px; line-height: 18px;' valign='top'>"
				+"<table style='font-size: 12px;'>"
				+"<tbody>"
				//				+"<tr>"
				//				+"<td>"+ inviteeusername + ",</td>"
				//				+"</tr>"
				+"<tr>"
				+"<td></td>"
				+"</tr>"
				+"<tr>"
				+"<td></td>"
				+"</tr>"
				+"<tr>"
				+ "<td>"
				+ "<p>Please use the following code to sign in:</p>"
				+ code
				+ "</br>"

				//				+ "<p>Please do not hesitate to contact me with any questions.</p>" 
				+"</td>"
				+"</tr>"
				+"<tr>"
				+"<td><p></p></td>"
				+"</tr>"
				//				+"<tr>"
				//				+"<td>Best Regards,</td>"
				//				+"</tr>"
				//				+"<tr>"
				//				+"<td>"+ownerName+"</td>"
				//				+"</tr>"
				+"<tr>"
				+"<td><p></p></td>"
				+"</tr>"
				+"</tbody>"
				+"</table>"
				+"</td>"
				+"</tr>"
				+"<tr>"
				+"<td valign='top' height='15'></td>"
				+"</tr>"
				+result[1]
						+"</tbody>"
						+"</table>"
						+"</td>"
						+"</tr>"
						+"<tr>"
						+"<td valign='top' height='15'></td>"
						+"</tr>"
						+"<tr>"
						+"<td style='font-family: Verdana, Geneva, sans-serif; font-size: 11px; color: #6c6c6c; border-top: solid 1px #c8c8c8; padding-top: 5px;' align='center' valign='top' height='15'>&copy; " + result[0] + "</td>"
						+"</tr>"
						+"</tbody>"
						+"</table>"
						+"</td>"
						+"</tr>"
						+"</tbody>"
						+"</table>"
						+"</td>"
						+"</tr>"
						+"</tbody>"
						+"</table>"
						+"</td>"
						+"</tr>"
						+"</tbody>"
						+"</table>"
						+"</div>"
						+"</body>"
						+"</html>";
		return new String[] {subject, email };
	}
}
