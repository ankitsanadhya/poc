/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */ 

package com.mwp.common.vo;

import javax.validation.constraints.NotEmpty;

import com.google.gson.annotations.Expose;
import com.mwp.common.ISkipObfuscation;
import com.mwp.common.enums.GenderEnum;
import com.mwp.common.enums.UserStatusEnum;

public class UsersVO implements ISkipObfuscation 
{
	@Expose(serialize = false)
	private String userId;
	@Expose
	private String firstName;
	private String lastName ;
	@Expose
	private String userName;
	@Expose
	@NotEmpty(message ="emailId cannot be Null.")
	private String emailId ;
	@Expose
	private String dob;
	@Expose(serialize = false)
	private String password;
	@Expose
	private String resetPasswordToken;
	@Expose
	private GenderEnum gender ;
	@Expose
	private String contactNo;
	@Expose
	private String country ;
	@Expose
	private String profilePicturePath;
	@Expose
	private String shareUrl;
	@Expose
	private UserStatusEnum userStatus;
	@Expose
	private boolean defaultDeveloper ;
	@Expose
	private String emailVerificationId;
	@Expose
	private boolean twoFactorLogin ;
	@Expose
	private long createdDate ;
	@Expose
	private long modifiedDate ;

	public UsersVO()
	{

	}
	public UsersVO(String userId, String firstName,String lastName,String userName,String emailId,String dob, GenderEnum gender, String contactNo, String country,String profilePicturePath,String shareUrl, UserStatusEnum userStatus, Boolean isDeveloper, String verificationId,long createdDate,long modifiedDate) 
	{
		this.userId=userId;
		this.firstName =firstName;
		this.lastName =lastName;
		this.userName=userName;
		this.emailId =emailId;
		this.dob =dob;
		this.gender =gender;
		this.contactNo=contactNo;
		this.country =country;
		// password =password;
		this.profilePicturePath =profilePicturePath;
		this.shareUrl=shareUrl;
		this.userStatus =userStatus;
		this.setDefaultDeveloper(isDeveloper);
		this.emailVerificationId =verificationId;
		this.createdDate =createdDate;
		this.modifiedDate =modifiedDate;

	}

	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getProfilePicturePath() {
		return profilePicturePath;
	}
	public void setProfilePicturePath(String profilePicturePath) {
		this.profilePicturePath = profilePicturePath;
	}

	public String getShareUrl() {
		return shareUrl;
	}
	public void setShareUrl(String shareUrl) {
		this.shareUrl = shareUrl;
	}
	public UserStatusEnum getUserStatus() {
		return userStatus;
	}
	public void setUserStatus(UserStatusEnum userStatus) {
		this.userStatus = userStatus;
	}
	public long getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(long createdDate) {
		this.createdDate = createdDate;
	}
	public long getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(long modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public GenderEnum getGender() {
		return gender;
	}

	public void setGender(GenderEnum gender) {
		this.gender = gender;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public boolean isDefaultDeveloper() {
		return defaultDeveloper;
	}
	public void setDefaultDeveloper(boolean defaultDeveloper) {
		this.defaultDeveloper = defaultDeveloper;
	}
	@Override
	public void guid() { }
	
	public String getEmailVerificationId() {
		return emailVerificationId;
	}
	public void setEmailVerificationId(String verificationId) {
		this.emailVerificationId = verificationId;
	}
	public boolean isTwoFactorLogin() {
		return twoFactorLogin;
	}
	public void setTwoFactorLogin(boolean twoFactorLogin) {
		this.twoFactorLogin = twoFactorLogin;
	}
	public String getResetPasswordToken() {
		return resetPasswordToken;
	}
	public void setResetPasswordToken(String resetPasswordToken) {
		this.resetPasswordToken = resetPasswordToken;
	}

}
