package com.mwp.common;

import com.mwp.common.enums.InstallJobStatusEnum;

public class AppDetailVo implements ISkipObfuscation {
	
	private String id;
	private String appId;
	private String versionId;
	private String appPlatformId;
	private transient String encKey;
	private String userId;
	private String checksum;
	private InstallJobStatusEnum status;
	private String downloadPath="";
	private String  fileName;
	private String token;
	private String title;
	private String version;
	
	
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getDownloadPath() {
		return downloadPath;
	}
	public void setDownloadPath(String downloadPath) {
		this.downloadPath = downloadPath;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getAppId() {
		return appId;
	}
	public void setAppId(String appId) {
		this.appId = appId;
	}
	public String getVersionId() {
		return versionId;
	}
	public void setVersionId(String versionId) {
		this.versionId = versionId;
	}
	public String getAppPlatformId() {
		return appPlatformId;
	}
	public void setAppPlatformId(String appPlatformId) {
		this.appPlatformId = appPlatformId;
	}
	public String getEncKey() {
		return encKey;
	}
	public void setEncKey(String encKey) {
		this.encKey = encKey;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getChecksum() {
		return checksum;
	}
	public void setChecksum(String checksum) {
		this.checksum = checksum;
	}
	public InstallJobStatusEnum getStatus() {
		return status;
	}
	public void setStatus(InstallJobStatusEnum status) {
		this.status = status;
	}
	@Override
	public void guid() {
		// TODO Auto-generated method stub
		
	}


}
