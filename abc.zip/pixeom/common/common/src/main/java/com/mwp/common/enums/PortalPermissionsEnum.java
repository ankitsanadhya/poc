///**
// * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
// * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
// * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
// * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
// * IN STRICTEST CONFIDENCE.
// *
// * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
// * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
// * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
// * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
// * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
// * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
// * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// */
//package com.mwp.common.enums;
//
//import java.util.Hashtable;
//
//
///*
// * Enum for portal permissions 
// *
// */
//public enum PortalPermissionsEnum {
//
//	pull(0, "Install"),	
//	push(1, "Update"),
//	delete(2, "Delete"),
//	publish(3, "Publish"),
//	unpublish(4, "Unpublish"),
//	
//	installApps(5, "Install Apps"),
//	uninstallApps(6, "Uninstall Apps"),
//	swUpdateAppliance(7, "Software Updates"),
//	deleteOfflineAppliance(8, "Delete Offline Appliances"),
//	
//	//co admin
//	addServer(9, "Add Server"),
//	editServer(10,"Edit Server"),
//	listServer(11,"List Server"),
//	removeServer(12,"Remove Server"),
//	addRules(13, "Add Rules"),
//	updateRules(14, "Update Rules"),
//	listRules(15, "List Rules"),
//	removeRules(16,"Remove Rules"),
//	listEC(15, "List Appliance"),
//	listApp(16, "List Application"),
//	listVersions(17, "List Versions"),
//	getUserCount(18, "Get User Count"),
//	getAppCount(19, "Get Application Count"),
//	getECCount(20, "Get Appliance Count"),
//	suspendResume(21, "Suspend resume User"),
//	listAlerts(22, "List Alerts"),
//	getSettings(23, "Get Settings"),
//	
//	//support
//	generateToken(24, "Generate Token"),
//	listToken(25, "List Token"),
//	removeToken(26, "Remove Token"),
//	
//	//document
//	addDocument(27, "Add Document"),
//	editDocument(28, "Edit Document"),
//	deleteDocument(29, "Delete Document"),
//	
//	//update Manager
//	addSysUpdateApp(30, "Add System Update  Application"),
//	listSysUpdateApp(31,"List System Update Application"),
//	editSysUpdateApp(32, "Edit System Update Application"),
//	deleteSysUpdateApp(33, "Delete System Update Application"),
//	releaseSysUpdateApp(34, "Release System Update Application"),
//	addGroup(35, "Add Group"),
//	listGroup(36, "List Group"),
//	deleteGroup(37, "Delete Group"),
//	addUser(38, "Add Group Member"),
//	listUser(39, "List Group Member"),
//	deleteUser(40, "Delete Group Member"),
//	listRelease(41, "List Release");
//	
//	
//
//	int value = 0;
//	String displayName = "";
//
//	PortalPermissionsEnum(int value, String displayName) {
//		this.value = value;
//		this.displayName = displayName;
//		PortalPermissionsEnumMap.map.put(value, this);
//	}
//
//	public int getValue() {
//		return this.value;
//	}
//	
//	public String getDisplayName() {
//		return this.displayName;
//	}
//
//	public static PortalPermissionsEnum get(int value) {
//		return PortalPermissionsEnumMap.map.get(value);
//	}
//
//	static class PortalPermissionsEnumMap {
//		static Hashtable<Integer, PortalPermissionsEnum> map = new Hashtable<Integer, PortalPermissionsEnum>(); 
//	}
//}