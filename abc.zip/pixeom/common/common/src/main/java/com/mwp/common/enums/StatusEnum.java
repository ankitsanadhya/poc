/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */ 

package com.mwp.common.enums;

import java.util.Hashtable;

public class StatusEnum {

	public enum VERSION_STATUS {
		UPLOADING(0),  // Version upload inprogress by developer.
		REVIEWPENDING(1),  // Reviewed Pending by admin.
		SUSPENDED(2),  // Version suspend by developer.
		DELETED(3),     // Delete version by developer
		LIVE(4),        // Upload successfully version.
		REVIEWED(5),    // Reviewed by Admin.
		OLDRELEASED(6);  // when new version upload then set this staus to all old versions.

		private int num;
		VERSION_STATUS(int n) {
			num = n;
			VersionStatusList.map.put(num, this);
		}

		public int getValue() {
			return num;
		}

		public static VERSION_STATUS GetEnum(int statusType) {
			return VersionStatusList.map.get(statusType);
		}
	}

	static class VersionStatusList {
		static Hashtable<Integer, VERSION_STATUS> map = new Hashtable<Integer, VERSION_STATUS>();
	}
}
