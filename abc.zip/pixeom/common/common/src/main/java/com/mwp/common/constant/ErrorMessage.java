/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */ 

package com.mwp.common.constant;

public class ErrorMessage
{

	/**
	 * APPLICATION_NOT_FOUND = "Application not found"
	 */
	public final static String APPLICATION_NOT_FOUND = "Application not found";
	
	/**
	 * UNAUTHORIZED = "Unauthorized."
	 */
	public final static String UNAUTHORIZED = "Unauthorized";
	
	/**
	 * INTERNAL_SERVER_ERROR = "Internal server error"
	 */
	public final static String INTERNAL_SERVER_ERROR = "Internal server error";
	
	/**
	 * USER_ALREADY_EXISTS = "User already exists"
	 */
	public final static String USER_ALREADY_EXISTS = "User already exists";
	
	/**
	 * USER_NOT_FOUND = "User not found"
	 */
	public final static String USER_NOT_FOUND = "User not found";
	
	/**
	 * EMAIL_ID_NOT_FOUND = "Email id not found"
	 */
	public final static String EMAIL_ID_NOT_FOUND = "Couldn't find your account.";
	
	/**
	 * INVALID_RESET_LOGIN_TOKEN = "Invalid reset password token"
	 */
	public final static String  INVALID_RESET_LOGIN_TOKEN = "Invalid reset password token";
	
	
	/**
	 * INVALID_CREDENTIALS = "Invalid credentials"
	 */
	public final static String  INVALID_CREDENTIALS = "Invalid credentials. Try again.";
	
	/**
	 * INVALID_CODE = "Invalid code"
	 */
	public final static String  INVALID_CODE = "Invalid code";
	
	/**
	 * ALREADY_MEMBER = "Already member"
	 */
	public final static String  ALREADY_MEMBER = "Already member";
	
	/**
	 * CODE_LIMIT_EXCEED = "Code limit exceed"
	 */
	public final static String  CODE_LIMIT_EXCEED = "Code limit exceed";
	
	/**
	 * INVALID_GROUP = "Invalid group"
	 */
	public final static String  INVALID_GROUP = "Invalid group";
	
	/**
	 * GROUP_NOT_FOUND = "Group not found"
	 */
	public final static String GROUP_NOT_FOUND = "Group not found";
	
	/**
	 * INVALID_RESOURCE = "Invalid resource"
	 */
	public final static String  INVALID_RESOURCE = "Invalid resource";
	
	/**
	 * RESOURCE_NOT_FOUND = "Resource not found"
	 */
	public final static String  RESOURCE_NOT_FOUND = "Resource not found";
	
	/**
	 * INVALID_TOKEN = "Invalid token"
	 */
	public final static String  INVALID_TOKEN = "Invalid token";
	
	 /**
	  * TOKEN_EXPIRED = "Token expired"
	  */
	 public final static String  TOKEN_EXPIRED = "Token expired";
	
	/**
	 * INVALID_EMAIL = "Invalid email"
	 */
	public final static String  INVALID_EMAIL = "Invalid email";
	
	/**
	 * VERIFICATION_FAILED = "Verification failedl"
	 */
	public final static String  VERIFICATION_FAILED = "Verification failed";
	
	/**
	 * ALREADY_APPROVED = "Email already approved"
	 */
	public final static String  ALREADY_APPROVED = "Email already approved";

	/**
	 * EMAIL_VERIFICATION_PENDING = "Email verification pending."
	 */
	public final static String  EMAIL_VERIFICATION_PENDING = "Email verification pending";
	
	/**
	 * GROUP_APPLICATION_EXIST = "Group application already exist."
	 */
	public final static String  GROUP_APPLICATION_EXIST = "Application already exists in group.";
	
	/**
	 * GROUP_APPLICATION_ADD_FAILED = "Adding application to group failed."
	 */
	public final static String  GROUP_APPLICATION_ADD_FAILED = "Adding application to group failed.";
	
	/**
	 * INSERT_CODE = "Insert code"
	 */
	public final static String  INSERT_CODE = "Insert code";
	
	/**
	 * DEVICE_NOT_FOUND = "Device not found."
	 */
	public final static String DEVICE_NOT_FOUND = "Device not found.";
	
	/**
	 * CLUSTER_NOT_FOUND = "Cluster not found."
	 */
	public final static String CLUSTER_NOT_FOUND = "Cluster not found.";
	
	
	/**
	 * Master_Delete_Request = "Can not delete Master Device.".
	 */
	public final static String MASTER_DELETE_REQUEST = "Can not delete Master Device.";
	
	/**
	 * Not_Enough_Resources_Available = "Appliance does not have enough resources required to run the application."
	 */
	public final static String NOT_ENOUGH_RESOURCES_AVAILABLE = "Appliance does not have enough resources required to run the application.";
	
	/**
	 * GROUP_EDGECORE_EXIST = "Device application already exist."
	 */
	public final static String  GROUP_EDGECORE_EXIST = "Device already exists in group.";
	
	/**
	 * GROUP_RESOURCE_EXIST = "Resource already exists in group.";
	 */
	public final static String  GROUP_RESOURCE_EXIST = "Resource already exists in group.";
	
	/**
	 * GROUP_EDGECORE_ADD_FAILED = "Adding device to group failed."
	 */
	public final static String  GROUP_EDGECORE_ADD_FAILED = "Adding device to group failed.";
	
	/**
	 * GROUP_RESOURCE_ADD_FAILED = "Adding resource to group failed.";
	 */
	public final static String  GROUP_RESOURCE_ADD_FAILED = "Adding resource to group failed.";
	
	/**
	 * NETWORK_EXIST = "Network already exists."
	 */
	public final static String  NETWORK_EXIST = "Network already exists.";
	
	/**
	 * APP_NETWORK_EXIST = "Application already exists in network."
	 */
	public final static String  APP_NETWORK_EXIST = "Application already exists in network.";
	
	/**
	 * Device_Name_Not_Available = "Device name not available."
	 */
	public final static String  DEVICE_NAME_NOT_AVAILABLE = "Device name not available.";
	
	/**
	 * Invalid_License = "Invalid License."
	 */
	public final static String  INVALID_LICENSE = "Invalid License.";
	
	/**
	 * REPO_NAME_TAKEN = "Repository name already exists."
	 */
	public final static String REPO_NAME_TAKEN = "Repository name already exists.";
}
