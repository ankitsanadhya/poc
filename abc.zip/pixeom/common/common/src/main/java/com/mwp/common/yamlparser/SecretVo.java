/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.mwp.common.yamlparser;

import java.util.ArrayList;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.mwp.common.ISkipObfuscation;
import com.mwp.common.enums.SecretTypeEnum;

public class SecretVo implements ISkipObfuscation {



	private String appSecretId;
	private String appId;
	
//	@Size(min = 2, max = 255, message = "The length of service name should be between 2 to 255")
//	@Pattern( regexp = "^[a-zA-Z0-9](?:[-_]*[A-Za-z0-9]+)*$" ,message = "Invalid service name")
	private String serviceName;
	
	@Size(min = 2, max = 64, message = "The length of secret key should be between 2 to 64")
	@Pattern( regexp = "^[a-zA-Z0-9](?:[-._]*[A-Za-z0-9]+)*$" ,message = "Invalid secret key")
	private String secretKey;
	
	private SecretTypeEnum secretType;
	private String path;
	private String fileName;
	private ArrayList<SecretVersionVO> listSecretVersion = new ArrayList<>();
	private String configType;
	private boolean isChanged;
	private boolean isRetain;
	private String localPath;
	private boolean optionalSecret;
	private boolean updateYml;
	private String tempPath;
	
	public String getTempPath() {
		return tempPath;
	}

	public void setTempPath(String tempPath) {
		this.tempPath = tempPath;
	}

	public boolean isUpdateYml() {
		return updateYml;
	}

	public void setUpdateYml(boolean updateYml) {
		this.updateYml = updateYml;
	}
	
	public boolean isOptionalSecret() {
		return optionalSecret;
	}
	public void setOptionalSecret(boolean optionalSecret) {
		this.optionalSecret = optionalSecret;
	}
	
	
	public String getLocalPath() {
		return localPath;
	}

	public void setLocalPath(String localPath) {
		this.localPath = localPath;
	}

	public boolean isChanged() {
		return isChanged;
	}
	
	public boolean isRetain() {
		return isRetain;
	}

	public void setRetain(boolean isRetain) {
		this.isRetain = isRetain;
	}

	public void setChanged(boolean isChanged) {
		this.isChanged = isChanged;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getKey() {
		return secretKey;
	}

	public void setKey(String key) {
		this.secretKey = key;
	}

	public SecretTypeEnum getType() {
		return secretType;
	}

	public void setType(SecretTypeEnum type) {
		this.secretType = type;
	}

	@Override
	public void guid() {
		// TODO Auto-generated method stub
		
	}

	public String getAppSecretId() {
		return appSecretId;
	}

	public void setAppSecretId(String appSecretId) {
		this.appSecretId = appSecretId;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public String getAppId() {
		return appId;
	}

	public void setAppId(String appId) {
		this.appId = appId;
	}

	private String secretValue;
	
	public String getSecretValue() {
		return secretValue;
	}

	public void setSecretValue(String secretValue) {
		this.secretValue = secretValue;
	}

	public ArrayList<SecretVersionVO> getListSecretVersion() {
		setVersionLst(listSecretVersion);
		return listSecretVersion;
	}

	public void setListSecretVersion(ArrayList<SecretVersionVO> listSecretVersion) {
		this.listSecretVersion = listSecretVersion;
	}
	
	public String getConfigType() {
		return configType;
	}

	public void setConfigType(String configType) {
		this.configType = configType;
	}
	
	private void setVersionLst(ArrayList<SecretVersionVO> listSecretVersion)
	{
		if(listSecretVersion.size() == 0)// || listSecretVersion.get(0).getType() == null)
		{
			if(getType()!=null)
			{
				SecretVersionVO verionVo = new SecretVersionVO();
				verionVo.setType(getType());
				verionVo.setFileName(getFileName());
				verionVo.setPath(getPath());
				verionVo.setAppSecretVersionId(getAppSecretId());
				verionVo.setValue(getSecretValue());
				listSecretVersion.add(verionVo);
			}

		}
		else if(listSecretVersion.get(0).getType() == null)
		{
			listSecretVersion.get(0).setType(getType());
		}
	}
}
