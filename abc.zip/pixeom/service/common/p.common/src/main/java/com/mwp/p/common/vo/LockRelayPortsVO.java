/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.common.vo;

import com.mwp.common.ISkipObfuscation;

/**
  Model class for   Lock Relay Ports
 */
public class LockRelayPortsVO implements ISkipObfuscation {
	private String sDeviceID;
	private String sRelayServerID;
	private int nPortSegmentStart;
	private long dModified;
	
	/**
	 * @return the sDeviceID
	 */
	public String getsDeviceID() {
		return sDeviceID;
	}
	/**
	 * @param sDeviceID the sDeviceID to set
	 */
	public void setsDeviceID(String sDeviceID) {
		this.sDeviceID = sDeviceID;
	}
	/**
	 * @return the sRelayServerID
	 */
	public String getsRelayServerID() {
		return sRelayServerID;
	}
	/**
	 * @param sRelayServerID the sRelayServerID to set
	 */
	public void setsRelayServerID(String sRelayServerID) {
		this.sRelayServerID = sRelayServerID;
	}
	/**
	 * @return the nPortSegmentStart
	 */
	public int getnPortSegmentStart() {
		return nPortSegmentStart;
	}
	/**
	 * @param nPortSegmentStart the nPortSegmentStart to set
	 */
	public void setnPortSegmentStart(int nPortSegmentStart) {
		this.nPortSegmentStart = nPortSegmentStart;
	}
	/**
	 * @return the dModified
	 */
	public long getdModified() {
		return dModified;
	}
	/**
	 * @param dModified the dModified to set
	 */
	public void setdModified(long dModified) {
		this.dModified = dModified;
	}
	@Override
	public void guid() {

		//do nothing
	}
}
