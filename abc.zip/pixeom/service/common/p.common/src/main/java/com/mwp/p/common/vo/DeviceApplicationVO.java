/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.common.vo;

import com.mwp.common.ISkipObfuscation;
import com.mwp.common.enums.Status;
import com.mwp.common.vo.ApplicationDetailsVO;
import com.mwp.common.vo.VersionVO;

/**
 * Model class for  Device Application extends ApplicationDetailsVO 
 */
public class DeviceApplicationVO extends ApplicationDetailsVO implements ISkipObfuscation{
	private Status status;
	private long installationDate;
	private boolean isUpdateAvailable;
	private String deviceId;
	private String deviceApplicationId;
	private String deviceName;
	private String verionId;
	private VersionVO versionVO;

	public VersionVO getVersionVO() {
		return versionVO;
	}

	public void setVersionVO(VersionVO versionVO) {
		this.versionVO = versionVO;
	}

	public String getDeviceApplicationId() {
		return deviceApplicationId;
	}

	public void setDeviceApplicationId(String deviceApplicationId) {
		this.deviceApplicationId = deviceApplicationId;
	}

	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	public Status getStatus() {
		return this.status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public long getInstallationDate() {
		return this.installationDate;
	}

	public void setInstallationDate(long installationDate) {
		this.installationDate = installationDate;
	}

	public boolean getIsUpdateAvailable() {
		return this.isUpdateAvailable;
	}

	public void setIsUpdateAvailable(boolean isUpdateAvailable) {
		this.isUpdateAvailable = isUpdateAvailable;
	}

	public String getDeviceName() {
		return deviceName;
	}

	public void setDeviceName(String deviceName) {
		this.deviceName = deviceName;
	}

	@Override
	public void guid() {
		//do nothing
		
	}

	public String getVerionId() {
		return verionId;
	}

	public void setVerionId(String verionId) {
		this.verionId = verionId;
	}
}