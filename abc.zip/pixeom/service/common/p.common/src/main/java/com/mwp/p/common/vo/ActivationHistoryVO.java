/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.common.vo;

import com.mwp.common.ISkipObfuscation;

/**
 * Model class for activation history of device
 *
 */
public class ActivationHistoryVO implements ISkipObfuscation{
	
	private String activationHistoryId;
	private String deviceId;
	private String userId;
	private String macAddress;
	private String machineId;
	private String nativeAppId;
	private String action;
	private String actionON;
	
	public String getActivationHistoryId() {
		return activationHistoryId;
	}
	public String getDeviceId() {
		return deviceId;
	}
	public String getUserId() {
		return userId;
	}
	public String getMacAddress() {
		return macAddress;
	}
	public String getMachineId() {
		return machineId;
	}
	public String getNativeAppId() {
		return nativeAppId;
	}
	public String getAction() {
		return action;
	}
	public String getActionON() {
		return actionON;
	}
	public void setActivationHistoryId(String activationHistoryId) {
		this.activationHistoryId = activationHistoryId;
	}
	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public void setMacAddress(String macAddress) {
		this.macAddress = macAddress;
	}
	public void setMachineId(String machineId) {
		this.machineId = machineId;
	}
	public void setNativeAppId(String nativeAppId) {
		this.nativeAppId = nativeAppId;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public void setActionON(String actionON) {
		this.actionON = actionON;
	}
	@Override
	public void guid() {
		// Do nothing 
		
	}
}
