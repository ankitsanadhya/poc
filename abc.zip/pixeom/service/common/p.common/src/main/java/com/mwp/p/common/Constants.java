/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.common;

import java.io.File;
import java.io.FileReader;
import java.util.HashMap;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.mwp.common.constant.Constant;
import com.mwp.logger.PALogger;
import com.mwp.p.common.enums.DNS_SERVERS;
import com.mwp.p.common.vo.DownloadVO;

/*
 * Portal constants
 */
public class Constants {
	
	private Constants()
	{
		//private constructor to hide public
	}
	
	/**
	 * Added portal Kafka URL and port.
	 */

	private static String PLATEFORM_REPO = "";
	private static String clairAddress = "";
	private static String SERVER_ADDRESS = "";
	private static DNS_SERVERS DNS_SERVER;
	
	private static String domainName = "";	
	private static String projectName = "";
	private static String clusterName = "";
	private static String DNSZone = "";
	private static String zone = "";
	private static String dataDiskName = "";
	private static String relayServerDisk = "";
	private static boolean isRunningOnCluster = false;

	public static String getPLATEFORM_REPO() {
		return PLATEFORM_REPO;
	}
	public static String getClairAddress() {
		return clairAddress;
	}
	public static String getSERVER_ADDRESS() {
		return SERVER_ADDRESS;
	}
	public static DNS_SERVERS getDNS_SERVER() {
		return DNS_SERVER;
	}
	
	public static String getDomainName() {
		return domainName;
	}
	public static String getProjectName() {
		return projectName;
	}
	public static String getClusterName() {
		return clusterName;
	}
	public static String getDNSZone() {
		return DNSZone;
	}
	public static String getZone() {
		return zone;
	}
	public static String getDataDiskName() {
		return dataDiskName;
	}
	public static String getRelayServerDisk() {
		return relayServerDisk;
	}
	public static boolean isRunningOnCluster() {
		return isRunningOnCluster;
	}
	/**
	 * Portal Data folder name = "PortalCache"
	 */
	public final static String PORTAL_DATA_FOLDER_NAME = "PortalCache";

	/**
	 * Portal project folder name = "Project" 
	 */
	public final static String PORTAL_PROJECT_FOLDER_NAME = "Project";

	/**
	 * App folder name = "app"
	 */
	public final static String PORTAL_APP_FOLDER_NAME = "app";

	/**
	 * portal yml folder name = "app/yml"
	 */
	public final static String PORTAL_YML_FOLDER_NAME = "app/yml";

	/**
	 * Download asset folder name "assets"  
	 */ 
	public final static String DOWNLOAD_ASSETS_FOLDER_NAME = "assets";

	/**
	 * UI folder name = "pp"
	 */
	public final static String UI_FOLDER_NAME = "pp";

	/**
	 * portal application id	
	 */
	public final static String PORTAL_APPLICATION_ID="41ff73c9719a42bdb0348355114ceb82";


	/**
	 * portal user id = "admin"
	 */
	public final static String PORTAL_USER_ID="admin";

	/**
	 * auth server ip port = "https://localhost:443/" 
	 */ 
	public final static String AUTH_SERVER_IP_PORT="https://localhost:443/";

	/**
	 * auth service name = "a.service/api";
	 */
	public final static String AUTH_SERVICE_NAME="a.service/api";

	/**
	 * box service name =  "b.service/api"
	 */
	public final static String BOX_SERVICE_NAME="b.service/api";

	/**
	 * portal service name = "p.service/api"
	 */
	public final static String PORTAL_SERVICE_NAME="p.service/api";

	/**
	 * app version = "app_version";
	 */
	public final static String APPVERSION="app_version";


	// <summary>
	// Portal cache path that needs when we are creating base structure for portal
	// </summary>
	public final static String  PORTAL_CACHE_PATH = Constant.localFileSeparator+"data"+Constant.localFileSeparator+ PORTAL_DATA_FOLDER_NAME +Constant.localFileSeparator;
	
	/**
	 * Portal files folder name = "files"
	 */
	public final static String PORTAL_FILES_FOLDER_NAME = "files";
	
	// <summary>
	// Portal files path that needs when we are creating base structure for portal
	// </summary>
	public final static String  PORTAL_FILES_PATH = Constant.localFileSeparator+"data"+Constant.localFileSeparator+ PORTAL_FILES_FOLDER_NAME +Constant.localFileSeparator;
	
	
	
	/**
	 * Download asset folder name "assets"  
	 */ 
	public final static String PORTAL_FUNCTION_FOLDER_NAME = "functions";

	/**
	 * Get portal server ip address from file.
	 */
	static {
		try {
			JSONParser parser = new JSONParser();
			JSONObject obj = (JSONObject) parser.parse(new FileReader("/opt/app_engine/ListingServer"));

			Constants.domainName=obj.get("domainName").toString();
			Constants.projectName=obj.get("ProjectName").toString();
			Constants.clusterName=obj.get("ClusterName").toString();
			Constants.DNSZone = obj.get("DNSZone").toString();
			Constants.zone=obj.get("Zone").toString();
			Constants.dataDiskName=obj.get("DataDiskName").toString();
			Constants.relayServerDisk=obj.get("RelayServerDisk").toString();

			Constants.PLATEFORM_REPO=obj.get("portalRepo").toString();
			Constants.clairAddress = obj.get("clairAddress").toString();
			Constants.SERVER_ADDRESS = obj.get("domainName").toString();
			if(new File("/opt/app_engine/cluster").exists()){
				isRunningOnCluster = true;
			}

			Constants.DNS_SERVER = DNS_SERVERS.valueOf(Constant.getPxConfig().get("dnsServer").toString());


		}
		catch (Exception e) 
		{
			PALogger.ERROR(e);	
		}
	}

	/**
	 * download token has table contains secureToken as key DownloadVO as value
	 */
	private static HashMap<String, DownloadVO> downloadTokens = new HashMap<String, DownloadVO>();
	
	public static HashMap<String, DownloadVO> getDownloadTokens(){
		return	downloadTokens;
	}
	
	public static final String UNABLE_TO_LIST_APPLICATIONS = "Unable to list applications.";
	public static final String GROUP = "group";
	public static final String UNABLE_TO_REMOVE_RESOURCE_FROM_GROUP =  "Unable to remove resource from group";
	public static final String UNABLE_TO_RESERVE_PORT_FOR_APPLICATION =  "Unable to reserve port for application.";
	public static final String  UNABLE_TO_UPLOAD_APPLICATION_RESOURCE= "Unable to upload application resource.";
	public static final String  UNABLE_TO_GET_BOX_STATICS_LIST = "Unable to get box statics list.";
	public static final String SECRET= "secret";
	public static final String VERSION_ALREADY_EXISTS = "Version already exists";
	public static final String CLUSTER_DATA = "cluster data.";
	public static final String BIN_BASH = "/bin/bash";
	
	public static final String UNABLE_TO_LIST_INVITED_APPLICATION  = "Unable to list invited application";
	public static final String IAMAGES_APP_ICON_PATH = "/var/www/html/pp/images/appicons/";

}
