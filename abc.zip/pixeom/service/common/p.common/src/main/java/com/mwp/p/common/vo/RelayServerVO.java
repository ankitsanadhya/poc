/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.common.vo;

import com.mwp.common.ISkipObfuscation;

/**
 * Model class opf RelayServer 
 */
public class RelayServerVO implements ISkipObfuscation {

	private String sRelayServerID;
	private String sRelayServerAddress;
	private String sRelayName;
	private int nPortRangeStart;
	private int nPortRangeEnd;
	private String sDeviceLimit;
	private int deviceCount;
	private int sPriority;
	private int nStatus;
	private String sRUserName;
	private String sRPassword;
	//added property for open ssh host key
	private String sHostKey;
	private int nRPort;
	private long dModified;

	//number of ports which are still available
	private int freePort;
	
	/**
	 * @return the sRelayServerID
	 */
	public String getsRelayServerID() {
		return sRelayServerID;
	}
	/**
	 * @param sRelayServerID the sRelayServerID to set
	 */
	public void setsRelayServerID(String sRelayServerID) {
		this.sRelayServerID = sRelayServerID;
	}
	/**
	 * @return the sRelayServerAddress
	 */
	public String getsRelayServerAddress() {
		return sRelayServerAddress;
	}
	/**
	 * @param sRelayServerAddress the sRelayServerAddress to set
	 */
	public void setsRelayServerAddress(String sRelayServerAddress) {
		this.sRelayServerAddress = sRelayServerAddress;
	}
	/**
	 * @return the sRelayName
	 */
	public String getsRelayName() {
		return sRelayName;
	}
	/**
	 * @param sRelayName the sRelayName to set
	 */
	public void setsRelayName(String sRelayName) {
		this.sRelayName = sRelayName;
	}
	/**
	 * @return the nPortRangeStart
	 */
	public int getnPortRangeStart() {
		return nPortRangeStart;
	}
	/**
	 * @param nPortRangeStart the nPortRangeStart to set
	 */
	public void setnPortRangeStart(int nPortRangeStart) {
		this.nPortRangeStart = nPortRangeStart;
	}
	/**
	 * @return the nPortRangeEnd
	 */
	public int getnPortRangeEnd() {
		return nPortRangeEnd;
	}
	/**
	 * @param nPortRangeEnd the nPortRangeEnd to set
	 */
	public void setnPortRangeEnd(int nPortRangeEnd) {
		this.nPortRangeEnd = nPortRangeEnd;
	}
	/**
	 * @return the sDeviceLimit
	 */
	public String getsDeviceLimit() {
		return sDeviceLimit;
	}
	/**
	 * @param sDeviceLimit the sDeviceLimit to set
	 */
	public void setsDeviceLimit(String sDeviceLimit) {
		this.sDeviceLimit = sDeviceLimit;
	}
	/**
	 * @return the deviceCount
	 */
	public int getDeviceCount() {
		return deviceCount;
	}
	/**
	 * @param deviceCount the deviceCount to set
	 */
	public void setDeviceCount(int deviceCount) {
		this.deviceCount = deviceCount;
	}
	/**
	 * @return the sPriority
	 */
	public int getsPriority() {
		return sPriority;
	}
	/**
	 * @param sPriority the sPriority to set
	 */
	public void setsPriority(int sPriority) {
		this.sPriority = sPriority;
	}
	/**
	 * @return the nStatus
	 */
	public int getnStatus() {
		return nStatus;
	}
	/**
	 * @param nStatus the nStatus to set
	 */
	public void setnStatus(int nStatus) {
		this.nStatus = nStatus;
	}
	/**
	 * @return the sRUserName
	 */
	public String getsRUserName() {
		return sRUserName;
	}
	/**
	 * @param sRUserName the sRUserName to set
	 */
	public void setsRUserName(String sRUserName) {
		this.sRUserName = sRUserName;
	}
	/**
	 * @return the sRPassword
	 */
	public String getsRPassword() {
		return sRPassword;
	}
	/**
	 * @param sRPassword the sRPassword to set
	 */
	public void setsRPassword(String sRPassword) {
		this.sRPassword = sRPassword;
	}
	/**
	 * @return the nRPort
	 */
	public int getnRPort() {
		return nRPort;
	}
	/**
	 * @param nRPort the nRPort to set
	 */
	public void setnRPort(int nRPort) {
		this.nRPort = nRPort;
	}
	/**
	 * @return the dModified
	 */
	public long getdModified() {
		return dModified;
	}
	/**
	 * @param dModified the dModified to set
	 */
	public void setdModified(long dModified) {
		this.dModified = dModified;
	}
	@Override
	public void guid() {
		// do nothing
		
	}
	public int getFreePort() {
		return freePort;
	}
	public void setFreePort(int freePort) {
		this.freePort = freePort;
	}
	public String getsHostKey() {
		return sHostKey;
	}
	public void setsHostKey(String sHostKey) {
		this.sHostKey = sHostKey;
	}
}
