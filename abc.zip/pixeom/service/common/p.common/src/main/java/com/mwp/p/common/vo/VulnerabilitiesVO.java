/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.mwp.p.common.vo;

import java.util.HashMap;
import java.util.Map;

import com.mwp.common.ISkipObfuscation;

public class VulnerabilitiesVO implements ISkipObfuscation {
	
private String name;
private String namespaceName;
private String description;
private String link;
private String severity;
private Object metadata;
private String fixedBy;
private Map<String, Object> additionalProperties = new HashMap<>();

public String getName() {
return name;
}

public void setName(String name) {
this.name = name;
}

public String getNamespaceName() {
return namespaceName;
}

public void setNamespaceName(String namespaceName) {
this.namespaceName = namespaceName;
}

public String getDescription() {
return description;
}

public void setDescription(String description) {
this.description = description;
}

public String getLink() {
return link;
}

public void setLink(String link) {
this.link = link;
}

public String getSeverity() {
return severity;
}

public void setSeverity(String severity) {
this.severity = severity;
}

public Object getMetadata() {
return metadata;
}

public void setMetadata(Object metadata) {
this.metadata = metadata;
}

public String getFixedBy() {
return fixedBy;
}

public void setFixedBy(String fixedBy) {
this.fixedBy = fixedBy;
}

public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}
	@Override
	public void guid() {
		// do nothing
		
	}

}
