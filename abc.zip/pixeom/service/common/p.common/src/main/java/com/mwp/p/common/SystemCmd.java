/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.common;

import java.util.ArrayList;
import java.util.List;

import com.mw.appliance.commandExecutor.TransactionCommand;
import com.mwp.logger.PALogger;

/**
 * This class provide method to run system command  
 *
 */
public class SystemCmd {
	
	private static SystemCmd systemCmd;
	public static SystemCmd getInstance()
	{
		if(systemCmd == null)
			systemCmd = new SystemCmd();

		return systemCmd;
	}
	
	/**
	 * Create source path shortcut folder on target path.  
	 * @param sourcePath source folder path 
	 * @param targetPath target shortcut path  
	 * @return result of the command.
	 * @throws Exception
	 */
	public String createDeviceCacheShortcut(String sourcePath, String targetPath) throws Exception {
		List<Object> arguments = new ArrayList<>();
		arguments.add("RunCommand");
		arguments.add("ln -sf "+ sourcePath +" " + targetPath);
		TransactionCommand tCmd = new TransactionCommand("SystemCommand", arguments);
		tCmd.execute();
		String result = tCmd.command.Result;
		PALogger.INFO(result);
		return result;

	}
}
