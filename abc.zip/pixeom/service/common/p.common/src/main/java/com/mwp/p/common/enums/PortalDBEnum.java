/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.common.enums;

/**
 * Enum : Portal database table names
 *
 */
public class PortalDBEnum {

	public enum TABLE_NAMES
	{
		application,
		applicationcategories,
		applicationconfigurations,
		applicationfilter,
		applicationimages,
		applicationserviceendpoints,
		applicationversions,
		category,
		company,
		deviceapplications,
		devices,
		groupapplications,
		groupapplicationversions,
		project,
		activations,
		activationhistory,
		//enums added for tables sortorder and filters
		sortorders, 
		filters,
		//enums added for tables adZone
		adZone,
		//added for table email server
		emailServers,
		discoveryjardetails,
		assignedrelayports,
		discoverydetails,
		//		listing,
		lockrelayports,
		relayservers,
		validationInfo,
		functions,
		functionversions,
		servicefunction,
		boxStatics,
		supportrelayservers,
		supportlockrelayports,
		supportassignedrelayports,
		labels,
		devicelabelmap, 
		installJobs,
		platform,
		applicationplatform,
		/*
		 * enums add for table applicationserviceports,
		 * which is used for save multiple internal-external port values. 
		 */
		applicationserviceports,
		dockerEventLog,
		applicationType,
		nodes,
		activityLog,
		virtualURLMap,
		rule,
		ruleTriggerLog,
		groupEdgeCore,
		settings,
		alerts,
		network,
		applicationNetwork,
		//RD_01
		projectsDoc,
		projectdocuments,
		
		//MPH
		projectDocumentsVersion,
		appSecret,
		jobSecret,
		groupResources,
		downloads,
		supportTokens, //#HDV_01
		appSecretVersion,
		applicationResources,
		appBackupTask,
		appBackupSync;
		
	}
	
		//#HDV_01
	public enum SUPPORTTOKENS
	{
		 supportTokenId,
		 token, 
		 nodeId,
		 hostName,
		 email,
		 userId, 
		 expiryTime,
		 status, 
		 modifiedon, 
		 createdon
	}

	public enum VIEW_NAMES
	{
		devicesnodes_view
	}

	public enum APPLICATION
	{
		appId,
		projectId,
		userId,
		title,
		//repositoryName,
		description,
		webAddress,
		//AKH_01
		secretKey,//add field in db for save app secretKey.
		icon,
		appStatus,
		appTypeId,
		usePxAuth,
		usePxEventService, 
		usePxCloudApi, 
		signUpType,
		//Added currency, price and rating for filters on UI.
		price,
		rating,
		currency,
		runAsService,
		createdDate,
		modifiedDate
	}

	public enum APPLICATION_CATEGORIES
	{
		appId,
		catId
	}

	public enum APPLICATION_FILTER
	{
		filterId,
		filterName,
		filterDetails,
		appFilterStatus,
		createdDate,
		modifiedDate
	}

	public enum APPLICATION_IMAGES
	{
		appImageId,
		appId,
		imagePath,
		sequenceNo
	}

	public enum APPLICATION_SERVICE_ENDPOINTS
	{
		appServiceEndpointId,
		appId,
		appVersionId,
		platformId,
		serviceName,
		protocol,
		containerPort,
		imageName,
		customHeaders
	}

	/*
	 * enums add for table applicationserviceports,
	 * which is used for save multiple internal-external port values. 
	 */
	public enum APPLICATION_SERVICE_PORTS{
		appServicePortId,
		appVersionId,
		serviceName,
		internalPort,
		externalPort
	}

	public enum APPLICATION_VERSIONS
	{
		appVersionId,
		appId,
		appPlatformId,
		projectId,
		composerFilePath,
		appVersion,
		versionStatus,
		releaseNotes,
		size,
		//AKH_01
		redirectUrl,
		restRedirectUrl,
		redirectSection,
		redirectType,
		createdDate,
		modifiedDate,
		toExecuteOrder,
		composeVersion
	}

	public enum CATEGORY
	{
		catId,
		userId,
		name,
		type,
		catStatus,
		createdDate,
		modifiedDate
	}

	public enum COMPANY
	{
		companyId,
		userId,
		projectId,
		companyName,
		icon,
		address,
		city,
		state,
		country,
		postalCode,
		webAddress,
		phone,
		email,
		companyStatus,
		createdDate,
		modifiedDate
	}

	public enum DEVICE_APPLICATIONS
	{
		deviceAppId,
		deviceId,
		appId,
		appVersionId,
		deviceAppstatus,
		createdDate,
		modifiedDate
	}

	public enum DEVICES
	{
		deviceId,
		userId,
		deviceName,
		deviceStatus,		
		platformId,
		swPlatformId,
		tags,
		description,
		action,
		isActivationConfirmed,
		deviceType,
		createdDate, 
		modifiedDate
	}

	public enum NODES
	{
		nodeId,
		deviceName,
		softwareVersion,
		hardwareInfo,
		macAddress,
		hostName,
		email,
		supportToken,
		tags,
		description,
		machineId,
		nativeAppId,
		action,
		deviceRole,
		deviceState,//Added column to keep value for master is active or not.-PS
		deviceId,
		network,
		createdDate,
		modifiedDate
	}


	public enum DEVICES_NODES_VIEW
	{
		devices_deviceId,
		devices_userId,
		devices_deviceName,
		devices_deviceStatus,
		devices_platformId,
		devices_swPlatformId,
		devices_tags,
		devices_description,
		devices_action,
		devices_isActivationConfirmed,
		devices_deviceType,
		devices_createdDate, 
		devices_modifiedDate,
		nodes_nodeId,
		nodes_deviceName,
		nodes_softwareVersion,
		nodes_hardwareInfo,
		nodes_macAddress,
		nodes_hostName,
		nodes_supportToken,
		nodes_tags,
		nodes_description,
		nodes_machineId,
		nodes_nativeAppId,
		nodes_action,
		nodes_deviceRole,
		nodes_deviceState, // Added colum according to nodes table changes.-PS
		nodes_deviceId,		
		nodes_createdDate,
		nodes_modifiedDate
	}

	public enum GROUP_APPLICATIONS
	{
		groupAppId,
		groupId,
		appId
	}

	public enum GROUP_APPLICATION_VERSIONS
	{
		groupAppVersionId,
		groupAppId,
		appVersionId
	}

	public enum PROJECT
	{
		projectId,
		userId,
		name,
		description,
		icon,
		projectStatus,
		createdDate,
		modifiedDate,
		companyId
	}

	public enum ACTIVATION_HISTORY
	{
		activationHistoryId,
		deviceId,
		userId,
		macAddress,
		machineId,
		nativeAppId,
		action,
		actionON
	}
	//enums added for filters.
	public enum FILTERS {
		filterId,
		filterGroupName,
		filterName
	}

	//enums added for sortorders.
	public enum SORTORDERS {
		sortId,
		sortGroupName,
		sortName
	}

	//column for table adZone
	public enum AD_ZONE
	{
		adId,
		appId,
		categoryId,
		type,
		zoneId,
		sortOrder,
		modifiedDate
	}


	//enum for ad type
	public enum AD_TYPE
	{
		defaultBanner,
		appBanner,

	}
	//column for table emailServers
	public enum EMAIL_SERVERS
	{
		serverId,
		serverAddress,
		serverName,
		status,
		username,
		password,
		port,
		priority,
		istls,
		modifiedDate
	}

	public enum DISCOVERY_JAR_DETAILS {
		sMACAddress,
		sHostName, 
		sRingID,
		sMasterID,
		nNodeStatus, 
		sIPAddress,
		sLocalIPAddress,
		sChatInputChannel,
		sChatOutputChannel,
		sChatSubscriptionChannel,
		sNodeCommunicationPort,
		sOpenStackPort,
		sKeyStonePort,
		sTomcatPort,
		sPort1, 
		sPort2, 
		sPort3, 
		sPort4, 
		sPort5, 
		sRURLTomcatPort,
		sRURLKeystonePort,
		sRAddress, 
		nStatus, 
		nIsDeleted,
		sConnectURL,
		nAdult,
		dHBRdate, 
		sNetworkType,
		sRelayServerID
	}

	public enum ASSIGNED_RELAY_PORTS {
		sDeviceID,
		sRelayServerID,
		nPortSegmentStart,
		nStatus,
		dModified,
	}

	public enum DISCOVERY_DETAILS {
		sDeviceID,
		sRingID,
		sMasterID,
		nNodeStatus, 
		sIPAddress,
		sLocalIPAddress,
		sChatInputChannel,
		sChatOutputChannel,
		sChatSubscriptionChannel,
		sNodeCommunicationPort, 
		sOpenStackPort,
		sKeyStonePort,
		sTomcatPort,
		sPort1, 
		sPort2, 
		sPort3, 
		sPort4, 
		sPort5, 
		sRURLTomcatPort, 
		sRURLKeystonePort,
		sRAddress,
		nStatus,
		sConnectURL,
		nAdult,
		dHBRdate,
		sRelayServerID,
		sNetworkType,
	}


	public enum LOCK_RELAY_PORTS {
		sDeviceID,
		sRelayServerID,
		nPortSegmentStart,
		dModified,
	}

	public enum RELAY_SERVERS {
		//Added column autoId for auto increment primary key -PS Bug 586
		autoId,
		sRelayServerID,
		sRelayServerAddress,
		sRelayName,
		nPortRangeStart,
		nPortRangeEnd,
		sDeviceLimit,
		nStatus,
		sRUserName,
		sRPassword,
		sHostKey,
		nRPort, 
		sPriority,
		dModified,
	}

	public enum VALIDATION_INFO {
		sMACAddress,
		sGUID,
		nStatus, 
		nTimestamp,
		sInternetAddress,
		dCreated,
		sCode,
		nPreviousTS,
	}

	public enum BOX_STATICS {
		deviceId,
		statics,
		modifiedDate
	}

	public enum FUNCTIONS{
		functionId,
		userId,
		name,
		modifiedDate
	}

	public enum FUNCTION_VERSIONS{
		functionVersionId,
		functionId,
		version,
		body,
		toExecute,
		modifiedDate
	}

	public enum SERVICE_FUNCTION{
		serviceFunctionId,
		userId,
		appId,
		serviceId,
		functionVersionId,
		modifiedDate
	}

	public enum  SUPPORT_RELAY_SERVERS {
		//Added column autoId for auto increment primary key -PS Bug 586
		autoId,
		sRelayServerID,
		sRelayServerAddress,
		sRelayName,
		nPortRangeStart,
		nPortRangeEnd,
		sDeviceLimit,
		nStatus,
		sRUserName,
		sRPassword,
		sHostKey,
		nRPort, 
		sPriority,
		dModified,
	}


	public enum SUPPORT_LOCK_RELAY_PORTS {
		sDeviceID,
		sRelayServerID,
		nPortSegmentStart,
		dModified
	}

	public enum SUPPORT_ASSIGNED_RELAY_PORTS {
		sDeviceID,
		sRelayServerID,
		nPortSegmentStart,
		nStatus,
		dModified
	}

	public enum LABELS
	{
		labelId,
		labelName,
		parentLabelId,
		userId
	}

	public enum DEVICE_LABEL_MAP
	{
		labelId,
		deviceId
	}

	public enum INSTALL_JOBS
	{
		uId, //unique id the schedule job
		/**
		 * device id or label id
		 */
		objectId, // the object id can be id of the label or device		
		type, //the type of the id 
		timeStamp, //Timestamp when to run the job 
		status, //status of install job it may be Pending/Sent
		userId,//user id
		appId, //the app to be installed
		appVersion, // the version number  of the app that can be null
		lastModified,//the datetime when status update
		operation,//the operation which is to be carried out
		message, //to save error message etc
		detail // detail to save any error message or information 
	}

	public enum PLATFORM {
		platformId,
		platformName,
		platformActualName,
		ordervalue,
		modifiedDate
	}

	public enum APPLICATION_PLATFORM {
		appPlatformId,
		platformId,
		appId,
		repositoryName,
		modifiedDate
	}

	public enum DOCKER_EVENT_LOG
	{
		id,
		applicationId,
		versionId,
		deviceId,
		event,
		systemStatus,
		createdDate

	}
	public enum APPLICATION_TYPE 
	{
		typeId,
		type,
		typeDisplayName

	}
	
	public enum ACTIVITY_LOG
	{
		id,
		timeStamp,
		action,
		userId,
		param
		

	}

	public enum VIRTUAL_URL_MAP
	{
		virtualMapId,
		virtualDomainName,
		deviceId,
		userId,
		createdDate,
		modifiedDate
	}
	
	public enum RULE
	{
		ruleId,
		ruleValue,
		ruleType,
		serverType,
		isKub
	}
	
	public enum RULE_TRIGGER_LOG
	{
		id,
		ruleId,
		startTime,
		endTime,
		stage,
		status,
		info
	}
	
	public enum GROUP_EDGECORE
	{
		groupEdgeCoreId,
		groupId,
		edgeCoreId
	}
	
	public enum SETTINGS {
		settingsKey,
		settingsValue
	}
	
	public enum SETTINGS_KEY{
		logLevelInfo,
		logLevelTrace,
		logLevelWarn,
		logLevelError
	}
	
	public enum ALERTS
	{
		alertId,
		alertType,
		messageType, 
		info,
		commandMessage, 
		createdDate
	}
	
	public enum NETWORK
	{
		networkId,
		networkName, 
		userId,
		networkType,
		createdDate
	}
	public enum APPLICATION_NETWORK
	{
		appNetId,
		appId,
		networkId
	}
	
	public enum PRORJECTS_DOC
	{
		 projectId, 
		 name, 
		 lastmodified,
		 userId		
	}

	public enum PRORJECT_DOCUMENTS
	{
		  documentId,	
		  projectId, 
		  name,
		  documentIndex,//Added field projectIndex for maintaining index...RD 
		  path,
		  //content, //Shifted to PRORJECT_DOCUMENTS_VERSIONS table
		  lastmodified, 
		  userId 	
	}
	
	public enum PRORJECT_DOCUMENTS_VERSIONS
	{
		versionId,
		documentId,	
		versionNumber, 
		status,
		userId,
		content,
		createdDate,
		lastmodified
	}
	public enum APP_SECRET
	{
		appSecretId,
		appId,	
		serviceName, 
		secretKey,
		displayName,
		configType,
		secretValue,
		createdDate,
		modifiedDate
	}
	
	public enum JOB_SECRET
	{
		jobSecretId,
		appSecretVersionId,
		edgeCoreId,	
		jobId, 
		serviceName, 
		createdDate,
		modifiedDate
	}
	
	/*
	 * Add table for updateSecret task it is child table of appSecret
	 * which maintain secret multiple values.
	 */
	public enum APP_SECRET_VERSION
	{
		appSecretVersionId,
		appSecretId,
		appUserId,
		displayName,
		type,
		secretValue,
		createdDate,
		modifiedDate
	}
	
	public enum GROUP_RESOURCES
	{
		groupResouceId,
		groupId,
		resourceId,
		resourceType
	}

	public enum DOWNLOADS
	{
		resourceId,
		resourceType,
		details,
		sortOrder
	}

	public enum APPLICATION_RESOURCES {
		resourceId,
		appId,
		kind,
		serviceName,
		isEncrypted,
		path,
		createdDate,
		modifiedDate
	}

	public enum APP_BACKUP_TASK {
		/**
		 * Primary key of backup task
		 */
		backupTaskId,
		/**
		 * Ark backup name 
		 */
		arkBackupName,
		/**
		 * Platform Name 
		 */
		platformName,
		/**
		 * Cluster Id 
		 */
		clusterId,
		/**
		 * Cluster Name
		 */
		clusterName,		
		/**
		 * Application ID
		 */
		applicationId,
		/**
		 * Application Name
		 */
		appName,
		/**
		 * App version Id
		 */
		appVersionId,
		/**
		 * App Version
		 */
		appVersion,
		/**
		 * backup status Active/Deleted
		 */
		status,
		/**
		 * backup started time
		 */
		startedTime,
		/**
		 * backup completed time
		 */
		completedTime,
	}
	
	public enum APP_BACKUP_SYNC {
		/**
		 * Cluster Id 
		 */
		clusterId,
		/**
		 * User Id 
		 */
		userId,
		/**
		 * backup status Active/Deleted
		 */
		status,
		/**
		 * backup started time
		 */
		requestedTime
	}
}

/**
 * History of check-in or issue resolved
 * 
 * 01 - 14-11-2016 AKH_01
 * Add restRedirectUrl, redirectUrl, redirectType and redirectSection these property shift from application to applicationVersion,
 * because may be each version have different redirection param.
 * 
 * 01 - 25-o4-2018
 * enums added for tables projectsDoc and projectdocuments for document view - RD,PSP	
 * 
 * #HDV_01
 *  01 - 01-o8-2018
 * enums added for table supportTokens as-SUPPORTTOKENS
 * add a field in DEVICES_NODES_VIEW HDV	
 * 	
 */
