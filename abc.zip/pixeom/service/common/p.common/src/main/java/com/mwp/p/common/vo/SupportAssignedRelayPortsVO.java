/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.common.vo;

import com.mwp.common.ISkipObfuscation;

/**
 * Model class of Support assigned relay ports  
 */
public class SupportAssignedRelayPortsVO implements ISkipObfuscation{
	private String sDeviceId;
	private String sRelayServerId;
	private int nPortSegmentStart;
	private int nStatus;
	private long dModified;
	
	/**
	 * @return the sDeviceId
	 */
	public String getsDeviceId() {
		return sDeviceId;
	}
	/**
	 * @param sDeviceID the sDeviceID to set
	 */
	public void setsDeviceId(String sDeviceId) {
		this.sDeviceId = sDeviceId;
	}
	/**
	 * @return the sRelayServerID
	 */
	public String getsRelayServerId() {
		return sRelayServerId;
	}
	/**
	 * @param sRelayServerID the sRelayServerID to set
	 */
	public void setsRelayServerId(String sRelayServerId) {
		this.sRelayServerId = sRelayServerId;
	}
	/**
	 * @return the nPortSegmentStart
	 */
	public int getnPortSegmentStart() {
		return nPortSegmentStart;
	}
	/**
	 * @param nPortSegmentStart the nPortSegmentStart to set
	 */
	public void setnPortSegmentStart(int nPortSegmentStart) {
		this.nPortSegmentStart = nPortSegmentStart;
	}
	/**
	 * @return the nStatus
	 */
	public int getnStatus() {
		return nStatus;
	}
	/**
	 * @param nStatus the nStatus to set
	 */
	public void setnStatus(int nStatus) {
		this.nStatus = nStatus;
	}
	/**
	 * @return the dModified
	 */
	public long getdModified() {
		return dModified;
	}
	/**
	 * @param dModified the dModified to set
	 */
	public void setdModified(long dModified) {
		this.dModified = dModified;
	}
	@Override
	public void guid() {
		// do nothing
		
	}
}
