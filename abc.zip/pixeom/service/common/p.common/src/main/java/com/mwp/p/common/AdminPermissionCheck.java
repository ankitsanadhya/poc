/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.mwp.p.common;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.mwp.common.constant.Constant;
import com.mwp.common.constant.PermissionResourceKeys;
import com.mwp.common.constant.PermissionResources;
import com.mwp.common.enums.RoleEnum;
import com.mwp.common.vo.AuthorizationsVO;

public class AdminPermissionCheck
{
	private AdminPermissionCheck() {
		throw new IllegalStateException("AdminPermissionCheck class");
	}

	public static void checkAdminPermission(AuthorizationsVO authorizationsVO, List<String> permissions,boolean checkForAnd) throws Exception
	{
		mcheckAdminPermission(authorizationsVO, permissions, checkForAnd);
	}
	private static void mcheckAdminPermission(AuthorizationsVO authorizationsVO, List<String> permissions, boolean checkForAnd) throws Exception
	{
		if(authorizationsVO.getRole() == RoleEnum.Admin) 
			return;
		finalPermisisonsToCheck(permissions);
		if(permissions.isEmpty())
			return;
		if(authorizationsVO.getGroupPermissions()==null || authorizationsVO.getGroupPermissions().isEmpty())
			throw new Exception(Constant.NOTPERMITTED);


		// Get List of groups for the given permission. 
		boolean permissionFound=false;


		List<String> lstpermission=new ArrayList<>();
		for (Object object : authorizationsVO.getGroupPermissions().entrySet())
		{
			Map.Entry pair = (Map.Entry) object;
			lstpermission.addAll((List<String>)pair.getValue());
		}
		for(String permission:permissions)
		{
			permissionFound=false;
			if(lstpermission.contains(permission))
			{
				permissionFound=true;
				if(!checkForAnd)   // boolean variable decides wheather check that permission lies within the list (Which came from authVo) or not. 
					break;
			}
			else if(checkForAnd)
				break;
		}

		if(!permissionFound)
			throw new Exception(Constant.NOTPERMITTED);

	}
	private static List<String> finalPermisisonsToCheck(List<String> permisison)
	{
		if(Constant.isWholePortalAccess())
		{
			List<String> checksToSkip = new ArrayList<>();
			checksToSkip.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_PROJECTS));
			checksToSkip.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_FUNCTIONS));
			checksToSkip.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_APPLIANCES));
			checksToSkip.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_SOFTWARE));
			checksToSkip.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_DOCS));
			checksToSkip.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_MODELS));

			permisison.removeAll(checksToSkip);
		}
		return permisison;
	}

}
