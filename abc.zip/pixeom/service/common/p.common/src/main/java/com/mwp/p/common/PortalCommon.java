/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.common;

import java.io.IOException;
import java.util.List;

import org.apache.commons.io.IOUtils;

import com.mwp.common.constant.Constant;
import com.mwp.common.enums.RelayEnum.NetworkTypeEnum;
import com.mwp.logger.PALogger;

/*
 * Supports common methods for portal.
 */
public class PortalCommon {

	private static PortalCommon portalCommon;
	public static PortalCommon getInstance()
	{
		if(portalCommon == null)
			portalCommon = new PortalCommon();

		return portalCommon;
	}
	
	/**
	 * Create public Url 
	 * @param imagePath
	 * @param uiFolderName
	 * @return
	 */
	public String createPublicUrl(String imagePath, String uiFolderName)
	{
		if(imagePath.contains(Constants.PORTAL_DATA_FOLDER_NAME)) {
			imagePath = imagePath.split(Constants.PORTAL_DATA_FOLDER_NAME)[1];
			return "https://localhost:443/"+uiFolderName + Constant.localFileSeparator + Constants.PORTAL_DATA_FOLDER_NAME + imagePath;
		}
		return "";
	}
	
	/**
	 * Executes the given command
	 * @param command
	 * @return
	 * @throws InterruptedException
	 * @throws IOException
	 */
	public String executeCommnad(List<String> command) throws InterruptedException, IOException {	
		Process p = null;
		String returnVal ="";

		try {
			ProcessBuilder pb = new ProcessBuilder(command);
			pb.redirectErrorStream(true);
			p = pb.start();

			returnVal = IOUtils.toString(p.getInputStream()); 

			IOUtils.closeQuietly(p.getOutputStream());
			PALogger.INFO(returnVal);
			IOUtils.closeQuietly(p.getInputStream());
			p.waitFor();
		} finally {
			if(p != null) {
				try {
					p.waitFor();
				} finally {
					p.destroy();
				}
			}
		}

		return returnVal;
	}
	
	/**
	 * return UI path = "pb"
	 * @return
	 */
	public String getUIPath() {
	    return "pb";
	}
	
	/**
	 * Check network type is relay or not.
	 * @param networkType
	 * @return  true if network type is one of RelayNR, RelayPF , RelayPFB or RelayWAN false otherwise.
	 */
	public boolean isRelay(NetworkTypeEnum networkType){
		if(networkType.ordinal() == NetworkTypeEnum.RelayNR.ordinal()
				||networkType.ordinal() == NetworkTypeEnum.RelayPF.ordinal()
				||networkType.ordinal() == NetworkTypeEnum.RelayPFB.ordinal()
				|| networkType.ordinal() == NetworkTypeEnum.RelayWAN.ordinal()){
			return true;
		}
		return false;
	}
}
