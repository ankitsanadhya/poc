/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.mwp.p.common.vo;

import com.google.gson.annotations.Expose;
import com.mwp.common.ISkipObfuscation;

public class SoftwareUpdatesVO implements ISkipObfuscation 
{
	@Expose()
	private String  categoryName;
	@Expose()
	private String  title;
	@Expose()
	private String  type;
	@Expose()
	private String  description;
	@Expose()
	private String  key;
	@Expose()
	private String  version;
	@Expose()
	private boolean  pwdRequired;
	@Expose()
	private boolean  isExternalDownload;//if external build is true then the link will be of public cloud otherwise from portal  
	
	@Expose(serialize = false)
    private String password;
	
	@Expose()
	private boolean isUpdatesAvailable;
	
	@Expose()
	private String accessKey;	
	
	@Expose()
	private String secretKey;	
	
	@Expose()
	private String cloudPath;
	
	
	public boolean isUpdatesAvailable() {
		return isUpdatesAvailable;
	}
	public void setUpdatesAvailable(boolean isUpdatesAvailable) {
		this.isUpdatesAvailable = isUpdatesAvailable;
	}
	public String getCategoryName() {
		return categoryName;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	public boolean isPwdRequired() {
		return pwdRequired;
	}
	public void setPwdRequired(boolean pwdRequired) {
		this.pwdRequired = pwdRequired;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
		
	public boolean isExternalDownload() {
		return isExternalDownload;
	}
	public void setExternalDownload(boolean isExternalDownload) {
		this.isExternalDownload = isExternalDownload;
	}
	
	public String getAccessKey() {
		return accessKey;
	}
	public void setAccessKey(String accessKey) {
		this.accessKey = accessKey;
	}
	public String getSecretKey() {
		return secretKey;
	}
	public void setSecretKey(String secretKey) {
		this.secretKey = secretKey;
	}

	public String getCloudPath() {
		return cloudPath;
	}
	public void setCloudPath(String cloudPath) {
		this.cloudPath = cloudPath;
	}
	
	@Override
	public void guid() {
		// do nothing
		
	}

}
