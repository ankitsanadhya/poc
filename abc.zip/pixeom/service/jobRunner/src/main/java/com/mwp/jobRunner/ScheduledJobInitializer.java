/** 
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com) 
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL 
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC. 
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD 
 * IN STRICTEST CONFIDENCE. 
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */ 

package com.mwp.jobRunner;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.mwp.common.Client;
import com.mwp.common.CredProvider;
import com.mwp.common.ScheduledJobDetails;
import com.mwp.common.constant.PermissionResourceKeys;
import com.mwp.common.constant.PermissionResources;
import com.mwp.common.enums.PermissionOperationEnum;
import com.mwp.common.interfaces.IScheduledJob;
import com.mwp.common.vo.ManagePermissionVO;
import com.mwp.common.vo.PermissionLabelVO;
import com.mwp.common.vo.PermissionVO;
import com.mwp.common.vo.RoleVO;
import com.mwp.logger.PALogLevel;
import com.mwp.logger.PALogger;
import com.mwp.p.common.Constants;
import com.mwp.p.common.enums.PortalDBEnum.SETTINGS_KEY;
import com.mwp.p.framework.Settings;



/**
 * This class use for schedule jobs.
 * @author pixeom
 *
 */
public class ScheduledJobInitializer {

	/**
	 * List of running jobs
	 */
	private List<String> runningJobs = new ArrayList<>();

	/**
	 * List of jobs need to start, add jobs in constructor
	 */
	private List<ScheduledJobDetails> jobClasses = new ArrayList<>();

	/**
	 * Default empty private Constructor
	 * Put you jobs implements with "IScheduledJob" interface,
	 * to start before server startup.
	 * Put FQDN of class. 
	 */
	private ScheduledJobInitializer() {
		jobClasses.add(new ScheduledJobDetails("com.mwp.p.service.PortalStartEndpoint"));
		jobClasses.add(new ScheduledJobDetails("com.mwp.p.application.jobs.DownloadLinksScrubber"));
		jobClasses.add(new ScheduledJobDetails("com.mwp.p.framework.job.AppBackupSyncJob"));
		jobClasses.add(new ScheduledJobDetails("com.mwp.p.application.jobs.HeapMonitor"));
	}

	/**
	 * 
	 * private inner static class.
	 * <p>
	 * When the singleton class is loaded, SingletonHelper class is not loaded into memory 
	 * and only when someone calls the getInstance method, this class gets loaded 
	 * and creates the Singleton class instance. It doesn’t require synchronization.
	 *
	 */
	private static class SingletonHelper {
		private static final ScheduledJobInitializer INSTANCE = new ScheduledJobInitializer();
	}

	/**
	 * @return the Singleton Instance of the class ScheduledJobInitializer
	 */
	public static ScheduledJobInitializer getInstance() {
		return SingletonHelper.INSTANCE;
	}

	/**
	 * Initialize all jobs in "jobClasses" list.
	 * For each job of object "ScheduledTaskDetails", 
	 * it creates new Thread and set in to  ScheduledTaskDetails object.
	 * In thread implementation it get the class from reflection and cast it with "IScheduledJob" 
	 * and calls "init" method of the interface.
	 */
	public void init() {		
		try {

			for (ScheduledJobDetails job : jobClasses) {
				if(!runningJobs.contains(job.getName())) {
					final String className = job.getName();
					job.setJobThread((new Thread(new Runnable() {
						public void run() {
							try {
								IScheduledJob obj = (IScheduledJob)Class.forName(className).getConstructor().newInstance();

								runningJobs.add(className);
								obj.init();
							} catch (Exception e) {
								PALogger.ERROR(e);	
							}
						}
					}, className)));
					job.Start();
				}
			}
		} catch(Exception e) {
			PALogger.ERROR(e);	
			try {
				Thread.sleep(5000);
			} catch (InterruptedException ex) {
				PALogger.ERROR(ex);	
				//Thread.currentThread().interrupt();
			}
			init();
		}
	}

	/**
	 * Initialize provided job in "jobClasses" list.
	 * For each job of object "ScheduledTaskDetails", 
	 * it creates new Thread and set in to  ScheduledTaskDetails object.
	 * In thread implementation it get the class from reflection and cast it with "IScheduledJob" 
	 * and calls "init" method of the interface.
	 * 
	 * It dose the same process as "init" for the provided class name.
	 * @param jobName - FQDN of the class
	 */
	public void startJob(String jobName) {
		try {
			final String name = jobName;
			for (ScheduledJobDetails job : jobClasses) {
				try {
					if(job.getName().equals(jobName)) {
						PALogger.INFO("STARTING" + jobName +" AT "+ new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(new Date()));
						job.setJobThread((new Thread(new Runnable() {
							public void run() {
								try {
									IScheduledJob obj = (IScheduledJob)Class.forName(name).getConstructor().newInstance();

									runningJobs.add(name);
									obj.init();
								} catch (Exception e) {
									PALogger.ERROR(e);	
								}
							}
						})));
						job.Start();
					}
				} catch(Exception ex) {
					PALogger.ERROR(ex);	
				}
			}
		} catch(Exception ex) {
			PALogger.ERROR(ex);	
		}
	}

	/**
	 * Stop all the jobs
	 */
	public void stop() {
		try {
			for (ScheduledJobDetails job : jobClasses) 
			{
				stopSingleJob(job, job.getName(), true);
			}
		} catch(Exception ex) {
			PALogger.ERROR(ex);	
		}
	}

	/**
	 * Stops a single job
	 * @param jobName - FQDN of the class
	 */
	public void stopJob(String jobName) {
		try {
			for (ScheduledJobDetails job : jobClasses)
			{
				if(stopSingleJob(job, jobName,false))
					break;
			}
		} catch(Exception ex) {
			PALogger.ERROR(ex);	
		}
	}

	public boolean stopSingleJob(ScheduledJobDetails job,String jobName,boolean stopAll)
	{
		boolean retVal = false;
		try 
		{

			if(stopAll || job.getName().equals(jobName))
			{
				PALogger.INFO("STOPPING" + jobName +" AT "+ new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(new Date()));
				job.Stop();
				retVal =true;
			}
		} catch(Exception ex) {
			PALogger.ERROR(ex);	
		}
		return retVal;
	}
	public void runStartup(){
		new Thread(new Runnable() {

			@Override
			public void run() {
				mRunStartup();

			}
		}).start();
	}

	private void mRunStartup(){
		try{
			//Setup Logger
			setupLogger();
			//Add/update permissions on auth server
			addAppPermission();
		} catch(Exception ex) {
			PALogger.ERROR(ex);	
		}
	}

	private void setupLogger(){
		try {
			Map<SETTINGS_KEY,String>	settings = new Settings().getSettings();

			for (Map.Entry<SETTINGS_KEY,String> entry : settings.entrySet()) {			
				switch (entry.getKey()) {
				case logLevelError:
					PALogger.SetLogLevelStatus(PALogLevel.ERROR, Boolean.valueOf(entry.getValue()));
					break;
				case logLevelInfo:
					PALogger.SetLogLevelStatus(PALogLevel.INFO, Boolean.valueOf(entry.getValue()));
					break;
				case logLevelTrace:
					PALogger.SetLogLevelStatus(PALogLevel.TRACE, Boolean.valueOf(entry.getValue()));
					break;
				case logLevelWarn:
					PALogger.SetLogLevelStatus(PALogLevel.WARN, Boolean.valueOf(entry.getValue()));
					break;
				default:
					break;
				}
			}

		} catch (SQLException e) {		
			PALogger.ERROR(e);
		}
	}

	/**
	 * Create PermissionLabelVO for your permission set.
	 * Create PermissionVO for each permission, set PermissionLabelVO in this.
	 * Create ManagePermissionVO for adding permission in to db, set PermissionVO in this.
	 * Create ManagePermissionVO for each role you want to add these permissions, set PermissionVO in this.
	 * 
	 * Add all ManagePermissionVO in lstOpr, this the list of operation to execute in auth-server
	 * 
	 * @throws KeyManagementException
	 * @throws NoSuchAlgorithmException
	 * @throws KeyStoreException
	 * @throws IOException
	 */
	public  void addAppPermission() throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException, IOException  
	{

		List<ManagePermissionVO> lstOpr = new ArrayList<>();
		ManagePermissionVO mngVo = new ManagePermissionVO();
		List<PermissionVO> lst = new ArrayList<>();//name,displayname,description,label list

		List<PermissionLabelVO> labelLst = new ArrayList<>();
		PermissionLabelVO labelVo = new PermissionLabelVO();
		labelVo.setKey(PermissionResources.getString(PermissionResourceKeys.PERMISSION_LABEL_KEY));
		labelVo.setValue(PermissionResources.getString(PermissionResourceKeys.PERMISSION_LABEL_VALUE_APPLIANCE));
		labelLst.add(labelVo);

		PermissionVO p = new PermissionVO();

		p.setName(PermissionResources.getString(PermissionResourceKeys.APPLIANCES_APP_START));
		p.setDisplayName(PermissionResources.getString(PermissionResourceKeys.APPLIANCES_APP_START));
		p.setDescription(PermissionResources.getString(PermissionResourceKeys.APPLIANCES_APP_START_DESC));
		p.setLabelLst(labelLst);
		lst.add(p);

		p = new PermissionVO();
		p.setName(PermissionResources.getString(PermissionResourceKeys.APPLIANCES_APP_RESTART));
		p.setDisplayName(PermissionResources.getString(PermissionResourceKeys.APPLIANCES_APP_RESTART));
		p.setDescription(PermissionResources.getString(PermissionResourceKeys.APPLIANCES_APP_RESTART_DESC));
		p.setLabelLst(labelLst);
		lst.add(p);

		p = new PermissionVO();
		p.setName(PermissionResources.getString(PermissionResourceKeys.APPLIANCES_APP_STOP));
		p.setDisplayName(PermissionResources.getString(PermissionResourceKeys.APPLIANCES_APP_STOP));
		p.setDescription(PermissionResources.getString(PermissionResourceKeys.APPLIANCES_APP_STOP_DESC));
		p.setLabelLst(labelLst);
		lst.add(p);

		//add permission(app start,stop,restart) in Db 
		mngVo.setOperation(PermissionOperationEnum.addPermission);
		mngVo.setAddList(lst);
		lstOpr.add(mngVo);	

		//add above 3 permission in role APPLIANCE_APP_MANAGER
		mngVo= new ManagePermissionVO();
		mngVo.setOperation(PermissionOperationEnum.addPermissionInRole);
		RoleVO roleObj = new RoleVO();
		roleObj.setLstpermissions(lst);
		roleObj.setRoleName(PermissionResources.getString(PermissionResourceKeys.APPLIANCE_APP_MANAGER));
		mngVo.setRoleObject(roleObj);
		lstOpr.add(mngVo);

		///////////////////////////////
		p = new PermissionVO();

		p.setName(PermissionResources.getString(PermissionResourceKeys.APPLIANCES_SYSTEM_REBOOT));
		p.setDisplayName(PermissionResources.getString(PermissionResourceKeys.APPLIANCES_SYSTEM_REBOOT));
		p.setDescription(PermissionResources.getString(PermissionResourceKeys.APPLIANCES_SYSTEM_REBOOT_DESC));
		p.setLabelLst(labelLst);
		lst.add(p);

		p = new PermissionVO();
		p.setName(PermissionResources.getString(PermissionResourceKeys.APPLIANCES_SYSTEM_SHUTDOWN));
		p.setDisplayName(PermissionResources.getString(PermissionResourceKeys.APPLIANCES_SYSTEM_SHUTDOWN));
		p.setDescription(PermissionResources.getString(PermissionResourceKeys.APPLIANCES_SYSTEM_SHUTDOWN_DESC));
		p.setLabelLst(labelLst);
		lst.add(p);

		p = new PermissionVO();
		p.setName(PermissionResources.getString(PermissionResourceKeys.APPLIANCES_SYSTEM_FACTORYRESET));
		p.setDisplayName(PermissionResources.getString(PermissionResourceKeys.APPLIANCES_SYSTEM_FACTORYRESET));
		p.setDescription(PermissionResources.getString(PermissionResourceKeys.APPLIANCES_SYSTEM_FACTORYRESET_DESC));
		p.setLabelLst(labelLst);
		lst.add(p);


		p = new PermissionVO();
		p.setName(PermissionResources.getString(PermissionResourceKeys.APPLIANCES_SYSTEM_RESET));
		p.setDisplayName(PermissionResources.getString(PermissionResourceKeys.APPLIANCES_SYSTEM_RESET));
		p.setDescription(PermissionResources.getString(PermissionResourceKeys.APPLIANCES_SYSTEM_RESET_DESC));
		p.setLabelLst(labelLst);
		lst.add(p);


		//add permission(system reboot,shutdown,reset and factory reset) in Db 
		mngVo= new ManagePermissionVO();
		mngVo.setOperation(PermissionOperationEnum.addPermission);
		mngVo.setAddList(lst);
		lstOpr.add(mngVo);

		//add above 4 + 3 permission in role APPLIANCE_CO_ADMIN
		mngVo= new ManagePermissionVO();
		mngVo.setOperation(PermissionOperationEnum.addPermissionInRole);
		roleObj = new RoleVO();
		roleObj.setLstpermissions(lst);
		roleObj.setRoleName(PermissionResources.getString(PermissionResourceKeys.APPLIANCE_CO_ADMIN));
		mngVo.setRoleObject(roleObj);
		lstOpr.add(mngVo);

		//////////////////////////////////////////////////////////////
		lst = new ArrayList<>();
		labelLst = new ArrayList<>();
		labelVo = new PermissionLabelVO();
		labelVo.setKey(PermissionResources.getString(PermissionResourceKeys.PERMISSION_LABEL_KEY));
		labelVo.setValue(PermissionResources.getString(PermissionResourceKeys.PERMISSION_LABEL_VALUE_ADMIN));
		labelLst.add(labelVo);

		//add permission(manage dapi public keys) in db 
		mngVo= new ManagePermissionVO();
		mngVo.setOperation(PermissionOperationEnum.addPermission);
		mngVo.setAddList(lst);
		lstOpr.add(mngVo);


		//add above (manage dapi public keys) permission in role CO_ADMIN
		mngVo= new ManagePermissionVO();
		mngVo.setOperation(PermissionOperationEnum.addPermissionInRole);
		roleObj = new RoleVO();
		roleObj.setLstpermissions(lst);
		roleObj.setRoleName(PermissionResources.getString(PermissionResourceKeys.CO_ADMIN));
		mngVo.setRoleObject(roleObj);
		lstOpr.add(mngVo);


		////////////////////////////////////////////////////////////////////////////
		lst = new ArrayList<>();
		labelLst = new ArrayList<>();
		labelVo = new PermissionLabelVO();
		labelVo.setKey(PermissionResources.getString(PermissionResourceKeys.PERMISSION_LABEL_KEY));
		labelVo.setValue(PermissionResources.getString(PermissionResourceKeys.PERMISSION_LABEL_VALUE_ADMIN));
		labelLst.add(labelVo);

		p = new PermissionVO();
		p.setName(PermissionResources.getString(PermissionResourceKeys.APPLIANCES_LIST));
		p.setLabelLst(labelLst);
		lst.add(p);

		//added appliances list permission in support role
		mngVo= new ManagePermissionVO();
		mngVo.setOperation(PermissionOperationEnum.addPermissionInRole);
		roleObj = new RoleVO();
		roleObj.setLstpermissions(lst);
		roleObj.setRoleName(PermissionResources.getString(PermissionResourceKeys.SUPPORT));
		mngVo.setRoleObject(roleObj);
		lstOpr.add(mngVo);

		/*******Start for Resources*********/

		//For resources - Create new permission label
		labelLst = new ArrayList<>();
		labelVo = new PermissionLabelVO();
		labelVo.setKey(PermissionResources.getString(PermissionResourceKeys.PERMISSION_LABEL_KEY));
		labelVo.setValue(PermissionResources.getString(PermissionResourceKeys.PERMISSION_LABEL_VALUE_APP));
		labelLst.add(labelVo);

		//For resources - Create list of permissions with lable
		lst = new ArrayList<>();
		p = new PermissionVO();
		p.setName(PermissionResources.getString(PermissionResourceKeys.APP_RESOURCES_CREATE));
		p.setDisplayName(PermissionResources.getString(PermissionResourceKeys.APP_RESOURCES_CREATE));
		p.setDescription(PermissionResources.getString(PermissionResourceKeys.APP_RESOURCES_CREATE_DESC));
		p.setLabelLst(labelLst);
		lst.add(p);

		p = new PermissionVO();
		p.setName(PermissionResources.getString(PermissionResourceKeys.APP_RESOURCES_DELETE));
		p.setDisplayName(PermissionResources.getString(PermissionResourceKeys.APP_RESOURCES_DELETE));
		p.setDescription(PermissionResources.getString(PermissionResourceKeys.APP_RESOURCES_DELETE_DESC));
		p.setLabelLst(labelLst);
		lst.add(p);

		p = new PermissionVO();
		p.setName(PermissionResources.getString(PermissionResourceKeys.APP_RESOURCES_LIST));
		p.setDisplayName(PermissionResources.getString(PermissionResourceKeys.APP_RESOURCES_LIST));
		p.setDescription(PermissionResources.getString(PermissionResourceKeys.APP_RESOURCES_LIST_DESC));
		p.setLabelLst(labelLst);
		lst.add(p);

		//For resources - Create Operation to add permission in DB
		mngVo= new ManagePermissionVO();
		mngVo.setOperation(PermissionOperationEnum.addPermission);
		mngVo.setAddList(lst);
		lstOpr.add(mngVo);

		//For resources - Add permissions into roles 
		mngVo= new ManagePermissionVO();
		mngVo.setOperation(PermissionOperationEnum.addPermissionInRole);
		roleObj = new RoleVO();
		roleObj.setLstpermissions(lst);
		roleObj.setRoleName(PermissionResources.getString(PermissionResourceKeys.PROJECT_APP_DEVELOPER));
		mngVo.setRoleObject(roleObj);
		lstOpr.add(mngVo);

		mngVo= new ManagePermissionVO();
		mngVo.setOperation(PermissionOperationEnum.addPermissionInRole);
		roleObj = new RoleVO();
		roleObj.setLstpermissions(lst);
		roleObj.setRoleName(PermissionResources.getString(PermissionResourceKeys.PROJECT_APP_USER));
		mngVo.setRoleObject(roleObj);
		lstOpr.add(mngVo);

		mngVo= new ManagePermissionVO();
		mngVo.setOperation(PermissionOperationEnum.addPermissionInRole);
		roleObj = new RoleVO();
		roleObj.setLstpermissions(lst);
		roleObj.setRoleName(PermissionResources.getString(PermissionResourceKeys.PROJECT_APP_CO_OWNER));
		mngVo.setRoleObject(roleObj);
		lstOpr.add(mngVo);

		/*******End for Resources*********/

		String authorizationHeader = "basic " +  new String(Base64.getEncoder().encode(("41ff73c9719a42bdb0348355114ceb82:" + new CredProvider().getPortalAppSecKey()).getBytes()));
		Client.callServer(Constants.AUTH_SERVER_IP_PORT, Constants.AUTH_SERVICE_NAME, "permissions","POST", "", null, lstOpr, authorizationHeader);	

	}
	//	public  void addAppPermission() throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException, IOException
	//	{
	//
	//		List<PermissionVO> lst = new ArrayList<>();
	//
	//		String permissionSetName = PermissionSet.CO_OWNER;
	//		PermissionVO p = new PermissionVO();
	//		p.setName(PortalPermissions.APPLIANCES_SYSTEM_UPDATE);
	//		p.setDisplayName(PortalPermissions.APPLIANCES_SYSTEM_UPDATE);
	//		lst.add(p);
	//
	//		p = new PermissionVO();
	//		p.setName(PortalPermissions.APPLIANCES_DELETEOFFLINE);
	//		p.setDisplayName(PortalPermissions.APPLIANCES_DELETEOFFLINE);
	//		lst.add(p);
	//
	//		
	//		p = new PermissionVO();
	//		p.setName(PortalPermissions.APPLIANCES_APP_INSTALL);
	//		p.setDisplayName(PortalPermissions.APPLIANCES_APP_INSTALL);
	//		lst.add(p);
	//
	//		
	//
	//		p = new PermissionVO();
	//		p.setName(PortalPermissions.APPLIANCES_APP_UNINSTALL);
	//		p.setDisplayName(PortalPermissions.APPLIANCES_APP_UNINSTALL);
	//		lst.add(p);
	//
	//		Map<String, Object> permissionMap = new HashMap<>();
	//		permissionMap.put("permissionSetName", permissionSetName);
	//		permissionMap.put("permissions", new Gson().toJson(lst));
	//		String authorizationHeader = "basic " +  new String(Base64.getEncoder().encode(("41ff73c9719a42bdb0348355114ceb82:" + new CredProvider().getPortalAppSecKey()).getBytes()));
	//		Client.callServer(Constants.AUTH_SERVER_IP_PORT, Constants.AUTH_SERVICE_NAME, "application","POST", "addpermission/" + Constants.PORTAL_APPLICATION_ID, null, permissionMap, authorizationHeader);	
	//	}

	/**
	 * Method call on startup of portal and check Portal app is registerd on auth server or not 
	 * @throws Exception
	 */
	//	private void checkAppAtAuthServer() throws Exception
	//	{
	//		/**
	//		 * Rest call for check app is added to auth server or not.
	//		 */
	//		String result = Client.callServer(Constants.AUTH_SERVER_IP_PORT, Constants.AUTH_SERVICE_NAME, "application","GET", Constants.PORTAL_APPLICATION_ID, null, null, "");
	//		ApplicationsVO applicationsVO=new Gson().fromJson(result, ApplicationsVO.class);
	//		if(applicationsVO!=null)  // Check it is added or not.
	//		{
	//			/**
	//			 * Check app version is updated or not on auth server.
	//			 */
	//			if(!Constants.APPVERSION.equals(applicationsVO.getAppVersion()))
	//			{
	//				applicationsVO.setAppVersion(Constants.APPVERSION);
	//
	//				/**
	//				 * Update Application permission if required and version (must set update version).
	//				 */
	//				List<PermissionVO> lstPermissionVOs=new ArrayList<>();
	//				PermissionVO permission1= new PermissionVO("","push","push",Constants.PORTAL_APPLICATION_ID,new Date().getTime(),new Date().getTime());
	//				PermissionVO permission2= new PermissionVO("","pull","pull",Constants.PORTAL_APPLICATION_ID,new Date().getTime(),new Date().getTime());
	//				PermissionVO permission3= new PermissionVO("","delete","delete",Constants.PORTAL_APPLICATION_ID,new Date().getTime(),new Date().getTime());
	//				PermissionVO permission4= new PermissionVO("","publish","publish",Constants.PORTAL_APPLICATION_ID,new Date().getTime(),new Date().getTime());
	//				lstPermissionVOs.add(permission1);
	//				lstPermissionVOs.add(permission2);
	//				lstPermissionVOs.add(permission3);
	//				lstPermissionVOs.add(permission4);
	//				applicationsVO.setPermissions(lstPermissionVOs);
	//				/**
	//				 * Rest call for update app version and permission.
	//				 */
	//				result = Client.callServer(Constants.AUTH_SERVER_IP_PORT, Constants.AUTH_SERVICE_NAME, "application","PUT", "", null, applicationsVO, "");
	//				ApplicationsVO updateapplicationsVO=new Gson().fromJson(result, ApplicationsVO.class);
	//				if(updateapplicationsVO==null)
	//				{
	//					throw new Exception("Update App Failed.");
	//				}
	//			}
	//		}
	//		else
	//		{
	//			/**
	//			 * Create new application object and set essential property.
	//			 */
	//			applicationsVO=new ApplicationsVO();
	//			applicationsVO.setAppId(Constants.PORTAL_APPLICATION_ID);
	//			applicationsVO.setAppSecretKey(new CredProvider().getPortalAppSecKey());
	//			applicationsVO.setCreatedDate(new Date().getTime());
	//			applicationsVO.setModifiedDate(new Date().getTime());
	//			applicationsVO.setAppVersion(String.valueOf("1"));
	//
	//			/**
	//			 * Add Essential permission for app.
	//			 */
	//			List<PermissionVO> lstPermissionVOs=new ArrayList<>();
	//			PermissionVO permission1= new PermissionVO("","push","push",Constants.PORTAL_APPLICATION_ID,new Date().getTime(),new Date().getTime());
	//			PermissionVO permission2= new PermissionVO("","pull","pull",Constants.PORTAL_APPLICATION_ID,new Date().getTime(),new Date().getTime());
	//			PermissionVO permission3= new PermissionVO("","delete","delete",Constants.PORTAL_APPLICATION_ID,new Date().getTime(),new Date().getTime());
	//			PermissionVO permission4= new PermissionVO("","publish","publish",Constants.PORTAL_APPLICATION_ID,new Date().getTime(),new Date().getTime());
	//			lstPermissionVOs.add(permission1);
	//			lstPermissionVOs.add(permission2);
	//			lstPermissionVOs.add(permission3);
	//			lstPermissionVOs.add(permission4);
	//			applicationsVO.setPermissions(lstPermissionVOs);
	//			applicationsVO.setSignUpType(SignUpTypeEnum.SignUpWithCodeOnly);
	//			applicationsVO.setStatus(ApplicationStatusEnum.Approved);
	//			applicationsVO.setUserId(Constants.PORTAL_USER_ID);
	//
	//			/**
	//			 * Rest call for add app to auth server.
	//			 */
	//			result = Client.callServer(Constants.AUTH_SERVER_IP_PORT, Constants.AUTH_SERVICE_NAME, "application","POST", "", null, applicationsVO, "");
	//		ApplicationsVO addapplicationsVO=new Gson().fromJson(result, ApplicationsVO.class);
	//			if(addapplicationsVO==null)
	//			{
	//				throw new Exception("Add App Failed.");
	//			}
	//		}
	//	}
}