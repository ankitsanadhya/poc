/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal;

import com.mwp.common.CredProvider;
import com.mwp.common.enums.Status;
import com.mwp.p.common.enums.PortalDBEnum;

public class CompanyDB {

	public String list() {
		return mList();
	}

	public String get() {
		return mGet();
	}

	public String companyNameExits() {
		return mCompanyNameExits();
	}

	public String add() {
		return mAdd();
	}

	public String update() {
		return mUpdate();
	}

	public String delete() {
		return mMarkCompanyDeleted();
	}

	private String mGet(){
		StringBuilder sb = new StringBuilder();
		sb.append("Select * ");
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.company);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.COMPANY.companyId);
		sb.append(" = ");
		sb.append("?");
		//sb.append(dbCon.formatString(companyId));

		sb.append(" AND ");

		sb.append(PortalDBEnum.TABLE_NAMES.company);
		sb.append(".");
		sb.append(PortalDBEnum.COMPANY.userId);
		sb.append(" = ");
		sb.append("?");
		//sb.append(PortalDatabaseEngine.getInstance().getConnection().formatString(userId));

		sb.append(" AND ");

		sb.append(PortalDBEnum.TABLE_NAMES.company);
		sb.append(".");
		sb.append(PortalDBEnum.COMPANY.companyStatus);
		sb.append(" != ");
		sb.append(Status.DELETED.ordinal());

		return sb.toString();
	}

	private String mCompanyNameExits(){
		StringBuilder sb = new StringBuilder();
		sb.append("Select * ");
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.company);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.COMPANY.companyName);
		sb.append(" = ");
		sb.append("?");
		//sb.append(dbCon.formatString(StringEncryptionDecryption.encrypt(companyName, new CredProvider().getEcnKey())));

		sb.append(" AND ");

		sb.append(PortalDBEnum.COMPANY.userId);
		sb.append(" = ");
		sb.append("?");
		//sb.append(PortalDatabaseEngine.getInstance().getConnection().formatString(userId));

		sb.append(" AND ");

		sb.append(PortalDBEnum.TABLE_NAMES.company);
		sb.append(".");
		sb.append(PortalDBEnum.COMPANY.companyStatus);
		sb.append(" != ");
		sb.append(Status.DELETED.ordinal());

		return sb.toString();
	}

	private String mList(){

		StringBuilder sb = new StringBuilder();
		sb.append("Select * ");
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.company);

		sb.append(" WHERE ");

		sb.append(PortalDBEnum.TABLE_NAMES.company);
		sb.append(".");
		sb.append(PortalDBEnum.COMPANY.userId);
		sb.append(" = ");
		sb.append("?");
		//sb.append(PortalDatabaseEngine.getInstance().getConnection().formatString(userId));

		sb.append(" AND ");

		sb.append(PortalDBEnum.TABLE_NAMES.company);
		sb.append(".");
		sb.append(PortalDBEnum.COMPANY.companyStatus);
		sb.append(" != ");
		sb.append(Status.DELETED.ordinal());

		return sb.toString();
	}

	private String mAdd() {

		String encKey = new CredProvider().getEcnKey();
		StringBuilder sb = new StringBuilder();
		sb.append("INSERT INTO ");
		sb.append(PortalDBEnum.TABLE_NAMES.company);
		sb.append(" ( ");
		sb.append(PortalDBEnum.COMPANY.companyId.name());
		sb.append(", ");
		sb.append(PortalDBEnum.COMPANY.projectId.name());
		sb.append(", ");
		sb.append(PortalDBEnum.COMPANY.userId.name());
		sb.append(", ");
		sb.append(PortalDBEnum.COMPANY.companyName.name());
		sb.append(", ");
		sb.append(PortalDBEnum.COMPANY.address.name());
		sb.append(", ");
		sb.append(PortalDBEnum.COMPANY.city.name());
		sb.append(", ");
		sb.append(PortalDBEnum.COMPANY.state.name());
		sb.append(", ");
		sb.append(PortalDBEnum.COMPANY.country.name());
		sb.append(", ");
		sb.append(PortalDBEnum.COMPANY.postalCode.name());
		sb.append(", ");
		sb.append(PortalDBEnum.COMPANY.webAddress.name());
		sb.append(", ");
		sb.append(PortalDBEnum.COMPANY.phone.name());
		sb.append(", ");
		sb.append(PortalDBEnum.COMPANY.email.name());
		sb.append(", ");
		sb.append(PortalDBEnum.COMPANY.companyStatus.name());
		sb.append(", ");
		sb.append(PortalDBEnum.COMPANY.modifiedDate.name());
		sb.append(", ");
		sb.append(PortalDBEnum.COMPANY.createdDate.name());
		sb.append(" ) VALUES ( ");
		sb.append("?");
//		sb.append(dbCon.formatString(companyInfoVO.getCompanyId()));
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(""));//  Ask VA
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(companyInfoVO.getUserId()));
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(StringEncryptionDecryption.encrypt(companyInfoVO.getName(), encKey)));
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(StringEncryptionDecryption.encrypt(companyInfoVO.getAddress(), encKey)));
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(StringEncryptionDecryption.encrypt(companyInfoVO.getCity(), encKey)));
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(StringEncryptionDecryption.encrypt(companyInfoVO.getState(), encKey)));
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(StringEncryptionDecryption.encrypt(companyInfoVO.getCountry(), encKey)));
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(StringEncryptionDecryption.encrypt(companyInfoVO.getPostalCode(), encKey)));
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(StringEncryptionDecryption.encrypt(companyInfoVO.getWebAddress(), encKey)));
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(StringEncryptionDecryption.encrypt(companyInfoVO.getPhone(), encKey)));
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(StringEncryptionDecryption.encrypt(companyInfoVO.getEmail(), encKey)));
		sb.append(", ");
		sb.append("?");
//		sb.append(Status.ACTIVE.ordinal());
		sb.append(", ");
		sb.append(" NOW()");
		sb.append(", ");
		sb.append(" NOW()");
		sb.append(" ) ");
		return sb.toString();
	}

	private String mUpdate() {
		
		StringBuilder sb = new StringBuilder();
		sb.append("UPDATE ");
		sb.append(PortalDBEnum.TABLE_NAMES.company);
		sb.append(" SET ");


		sb.append(PortalDBEnum.COMPANY.address.name());
		sb.append(" = ");
		sb.append("?");
		//sb.append(dbCon.formatString(StringEncryptionDecryption.encrypt(cInfoVO.getAddress(), encKey)));
		sb.append(", ");

		sb.append(PortalDBEnum.COMPANY.city.name());
		sb.append(" = ");
		sb.append("?");
		//sb.append(dbCon.formatString(StringEncryptionDecryption.encrypt(cInfoVO.getCity(), encKey)));
		sb.append(", ");

		sb.append(PortalDBEnum.COMPANY.state.name());
		sb.append(" = ");
		sb.append("?");
		//sb.append(dbCon.formatString(StringEncryptionDecryption.encrypt(cInfoVO.getState(), encKey)));
		sb.append(", ");

		sb.append(PortalDBEnum.COMPANY.country.name());
		sb.append(" = ");
		sb.append("?");
		//sb.append(dbCon.formatString(StringEncryptionDecryption.encrypt(cInfoVO.getCountry(), encKey)));
		sb.append(", ");

		sb.append(PortalDBEnum.COMPANY.postalCode.name());
		sb.append(" = ");
		sb.append("?");
		//sb.append(dbCon.formatString(StringEncryptionDecryption.encrypt(cInfoVO.getPostalCode(), encKey)));
		sb.append(", ");

		sb.append(PortalDBEnum.COMPANY.webAddress.name());
		sb.append(" = ");
		sb.append("?");
		//sb.append(dbCon.formatString(StringEncryptionDecryption.encrypt(cInfoVO.getWebAddress(), encKey)));
		sb.append(", ");

		sb.append(PortalDBEnum.COMPANY.phone.name());
		sb.append(" = ");
		sb.append("?");
		//sb.append(dbCon.formatString(StringEncryptionDecryption.encrypt(cInfoVO.getPhone(), encKey)));
		sb.append(", ");

		sb.append(PortalDBEnum.COMPANY.email.name());
		sb.append(" = ");
		sb.append("?");
		//sb.append(dbCon.formatString(StringEncryptionDecryption.encrypt(cInfoVO.getEmail(), encKey)));
		sb.append(", ");

		sb.append(PortalDBEnum.COMPANY.modifiedDate.name());
		sb.append(" = NOW()");

		sb.append(" WHERE ");
		sb.append(PortalDBEnum.COMPANY.companyId.name());
		sb.append(" = ");
		sb.append("?");
		//sb.append(dbCon.formatString(cInfoVO.getCompanyId()));
		return sb.toString();
	}

	private String mMarkCompanyDeleted() {
		StringBuilder sb = new StringBuilder();
		sb.append("UPDATE ");
		sb.append(PortalDBEnum.TABLE_NAMES.company);
		sb.append(" SET ");

		sb.append(PortalDBEnum.COMPANY.companyStatus.name());
		sb.append(" = ");
		sb.append("?");
//		sb.append(Status.DELETED.ordinal());
		sb.append(", ");

		sb.append(PortalDBEnum.COMPANY.modifiedDate.name());
		sb.append(" = NOW()");

		sb.append(" WHERE ");

		sb.append(PortalDBEnum.COMPANY.companyId.name());
		sb.append(" = ");
		sb.append("?");
//		sb.append(dbCon.formatString(companyId));
		sb.append(" AND ");

		sb.append(PortalDBEnum.TABLE_NAMES.company);
		sb.append(".");
		sb.append(PortalDBEnum.COMPANY.userId);
		sb.append(" = ");
		sb.append("?");
		//sb.append(PortalDatabaseEngine.getInstance().getConnection().formatString(userId));
		return sb.toString();
	}

}
