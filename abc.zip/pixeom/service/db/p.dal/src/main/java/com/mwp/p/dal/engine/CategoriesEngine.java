/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal.engine;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.mwp.common.Common;
import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.common.constant.Constant;
import com.mwp.common.enums.Status;
import com.mwp.common.vo.CategoryVO;
import com.mwp.common.vo.QueryVO;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.dal.AppCategoriesDB;
import com.mwp.p.dal.CategoriesDB;

public class CategoriesEngine {



	/**
	 * Returns {@link CategoryVO}
	 * according to requested categoryId.
	 * @param categoryId
	 * @return
	 * @throws Exception
	 */
	public CategoryVO getCategory(String categoryId) throws SQLException{
		return mGetCategory(categoryId);
	}

	/**
	 * Returns updated {@link CategoryVO}
	 * update category status/name which id specified in category object.
	 * @param categoryVO
	 * @return
	 * @throws Exception
	 */
	public CategoryVO editCategory(CategoryVO categoryVO) throws Exception{
		return mEditCategory(categoryVO);
	}
	/**
	 * Remove category change status = 'SUSPENDED' in database.
	 * @param categoryId
	 * @throws Exception
	 */
	public void deleteCategory(String categoryId) throws SQLException{
		mDeleteCategory(categoryId);
	}

	/**
	 * This method add category in category database.
	 * @param categoryVO
	 * @return
	 * @throws Exception
	 */
	public CategoryVO addCategory(CategoryVO categoryVO) throws SQLException{
		return mAddCategory(categoryVO);
	}
	/**
	 * This method gives all Categories using paging.
	 * @param pageNo
	 * @param pageSize
	 * @param searchText
	 * @return
	 * @throws Exception
	 */
	public Map<String, Object> searchCategories(int pageNo, int pageSize, String searchText) throws SQLException {
		return mSearchCategories(pageNo, pageSize, searchText);
	}

	/**
	 * Returns List of {@link CategoryVO}
	 * of default categories.
	 * @return
	 * @throws Exception
	 */
	public List<CategoryVO> listDefaultCategory() throws SQLException{
		return mListDefaultCategory();
	}

	/**
	 * This method gives list of all {@link CategoryVO} according to requested search text.
	 * @param searchText
	 * @return
	 * @throws Exception
	 */
	public Map<String, Object> suggestedCategories(String searchText) throws SQLException {
		return mSuggestedCategories(searchText);
	}

	private CategoryVO mGetCategory(String categoryId) throws SQLException{
		CategoriesDB catDB = new CategoriesDB();

		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(catDB.getCategory()).addParameter(categoryId).build();

		CategoryVO categoryVO = null;
		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				categoryVO = setCategoryObject(rs);
			} 
		} 
		return categoryVO;
	}

	private CategoryVO mEditCategory(CategoryVO categoryVO) throws Exception{
		CategoriesDB catDB = new CategoriesDB();

		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(catDB.editCategory())
				.addParameter(categoryVO.getName())
				.addParameter(categoryVO.getStatus().ordinal())
				.addParameter(categoryVO.isDefaultCategory())
				.addParameter(categoryVO.getCategoryId())
				.build();

		int updateCount = PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
		if(updateCount > 0){
			return categoryVO;
		}else{
			throw new Exception("category update failed.");
		}
	}

	private void mDeleteCategory(String categoryId) throws SQLException{
		ArrayList<QueryVO> queries = new ArrayList<>();

		QueryVO queryVO1 = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new CategoriesDB().deleteCategory()).addParameter(categoryId).build();

		queries.add(queryVO1);


		QueryVO queryVO2 = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new AppCategoriesDB().deleteAppsFromCategory()).addParameter(categoryId).build();

		queries.add(queryVO2);

		PortalDatabaseEngine.getInstance().getConnection().executeUpdatesInTransaction(queries);
	}

	private CategoryVO mAddCategory(CategoryVO categoryVO) throws SQLException{
		categoryVO.setCategoryId(Common.getRandomId());

		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new CategoriesDB().addCategory())
				.addParameter(categoryVO.getCategoryId())
				.addParameter(categoryVO.getName())
				.addParameter(categoryVO.getStatus().ordinal())
				.addParameter(categoryVO.isDefaultCategory())
				.build();


		int isAdd = PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
		if(isAdd > 0){
			return categoryVO;
		}else{
			return null;
		}
	}

	private Map<String, Object> mSearchCategories(int pageNo, int pageSize, String searchText) throws SQLException {
		HashMap<String, Object> hashOutput = new HashMap<>();
		List<CategoryVO> listCategory = new ArrayList<>();
		
		List<String> queries = new CategoriesDB().searchCategories();
		
		long offset = (pageNo - 1) * pageSize;

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
						.appendQuery(queries.get(0))
						.addParameter(searchText)
						.addParameter(pageSize)
						.addParameter(offset)
						.build();

		QueryVO queryVOCount = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
						.appendQuery(queries.get(1)).build();
		
		int totalCategoryCount = 0; 
		
		
		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO);
				ResultSet rsCount = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVOCount)){
			while (rsCount.next()){
				if(totalCategoryCount <= 0){
					totalCategoryCount = rsCount.getInt("categoryCount");
				}
			}
			while (rs.next()){
				listCategory.add(setCategoryObject(rs));				
			}		

		}

		int totalPages = totalCategoryCount / pageSize;
		if((totalCategoryCount % pageSize) > 0){
			totalPages += 1;			
		}
		hashOutput.put(Constant.DATA, listCategory);
		hashOutput.put("totalPages", totalPages);
		hashOutput.put("pageNo", pageNo);
		hashOutput.put("pageSize", pageSize);
		return hashOutput;
	}

	private List<CategoryVO> mListDefaultCategory() throws SQLException{
		List<CategoryVO> listCategory = new ArrayList<>();
		
		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new CategoriesDB().listDefaultCategories()).build();

		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)){
			while (rs.next()){
				listCategory.add(setCategoryObject(rs));
			}
		}
		return listCategory;
	}

	private HashMap<String, Object> mSuggestedCategories(String searchText) throws SQLException {
		int pageSize = 10;
		HashMap<String, Object> hashOutput = new HashMap<>();
		List<CategoryVO> listCategory = new ArrayList<>();

		int totalCategoryCount = 0; 
		
		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new CategoriesDB().suggestedCategories()).build();

		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)){
			while (rs.next()){
				listCategory.add(setCategoryObject(rs));
				if(totalCategoryCount <= 0){
					totalCategoryCount = rs.getInt("categoryCount");
				}
			}
		}

		int totalPages = totalCategoryCount / pageSize;
		if((totalCategoryCount % pageSize) > 0){
			totalPages += 1;			
		}
		hashOutput.put(Constant.DATA, listCategory);
		hashOutput.put("totalPages", totalPages);
		hashOutput.put("pageNo", 1);
		hashOutput.put("pageSize", pageSize);
		return hashOutput;
	}

	private CategoryVO setCategoryObject(ResultSet rs) throws SQLException
	{
		CategoryVO categoryVO = new CategoryVO();

		categoryVO.setCategoryId(rs.getString(PortalDBEnum.CATEGORY.catId.name()));
		categoryVO.setName(rs.getString(PortalDBEnum.CATEGORY.name.name()));
		categoryVO.setStatus(Status.GetEnum(rs.getInt(PortalDBEnum.CATEGORY.catStatus.name())));
		categoryVO.setDefaultCategory(rs.getBoolean(PortalDBEnum.CATEGORY.type.name()));
		categoryVO.setCreatedDate(rs.getTimestamp(PortalDBEnum.CATEGORY.createdDate.name()).getTime());
		categoryVO.setModifiedDate(rs.getTimestamp(PortalDBEnum.CATEGORY.modifiedDate.name()).getTime());

		return categoryVO;
	}
}
