/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal.engine;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;

import javax.ws.rs.HttpMethod;

import org.apache.commons.io.FileUtils;

import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.mwp.common.Client;
import com.mwp.common.Common;
import com.mwp.common.CredProvider;
import com.mwp.common.FileBasedLock;
import com.mwp.common.StringFunctions;
import com.mwp.common.enums.RoleEnum;
import com.mwp.common.vo.ApplicationUserVO;
import com.mwp.db.Interface.IConnection;
import com.mwp.db.Interface.IDatabaseScript;
import com.mwp.db.connection.MysqlConnection;
import com.mwp.db.engine.DatabaseEngine;
import com.mwp.logger.PALogger;
import com.mwp.p.common.Constants;
import com.mwp.p.dal.PortalDatabaseScript;
import com.mwp.p.dal.PortalUpdateScripts;

/**
 * This class manage portal database connection, current version, db username/password,
 * database server path.
 * @author root
 *
 */
public class PortalDatabaseEngine extends DatabaseEngine{

	private static DatabaseEngine instance;
	private static final String DB_NAME = "platformportal";
	/*
	 * AKH_01_1,AKH_02_1, AKH_03, AKH_04 
	 */
	private static final int CURRENT_VERSION = 87;
	private static String dbServerPath = "localhost:3306";
	private static String dbUsername = "root";

	static {
		String tempPath = System.getProperty("java.io.tmpdir");
		File lockFile = new File(tempPath + DB_NAME + "_lock.file");

		FileBasedLock dbCreateLock = new FileBasedLock();
		dbCreateLock.getLock(lockFile);

		MysqlConnection connection = null;
		try {
			List<String> dbServerSettings =  Common.getDbServerSettings();
			if(dbServerSettings.size() == 2){
				String dbServerAddress =  dbServerSettings.get(0).trim();				
				if(!StringFunctions.isNullOrWhitespace(dbServerAddress)){
					dbServerPath = dbServerAddress; 
				}

				String dbServerUser =  dbServerSettings.get(1).trim();				
				if(!StringFunctions.isNullOrWhitespace(dbServerUser)){
					dbUsername = dbServerUser; 
				}


			}
			connection = new MysqlConnection(DB_NAME, dbServerPath, dbUsername, new CredProvider().getMysqlPwd());
		} catch (ClassNotFoundException | IOException e) {
			PALogger.INFO("Shutting down process (PortalDatabaseEngine) - cannot connect to mysql");
			PALogger.ERROR(e);
			System.exit(0);
		}

		instance = new PortalDatabaseEngine(CURRENT_VERSION, connection);

		dbCreateLock.releaseLock();

	}


	public static DatabaseEngine getInstance() {
		return instance;
	}

	/**
	 * initiate db coonection, pass version and coonection to super class,
	 * if database not exist in mysql schema then create, if exist then execute update script.
	 * @param version current version of db which define in constant.
	 * @param connection
	 */
	private PortalDatabaseEngine(int version, IConnection connection) {
		super(version, connection, DB_NAME);

		IDatabaseScript portalDatabaseScript = new PortalDatabaseScript(DB_NAME);
		//LinkedHashMap<K, V>
		this.configureDatabase(portalDatabaseScript);
		//DB- Moved this logic to centralized base class which takes decision whether to update existing database or to create the database if it not exists

	}


	@Override
	protected void createDatabase(IDatabaseScript dbScripts) throws Exception
	{
		//DB - Overrided the create database method as addAdmin mthod was invoked extra after creating the database
		super.createDatabase(dbScripts);
		addAdmin();
	}



	private void addAdmin()
	{
		String adminFilePath = "/opt/app_engine/AdminUser";

		File adminFile= new File(adminFilePath); 
		if(!adminFile.exists())
			return;

		String result;
		try 
		{
			result = FileUtils.readFileToString(adminFile);
		} catch (IOException e)
		{
			PALogger.ERROR(e);
			return;
		}

		ApplicationUserVO userVo;
		try
		{
			userVo = new Gson().fromJson(result, ApplicationUserVO.class);
			userVo.setAppId(Constants.PORTAL_APPLICATION_ID);
			userVo.setRole(RoleEnum.Admin);
			userVo.setStatus(1);
			userVo.setProfilePicturePath("");
			Client.callServer(Constants.AUTH_SERVER_IP_PORT, Constants.AUTH_SERVICE_NAME, "applications", HttpMethod.POST, Constants.PORTAL_APPLICATION_ID  +   "/user", null, userVo, "");
		}
		catch (JsonSyntaxException e)
		{
			// not a valid json
			PALogger.ERROR(e);
		} 
		catch (Exception e) 
		{
			PALogger.ERROR(e);
			PALogger.ERROR("adding admin user for portal on auth server failed");	
			System.exit(0);
		}
	}

	/**
	 * This methods is used to update database
	 * @param dbVersion : current database version 
	 * @param dbScripts : create database script
	 * @throws Exception 
	 * @throws TimeoutException 
	 * @throws ExecutionException 
	 * @throws InterruptedException 
	 * @throws ParseException 
	 * @throws IOException 
	 * 
	 */
	@Override
	protected void updateDatabase(int dbVersion) throws Exception {
		/**
		 * getting latest update script by comparing dbVersion(exist in t999 db) 
		 * and currentVersion(exist in constant).
		 */
		PortalUpdateScripts pus = new PortalUpdateScripts(DB_NAME);
		PortalDatabaseScript pds = new PortalDatabaseScript(DB_NAME);
		switch (dbVersion+1) {
		case 76:
			getConnection().executeUpdate(pds.getSupportTokensTables());
			getConnection().executeUpdateDDL(pds.AlterNodesTable());
			for (String query : pds.AlterDeviceNodesTokenView()) {
				getConnection().executeUpdate(query);	
			}
			getConnection().executeUpdate(pds.getDBUpdateVersionQuery(76));
		case 77:
			for (String query : pus.getRelayServerScripts()) {
				getConnection().executeUpdateDDL(query);
			}
			getConnection().executeUpdate(pds.getDBUpdateVersionQuery(77));
		case 78:
			getConnection().executeUpdateDDL(pus.addSortOrderInDownload());
			getConnection().executeUpdate(pds.getDBUpdateVersionQuery(78));

		case 79:
			getConnection().executeUpdateDDL(pus.updateColumnInActivityLog());
			getConnection().executeUpdate(pds.getDBUpdateVersionQuery(79));
		case 80:
			for (String query : pus.getUpdateSecretCreateScripts()) {
				getConnection().executeUpdateDDL(query);
			}
			getConnection().executeUpdate(pds.getDBUpdateVersionQuery(80));
		case 81:
//			getConnection().executeUpdatesInTransaction(pus.getUpdateSecretInsertScripts());
//			getConnection().executeUpdate(pds.getDBUpdateVersionQuery(81));
		case 82:
			for (String query : pus.getUpdateSecretDeleteScripts()) {
				getConnection().executeUpdateDDL(query);
			}
			getConnection().executeUpdate(pds.getDBUpdateVersionQuery(82));
		case 83:
			getConnection().executeUpdateDDL(pus.addTypeInSecretVersion());
			getConnection().executeUpdate(pus.updateType());
			getConnection().executeUpdateDDL(pus.deleteTypeFromSecret());

			getConnection().executeUpdate(pds.getDBUpdateVersionQuery(83));

		case 84:
			//getConnection().executeUpdatesInTransaction(pus.queryBeforeAddForeignKey());
			for (String query : pus.addForeignKey()) {
				getConnection().executeUpdateDDL(query);
			}
			getConnection().executeUpdate(pds.getDBUpdateVersionQuery(84));
		case 85:
			getConnection().executeUpdateDDL(pus.applicationResourceTables());
			getConnection().executeUpdate(pds.getDBUpdateVersionQuery(85));
		case 86:
			getConnection().executeUpdateDDL(pus.applicationBackupTable());
			getConnection().executeUpdateDDL(pus.applicationBackupSyncTable());
			getConnection().executeUpdate(pds.getDBUpdateVersionQuery(86));
		case 87:
			getConnection().executeUpdateDDL(pus.modifyAppBackupTaskTable());
			getConnection().executeUpdate(pds.getDBUpdateVersionQuery(87));
		}
	}

}

/**
 * History of check-in or issue resolved
 * 
 * 01 - 7-10-2016 
 * AKH_01_1
 * version increased 8 because 
 * Remove applicationconfigurations table from platformportal database, and remove appConfigId from applicationversions table.
 * change coulmn name appConfigId to appVersionId of applicationserviceendpoints table.
 * Add coulmn (usePxAuth, usePxEventService, usePxCloudApi, signUpType) in applications table.
 * 02 - 20-10-2016
 * AKH_02_1
 * Add field price and rating in application table for use sorting on UI.
 * 03 - 4-11-2016
 * AKH_03
 * Add field restRedirectUrl in application table we save "reverse proxy" and "specific port" in redirect Url and rest Url save in restRedirectUrl.
 * 
 * 04 - 14-11-2016 AKH_04
 * remove restRedirectUrl, redirectUrl, redirectType and redirectSection these property from application and shift to applicationVersion,
 * because may be each version have different redirection param.
 */
