/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal;

import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.common.enums.PortalDBEnum.ASSIGNED_RELAY_PORTS;

/**
 *This class create queries related to table {@link ASSIGNED_RELAY_PORTS}
 */
public class AssignedRelayPortsDB {

	public AssignedRelayPortsDB() {
	}
	
	/**
	 * create query to get maximum of relay ports PortSegment
	 * @param relayServerId
	 * @return
	 */
	public String getMaxRelayPort() {
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT ");
		sb.append(" MAX(nPortSegmentStart) as MaxAvailablePortSegment FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.assignedrelayports.name());
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.ASSIGNED_RELAY_PORTS.sRelayServerID.name());sb.append(" = ");sb.append("?");
		
		return sb.toString();
	}

	/**
	 * create query to delete assigned  port of a device  
	 * @param deviceId
	 */
	public String deleteDeviceAssignedPorts() {
		StringBuilder sb = new StringBuilder();
		sb.append("DELETE FROM ");sb.append(PortalDBEnum.TABLE_NAMES.assignedrelayports.name());
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.ASSIGNED_RELAY_PORTS.sDeviceID.name());sb.append(" = ");sb.append("?");
		return sb.toString();
	}

	/**
	 * Create query to get all available ports for relay server id 
	 * @param relayServerId
	 * @return  ArrayList<AssignedRelayPortsVO>
	 */
	public String getAvailablePorts() {
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT * FROM ");sb.append(PortalDBEnum.TABLE_NAMES.assignedrelayports.name());
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.ASSIGNED_RELAY_PORTS.sRelayServerID.name());sb.append(" = ");sb.append("?");
		sb.append(" AND ");
		sb.append(PortalDBEnum.ASSIGNED_RELAY_PORTS.nStatus.name());sb.append(" != ");sb.append("?");
		return sb.toString();
	}

	/**
	 * create query to 	 get assigned relay ports of device id.
	 * @param deviceId
	 * @return
	 */
	public String getAssignedRelayPortsVO(String deviceId) {
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT * FROM ");sb.append(PortalDBEnum.TABLE_NAMES.assignedrelayports.name());
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.ASSIGNED_RELAY_PORTS.sDeviceID.name());sb.append(" = ");sb.append("?");
		return sb.toString();
	}

	/**
	 * create query to add assigned  relay port for device 
	 * @param deviceId
	 * @param relayServerID
	 * @param portSegmentStart
	 * @return
	 */
	public String addAssignedRelayPorts() {

		StringBuilder sb = new StringBuilder();
		sb.append("INSERT INTO ");
		sb.append(PortalDBEnum.TABLE_NAMES.assignedrelayports.name());
		sb.append(" ( ");
		sb.append(PortalDBEnum.ASSIGNED_RELAY_PORTS.sDeviceID.name());
		sb.append(", ");
		sb.append(PortalDBEnum.ASSIGNED_RELAY_PORTS.sRelayServerID.name());
		sb.append(", ");
		sb.append(PortalDBEnum.ASSIGNED_RELAY_PORTS.nPortSegmentStart.name());
		sb.append(", ");
		sb.append(PortalDBEnum.ASSIGNED_RELAY_PORTS.nStatus.name());
		sb.append(", ");
		sb.append(PortalDBEnum.ASSIGNED_RELAY_PORTS.dModified.name());
		sb.append(" ) VALUES (");
		sb.append("?");
		//sb.append(dbCon.formatString(deviceId));
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(relayServerID));
		sb.append(", ");
		sb.append("?");
//		sb.append(portSegmentStart);
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString("1"));
		sb.append(", NOW() )");
		sb.append(" ON DUPLICATE KEY UPDATE ");
		sb.append(PortalDBEnum.ASSIGNED_RELAY_PORTS.sRelayServerID.name());
		sb.append(" = ");
		sb.append("?");
//		sb.append(dbCon.formatString(relayServerID));
		sb.append(", ");
		sb.append(PortalDBEnum.ASSIGNED_RELAY_PORTS.nPortSegmentStart.name());
		sb.append(" = ");
		sb.append("?");
//		sb.append(portSegmentStart);
		sb.append(", ");
		sb.append(PortalDBEnum.ASSIGNED_RELAY_PORTS.nStatus.name());
		sb.append(" = ");
		sb.append("?");
//		sb.append(dbCon.formatString("1"));
		sb.append(", ");
		sb.append(PortalDBEnum.ASSIGNED_RELAY_PORTS.dModified.name());
		sb.append(" = NOW()");
		return sb.toString();
	}

	/**
	 * create query to get assigned relay ports for device and realye server id.
	 * @param deviceId
	 * @param relayServerId
	 * @return
	 */
	public String getAssignedRelayPortsVO() {
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT * FROM ");sb.append(PortalDBEnum.TABLE_NAMES.assignedrelayports.name());
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.ASSIGNED_RELAY_PORTS.sRelayServerID.name());sb.append(" = ");sb.append("?");
		sb.append(" AND ");
		sb.append(PortalDBEnum.ASSIGNED_RELAY_PORTS.sDeviceID.name());sb.append(" = ");sb.append("?");
		return sb.toString();
		}
	
	/**
	 * Create query to update status of relay server port to 2 for device id.
	 * @param deviceId
	 * @return
	 */
	public String updateAssignedPortsStatus() {
		StringBuilder sb = new StringBuilder();
		sb.append("UPDATE ");
		sb.append(PortalDBEnum.TABLE_NAMES.assignedrelayports.name());
		sb.append(" SET ");
		sb.append(PortalDBEnum.ASSIGNED_RELAY_PORTS.nStatus.name());
		sb.append(" = ");
		sb.append("?");
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.ASSIGNED_RELAY_PORTS.sDeviceID.name());
		sb.append(" = ");
		sb.append("?");
		return sb.toString();
	}

	/**
	 * Create query to update sDeviceId in assigned relay ports and set deviceId where sDeviceId is set to macAddress.  
	 * @param macAddress
	 * @param deviceId
	 * @return
	 */
	public String updateAssignMacdevice() {
		StringBuilder sb = new StringBuilder();
		sb.append("UPDATE ");sb.append(PortalDBEnum.TABLE_NAMES.assignedrelayports.name());
		sb.append(" SET ");
		sb.append(PortalDBEnum.ASSIGNED_RELAY_PORTS.sDeviceID.name());sb.append(" = ");sb.append("?");
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.ASSIGNED_RELAY_PORTS.sDeviceID.name());sb.append(" = ");sb.append("?");
		return sb.toString();
	}
}
