/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal.engine;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import com.mwp.common.CredProvider;
import com.mwp.common.StringFunctions;
import com.mwp.common.Utils;
import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.common.constant.Constant;
import com.mwp.common.constant.ErrorMessage;
import com.mwp.common.enums.Operator;
import com.mwp.common.enums.RedirectType;
import com.mwp.common.enums.SignUpTypeEnum;
import com.mwp.common.enums.Status;
import com.mwp.common.vo.AppInstallDetailsVO;
import com.mwp.common.vo.AppNotificationVo;
import com.mwp.common.vo.ApplicationDetailsVO;
import com.mwp.common.vo.ApplicationImagesVO;
import com.mwp.common.vo.ApplicationPlatformVO;
import com.mwp.common.vo.ApplicationVO;
import com.mwp.common.vo.CategoryVO;
import com.mwp.common.vo.DevAppDetailsVO;
import com.mwp.common.vo.FilterObject;
import com.mwp.common.vo.PortVO;
import com.mwp.common.vo.QueryVO;
import com.mwp.common.vo.ServiceEndpointVO;
import com.mwp.common.vo.VersionVO;
import com.mwp.p.common.Constants;
import com.mwp.p.common.PortalCommon;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.common.vo.AppCommandVO;
import com.mwp.p.common.vo.DeviceApplicationVO;
import com.mwp.p.common.vo.UsersApplicationsVersionVO;
import com.mwp.p.dal.ApplicationDetailsDB;
import com.mwp.p.dal.ApplicationGroupsDB;
import com.mwp.p.dal.ApplicationVersionDB;
import com.mwp.p.dal.ApplicationsDB;
import com.mwp.p.dal.DeviceApplicationsDB;
import com.mwp.p.dal.EdgeCoreGroupsDB;
import com.pa.crypto.StringEncryptionDecryption;

/**
 * This class manage application, give list of application in various way (search application- using filterObject, suggested application),
 * get details of application.
 * @author root
 *
 */
public class ApplicationsEngine {

	/**
	 * This method gives all applications using paging and 
	 * filters (category, sort, search text, start with, start end, etc.).
	 * @param pageNo page number
	 * @param pageSize number of applications in one page.
	 * @param filters filters list to apply on search
	 * @return  HashMap<String, Object> with keys totalPages, pageSize, pageNumber, data . data is List<ApplicationVO> 
	 * @throws Exception 
	 */
	public Map<String, Object> searchApps(int pageNo, int pageSize, List<FilterObject> filters,boolean toListAllApps) throws SQLException {
		return mSearchApps(pageNo, pageSize, filters, toListAllApps);
	}

	/**
	 * This method gives list of all {@link ApplicationVO} 
	 * according to requested search text.
	 * @param searchText requested search text 
	 * @return  List<ApplicationVO> 
	 * @throws Exception
	 */
	public List<ApplicationVO> suggestedApps(String searchText) throws SQLException {
		return mSuggestedApps(searchText);
	}

	/**
	 * Get application details according to appId,
	 * and those which have application version status LIVE,
	 * userId is optional param (this is used for set IsInstalled property - app already installed on any user devices).
	 * @param appId
	 * @param userId
	 * @return
	 * @throws Exception
	 */
	public ApplicationDetailsVO getAppDetail(String appId,String userId) throws SQLException {
		//#AKH_01_1
		return mGetApplicationDetails(appId, userId);
	}

	/**
	 * This method returns map of actions for an application according to device
	 * @param appId
	 * @param userId
	 * @param grpIds
	 * @return List<AppCommandVO>
	 * @throws Exception
	 */
	public List<AppCommandVO> getAppCommandsForUser(String appId,String userId, List<String> grpIds) throws SQLException {
		return mGetAppCommandsForUser(appId, userId, grpIds);
	}

	/**
	 * This method gives application installation detail 
	 * according to given application Id.
	 * @param appId Application Id which is unique for each application.
	 * @param userId is optional if user wants this application installed on my device or not.
	 * @return AppInstallDetailsVO object
	 * @throws Exception 
	 */
	public AppInstallDetailsVO getAppInstallDetail(String appId,String versionId, String appPlatformId) throws SQLException {
		return mGetInstallAppDetails(appId, versionId, appPlatformId);
	}

	/**
	 * This method gives list application of user 
	 * according to given user Id.
	 * @param userId is who created the application.
	 * @return
	 * @throws Exception 
	 */
	public List<ApplicationVO> listApplicationOfUser(String userId) throws SQLException {
		return mListApplicationOfUser(userId);
	}

	/**
	 * This method gives all versions of application 
	 * according to given appId and UserId
	 * @param appId Application Id which is unique for each application.
	 * @param userId is who created the application.
	 * @return
	 * @throws Exception 
	 */
	public List<VersionVO> listVersionOfApplication(String appId,String userId) throws SQLException {
		return mListVersionOfApplication(appId,userId);
	}


	/**
	 * Get list of groups of requested app
	 * @param appId
	 * @param groupIds if group Ids not null or empty then group returned where group ids in this list. 
	 * @return
	 * @throws SQLException
	 */
	public List<String> listGroupsOfApp(String appId, List<String> groupIds) throws SQLException {
		return mListGroupsOfApp(appId, groupIds);
	}

	/**
	 * This method gives secretKey of application using applicationId and userId.
	 * @param appId
	 * @param userId
	 * @return secretKey in string param.
	 * @throws SQLException 
	 */
	public String getSecretKey(String appId, String userId) throws SQLException {
		return mGetSecretKey(appId, userId);
	}

	/**
	 * This method return DeviceApplicationVO object to UI, device application get according to appId and deviceId,
	 * This object contains info of, 
	 * (application, company, appVersion, appImages, deviceId, installationDate, appCategories, isUpdateAvailable). 
	 * @param appId
	 * @param deviceId
	 * @return DeviceApplicationVO object
	 * @throws SQLException
	 */
	public DeviceApplicationVO getInstalledDeviceAppDetail(String appId, String deviceId) throws SQLException {
		return mGetInstalledDeviceAppDetail(appId, deviceId);
	}


	/**
	 * with paging
	 * This method return DeviceApplicationVO object to UI, device application get according to appId and deviceId,
	 * This object contains info of, 
	 * (application, company, appVersion, appImages, deviceId, installationDate, appCategories, isUpdateAvailable). 
	 * @param appId
	 * @param pageNo
	 * @param pageSize
	 * @return  HashMap<String, Object> with keys totalPages, pageSize, pageNumber, data . data is  ArrayList<DeviceApplicationVO>
	 * @throws SQLException
	 */
	public Map<String, Object> getInstalledDeviceAppDetail(String appId ,int pageNo, int pageSize) throws SQLException {
		return mGetInstalledDeviceAppDetail(appId,pageNo,pageSize);
	}

	/**
	 * this query execute for getting new updated application version available,
	 * if getting true means new Update Available.
	 * @param appId - unique id of application.
	 * @param appVersionId - of application version installed on device.
	 * @return
	 * @throws SQLException 
	 */
	public boolean getUpdateAvailableForInstalledApp(String appId, String appVersionId, String appPlatformId) throws SQLException{
		boolean isUpdateAvailable = false;
		/*
		 * getting query for new updated application version available.
		 */
		String sql = new ApplicationDetailsDB().getUpdateAvailableForInstalledApp();

		List<String> parameters = new ArrayList<>();

		parameters.add(appPlatformId);
		parameters.add(appId);
		parameters.add(appVersionId);

		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(sql).addParameters(parameters).build();



		try(ResultSet r = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)){
			while (r.next()){
				/*
				 * isUpdateAvailable property "true" OR "false",
				 * so UI take decision on update available. 
				 */
				isUpdateAvailable = r.getBoolean("isUpdateAvailable");
			}
		}
		return isUpdateAvailable;
	}

	/**
	 * This method gives basic application detail without any status check,
	 * according to appId param.
	 * @param appId
	 * @return ApplicationVO object.
	 * @throws SQLException 
	 */
	public ApplicationVO getApplicationBasicDetail(String appId) throws SQLException{
		return mGetApplicationBasicDetail(appId);
	}

	/**
	 * This return AppNotificationVo object (Title, appVersion, size),
	 * Main Table application, LEFT JOIN (applicationversions).
	 * @param appId
	 * @param appVersionId get appVersion according to appVersionId
	 * @return AppNotificationVo
	 * @throws SQLException 
	 */
	public AppNotificationVo getAppDetailsForNotification(String appId, String appVersionId) throws SQLException {
		return mGetAppDetailsForNotification(appId, appVersionId);
	}

	/**
	 * method list apps with their latest version
	 * @param pageNo
	 * @param pageSize
	 * @return
	 * @throws Exception 
	 */
	public Map<String, Object> listAllLatestVersion(int pageNo, int pageSize) throws SQLException
	{
		return mListAllLatestVersion(pageNo,pageSize);
	}
	/**
	 * This return AppNotificationVo object (Title, appVersion, size),
	 * Main Table application, LEFT JOIN (applicationversions).
	 * @param appId
	 * @param appVersionId get appVersion according to appVersionId
	 * @return AppNotificationVo
	 * @throws SQLException 
	 */
	private AppNotificationVo mGetAppDetailsForNotification(String appId, String appVersionId) throws SQLException {
		/*
		 * AppNotificationVo VO object return to calling method.
		 */
		AppNotificationVo appNotifyVO = null;

		List<String> parameters = new ArrayList<>();
		parameters.add(appId);

		if(!StringFunctions.isNullOrWhitespace(appVersionId))
			parameters.add(appVersionId);


		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new ApplicationDetailsDB().getAppDetailsWithVersion(appVersionId)).addParameters(parameters).build();

		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)){
			while (rs.next()){
				if(appNotifyVO == null){
					appNotifyVO = new AppNotificationVo();
					appNotifyVO.setAppId(rs.getString(PortalDBEnum.APPLICATION.appId.name()));
					appNotifyVO.setVersionId(rs.getString(PortalDBEnum.APPLICATION_VERSIONS.appVersionId.name()));
					appNotifyVO.setVersion(rs.getString(PortalDBEnum.APPLICATION_VERSIONS.appVersion.name()));
					appNotifyVO.setTitle(rs.getString(PortalDBEnum.APPLICATION.title.name()));
					appNotifyVO.setSize(rs.getLong(PortalDBEnum.APPLICATION_VERSIONS.size.name()));
				}
			}
		}
		if(appNotifyVO == null){
			throw new SQLException("Application detail not found.");
		}
		return appNotifyVO;
	}

	/**
	 * This method gives basic application detail without any status check,
	 * according to appId param.
	 * @param appId
	 * @return ApplicationVO object.
	 * @throws SQLException 
	 */
	private ApplicationVO mGetApplicationBasicDetail(String appId) throws SQLException {
		/*
		 * ApplicationVO object. This will be returned to UI
		 */
		ApplicationVO appDetailsVO = null;

		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new ApplicationsDB().getApplicationBasicDetail()).addParameter(appId).build();


		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)){
			while (rs.next()){
				if(appDetailsVO == null){
					appDetailsVO = new ApplicationDetailsVO();
					appDetailsVO.setApplicationId(rs.getString(PortalDBEnum.APPLICATION.appId.name()));
					appDetailsVO.setAppTypeId(rs.getString(PortalDBEnum.APPLICATION.appTypeId.name()));
					/*
					 *  set owner id for permission check (which added at Portal getApplicationdetail() method).
					 */
					appDetailsVO.setAppOwnerId(rs.getString(PortalDBEnum.APPLICATION.userId.name()));
					appDetailsVO.setProjectId(rs.getString(PortalDBEnum.APPLICATION.projectId.name()));
					appDetailsVO.setIcon(rs.getString(PortalDBEnum.APPLICATION.icon.name()));
					/*
					 * add if check if icon has empty value then created publicURL.
					 */
					if(!StringFunctions.isNullOrWhitespace(appDetailsVO.getIcon())){
						appDetailsVO.setIcon(PortalCommon.getInstance().createPublicUrl(appDetailsVO.getIcon(), Constants.UI_FOLDER_NAME));
					}
					appDetailsVO.setAppStatus(Status.GetEnum(rs.getInt(PortalDBEnum.APPLICATION.appStatus.name())));
					appDetailsVO.setTitle(rs.getString(PortalDBEnum.APPLICATION.title.name()));
					appDetailsVO.setUserId(rs.getString(PortalDBEnum.APPLICATION.userId.name()));
					appDetailsVO.setWebAddress(rs.getString(PortalDBEnum.APPLICATION.webAddress.name()));
					//AKH_03, AKH_04
					appDetailsVO.setPrice(rs.getBigDecimal(PortalDBEnum.APPLICATION.price.name()));
					appDetailsVO.setRating(rs.getDouble(PortalDBEnum.APPLICATION.rating.name()));
					appDetailsVO.setCurrency(rs.getString(PortalDBEnum.APPLICATION.currency.name()));
					appDetailsVO.setRunAsService(rs.getBoolean(PortalDBEnum.APPLICATION.runAsService.name()));
					appDetailsVO.setCreatedDate(rs.getTimestamp(PortalDBEnum.APPLICATION.createdDate.name()).getTime());
					appDetailsVO.setModifiedDate(rs.getTimestamp(PortalDBEnum.APPLICATION.modifiedDate.name()).getTime());
				}
				ApplicationPlatformVO platformVO = new ApplicationPlatformVO();
				platformVO.setAppId(rs.getString(PortalDBEnum.APPLICATION.appId.name()));
				platformVO.setAppPlatformId(rs.getString(PortalDBEnum.APPLICATION_PLATFORM.appPlatformId.name()));
				platformVO.setPlatformId(rs.getString(PortalDBEnum.APPLICATION_PLATFORM.platformId.name()));
				platformVO.setRepositoryName(rs.getString(PortalDBEnum.APPLICATION_PLATFORM.repositoryName.name()));
				appDetailsVO.getPlatFormList().add(platformVO);

				/**
				 * Set repositery name -PS 
				 */
				appDetailsVO.setRepositoryName(platformVO.getRepositoryName());
			}
		}
		if(appDetailsVO == null){
			throw new SQLException("Application detail not found.");
		}
		return appDetailsVO;
	}



	/**
	 * This method return DeviceApplicationVO object to UI, device application get according to appId and deviceId,
	 * This object contains info of, 
	 * (application, company, appVersion, appImages, deviceId, installationDate, appCategories, isUpdateAvailable). 
	 * @param appId
	 * @param deviceId
	 * @return
	 * @throws SQLException
	 */
	private DeviceApplicationVO mGetInstalledDeviceAppDetail(String appId, String deviceId) throws SQLException {
		/*
		 * ApplicationDetails VO object. This will be returned to UI
		 */
		DeviceApplicationVO appDetailsVO = null;
		HashMap<String, CategoryVO> hashCategory = new HashMap<>();
		HashMap<String, ApplicationImagesVO> hashAppImage = new HashMap<>();
		HashMap<String, ApplicationPlatformVO> hashAppPlatform = new HashMap<>();
		String sql = new DeviceApplicationsDB().getInstalledDeviceAppDetail();

		List<String> parameters = new ArrayList<>();
		parameters.add(appId);
		parameters.add(deviceId);

		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(sql).addParameters(parameters).build();


		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)){
			String encKey = new CredProvider().getEcnKey();
			while (rs.next()){
				if(appDetailsVO == null){
					appDetailsVO = new DeviceApplicationVO();
					appDetailsVO.setApplicationId(rs.getString(PortalDBEnum.APPLICATION.appId.name()));
					appDetailsVO.setAppTypeId(rs.getString(PortalDBEnum.APPLICATION.appTypeId.name()));
					/*
					 *  set owner id for permission check (which added at Portal getApplicationdetail() method).
					 */
					appDetailsVO.setAppOwnerId(rs.getString(PortalDBEnum.APPLICATION.userId.name()));
					appDetailsVO.setProjectId(rs.getString(PortalDBEnum.APPLICATION.projectId.name()));
					appDetailsVO.setIcon(rs.getString(PortalDBEnum.APPLICATION.icon.name()));
					/*
					 * add if check if icon has empty value then created publicURL.
					 */
					if(!StringFunctions.isNullOrWhitespace(appDetailsVO.getIcon())){
						appDetailsVO.setIcon(PortalCommon.getInstance().createPublicUrl(appDetailsVO.getIcon(), Constants.UI_FOLDER_NAME));
					}
					appDetailsVO.setAppStatus(Status.GetEnum(rs.getInt(PortalDBEnum.APPLICATION.appStatus.name())));
					appDetailsVO.setTitle(rs.getString(PortalDBEnum.APPLICATION.title.name()));
					appDetailsVO.setUserId(rs.getString(PortalDBEnum.APPLICATION.userId.name()));
					appDetailsVO.setWebAddress(rs.getString(PortalDBEnum.APPLICATION.webAddress.name()));
					//AKH_03
					appDetailsVO.setDescription(rs.getString(PortalDBEnum.APPLICATION.description.name()));
					//AKH_02_1
					appDetailsVO.setPrice(rs.getBigDecimal(PortalDBEnum.APPLICATION.price.name()));
					appDetailsVO.setRating(rs.getDouble(PortalDBEnum.APPLICATION.rating.name()));
					appDetailsVO.setCurrency(rs.getString(PortalDBEnum.APPLICATION.currency.name()));
					appDetailsVO.setRunAsService(rs.getBoolean(PortalDBEnum.APPLICATION.runAsService.name()));
					appDetailsVO.setCreatedDate(rs.getTimestamp(PortalDBEnum.APPLICATION.createdDate.name()).getTime());
					appDetailsVO.setModifiedDate(rs.getTimestamp(PortalDBEnum.APPLICATION.modifiedDate.name()).getTime());
					/*
					 * this value get from joining ON table company.
					 */
					appDetailsVO.setCompanyName(StringEncryptionDecryption.decrypt(rs.getString(PortalDBEnum.COMPANY.companyName.name()), encKey));
					appDetailsVO.setCompanyWebAddress(StringEncryptionDecryption.decrypt(rs.getString("companyWebAddress"), encKey));
					/*
					 * appVersion and releaseNotes value get from joining ON table applicationversion.
					 * and it is which have status LIVE.
					 */
					appDetailsVO.setVersion(rs.getString(PortalDBEnum.APPLICATION_VERSIONS.appVersion.name()));
					appDetailsVO.setReleaseNotes(rs.getString(PortalDBEnum.APPLICATION_VERSIONS.releaseNotes.name()));
					appDetailsVO.setSize(rs.getLong(PortalDBEnum.APPLICATION_VERSIONS.size.name()));
					//AKH_04
					appDetailsVO.setRedirectUrl(rs.getString(PortalDBEnum.APPLICATION_VERSIONS.redirectUrl.name()));
					appDetailsVO.setRestRedirectUrl(rs.getString(PortalDBEnum.APPLICATION_VERSIONS.restRedirectUrl.name()));
					appDetailsVO.setRedirectSection(rs.getString(PortalDBEnum.APPLICATION_VERSIONS.redirectSection.name()));
					appDetailsVO.setRedirectType(RedirectType.GetEnum(rs.getInt(PortalDBEnum.APPLICATION_VERSIONS.redirectType.name())));
					//Set whole versionVO object to get all the properties to show on UI.- PS Bug 790   
					VersionVO versionVO = new VersionEngine().setVersionObject(rs);	
					appDetailsVO.getVersions().add(versionVO);

					/*
					 * set installation date of application on device from joining ON table deviceApplication. 
					 */
					appDetailsVO.setInstallationDate(rs.getTimestamp("installationDate").getTime());
					appDetailsVO.setDeviceId(deviceId);
					appDetailsVO.setDeviceName(rs.getString(PortalDBEnum.DEVICES.deviceName.name()));
				}
				/*
				 * Check appImageId not empty in resultSet and already not exist in hashTable of image,
				 * so duplicate entry not added in object.  
				 */
				String appImageId = rs.getString(PortalDBEnum.APPLICATION_IMAGES.appImageId.name());
				if(!StringFunctions.isNullOrWhitespace(appImageId) && !hashAppImage.containsKey(appImageId)){
					hashAppImage.put(appImageId, setApplicationImageObject(rs));
				}
				/*
				 * check category object not exist in hashTable of category,
				 * so duplicate entry not added in object.
				 */
				String catId = rs.getString(PortalDBEnum.CATEGORY.catId.name());
				if(!StringFunctions.isNullOrWhitespace(catId) && !hashCategory.containsKey(catId)){
					/*
					 * create category new object set values and ADD in hashCategory.
					 */
					CategoryVO categoryVO = new CategoryVO();
					categoryVO.setCategoryId(catId);
					categoryVO.setName(rs.getString(PortalDBEnum.CATEGORY.name.name()));
					hashCategory.put(catId, categoryVO);
				}
				String appPlatformId = rs.getString("appplatform_appPlatformId");
				if(!StringFunctions.isNullOrWhitespace(appPlatformId) && !hashAppPlatform.containsKey(appPlatformId)){
					/*
					 * create ApplicationPlatformVO new object set values and ADD in hashAppPlatform.
					 */
					ApplicationPlatformVO platformVO = new ApplicationPlatformVO();
					platformVO.setAppId(rs.getString(PortalDBEnum.APPLICATION.appId.name()));
					platformVO.setAppPlatformId(appPlatformId);
					platformVO.setPlatformId(rs.getString(PortalDBEnum.APPLICATION_PLATFORM.platformId.name()));
					platformVO.setRepositoryName(rs.getString(PortalDBEnum.APPLICATION_PLATFORM.repositoryName.name()));
					hashAppPlatform.put(appPlatformId, platformVO);
				}
			}
		}
		if(appDetailsVO == null){
			throw new SQLException("Application detail not found.");
		}
		/*
		 * set application images object from hashAppImage object which set in ResultSet iteration.
		 */
		appDetailsVO.getImages().addAll(hashAppImage.values());
		/*
		 * set application categories object from hashCategory object which set in ResultSet iteration.
		 */
		appDetailsVO.getCategories().addAll(hashCategory.values());
		appDetailsVO.getPlatFormList().addAll(hashAppPlatform.values());

		return appDetailsVO;
	}


	/**
	 * This method return DeviceApplicationVO object to UI, device application get according to appId and deviceId,
	 * This object contains info of, 
	 * (application, company, appVersion, appImages, deviceId, installationDate, appCategories, isUpdateAvailable). 
	 * @param appId
	 * @param deviceId
	 * @return
	 * @throws SQLException
	 */
	private HashMap<String, Object>  mGetInstalledDeviceAppDetail(String appId,int pageNo, int pageSize) throws SQLException {
		/*
		 * ApplicationDetails VO object. This will be returned to UI
		 */
		DeviceApplicationVO appDetailsVO = null;
		HashMap<String, CategoryVO> hashCategory = new HashMap<>();
		HashMap<String, ApplicationImagesVO> hashAppImage = new HashMap<>();
		HashMap<String, ApplicationPlatformVO> hashAppPlatform = new HashMap<>();
		HashMap<String, Object> hashOutput = new HashMap<>();
		ArrayList<DeviceApplicationVO> deviceApplication = new ArrayList<>();

		//		sb.append(" WHERE ");
		//		sb.append(" a.appId = ");sb.append(PortalDatabaseEngine.getInstance().getConnection().formatString(appId));
		//		sb.append(" ORDER BY ");
		//		sb.append(PortalDBEnum.TABLE_NAMES.devices);sb.append(".");sb.append(PortalDBEnum.DEVICES.deviceName);sb.append(" ASC ");
		//		sb.append(" limit ");
		//		sb.append(pageSize);
		//		sb.append(" offset ");
		//		sb.append(offset);

		int offset = (pageNo-1) * pageSize;

		List<Object> parameters = new ArrayList<>();
		parameters.add(appId);
		parameters.add(pageSize);
		parameters.add(offset);

		List<String> sqlList = new DeviceApplicationsDB().getInstalledDeviceAppDetailWithLimitOffset();

		QueryVO queryVOData = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(sqlList.get(0)).addParameters(parameters).build();


		QueryVO queryVOCount = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(sqlList.get(1)).addParameters(parameters).build();

		int totalCategoryCount = 0;

		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVOData);
				ResultSet rsCount = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVOCount)){

			while (rsCount.next()){
				if(totalCategoryCount <= 0){
					/*
					 * getting total no of rows without page limit.
					 */
					totalCategoryCount = rsCount.getInt("appCount");
				}
			}
			String encKey = new CredProvider().getEcnKey();
			while (rs.next()){

				String deviceid = rs.getString(PortalDBEnum.DEVICE_APPLICATIONS.deviceId.name());

				appDetailsVO = new DeviceApplicationVO();
				appDetailsVO.setApplicationId(rs.getString(PortalDBEnum.APPLICATION.appId.name()));
				appDetailsVO.setAppTypeId(rs.getString(PortalDBEnum.APPLICATION.appTypeId.name()));
				/*
				 *  set owner id for permission check (which added at Portal getApplicationdetail() method).
				 */
				appDetailsVO.setAppOwnerId(rs.getString(PortalDBEnum.APPLICATION.userId.name()));
				appDetailsVO.setProjectId(rs.getString(PortalDBEnum.APPLICATION.projectId.name()));
				appDetailsVO.setIcon(rs.getString(PortalDBEnum.APPLICATION.icon.name()));
				/*
				 * add if check if icon has empty value then created publicURL.
				 */
				if(!StringFunctions.isNullOrWhitespace(appDetailsVO.getIcon())){
					appDetailsVO.setIcon(PortalCommon.getInstance().createPublicUrl(appDetailsVO.getIcon(), Constants.UI_FOLDER_NAME));
				}
				appDetailsVO.setAppStatus(Status.GetEnum(rs.getInt(PortalDBEnum.APPLICATION.appStatus.name())));
				appDetailsVO.setTitle(rs.getString(PortalDBEnum.APPLICATION.title.name()));
				appDetailsVO.setUserId(rs.getString(PortalDBEnum.APPLICATION.userId.name()));
				appDetailsVO.setWebAddress(rs.getString(PortalDBEnum.APPLICATION.webAddress.name()));
				//AKH_03
				appDetailsVO.setDescription(rs.getString(PortalDBEnum.APPLICATION.description.name()));
				//AKH_02_1
				appDetailsVO.setPrice(rs.getBigDecimal(PortalDBEnum.APPLICATION.price.name()));
				appDetailsVO.setRating(rs.getDouble(PortalDBEnum.APPLICATION.rating.name()));
				appDetailsVO.setCurrency(rs.getString(PortalDBEnum.APPLICATION.currency.name()));
				appDetailsVO.setRunAsService(rs.getBoolean(PortalDBEnum.APPLICATION.runAsService.name()));
				appDetailsVO.setCreatedDate(rs.getTimestamp(PortalDBEnum.APPLICATION.createdDate.name()).getTime());
				appDetailsVO.setModifiedDate(rs.getTimestamp(PortalDBEnum.APPLICATION.modifiedDate.name()).getTime());
				/*
				 * this value get from joining ON table company.
				 */
				appDetailsVO.setCompanyName(StringEncryptionDecryption.decrypt(rs.getString(PortalDBEnum.COMPANY.companyName.name()), encKey));
				appDetailsVO.setCompanyWebAddress(StringEncryptionDecryption.decrypt(rs.getString("companyWebAddress"), encKey));
				/*
				 * appVersion and releaseNotes value get from joining ON table applicationversion.
				 * and it is which have status LIVE.
				 */
				appDetailsVO.setVersion(rs.getString(PortalDBEnum.APPLICATION_VERSIONS.appVersion.name()));
				appDetailsVO.setReleaseNotes(rs.getString(PortalDBEnum.APPLICATION_VERSIONS.releaseNotes.name()));
				appDetailsVO.setSize(rs.getLong(PortalDBEnum.APPLICATION_VERSIONS.size.name()));
				//AKH_04
				appDetailsVO.setRedirectUrl(rs.getString(PortalDBEnum.APPLICATION_VERSIONS.redirectUrl.name()));
				appDetailsVO.setRestRedirectUrl(rs.getString(PortalDBEnum.APPLICATION_VERSIONS.restRedirectUrl.name()));
				appDetailsVO.setRedirectSection(rs.getString(PortalDBEnum.APPLICATION_VERSIONS.redirectSection.name()));
				appDetailsVO.setRedirectType(RedirectType.GetEnum(rs.getInt(PortalDBEnum.APPLICATION_VERSIONS.redirectType.name())));

				//Set whole versionVO object to get all the properties to show on UI.- PS Bug 790  
				VersionVO versionVO = new VersionEngine().setVersionObject(rs);	
				appDetailsVO.getVersions().add(versionVO);

				/*
				 * set installation date of application on device from joining ON table deviceApplication. 
				 */
				appDetailsVO.setInstallationDate(rs.getTimestamp("installationDate").getTime());
				appDetailsVO.setDeviceId(deviceid);
				appDetailsVO.setDeviceName(rs.getString(PortalDBEnum.DEVICES.deviceName.name()));
				appDetailsVO.setStatus(Status.GetEnum(rs.getInt(PortalDBEnum.DEVICE_APPLICATIONS.deviceAppstatus.name())));
				appDetailsVO.setVerionId(rs.getString(PortalDBEnum.DEVICE_APPLICATIONS.appVersionId.name()));

				/*
				 * Check appImageId not empty in resultSet and already not exist in hashTable of image,
				 * so duplicate entry not added in object.  
				 */
				String appImageId = rs.getString(PortalDBEnum.APPLICATION_IMAGES.appImageId.name());
				if(!StringFunctions.isNullOrWhitespace(appImageId) && !hashAppImage.containsKey(appImageId)){
					hashAppImage.put(appImageId, setApplicationImageObject(rs));
				}
				/*
				 * check category object not exist in hashTable of category,
				 * so duplicate entry not added in object.
				 */
				String catId = rs.getString(PortalDBEnum.CATEGORY.catId.name());
				if(!StringFunctions.isNullOrWhitespace(catId) && !hashCategory.containsKey(catId)){
					/*
					 * create category new object set values and ADD in hashCategory.
					 */
					CategoryVO categoryVO = new CategoryVO();
					categoryVO.setCategoryId(catId);
					categoryVO.setName(rs.getString(PortalDBEnum.CATEGORY.name.name()));
					hashCategory.put(catId, categoryVO);
				}
				deviceApplication.add(appDetailsVO);
			}		
		}	
		if(appDetailsVO == null){
			throw new SQLException("Application detail not found.");
		}
		/*
		 * set application images object from hashAppImage object which set in ResultSet iteration.
		 */
		appDetailsVO.getImages().addAll(hashAppImage.values());
		/*
		 * set application categories object from hashCategory object which set in ResultSet iteration.
		 */
		appDetailsVO.getCategories().addAll(hashCategory.values());
		appDetailsVO.getPlatFormList().addAll(hashAppPlatform.values());


		/*
		 * calculate total pages count send to UI for next iteration.
		 */
		int totalPages = totalCategoryCount / pageSize;
		if((totalCategoryCount % pageSize) > 0){
			totalPages += 1;			
		}
		hashOutput.put(Constant.DATA, deviceApplication);
		hashOutput.put("totalPages", totalPages);
		hashOutput.put("pageNo", pageNo);
		hashOutput.put("pageSize", pageSize);

		return hashOutput;
	}

	/**
	 * This method give userId of application which is saved in db when app created,
	 * it gives null if app status 'DELETED' and not found, other return userId.
	 * @param appId
	 * @return userId of application.
	 * @throws SQLException
	 */
	public String getUserIdOfApp(String appId) throws SQLException {
		return mGetUserIdOfApp(appId);
	}

	private String mGetUserIdOfApp(String appId) throws SQLException {
		/**
		 * userId is local return variable default set null,
		 * it set when result set have value of userId in db.  
		 */
		String userId = null;
		/**
		 * This method give query for getting userId from db,
		 * using applicationId and appStaus != DELETED 
		 */
		String sql = new ApplicationsDB().getUserIdOfApp();

		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(sql).addParameter(appId).build();
		
		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)){
			while (rs.next()){
				userId = rs.getString(PortalDBEnum.APPLICATION.userId.name());
			}
		}
		return userId;
	}

	/**
	 * This method gives secretKey of application using applicationId and userId.
	 * @param appId
	 * @param userId
	 * @return secretKey in string param.
	 * @throws SQLException 
	 */
	private String mGetSecretKey(String appId, String userId) throws SQLException {
		/**
		 * secretKey is local return variable default set empty,
		 * it set when result set have value of secretKey in db.  
		 */
		String secretKey = "";
		/**
		 * This method give query for getting secretKey from db,
		 * using applicationId and userId 
		 */
		String sql = new ApplicationsDB().getSecretKey();
		
		List<String> parameters = new ArrayList<>();
		parameters.add(appId);
		parameters.add(userId);

		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(sql).addParameters(parameters).build();
		
		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)){
			while (rs.next()){
				secretKey = StringEncryptionDecryption.decrypt(rs.getString(PortalDBEnum.APPLICATION.secretKey.name()), new CredProvider().getEcnKey());
			}
		}
		/**
		 * throws sql exception if doesn't getting resultset and secretKey variable is empty.
		 */
		if("".equals(secretKey)){
			throw new SQLException("secretKey not found.");
		}
		return secretKey;
	}

	private List<ApplicationVO> mListApplicationOfUser(String userId) throws SQLException {
		List<ApplicationVO> listApplication = new ArrayList<>();
		String sql = new ApplicationsDB().listApplicationOfUser();
		
		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(sql).addParameter(userId).build();
		
		HashMap<String, ApplicationVO> hashApplication = new HashMap<>();
		List<String> listAppPlatform = new ArrayList<>();
		String appId = "";
		
		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)){
			while (rs.next()){
				appId = rs.getString(PortalDBEnum.APPLICATION.appId.name());
				if(!StringFunctions.isNullOrWhitespace(appId) && !hashApplication.containsKey(appId)){
					hashApplication.put(appId, setApplicationObject(rs));
				}

				String appPlatformId = rs.getString(PortalDBEnum.APPLICATION_PLATFORM.appPlatformId.name());
				if(!listAppPlatform.contains(appPlatformId)){
					/*
					 * create ApplicationPlatformVO new object set values and ADD in hashAppPlatform.
					 */
					ApplicationPlatformVO platformVO = new ApplicationPlatformVO();
					platformVO.setAppId(rs.getString(PortalDBEnum.APPLICATION.appId.name()));
					platformVO.setAppPlatformId(appPlatformId);
					platformVO.setPlatformId(rs.getString(PortalDBEnum.APPLICATION_PLATFORM.platformId.name()));
					platformVO.setRepositoryName(rs.getString(PortalDBEnum.APPLICATION_PLATFORM.repositoryName.name()));
					hashApplication.get(appId).getPlatFormList().add(platformVO);
				}
			}
		}
		listApplication.addAll(hashApplication.values());
		return listApplication;
	}

	private HashMap<String, Object> mSearchApps(int pageNo, int pageSize, List<FilterObject> filters,boolean toListAllApps) throws SQLException {
		HashMap<String, Object> hashOutput = new HashMap<>();
		List<ApplicationVO> listApplication = new ArrayList<>();
		List<String> queries = new ApplicationsDB().searchApps(filters,toListAllApps);
		
		int totalAlertCount = 0;

		long offset = (pageNo - 1) * pageSize;

		List<Object> parameters = createFilterParameters(filters);
		parameters.add(pageSize);
		parameters.add(offset);
		
		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
						.appendQuery(queries.get(0)).addParameters(parameters).build();

		QueryVO queryVOCount = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
						.appendQuery(queries.get(1)).build();
		
		int totalAppCount = 0; 
		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO);
				ResultSet rsCount = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVOCount)){
			while (rsCount.next()){
				totalAppCount = rsCount.getInt("rowCount");    
			}
			while (rs.next()){
				listApplication.add(setApplicationObject(rs));

			}
		}
		int totalPages = totalAppCount / pageSize;
		if((totalAppCount % pageSize) > 0){
			totalPages += 1;			
		}
		hashOutput.put(Constant.DATA, listApplication);
		hashOutput.put("totalPages", totalPages);
		hashOutput.put("pageNo", pageNo);
		hashOutput.put("pageSize", pageSize);
		hashOutput.put("totalAppCount", totalAppCount);
		return hashOutput;
	}
	
	private List<Object> createFilterParameters(List<FilterObject> filters) {
		List<Object> parameters = new LinkedList<>();
		String searchString = "";
		if (filters != null) {
			for (FilterObject filterObject : filters) {
				switch (filterObject.getFilterType()) {
				case CATEGORY:
					if (filterObject.getValues().size() > 1) {
//						sqlArryaParam = new SqlArrayParam(filterObject.getValues().toArray(), SQLConstant.TYPE_NAME_VARCHAR);
						parameters.addAll(filterObject.getValues());
					} else {
						parameters.add(filterObject.getValues().get(0));
					}
					break;
				case FILTER:
					switch (filterObject.getStartValue().trim()) {
					case "1":// "Free"
					
						break;
					case "2":// "Paid"
						
						break;
					case "3":// "4 stars and above"
						
						break;
					case "4":// "3 stars and above"
						
						break;
					case "status":
						List<Integer> lstStatus = new ArrayList<>();
						for (String appStatus : filterObject.getValues()) {
							lstStatus.add(Status.valueOf(appStatus).ordinal());
						}
						
//						sqlArryaParam = new SqlArrayParam(lstStatus.toArray(), SQLConstant.TYPE_NAME_VARCHAR);
//						parameters.add(sqlArryaParam);
						parameters.addAll(lstStatus);
						break;
					case "appType":
//						sqlArryaParam = new SqlArrayParam(filterObject.getValues().toArray(), SQLConstant.TYPE_NAME_VARCHAR);
//						parameters.add(sqlArryaParam);
						parameters.addAll(filterObject.getValues());
						break;
					default:
						break;

					}
					break;
				case SEARCHTEXT:
					if (filterObject.getOperator().ordinal() == Operator.LIKE.ordinal()) {
						searchString = filterObject.getStartValue();
						parameters.add(Utils.getFormatStringForLike(true, searchString, true));
					} else if (filterObject.getOperator().ordinal() == Operator.EQUAL.ordinal()) {
						parameters.add(filterObject.getStartValue());
					}

					break;
				case SORT: 
					switch (filterObject.getStartValue().trim()) {
					case "title":
						if (!StringFunctions.isNullOrEmpty(searchString)) {
							
							parameters.add(searchString);
							
							parameters.add(Utils.getFormatStringForLike(false, searchString, true));
							
							parameters.add(Utils.getFormatStringForLike(true, searchString, false));
						}
						break;
					case "1":// "Low to High"
						
						break;
					case "2":// "High to Low"
						
						break;
					case "3":// "Most popular"
						
						break;
					case "4":// "Latest first"
						
						break;
					case "status":
						
						break;
					case "creationTime":
						
						break;
					default:
						break;
					}
					
					break;

				default:
					break;
				}
			}
		}
		
		return parameters;
	}

	private List<ApplicationVO> mSuggestedApps(String searchText) throws SQLException {
		List<ApplicationVO> listApp = new ArrayList<>();
		String sql = new ApplicationsDB().listApp();

		QueryVO query = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameterForLike(false, searchText, true).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(query)) {
			while (rs.next()) {
				// set list of application object.
				listApp.add(setApplicationObject(rs));
			}
		}
		return listApp;
	}
	
	public List<String> getEdgeCoreByGroupIds(List<String> grpIds) throws SQLException {
		if (grpIds == null || grpIds.isEmpty()) {
			grpIds = new ArrayList<>();
			grpIds.add("");
		}
		String sql = new EdgeCoreGroupsDB().listEdgeCoreForGroups(grpIds);

		List<String> edgeCoreIds = new ArrayList<>();
		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameters(grpIds).build();
		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				edgeCoreIds.add(rs.getString(PortalDBEnum.GROUP_EDGECORE.edgeCoreId.name()));
			}
		}
		return edgeCoreIds;
	}

	private List<AppCommandVO> mGetAppCommandsForUser(String appId,String userId,List<String> grpIds) throws SQLException {
		
		List<String> edgeCoreIds = getEdgeCoreByGroupIds(grpIds);
		
		String sql = new DeviceApplicationsDB().getApplicationStatusOnUserDevices(edgeCoreIds);

		SqlQueryBuilder queryBuilder = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(appId)
						.addParameter(userId);
		if (edgeCoreIds != null && !edgeCoreIds.isEmpty()) {
			queryBuilder.addParameters(edgeCoreIds);
		}
		
		QueryVO queryVO = queryBuilder.build();

		List<AppCommandVO> result = new ArrayList<>();
		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()){
				String[] actions = rs.getString("actions").split(",");
				AppCommandVO appCommandVO = new AppCommandVO();
				appCommandVO.setActions(Arrays.asList(actions));
				appCommandVO.setDeviceId(rs.getString(PortalDBEnum.DEVICE_APPLICATIONS.deviceId.name()));
				appCommandVO.setDeviceName(rs.getString(PortalDBEnum.DEVICES.deviceName.name()));
				result.add(appCommandVO);
			}
		}

		return result;
	}


	/**
	 * Get application details according to appId,
	 * and those which have application version status LIVE,
	 * userId is optional param (this is used for set IsInstalled property - app already installed on any user devices).
	 * @param appId
	 * @param userId
	 * @return
	 * @throws Exception
	 */
	private ApplicationDetailsVO mGetApplicationDetails(String appId, String userId) throws SQLException {
		/*
		 * ApplicationDetails VO object. This will be returned to UI
		 */
		ApplicationDetailsVO appDetailsVO = null;
		Map<String, CategoryVO> hashCategory = new HashMap<>();
		Map<String, ApplicationImagesVO> hashAppImage = new HashMap<>();
		Map<String, ApplicationPlatformVO> hashAppPlatform = new HashMap<>();
		Map<String, VersionVO> hashVersion = new HashMap<>();

		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new ApplicationDetailsDB().getApplicationDetails()).addParameter(appId).build();

		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)){
			String encKey = new CredProvider().getEcnKey();
			while (rs.next()){
				if(appDetailsVO == null){
					appDetailsVO = new ApplicationDetailsVO();
					appDetailsVO.setApplicationId(rs.getString(PortalDBEnum.APPLICATION.appId.name()));
					appDetailsVO.setAppTypeId(rs.getString(PortalDBEnum.APPLICATION.appTypeId.name()));
					/*
					 *  set owner id for permission check (which added at Portal getApplicationdetail() method).
					 */
					appDetailsVO.setAppOwnerId(rs.getString(PortalDBEnum.APPLICATION.userId.name()));
					appDetailsVO.setProjectId(rs.getString(PortalDBEnum.APPLICATION.projectId.name()));
					appDetailsVO.setIcon(rs.getString(PortalDBEnum.APPLICATION.icon.name()));
					/*
					 * add if check if icon has empty value then created publicURL.
					 */
					if(!StringFunctions.isNullOrWhitespace(appDetailsVO.getIcon())){
						appDetailsVO.setIcon(PortalCommon.getInstance().createPublicUrl(appDetailsVO.getIcon(), Constants.UI_FOLDER_NAME));
					}
					appDetailsVO.setAppStatus(Status.GetEnum(rs.getInt(PortalDBEnum.APPLICATION.appStatus.name())));
					appDetailsVO.setTitle(rs.getString(PortalDBEnum.APPLICATION.title.name()));
					appDetailsVO.setUserId(rs.getString(PortalDBEnum.APPLICATION.userId.name()));
					appDetailsVO.setWebAddress(rs.getString(PortalDBEnum.APPLICATION.webAddress.name()));
					//AKH_03

					appDetailsVO.setDescription(rs.getString(PortalDBEnum.APPLICATION.description.name()));
					//AKH_02_1
					appDetailsVO.setPrice(rs.getBigDecimal(PortalDBEnum.APPLICATION.price.name()));
					appDetailsVO.setRating(rs.getDouble(PortalDBEnum.APPLICATION.rating.name()));
					appDetailsVO.setCurrency(rs.getString(PortalDBEnum.APPLICATION.currency.name()));
					appDetailsVO.setRunAsService(rs.getBoolean(PortalDBEnum.APPLICATION.runAsService.name()));
					appDetailsVO.setCreatedDate(rs.getTimestamp(PortalDBEnum.APPLICATION.createdDate.name()).getTime());
					appDetailsVO.setModifiedDate(rs.getTimestamp(PortalDBEnum.APPLICATION.modifiedDate.name()).getTime());
					/*
					 * this value get from joining ON table company.
					 */
					appDetailsVO.setCompanyName(StringEncryptionDecryption.decrypt(rs.getString(PortalDBEnum.COMPANY.companyName.name()), encKey));
					appDetailsVO.setCompanyWebAddress(StringEncryptionDecryption.decrypt(rs.getString("companyWebAddress"), encKey));
					/*
					 * appVersion and releaseNotes value get from joining ON table applicationversion.
					 * and it is which have status LIVE.
					 */
					appDetailsVO.setVersion(rs.getString(PortalDBEnum.APPLICATION_VERSIONS.appVersion.name()));
					appDetailsVO.setReleaseNotes(rs.getString(PortalDBEnum.APPLICATION_VERSIONS.releaseNotes.name()));
					appDetailsVO.setSize(rs.getLong(PortalDBEnum.APPLICATION_VERSIONS.size.name()));
					//AKH_04
					appDetailsVO.setRedirectUrl(rs.getString(PortalDBEnum.APPLICATION_VERSIONS.redirectUrl.name()));
					appDetailsVO.setRestRedirectUrl(rs.getString(PortalDBEnum.APPLICATION_VERSIONS.restRedirectUrl.name()));
					appDetailsVO.setRedirectSection(rs.getString(PortalDBEnum.APPLICATION_VERSIONS.redirectSection.name()));
					appDetailsVO.setRedirectType(RedirectType.GetEnum(rs.getInt(PortalDBEnum.APPLICATION_VERSIONS.redirectType.name())));
					appDetailsVO.setInstalled(false);					
				}
				/*
				 * Check appImageId not empty in resultSet and already not exist in hashTable of image,
				 * so duplicate entry not added in object.  
				 */
				String appImageId = rs.getString(PortalDBEnum.APPLICATION_IMAGES.appImageId.name());
				if(!StringFunctions.isNullOrWhitespace(appImageId) && !hashAppImage.containsKey(appImageId)){
					hashAppImage.put(appImageId, setApplicationImageObject(rs));
				}
				/*
				 * check category object not exist in hashTable of category,
				 * so duplicate entry not added in object.
				 */
				String catId = rs.getString(PortalDBEnum.CATEGORY.catId.name());
				if(!StringFunctions.isNullOrWhitespace(catId) && !hashCategory.containsKey(catId)){
					/*
					 * create category new object set values and ADD in hashCategory.
					 */
					CategoryVO categoryVO = new CategoryVO();
					categoryVO.setCategoryId(catId);
					categoryVO.setName(rs.getString(PortalDBEnum.CATEGORY.name.name()));
					hashCategory.put(catId, categoryVO);
				}
				String appPlatformId = rs.getString(PortalDBEnum.APPLICATION_PLATFORM.appPlatformId.name());
				if(!StringFunctions.isNullOrWhitespace(appPlatformId) && !hashAppPlatform.containsKey(appPlatformId)){
					/*
					 * create ApplicationPlatformVO new object set values and ADD in hashAppPlatform.
					 */
					ApplicationPlatformVO platformVO = new ApplicationPlatformVO();
					platformVO.setAppId(rs.getString(PortalDBEnum.APPLICATION.appId.name()));
					platformVO.setAppPlatformId(appPlatformId);
					platformVO.setPlatformId(rs.getString(PortalDBEnum.APPLICATION_PLATFORM.platformId.name()));
					platformVO.setRepositoryName(rs.getString(PortalDBEnum.APPLICATION_PLATFORM.repositoryName.name()));
					hashAppPlatform.put(appPlatformId, platformVO);
				}
				String appVersionId = rs.getString(PortalDBEnum.APPLICATION_VERSIONS.appVersionId.name());
				if(!StringFunctions.isNullOrWhitespace(appVersionId) && !hashVersion.containsKey(appVersionId)){
					/*
					 * create ApplicationPlatformVO new object set values and ADD in hashAppPlatform.
					 */
					VersionVO versionVO = new VersionVO();
					/*
					 * appVersion and releaseNotes value get from joining ON table applicationversion.
					 * and it is which have status LIVE.
					 */
					versionVO.setVersionId(appVersionId);
					versionVO.setVersionNumber(rs.getString(PortalDBEnum.APPLICATION_VERSIONS.appVersion.name()));
					versionVO.setReleaseNote(rs.getString(PortalDBEnum.APPLICATION_VERSIONS.releaseNotes.name()));
					versionVO.setSize(rs.getLong(PortalDBEnum.APPLICATION_VERSIONS.size.name()));
					versionVO.setRedirectUrl(rs.getString(PortalDBEnum.APPLICATION_VERSIONS.redirectUrl.name()));
					versionVO.setRestRedirectUrl(rs.getString(PortalDBEnum.APPLICATION_VERSIONS.restRedirectUrl.name()));
					versionVO.setRedirectSection(rs.getString(PortalDBEnum.APPLICATION_VERSIONS.redirectSection.name()));
					versionVO.setRedirectType(RedirectType.GetEnum(rs.getInt(PortalDBEnum.APPLICATION_VERSIONS.redirectType.name())));
					versionVO.setComposeVersion(rs.getString(PortalDBEnum.APPLICATION_VERSIONS.composeVersion.name()));

					versionVO.setModifiedDate(rs.getTimestamp("versionModifiedDate").getTime());
					versionVO.setAppPlatformId(rs.getString("appPlatformIdVersion"));
					hashVersion.put(appVersionId, versionVO);
				}
			}
		}
		if(appDetailsVO == null){
			throw new SQLException("Application detail not found.");
		}
		/*
		 * set application images object from hashAppImage object which set in ResultSet iteration.
		 */
		appDetailsVO.getImages().addAll(hashAppImage.values());
		/*
		 * set application categories object from hashCategory object which set in ResultSet iteration.
		 */
		appDetailsVO.getCategories().addAll(hashCategory.values());
		appDetailsVO.getPlatFormList().addAll(hashAppPlatform.values());
		appDetailsVO.getVersions().addAll(hashVersion.values());
		/*
		 * if userId set from UI, then we execute one more query,
		 * for getting this application installed on any of user devices,
		 * if getting true then we set application -> isInstalled property "true". 
		 */
		if(!StringFunctions.isNullOrWhitespace(userId)){
			/*
			 * getting query for app install on any user device.
			 */
			String sql = new DeviceApplicationsDB().isAppInstalledOnDevice();

			List<String> parameters = new ArrayList<>();
			parameters.add(userId);
			parameters.add(appId);

			QueryVO queryVO1 = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
					.appendQuery(sql).addParameters(parameters).build();

			try(ResultSet r = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO1)){
				while (r.next()){
					/*
					 * set application -> isInstalled property "true" OR "false",
					 * so UI take decision to show installed/install button. 
					 */
					appDetailsVO.setInstalled(r.getBoolean("isInstalled"));
				}
			}
		}
		return appDetailsVO;
	}


	/**
	 * Getting Install application details from joining (application/applicationserviceendpoints/applicationversions)
	 * @param appId
	 * @param appVersionId is optional param if empty then give LIVE status version.
	 * @return AppInstallDetailsVO object which is return on UI.
	 * @throws SQLException
	 */
	private AppInstallDetailsVO mGetInstallAppDetails(String appId, String appVersionId, String applicationPlatformId) throws SQLException {
		/*
		 * AppInstallDetails VO object. This will be returned to UI
		 */
		AppInstallDetailsVO installAppDetails = null;
		/*
		 * Getting Install application details query from joining (application/applicationserviceendpoints/applicationversions).
		 */

		List<String> parameters = new ArrayList<>();

		parameters.add(appId);

		if(!StringFunctions.isNullOrWhitespace(applicationPlatformId) && StringFunctions.isNullOrWhitespace(appVersionId)){
			parameters.add(applicationPlatformId);
		}
		else if(!StringFunctions.isNullOrWhitespace(appVersionId))
		{
			parameters.add(appVersionId);
		}

		//		sb.append(" WHERE ");
		//		sb.append(" a.appId = ");sb.append(PortalDatabaseEngine.getInstance().getConnection().formatString(appId));
		//		/*
		//		 * Added status check for deleted app in application details because deleted apps is being install by schedular.- PS 679
		//		 */
		//		sb.append(" AND ");
		//		sb.append("a.");sb.append(PortalDBEnum.APPLICATION.appStatus);sb.append(" != ");sb.append(Status.DELETED.ordinal());
		//		
		//		sb.append(" AND ");
		//		if(!StringFunctions.isNullOrWhitespace(appPlatformId) && StringFunctions.isNullOrWhitespace(appVersionId)){
		//			sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.appPlatformId.name());
		//			sb.append(" = ");sb.append(dbCon.formatString(appPlatformId));
		//			sb.append(" AND ");
		//			sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.versionStatus.name());
		//			sb.append(" = ");sb.append(VERSION_STATUS.LIVE.ordinal());
		//		}else if(StringFunctions.isNullOrWhitespace(appVersionId)){
		//			sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.versionStatus.name());
		//			sb.append(" = ");sb.append(VERSION_STATUS.LIVE.ordinal());
		//		} else{
		//			sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.appVersionId.name());
		//			sb.append(" = ");sb.append(PortalDatabaseEngine.getInstance().getConnection().formatString(appVersionId));
		//			/*
		//			 * Added status check for deleted version in  application version details because deleted version is being install by schedular.- PS  refre 714
		//			 */
		//			sb.append(" AND ");
		//			sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.versionStatus.name());
		//			sb.append(" != ");sb.append(VERSION_STATUS.DELETED.ordinal());
		//		}


		String sql = new ApplicationDetailsDB().getInstallAppDetails(appId, appVersionId, applicationPlatformId);

		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(sql).addParameters(parameters).build();


		/*
		 * create local hashtable for serviceEndpoints,
		 * to maintain duplicate entry not added in list.
		 */
		Map<String, ServiceEndpointVO> hashServiceEndpoints = new HashMap<>();
		Map<String, ApplicationPlatformVO> hashAppPlatform = new HashMap<>();
		Map<String, PortVO> hashPortList = new HashMap<>();

		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)){
			String encKey = new CredProvider().getEcnKey();
			while (rs.next()){
				if(installAppDetails == null){
					installAppDetails = new DevAppDetailsVO();
					installAppDetails.setApplicationId(rs.getString(PortalDBEnum.APPLICATION.appId.name()));
					installAppDetails.setAppTypeId(rs.getString(PortalDBEnum.APPLICATION.appTypeId.name()));
					installAppDetails.setAppOwnerId(rs.getString(PortalDBEnum.APPLICATION.userId.name()));
					installAppDetails.setAppStatus(Status.GetEnum(rs.getInt(PortalDBEnum.APPLICATION.appStatus.name())));
					installAppDetails.setDescription(rs.getString(PortalDBEnum.APPLICATION.description.name()));
					//AKH_02_1
					installAppDetails.setPrice(rs.getBigDecimal(PortalDBEnum.APPLICATION.price.name()));
					installAppDetails.setRating(rs.getDouble(PortalDBEnum.APPLICATION.rating.name()));
					installAppDetails.setCurrency(rs.getString(PortalDBEnum.APPLICATION.currency.name()));
					installAppDetails.setRunAsService(rs.getBoolean(PortalDBEnum.APPLICATION.runAsService.name()));
					installAppDetails.setIcon(rs.getString(PortalDBEnum.APPLICATION.icon.name()));
					/*
					 * add if check if icon has empty value then created publicURL.
					 */
					if(!StringFunctions.isNullOrWhitespace(installAppDetails.getIcon())){
						installAppDetails.setIcon(PortalCommon.getInstance().createPublicUrl(installAppDetails.getIcon(), Constants.UI_FOLDER_NAME));
					}
					installAppDetails.setProjectId(rs.getString(PortalDBEnum.APPLICATION.projectId.name()));
					//AKH_03

					installAppDetails.setTitle(rs.getString(PortalDBEnum.APPLICATION.title.name()));
					installAppDetails.setUserId(rs.getString(PortalDBEnum.APPLICATION.userId.name()));
					installAppDetails.setWebAddress(rs.getString(PortalDBEnum.APPLICATION.webAddress.name()));
					/*
					 * to show on UI secretKey giving only this method detail (getInstallAppDetail).
					 */
					installAppDetails.setSecretKey(StringEncryptionDecryption.decrypt(rs.getString(PortalDBEnum.APPLICATION.secretKey.name()), encKey));
					/*
					 * add Px default config value.
					 */
					installAppDetails.setUsePxAuth(rs.getBoolean(PortalDBEnum.APPLICATION.usePxAuth.name()));
					installAppDetails.setUsePxCloudApi(rs.getBoolean(PortalDBEnum.APPLICATION.usePxCloudApi.name()));
					installAppDetails.setUsePxEventService(rs.getBoolean(PortalDBEnum.APPLICATION.usePxEventService.name()));
					installAppDetails.setSignUpType(SignUpTypeEnum.GetEnum(rs.getInt(PortalDBEnum.APPLICATION.signUpType.name())));

					/*
					 * this value get from joining ON table company.
					 */
					installAppDetails.setCompanyName(StringEncryptionDecryption.decrypt(rs.getString(PortalDBEnum.COMPANY.companyName.name()), encKey));
					installAppDetails.setCompanyWebAddress(StringEncryptionDecryption.decrypt(rs.getString("companyWebAddress"), encKey));
					/*
					 * appVersion, composerFilePath, size and releaseNotes value get from joining ON table applicationversion.
					 * if appVersionId param has value then it get according to appVersionId
					 * else which have status LIVE.
					 */
					installAppDetails.setVersionId(rs.getString(PortalDBEnum.APPLICATION_VERSIONS.appVersionId.name()));
					installAppDetails.setVersion(rs.getString(PortalDBEnum.APPLICATION_VERSIONS.appVersion.name()));
					installAppDetails.setReleaseNotes(rs.getString(PortalDBEnum.APPLICATION_VERSIONS.releaseNotes.name()));
					installAppDetails.setComposeFileUrl(rs.getString(PortalDBEnum.APPLICATION_VERSIONS.composerFilePath.name()));
					installAppDetails.setSize(rs.getLong(PortalDBEnum.APPLICATION_VERSIONS.size.name()));
					String executionOrder =  rs.getString(PortalDBEnum.APPLICATION_VERSIONS.toExecuteOrder.name());
					List<String> executionOrderList = new ArrayList<>();
					if(!StringFunctions.isNullOrWhitespace(executionOrder))
						executionOrderList = new ArrayList<>(Arrays.asList(executionOrder.split(",")));  
					installAppDetails.setToExecuteOrder(executionOrderList);



					//AKH_04
					installAppDetails.setRedirectType(RedirectType.GetEnum(rs.getInt(PortalDBEnum.APPLICATION_VERSIONS.redirectType.name())));
					installAppDetails.setRedirectUrl(rs.getString(PortalDBEnum.APPLICATION_VERSIONS.redirectUrl.name()));
					installAppDetails.setRestRedirectUrl(rs.getString(PortalDBEnum.APPLICATION_VERSIONS.restRedirectUrl.name()));
					installAppDetails.setRedirectSection(rs.getString(PortalDBEnum.APPLICATION_VERSIONS.redirectSection.name()));
					/*
					 * set public url instead of local file path to download compose file from portal
					 */
					if(!StringFunctions.isNullOrWhitespace(installAppDetails.getComposeFileUrl())){
						installAppDetails.setComposeFileUrl(PortalCommon.getInstance().createPublicUrl(installAppDetails.getComposeFileUrl(), Constants.UI_FOLDER_NAME));
					}
				}
				/*
				 * create serviceEndpoint new object set values and ADD in serviceEndpoint list.
				 */
				String serviceEndpointId = rs.getString(PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.appServiceEndpointId.name());
				if(!StringFunctions.isNullOrWhitespace(serviceEndpointId) && !hashServiceEndpoints.containsKey(serviceEndpointId)){
					ServiceEndpointVO serviceEndpoint = new ServiceEndpointVO();
					serviceEndpoint.setAppServiceEndpointId(serviceEndpointId);
					serviceEndpoint.setServiceName(rs.getString(PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.serviceName.name()));
					hashServiceEndpoints.put(serviceEndpointId, serviceEndpoint);
				}

				String appPlatformId = rs.getString(PortalDBEnum.APPLICATION_PLATFORM.appPlatformId.name());
				if(!StringFunctions.isNullOrWhitespace(appPlatformId) && !hashAppPlatform.containsKey(appPlatformId)){
					/*
					 * create ApplicationPlatformVO new object set values and ADD in hashAppPlatform.
					 */
					ApplicationPlatformVO platformVO = new ApplicationPlatformVO();
					platformVO.setAppId(rs.getString(PortalDBEnum.APPLICATION.appId.name()));
					platformVO.setAppPlatformId(appPlatformId);
					platformVO.setPlatformId(rs.getString(PortalDBEnum.APPLICATION_PLATFORM.platformId.name()));
					platformVO.setRepositoryName(rs.getString(PortalDBEnum.APPLICATION_PLATFORM.repositoryName.name()));
					hashAppPlatform.put(appPlatformId, platformVO);

					installAppDetails.setRepositoryName(platformVO.getRepositoryName());
				}
				/*
				 * Add Application Service Port.
				 */
				String servicePortId = rs.getString(PortalDBEnum.APPLICATION_SERVICE_PORTS.appServicePortId.name());
				if(!StringFunctions.isNullOrWhitespace(servicePortId) && !hashPortList.containsKey(servicePortId)){
					PortVO servicePort = new PortVO();
					servicePort.setPortId(servicePortId);
					servicePort.setAppVersionId(rs.getString(PortalDBEnum.APPLICATION_SERVICE_PORTS.appVersionId.name()));
					servicePort.setImageId(rs.getString(PortalDBEnum.APPLICATION_SERVICE_PORTS.serviceName.name()));
					servicePort.setInternalPort(rs.getInt(PortalDBEnum.APPLICATION_SERVICE_PORTS.internalPort.name()));
					servicePort.setPort(Integer.valueOf(StringEncryptionDecryption.decrypt(rs.getString(PortalDBEnum.APPLICATION_SERVICE_PORTS.externalPort.name()), encKey)));
					hashPortList.put(servicePortId, servicePort);
				}
			}
		}
		if(installAppDetails == null){
			throw new SQLException(ErrorMessage.APPLICATION_NOT_FOUND);
		}
		/*
		 * Add list of serviceEndpoint in installAppDetails object which we return to UI.
		 */
		installAppDetails.getServiceEndpoints().addAll(hashServiceEndpoints.values());
		installAppDetails.getPlatFormList().addAll(hashAppPlatform.values());
		installAppDetails.getPorts().addAll(hashPortList.values());
		return installAppDetails;
	}

	protected ApplicationVO setApplicationObject(ResultSet rs) throws SQLException{
		ApplicationVO appVO = new UsersApplicationsVersionVO();
		appVO.setApplicationId(rs.getString(PortalDBEnum.APPLICATION.appId.name()));
		appVO.setAppTypeId(rs.getString(PortalDBEnum.APPLICATION.appTypeId.name()));
		appVO.setProjectId(rs.getString(PortalDBEnum.APPLICATION.projectId.name()));
		appVO.setIcon(rs.getString(PortalDBEnum.APPLICATION.icon.name()));
		if(!StringFunctions.isNullOrWhitespace(appVO.getIcon())){
			appVO.setIcon(PortalCommon.getInstance().createPublicUrl(appVO.getIcon(), Constants.UI_FOLDER_NAME));
		}
		appVO.setAppStatus(Status.GetEnum(rs.getInt(PortalDBEnum.APPLICATION.appStatus.name())));
		appVO.setTitle(rs.getString(PortalDBEnum.APPLICATION.title.name()));
		appVO.setUserId(rs.getString(PortalDBEnum.APPLICATION.userId.name()));
		appVO.setWebAddress(rs.getString(PortalDBEnum.APPLICATION.webAddress.name()));
		//AKH_02_1, AKH_03
		appVO.setPrice(rs.getBigDecimal(PortalDBEnum.APPLICATION.price.name()));
		appVO.setRating(rs.getDouble(PortalDBEnum.APPLICATION.rating.name()));
		appVO.setCurrency(rs.getString(PortalDBEnum.APPLICATION.currency.name()));
		appVO.setRunAsService(rs.getBoolean(PortalDBEnum.APPLICATION.runAsService.name()));

		appVO.setCreatedDate(rs.getTimestamp(PortalDBEnum.APPLICATION.createdDate.name()).getTime());
		appVO.setModifiedDate(rs.getTimestamp(PortalDBEnum.APPLICATION.modifiedDate.name()).getTime());

		return appVO;
	}



	protected ApplicationImagesVO setApplicationImageObject(ResultSet rs) throws SQLException{
		ApplicationImagesVO appImageVO = new  ApplicationImagesVO();
		appImageVO.setAppImageId(rs.getString(PortalDBEnum.APPLICATION_IMAGES.appImageId.name()));
		appImageVO.setAppId(rs.getString(PortalDBEnum.APPLICATION.appId.name()));
		appImageVO.setSequenceNo(rs.getInt(PortalDBEnum.APPLICATION_IMAGES.sequenceNo.name()));
		appImageVO.setImagePath(rs.getString(PortalDBEnum.APPLICATION_IMAGES.imagePath.name()));
		if(!StringFunctions.isNullOrWhitespace(appImageVO.getImagePath())){
			appImageVO.setImagePath(PortalCommon.getInstance().createPublicUrl(appImageVO.getImagePath(), Constants.UI_FOLDER_NAME));
		}
		return appImageVO;
	}

	private List<VersionVO> mListVersionOfApplication(String appId,
			String userId) throws SQLException {
		List<VersionVO> versionVOs = new ArrayList<>();
		
		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new ApplicationVersionDB().getAllAppVersionByOwner()).addParameter(appId).addParameter(userId).build();
		
		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)){
			while (	rs.next()){
				//set list of version object.
				versionVOs.add(new VersionEngine().setVersionObject(rs));
			}
		}
		return versionVOs;
	}

	protected ServiceEndpointVO setServiceEndpointObject(ResultSet rs) throws SQLException {
		ServiceEndpointVO serviceEndpoint = new ServiceEndpointVO();
		serviceEndpoint.setAppServiceEndpointId(rs.getString(PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.appServiceEndpointId.name()));
		serviceEndpoint.setAppVersionId(rs.getString(PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.appVersionId.name()));
		serviceEndpoint.setAppId(rs.getString(PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.appId.name()));
		serviceEndpoint.setPlatformId(rs.getString(PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.platformId.name()));
		serviceEndpoint.setContainerPort(rs.getInt(PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.containerPort.name()));
		serviceEndpoint.setCustomHeaders(rs.getString(PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.customHeaders.name()));
		serviceEndpoint.setImageName(rs.getString(PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.imageName.name()));
		serviceEndpoint.setProtocol(rs.getString(PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.protocol.name()));
		serviceEndpoint.setServiceName(rs.getString(PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.serviceName.name()));
		return serviceEndpoint;
	}

	private List<String> mListGroupsOfApp(String appId, List<String> groupIds) throws SQLException {
		List<String> listGroupIds = new ArrayList<>();

		String query = new ApplicationGroupsDB().getGroupsOfApp(appId, groupIds);

		//SqlArrayParam sqlArrayParam = new SqlArrayParam(groupIds.toArray(), SQLConstant.TYPE_NAME_VARCHAR);

		SqlQueryBuilder builder = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(query)
						.addParameter(appId);
		
		if (groupIds != null && !groupIds.isEmpty()) {
			builder.addParameters(groupIds);
		}
		QueryVO queryVO = builder.build();
		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				listGroupIds.add(rs.getString(PortalDBEnum.GROUP_APPLICATIONS.groupId.name()));
			}
		}

		return listGroupIds;
	}


	/**
	 * This method delete app 
	 * @param projectId
	 * @return
	 */
	public String deleteAppFromDb(String projectId)
	{
		return mDeleteAppFromDb(projectId);
	}

	private String mDeleteAppFromDb(String projectId)
	{
		ApplicationsDB applicationDB=new ApplicationsDB();
		return applicationDB.deleteAppsFromDb(projectId);
	}

	private Map<String, Object> mListAllLatestVersion(int pageNo, int pageSize) throws SQLException
	{
		HashMap<String, Object> hashOutput = new HashMap<>();
		List<ApplicationDetailsVO> listApplication = new ArrayList<>();
		List<String> queries = new ApplicationVersionDB().getAllLatestVersion();
		
		int offset = (pageNo-1) * pageSize;

		List<Object> parameters = new ArrayList<>();
		parameters.add(pageSize);
		parameters.add(offset);
		
		QueryVO queryVOData = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
					.appendQuery(queries.get(0)).addParameters(parameters).build();

		QueryVO queryVOCount = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(queries.get(1)).build();
		
		int totalAppCount = 0; 
		

		String appId="";
		HashMap<String, ApplicationDetailsVO> appMap= new HashMap<>();
		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVOData);
			ResultSet rsCount = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVOCount)){
			while (rsCount.next()){
				totalAppCount = rsCount.getInt("rowCount");    
			}
			while (rs.next())
			{
				appId= rs.getString(PortalDBEnum.TABLE_NAMES.application+ "." +PortalDBEnum.APPLICATION.appId.name());
				if(!appMap.containsKey(appId))
				{
					appMap.put(appId, setLatestVersionObject(rs));
				}
				else
				{
					ApplicationDetailsVO appDetailVoOld= appMap.get(appId);
					appDetailVoOld.getVersions().add(setVersionObject(rs));
				}

			}
		}
		int totalPages = totalAppCount / pageSize;
		if((totalAppCount % pageSize) > 0){
			totalPages += 1;			
		}
		listApplication.addAll(appMap.values());
		hashOutput.put(Constant.DATA, listApplication);
		hashOutput.put("totalPages", totalPages);
		hashOutput.put("pageNo", pageNo);
		hashOutput.put("pageSize", pageSize);
		return hashOutput;
	}
	public List<Map<String, String>> getCount() throws SQLException
	{
		return mGetCount();
	}
	public List<Map<String, String>> mGetCount() throws SQLException
	{
		ApplicationsDB appDb= new ApplicationsDB();

		String status="";
		int count = 0;
		HashMap<String, String> mapVal= new HashMap<>();
		ArrayList<Map<String, String>> returnList= new ArrayList<>();

		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(appDb.getCount()).build();

		try(ResultSet result =  PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO))
		{	
			while(result.next())
			{
				mapVal= new HashMap<>();
				status= Status.GetEnum(result.getInt(PortalDBEnum.APPLICATION.appStatus.name())).name();
				count= result.getInt("count");
				mapVal.put("Status", status);
				mapVal.put("Count",String.valueOf(count));
				returnList.add(mapVal);

			}
		}		
		return returnList;
	}
	protected ApplicationDetailsVO setLatestVersionObject(ResultSet rs) throws SQLException
	{
		ApplicationDetailsVO appVO = new ApplicationDetailsVO();
		appVO.setApplicationId(rs.getString(PortalDBEnum.TABLE_NAMES.application+ "." +PortalDBEnum.APPLICATION.appId.name()));
		appVO.setIcon(rs.getString(PortalDBEnum.TABLE_NAMES.application+ "." +PortalDBEnum.APPLICATION.icon.name()));
		if(!StringFunctions.isNullOrWhitespace(appVO.getIcon())){
			appVO.setIcon(PortalCommon.getInstance().createPublicUrl(appVO.getIcon(), Constants.UI_FOLDER_NAME));
		}
		appVO.setAppTypeId(rs.getString(PortalDBEnum.TABLE_NAMES.application+ "." + PortalDBEnum.APPLICATION.appTypeId.name()));
		appVO.setWebAddress(rs.getString(PortalDBEnum.TABLE_NAMES.application+ "." +PortalDBEnum.APPLICATION.webAddress.name()));
		appVO.setTitle(rs.getString(PortalDBEnum.TABLE_NAMES.application+ "." +PortalDBEnum.APPLICATION.title.name()));
		List<VersionVO> versions= new ArrayList<>();
		versions.add(setVersionObject(rs));
		appVO.setVersions(versions);
		return appVO;
	}

	protected VersionVO setVersionObject(ResultSet rs) throws SQLException
	{
		VersionVO versionVo = new VersionVO();
		versionVo.setVersionNumber(rs.getString("versionNumber"));
		versionVo.setAppPlatformId(rs.getString(PortalDBEnum.TABLE_NAMES.applicationversions+ "." +PortalDBEnum.APPLICATION_VERSIONS.appPlatformId.name()));
		return versionVo;
	}


}

/**
 * History of check-in or issue resolved
 * 
 * 01 - 12-10-2016 
 * AKH_01_1
 * Remove mGetAppDetail and use new mGetApplicationDetail method, 
 * because in old method mashup with getDevAppDetail and getAppInstallDetail and use unnecessary query. 
 * 
 * 02 - 21-10-2016
 * AKH_02_1
 * set currency, price and rating field for used sorting on UI.
 * 
 * 03 - 4-11-2016
 * AKH_03
 * set restRedirectUrl and redirectSection in application we save "reverse proxy" and "specific port" in redirect Url and rest Url save in restRedirectUrl.
 * 
 * 04 - 14-11-2016 AKH_04
 * remove restRedirectUrl, redirectUrl, redirectType and redirectSection from application these property shift to applicationVersion,
 * because may be each version have different redirection param so we get from applicationVersionDB.
 */
