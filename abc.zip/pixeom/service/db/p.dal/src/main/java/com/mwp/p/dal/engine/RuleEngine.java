/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal.engine;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.common.enums.RuleServerType;
import com.mwp.common.enums.RuleType;
import com.mwp.common.vo.QueryVO;
import com.mwp.common.vo.RuleVO;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.dal.RuleDal;


/**
 * this class contains query executors for get Rule from Rule table and parser to parse result set from Rule Table
 * @author root
 *
 */
public class RuleEngine 
{

	
	/**
	 * list all email servers 
	 * @return
	 * @throws SQLException
	 */
	public List<RuleVO> listsAll() throws SQLException
	{
		return mListsAll();
	}
	/**
	 * list all email servers 
	 * @return
	 * @throws SQLException
	 */
	public List<RuleVO> getRuleByTypes(RuleType ruletype) throws SQLException
	{
		return mGetRuleByTypes(ruletype.ordinal());
	}


	public RuleVO insert(RuleVO rulevo) throws SQLException 
	{
		return mInsert(rulevo);
	}
	public RuleVO update(String ruleId, String ruleValue) throws SQLException 
	{
		return mUpdate(ruleId, ruleValue);
	}
	
	public   void delete(String ruleId) throws SQLException 
	{
		mDelete(ruleId);
	}
	public RuleVO get(String ruleID) throws SQLException
	{
		return mGet(ruleID);
	}
	
	private List<RuleVO> mListsAll() throws SQLException
	{
		List<RuleVO> lstServer = new ArrayList<>();
		RuleDal ruleDalObj = new RuleDal();
		
		RuleVO voObj = null;
		
		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery( ruleDalObj.listAll()).build();

		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO))
		{
			while (rs.next())
			{
				 voObj = parseResultSet(rs);
				 lstServer.add(voObj);
				
			}
		}
		return lstServer;
	}
	
	private RuleVO mGet(String ruleID) throws SQLException
	{
		RuleVO voObj = null;
		RuleDal ruleDalObj = new RuleDal();
		
		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(ruleDalObj.getRule()).addParameter(ruleID).build();

		
		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO))
		{
			while (rs.next())
			{
				voObj = parseResultSet(rs);
			}
		}
		return voObj;
	}
	
	private ArrayList<RuleVO> mGetRuleByTypes(int ruleType) throws SQLException
	{
		ArrayList<RuleVO> rules = new ArrayList<>();
		RuleVO voObj = null;
		RuleDal ruleDalObj = new RuleDal();
		
		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(ruleDalObj.get()).addParameter(ruleType).build();

		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO))
		{
			while (rs.next())
			{
				voObj = parseResultSet(rs);
				rules.add(voObj);
			}
		}
		return rules;
	}
	


	private RuleVO mInsert(RuleVO rulevo) throws SQLException 
	{	
		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new RuleDal().insert())
				.addParameter(rulevo.getRuleId())
				.addParameter(rulevo.getRuleValue())
				.addParameter(rulevo.getRuleType().ordinal())
				.addParameter(rulevo.getServerType().ordinal())
				.addParameter(rulevo.getApplianceIsKub()).build();
		
		PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
	
		return mGet(rulevo.getRuleId());
	}
	
	private  RuleVO mUpdate(String ruleId, String ruleValue) throws SQLException 
	{
		RuleDal ruleDalObj = new RuleDal();
	
		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(ruleDalObj.update()).addParameter(ruleValue).addParameter(ruleId).build();

		PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
		return mGet(ruleId);
	}
	
	private   void mDelete(String ruleId) throws SQLException 
	{	
		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new RuleDal().delete())
				.addParameter(ruleId).build();

		PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
	}
	/**
	 * method to parse result set to EmailServersVO object
	 * @param result
	 * @return
	 * @throws SQLException 
	 */
	private RuleVO parseResultSet(ResultSet result) throws SQLException
	{	
		RuleVO ruleVO= new RuleVO();
		ruleVO.setRuleId(result.getString(PortalDBEnum.RULE.ruleId.name()));
		ruleVO.setRuleValue(result.getString(PortalDBEnum.RULE.ruleValue.name()));
		ruleVO.setRuleType(RuleType.GetEnum(result.getInt(PortalDBEnum.RULE.ruleType.name())));
		ruleVO.setServerType(RuleServerType.GetEnum(result.getInt(PortalDBEnum.RULE.serverType.name())));
		ruleVO.setApplianceIsKub(result.getBoolean(PortalDBEnum.RULE.isKub.name()));

		return ruleVO;
	}
	
}
