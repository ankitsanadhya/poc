/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.mwp.p.dal;

import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.common.enums.Status;
import com.mwp.common.enums.StatusEnum.VERSION_STATUS;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.common.enums.PortalDBEnum.DEVICES_NODES_VIEW;

public class UsersApplicationDB {

	/**
	 *  Create query to list application info, all application which exist on device.
	 * @param pageNo page number
	 * @param pageSize number of page in one page of result
	 * @param deviceId device id
	 * @return
	 */

	public String listDeviceApplication() {
		return mListDeviceApplication();
	}



	public String listUsersDeviceApplication(int userIdSize) {
		return mListUsersDeviceApplication(userIdSize);
	}

	/**
	 * list project application according to given projectId.
	 * @param projectId
	 * @param userId   // add User Id if same user came for listing request.
	 * @return
	 */
	public String listUserApp(int userIdSize) {
		return mListUserApps(userIdSize);
	}


	public String listDevice() {
		return mListDevice();
	}


	public String listUsersApplicationVersion(int userIdSize) {
		return mListUsersApplicationVersion(userIdSize);
	}


	public String listApplicationVersion() {
		return mListApplicationVersion();
	}


	/**
	 * list devices on which application has been installed.
	 * @param appid
	 * @return
	 */
	public String mListDevice() {
		StringBuilder sb = new StringBuilder();
		sb.append("Select * ");
		sb.append(" FROM ");
		sb.append(PortalDBEnum.VIEW_NAMES.devicesnodes_view);	

		sb.append(" WHERE ");
		sb.append(DEVICES_NODES_VIEW.devices_deviceStatus);
		sb.append(" != ");
		sb.append(Status.DELETED.ordinal());
		sb.append(" AND ");
		sb.append(PortalDBEnum.DEVICES_NODES_VIEW.devices_deviceId);
		sb.append(" IN ( SELECT ");
		sb.append(PortalDBEnum.DEVICE_APPLICATIONS.deviceId);
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.deviceapplications);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.DEVICE_APPLICATIONS.appId);
		sb.append(" = ");
		sb.append("?");
		//sb.append(PortalDatabaseEngine.getInstance().getConnection().formatString(appid));
		sb.append(") ");
	
		return sb.toString();
	}




	/**
	 * getting application info, all application which are exist on device.
	 * @param pageNo
	 * @param pageSize
	 * @param deviceId
	 * @return
	 */
	private String mListDeviceApplication() {

		StringBuilder sb = new StringBuilder();
		sb.append("SELECT ");				
		sb.append("app.*");
		sb.append(", dapp."); sb.append(PortalDBEnum.DEVICE_APPLICATIONS.deviceId);
		sb.append(", dapp."); sb.append(PortalDBEnum.DEVICE_APPLICATIONS.appVersionId);
		sb.append(", dev."); sb.append(PortalDBEnum.DEVICES.deviceName);
		sb.append(", appversion.*");		
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.devices);
		sb.append(" AS dev ");
		sb.append(" LEFT JOIN ");
		sb.append(PortalDBEnum.TABLE_NAMES.deviceapplications); sb.append(" AS dapp ");
		sb.append(" ON (dev."); sb.append(PortalDBEnum.DEVICES.deviceId);
		sb.append(" = dapp."); sb.append(PortalDBEnum.DEVICE_APPLICATIONS.deviceId);
		sb.append(" AND ");  
		sb.append("dapp.");sb.append(PortalDBEnum.DEVICE_APPLICATIONS.deviceAppstatus);sb.append(" != ");sb.append(Status.DELETED.ordinal());
		sb.append(") ");
		sb.append(" LEFT JOIN ");sb.append(PortalDBEnum.TABLE_NAMES.application);sb.append(" AS app ON app."); sb.append(PortalDBEnum.APPLICATION.appId);
		sb.append(" = dapp."); sb.append(PortalDBEnum.DEVICE_APPLICATIONS.appId);
		sb.append(" LEFT JOIN ");sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(" AS appversion ON appversion."); sb.append(PortalDBEnum.APPLICATION_VERSIONS.appVersionId);
		sb.append(" = dapp."); sb.append(PortalDBEnum.DEVICE_APPLICATIONS.appVersionId);
		sb.append(" WHERE ");
		sb.append("dev.");sb.append(PortalDBEnum.DEVICE_APPLICATIONS.deviceId);
		sb.append(" = ");
		sb.append("?");
//		sb.append(PortalDatabaseEngine.getInstance().getConnection().formatString(deviceId));
		sb.append(" ORDER BY ");
		sb.append(" app.");sb.append(PortalDBEnum.APPLICATION.modifiedDate);sb.append(" DESC ");

		return sb.toString();		
	}
	
	

	/**
	 * list all users devices and installed applications.
	 * @param userId
	 * @return
	 */
	private String mListUsersDeviceApplication(int userIdSize) {
		SqlQueryBuilder queryBuilder = new SqlQueryBuilder();
		
		queryBuilder.appendQuery("SELECT ");
		queryBuilder.appendQuery(PortalDBEnum.VIEW_NAMES.devicesnodes_view);
		queryBuilder.appendQuery(".*");
		queryBuilder.appendQuery(", app.");
		queryBuilder.appendQuery(PortalDBEnum.APPLICATION.appId);
		queryBuilder.appendQuery(", app.");
		queryBuilder.appendQuery(PortalDBEnum.APPLICATION.appTypeId);
		queryBuilder.appendQuery(", app.");
		queryBuilder.appendQuery(PortalDBEnum.APPLICATION.icon);
		queryBuilder.appendQuery(", app.");
		queryBuilder.appendQuery(PortalDBEnum.APPLICATION.title);
		queryBuilder.appendQuery(", app.");
		queryBuilder.appendQuery(PortalDBEnum.APPLICATION.userId);
		queryBuilder.appendQuery(", app.");
		queryBuilder.appendQuery(PortalDBEnum.APPLICATION.webAddress);
		queryBuilder.appendQuery(", app.");
		queryBuilder.appendQuery(PortalDBEnum.APPLICATION.appStatus);
		queryBuilder.appendQuery(", app.");
		queryBuilder.appendQuery(PortalDBEnum.APPLICATION.createdDate);
		queryBuilder.appendQuery(", app.");
		queryBuilder.appendQuery(PortalDBEnum.APPLICATION.modifiedDate);
		queryBuilder.appendQuery(", dapp.");
		queryBuilder.appendQuery(PortalDBEnum.DEVICE_APPLICATIONS.deviceId);
		queryBuilder.appendQuery(", dapp.");
		queryBuilder.appendQuery(PortalDBEnum.DEVICE_APPLICATIONS.appVersionId);
		queryBuilder.appendQuery(", dev.");
		queryBuilder.appendQuery(PortalDBEnum.DEVICES.deviceName);
		queryBuilder.appendQuery(", appversion.*");
		queryBuilder.appendQuery(" FROM ");
		queryBuilder.appendQuery(PortalDBEnum.VIEW_NAMES.devicesnodes_view);
		queryBuilder.appendQuery(" LEFT JOIN ");
		queryBuilder.appendQuery(PortalDBEnum.TABLE_NAMES.deviceapplications);
		queryBuilder.appendQuery(" AS dapp");
		queryBuilder.appendQuery(" ON ");
		queryBuilder.appendQuery(DEVICES_NODES_VIEW.devices_deviceId);
		queryBuilder.appendQuery("  = dapp.deviceId ");
		queryBuilder.appendQuery(" AND dapp.");
		queryBuilder.appendQuery(PortalDBEnum.DEVICE_APPLICATIONS.deviceAppstatus);
		queryBuilder.appendQuery(" != ");
		queryBuilder.appendQuery(Status.DELETED.ordinal());
		queryBuilder.appendQuery(" LEFT JOIN ");
		queryBuilder.appendQuery(PortalDBEnum.TABLE_NAMES.application);
		queryBuilder.appendQuery(" AS app ON dapp.");
		queryBuilder.appendQuery(PortalDBEnum.DEVICE_APPLICATIONS.appId);
		queryBuilder.appendQuery(" = app.");
		queryBuilder.appendQuery(PortalDBEnum.APPLICATION.appId);
		queryBuilder.appendQuery(" LEFT JOIN ");
		queryBuilder.appendQuery(PortalDBEnum.TABLE_NAMES.devices);
		queryBuilder.appendQuery(" AS dev ON dapp.");
		queryBuilder.appendQuery(PortalDBEnum.DEVICE_APPLICATIONS.deviceId);
		queryBuilder.appendQuery(" = dev.");
		queryBuilder.appendQuery(PortalDBEnum.DEVICES.deviceId);
		queryBuilder.appendQuery(" LEFT JOIN ");
		queryBuilder.appendQuery(PortalDBEnum.TABLE_NAMES.applicationversions);
		queryBuilder.appendQuery(" AS appversion ON dapp.");
		queryBuilder.appendQuery(PortalDBEnum.DEVICE_APPLICATIONS.appVersionId);
		queryBuilder.appendQuery(" = appversion.");
		queryBuilder.appendQuery(PortalDBEnum.APPLICATION_VERSIONS.appVersionId);
		queryBuilder.appendQuery(" WHERE ");
		queryBuilder.appendQuery(DEVICES_NODES_VIEW.devices_deviceStatus);
		queryBuilder.appendQuery(" != ");
		queryBuilder.appendQuery(Status.DELETED.ordinal());
		queryBuilder.appendQuery(" AND ");
		queryBuilder.appendQuery(PortalDBEnum.DEVICES_NODES_VIEW.devices_userId);

		queryBuilder.appendQueryIN(userIdSize);

		queryBuilder.appendQuery(" ORDER BY ");
		queryBuilder.appendQuery(" app.");
		queryBuilder.appendQuery(PortalDBEnum.APPLICATION.modifiedDate);
		queryBuilder.appendQuery(" DESC ");

		return queryBuilder.getQuery().toString();

	}


	private String mListUserApps(int userIdSize) {
		SqlQueryBuilder queryBuilder = new SqlQueryBuilder();
		queryBuilder.appendQuery("Select a.* ");
		queryBuilder.appendQuery(", appplatform." + PortalDBEnum.APPLICATION_PLATFORM.appPlatformId);
		queryBuilder.appendQuery(", appplatform." + PortalDBEnum.APPLICATION_PLATFORM.platformId);
		queryBuilder.appendQuery(", appplatform." + PortalDBEnum.APPLICATION_PLATFORM.repositoryName);
		queryBuilder.appendQuery(" FROM ");
		queryBuilder.appendQuery(PortalDBEnum.TABLE_NAMES.application);
		queryBuilder.appendQuery(" as a ");
		queryBuilder.appendQuery(" LEFT JOIN ");
		queryBuilder.appendQuery(PortalDBEnum.TABLE_NAMES.applicationplatform);
		queryBuilder.appendQuery(" AS appplatform ON appplatform.");
		queryBuilder.appendQuery(PortalDBEnum.APPLICATION_PLATFORM.appId);
		queryBuilder.appendQuery(" = a.");
		queryBuilder.appendQuery(PortalDBEnum.APPLICATION.appId);
		queryBuilder.appendQuery(" WHERE ");
		queryBuilder.appendQuery("a.");
		queryBuilder.appendQuery(PortalDBEnum.APPLICATION.appStatus);
		queryBuilder.appendQuery(" != ");
		queryBuilder.appendQuery(Status.DELETED.ordinal());
		queryBuilder.appendQuery(" AND ");
		queryBuilder.appendQuery("a.");
		queryBuilder.appendQuery(PortalDBEnum.APPLICATION.userId);
		
//		queryBuilder.appendQuery(" IN(");
//		queryBuilder.appendQuery(PortalDatabaseEngine.getInstance().getConnection().formatStringForIn(userId));
		
		queryBuilder.appendQueryIN(userIdSize);
		queryBuilder.appendQuery(" ORDER BY ");
		queryBuilder.appendQuery(PortalDBEnum.APPLICATION.modifiedDate);
		queryBuilder.appendQuery(" DESC ");
		return queryBuilder.getQuery().toString();
	}


	/**
	 * This query return details of application (Title, CompanyName, categoryId, imagePath, appVersion).
	 * This query has JOIN ON (company/applicationcategories/category),
	 * LEFT JOIN ON (applicationimages/applicationversions).
	 * @param appId
	 * @return
	 */
	private String mListApplicationVersion() {
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT ");
		sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.appVersionId.name());
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.appVersion.name());
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.releaseNotes.name());
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.size.name());


		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.applicationserviceports);sb.append(".");sb.append(PortalDBEnum.APPLICATION_SERVICE_PORTS.appVersionId.name());
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.applicationserviceports);sb.append(".");sb.append(PortalDBEnum.APPLICATION_SERVICE_PORTS.internalPort.name());
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.applicationserviceports);sb.append(".");sb.append(PortalDBEnum.APPLICATION_SERVICE_PORTS.externalPort.name());
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.applicationserviceports);sb.append(".");sb.append(PortalDBEnum.APPLICATION_SERVICE_PORTS.appServicePortId.name());

		//AKH_04
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.redirectType.name());
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.redirectSection.name());
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.redirectUrl.name());
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.restRedirectUrl.name());
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.composeVersion.name());
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.modifiedDate.name());sb.append(" as versionModifiedDate");
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.appPlatformId.name());sb.append(" as appPlatformIdVersion");
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);
		sb.append(" LEFT JOIN ");
		sb.append(PortalDBEnum.TABLE_NAMES.applicationserviceports);
		sb.append(" on ");
		sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.appVersion.name()); 
		sb.append("=");
		sb.append(PortalDBEnum.TABLE_NAMES.applicationserviceports);sb.append(".");sb.append(PortalDBEnum.APPLICATION_SERVICE_PORTS.appVersionId.name());
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.appId.name()); 
		sb.append(" = ");
		sb.append("?");
//		sb.append(PortalDatabaseEngine.getInstance().getConnection().formatString(appId));
		sb.append(" AND ");
		sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.versionStatus.name());
		sb.append(" = ");sb.append(VERSION_STATUS.LIVE.ordinal());

		return sb.toString();
	}




	private String mListUsersApplicationVersion(int userIdSize) {
		SqlQueryBuilder queryBuilder = new SqlQueryBuilder();
		
		queryBuilder.appendQuery("Select a.* ");
		queryBuilder.appendQuery(", appplatform." + PortalDBEnum.APPLICATION_PLATFORM.appPlatformId);
		queryBuilder.appendQuery(", appplatform." + PortalDBEnum.APPLICATION_PLATFORM.platformId);
		queryBuilder.appendQuery(", appplatform." + PortalDBEnum.APPLICATION_PLATFORM.repositoryName);
		queryBuilder.appendQuery(",");
		queryBuilder.appendQuery("appver.");
		queryBuilder.appendQuery(PortalDBEnum.APPLICATION_VERSIONS.appVersionId.name());
		queryBuilder.appendQuery(", ");
		queryBuilder.appendQuery("appver.");
		queryBuilder.appendQuery(PortalDBEnum.APPLICATION_VERSIONS.appVersion.name());
		queryBuilder.appendQuery(", ");
		queryBuilder.appendQuery("appver.");
		queryBuilder.appendQuery(PortalDBEnum.APPLICATION_VERSIONS.releaseNotes.name());
		queryBuilder.appendQuery(", ");
		queryBuilder.appendQuery("appver.");
		queryBuilder.appendQuery(PortalDBEnum.APPLICATION_VERSIONS.size.name());
		queryBuilder.appendQuery(", ");
		queryBuilder.appendQuery("appver.");
		queryBuilder.appendQuery(PortalDBEnum.APPLICATION_VERSIONS.versionStatus.name());
		queryBuilder.appendQuery(", ");
		queryBuilder.appendQuery("verport.");
		queryBuilder.appendQuery(PortalDBEnum.APPLICATION_SERVICE_PORTS.appVersionId.name());
		queryBuilder.appendQuery(", ");
		queryBuilder.appendQuery("verport.");
		queryBuilder.appendQuery(PortalDBEnum.APPLICATION_SERVICE_PORTS.internalPort.name());
		queryBuilder.appendQuery(", ");
		queryBuilder.appendQuery("verport.");
		queryBuilder.appendQuery(PortalDBEnum.APPLICATION_SERVICE_PORTS.externalPort.name());
		queryBuilder.appendQuery(", ");
		queryBuilder.appendQuery("verport.");
		queryBuilder.appendQuery(PortalDBEnum.APPLICATION_SERVICE_PORTS.appServicePortId.name());
		queryBuilder.appendQuery(", ");
		queryBuilder.appendQuery("appver.");
		queryBuilder.appendQuery(PortalDBEnum.APPLICATION_VERSIONS.redirectType.name());
		queryBuilder.appendQuery(", ");
		queryBuilder.appendQuery("appver.");
		queryBuilder.appendQuery(PortalDBEnum.APPLICATION_VERSIONS.redirectSection.name());
		queryBuilder.appendQuery(", ");
		queryBuilder.appendQuery("appver.");
		queryBuilder.appendQuery(PortalDBEnum.APPLICATION_VERSIONS.redirectUrl.name());
		queryBuilder.appendQuery(", ");
		queryBuilder.appendQuery("appver.");
		queryBuilder.appendQuery(PortalDBEnum.APPLICATION_VERSIONS.restRedirectUrl.name());
		queryBuilder.appendQuery(", ");
		queryBuilder.appendQuery("appver.");
		queryBuilder.appendQuery(PortalDBEnum.APPLICATION_VERSIONS.composeVersion.name());
		queryBuilder.appendQuery(", ");
		queryBuilder.appendQuery("appver.");
		queryBuilder.appendQuery(PortalDBEnum.APPLICATION_VERSIONS.modifiedDate.name());
		queryBuilder.appendQuery(" as versionModifiedDate");
		queryBuilder.appendQuery(", ");
		queryBuilder.appendQuery("appver.");
		queryBuilder.appendQuery(PortalDBEnum.APPLICATION_VERSIONS.createdDate.name());
		queryBuilder.appendQuery(" as versioncreatedDate");
		queryBuilder.appendQuery(", ");
		queryBuilder.appendQuery("appver.");
		queryBuilder.appendQuery(PortalDBEnum.APPLICATION_VERSIONS.appPlatformId.name());
		queryBuilder.appendQuery(" as appPlatformIdVersion");
		queryBuilder.appendQuery(" FROM ");
		queryBuilder.appendQuery(PortalDBEnum.TABLE_NAMES.application);
		queryBuilder.appendQuery(" as a ");
		queryBuilder.appendQuery(" LEFT JOIN ");
		queryBuilder.appendQuery(PortalDBEnum.TABLE_NAMES.applicationplatform);
		queryBuilder.appendQuery(" AS appplatform ON appplatform.");
		queryBuilder.appendQuery(PortalDBEnum.APPLICATION_PLATFORM.appId);
		queryBuilder.appendQuery(" = a.");
		queryBuilder.appendQuery(PortalDBEnum.APPLICATION.appId);
		queryBuilder.appendQuery(" LEFT JOIN ");
		queryBuilder.appendQuery(PortalDBEnum.TABLE_NAMES.applicationversions);
		queryBuilder.appendQuery(" as appver ");
		queryBuilder.appendQuery(" on ");
		queryBuilder.appendQuery(" appver.");
		queryBuilder.appendQuery(PortalDBEnum.APPLICATION_VERSIONS.appId.name());
		queryBuilder.appendQuery(" = ");
		queryBuilder.appendQuery("a.");
		queryBuilder.appendQuery(PortalDBEnum.APPLICATION.appId.name());
		queryBuilder.appendQuery(" LEFT JOIN ");
		queryBuilder.appendQuery(PortalDBEnum.TABLE_NAMES.applicationserviceports);
		queryBuilder.appendQuery(" as verport ");
		queryBuilder.appendQuery(" on ");
		queryBuilder.appendQuery(" appver.");
		queryBuilder.appendQuery(PortalDBEnum.APPLICATION_VERSIONS.appVersionId.name());
		queryBuilder.appendQuery(" = ");
		queryBuilder.appendQuery(" verport.");
		queryBuilder.appendQuery(PortalDBEnum.APPLICATION_SERVICE_PORTS.appVersionId.name());
		queryBuilder.appendQuery(" WHERE ");
		queryBuilder.appendQuery("a.");
		queryBuilder.appendQuery(PortalDBEnum.APPLICATION.appStatus);
		queryBuilder.appendQuery(" != ");
		queryBuilder.appendQuery(Status.DELETED.ordinal());
		queryBuilder.appendQuery(" AND ");
		queryBuilder.appendQuery("a.");
		queryBuilder.appendQuery(PortalDBEnum.APPLICATION.userId.name());

		queryBuilder.appendQueryIN(userIdSize);
		
//		queryBuilder.appendQuery(" IN(");
//		queryBuilder.appendQuery(PortalDatabaseEngine.getInstance().getConnection().formatStringForIn(userId));
		
		queryBuilder.appendQuery(" ORDER BY appver.");
		queryBuilder.appendQuery(PortalDBEnum.APPLICATION_VERSIONS.createdDate);
		queryBuilder.appendQuery(" DESC ");

		return queryBuilder.getQuery().toString();
	}


}
