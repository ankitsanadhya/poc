/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal;

import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.p.common.enums.PortalDBEnum;

/**
 * Each application have resources, other than yamls
 * like nginx configs, certificates, build files, env files...
 * This kind of resources are saved on file system and the mapping 
 * with app is stored in this table.
 *
 */
public class ApplicationResourcesDB {

	public String get() {
		return mGetForResourceId();
	}

	public String getForResourceIdsListIN(int count) {
		return mGetForResourceIdsListIN(count);
	}

	public String getForApp() {
		return mGetForApp();
	}

	public String getForAppIdAndKind() {
		return mGetForAppIdAndKind();
	}

	public String add() {
		return mAdd();
	}

	public String delete() {
		return mDelete();
	}

	private String mGetForResourceId() {
		return new StringBuilder("SELECT * FROM ")
				.append(PortalDBEnum.TABLE_NAMES.applicationResources) 
				.append(" WHERE ")
				.append(PortalDBEnum.APPLICATION_RESOURCES.resourceId).append(" = ").append("?").toString();
	}

	private String mGetForResourceIdsListIN(int resourceIdsCount) {
		
		
		SqlQueryBuilder builder = new SqlQueryBuilder();
		builder.appendQuery("SELECT * FROM ");
		builder.appendQuery(PortalDBEnum.TABLE_NAMES.applicationResources);
		builder.appendQuery(" WHERE ");
		builder.appendQuery(PortalDBEnum.APPLICATION_RESOURCES.resourceId);
		builder.appendQueryIN(resourceIdsCount);
		builder.appendQuery(" ORDER BY ");
		builder.appendQuery(PortalDBEnum.APPLICATION_RESOURCES.serviceName);
		return builder.getQuery().toString();
	}

	private String mGetForApp() {
		return new StringBuilder("SELECT * FROM ")
				.append(PortalDBEnum.TABLE_NAMES.applicationResources) 
				.append(" WHERE ")
				.append(PortalDBEnum.APPLICATION_RESOURCES.appId).append(" = ").append("?")
				.append(" ORDER BY ")
				.append(PortalDBEnum.APPLICATION_RESOURCES.serviceName).toString();
	}

	private String mGetForAppIdAndKind() {
		return new StringBuilder("SELECT * FROM ")
				.append(PortalDBEnum.TABLE_NAMES.applicationResources) 
				.append(" WHERE ")
				.append(PortalDBEnum.APPLICATION_RESOURCES.appId).append(" = ").append("?") 
				.append(" AND ")
				.append(PortalDBEnum.APPLICATION_RESOURCES.kind).append(" = ").append("?").toString();
	}

	private String mAdd() {
		return new StringBuilder("INSERT INTO ")
				.append(PortalDBEnum.TABLE_NAMES.applicationResources)
				.append(" (")
				.append(PortalDBEnum.APPLICATION_RESOURCES.resourceId).append(", ")
				.append(PortalDBEnum.APPLICATION_RESOURCES.appId).append(", ")
				.append(PortalDBEnum.APPLICATION_RESOURCES.kind).append(", ")
				.append(PortalDBEnum.APPLICATION_RESOURCES.serviceName).append(", ")
				.append(PortalDBEnum.APPLICATION_RESOURCES.isEncrypted).append(", ")
				.append(PortalDBEnum.APPLICATION_RESOURCES.path).append(", ")
				.append(PortalDBEnum.APPLICATION_RESOURCES.createdDate).append(", ")
				.append(PortalDBEnum.APPLICATION_RESOURCES.modifiedDate)
				.append(") VALUES (")
				.append("?").append(",")
				.append("?").append(",")
				.append("?").append(",")
				.append("?").append(",")
				.append("?").append(",")
				.append("?").append(",")
				.append("NOW(), NOW())").toString();
	}

	private String mDelete() {
		return new StringBuilder("DELETE FROM ")
				.append(PortalDBEnum.TABLE_NAMES.applicationResources) 
				.append(" WHERE ")
				.append(PortalDBEnum.APPLICATION_RESOURCES.resourceId).append(" = ").append("?").toString();
	}
}