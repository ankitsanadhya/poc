package com.mwp.p.dal.engine;

import java.util.LinkedList;
import java.util.List;

import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.p.common.enums.PortalDBEnum;

/**
 * Hello world!
 *
 */
public class App 
{

	public static void main(String[] args) throws Exception {
//		List<Integer> lstMsgType = new ArrayList<>();
//		
//		List<String> list = new LinkedList<>();
//		list.add("1");
//		list.add("2");
//		list.add("3");
//		list.add("4");
//		list.add("5");
//		list.add("6");
//		list.add("7");
//		
//		for (String msgType : list) {
//			lstMsgType.add(Integer.valueOf(msgType));
//		}
//		SqlArrayParam sqlArryaParam = new SqlArrayParam(lstMsgType.toArray(), SQLConstant.TYPE_NAME_INTEGER);
//		System.out.println(lstMsgType.toArray().getClass());
//		Object[] obj = lstMsgType.toArray();
//		if(obj instanceof Integer[]){
//			System.out.println("Integer[]");
//		}
		List<String> list = new LinkedList<>();
		list.add("1");
		list.add("2");
		list.add("4");
		StringBuilder qry= new StringBuilder();
//		qry.append("DELETE FROM ");
//		qry.append("Groups"); 
//		qry.append(" WHERE ");
//		qry.append("appId"); 
//		qry.append(" NOT IN (SELECT ");
//		qry.append("appId"); 
//		qry.append(" FROM ");
//		qry.append("Applications"); 
//		qry.append(")");
		
		qry = new StringBuilder("SELECT * FROM ")
			.append(PortalDBEnum.TABLE_NAMES.applicationResources) 
			.append(" WHERE ") 
			.append(PortalDBEnum.APPLICATION_RESOURCES.resourceId);
			
//			.append(" ORDER BY ")
//			.append(PortalDBEnum.APPLICATION_RESOURCES.serviceName);
		
		String in = qry.toString();
		
		
//		qry = new StringBuilder();
//		qry.append("DELETE FROM ");
//		qry.append("Tokens");
//		qry.append(" WHERE ");
//		qry.append("appUserId");
//		qry.append(" NOT IN (SELECT ");
//		qry.append("appUserId");
//		qry.append(" FROM ");
//		qry.append("ApplicationUser");
//		qry.append(")");
//		String notIN = qry.toString();
		
		System.out.println(new SqlQueryBuilder("").appendQuery(in).appendQueryIN(list).addParameters(list).build());
		System.out.println(new SqlQueryBuilder("").appendQuery(in).appendQueryIN(3).build());
		
//		List<String> grpIds = new LinkedList<>();
//		String appId = "";
//		String userId = "";
//		
//		StringBuilder sb = new StringBuilder();
//		/*
//		 * Add deviceAppstatus check if DELETED then also give "install" action not "uninstall",
//		 * because we maintain deviceApplication relation in db with status.
//		 */
//		sb.append("SELECT a.deviceName, a.deviceId, ")
//		.append(" CASE WHEN (a.appId IS NULL OR a.deviceAppstatus = 3) THEN 'install' ")
//		.append(" WHEN (b.versionStatus = 4 OR a.appVersionId='null' OR a.appVersionId IS NULL) THEN 'uninstall' ")
//		.append(" ELSE 'update,uninstall' END ")
//		.append(" AS actions ")
//		.append(" FROM ")
//		.append(" (select t1.appId, t2.deviceId, t2.deviceName, t1.appVersionId, t1.deviceAppstatus ")
//		.append(" FROM ")
//		.append(" devices as t2 ")
//		.append(" LEFT JOIN deviceapplications AS t1 ")
//		.append("ON (t2.deviceId=t1.deviceId and t1.appId = ").append("?"+ ")")
//		.append(" WHERE ")
//		.append(" t2.deviceStatus = ").append(Status.ACTIVE.ordinal())
//		.append(" AND ")
//		.append(" (userId = ").append("?" + ") ");
//
//		if(!grpIds.isEmpty())
//		{
//			sb.append(" Or ")
//			/******/.append("t2.deviceId IN (") 
//			/******/.append(new EdgeCoreGroupsDB().listEdgeCoreForGroups(grpIds)) 
//			/******/.append("))");
//		}
//		else
//		{
//			sb.append(") ");
//		}
//		sb.append(" AS a ")
//		.append(" LEFT JOIN applicationversions AS b ")
//		.append(" ON (a.appVersionId=b.appVersionId)");
//
//		String query = sb.toString();
//		SqlArrayParam sqlArryaParam = new SqlArrayParam(grpIds.toArray(), SQLConstant.TYPE_NAME_VARCHAR);
//		QueryVO queryVO = new SqlQueryBuilder(
//				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(query)
//						.addParameter("15d067e3210a4748b1c4b8b7b414dc63")
//						.addParameter("d9f1d8be704940e7940000c81a1989d1")
//						.addParameter(sqlArryaParam)
//						.build();
//
//		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
//			while (rs.next()) {
//				System.out.println(rs);
//			}
//		}
		
		
	}

}