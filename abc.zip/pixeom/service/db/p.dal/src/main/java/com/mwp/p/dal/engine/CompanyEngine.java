/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal.engine;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mwp.common.Common;
import com.mwp.common.CredProvider;
import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.common.enums.Status;
import com.mwp.common.vo.QueryVO;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.common.vo.CompanyInfoVO;
import com.mwp.p.dal.CompanyDB;
import com.pa.crypto.StringEncryptionDecryption;

/**
 * The class manages the list, add, update delete of company information
 *
 */
public class CompanyEngine {
	
	/**
	 * List all companies exists for single user for given user id.
	 * @param userId
	 * @return List of CompanyInfoVO objects.
	 * @throws Exception
	 */
	public List<CompanyInfoVO> list(String userId) throws SQLException {
		return mList(userId);
	}
	
	public CompanyInfoVO get(String companyId, String userId) throws SQLException {
		return mGet(companyId, userId);
	}
	
	
	/**
	 * Check if company for given company name already exists for user. 
	 * @param companyName
	 * @param userId
	 * @return
	 * @throws Exception
	 */
	public boolean isCompanyExits(String companyName, String userId) throws SQLException {
		return mIsCompanyExits(companyName, userId);
	}
	
	public CompanyInfoVO add(CompanyInfoVO companyInfoVO) throws SQLException {
		return mAdd(companyInfoVO);
	}
	
	/**
	 * update information of existing company information.
	 * @param companyInfoVO
	 * @param userId user id.
	 * @return
	 * @throws Exception "no company found" if company with given id not exists. 
	 */
	public CompanyInfoVO update(CompanyInfoVO companyInfoVO) throws SQLException {
		return mUpdate(companyInfoVO);
	}
	

	/**
	 * delete a company info with given company id.
	 * @param companyId
	 * @param userId
	 * @return
	 * @throws Exception
	 */
	public CompanyInfoVO delete(String companyId, String userId) throws SQLException {
		return mDelete(companyId, userId);
	}

	private List<CompanyInfoVO> mList(String userId) throws SQLException {
		CompanyDB companyDB = new CompanyDB();

		String sql = companyDB.list();
		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(userId).build();

		List<CompanyInfoVO> companyInfoVOs = new ArrayList<>();
		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				CompanyInfoVO companyInfoVO = setCompanyObject(rs);
				companyInfoVOs.add(companyInfoVO);
			}
		}
		return companyInfoVOs;
	}
	
	private CompanyInfoVO mGet(String companyId, String userId) throws SQLException {
		CompanyDB companyDB = new CompanyDB();
		String sql = companyDB.get();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(companyId).addParameter(userId).build();
		CompanyInfoVO companyInfo = null;

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				companyInfo = setCompanyObject(rs);
			}
		}
		return companyInfo;
	}
	
	private boolean mIsCompanyExits(String companyName, String userId) throws SQLException {
		CompanyDB companyDB = new CompanyDB();
		String sql = companyDB.companyNameExits();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameterEncrypted(companyName).addParameter(userId).build();

		boolean retVal = false;

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				retVal = true;
			}
		}
		return retVal;
	}
	
	private CompanyInfoVO mAdd(CompanyInfoVO companyInfoVO) throws SQLException {
		CompanyDB companyDB = new CompanyDB();
		
		companyInfoVO.setCompanyId(Common.getRandomId());
		
		String sql = companyDB.add();
		
		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(companyInfoVO.getCompanyId())
						.addParameter("")
						.addParameter(companyInfoVO.getUserId())
						.addParameterEncrypted(companyInfoVO.getName())
						.addParameterEncrypted(companyInfoVO.getAddress())
						.addParameterEncrypted(companyInfoVO.getCity())
						.addParameterEncrypted(companyInfoVO.getState())
						.addParameterEncrypted(companyInfoVO.getCountry())
						.addParameterEncrypted(companyInfoVO.getPostalCode())
						.addParameterEncrypted(companyInfoVO.getWebAddress())
						.addParameterEncrypted(companyInfoVO.getPhone())
						.addParameterEncrypted(companyInfoVO.getEmail())
						.addParameter(Status.ACTIVE.ordinal())
						.build();

		
		
		int isAdd = PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
		if(isAdd > 0){
			return companyInfoVO;
		} else {
			return null;
		}
	}
	
	private CompanyInfoVO mUpdate(CompanyInfoVO companyInfoVO) throws SQLException {
		CompanyDB companyDB = new CompanyDB();
		String sql = companyDB.update();
		
		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameterEncrypted(companyInfoVO.getAddress())
						.addParameterEncrypted(companyInfoVO.getCity())
						.addParameterEncrypted(companyInfoVO.getState())
						.addParameterEncrypted(companyInfoVO.getCountry())
						.addParameterEncrypted(companyInfoVO.getPostalCode())
						.addParameterEncrypted(companyInfoVO.getWebAddress())
						.addParameterEncrypted(companyInfoVO.getPhone())
						.addParameterEncrypted(companyInfoVO.getEmail())
						.addParameter(companyInfoVO.getCompanyId())
						.build();
		
		PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
		return companyInfoVO;
	}

	private CompanyInfoVO mDelete(String companyId, String userId) throws SQLException {
		CompanyDB companyDB = new CompanyDB();
		CompanyInfoVO companyInfoVO = mGet(companyId, userId);
		
		String sql = companyDB.delete();
		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(Status.DELETED.ordinal()).addParameter(companyId)
						.addParameter(userId)
						.build();

		PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
		return companyInfoVO;
	}
	
	private CompanyInfoVO setCompanyObject(ResultSet rs) throws SQLException
	{
		CompanyInfoVO companyInfo = new CompanyInfoVO();
		String encKey = new CredProvider().getEcnKey();

		companyInfo.setCompanyId(rs.getString(PortalDBEnum.COMPANY.companyId.name()));
		companyInfo.setAddress(StringEncryptionDecryption.decrypt(rs.getString(PortalDBEnum.COMPANY.address.name()), encKey));
		companyInfo.setName(StringEncryptionDecryption.decrypt(rs.getString(PortalDBEnum.COMPANY.companyName.name()), encKey));
		companyInfo.setWebAddress(StringEncryptionDecryption.decrypt(rs.getString(PortalDBEnum.COMPANY.webAddress.name()), encKey));
		companyInfo.setPostalCode(StringEncryptionDecryption.decrypt(rs.getString(PortalDBEnum.COMPANY.postalCode.name()), encKey));
		companyInfo.setCity(StringEncryptionDecryption.decrypt(rs.getString(PortalDBEnum.COMPANY.city.name()), encKey));
		companyInfo.setState(StringEncryptionDecryption.decrypt(rs.getString(PortalDBEnum.COMPANY.state.name()), encKey));
		companyInfo.setCountry(StringEncryptionDecryption.decrypt(rs.getString(PortalDBEnum.COMPANY.country.name()), encKey));
		companyInfo.setEmail(StringEncryptionDecryption.decrypt(rs.getString(PortalDBEnum.COMPANY.email.name()), encKey));
		companyInfo.setPhone(StringEncryptionDecryption.decrypt(rs.getString(PortalDBEnum.COMPANY.phone.name()), encKey));
		
		return companyInfo;
	}
}
