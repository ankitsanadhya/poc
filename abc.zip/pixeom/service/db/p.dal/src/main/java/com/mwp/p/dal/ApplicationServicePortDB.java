/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal;

import java.util.List;

import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.common.enums.PortalDBEnum.APPLICATION_SERVICE_PORTS;
import com.mwp.p.common.enums.PortalDBEnum.APPLICATION_VERSIONS;

/**
 * This class create queries related to {@link APPLICATION_SERVICE_PORTS}
 */
public class ApplicationServicePortDB {

	/**
	 * Create query to check if port range exists in database or not.This query joins {@link ApplicationServicePortDB} to {@link APPLICATION_VERSIONS} 
	 * @param externalPortVOs port list to check in database 
	 * @param appId appId
	 * @return
	 */
	public String checkPortRangeExist(List<String> externalPortVOs) {
		SqlQueryBuilder builder = new SqlQueryBuilder();
		// Check is Available, IF(case, true condition, false condition)
		builder.appendQuery("SELECT IF (COUNT(externalPort) > 0,1,0) AS isAvailable FROM ");
		builder.appendQuery(PortalDBEnum.TABLE_NAMES.applicationserviceports);

		builder.appendQuery(" JOIN ");
		builder.appendQuery(PortalDBEnum.TABLE_NAMES.applicationversions);
		builder.appendQuery(" ON applicationserviceports.");
		builder.appendQuery(PortalDBEnum.APPLICATION_SERVICE_PORTS.appVersionId.name());
		builder.appendQuery(" = ");
		builder.appendQuery("applicationversions.");
		builder.appendQuery(PortalDBEnum.APPLICATION_VERSIONS.appVersionId.name());

		builder.appendQuery(" WHERE ");
		builder.appendQuery(PortalDBEnum.APPLICATION_SERVICE_PORTS.externalPort);

		builder.appendQueryIN(externalPortVOs);

		// Compare lower case because, save value as it is into the DB but while
		// comparing we check for URL path that is case insensitive.
		// sb.append(" IN (");
		// sb.append("?");
		// sb.append(PortalDatabaseEngine.getInstance().getConnection().formatStringForIn(externalPortVOs));
		// sb.append(") ");
		builder.appendQuery(" AND ");
		builder.appendQuery(" applicationversions.");
		builder.appendQuery(PortalDBEnum.APPLICATION_VERSIONS.appId.name());
		builder.appendQuery(" <> ");
		builder.appendQuery("?");
		// sb.append(dbCon.formatString(appId));
		return builder.getQuery().toString();
	}
	
	/**
	 * Create query to add port entry in  {@link APPLICATION_SERVICE_PORTS} 
	 * @param port
	 * @return
	 */
	public String getQueryForAddApplicationServicePort(){
		StringBuilder sb = new StringBuilder();
		sb.append("INSERT INTO ");
		sb.append(PortalDBEnum.TABLE_NAMES.applicationserviceports);
		sb.append(" ( ");
		sb.append(PortalDBEnum.APPLICATION_SERVICE_PORTS.appServicePortId.name());
		sb.append(", ");
		sb.append(PortalDBEnum.APPLICATION_SERVICE_PORTS.appVersionId.name());
		sb.append(", ");
		sb.append(PortalDBEnum.APPLICATION_SERVICE_PORTS.serviceName.name());
		sb.append(", ");
		sb.append(PortalDBEnum.APPLICATION_SERVICE_PORTS.internalPort.name());
		sb.append(", ");
		sb.append(PortalDBEnum.APPLICATION_SERVICE_PORTS.externalPort.name());
		sb.append(" ) VALUES ( ");
		sb.append("?");
		sb.append(", ");
		sb.append("?");
		sb.append(", ");
		sb.append("?");
		sb.append(", ");
		sb.append("?");
		sb.append(", ");
		sb.append("?");
		sb.append(" ) ");
		return sb.toString();
	}

}
