/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */ 

package com.mwp.p.dal;

import java.util.ArrayList;
import java.util.List;

import com.mwp.common.enums.AppBackupTaskStatus;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.common.enums.PortalDBEnum.APPLICATION;
import com.mwp.p.common.enums.PortalDBEnum.APPLICATION_PLATFORM;
import com.mwp.p.common.enums.PortalDBEnum.APPLICATION_SERVICE_PORTS;
import com.mwp.p.common.enums.PortalDBEnum.APPLICATION_TYPE;
import com.mwp.p.common.enums.PortalDBEnum.APPLICATION_VERSIONS;
import com.mwp.p.common.enums.PortalDBEnum.APP_SECRET;
import com.mwp.p.common.enums.PortalDBEnum.APP_SECRET_VERSION;
import com.mwp.p.common.enums.PortalDBEnum.DEVICES;
import com.mwp.p.common.enums.PortalDBEnum.DEVICE_LABEL_MAP;
import com.mwp.p.common.enums.PortalDBEnum.LABELS;
import com.mwp.p.common.enums.PortalDBEnum.PLATFORM;

public class PortalUpdateScripts {

	private String dbName = "";
	public PortalUpdateScripts(String db_Name) {
		dbName = db_Name;
	}
	public ArrayList<String> getRelayServerScripts() {
		//added hostkey column in relay server and support relay server
		ArrayList<String> ddl76 = new ArrayList<>();
		ddl76.add("ALTER TABLE " + PortalDBEnum.TABLE_NAMES.relayservers.name() + " ADD COLUMN " + PortalDBEnum.RELAY_SERVERS.sHostKey + " TEXT NOT NULL  AFTER "  +  PortalDBEnum.RELAY_SERVERS.sRPassword);
		ddl76.add("ALTER TABLE " + PortalDBEnum.TABLE_NAMES.supportrelayservers.name() + " ADD COLUMN " + PortalDBEnum.SUPPORT_RELAY_SERVERS.sHostKey + " TEXT NOT NULL  AFTER "  +  PortalDBEnum.SUPPORT_RELAY_SERVERS.sRPassword);
		return ddl76;
	}
	
	public ArrayList<String> getUpdateSecretCreateScripts() {
		PortalDatabaseScript pds = new PortalDatabaseScript(dbName);
		ArrayList<String> ddl77 = new ArrayList<>();
		/*
		 * create table appSecretVersion
		 */
		ddl77.add(pds.createAppSecretVersion());
		ddl77.add("ALTER TABLE " + PortalDBEnum.TABLE_NAMES.jobSecret.name() + " ADD COLUMN " + PortalDBEnum.JOB_SECRET.appSecretVersionId + " varchar(32) NOT NULL  AFTER "  +  PortalDBEnum.JOB_SECRET.jobSecretId);
		ddl77.add("ALTER TABLE " + PortalDBEnum.TABLE_NAMES.appSecret.name() + " ADD COLUMN " + PortalDBEnum.APP_SECRET.configType + " varchar(255) AFTER "  +  PortalDBEnum.APP_SECRET.displayName);
		ddl77.add("ALTER TABLE "+PortalDBEnum.TABLE_NAMES.jobSecret.name() + " DROP FOREIGN KEY `job_secret_ibfk_1`");
		return ddl77;
	}
	
	public ArrayList<String> getUpdateSecretInsertScripts() {
		ArrayList<String> ddl77 = new ArrayList<>();
		ddl77.add("INSERT INTO " + PortalDBEnum.TABLE_NAMES.appSecretVersion.name() 
		+" ( " + PortalDBEnum.APP_SECRET_VERSION.appSecretVersionId + ", " + PortalDBEnum.APP_SECRET_VERSION.appSecretId + ", " + PortalDBEnum.APP_SECRET_VERSION.secretValue +", "+ PortalDBEnum.APP_SECRET_VERSION.displayName + ", "+ PortalDBEnum.APP_SECRET_VERSION.appUserId + ")"
		+" SELECT "	+ PortalDBEnum.APP_SECRET.appSecretId + ", " + PortalDBEnum.APP_SECRET.appSecretId + ", `secretValue`, `displayName`, ''"
		+" FROM " + PortalDBEnum.TABLE_NAMES.appSecret.name());

		ddl77.add("UPDATE " + PortalDBEnum.TABLE_NAMES.jobSecret.name() + " SET `appSecretVersionId` = `appSecretId`");
		return ddl77;
	}
	
	public ArrayList<String> getUpdateSecretDeleteScripts() {
		ArrayList<String> ddl77 = new ArrayList<>();
		ddl77.add("ALTER TABLE appSecret DROP FOREIGN KEY app_secret_ibfk");
		ddl77.add("ALTER TABLE appSecret DROP INDEX app_secret_Unique");
		ddl77.add("ALTER TABLE "+ PortalDBEnum.TABLE_NAMES.appSecret.name() +" DROP COLUMN `displayName`, DROP COLUMN `secretValue`");
		ddl77.add("ALTER TABLE " + PortalDBEnum.TABLE_NAMES.jobSecret.name() + " DROP COLUMN `appSecretId`");
		ddl77.add("ALTER TABLE "+PortalDBEnum.TABLE_NAMES.jobSecret.name() + " ADD CONSTRAINT `job_secret_ibfk_1` "
				+ "FOREIGN KEY (`appSecretVersionId`) REFERENCES "+PortalDBEnum.TABLE_NAMES.appSecretVersion.name()
				+ " (`appSecretVersionId`) ON DELETE CASCADE");
		
		return ddl77;
	}
	


	public  String addSortOrderInDownload()
	{
		StringBuilder qry = new StringBuilder("ALTER TABLE " );
		qry.append(PortalDBEnum.TABLE_NAMES.downloads.name());
		qry.append(" ADD COLUMN ");
		qry.append(PortalDBEnum.DOWNLOADS.sortOrder);
		qry.append(" int not NULL DEFAULT 1 AFTER ");
		qry.append(PortalDBEnum.DOWNLOADS.details);
		return qry.toString();
	}
	public String updateColumnInActivityLog()
	{
		StringBuilder qry = new StringBuilder("ALTER TABLE " );
		qry.append(PortalDBEnum.TABLE_NAMES.activityLog.name());
		qry.append(" MODIFY COLUMN ");
		qry.append(PortalDBEnum.ACTIVITY_LOG.id.name());
		qry.append(" varchar(32) not null");
		return qry.toString();

	}


	
	public String addTypeInSecretVersion()
	{
		StringBuilder qry = new StringBuilder("ALTER TABLE " );
		qry.append(PortalDBEnum.TABLE_NAMES.appSecretVersion.name());
		qry.append( " ADD COLUMN ");
		qry.append( PortalDBEnum.APP_SECRET_VERSION.type.name()); 
		qry.append( " int NOT NULL AFTER ");
		qry.append( PortalDBEnum.APP_SECRET_VERSION.displayName.name()); 
		return qry.toString();
		
	}
	
	public String modifyAppBackupTaskTable()
	{
		StringBuilder qry = new StringBuilder("ALTER TABLE " );
		qry.append(PortalDBEnum.TABLE_NAMES.appBackupTask.name());
		qry.append( " MODIFY COLUMN ");
		qry.append(PortalDBEnum.APP_BACKUP_TASK.appName.name()); 
		qry.append( " varchar(50) NOT NULL");
		return qry.toString();		
	}

	
	public String updateType()
	{
		StringBuilder qry = new StringBuilder("UPDATE ");
		//TODO
		qry.append(PortalDBEnum.TABLE_NAMES.appSecretVersion.name());
		qry.append(" JOIN ");
		qry.append(PortalDBEnum.TABLE_NAMES.appSecret);qry.append(" AS appSec ");
		qry.append(" ON ");qry.append(" appSec");qry.append(".");qry.append(APP_SECRET.appSecretId);
		qry.append(" = ");
		qry.append(PortalDBEnum.TABLE_NAMES.appSecretVersion);qry.append(".");qry.append(APP_SECRET_VERSION.appSecretId);
		qry.append(" SET ");
		qry.append(PortalDBEnum.TABLE_NAMES.appSecretVersion);qry.append(".");
		qry.append(APP_SECRET_VERSION.type);
		qry.append(" = ");
		qry.append(" appSec.type");
		return qry.toString();
	}
	
	public String deleteTypeFromSecret()
	{
		StringBuilder qry = new StringBuilder("ALTER TABLE " );
		qry.append(PortalDBEnum.TABLE_NAMES.appSecret.name());
		qry.append( " DROP COLUMN `type`");
		return qry.toString();
		
	}
	
	public List<String> queryBeforeAddForeignKey()
	{
		List<String> deleteData = new ArrayList<>(); 
		deleteData.addAll(removeEntriesVoilatingForiegnKeyInAppPt());
		deleteData.add(removeEntriesVoilatingForiegnKeyInAppVersions());
		deleteData.add(removeEntriesVoilatingForiegnKeyInAppSerPort());
		deleteData.addAll(removeEntriesVoilatingForiegnKeyInDevices());
		deleteData.addAll(removeEntriesVoilatingForiegnKeyInDeviceLabelMap());

		return deleteData;
	}

	public List<String> addForeignKey()
	{
		List<String> modifyScript = new ArrayList<>();
		modifyScript.add(addForeignKeyInAppPt());
		modifyScript.add(addForeignKeyInAppVersions());
		modifyScript.add(addForeignKeyInAppSerPort());
		modifyScript.add(addForeignKeyInDevices());
		modifyScript.add(addForeignKeyInDeviceLabelMap());
		return modifyScript;
	}
	
	
	private List<String> removeEntriesVoilatingForiegnKeyInAppPt() 
	{
		List<String> queries = new ArrayList<>();
		//delete from applicationplatform where appId not in (select appId from application);
//      delete from applicationplatform where platformId not in (select platformId from platform);
		StringBuilder qry= new StringBuilder();
		qry.append("DELETE FROM ");
		qry.append(PortalDBEnum.TABLE_NAMES.applicationplatform.name()); 
		qry.append(" WHERE ");
		qry.append(APPLICATION_PLATFORM.appId.name()); 
		qry.append(" NOT IN (SELECT ");
		qry.append(APPLICATION.appId.name()); 
		qry.append(" FROM ");
		qry.append(PortalDBEnum.TABLE_NAMES.application.name()); 
		qry.append(")");
		queries.add(qry.toString());
		
		 qry= new StringBuilder();
		 qry.append("DELETE FROM ");
			qry.append(PortalDBEnum.TABLE_NAMES.applicationplatform.name()); 
			qry.append(" WHERE ");
			qry.append(APPLICATION_PLATFORM.platformId.name()); 
			qry.append(" NOT IN (SELECT ");
			qry.append(PLATFORM.platformId.name()); 
			qry.append(" FROM ");
			qry.append(PortalDBEnum.TABLE_NAMES.platform.name()); 
			qry.append(")");
			queries.add(qry.toString());
			
		return queries;
	}
	
	private String removeEntriesVoilatingForiegnKeyInAppVersions() 
	{

//		select count(*) from applicationversions where appPlatformId not in (select appPlatformId from applicationplatform);
		StringBuilder qry= new StringBuilder();
		qry.append("DELETE FROM ");
		qry.append(PortalDBEnum.TABLE_NAMES.applicationversions.name()); 
		qry.append(" WHERE ");
		qry.append(APPLICATION_VERSIONS.appPlatformId.name()); 
		qry.append(" NOT IN (SELECT ");
		qry.append(APPLICATION_PLATFORM.appPlatformId.name()); 
		qry.append(" FROM ");
		qry.append(PortalDBEnum.TABLE_NAMES.applicationplatform.name()); 
		qry.append(")");
		return qry.toString();
	}
	
	private String removeEntriesVoilatingForiegnKeyInAppSerPort() 
	{

		//select count(*) from applicationserviceports where appVersionId not in (select appVersionId from applicationversions);
		StringBuilder qry= new StringBuilder();
		qry.append("DELETE FROM ");
		qry.append(PortalDBEnum.TABLE_NAMES.applicationserviceports.name()); 
		qry.append(" WHERE ");
		qry.append(APPLICATION_SERVICE_PORTS.appVersionId.name()); 
		qry.append(" NOT IN (SELECT ");
		qry.append(APPLICATION_VERSIONS.appVersionId.name()); 
		qry.append(" FROM ");
		qry.append(PortalDBEnum.TABLE_NAMES.applicationversions.name()); 
		qry.append(")");
		return qry.toString();
	}
	
	private List<String> removeEntriesVoilatingForiegnKeyInDevices() 
	{
		List<String> queries = new ArrayList<>();
		//select count(*) from devices where platformId not in (select platformId from platform);
				//select count(*) from devices where swPlatformId not in (select typeId from applicationType);
		StringBuilder qry= new StringBuilder();
		qry.append("DELETE FROM ");
		qry.append(PortalDBEnum.TABLE_NAMES.devices.name()); 
		qry.append(" WHERE ");
		qry.append(DEVICES.platformId.name()); 
		qry.append(" NOT IN (SELECT ");
		qry.append(PLATFORM.platformId.name()); 
		qry.append(" FROM ");
		qry.append(PortalDBEnum.TABLE_NAMES.platform.name()); 
		qry.append(")");
		queries.add(qry.toString());
		
		 qry= new StringBuilder();
		 qry.append("DELETE FROM ");
			qry.append(PortalDBEnum.TABLE_NAMES.devices.name()); 
			qry.append(" WHERE ");
			qry.append(DEVICES.swPlatformId.name()); 
			qry.append(" NOT IN (SELECT ");
			qry.append(APPLICATION_TYPE.typeId.name()); 
			qry.append(" FROM ");
			qry.append(PortalDBEnum.TABLE_NAMES.applicationType.name()); 
			qry.append(")");
			queries.add(qry.toString());
			
		return queries;
	}
	
	private List<String> removeEntriesVoilatingForiegnKeyInDeviceLabelMap() 
	{
		List<String> queries = new ArrayList<>();
		//select count(*) from devicelabelmap where deviceId not in (select deviceId from devices);
		//select count(*) from devicelabelmap where labelId not in (select labelId from labels);
		StringBuilder qry= new StringBuilder();
		qry.append("DELETE FROM ");
		qry.append(PortalDBEnum.TABLE_NAMES.devicelabelmap.name()); 
		qry.append(" WHERE ");
		qry.append(DEVICE_LABEL_MAP.deviceId.name()); 
		qry.append(" NOT IN (SELECT ");
		qry.append(DEVICES.deviceId.name()); 
		qry.append(" FROM ");
		qry.append(PortalDBEnum.TABLE_NAMES.devices.name()); 
		qry.append(")");
		queries.add(qry.toString());
		
		 qry= new StringBuilder();
		 qry.append("DELETE FROM ");
			qry.append(PortalDBEnum.TABLE_NAMES.devicelabelmap.name()); 
			qry.append(" WHERE ");
			qry.append(DEVICE_LABEL_MAP.labelId.name()); 
			qry.append(" NOT IN (SELECT ");
			qry.append(LABELS.labelId.name()); 
			qry.append(" FROM ");
			qry.append(PortalDBEnum.TABLE_NAMES.labels.name()); 
			qry.append(")");
			queries.add(qry.toString());
			
		return queries;
	}
	
	private String addForeignKeyInAppPt()
	{
		StringBuilder qry= new StringBuilder("ALTER TABLE ");
		qry.append(PortalDBEnum.TABLE_NAMES.applicationplatform.name()); 
		qry.append(" ADD CONSTRAINT `appPt_1` FOREIGN KEY (");
		qry.append(PortalDBEnum.APPLICATION_PLATFORM.appId.name());
		qry.append(")");
		qry.append(" REFERENCES ");
		qry.append(PortalDBEnum.TABLE_NAMES.application.name()); 
		qry.append( " (" );
		qry.append(PortalDBEnum.APPLICATION.appId.name()); 
		qry.append(") ON DELETE CASCADE, ");
		qry.append(" ADD CONSTRAINT `appPt_2` FOREIGN KEY (");
		qry.append(PortalDBEnum.APPLICATION_PLATFORM.platformId.name());
		qry.append(")");
		qry.append(" REFERENCES ");
		qry.append(PortalDBEnum.TABLE_NAMES.platform.name()); 
		qry.append( " (" );
		qry.append(PortalDBEnum.PLATFORM.platformId.name()); 
		qry.append(") ON DELETE CASCADE ");
		return qry.toString();
	}
	
	private String addForeignKeyInAppVersions()
	{
		StringBuilder qry= new StringBuilder("ALTER TABLE ");
		qry.append(PortalDBEnum.TABLE_NAMES.applicationversions.name()); 
		qry.append(" ADD CONSTRAINT `applicationversions_ibfk_3` FOREIGN KEY (");
		qry.append(PortalDBEnum.APPLICATION_VERSIONS.appPlatformId.name());
		qry.append(")");
		qry.append(" REFERENCES ");
		qry.append(PortalDBEnum.TABLE_NAMES.applicationplatform.name()); 
		qry.append( " (" );
		qry.append(PortalDBEnum.APPLICATION_PLATFORM.appPlatformId.name()); 
		qry.append(") ON DELETE CASCADE ");
		return qry.toString();
	}
	
	private String addForeignKeyInAppSerPort()
	{
		StringBuilder qry= new StringBuilder("ALTER TABLE ");
		qry.append(PortalDBEnum.TABLE_NAMES.applicationserviceports.name()); 
		
		qry.append(" ADD CONSTRAINT `appSerPort_1` FOREIGN KEY (");
		qry.append(PortalDBEnum.APPLICATION_SERVICE_PORTS.appVersionId.name());
		qry.append(")");
		qry.append(" REFERENCES ");
		qry.append(PortalDBEnum.TABLE_NAMES.applicationversions.name()); 
		qry.append( " (" );
		qry.append(PortalDBEnum.APPLICATION_VERSIONS.appVersionId.name()); 
		qry.append(") ON DELETE CASCADE ");
		return qry.toString();
	}
	
	private String addForeignKeyInDevices()
	{
		StringBuilder qry= new StringBuilder("ALTER TABLE ");
		qry.append(PortalDBEnum.TABLE_NAMES.devices.name()); 
		qry.append(" ADD CONSTRAINT `devices_ibfk_1` FOREIGN KEY (");
		qry.append(PortalDBEnum.DEVICES.platformId.name());
		qry.append(")");
		qry.append(" REFERENCES ");
		qry.append(PortalDBEnum.TABLE_NAMES.platform.name()); 
		qry.append( " (" );
		qry.append(PortalDBEnum.PLATFORM.platformId.name()); 
		qry.append(") ON DELETE CASCADE, ");
		qry.append(" ADD CONSTRAINT `devices_ibfk_2` FOREIGN KEY (");
		qry.append(PortalDBEnum.DEVICES.swPlatformId.name());
		qry.append(")");
		qry.append(" REFERENCES ");
		qry.append(PortalDBEnum.TABLE_NAMES.applicationType.name()); 
		qry.append( " (" );
		qry.append(PortalDBEnum.APPLICATION_TYPE.typeId.name()); 
		qry.append(") ON DELETE CASCADE ");
		return qry.toString();
	}
	
	private String addForeignKeyInDeviceLabelMap()
	{
		StringBuilder qry= new StringBuilder("ALTER TABLE ");
		qry.append(PortalDBEnum.TABLE_NAMES.devicelabelmap.name()); 
		qry.append(" ADD CONSTRAINT `deviceLbl_1` FOREIGN KEY (");
		qry.append(PortalDBEnum.DEVICE_LABEL_MAP.deviceId.name());
		qry.append(")");
		qry.append(" REFERENCES ");
		qry.append(PortalDBEnum.TABLE_NAMES.devices.name()); 
		qry.append( " (" );
		qry.append(PortalDBEnum.DEVICES.deviceId.name()); 
		qry.append(") ON DELETE CASCADE, ");
		qry.append(" ADD CONSTRAINT `deviceLbl_2` FOREIGN KEY (");
		qry.append(PortalDBEnum.DEVICE_LABEL_MAP.labelId.name());
		qry.append(")");
		qry.append(" REFERENCES ");
		qry.append(PortalDBEnum.TABLE_NAMES.labels.name()); 
		qry.append( " (" );
		qry.append(PortalDBEnum.LABELS.labelId.name()); 
		qry.append(") ON DELETE CASCADE ");
		
		return qry.toString();
	}


	/**
	* DB version 85
	*/
	public String applicationResourceTables() {
		return new StringBuilder("CREATE TABLE " + PortalDBEnum.TABLE_NAMES.applicationResources)
				.append(" (")
				.append(PortalDBEnum.APPLICATION_RESOURCES.resourceId).append(" varchar(32) NOT NULL, ")
				.append(PortalDBEnum.APPLICATION_RESOURCES.appId).append(" varchar(32) NOT NULL, ")
				.append(PortalDBEnum.APPLICATION_RESOURCES.kind).append(" varchar(32) NOT NULL, ")
				.append(PortalDBEnum.APPLICATION_RESOURCES.serviceName).append(" varchar(500) NOT NULL, ")
				.append(PortalDBEnum.APPLICATION_RESOURCES.isEncrypted).append(" tinyint(1) NOT NULL, ")
				.append(PortalDBEnum.APPLICATION_RESOURCES.path).append(" text COLLATE utf8mb4_unicode_ci NOT NULL, ")
				.append(PortalDBEnum.APPLICATION_RESOURCES.createdDate).append(" timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP, ")
				.append(PortalDBEnum.APPLICATION_RESOURCES.modifiedDate).append(" timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, ")
				.append(" PRIMARY KEY (").append(PortalDBEnum.APPLICATION_RESOURCES.resourceId).append("), ")
				.append(" FOREIGN KEY (").append(PortalDBEnum.APPLICATION_RESOURCES.appId).append(") REFERENCES ").append(PortalDBEnum.TABLE_NAMES.application).append(" (").append(PortalDBEnum.APPLICATION.appId).append(") ON DELETE CASCADE, ")
				.append(" KEY ").append(PortalDBEnum.APPLICATION_RESOURCES.kind).append(" (").append(PortalDBEnum.APPLICATION_RESOURCES.kind).append("), ")
				.append(" KEY ").append(PortalDBEnum.APPLICATION_RESOURCES.serviceName).append(" (").append(PortalDBEnum.APPLICATION_RESOURCES.serviceName).append(") ")
				.append( ") ENGINE=InnoDB DEFAULT CHARSET=utf8").toString();
	}
	
	/**
	 * DB version 86
	 * 
	 * Tables to hold Application backup info
	 *  
	 * @return
	 */
	public String applicationBackupTable() {
		return new StringBuilder("CREATE TABLE IF NOT EXISTS ")
				.append(PortalDBEnum.TABLE_NAMES.appBackupTask.name())
				.append( " (" )
				.append( PortalDBEnum.APP_BACKUP_TASK.backupTaskId.name())
				.append( " varchar(32) NOT NULL,")
				.append( PortalDBEnum.APP_BACKUP_TASK.arkBackupName.name() )
				.append( " varchar(1024) NOT NULL,")
				.append( PortalDBEnum.APP_BACKUP_TASK.platformName.name())
				.append( " varchar(32) NOT NULL,")
				.append( PortalDBEnum.APP_BACKUP_TASK.clusterId.name())
				.append( " varchar(32) NOT NULL,")
				.append( PortalDBEnum.APP_BACKUP_TASK.clusterName.name())
				.append( " varchar(32) NOT NULL,")
				.append( PortalDBEnum.APP_BACKUP_TASK.applicationId.name())
				.append( " varchar(32) NOT NULL,")
				.append( PortalDBEnum.APP_BACKUP_TASK.appName.name())
				.append( " varchar(50) NOT NULL,")
				.append( PortalDBEnum.APP_BACKUP_TASK.appVersionId.name())
				.append( " varchar(32) NOT NULL,")
				.append( PortalDBEnum.APP_BACKUP_TASK.appVersion.name())
				.append( " varchar(32) NOT NULL,")
				.append( PortalDBEnum.APP_BACKUP_TASK.status.name())		
				.append( " tinyint(1) DEFAULT " + AppBackupTaskStatus.ACTIVE.getStatusValue() + ", ")
				.append( PortalDBEnum.APP_BACKUP_TASK.startedTime.name() )
				.append( " timestamp  NOT NULL DEFAULT CURRENT_TIMESTAMP,")
				.append( PortalDBEnum.APP_BACKUP_TASK.completedTime.name() )
				.append( " timestamp  NOT NULL DEFAULT CURRENT_TIMESTAMP,")
				.append(" PRIMARY KEY (")
				.append( PortalDBEnum.APP_BACKUP_TASK.backupTaskId.name())
				.append( "),")
				.append(" KEY (")
				.append( PortalDBEnum.APP_BACKUP_TASK.clusterId.name())
				.append( "),")
				.append(" KEY (")
				.append( PortalDBEnum.APP_BACKUP_TASK.arkBackupName.name())
				.append( "),")
				.append(" KEY (")
				.append( PortalDBEnum.APP_BACKUP_TASK.applicationId.name())
				.append( "),")
				.append(" KEY (")
				.append( PortalDBEnum.APP_BACKUP_TASK.completedTime.name())
				.append( "))").toString();
	}

	/**
	 * DB version 86
	 * 
	 * Cluster sync todo in application backup table 
	 * 
	 * @return
	 */
	public String applicationBackupSyncTable() {
		return new StringBuilder("CREATE TABLE IF NOT EXISTS ")
				.append(PortalDBEnum.TABLE_NAMES.appBackupSync.name())
				.append( " (" )
				.append( PortalDBEnum.APP_BACKUP_SYNC.clusterId.name())
				.append( " varchar(32) NOT NULL,")
				.append( PortalDBEnum.APP_BACKUP_SYNC.userId.name())
				.append( " varchar(32) NOT NULL,")
				.append( PortalDBEnum.APP_BACKUP_SYNC.status.name())		
				.append( " tinyint(1) DEFAULT " + AppBackupTaskStatus.ACTIVE.getStatusValue() + ", ")
				.append( PortalDBEnum.APP_BACKUP_SYNC.requestedTime.name())
				.append( " timestamp  NOT NULL DEFAULT CURRENT_TIMESTAMP,")
				.append(" KEY (")
				.append( PortalDBEnum.APP_BACKUP_SYNC.clusterId.name())
				.append( "),")
				.append(" KEY (")
				.append( PortalDBEnum.APP_BACKUP_SYNC.status.name())
				.append( "),")
				.append(" KEY (")
				.append( PortalDBEnum.APP_BACKUP_SYNC.requestedTime.name())
				.append( "))").toString();
	}
}
