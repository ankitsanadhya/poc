/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.mwp.p.dal;

import com.mwp.common.yamlparser.SecretVersionVO;
import com.mwp.db.Interface.IConnection;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.common.enums.PortalDBEnum.APP_SECRET_VERSION;
import com.mwp.p.dal.engine.PortalDatabaseEngine;

public class AppSecretVersionDB {

	private IConnection dbCon= null;
	private String table;
	StringBuilder colList;
	public AppSecretVersionDB()
	{
		//set database connection object.
		dbCon = PortalDatabaseEngine.getInstance().getConnection();
		table = PortalDBEnum.TABLE_NAMES.appSecretVersion.name();
		colList= new StringBuilder(APP_SECRET_VERSION.appSecretVersionId.name());
		colList.append(", "	);			
		colList.append( APP_SECRET_VERSION.appSecretId.name() );
		colList.append( ", ");
		colList.append(APP_SECRET_VERSION.appUserId.name()); 
		colList.append( ", ");
		colList.append( APP_SECRET_VERSION.displayName.name()); 
		colList.append( ", ");	
		colList.append( APP_SECRET_VERSION.type.name()); 
		colList.append( ", ");	
		colList.append( APP_SECRET_VERSION.secretValue.name()); 
		colList.append( ", ");	
		colList.append( APP_SECRET_VERSION.createdDate.name());
		colList.append( ", ");
		colList.append(APP_SECRET_VERSION.modifiedDate.name());
	}
	
//	appSecretVersionId,
//	appSecretId,
//	appUserId, 
//	configType,
//	displayName,
//	secretValue,
//	createdDate,
//	modifiedDate
	public String insert(SecretVersionVO secVersionObj)
	{
		StringBuilder qry= new StringBuilder("INSERT INTO ");
		qry.append(table);
		qry.append( "(");
		qry.append( colList); 
		qry.append( ") VALUES (");	    
		qry.append("?");
		qry.append( ","	);   
		qry.append("?");
		qry.append( ",");
		qry.append("?");
		qry.append( ",");
		qry.append("?");
		qry.append( ",");
		qry.append("?");
		qry.append( ",");
		qry.append("?");
		qry.append( ",");
		qry.append( "NOW()");
		qry.append( ",");
		qry.append( "NOW()");
		qry.append( ")");
		return qry.toString();
	}
	
	public String edit()
	{
		StringBuilder qry= new StringBuilder();
		qry.append("UPDATE ");
		qry.append(table);
		qry.append(" SET ");
		qry.append( APP_SECRET_VERSION.displayName.name());
		qry.append( " = ");
		qry.append("?");
		qry.append(", ");
		qry.append( APP_SECRET_VERSION.secretValue.name());
		qry.append( " = ");
		qry.append("?");
		qry.append(" WHERE ");
		qry.append( APP_SECRET_VERSION.appSecretVersionId.name());
		qry.append( " = ");
		qry.append("?");
		return qry.toString();
	}
	
	public String delete()
	{
		StringBuilder qry= new StringBuilder("DELETE FROM " );
		qry.append(table );
		qry.append(" WHERE " );
		qry.append( APP_SECRET_VERSION.appSecretVersionId.name());
		qry.append( " = ");
		qry.append("?");
		return qry.toString();
	}
	
	public String deleteAppSecretVersions()
	{
		StringBuilder qry= new StringBuilder("DELETE FROM " );
		qry.append(table );
		qry.append(" WHERE " );
		qry.append( APP_SECRET_VERSION.appSecretId.name());
		qry.append( " = ");
		qry.append("?");
		return qry.toString();
	}
	
	public String getAppSecretId()
	{
		//select appSecretId from appSecretVersion where appSecretVersionId = '104199bbaaeb4ad5b0e92d7c6ba65bc6'
		StringBuilder qry= new StringBuilder("SELECT " );
		qry.append( APP_SECRET_VERSION.appSecretId.name());
		qry.append(" FROM " );
		qry.append(table );
		qry.append(" WHERE " );
		qry.append( APP_SECRET_VERSION.appSecretVersionId.name());
		qry.append( " = ");
		qry.append("?");
		//qry.append(dbCon.formatString(appSecertVersionId));
		return qry.toString();
		
	}
	public String countVersions()
	{
	//	select appSecretId, count(*) as secretVersionCount  from appSecretVersion where appSecretId in (select appSecretId from appSecretVersion where appSecretVersionId = '104199bbaaeb4ad5b0e92d7c6ba65bc6');

		StringBuilder qry= new StringBuilder("SELECT " );
		qry.append( APP_SECRET_VERSION.appSecretId.name());
		qry.append(", " );
		qry.append(" count(*) as secretVersionCount ");
		qry.append(" FROM " );
		qry.append(table );
		qry.append(" WHERE " );
		qry.append( APP_SECRET_VERSION.appSecretId.name());
		qry.append(" IN ( " );
		qry.append("?");
		//qry.append(getAppSecretId(appSecertVersionId));
		qry.append( " ) ");
		return qry.toString();
	}
}
