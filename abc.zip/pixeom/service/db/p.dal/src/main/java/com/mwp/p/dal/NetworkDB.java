/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.mwp.p.dal;


import java.util.ArrayList;
import java.util.List;

import com.mwp.common.enums.NetworkTypeEnum;
import com.mwp.common.enums.Operator;
import com.mwp.common.vo.FilterObject;
import com.mwp.db.Interface.IConnection;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.dal.engine.PortalDatabaseEngine;

public class NetworkDB 
{
	String table = "";
	StringBuilder colList;

	private IConnection connection= null;
	public NetworkDB() 
	{
		table = PortalDBEnum.TABLE_NAMES.network.name();
		connection = PortalDatabaseEngine.getInstance().getConnection();
		
		colList=new StringBuilder(PortalDBEnum.NETWORK.networkId.name());
		colList.append(", ");
		colList.append( PortalDBEnum.NETWORK.networkName.name() );
		colList.append(", ");
		colList.append( PortalDBEnum.NETWORK.userId.name() );
		colList.append(", ");
		colList.append( PortalDBEnum.NETWORK.networkType.name() );
		colList.append(", ");
		colList.append( PortalDBEnum.NETWORK.createdDate.name());
	}
	
	public String insert()
	{
		StringBuilder qry= new StringBuilder();
		qry.append("INSERT INTO ");
		qry.append( table); 
		qry.append( "(");
		qry.append( colList); 
		qry.append( ") VALUES (");
		qry.append("?");
		//qry.append( connection.formatString(networkId));
		qry.append( ",");
		qry.append("?");
//		qry.append(connection.formatString(networkName));
		qry.append( ",");
		qry.append("?");
//		qry.append( connection.formatString(userId));
		qry.append( ",");
		qry.append("?");
		//qry.append( networkType.ordinal());
		qry.append( ",");
		qry.append("NOW()");
		qry.append( ")");

		return qry.toString();
	}
	
	
//	public String listPrivateNetwork(String userId)
//	{
//		StringBuilder qry= new StringBuilder("SELECT ");
//		qry.append(colList);
//		qry.append(" FROM ");
//		qry.append(table);
//		qry.append(" WHERE ");
//		qry.append( PortalDBEnum.NETWORK.userId.name());
//		qry.append(" = ");
//		qry.append( connection.formatString(userId));
//		qry.append(" AND ");
//		qry.append( PortalDBEnum.NETWORK.networkType.name());
//		qry.append(" = ");
//		qry.append( NetworkTypeEnum.privateNetwork.ordinal());
//		return qry.toString();
//	}
	
	
	public String listPublicNetwork()
	{
		StringBuilder qry= new StringBuilder("SELECT ");
		qry.append(colList);
		qry.append(" FROM ");
		qry.append(table);
		qry.append(" WHERE ");
		qry.append( PortalDBEnum.NETWORK.networkType.name());
		qry.append(" = ");
		qry.append( NetworkTypeEnum.publicNetwork.ordinal());
		return qry.toString();
	}

	public String getNetworkByname()
	{
		StringBuilder qry= new StringBuilder("SELECT ");
		qry.append(colList);
		qry.append(" FROM ");
		qry.append(table);
		qry.append(" WHERE ");
		qry.append( PortalDBEnum.NETWORK.networkName.name());
		qry.append(" = ");
		qry.append("?");
		//qry.append( connection.formatString(networkName));
		return qry.toString();
	}
	
	public String getNetwork()
	{
		StringBuilder qry= new StringBuilder("SELECT ");
		qry.append(colList);
		qry.append(" FROM ");
		qry.append(table);
		qry.append(" WHERE ");
		qry.append( PortalDBEnum.NETWORK.networkId.name());
		qry.append(" = ");
		qry.append("?");
//		qry.append( connection.formatString(networkId));
		return qry.toString();
	}
	public String deleteNetwork()
	{
		StringBuilder sb = new StringBuilder();
		sb.append("DELETE FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.network);
		sb.append(" WHERE ");
		sb.append( PortalDBEnum.NETWORK.networkId.name());
		sb.append(" = ");
		sb.append("?");
		//sb.append( connection.formatString(networkId));
		return sb.toString();
	}
	
	public String updateNetwork()
	{
		StringBuilder sb = new StringBuilder();
		sb.append("UPDATE ");
		sb.append(PortalDBEnum.TABLE_NAMES.network);
		sb.append(" SET ");
		sb.append( PortalDBEnum.NETWORK.networkName.name());
		sb.append(" = ");
		sb.append("?");
		//sb.append( connection.formatString(networkName));
		sb.append(" WHERE ");
		sb.append( PortalDBEnum.NETWORK.networkId.name());
		sb.append(" = ");
		sb.append("?");
//		sb.append( connection.formatString(networkId));
		return sb.toString();
	}
	
	public List<String> listNetworkFilter(List<FilterObject> filters) 
	{
		ArrayList<String> queries = new ArrayList<>();
		
		StringBuilder whereClause = null;
		StringBuilder qry= new StringBuilder();
		
		qry.append("SELECT SQL_CALC_FOUND_ROWS ");
		qry.append(colList);
		qry.append(" FROM ");
		qry.append(table);
		StringBuilder sortOrder = null;
		String searchString = "";
		boolean isNetWorkFilterAdded = false;

		
		if(filters!=null)
		{
			for (FilterObject filterObject : filters)
			{
				switch (filterObject.getFilterType()) 
				{
				case FILTER:
					switch (filterObject.getFilterkey())
					{
					case NetworkType:

						whereClause = getWhereClause(whereClause);
						NetworkTypeEnum networkType=NetworkTypeEnum.valueOf(filterObject.getStartValue());
						
						switch (networkType)
						{
						case publicNetwork:
							 isNetWorkFilterAdded = true;
							whereClause.append( PortalDBEnum.NETWORK.networkType.name());
							whereClause.append(" = ");
							whereClause.append("?");
							break;
						case privateNetwork:
							 isNetWorkFilterAdded = true;
							 whereClause.append(" ( ");
							whereClause.append( PortalDBEnum.NETWORK.userId.name());
							whereClause.append(" = ");
							whereClause.append("?");
							//whereClause.append( connection.formatString(userId));
							whereClause.append(" AND ");
							whereClause.append( PortalDBEnum.NETWORK.networkType.name());
							whereClause.append(" = ");
							whereClause.append("?");
							//whereClause.append( NetworkTypeEnum.privateNetwork.ordinal());
							whereClause.append(" ) ");
							break;
						case publicPrivateNetwork:
							 isNetWorkFilterAdded = true;
							whereClause.append(" ( ");
							whereClause.append( PortalDBEnum.NETWORK.userId.name());
							whereClause.append(" = ");
							whereClause.append("?");
							//whereClause.append( connection.formatString(userId));
							whereClause.append(" OR ");
							whereClause.append( PortalDBEnum.NETWORK.networkType.name());
							whereClause.append(" = ");
							whereClause.append("?");
							//whereClause.append( NetworkTypeEnum.publicNetwork.ordinal());
							whereClause.append(" ) ");
							
							break;

						default:
							break;
						}
						break;
					default:
						break;
					}
					break;
				case SEARCHTEXT:
					whereClause = getWhereClause(whereClause);
					whereClause.append(PortalDBEnum.NETWORK.networkName.name());

					if(filterObject.getOperator().ordinal()== Operator.LIKE.ordinal())
					{
						//network name contains search text
						searchString = filterObject.getStartValue();
						whereClause.append(" LIKE ");
						whereClause.append("?");
						//whereClause.append(connection.formatStringForLike(true,searchString, true));							
					}
					else if(filterObject.getOperator().ordinal()== Operator.EQUAL.ordinal()) 
					{
						whereClause.append(" = ");
						whereClause.append("?");
						//whereClause.append(PortalDatabaseEngine.getInstance().getConnection().formatString(filterObject.getStartValue()));
					}
					break;
				case SORT:
					sortOrder = new StringBuilder();
					sortOrder.append(" ORDER BY ");
					switch(filterObject.getSortKey())
					{
					case Name:
						//Here assuming that we will always add search filter before the sort filter.
						if(searchString.equals(""))
						{
							sortOrder.append(PortalDBEnum.NETWORK.networkName);
						}
						else
						{
							//sort by best match : Exact equals first then starts with, then contains and then ends with.
							sortOrder.append(" CASE WHEN ");
							sortOrder.append(PortalDBEnum.NETWORK.networkName);
							sortOrder.append(" = ");
							sortOrder.append("?");
							//sortOrder.append(PortalDatabaseEngine.getInstance().getConnection().formatString(searchString));
							sortOrder.append(" THEN 0 ");

							sortOrder.append(" WHEN ");
							sortOrder.append(PortalDBEnum.NETWORK.networkName);
							sortOrder.append(" LIKE ");
							sortOrder.append("?");
							//sortOrder.append(PortalDatabaseEngine.getInstance().getConnection().formatStringForLike(false, searchString, true));
							sortOrder.append(" THEN 1 ");

							sortOrder.append(" WHEN ");
							sortOrder.append(PortalDBEnum.NETWORK.networkName);
							sortOrder.append(" LIKE ");
							sortOrder.append("?");
							//sortOrder.append(PortalDatabaseEngine.getInstance().getConnection().formatStringForLike(true, searchString, false));
							sortOrder.append(" THEN 3 ");

							sortOrder.append(" ELSE 2 ");

							sortOrder.append(" END ");
							sortOrder.append(" , ");
							sortOrder.append(PortalDBEnum.NETWORK.networkName);
						}	
						break;
					case CreationTime:
						sortOrder.append(PortalDBEnum.NETWORK.createdDate);
						break;
					default:
						break;
					}
					if(filterObject.getOperator().ordinal()==Operator.DESC.ordinal()){
						sortOrder.append(" DESC");
					}
					break;
				default:
					break;
				}
			}
		}
		
		if(!isNetWorkFilterAdded)
		{
			whereClause = getWhereClause(whereClause);
			whereClause.append( PortalDBEnum.NETWORK.networkType.name());
			whereClause.append(" = ");
			whereClause.append("?");
			//whereClause.append( NetworkTypeEnum.publicNetwork.ordinal());
		}
		qry.append(whereClause);

		//Add sort order
		if(sortOrder != null){
			qry.append(sortOrder);
		}
		qry.append(" limit ");
//		qry.append(pageSize);
		qry.append("?");
		qry.append(" offset ");
		qry.append("?");
//		qry.append(offset);

		queries.add(qry.toString());
		queries.add("SELECT FOUND_ROWS() as rowCount");

		return queries;
	}
	
	private StringBuilder getWhereClause(StringBuilder whereClause){
		if(whereClause == null){
			whereClause = new StringBuilder();
			whereClause.append(" WHERE ");						
		} else{
			whereClause.append(" AND ");
		}
		return whereClause;			
	}
	
}
