/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal;

import java.util.ArrayList;
import java.util.List;

import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.db.Interface.IConnection;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.dal.engine.PortalDatabaseEngine;

/*
 * Database class to manage hierarchy labels in database.
 */
public class LabelDB 
{
	/*
	 * Database connection object 
	 */
	private IConnection dbCon= null;

	/*
	 * Default constructor that set connection object.
	 */
	public LabelDB() {
		dbCon = PortalDatabaseEngine.getInstance().getConnection();
	}

	//	********************************PUBLIC METHODS******************************
	/**
	 * Create query to insert new label hierarchy object in database  
	 * @param labelVO
	 * @return query to insert label
	 */
	public String addLabel(boolean checkParent)
	{
		return this.mAddLabel(checkParent);
	}

	/**
	 * create query to list the labels  
	 * @param userId
	 * @return
	 */
	public String listLabelId()
	{
		return mListLabelId();
	}

	/**
	 * create query to list the labels  
	 * @param userId
	 * @return
	 */
	public String listLabel()
	{
		return mListLabel();
	}

	/**
	 * create query to edit existing label name
	 * @param labelVO
	 * @return
	 */
	public String editLabel()
	{
		return this.mEditLabel();
	}

	/**
	 * delete existing label of user 
	 * @param labelId
	 * @param userId
	 * @return
	 */
	public List<String> deleteLabel(int labelIdsCount)
	{
		return this.mDeleteLabel(labelIdsCount);
	}

	/**
	 * Create query to get root label id.
	 * @param userId
	 * @return
	 */
	public String getRootId(String userId)
	{
		StringBuilder sb = new StringBuilder();
		sb.append(" SELECT ");
		sb.append(PortalDBEnum.LABELS.labelId.name());
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.labels);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.LABELS.userId.name());
		sb.append(" = ");
		sb.append("?");
		sb.append(" AND ");
		sb.append(PortalDBEnum.LABELS.parentLabelId.name());
		sb.append(" = ");
		sb.append("?");		
		return sb.toString();	
	}



	//	********************************PRIVATE METHODS******************************

	private String mAddLabel(boolean checkParent)
	{
		StringBuilder sb = new StringBuilder();
		if (checkParent) {
			sb.append("INSERT INTO ");
			sb.append(PortalDBEnum.TABLE_NAMES.labels);
			sb.append(" SELECT ");
			sb.append("?");
			// sb.append(dbCon.formatString(labelVO.getLabelId()));
			sb.append(", ");
			sb.append("?");
			// sb.append(dbCon.formatString(labelVO.getLabelName()));
			sb.append(", ");
			sb.append("?");
			// sb.append(dbCon.formatString(labelVO.getParentLabelId()));
			sb.append(", ");
			sb.append("?");
			// sb.append(dbCon.formatString(labelVO.getUserId()));
			sb.append(" FROM ");
			sb.append(PortalDBEnum.TABLE_NAMES.labels);

			sb.append(" WHERE ");
			sb.append(PortalDBEnum.LABELS.labelId.name());
			sb.append(" = ");
			sb.append("?");
			// sb.append(dbCon.formatString(labelVO.getParentLabelId()));
			sb.append(" AND ");
			sb.append("?");
			// sb.append(dbCon.formatString(labelVO.getParentLabelId()));
			sb.append(" != ");
			sb.append("?");
			// sb.append(dbCon.formatString(labelVO.getLabelId()));
			sb.append(" AND ");
			sb.append(PortalDBEnum.LABELS.userId.name());
			sb.append(" = ");
			sb.append("?");
			// sb.append(dbCon.formatString(labelVO.getUserId()));
		} else {
			sb.append("INSERT INTO ");
			sb.append(PortalDBEnum.TABLE_NAMES.labels);
			sb.append(" ( ");
			sb.append(PortalDBEnum.LABELS.labelId.name());
			sb.append(", ");
			sb.append(PortalDBEnum.LABELS.labelName.name());
			sb.append(", ");
			sb.append(PortalDBEnum.LABELS.parentLabelId.name());
			sb.append(", ");
			sb.append(PortalDBEnum.LABELS.userId.name());
			sb.append(" ) VALUES ( ");
			sb.append("?");
			//sb.append(dbCon.formatString(labelVO.getLabelId()));
			sb.append(", ");
			sb.append("?");
//			sb.append(dbCon.formatString(labelVO.getLabelName()));
			sb.append(", ");
			sb.append("?");
//			sb.append(dbCon.formatString(labelVO.getParentLabelId()));
			sb.append(", ");
			sb.append("?");
//			sb.append(dbCon.formatString(labelVO.getUserId()));
			sb.append(" ) ");
		}
		return sb.toString();
	}

	private String mListLabel()
	{
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT * FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.labels);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.LABELS.userId.name());
		sb.append(" = ");
		sb.append("?");
//		sb.append(dbCon.formatString(userId));

		
		return sb.toString();		
	}

	private String mListLabelId()
	{
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT " +  PortalDBEnum.LABELS.labelId.name() + " FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.labels);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.LABELS.userId.name());
		sb.append(" = ");
		sb.append("?");
		//sb.append(dbCon.formatString(userId));
		sb.append(" AND ");
		sb.append(PortalDBEnum.LABELS.parentLabelId.name());
		sb.append(" = ");
		sb.append("?");
		//sb.append(dbCon.formatString(parentLabelId));
		sb.append(" ORDER BY ");
		sb.append(PortalDBEnum.LABELS.parentLabelId.name());
		return sb.toString();		
	}

	private String mEditLabel()
	{
		StringBuilder sb = new StringBuilder();
		sb.append("Update ");
		sb.append(PortalDBEnum.TABLE_NAMES.labels.name());
		sb.append(" SET ");
		sb.append(PortalDBEnum.LABELS.labelName.name());
		sb.append(" = ");
		sb.append("?");
//		sb.append(dbCon.formatString(labelVO.getLabelName()));
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.LABELS.labelId.name());
		sb.append(" = ");
		sb.append("?");
//		sb.append(dbCon.formatString(labelVO.getLabelId()));
		sb.append(" AND ");
		sb.append(PortalDBEnum.LABELS.userId.name());
		sb.append(" = ");
		sb.append("?");
//		sb.append(dbCon.formatString(labelVO.getUserId()));

		return sb.toString();
	}

	private List<String> mDeleteLabel(int labelIdsCount)
	{		
		SqlQueryBuilder queryBuilder = new SqlQueryBuilder(); 
		List<String> queries = new ArrayList<>();
		queryBuilder.appendQuery("UPDATE ");
		queryBuilder.appendQuery(PortalDBEnum.TABLE_NAMES.devicelabelmap);
		queryBuilder.appendQuery(" SET ");  
		queryBuilder.appendQuery(PortalDBEnum.DEVICE_LABEL_MAP.labelId.name());
		queryBuilder.appendQuery(" = ");
		queryBuilder.appendQuery("?");
		//queryBuilder.appendQuery(dbCon.formatString(Constant.ROOT_LABEL_ID));
		queryBuilder.appendQuery(" WHERE ");
		queryBuilder.appendQuery(PortalDBEnum.DEVICE_LABEL_MAP.labelId.name());
		queryBuilder.appendQueryIN(labelIdsCount);
//		queryBuilder.appendQuery(" IN (");
//		queryBuilder.appendQuery(dbCon.formatStringForIn((labelIds)));
//		queryBuilder.appendQuery(" ) ");		
		
		queries.add(queryBuilder.getQuery().toString());

		queryBuilder = new SqlQueryBuilder(); 

		queryBuilder.appendQuery("Delete from ");
		queryBuilder.appendQuery(PortalDBEnum.TABLE_NAMES.labels.name());		
		queryBuilder.appendQuery(" WHERE ");
		queryBuilder.appendQuery(PortalDBEnum.LABELS.labelId.name());
		
		queryBuilder.appendQueryIN(labelIdsCount);
		
//		queryBuilder.appendQuery(" IN (");		
//		queryBuilder.appendQuery(dbCon.formatStringForIn((labelIds)));
//		queryBuilder.appendQuery(") ");
		
		queryBuilder.appendQuery(" AND ");
		queryBuilder.appendQuery(PortalDBEnum.LABELS.userId.name());
		queryBuilder.appendQuery(" = ");
		queryBuilder.appendQuery("?");
		//queryBuilder.appendQuery(dbCon.formatString(userId));
		
		queries.add(queryBuilder.getQuery().toString());



		return queries;

	}


}
