/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.mwp.p.dal.engine;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import com.mwp.common.Common;
import com.mwp.common.StringFunctions;
import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.common.vo.QueryVO;
import com.mwp.p.common.enums.PortalDBEnum.DOWNLOADS;
import com.mwp.p.common.enums.ResourceType;
import com.mwp.p.common.vo.DownloadResourceVO;
import com.mwp.p.dal.DownloadDB;

public class DownloadsEngine {
	// add,edit,delete,list,get
	public DownloadResourceVO add(DownloadResourceVO resourceVO) throws SQLException {
		return mAdd(resourceVO);
	}

	public DownloadResourceVO edit(DownloadResourceVO resourceVO) throws SQLException {
		return mEdit(resourceVO);
	}

	public void updateSortOrder(Map<String, Integer> idOrderMap) throws SQLException {
		mUpdateSortOrder(idOrderMap);
	}

	public void delete(String resourceId) throws SQLException {
		mDelete(resourceId);
	}

	public List<DownloadResourceVO> listResouces(String resourceType) throws SQLException {
		return mListResources(resourceType);
	}

	public List<DownloadResourceVO> listInvitedResouces(List<String> groupIds, String resourceType)
			throws SQLException {
		return mListInvitedResources(resourceType, groupIds);
	}

	public DownloadResourceVO getResource(String resourceId) throws SQLException {
		return get(resourceId);
	}

	private DownloadResourceVO mAdd(DownloadResourceVO resourceVO) throws SQLException {
		String resourceId = Common.getRandomId();
		DownloadDB dbObj = new DownloadDB();
		// String sql = dbObj.insert(resourceId, resourceVO.getResourceType(),
		// resourceVO.getDetails());
		String sql = dbObj.insert();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(resourceId).addParameter(resourceVO.getResourceType().ordinal())
						.addParameter(resourceVO.getDetails()).addParameter(resourceVO.getResourceType().ordinal())
						.build();

		PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
		return get(resourceId);
	}

	private DownloadResourceVO mEdit(DownloadResourceVO resourceVO) throws SQLException {
		DownloadDB dbObj = new DownloadDB();
		// String sql = dbObj.edit(resourceVO.getResourceId(),
		// resourceVO.getDetails());
		String sql = dbObj.edit();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(resourceVO.getDetails()).addParameter(resourceVO.getResourceId()).build();

		PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
		return get(resourceVO.getResourceId());
	}

	private void mUpdateSortOrder(Map<String, Integer> idOrderMap) throws SQLException {
		DownloadDB dbObj = new DownloadDB();
		String sql = dbObj.updateSortOrder(idOrderMap);
		List<Object> params = new LinkedList<>();
		for (Map.Entry<String, Integer> mapEntry : idOrderMap.entrySet()) {
			params.add(mapEntry.getKey());
			params.add(mapEntry.getValue());
		}

		QueryVO queryVO = new SqlQueryBuilder().appendQuery(sql).addParameters(params)
				.addParameters(new ArrayList<>(idOrderMap.keySet())).build();
		PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
	}

	private void mDelete(String resourceId) throws SQLException {
		DownloadDB dbObj = new DownloadDB();
		String sql = dbObj.delete();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(resourceId).build();

		PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
	}

	private List<DownloadResourceVO> mListResources(String resourceType) throws SQLException {
		DownloadDB dbObj = new DownloadDB();
		String sql = dbObj.list(resourceType);

		List<DownloadResourceVO> list = new ArrayList<>();
		DownloadResourceVO resourceVo;
		SqlQueryBuilder builder = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql);
		
		if(!StringFunctions.isNullOrEmpty(resourceType)){
			builder.addParameter(ResourceType.valueOf(resourceType).ordinal());
		}
		
		QueryVO queryVO = builder.build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				resourceVo = mGetResource(rs);
				list.add(resourceVo);
			}
		}
		return list;
	}

	private List<DownloadResourceVO> mListInvitedResources(String resourceType, List<String> groupIds)
			throws SQLException {
		DownloadDB dbObj = new DownloadDB();
		String sql = dbObj.listInvitedResources(groupIds, resourceType);
		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameters(groupIds).addParameter(ResourceType.valueOf(resourceType).ordinal()).build();

		List<DownloadResourceVO> list = new ArrayList<>();
		DownloadResourceVO resourceVo;
		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				resourceVo = mGetResource(rs);
				list.add(resourceVo);
			}
		}
		return list;
	}

	private DownloadResourceVO get(String resourceId) throws SQLException {
		DownloadDB dbObj = new DownloadDB();
		String sql = dbObj.get();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(resourceId).build();

		DownloadResourceVO resourceVo = null;
		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				resourceVo = mGetResource(rs);

			}
		}
		return resourceVo;
	}

	private DownloadResourceVO mGetResource(ResultSet resultSet) throws SQLException {
		DownloadResourceVO resourceVo = new DownloadResourceVO();
		resourceVo.setResourceId(resultSet.getString(DOWNLOADS.resourceId.name()));
		resourceVo.setResourceType(ResourceType.values()[resultSet.getInt(DOWNLOADS.resourceType.name())]);
		resourceVo.setDetails(resultSet.getString(DOWNLOADS.details.name()));
		resourceVo.setSortOrder(resultSet.getInt(DOWNLOADS.sortOrder.name()));
		return resourceVo;
	}
}
