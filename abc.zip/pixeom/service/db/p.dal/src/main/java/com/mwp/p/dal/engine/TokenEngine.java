/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.mwp.p.dal.engine;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.mwp.common.CredProvider;
import com.mwp.common.Utils;
import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.common.enums.TokenEnum.TOKENSTATUS;
import com.mwp.common.vo.QueryVO;
import com.mwp.common.vo.TokenVO;
import com.mwp.p.common.enums.PortalDBEnum.SUPPORTTOKENS;
import com.mwp.p.dal.TokenDB;
import com.pa.crypto.StringEncryptionDecryption;

public class TokenEngine {

	/**
	 * Get Token information using hostName then add support token with new
	 * random id if support token is empty
	 * 
	 * @param email
	 *            email id
	 * @param hostName
	 *            host name
	 * @return support token
	 * @throws Exception
	 *             1. if token not found for given host name 2. if fail to add
	 *             entry
	 * 
	 */
	public TokenVO generateSupportToken(String email, String hostName, String userId, long expiryTime, String nodeId)
			throws SQLException {
		TokenVO tokenData = null;
		String token = Utils.randomUUID();
		tokenData = getTokenDetailsByToken(token);
		if (tokenData == null) {
			String supportToken = Utils.randomUUID();

			String sql = new TokenDB().insert();

			QueryVO queryVO = new SqlQueryBuilder(
					PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
							.addParameter(supportToken).addParameter(nodeId).addParameterEncrypted(email)
							.addParameter(hostName).addParameter(expiryTime).addParameter(userId).addParameter(token)
							.addParameter(TOKENSTATUS.NEW.ordinal()).build();

			int insertCount = PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
			if (insertCount == 0) {
				throw new SQLException("Unable to add token details, please try again.");
			}
			tokenData = getTokenDetails(email, hostName);
		}
		return tokenData;
	}

	/**
	 * Get token details(token and supporttokenid).
	 * 
	 * @param hostName
	 * @param email
	 * @throws SQLException
	 */
	public TokenVO getTokenDetails(String email, String hostname) throws SQLException {
		String sql = new TokenDB().getTokenDetails();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameterEncrypted(email).addParameter(hostname).build();
		return getTokenVo(queryVO);
	}

	/**
	 * Get token details(token and supporttokenid).
	 * 
	 * @param hostName
	 * @param email
	 * @throws SQLException
	 */
	public TokenVO checkValidToken(String token) throws SQLException {
		String sql = new TokenDB().checkValidToken();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(token).build();

		return getTokenVo(queryVO);
	}

	/**
	 * Get token details(TokenVO)
	 * 
	 * @param nodeId
	 * @throws SQLException
	 */
	public TokenVO getTokenDetails(String nodeId) throws SQLException {
		String sql = new TokenDB().getTokenDetailsFromNodeId();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(nodeId).build();

		return getTokenVo(queryVO);
	}

	/**
	 * Get token details(TokenVO)
	 * 
	 * @param nodeId
	 * @throws SQLException
	 */
	public TokenVO getTokenDetailsByToken(String token) throws SQLException {
		String sql = new TokenDB().getTokenDetailsByToken();
		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(token).build();

		return getTokenVo(queryVO);
	}

	/**
	 * Update token detail.
	 * 
	 * @param tokenstatus
	 * @param hostName
	 *            host name
	 * @return support token
	 * @throws Exception
	 */
	public boolean updateTokenstatus(String supportToken, TOKENSTATUS status) throws SQLException {
		String sqlUpdateSupportTokensStatus = new TokenDB().updateTokenStatus();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
						.appendQuery(sqlUpdateSupportTokensStatus).addParameter(status.ordinal())
						.addParameter(supportToken).build();

		int rsUdpatedToken = PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
		return rsUdpatedToken != 0;
	}

	/**
	 * Delete token details.
	 * 
	 * @param token
	 * @throws SQLException
	 */
	public boolean deleteTokenDetails(String token) throws SQLException {
		String deleteSql = new TokenDB().deleteTokenDetails();
		
		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
						.appendQuery(deleteSql).addParameter(token)
						.build();

		int rsDeletedToken = PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
		return rsDeletedToken != 0;
	}

	/**
	 * create TokenVo from ResultSet
	 */
	public TokenVO setTokenObject(ResultSet rs) throws SQLException {
		TokenVO tokenvo = new TokenVO();
		tokenvo.setSupportTokenId(rs.getString(SUPPORTTOKENS.supportTokenId.name()));
		tokenvo.setEmail(StringEncryptionDecryption.decrypt(rs.getString(SUPPORTTOKENS.email.name()),
				new CredProvider().getEcnKey()));
		tokenvo.setHostName(rs.getString(SUPPORTTOKENS.hostName.name()));
		tokenvo.setUserId(rs.getString(SUPPORTTOKENS.userId.name()));
		tokenvo.setToken(rs.getString(SUPPORTTOKENS.token.name()));
		tokenvo.setNodeId(rs.getString(SUPPORTTOKENS.nodeId.name()));
		tokenvo.setStatus(TOKENSTATUS.GetEnum(rs.getInt(SUPPORTTOKENS.status.name())));
		tokenvo.setExpiryTime(rs.getLong(SUPPORTTOKENS.expiryTime.name()));
		tokenvo.setCreatedon(rs.getTimestamp(SUPPORTTOKENS.createdon.name()).getTime());
		tokenvo.setModifiedon(rs.getTimestamp(SUPPORTTOKENS.modifiedon.name()).getTime());
		return tokenvo;
	}

	/**
	 * Get TokenVO by executing given sql.
	 */
	private TokenVO getTokenVo(QueryVO queryVO) throws SQLException {
		TokenVO tokenVO = null;
		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				tokenVO = setTokenObject(rs);
			}
		}
		return tokenVO;
	}

}
