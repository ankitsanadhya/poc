/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal.engine;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.common.enums.AppBackupTaskStatus;
import com.mwp.common.vo.QueryVO;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.common.vo.AppBackupSyncVO;
import com.mwp.p.dal.AppBackupSyncDB;

public class AppBackupSyncEngine {

	/**
	 * Get all sync tasks
	 * @return
	 */
	public List<AppBackupSyncVO> get() throws SQLException {
		return mGet();
	}

	/**
	 * Get sync Tasks for cluster id with status 
	 * @param clusterId
	 * @param appBackupTaskStatus
	 * @return
	 */
	public AppBackupSyncVO get(String clusterId, AppBackupTaskStatus appBackupTaskStatus) throws SQLException {
		return mGet(clusterId, appBackupTaskStatus);
	}

	/**
	 * Add sync task for cluster and user
	 * @param clusterId
	 * @param userId
	 * @return - database rows affected
	 */
	public int insert(String clusterId, String userId) throws SQLException {
		return mInsert(clusterId, userId);
	}

	/**
	 * update the AppBackupTaskStatus for clusterID 
	 * @param clusterId
	 * @param appBackupTaskStatus
	 * @return - database rows affected
	 */
	public int update(String clusterId, AppBackupTaskStatus appBackupTaskStatus) throws SQLException {
		return mUpdate(clusterId, appBackupTaskStatus);
	}

	/**
	 * Delete Sync task for cluster with status check ()  
	 * @param clusterId
	 * @param appBackupTaskStatus
	 * @return - database rows affected
	 */
	public int delete(String clusterId, AppBackupTaskStatus appBackupTaskStatus) throws SQLException {
		return mDelete(clusterId, appBackupTaskStatus);
	}

	private List<AppBackupSyncVO> mGet() throws SQLException {
		List<AppBackupSyncVO> appBackupSyncVOs = new LinkedList<>();
	
		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new AppBackupSyncDB().get()).build();

		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				appBackupSyncVOs.add(setAppBackupTaskObject(rs));
			}
		}

		return appBackupSyncVOs;
	}

	private AppBackupSyncVO mGet(String clusterId, AppBackupTaskStatus appBackupTaskStatus) throws SQLException {

		String listQuery = new AppBackupSyncDB().getWithClusterIdAndStatus();
		
		List<Object> parameters = new ArrayList<>();
		parameters.add(clusterId);
		parameters.add(appBackupTaskStatus.getStatusValue());
		
		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(listQuery).addParameters(parameters).build();

		
		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				return setAppBackupTaskObject(rs);
			}
		}

		return null;
	}

	private int mInsert(String clusterId, String userId) throws SQLException {
		String insertQuery = new AppBackupSyncDB().insert();
		
//		.append(table)
//		.append(" (")
//		.append(colList) 
//		.append(") VALUES (")
//		.append(connection.formatString(clusterId)).append(",")
//		.append(connection.formatString(userId)).append(",")
//		.append(AppBackupTaskStatus.ACTIVE.getStatusValue()).append(",")
//		.append(connection.formatString(new Timestamp(System.currentTimeMillis()).toString()))
//		.append(") ");		
	
		List<Object> parameters = new ArrayList<>();
		parameters.add(clusterId);
		parameters.add(userId);
		//parameters.add(AppBackupTaskStatus.ACTIVE.getStatusValue());
		parameters.add(new Timestamp(System.currentTimeMillis()).toString());
		
		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(insertQuery).addParameters(parameters).build();

		
		return PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
	}

	private int mUpdate(String clusterId, AppBackupTaskStatus appBackupTaskStatus) throws SQLException {
		
		String updateQuery = new AppBackupSyncDB().update();
	
		List<Object> parameters = new ArrayList<>();
		parameters.add(appBackupTaskStatus.getStatusValue());
		parameters.add(clusterId);
		
		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(updateQuery).addParameters(parameters).build();
		
		return PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
	}

	private int mDelete(String clusterId, AppBackupTaskStatus appBackupTaskStatus) throws SQLException {
		String listQuery = new AppBackupSyncDB().delete();
	
		List<Object> parameters = new ArrayList<>();
		parameters.add(clusterId);
		parameters.add(appBackupTaskStatus.getStatusValue());

		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(listQuery).addParameters(parameters).build();

		
		return PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
	}

	/**
	 * Create AppBackupSyncVO object through given Resultset
	 * @param rs
	 * @return AppBackupSyncVO
	 * @throws SQLException 
	 */
	private static AppBackupSyncVO setAppBackupTaskObject(ResultSet rs) throws SQLException{

		AppBackupSyncVO appBackupSyncVO = new AppBackupSyncVO();
		appBackupSyncVO.setClusterId(rs.getString(PortalDBEnum.APP_BACKUP_SYNC.clusterId.name()));
		appBackupSyncVO.setUserId(rs.getString(PortalDBEnum.APP_BACKUP_SYNC.userId.name()));
		appBackupSyncVO.setStatus(AppBackupTaskStatus.byDescription(rs.getInt(PortalDBEnum.APP_BACKUP_SYNC.status.name())));
		appBackupSyncVO.setRequestedTime(rs.getTimestamp(PortalDBEnum.APP_BACKUP_SYNC.requestedTime.name()).getTime());

		return appBackupSyncVO;
	}
}
