/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal.engine;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.mwp.common.StringFunctions;
import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.common.enums.NodeType;
import com.mwp.common.enums.StateEnum;
import com.mwp.common.enums.Status;
import com.mwp.common.vo.DeviceNodeMasterVO;
import com.mwp.common.vo.DeviceVO;
import com.mwp.common.vo.LabelVO;
import com.mwp.common.vo.QueryVO;
import com.mwp.logger.PALogger;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.dal.DeviceLabelMapDB;
import com.mwp.p.dal.DevicesDB;

/**
 * This class manages the queries returned related to device cluster.
 *
 */
public class ClusterEngine 
{	
	/**
	 * Create a cluster with the kubernetes devices.
	 * @param clusterDeviceVO object of cluster Device 
	 * @param deviceList List<DeviceNodeMasterVO> Role of device as (Master/Node) , mac Address and Device state 
	 * Note: one and only one device in list must have State as ACTIVE MASTER.
     * if root exist for this user then insert this entry in root otherwise add label
     * @return new cluster object as DeviceVO that contains DeviceNodeVO in nodes property. 
	 * @return
	 * @throws Exception
	 */
	public DeviceVO createCluster(DeviceVO clusterDeviceVO,   List<DeviceNodeMasterVO>  deviceList) throws Exception
	{
		return mCreateCluster(clusterDeviceVO, deviceList);
	}
	
	private List<String> getDeviceIds(List<String> allMacAddresses) throws SQLException {
		ArrayList<String> deviceIds = new ArrayList<>();
		// Select devices Id query before update deviceId of node table
		SqlQueryBuilder queryBuilder = new SqlQueryBuilder();
		queryBuilder.appendQuery("Select ");
		queryBuilder.appendQuery(PortalDBEnum.DEVICES_NODES_VIEW.devices_deviceId.name());
		queryBuilder.appendQuery(" FROM ");
		queryBuilder.appendQuery(PortalDBEnum.VIEW_NAMES.devicesnodes_view.name());
		queryBuilder.appendQuery(" WHERE ");
		queryBuilder.appendQuery(PortalDBEnum.DEVICES_NODES_VIEW.nodes_macAddress.name());
		queryBuilder.appendQueryIN(allMacAddresses);
		//queryBuilder.appendQuery("?");

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
						.appendQuery(queryBuilder.getQuery().toString()).addParameters(allMacAddresses).build();
		PALogger.TRACE(queryVO);
		try (ResultSet rsNodeId = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rsNodeId.next()) {
				deviceIds.add(rsNodeId.getString(PortalDBEnum.DEVICES_NODES_VIEW.devices_deviceId.name()));
			}
		}

		return deviceIds;
	}
	
	private DeviceVO mCreateCluster(DeviceVO clusterDeviceVO, List<DeviceNodeMasterVO> deviceList) throws Exception {
		List<QueryVO> quries = new ArrayList<>();
		ArrayList<String> allMacAddresses = new ArrayList<>();
		ArrayList<String> masterMacAddresses = new ArrayList<>();
		String activeMasterMacAddress = "";
		for (DeviceNodeMasterVO productObj : deviceList) {
			if (productObj.getNodeType() == NodeType.MASTER) {
				/*
				 * Add into MASTER mac addresses list
				 */
				masterMacAddresses.add(productObj.getMacAddress());
				if (productObj.getNodeState() == StateEnum.Active) {
					activeMasterMacAddress = productObj.getMacAddress();
				}
			}

			allMacAddresses.add(productObj.getMacAddress());
		}

		List<String> deviceIds = getDeviceIds(allMacAddresses);

		Map<String, String> queries = new DevicesDB().createCluster(deviceIds, allMacAddresses, masterMacAddresses,
				activeMasterMacAddress);

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
						.appendQuery(queries.get("InsertDevice")).addParameter(clusterDeviceVO.getDeviceId())
						.addParameter(clusterDeviceVO.getUserId()).addParameter(clusterDeviceVO.getPlatformId())
						.addParameter(clusterDeviceVO.getSwPlatformId()).addParameter(Status.ACTIVE.ordinal())
						.addParameter(clusterDeviceVO.getDeviceName())
						.addParameter(clusterDeviceVO.getDeviceType().ordinal())
						.addParameter(clusterDeviceVO.isActivationConfirmed()).build();
		PALogger.TRACE(queryVO);
		quries.add(queryVO);

		queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(queries.get("UpdateNode")).addParameter(clusterDeviceVO.getDeviceId())
				.addParameters(allMacAddresses).build();
		PALogger.TRACE(queryVO);
		quries.add(queryVO);

		if (queries.containsKey("UpdateMasterRole")) {
			queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
					.appendQuery(queries.get("UpdateMasterRole")).addParameters(masterMacAddresses).build();
			PALogger.TRACE(queryVO);
			quries.add(queryVO);
		}

		if (queries.containsKey("UpdateActiveMasterState")) {
			queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
					.appendQuery(queries.get("UpdateActiveMasterState")).addParameter(activeMasterMacAddress).build();
			PALogger.TRACE(queryVO);
			quries.add(queryVO);
		}

		if (queries.containsKey("UpdateBackUpMasterState")) {
			queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
					.appendQuery(queries.get("UpdateBackUpMasterState")).addParameter(clusterDeviceVO.getDeviceId())
					.addParameter(activeMasterMacAddress).build();
			PALogger.TRACE(queryVO);
			quries.add(queryVO);
		}

		if (queries.containsKey("DeleteDevice")) {
			queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
					.appendQuery(queries.get("DeleteDevice")).addParameters(deviceIds)
					.build();
			PALogger.TRACE(queryVO);
			quries.add(queryVO);
		}

		if (queries.containsKey("DeleteStatistics")) {
			queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
					.appendQuery(queries.get("DeleteStatistics")).addParameters(deviceIds)
					.build();
			PALogger.TRACE(queryVO);
			
			quries.add(queryVO);
		}

		/*
		 * Add cluster device to root label
		 */
		LabelEngine labelEngine = new LabelEngine();
		String rootId = labelEngine.getRootId(clusterDeviceVO.getUserId());
		if (StringFunctions.isNullOrWhitespace(rootId)) {
			LabelVO labelRoot = labelEngine.addRoot(clusterDeviceVO.getUserId());
			rootId = labelRoot.getLabelId();
		}

		// if root exist for this user then insert this entry in root otherwise
		// add label
		DeviceLabelMapDB deviceMap = new DeviceLabelMapDB();
		String sql = deviceMap.addDeviceLabel();
		queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(sql).addParameter(rootId).addParameter(clusterDeviceVO.getDeviceId()).build();
		PALogger.TRACE(queryVO);
		quries.add(queryVO);

		PortalDatabaseEngine.getInstance().getConnection().executeUpdatesInTransaction(quries);
		return clusterDeviceVO;
	}

	/**
	 * Add a device to existing cluster.
	 * 
	 * @param clusterDeviceVO
	 *            in which the device to be added
	 * @param listProductId
	 *            List<DeviceNodeMasterVO> Role of device as Key( Master/Node) ,
	 *            mac Address as value.
	 * @throws SQLException
	 */
	public void addDevicesToCluster(DeviceVO clusterDeviceVO, List<DeviceNodeMasterVO> deviceList) throws SQLException {
		mAddDevicesToCluster(clusterDeviceVO, deviceList);
	}

	private void mAddDevicesToCluster(DeviceVO clusterDeviceVO, List<DeviceNodeMasterVO> listProductId)
			throws SQLException {
		List<String> allMacAddresses = new ArrayList<>();
		List<String> masterMacAddresses = new ArrayList<>();
		String activeMasterMacAddress = "";
		for (DeviceNodeMasterVO productObj : listProductId) {
			if (productObj.getNodeType() == NodeType.MASTER) {
				/*
				 * Add into MASTER mac addresses list
				 */
				masterMacAddresses.add(productObj.getMacAddress());
				if (productObj.getNodeState() == StateEnum.Active) {
					activeMasterMacAddress = productObj.getMacAddress();
				}
			}

			allMacAddresses.add(productObj.getMacAddress());
		}

		List<String> deviceIds = getDeviceIds(allMacAddresses);

		Map<String, String> queries = new DevicesDB().addDevicesToCluster(deviceIds, allMacAddresses,
				masterMacAddresses, activeMasterMacAddress);

		List<QueryVO> queryVOs = getAddDeviceQueryVOList(queries, clusterDeviceVO, listProductId);

		PortalDatabaseEngine.getInstance().getConnection().executeUpdatesInTransaction(queryVOs);
	}
	
	private List<QueryVO> getAddDeviceQueryVOList(Map<String, String> queries, DeviceVO clusterDeviceVO,
			List<DeviceNodeMasterVO> deviceList) throws SQLException {

		List<QueryVO> quries = new ArrayList<>();
		ArrayList<String> allMacAddresses = new ArrayList<>();
		ArrayList<String> masterMacAddresses = new ArrayList<>();
		String activeMasterMacAddress = "";
		for (DeviceNodeMasterVO productObj : deviceList) {
			if (productObj.getNodeType() == NodeType.MASTER) {
				/*
				 * Add into MASTER mac addresses list
				 */
				masterMacAddresses.add(productObj.getMacAddress());
				if (productObj.getNodeState() == StateEnum.Active) {
					activeMasterMacAddress = productObj.getMacAddress();
				}
			}

			allMacAddresses.add(productObj.getMacAddress());
		}

		List<String> deviceIds = getDeviceIds(allMacAddresses);

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
						.appendQuery(queries.get("UpdateNode")).addParameter(clusterDeviceVO.getDeviceId())
						.addParameters(allMacAddresses).build();
		quries.add(queryVO);

		if (queries.containsKey("UpdateMasterRole")) {
			queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
					.appendQuery(queries.get("UpdateMasterRole")).addParameters(masterMacAddresses).build();
			quries.add(queryVO);
		}

		if (queries.containsKey("UpdateActiveMasterState")) {
			queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
					.appendQuery(queries.get("UpdateActiveMasterState")).addParameter(activeMasterMacAddress).build();
			quries.add(queryVO);
		}

		if (queries.containsKey("UpdateBackUpMasterState")) {
			queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
					.appendQuery(queries.get("UpdateBackUpMasterState")).addParameter(clusterDeviceVO.getDeviceId())
					.addParameter(activeMasterMacAddress).build();
			quries.add(queryVO);
		}

		if (queries.containsKey("DeleteDevice")) {
			queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
					.appendQuery(queries.get("DeleteDevice")).addParameters(deviceIds).build();
			PALogger.TRACE(queryVO);
			quries.add(queryVO);
		}

		if (queries.containsKey("DeleteStatistics")) {
			queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
					.appendQuery(queries.get("DeleteStatistics")).addParameters(deviceIds).build();
			PALogger.TRACE(queryVO);

			quries.add(queryVO);
		}

		return quries;
	}

	/**
	 * Update name of cluster in database 
	 * @param clusterDeviceId
	 * @param clusterName
	 * @return
	 * @throws SQLException
	 */
	public boolean updateClusterName(String clusterDeviceId, String clusterName) throws SQLException
	{
		return mUpdateClusterName(clusterDeviceId, clusterName); 
	}
	
	private boolean mUpdateClusterName(String clusterDeviceId, String clusterName) throws SQLException
	{
		String query = new DevicesDB().updateClusterDeviceName();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(query)
						.addParameter(clusterDeviceId).addParameter(clusterName).build();

		int count = PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
		return (count > 0);
	}

	/**
	 * Get id of cluster by name
	 * @param clusterName
	 * @return
	 * @throws SQLException
	 */
	public String getClusterId(String clusterName) throws SQLException 
	{
		return mGetClusterId(clusterName);
		
	}
	
	private String mGetClusterId(String clusterName) throws SQLException 
	{
		String sql = new DevicesDB().getClusterId();
		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(clusterName).build();
		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				return rs.getString(PortalDBEnum.DEVICES.deviceId.name());
			}
		}

		return "";

	}
}
