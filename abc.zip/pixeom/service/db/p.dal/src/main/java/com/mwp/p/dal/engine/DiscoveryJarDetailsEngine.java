/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal.engine;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mwp.common.CredProvider;
import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.common.enums.RelayEnum.NetworkTypeEnum;
import com.mwp.common.vo.DiscoveryJarDetailsVO;
import com.mwp.common.vo.QueryVO;
import com.mwp.logger.PALogger;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.common.enums.PortalDBEnum.DISCOVERY_JAR_DETAILS;
import com.mwp.p.dal.DiscoveryJarDetailsDB;
import com.pa.crypto.StringEncryptionDecryption;

/**
 * This class executes querioes related to {@link DISCOVERY_JAR_DETAILS} table  
 *
 */
public class DiscoveryJarDetailsEngine {

	/**
	 * Add new  discovery jar details on duplicate key update properties.
	 * @param deviceId
	 * @param hostName
	 * @param iPAddress
	 * @param localIPAddress
	 * @param chatInputChannel
	 * @param chatOutputChannel
	 * @param chatSubscriptionChannel
	 * @param nodeCommunicationPort
	 * @param openStackPort
	 * @param tomcatPort
	 * @param port1
	 * @param port2
	 * @param port3
	 * @param port4
	 * @param port5
	 * @param rURLTomcatPort
	 * @param rAddress
	 * @param isSetRURL
	 * @param status
	 * @param networkType
	 * @param relayServerId
	 * @param portSegmentStart
	 * @throws SQLException
	 */
	public void updateDiscoveryDetails(String deviceId, String hostName, String iPAddress, 
			String localIPAddress, String chatInputChannel, String chatOutputChannel, String chatSubscriptionChannel, 
			String nodeCommunicationPort, String openStackPort,  String tomcatPort, String port1, String port2, 
			String port3, String port4, String port5, String rURLTomcatPort,  String rAddress, 
			 int status, NetworkTypeEnum networkType, String relayServerId) throws SQLException {
		mUupdateDiscoveryDetails(deviceId, hostName, iPAddress, localIPAddress, chatInputChannel, chatOutputChannel, chatSubscriptionChannel, 
				nodeCommunicationPort, openStackPort,  tomcatPort, port1, port2, port3, port4, port5, 
				rURLTomcatPort,  rAddress,  status, networkType, relayServerId);
	}

	/**
	 * Get discovery jar details object by macAddress also set relay server information
	 * @param mACAddress
	 * @return
	 * @throws SQLException
	 */
	public DiscoveryJarDetailsVO getDiscoveryJarDetailsWithRelay(String mACAddress) throws SQLException {
		return mGetDiscoveryJarDetailsWithRelay(mACAddress);
	}


	/**
	 * Get discovery jar details object by macAddress
	 * @param mACAddress
	 * @return
	 * @throws SQLException
	 */
	public DiscoveryJarDetailsVO getDiscoveryJarDetails(String mACAddress) throws SQLException {
		DiscoveryJarDetailsVO detailsVO = null;
		String sql = new DiscoveryJarDetailsDB().getDiscoveryJarDetails();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(mACAddress).addParameter(1).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				detailsVO = new DiscoveryJarDetailsVO();
				detailsVO.setnStatus(rs.getInt(PortalDBEnum.DISCOVERY_JAR_DETAILS.nStatus.name()));
				detailsVO.setsIPAddress(rs.getString(PortalDBEnum.DISCOVERY_JAR_DETAILS.sIPAddress.name()));
				detailsVO.setsLocalIPAddress(rs.getString(PortalDBEnum.DISCOVERY_JAR_DETAILS.sLocalIPAddress.name()));
				detailsVO.setsTomcatPort(rs.getString(PortalDBEnum.DISCOVERY_JAR_DETAILS.sTomcatPort.name()));
				detailsVO.setsRURLTomcatPort(rs.getString(PortalDBEnum.DISCOVERY_JAR_DETAILS.sRURLTomcatPort.name()));
				detailsVO.setsRelayServerID(rs.getString(PortalDBEnum.DISCOVERY_JAR_DETAILS.sRelayServerID.name()));
				detailsVO.setsRAddress(rs.getString(PortalDBEnum.DISCOVERY_JAR_DETAILS.sRAddress.name()));
				detailsVO.setsPort1(rs.getString(PortalDBEnum.DISCOVERY_JAR_DETAILS.sPort1.name()));
				detailsVO.setsPort2(rs.getString(PortalDBEnum.DISCOVERY_JAR_DETAILS.sPort2.name()));
				detailsVO.setsPort3(rs.getString(PortalDBEnum.DISCOVERY_JAR_DETAILS.sPort3.name()));
				detailsVO.setsPort4(rs.getString(PortalDBEnum.DISCOVERY_JAR_DETAILS.sPort4.name()));
				detailsVO.setsPort5(rs.getString(PortalDBEnum.DISCOVERY_JAR_DETAILS.sPort5.name()));
				detailsVO.setsNetworkType(
						NetworkTypeEnum.GetEnum(rs.getInt(PortalDBEnum.DISCOVERY_JAR_DETAILS.sNetworkType.name())));
				detailsVO.setsConnectURL(rs.getString(PortalDBEnum.DISCOVERY_JAR_DETAILS.sConnectURL.name()));
				detailsVO.setsMACAddress(rs.getString(PortalDBEnum.DISCOVERY_JAR_DETAILS.sMACAddress.name()));
				detailsVO.setsHostName(rs.getString(PortalDBEnum.DISCOVERY_JAR_DETAILS.sHostName.name()));
				detailsVO.setdHBRdate(rs.getTimestamp(PortalDBEnum.DISCOVERY_JAR_DETAILS.dHBRdate.name()).getTime());
			}
		}
		return detailsVO;
	}

	/**
	 * Get discovery jar details object by hostName  
	 * @param hostName
	 * @return
	 * @throws SQLException
	 */
	public DiscoveryJarDetailsVO getDiscoveryJarDetailsUsingHostName(String hostName) throws SQLException {
		DiscoveryJarDetailsVO detailsVO = null;
		String sql = new DiscoveryJarDetailsDB().getDiscoveryJarDetailsUsingHostName();
		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(hostName).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				detailsVO = new DiscoveryJarDetailsVO();
				detailsVO.setnStatus(rs.getInt(PortalDBEnum.DISCOVERY_JAR_DETAILS.nStatus.name()));
				detailsVO.setsIPAddress(rs.getString(PortalDBEnum.DISCOVERY_JAR_DETAILS.sIPAddress.name()));
				detailsVO.setsLocalIPAddress(rs.getString(PortalDBEnum.DISCOVERY_JAR_DETAILS.sLocalIPAddress.name()));
				detailsVO.setsTomcatPort(rs.getString(PortalDBEnum.DISCOVERY_JAR_DETAILS.sTomcatPort.name()));
				detailsVO.setsRURLTomcatPort(rs.getString(PortalDBEnum.DISCOVERY_JAR_DETAILS.sRURLTomcatPort.name()));
				detailsVO.setsRelayServerID(rs.getString(PortalDBEnum.DISCOVERY_JAR_DETAILS.sRelayServerID.name()));
				detailsVO.setsRAddress(rs.getString(PortalDBEnum.DISCOVERY_JAR_DETAILS.sRAddress.name()));
				detailsVO.setsPort1(rs.getString(PortalDBEnum.DISCOVERY_JAR_DETAILS.sPort1.name()));
				detailsVO.setsPort2(rs.getString(PortalDBEnum.DISCOVERY_JAR_DETAILS.sPort2.name()));
				detailsVO.setsPort3(rs.getString(PortalDBEnum.DISCOVERY_JAR_DETAILS.sPort3.name()));
				detailsVO.setsPort4(rs.getString(PortalDBEnum.DISCOVERY_JAR_DETAILS.sPort4.name()));
				detailsVO.setsPort5(rs.getString(PortalDBEnum.DISCOVERY_JAR_DETAILS.sPort5.name()));
				detailsVO.setsNetworkType(
						NetworkTypeEnum.GetEnum(rs.getInt(PortalDBEnum.DISCOVERY_JAR_DETAILS.sNetworkType.name())));
				detailsVO.setsConnectURL(rs.getString(PortalDBEnum.DISCOVERY_JAR_DETAILS.sConnectURL.name()));
				detailsVO.setsMACAddress(rs.getString(PortalDBEnum.DISCOVERY_JAR_DETAILS.sMACAddress.name()));
				detailsVO.setsHostName(rs.getString(PortalDBEnum.DISCOVERY_JAR_DETAILS.sHostName.name()));
				detailsVO.setdHBRdate(rs.getTimestamp(PortalDBEnum.DISCOVERY_JAR_DETAILS.dHBRdate.name()).getTime());

				detailsVO.setsChatInputChannel(
						rs.getString(PortalDBEnum.DISCOVERY_JAR_DETAILS.sChatInputChannel.name()));
				detailsVO.setsChatOutputChannel(
						rs.getString(PortalDBEnum.DISCOVERY_JAR_DETAILS.sChatOutputChannel.name()));
				detailsVO.setsChatSubscriptionChannel(
						rs.getString(PortalDBEnum.DISCOVERY_JAR_DETAILS.sChatSubscriptionChannel.name()));
				detailsVO.setsNodeCommunicationPort(
						rs.getString(PortalDBEnum.DISCOVERY_JAR_DETAILS.sNodeCommunicationPort.name()));
				detailsVO.setsOpenStackPort(rs.getString(PortalDBEnum.DISCOVERY_JAR_DETAILS.sOpenStackPort.name()));
			}
		}
		return detailsVO;
	}

	/**
	 * Get discovery jar details where ipaddress set to given  ExternalIP
	 * @param externalIP
	 * @return
	 * @throws SQLException
	 */
	public List<DiscoveryJarDetailsVO> getNonActivatedDevices(String externalIP) throws SQLException {
		List<DiscoveryJarDetailsVO> lstDetailsVO = new ArrayList<>();
		String sql = new DiscoveryJarDetailsDB().getNonActivatedDevices();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameterForLike(true, externalIP, true).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				DiscoveryJarDetailsVO detailsVO = new DiscoveryJarDetailsVO();
				detailsVO.setnStatus(rs.getInt(PortalDBEnum.DISCOVERY_JAR_DETAILS.nStatus.name()));
				detailsVO.setsIPAddress(rs.getString(PortalDBEnum.DISCOVERY_JAR_DETAILS.sIPAddress.name()));
				detailsVO.setsLocalIPAddress(rs.getString(PortalDBEnum.DISCOVERY_JAR_DETAILS.sLocalIPAddress.name()));
				detailsVO.setsTomcatPort(rs.getString(PortalDBEnum.DISCOVERY_JAR_DETAILS.sTomcatPort.name()));
				detailsVO.setsRURLTomcatPort(rs.getString(PortalDBEnum.DISCOVERY_JAR_DETAILS.sRURLTomcatPort.name()));
				detailsVO.setsRelayServerID(rs.getString(PortalDBEnum.DISCOVERY_JAR_DETAILS.sRelayServerID.name()));
				detailsVO.setsRAddress(rs.getString(PortalDBEnum.DISCOVERY_JAR_DETAILS.sRAddress.name()));
				detailsVO.setsPort1(rs.getString(PortalDBEnum.DISCOVERY_JAR_DETAILS.sPort1.name()));
				detailsVO.setsPort2(rs.getString(PortalDBEnum.DISCOVERY_JAR_DETAILS.sPort2.name()));
				detailsVO.setsPort3(rs.getString(PortalDBEnum.DISCOVERY_JAR_DETAILS.sPort3.name()));
				detailsVO.setsPort4(rs.getString(PortalDBEnum.DISCOVERY_JAR_DETAILS.sPort4.name()));
				detailsVO.setsPort5(rs.getString(PortalDBEnum.DISCOVERY_JAR_DETAILS.sPort5.name()));
				detailsVO.setsNetworkType(
						NetworkTypeEnum.GetEnum(rs.getInt(PortalDBEnum.DISCOVERY_JAR_DETAILS.sNetworkType.name())));
				detailsVO.setsConnectURL(rs.getString(PortalDBEnum.DISCOVERY_JAR_DETAILS.sConnectURL.name()));
				detailsVO.setsMACAddress(rs.getString(PortalDBEnum.DISCOVERY_JAR_DETAILS.sMACAddress.name()));
				detailsVO.setsHostName(rs.getString(PortalDBEnum.DISCOVERY_JAR_DETAILS.sHostName.name()));
				detailsVO.setdHBRdate(rs.getTimestamp(PortalDBEnum.DISCOVERY_JAR_DETAILS.dHBRdate.name()).getTime());
				lstDetailsVO.add(detailsVO);
			}
		}
		return lstDetailsVO;
	}

	/**
	 * Update connectUrl of discovery jar details entry by macAddress
	 * @param connectURL
	 * @param macAddress
	 * @throws SQLException if macAddress does not exists
	 */
	public void updateDiscoveryDetailsConnectUrl(String connectURL, String macAddress) throws SQLException{
		mUpdateDiscoveryjarDetailsConnectUrl(connectURL, macAddress);
	}

	/**
	 * Delete entry of discovery jar details for device by macAddress
	 * @param mACAddress
	 * @throws SQLException
	 */
	public void deleteDiscoveryJarDetails(String mACAddress) throws SQLException {
		mDeleteDiscoveryJarDetails(mACAddress);

	}

	private void mDeleteDiscoveryJarDetails(String mACAddress) throws SQLException {
		String sql = new DiscoveryJarDetailsDB().deleteDiscoveryJarDetails();
		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(mACAddress).build();

		PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);

	}

	/**
	 *  Update heartbeat of device by macAddress
	 * @param productId
	 * @throws SQLException
	 */
	public void updateInactiveDeviceHeartbeat(String productId) throws SQLException {
		String sql = new DiscoveryJarDetailsDB().updateInactiveDeviceHeartbeat();
		
		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(productId).build();

		
		PALogger.INFO("=====updateInactiveDeviceHeartbeat SQL====" + sql + "============");
		int updateCount = PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
		if(updateCount == 0){
			throw new SQLException("Unable to update discoveryjardetails, please try again.");
		}
	}

	private void mUpdateDiscoveryjarDetailsConnectUrl(String connectURL, String macAddress) throws SQLException {
		String sql = new DiscoveryJarDetailsDB().updateDiscoveryDetailsConnectUrl();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(connectURL).addParameter(macAddress).build();

		int updateCount = PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
		if (updateCount == 0) {
			throw new SQLException("Unable to update discoveryjardetails, please try again.");
		}
	}

	private DiscoveryJarDetailsVO mGetDiscoveryJarDetailsWithRelay(String mACAddress) throws SQLException {
		DiscoveryJarDetailsVO detailsVO = null;
		String sql = new DiscoveryJarDetailsDB().getDiscoveryJarDetailsWithRelay();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(mACAddress).addParameter(1).addParameter(4).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				detailsVO = new DiscoveryJarDetailsVO();
				detailsVO.setnStatus(rs.getInt(PortalDBEnum.DISCOVERY_JAR_DETAILS.nStatus.name()));
				detailsVO.setsIPAddress(rs.getString(PortalDBEnum.DISCOVERY_JAR_DETAILS.sIPAddress.name()));
				detailsVO.setsLocalIPAddress(rs.getString(PortalDBEnum.DISCOVERY_JAR_DETAILS.sLocalIPAddress.name()));
				detailsVO.setsTomcatPort(rs.getString(PortalDBEnum.DISCOVERY_JAR_DETAILS.sTomcatPort.name()));
				detailsVO.setsRURLTomcatPort(rs.getString(PortalDBEnum.DISCOVERY_JAR_DETAILS.sRURLTomcatPort.name()));
				detailsVO.setsRelayServerID(rs.getString(PortalDBEnum.DISCOVERY_JAR_DETAILS.sRelayServerID.name()));
				detailsVO.setsRAddress(rs.getString(PortalDBEnum.DISCOVERY_JAR_DETAILS.sRAddress.name()));
				detailsVO.setsPort1(rs.getString(PortalDBEnum.DISCOVERY_JAR_DETAILS.sPort1.name()));
				detailsVO.setsPort2(rs.getString(PortalDBEnum.DISCOVERY_JAR_DETAILS.sPort2.name()));
				detailsVO.setsPort3(rs.getString(PortalDBEnum.DISCOVERY_JAR_DETAILS.sPort3.name()));
				detailsVO.setsPort4(rs.getString(PortalDBEnum.DISCOVERY_JAR_DETAILS.sPort4.name()));
				detailsVO.setsPort5(rs.getString(PortalDBEnum.DISCOVERY_JAR_DETAILS.sPort5.name()));
				detailsVO.setsNetworkType(
						NetworkTypeEnum.GetEnum(rs.getInt(PortalDBEnum.DISCOVERY_JAR_DETAILS.sNetworkType.name())));
				detailsVO.setsConnectURL(rs.getString(PortalDBEnum.DISCOVERY_JAR_DETAILS.sConnectURL.name()));
				detailsVO.setsMACAddress(rs.getString(PortalDBEnum.DISCOVERY_JAR_DETAILS.sMACAddress.name()));
				detailsVO.setsHostName(rs.getString(PortalDBEnum.DISCOVERY_JAR_DETAILS.sHostName.name()));
				detailsVO.setdHBRdate(rs.getTimestamp(PortalDBEnum.DISCOVERY_JAR_DETAILS.dHBRdate.name()).getTime());
				detailsVO.setsRelayServerAddress(rs.getString(PortalDBEnum.RELAY_SERVERS.sRelayServerAddress.name()));

				String rUserName = StringEncryptionDecryption.encrypt(
						StringEncryptionDecryption.decrypt(rs.getString(PortalDBEnum.RELAY_SERVERS.sRUserName.name()),
								new CredProvider().getEcnKey()),
						mACAddress);
				String rpwd = StringEncryptionDecryption.encrypt(
						StringEncryptionDecryption.decrypt(rs.getString(PortalDBEnum.RELAY_SERVERS.sRPassword.name()),
								new CredProvider().getEcnKey()),
						mACAddress);
				String hostKey = StringEncryptionDecryption.encrypt(
						StringEncryptionDecryption.decrypt(rs.getString(PortalDBEnum.RELAY_SERVERS.sHostKey.name()),
								new CredProvider().getEcnKey()),
						mACAddress);

				detailsVO.setsRUserName(rUserName);
				detailsVO.setsRPassword(rpwd);
				detailsVO.setsHostKey(hostKey);

				detailsVO.setnRPort(rs.getInt(PortalDBEnum.RELAY_SERVERS.nRPort.name()));
			}
		} 
		return detailsVO;
	}

	private void mUupdateDiscoveryDetails(String deviceId, String hostName, String iPAddress, 
			String localIPAddress, String chatInputChannel, String chatOutputChannel, String chatSubscriptionChannel, 
			String nodeCommunicationPort, String openStackPort, String tomcatPort, String port1, String port2, 
			String port3, String port4, String port5, String rURLTomcatPort,  String rAddress, 
			 int status, NetworkTypeEnum networkType, String relayServerId ) throws SQLException {

		QueryVO  queryVO = getJarObject(deviceId, hostName, iPAddress, localIPAddress, chatInputChannel, chatOutputChannel,
				chatSubscriptionChannel, nodeCommunicationPort, openStackPort, tomcatPort, port1, port2, port3, port4,
				port5, rURLTomcatPort, rAddress, status, networkType, relayServerId);
		int updateCount = PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
		if(updateCount == 0){
			throw new SQLException("Unable to update discoveryjardetails, please try again.");
		}
	}
	
	private QueryVO getJarObject(String deviceId, String hostName, String iPAddress, String localIPAddress,
			String chatInputChannel, String chatOutputChannel, String chatSubscriptionChannel,
			String nodeCommunicationPort, String openStackPort, String tomcatPort, String port1, String port2,
			String port3, String port4, String port5, String rURLTomcatPort, String rAddress, int status,
			NetworkTypeEnum networkType, String relayServerId) throws SQLException {
		String sql = new DiscoveryJarDetailsDB().addDiscoveryJarDetails();
		// return new SqlQueryBuilder(
		// PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
		// .addParameter(deviceId).addParameter(hostName).addParameter("").addParameter(deviceId)
		// .addParameter(0).addParameter(iPAddress).addParameter(localIPAddress)
		// .addParameter(chatInputChannel).addParameter(chatOutputChannel)
		// .addParameter(chatSubscriptionChannel).addParameter(nodeCommunicationPort)
		// .addParameter(openStackPort).addParameter("").addParameter(tomcatPort).addParameter("")
		// .addParameter(port1).addParameter(port2).addParameter(port3).addParameter(port4)
		// .addParameter(port5).addParameter(rURLTomcatPort).addParameter("").addParameter(rAddress)
		// .addParameter(status).addParameter(relayServerId).addParameter(networkType.ordinal())
		//
		// .addParameter(hostName).addParameter(iPAddress)
		// .addParameter(localIPAddress).addParameter(chatInputChannel).addParameter(chatOutputChannel)
		// .addParameter(chatSubscriptionChannel).addParameter(nodeCommunicationPort)
		// .addParameter(openStackPort)
		// .addParameter("").addParameter(tomcatPort).addParameter(port1).addParameter(port2)
		// .addParameter(port3).addParameter(port4).addParameter(port5).addParameter(rURLTomcatPort)
		// .addParameter(rAddress).addParameter(status).addParameter(relayServerId)
		// .addParameter(networkType.ordinal())
		//
		// .build();

		return new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(sql).addParameter(deviceId).addParameter(hostName).addParameter("").addParameter(deviceId)
				.addParameter(0).addParameter(iPAddress).addParameter(localIPAddress).addParameter(chatInputChannel)
				.addParameter(chatOutputChannel).addParameter(chatSubscriptionChannel)
				.addParameter(nodeCommunicationPort).addParameter(openStackPort).addParameter("")
				.addParameter(tomcatPort).addParameter("").addParameter(port1).addParameter(port2).addParameter(port3)
				.addParameter(port4).addParameter(port5).addParameter(rURLTomcatPort).addParameter("")
				.addParameter(rAddress).addParameter(status).addParameter(relayServerId)
				.addParameter(networkType.ordinal()).addParameter(hostName).addParameter(iPAddress)
				.addParameter(localIPAddress).addParameter(chatInputChannel).addParameter(chatOutputChannel)
				.addParameter(chatSubscriptionChannel).addParameter(nodeCommunicationPort).addParameter(openStackPort)
				.addParameter("").addParameter(tomcatPort).addParameter(port1).addParameter(port2).addParameter(port3)
				.addParameter(port4).addParameter(port5).addParameter(rURLTomcatPort).addParameter("")
				.addParameter(rAddress).addParameter(status).addParameter(relayServerId)
				.addParameter(networkType.ordinal()).build();

	}
	
}
