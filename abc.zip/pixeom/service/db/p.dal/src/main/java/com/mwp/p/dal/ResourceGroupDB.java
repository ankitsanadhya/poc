/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.mwp.p.dal;

import java.util.List;

import com.mwp.common.StringFunctions;
import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.p.common.enums.PortalDBEnum;

public class ResourceGroupDB 
{
	/**
	 * add resource group relation
	 * @param resourceId
	 * @param groupId
	 * @param resourceType
	 * @return
	 */
	public String addResourceToGroup()  {
		return mAddResourceToGroup();
	}

	/**
	 * remove resource from group
	 * @param resourceId
	 * @param groupId
	 * @return
	 */
	public String removeResourceFromGroup(String resourceId) {
		return mRemoveResourceFromGroup(resourceId); 
	}
	
	
	/**
	 * remove resources from group
	 * @param resourceIds
	 * @param groupId
	 * @return
	 */
	public String removeResourceFromGroup(List<String> resourceIds) {
		return mRemoveResourceFromGroup(resourceIds); 
	}

	/**
	 *  get groupResourceId  according to resourceId,groupId combination.
	 * @param resourceId
	 * @param groupId
	 * @return
	 */
	public String getGroupResourceId() {
		return mGetGroupResourceId();
	}


	private String mAddResourceToGroup() 
	{
		StringBuilder sb = new StringBuilder();
		sb.append("INSERT INTO ");
		sb.append(PortalDBEnum.TABLE_NAMES.groupResources);
		sb.append(" ( ");
		sb.append(PortalDBEnum.GROUP_RESOURCES.groupResouceId.name());
		sb.append(", ");
		sb.append(PortalDBEnum.GROUP_RESOURCES.groupId.name());
		sb.append(", ");
		sb.append(PortalDBEnum.GROUP_RESOURCES.resourceId.name());
		sb.append(", ");
		sb.append(PortalDBEnum.GROUP_RESOURCES.resourceType.name());
		sb.append(" ) VALUES ( ");
		//sb.append(dbCon.formatString(Common.getRandomId()));
		sb.append("?");
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(groupId));
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(resourceId));
		sb.append(", ");
		sb.append("?");
//		sb.append(resourceType.ordinal());
		sb.append(" ) ");
		return sb.toString();
	}

	private String mRemoveResourceFromGroup(String resourceId)
	{
		StringBuilder sb = new StringBuilder();
		sb.append("DELETE ");
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.groupResources);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.GROUP_RESOURCES.groupId.name());
		sb.append(" = ");
		sb.append("?");
//		sb.append(dbCon.formatString(groupId));
		//resourceId will be blank in case of delete group(where all resourceId in group are to be removed from group)
		if(!StringFunctions.isNullOrWhitespace(resourceId))
		{
			sb.append(" AND ");
			sb.append(PortalDBEnum.GROUP_RESOURCES.resourceId.name());
			sb.append(" = ");
			sb.append("?");
//			sb.append(dbCon.formatString(resourceId));
		}
		return sb.toString();
	}

	
//	public static void main(String[] args) 
//	{
//		ResourceGroupDB grp= new ResourceGroupDB();
//		List<String> st= new ArrayList<>();
//		st.add("12");
//		st.add("123");
//		st.add("45");
//		grp.removeResourceFromGroup(st, "gH");
//	}
	
	private String mRemoveResourceFromGroup(List<String> resourceIds)
	{
		SqlQueryBuilder builder = new SqlQueryBuilder();
		builder.appendQuery("DELETE ");
		builder.appendQuery(" FROM ");
		builder.appendQuery(PortalDBEnum.TABLE_NAMES.groupResources);
		builder.appendQuery(" WHERE ");
		builder.appendQuery(PortalDBEnum.GROUP_RESOURCES.groupId.name());
		builder.appendQuery(" = ");
		builder.appendQuery("?");
//		builder.appendQuery(dbCon.formatString(groupId));
		builder.appendQuery(" AND ");
		builder.appendQuery(PortalDBEnum.GROUP_RESOURCES.resourceId.name());
		
		builder.appendQueryIN(resourceIds);
		
//		builder.appendQuery(" In (");
//		builder.appendQuery(dbCon.formatStringForIn(resourceIds));
//		builder.appendQuery(")");
		
		return builder.getQuery().toString();
	}


	private String mGetGroupResourceId()
	{
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT ");
		sb.append(PortalDBEnum.GROUP_RESOURCES.groupResouceId.name());
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.groupResources);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.GROUP_RESOURCES.groupId.name());
		sb.append(" = ");
		sb.append("?");
//		sb.append(dbCon.formatString(groupId));
		sb.append(" AND ");
		sb.append(PortalDBEnum.GROUP_RESOURCES.resourceId.name());
		sb.append(" = ");
		sb.append("?");
//		sb.append(dbCon.formatString(resourceId));

		return sb.toString();
	}
}
