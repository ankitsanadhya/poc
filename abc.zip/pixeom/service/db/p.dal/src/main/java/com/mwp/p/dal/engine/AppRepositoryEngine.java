/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal.engine;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mwp.common.Common;
import com.mwp.common.StringFunctions;
import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.common.vo.ApplicationPlatformVO;
import com.mwp.common.vo.QueryVO;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.dal.AppRepositoryDB;

/**
 * This class manages Application repository
 */
public class AppRepositoryEngine {

	/**
	 * Add application repository in applicationPlatform table 
	 * @param appRepoVO
	 * @return
	 * @throws SQLException exception "application repository not added." if not added
	 */

	public ApplicationPlatformVO addAppRepo(ApplicationPlatformVO appRepoVO) throws SQLException {
		return mAddAppRepo(appRepoVO);
	}

	private ApplicationPlatformVO mAddAppRepo(ApplicationPlatformVO appRepoVO) throws SQLException {
		AppRepositoryDB repositoryDB = new AppRepositoryDB();
		appRepoVO.setAppPlatformId(Common.getRandomId());
		String sql = repositoryDB.addAppRepo(appRepoVO);

		List<String> parameters = new ArrayList<>();
		parameters.add(appRepoVO.getAppPlatformId());
		parameters.add(appRepoVO.getPlatformId());
		parameters.add(appRepoVO.getAppId());
		parameters.add(appRepoVO.getRepositoryName());

		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(sql).addParameters(parameters).build();

		int addCount = PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
		if(addCount==0){
			throw new SQLException("application repository not added.");
		}
		return appRepoVO;
	}

	public List<String> isRepoNameAvailable(List<String> repoNames, String appId) throws SQLException {
		return mIsRepoNameAvailable(repoNames, appId);
	}

	private List<String> mIsRepoNameAvailable(List<String> repoNames, String appId) throws SQLException {
		List<String> lstRepoNamesTaken = new ArrayList<>();
		AppRepositoryDB repositoryDB = new AppRepositoryDB();
		String sql = repositoryDB.isRepoNameAvailable(repoNames, appId);

		//SqlArrayParam sqlArrayParam = new SqlArrayParam(repoNames.toArray(), "VARCHAR");

		List<Object> parameters = new ArrayList<>();
		parameters.addAll(repoNames);
		if(!StringFunctions.isNullOrWhitespace(appId)){
			parameters.add(appId);
		}
		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(sql).addParameters(parameters).build();

		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)){
			while(rs.next()){
				lstRepoNamesTaken.add(rs.getString(PortalDBEnum.APPLICATION_PLATFORM.repositoryName.name()));
			}
		}
		return lstRepoNamesTaken;
	}
}
