/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal.engine;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.common.vo.QueryVO;
import com.mwp.p.common.enums.PortalDBEnum.SORTORDERS;
import com.mwp.p.common.vo.SortOrderVO;
import com.mwp.p.dal.SortDB;

/**
 * This class give the sort order related data comes from different order
 * operations queries on sort order table.
 * 
 * @author root *
 */
public class SortingEngine {

	/*
	 * public methods.
	 */

	/**
	 * This method get details of sorting orders.
	 * 
	 * @return list of SortOrderVO
	 * @throws Exception
	 */
	public List<SortOrderVO> getAllSortOrder() throws SQLException {
		return mGetAllSortOrders();
	}

	/*
	 * private methods.
	 */
	private List<SortOrderVO> mGetAllSortOrders() throws SQLException {
		List<SortOrderVO> lstSortOrderVO = new ArrayList<>();
		SortDB sortorderDB = new SortDB();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
						.appendQuery(sortorderDB.getAllSortDetails()).build();
		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				lstSortOrderVO.add(setSortOrderVO(rs));
			}
		}

		return lstSortOrderVO;
	}

	private SortOrderVO setSortOrderVO(ResultSet rs) throws SQLException {
		SortOrderVO sortOrderVo = new SortOrderVO();
		sortOrderVo.setSortGroupName(rs.getString(SORTORDERS.sortGroupName.name()));
		sortOrderVo.setSortName(rs.getString(SORTORDERS.sortName.name()));
		sortOrderVo.setSortId(rs.getString(SORTORDERS.sortId.name()));
		return sortOrderVo;
	}
}
