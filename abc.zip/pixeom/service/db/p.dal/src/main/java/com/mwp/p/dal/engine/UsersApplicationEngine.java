/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.mwp.p.dal.engine;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.mwp.common.CredProvider;
import com.mwp.common.StringFunctions;
import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.common.enums.RedirectType;
import com.mwp.common.enums.Status;
import com.mwp.common.enums.StatusEnum.VERSION_STATUS;
import com.mwp.common.vo.ApplicationPlatformVO;
import com.mwp.common.vo.ApplicationVO;
import com.mwp.common.vo.DeviceNodeVO;
import com.mwp.common.vo.DeviceVO;
import com.mwp.common.vo.PortVO;
import com.mwp.common.vo.QueryVO;
import com.mwp.common.vo.VersionVO;
import com.mwp.p.common.Constants;
import com.mwp.p.common.PortalCommon;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.common.enums.PortalDBEnum.DEVICES_NODES_VIEW;
import com.mwp.p.common.vo.DeviceApplicationVO;
import com.mwp.p.common.vo.UserDeviceApplicationsVO;
import com.mwp.p.common.vo.UsersApplicationsVersionVO;
import com.mwp.p.dal.UsersApplicationDB;
import com.pa.crypto.StringEncryptionDecryption;

public class UsersApplicationEngine 
{
	/**
	 * List device of user. 
	 * @param userIds
	 * @return
	 * @throws Exception
	 */
	public List<DeviceVO> listDevice(String appid) throws SQLException {
		return mListDevice(appid);
	}

	/**
	 * List all application info, all application of users that exist on device
	 * @param pageNo
	 * @param pageSize
	 * @param userId
	 * @param deviceId
	 * @return
	 * @throws Exception
	 */
	public List<DeviceApplicationVO> listDeviceApplication(String deviceId) throws SQLException {
		return mListDeviceApplication(deviceId);
	}

	/**
	 return all devices of users and installed apps on the devices.
	 * @param userIds
	 * @return  HashMap<String,HashMap<String, UserDeviceApplicationsVO>> key: userid, value: HashMap<String, UserDeviceApplicationsVO>
	 * HashMap<String, UserDeviceApplicationsVO> key: device id, value: UserDeviceApplicationsVO object
	 * @throws Exception
	 */
	public  Map<String,HashMap<String, UserDeviceApplicationsVO>> listUsersDeviceApplication(List<String> userIds) throws SQLException {
		return mListUsersDeviceApplication(userIds);
	}

	/**
	 * List application of Users.
	 * @param projectId
	 * @param userId user id of user whuch came for listing request
	 * @return
	 * @throws Exception
	 */
	public List<ApplicationVO> listUsersApps(List<String> userIds) throws SQLException{
		return mListUsersApps(userIds);
	}

	public Map<String, HashMap<String, UsersApplicationsVersionVO>> listUsersApplicationVersion(List<String> userid) throws SQLException {
		return mlistUsersApplicationVersion(userid);
	}

	public List<VersionVO> listApplicationVersion(String appId) throws SQLException {
		return mListApplicationVersion(appId);
	}

	private List<VersionVO> mListApplicationVersion(String appId) throws SQLException {

		HashMap<String, VersionVO> hashVersion = new HashMap<>();

		String sql = new UsersApplicationDB().listApplicationVersion();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(appId).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {

				String appVersionId = rs.getString(PortalDBEnum.APPLICATION_VERSIONS.appVersionId.name());
				if (!StringFunctions.isNullOrWhitespace(appVersionId) && !hashVersion.containsKey(appVersionId)) {
					/*
					 * create ApplicationPlatformVO new object set values and
					 * ADD in hashAppPlatform.
					 */
					VersionVO versionVO = new VersionVO();
					/*
					 * appVersion and releaseNotes value get from joining ON
					 * table applicationversion. and it is which have status
					 * LIVE.
					 */
					versionVO.setVersionId(appVersionId);
					versionVO.setVersionNumber(rs.getString(PortalDBEnum.APPLICATION_VERSIONS.appVersion.name()));
					versionVO.setReleaseNote(rs.getString(PortalDBEnum.APPLICATION_VERSIONS.releaseNotes.name()));
					versionVO.setSize(rs.getLong(PortalDBEnum.APPLICATION_VERSIONS.size.name()));
					versionVO.setRedirectUrl(rs.getString(PortalDBEnum.APPLICATION_VERSIONS.redirectUrl.name()));
					versionVO
							.setRestRedirectUrl(rs.getString(PortalDBEnum.APPLICATION_VERSIONS.restRedirectUrl.name()));

					versionVO
							.setRedirectSection(rs.getString(PortalDBEnum.APPLICATION_VERSIONS.redirectSection.name()));
					versionVO.setRedirectType(
							RedirectType.GetEnum(rs.getInt(PortalDBEnum.APPLICATION_VERSIONS.redirectType.name())));
					versionVO.setComposeVersion(rs.getString(PortalDBEnum.APPLICATION_VERSIONS.composeVersion.name()));
					versionVO.setModifiedDate(rs.getTimestamp("versionModifiedDate").getTime());
					versionVO.setAppPlatformId(rs.getString("appPlatformIdVersion"));
					hashVersion.put(appVersionId, versionVO);
				}

				String appServicePortId = rs.getString(PortalDBEnum.APPLICATION_SERVICE_PORTS.appServicePortId.name());
				String portappVersionId = rs.getString(PortalDBEnum.APPLICATION_SERVICE_PORTS.appVersionId.name());
				if (!StringFunctions.isNullOrWhitespace(appServicePortId)
						&& hashVersion.containsKey(portappVersionId)) {
					/*
					 * create ApplicationPlatformVO new object set values and
					 * ADD in hashAppPlatform.
					 */
					PortVO port = new PortVO();
					port.setAppVersionId(portappVersionId);
					port.setInternalPort(rs.getInt(PortalDBEnum.APPLICATION_SERVICE_PORTS.internalPort.name()));
					port.setPort(Integer.valueOf(StringEncryptionDecryption.decrypt(
							rs.getString(PortalDBEnum.APPLICATION_SERVICE_PORTS.externalPort.name()),
							new CredProvider().getEcnKey())));
					port.setPortId(appServicePortId);

					hashVersion.get(portappVersionId).getPortlist().add(port);
				}
			}
		}
		return new ArrayList<>(hashVersion.values());
	}



	private List<DeviceApplicationVO> mListDeviceApplication(String deviceId) throws SQLException {

		List<DeviceApplicationVO> listDeviceApp = new ArrayList<>();
		String sql = new UsersApplicationDB().listDeviceApplication();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(deviceId).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {

				DeviceApplicationVO deviceAppVO = new DeviceApplicationVO();
				/*
				 * set basic applicationVO detail.
				 */
				deviceAppVO.setApplicationId(rs.getString(PortalDBEnum.APPLICATION.appId.name()));
				deviceAppVO.setAppTypeId(rs.getString(PortalDBEnum.APPLICATION.appTypeId.name()));
				deviceAppVO.setIcon(rs.getString(PortalDBEnum.APPLICATION.icon.name()));
				if (!StringFunctions.isNullOrWhitespace(deviceAppVO.getIcon())) {
					deviceAppVO.setIcon(PortalCommon.getInstance().createPublicUrl(deviceAppVO.getIcon(),
							Constants.UI_FOLDER_NAME));
				}
				deviceAppVO.setProjectId(rs.getString(PortalDBEnum.APPLICATION.projectId.name()));
				// deviceAppVO.setRepositoryName(rs.getString(PortalDBEnum.APPLICATION.repositoryName.name()));
				// //***pschange***
				deviceAppVO.setTitle(rs.getString(PortalDBEnum.APPLICATION.title.name()));
				deviceAppVO.setUserId(rs.getString(PortalDBEnum.APPLICATION.userId.name()));
				deviceAppVO.setWebAddress(rs.getString(PortalDBEnum.APPLICATION.webAddress.name()));
				deviceAppVO.setAppStatus(Status.GetEnum(rs.getInt(PortalDBEnum.APPLICATION.appStatus.name())));

				/**
				 * Added APPLICATION_VERSIONS joining to show version number in
				 * My Installed Apps - PS bug 548
				 */
				deviceAppVO.setVersionVO(new VersionEngine().setVersionObject(rs));

				// AKH_01, AKH_02
				/*
				 * set deviceId for UI so they use deviceId in getting appdetail
				 * and return deviceApplicationVO object.
				 */
				deviceAppVO.setDeviceId(rs.getString(PortalDBEnum.DEVICE_APPLICATIONS.deviceId.name()));
				deviceAppVO.setVerionId(rs.getString(PortalDBEnum.DEVICE_APPLICATIONS.appVersionId.name()));
				/*
				 * for show on UI device name.
				 */
				deviceAppVO.setDeviceName(rs.getString(PortalDBEnum.DEVICES.deviceName.name()));
				listDeviceApp.add(deviceAppVO);
			}
		}
		return listDeviceApp;
	}

	/**
	 * getting application info, all application which are exist on device.
	 * @param pageNo
	 * @param pageSize
	 * @param userId
	 * @param deviceId
	 * @return
	 */
	private Map<String, HashMap<String, UserDeviceApplicationsVO>> mListUsersDeviceApplication(List<String> useridlst)
			throws SQLException {

		String sql = new UsersApplicationDB().listUsersDeviceApplication(useridlst.size());

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameters(useridlst).build();

		HashMap<String, HashMap<String, UserDeviceApplicationsVO>> hashDeviceVOval = new HashMap<>();

		DevicesEngine deviceengin = new DevicesEngine();
		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				String deviceId = rs.getString(PortalDBEnum.DEVICES_NODES_VIEW.devices_deviceId.name());
				String userid = rs.getString(PortalDBEnum.DEVICES_NODES_VIEW.devices_userId.name());
				if (!hashDeviceVOval.containsKey(userid)) {
					HashMap<String, UserDeviceApplicationsVO> userdevice = new HashMap<>();
					hashDeviceVOval.put(userid, userdevice);
				}

				HashMap<String, String> hashNodeIds = new HashMap<>();

				if (hashDeviceVOval.get(userid).containsKey(deviceId)) {
					String nodeId = rs.getString(DEVICES_NODES_VIEW.nodes_nodeId.name());
					if (!hashNodeIds.containsKey(nodeId)) {
						DeviceNodeVO nodeVO = deviceengin.setNodeObjectForView(rs, true);
						hashDeviceVOval.get(userid).get(deviceId).getDevice().getNodes().add(nodeVO);
						hashNodeIds.put(nodeVO.getNodeId(), deviceId);
					}

				} else {
					DeviceVO deviceVO = deviceengin.setDeviceObject(rs, true, false);
					UserDeviceApplicationsVO userdevice = new UserDeviceApplicationsVO();
					userdevice.setDevice(deviceVO);
					hashDeviceVOval.get(userid).put(deviceVO.getDeviceId(), userdevice);
					String nodeId = rs.getString(DEVICES_NODES_VIEW.nodes_nodeId.name());
					hashNodeIds.put(nodeId, deviceId);
				}

				String appid = rs.getString(PortalDBEnum.APPLICATION.appId.name());

				if (StringFunctions.isNullOrWhitespace(appid)) {
					continue;
				}

				if (!hashDeviceVOval.get(userid).get(deviceId).getInstalledapps().stream()
						.anyMatch(t -> t.getApplicationId().equals(appid))) {
					DeviceApplicationVO deviceAppVO = new DeviceApplicationVO();
					/*
					 * set basic applicationVO detail.
					 */
					deviceAppVO.setApplicationId(rs.getString(PortalDBEnum.APPLICATION.appId.name()));
					deviceAppVO.setAppTypeId(rs.getString(PortalDBEnum.APPLICATION.appTypeId.name()));
					deviceAppVO.setIcon(rs.getString(PortalDBEnum.APPLICATION.icon.name()));
					if (!StringFunctions.isNullOrWhitespace(deviceAppVO.getIcon())) {
						deviceAppVO.setIcon(PortalCommon.getInstance().createPublicUrl(deviceAppVO.getIcon(),
								Constants.UI_FOLDER_NAME));
					}
					deviceAppVO.setProjectId(rs.getString(PortalDBEnum.APPLICATION.projectId.name()));
					// ***pschange***
					deviceAppVO.setTitle(rs.getString(PortalDBEnum.APPLICATION.title.name()));
					deviceAppVO.setUserId(rs.getString(PortalDBEnum.APPLICATION.userId.name()));
					deviceAppVO.setWebAddress(rs.getString(PortalDBEnum.APPLICATION.webAddress.name()));
					deviceAppVO.setAppStatus(Status.GetEnum(rs.getInt(PortalDBEnum.APPLICATION.appStatus.name())));
					deviceAppVO.setCreatedDate(rs.getTimestamp(PortalDBEnum.APPLICATION.createdDate.name()).getTime());
					deviceAppVO
							.setModifiedDate(rs.getTimestamp(PortalDBEnum.APPLICATION.modifiedDate.name()).getTime());

					/**
					 * Added APPLICATION_VERSIONS joining to show version number
					 * in My Installed Apps - PS bug 548
					 */
					deviceAppVO.setVersionVO(new VersionEngine().setVersionObject(rs));

					// AKH_01, AKH_02
					/*
					 * set deviceId for UI so they use deviceId in getting
					 * appdetail and return deviceApplicationVO object.
					 */
					deviceAppVO.setDeviceId(rs.getString(PortalDBEnum.DEVICE_APPLICATIONS.deviceId.name()));
					deviceAppVO.setVerionId(rs.getString(PortalDBEnum.DEVICE_APPLICATIONS.appVersionId.name()));
					/*
					 * for show on UI device name.
					 */
					deviceAppVO.setDeviceName(rs.getString(PortalDBEnum.DEVICES.deviceName.name()));

					hashDeviceVOval.get(userid).get(deviceId).getInstalledapps().add(deviceAppVO);
				}

			}
		}
		return hashDeviceVOval;
	}

	private List<DeviceVO> mListDevice(String appid) throws SQLException {
		List<DeviceVO> listDevice = new ArrayList<>();
		String sql = new UsersApplicationDB().listDevice();
		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(appid).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			listDevice = new DevicesEngine().setDeviceObjectList(rs, true, false, false, false, false, null);
		}
		return listDevice;
	}


	private List<ApplicationVO> mListUsersApps(List<String> userId) throws SQLException {
		List<ApplicationVO> listApp = new ArrayList<>();
		UsersApplicationDB applicationsDB = new UsersApplicationDB();

		String sql = applicationsDB.listUserApp(userId.size());

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameters(userId).build();

		HashMap<String, ApplicationVO> hashApplication = new HashMap<>();
		List<String> listAppPlatform = new ArrayList<>();
		String appId = "";
		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {

				appId = rs.getString(PortalDBEnum.APPLICATION.appId.name());
				if (!StringFunctions.isNullOrWhitespace(appId) && !hashApplication.containsKey(appId)) {
					hashApplication.put(appId, new ApplicationsEngine().setApplicationObject(rs));
				}

				String appPlatformId = rs.getString(PortalDBEnum.APPLICATION_PLATFORM.appPlatformId.name());
				if (!listAppPlatform.contains(appPlatformId)) {
					/*
					 * create ApplicationPlatformVO new object set values and
					 * ADD in hashAppPlatform.
					 */
					ApplicationPlatformVO platformVO = new ApplicationPlatformVO();
					platformVO.setAppId(rs.getString(PortalDBEnum.APPLICATION.appId.name()));
					platformVO.setAppPlatformId(appPlatformId);
					platformVO.setPlatformId(rs.getString(PortalDBEnum.APPLICATION_PLATFORM.platformId.name()));
					platformVO.setRepositoryName(rs.getString(PortalDBEnum.APPLICATION_PLATFORM.repositoryName.name()));
					hashApplication.get(appId).getPlatFormList().add(platformVO);
				}
			}
		}
		listApp.addAll(hashApplication.values());
		return listApp;
	}




	/**
	 * * Get application Version to appId,
	 * @param appId
	 * @return
	 * @throws SQLException
	 */
	private Map<String, HashMap<String, UsersApplicationsVersionVO>> mlistUsersApplicationVersion(
			List<String> useridlst) throws SQLException {

		HashMap<String, VersionVO> hashVersion = new HashMap<>();
		String sql = new UsersApplicationDB().listUsersApplicationVersion(useridlst.size());

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameters(useridlst).build();

		String encKey = new CredProvider().getEcnKey();
		HashMap<String, HashMap<String, UsersApplicationsVersionVO>> returvalue = new HashMap<>();
		List<String> listAppPlatform = new ArrayList<>();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {

				String appId = rs.getString(PortalDBEnum.APPLICATION.appId.name());
				String userid = rs.getString(PortalDBEnum.APPLICATION.userId.name());

				if (!returvalue.containsKey(userid)) {
					HashMap<String, UsersApplicationsVersionVO> appversion = new HashMap<>();
					returvalue.put(userid, appversion);
				}

				if (!StringFunctions.isNullOrWhitespace(appId) && !returvalue.get(userid).containsKey(appId)) {
					ApplicationVO userapps = new UsersApplicationsVersionVO();
					userapps = new ApplicationsEngine().setApplicationObject(rs);
					returvalue.get(userid).put(appId, (UsersApplicationsVersionVO) userapps);
				}

				String appPlatformId = rs.getString(PortalDBEnum.APPLICATION_PLATFORM.appPlatformId.name());
				if (!listAppPlatform.contains(appPlatformId)) {
					/*
					 * create ApplicationPlatformVO new object set values and
					 * ADD in hashAppPlatform.
					 */
					ApplicationPlatformVO platformVO = new ApplicationPlatformVO();
					platformVO.setAppId(rs.getString(PortalDBEnum.APPLICATION.appId.name()));
					platformVO.setAppPlatformId(appPlatformId);
					platformVO.setPlatformId(rs.getString(PortalDBEnum.APPLICATION_PLATFORM.platformId.name()));
					platformVO.setRepositoryName(rs.getString(PortalDBEnum.APPLICATION_PLATFORM.repositoryName.name()));
					returvalue.get(userid).get(appId).getPlatFormList().add(platformVO);
					listAppPlatform.add(appPlatformId);
				}

				String appVersionId = rs.getString(PortalDBEnum.APPLICATION_VERSIONS.appVersionId.name());
				if (!StringFunctions.isNullOrWhitespace(appVersionId) && !hashVersion.containsKey(appVersionId)) {
					/*
					 * create ApplicationPlatformVO new object set values and
					 * ADD in hashAppPlatform.
					 */
					VersionVO versionVO = new VersionVO();
					/*
					 * appVersion and releaseNotes value get from joining ON
					 * table applicationversion. and it is which have status
					 * LIVE.
					 */
					versionVO.setVersionId(appVersionId);
					versionVO.setVersionNumber(rs.getString(PortalDBEnum.APPLICATION_VERSIONS.appVersion.name()));
					versionVO.setReleaseNote(rs.getString(PortalDBEnum.APPLICATION_VERSIONS.releaseNotes.name()));
					versionVO.setSize(rs.getLong(PortalDBEnum.APPLICATION_VERSIONS.size.name()));
					versionVO.setStatus(
							VERSION_STATUS.GetEnum(rs.getInt(PortalDBEnum.APPLICATION_VERSIONS.versionStatus.name())));
					versionVO.setRedirectUrl(rs.getString(PortalDBEnum.APPLICATION_VERSIONS.redirectUrl.name()));
					versionVO
							.setRestRedirectUrl(rs.getString(PortalDBEnum.APPLICATION_VERSIONS.restRedirectUrl.name()));

					versionVO
							.setRedirectSection(rs.getString(PortalDBEnum.APPLICATION_VERSIONS.redirectSection.name()));
					versionVO.setRedirectType(
							RedirectType.GetEnum(rs.getInt(PortalDBEnum.APPLICATION_VERSIONS.redirectType.name())));
					versionVO.setComposeVersion(rs.getString(PortalDBEnum.APPLICATION_VERSIONS.composeVersion.name()));
					versionVO.setModifiedDate(rs.getTimestamp("versionModifiedDate").getTime());
					versionVO.setAppPlatformId(rs.getString("appPlatformIdVersion"));
					versionVO.setCreatedDate(rs.getTimestamp("versioncreatedDate").getTime());
					hashVersion.put(appVersionId, versionVO);
					returvalue.get(userid).get(appId).getVersions().add(versionVO);
				}

				String appServicePortId = rs.getString(PortalDBEnum.APPLICATION_SERVICE_PORTS.appServicePortId.name());
				String portappVersionId = rs.getString(PortalDBEnum.APPLICATION_SERVICE_PORTS.appVersionId.name());
				if (!StringFunctions.isNullOrWhitespace(appServicePortId)
						&& hashVersion.containsKey(portappVersionId)) {
					/*
					 * create ApplicationPlatformVO new object set values and
					 * ADD in hashAppPlatform.
					 */
					PortVO port = new PortVO();
					port.setAppVersionId(portappVersionId);
					port.setInternalPort(rs.getInt(PortalDBEnum.APPLICATION_SERVICE_PORTS.internalPort.name()));
					port.setPort(Integer.valueOf(StringEncryptionDecryption.decrypt(
							rs.getString(PortalDBEnum.APPLICATION_SERVICE_PORTS.externalPort.name()), encKey)));
					port.setPortId(appServicePortId);

					hashVersion.get(portappVersionId).getPortlist().add(port);
				}

			}
		}

		return returvalue;
	}
}
