/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal.engine;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

import com.mwp.common.Common;
import com.mwp.common.CredProvider;
import com.mwp.common.StringFunctions;
import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.common.enums.Status;
import com.mwp.common.vo.ApplicationPlatformVO;
import com.mwp.common.vo.ApplicationVO;
import com.mwp.common.vo.QueryVO;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.common.vo.CompanyInfoVO;
import com.mwp.p.common.vo.ProjectVO;
import com.mwp.p.dal.ApplicationsDB;
import com.mwp.p.dal.ProjectsApplicationDB;
import com.mwp.p.dal.ProjectsCompanyDB;
import com.pa.crypto.StringEncryptionDecryption;

/**
 * This class manages projects, Add update delete 
 *
 */
public class ProjectsEngine {

	/**
	 * Add project with company information in project and company db.
	 * @param projectVO
	 * @return
	 * @throws Exception
	 */
	public ProjectVO addProject(ProjectVO projectVO) throws SQLException{
		return mAddProject(projectVO);
	}

	/**
	 * List of project which create by specific user which 'userId' given in param.
	 * @param userId
	 * @return
	 * @throws Exception
	 */
	public List<ProjectVO> listProject(String userId) throws SQLException{
		return mListProject(userId);
	}

	/**
	 * check whether project exists for company name
	 * @param companyId
	 * @return
	 * @throws Exception
	 */
	public boolean projectExits(String companyId) throws SQLException{
		return mProjectExits(companyId);
	}

	/**
	 * List of project  which has status 'status' given in param.
	 * @param status
	 * @return
	 * @throws Exception
	 */
	public List<ProjectVO> listProjectByStaus(Status status) throws SQLException{
		return mListProjectByStatus(status);
	}

	/**
	 * Get detail of project(project info with company information).
	 * @param projectId
	 * @return
	 * @throws Exception
	 */
	public ProjectVO getProjectDetail(String projectId) throws SQLException{
		return mGetProjectDetail(projectId);
	}

	/**
	 * update project info with company info.
	 * @param projectVO
	 * @return ProjectVO updated object 
	 * @throws Exception
	 */
	public ProjectVO updateProject(ProjectVO projectVO) throws SQLException{
		return mUpdateProject(projectVO);
	}

	/**
	 * delete project change project status to DELETED with specific projectId.
	 * @param projectId
	 * @param userId user id of user which came for delete request
	 * @throws Exception
	 */
	public void deleteProject(String projectId,String userId) throws SQLException{
		mDeleteProject(projectId,userId);
	}

	/**
	 * Get number of projects of particular user.
	 * @param userId
	 * @throws Exception
	 */
	public int projectCount(String userId) throws SQLException{
		return mProjectCount(userId);
	}


	/**
	 * List application of project.
	 * @param projectId
	 * @param userId user id of user whuch came for listing request
	 * @return
	 * @throws Exception
	 */
	public List<ApplicationVO> listProjectApps(String projectId,String userId) throws SQLException{
		return mListProjectApps(projectId,userId);
	}

	/**
	 * List application of project.
	 * @param projectId
	 * @return
	 * @throws Exception
	 */

	public List<ApplicationVO> listAppsOfDelete(String projectId) throws SQLException{
		return mListAppsOfDelete(projectId);
	}

	/**
	 * delete project from database with specific projectId.
	 * @param projectId
	 * @throws Exception
	 */
	public List<String> deleteProjectFromDb(){
		return mDeleteProjectFromDb();
	}

	private ProjectVO mAddProject(ProjectVO projectVO) throws SQLException {
		projectVO.setProjectId(Common.getRandomId());

		ProjectsCompanyDB projDB = new ProjectsCompanyDB();
		List<String> queries = projDB.addProject();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
						.appendQuery(queries.get(0)).addParameter(projectVO.getProjectId())
						.addParameter(projectVO.getCompanyInfo().getCompanyId()).addParameter(projectVO.getUserId())
						.addParameter(projectVO.getName()).addParameter(projectVO.getDescription())
						.addParameter(projectVO.getIcon()).addParameter(projectVO.getStatus().ordinal()).build();

		PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
		return projectVO;
	}

	private boolean mProjectExits(String companyId) throws SQLException {
		ProjectsCompanyDB projDB = new ProjectsCompanyDB();
		String sql = projDB.projectExits();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(companyId).addParameter(Status.DELETED.ordinal()).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				return true;
			}
		}
		return false;
	}

	private List<ProjectVO> mListProject(String userId) throws SQLException {
		List<ProjectVO> listProject = new ArrayList<>();
		ProjectsCompanyDB projDB = new ProjectsCompanyDB();

		String sql = projDB.listProject();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(userId).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				listProject.add(setProjectObject(rs));
			}
		}
		return listProject;
	}

	private List<ProjectVO> mListProjectByStatus(Status status) throws SQLException {
		List<ProjectVO> listProject = new ArrayList<>();
		ProjectsCompanyDB projDB = new ProjectsCompanyDB();

		String sql = projDB.listProjectByStatus();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(status.ordinal()).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				listProject.add(setProjectObject(rs));
			}
		}
		return listProject;
	}

	private ProjectVO mGetProjectDetail(String projectId) throws SQLException {
		ProjectVO projectVO = null;
		ProjectsCompanyDB projDB = new ProjectsCompanyDB();

		String sql = projDB.getProjectDetail();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(projectId).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				projectVO = setProjectObjectWithCompanyInfo(rs);
			}
		}
		return projectVO;
	}
	
	private ProjectVO mUpdateProject(ProjectVO projectVO) throws SQLException{
		ProjectsCompanyDB projDB = new ProjectsCompanyDB();
		
		List<String> queries = projDB.updateProject();
		
		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(queries.get(0))
						.addParameter(projectVO.getName())
						.addParameter(projectVO.getDescription())
						.addParameter(projectVO.getIcon())
						.addParameter(projectVO.getStatus().ordinal())
						.addParameter(projectVO.getCompanyInfo().getCompanyId())
						.addParameter(projectVO.getProjectId())
						.build();
		
		PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
		return projectVO;
	}

	private void mDeleteProject(String projectId,String userId) throws SQLException{
		ProjectsApplicationDB projectsApplicationDB = new ProjectsApplicationDB();
		List<QueryVO> queryVOs = new LinkedList<>();
		
		List<String> queries = projectsApplicationDB.deletetProject();
		
		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(queries.get(0))
						.addParameter(projectId)
						.addParameter(userId)
						.build();
		queryVOs.add(queryVO);
		
		queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(queries.get(1))
						.addParameter(projectId)
						.addParameter(userId)
						.build();
		queryVOs.add(queryVO);
		
		PortalDatabaseEngine.getInstance().getConnection().executeUpdatesInTransaction(queryVOs);
	}

	private List<ApplicationVO> mListProjectApps(String projectId, String userId) throws SQLException {
		List<ApplicationVO> listApp = new ArrayList<>();
		ApplicationsDB applicationsDB = new ApplicationsDB();
		HashMap<String, ApplicationVO> hashApplication = new HashMap<>();
		List<String> listAppPlatform = new ArrayList<>();

		String sql = applicationsDB.listProjectApp();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(projectId).addParameter(userId).build();

		String appId = "";
		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {

				appId = rs.getString(PortalDBEnum.APPLICATION.appId.name());
				if (!StringFunctions.isNullOrWhitespace(appId) && !hashApplication.containsKey(appId)) {
					hashApplication.put(appId, new ApplicationsEngine().setApplicationObject(rs));
				}

				String appPlatformId = rs.getString(PortalDBEnum.APPLICATION_PLATFORM.appPlatformId.name());
				if (!listAppPlatform.contains(appPlatformId)) {
					/*
					 * create ApplicationPlatformVO new object set values and
					 * ADD in hashAppPlatform.
					 */
					ApplicationPlatformVO platformVO = new ApplicationPlatformVO();
					platformVO.setAppId(rs.getString(PortalDBEnum.APPLICATION.appId.name()));
					platformVO.setAppPlatformId(appPlatformId);
					platformVO.setPlatformId(rs.getString(PortalDBEnum.APPLICATION_PLATFORM.platformId.name()));
					platformVO.setRepositoryName(rs.getString(PortalDBEnum.APPLICATION_PLATFORM.repositoryName.name()));
					hashApplication.get(appId).getPlatFormList().add(platformVO);
				}
			}
		}
		
		listApp.addAll(hashApplication.values());
		return listApp;
	}

	private int mProjectCount(String userId) throws SQLException {
		ProjectsCompanyDB projDB = new ProjectsCompanyDB();
		String sql = projDB.projectCount();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(userId).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			if (rs.next()) {
				return rs.getInt("ROWCOUNT");
			}
		}
		return 0;
	}

	/**
	 * set property of project.
	 * @param rs
	 * @return
	 * @throws Exception
	 */
	private ProjectVO setProjectObject(ResultSet rs) throws SQLException
	{
		ProjectVO projectVO = new ProjectVO();

		projectVO.setUserId(rs.getString(PortalDBEnum.PROJECT.userId.name()));
		projectVO.setProjectId(rs.getString(PortalDBEnum.PROJECT.projectId.name()));
		projectVO.setName(rs.getString(PortalDBEnum.PROJECT.name.name()));
		projectVO.setDescription(rs.getString(PortalDBEnum.PROJECT.description.name()));
		projectVO.setStatus(Status.GetEnum(rs.getInt(PortalDBEnum.PROJECT.projectStatus.name())));
		projectVO.setIcon(rs.getString(PortalDBEnum.PROJECT.icon.name()));
		projectVO.setCreatedDate(rs.getTimestamp(PortalDBEnum.PROJECT.createdDate.name()).getTime());
		projectVO.setModifiedDate(rs.getTimestamp(PortalDBEnum.PROJECT.modifiedDate.name()).getTime());
		return projectVO;
	}

	/**
	 * set property of project with company info.
	 * @param rs
	 * @return
	 * @throws SQLException 
	 * @throws Exception
	 */
	private ProjectVO setProjectObjectWithCompanyInfo(ResultSet rs) throws SQLException 
	{
		ProjectVO projectVO = setProjectObject(rs);
		String encKey = new CredProvider().getEcnKey();
		
		CompanyInfoVO companyInfo = new CompanyInfoVO();
		companyInfo.setCompanyId(rs.getString(PortalDBEnum.COMPANY.companyId.name()));
		companyInfo.setAddress(StringEncryptionDecryption.decrypt(rs.getString(PortalDBEnum.COMPANY.address.name()), encKey));
		companyInfo.setName(StringEncryptionDecryption.decrypt(rs.getString(PortalDBEnum.COMPANY.companyName.name()), encKey));
		companyInfo.setWebAddress(StringEncryptionDecryption.decrypt(rs.getString(PortalDBEnum.COMPANY.webAddress.name()), encKey));
		companyInfo.setPostalCode(StringEncryptionDecryption.decrypt(rs.getString(PortalDBEnum.COMPANY.postalCode.name()), encKey));
		companyInfo.setCity(StringEncryptionDecryption.decrypt(rs.getString(PortalDBEnum.COMPANY.city.name()), encKey));
		companyInfo.setState(StringEncryptionDecryption.decrypt(rs.getString(PortalDBEnum.COMPANY.state.name()), encKey));
		companyInfo.setCountry(StringEncryptionDecryption.decrypt(rs.getString(PortalDBEnum.COMPANY.country.name()), encKey));
		companyInfo.setEmail(StringEncryptionDecryption.decrypt(rs.getString(PortalDBEnum.COMPANY.email.name()), encKey));
		companyInfo.setPhone(StringEncryptionDecryption.decrypt(rs.getString(PortalDBEnum.COMPANY.phone.name()), encKey));
		projectVO.setCompanyInfo(companyInfo);
		return projectVO;
	}

	private List<ApplicationVO> mListAppsOfDelete(String projectId) throws SQLException
	{
		List<ApplicationVO> listApp = new ArrayList<>();
		ApplicationsDB applicationsDB = new ApplicationsDB();
		HashMap<String, ApplicationVO> hashApplication = new HashMap<>();
		List<String> listAppPlatform = new ArrayList<>();

		String sql = applicationsDB.listofAppsOfDeleteProject(projectId);

		String appId = "";
		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(projectId).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				appId = rs.getString(PortalDBEnum.APPLICATION.appId.name());
				if (!StringFunctions.isNullOrWhitespace(appId) && !hashApplication.containsKey(appId)) {
					hashApplication.put(appId, new ApplicationsEngine().setApplicationObject(rs));
				}

				String appPlatformId = rs.getString(PortalDBEnum.APPLICATION_PLATFORM.appPlatformId.name());
				if (!listAppPlatform.contains(appPlatformId)) {
					/*
					 * create ApplicationPlatformVO new object set values and
					 * ADD in hashAppPlatform.
					 */
					ApplicationPlatformVO platformVO = new ApplicationPlatformVO();
					platformVO.setAppId(rs.getString(PortalDBEnum.APPLICATION.appId.name()));
					platformVO.setAppPlatformId(appPlatformId);
					platformVO.setPlatformId(rs.getString(PortalDBEnum.APPLICATION_PLATFORM.platformId.name()));
					platformVO.setRepositoryName(rs.getString(PortalDBEnum.APPLICATION_PLATFORM.repositoryName.name()));
					hashApplication.get(appId).getPlatFormList().add(platformVO);
				}
			}
		}
		listApp.addAll(hashApplication.values());
		return listApp;
	}

	private List<String> mDeleteProjectFromDb()
	{
		ProjectsCompanyDB projectsCompanyDB = new ProjectsCompanyDB();
		return projectsCompanyDB.deleteProjectFromDb();
	}
}