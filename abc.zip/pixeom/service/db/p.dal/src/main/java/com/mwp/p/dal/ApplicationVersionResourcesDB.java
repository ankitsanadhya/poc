/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal;

/**
 * Each application have resources, other than yamls
 * like nginx configs, certificates, build files, env files...
 * This kind of resources are saved on file system and the mapping 
 * with app is stored in ApplicationResources table.
 * 
 * The mapping between app version and the resource is kept in this file.
 * 
 */
public class ApplicationVersionResourcesDB {

	/*private IConnection dbCon = null;
	public ApplicationVersionResourcesDB() {
		dbCon = PortalDatabaseEngine.getInstance().getConnection();
	}

	public String get(String applicationId) {
		return mGet(applicationId);
	}

	public String get(String applicationId, String versionId) {
		return mGet(applicationId, versionId);
	}

	public String get(String applicationId, String versionId, String resourceId) {
		return mGet(applicationId, versionId, resourceId);
	}

	public String get(String applicationId, String versionId, List<String> resourceIds) {
		return mGet(applicationId, versionId, resourceIds);
	}

	public String add(String appId, String appVersionId, String resourceId) {
		return mAdd(appId, appVersionId, resourceId);
	}

	public List<String> add(String appId, String appVersionId, List<String> resourceIds) {
		return mAdd(appId, appVersionId, resourceIds);
	}

	public String delete(String applicationId, String versionId) {
		return mDelete(applicationId, versionId);
	}

	private String mGet(String applicationId) {
		return new StringBuilder("SELECT ar.*, avr.").append(PortalDBEnum.APPLICATION_VERSION_RESOURCES.appVersionId) 
				.append(" FROM ").append(PortalDBEnum.TABLE_NAMES.applicationVersionResources).append(" AS avr ") 
				.append(" LEFT JOIN ").append(PortalDBEnum.TABLE_NAMES.applicationResources).append(" AS ar ")
				.append(" ON ")
				.append(" ar.").append(PortalDBEnum.APPLICATION_RESOURCES.resourceId).append(" = avr.").append(PortalDBEnum.APPLICATION_VERSION_RESOURCES.resourceId)
				.append(" WHERE ") 
				.append(" avr.").append(PortalDBEnum.APPLICATION_VERSION_RESOURCES.appId).append(" = ").append(dbCon.formatString(applicationId)).toString();
	}

	private String mGet(String applicationId, String versionId) {
		return new StringBuilder("SELECT ar.*, avr.").append(PortalDBEnum.APPLICATION_VERSION_RESOURCES.appVersionId) 
				.append(" FROM ").append(PortalDBEnum.TABLE_NAMES.applicationVersionResources).append(" AS avr ") 
				.append(" LEFT JOIN ").append(PortalDBEnum.TABLE_NAMES.applicationResources).append(" AS ar ")
				.append(" ON ")
				.append(" ar.").append(PortalDBEnum.APPLICATION_RESOURCES.resourceId).append(" = avr.").append(PortalDBEnum.APPLICATION_VERSION_RESOURCES.resourceId)
				.append(" WHERE ") 
				.append(" avr.").append(PortalDBEnum.APPLICATION_VERSION_RESOURCES.appId).append(" = ").append(dbCon.formatString(applicationId))
				.append(" AND ") 
				.append(" avr.").append(PortalDBEnum.APPLICATION_VERSION_RESOURCES.appVersionId).append(" = ").append(dbCon.formatString(versionId)).toString();
	}

	private String mGet(String applicationId, String versionId, String resourceId) {
		return new StringBuilder("SELECT ar.*, avr.").append(PortalDBEnum.APPLICATION_VERSION_RESOURCES.appVersionId) 
				.append(" FROM ").append(PortalDBEnum.TABLE_NAMES.applicationVersionResources).append(" AS avr ") 
				.append(" LEFT JOIN ").append(PortalDBEnum.TABLE_NAMES.applicationResources).append(" AS ar ")
				.append(" ON ")
				.append(" ar.").append(PortalDBEnum.APPLICATION_RESOURCES.resourceId).append(" = avr.").append(PortalDBEnum.APPLICATION_VERSION_RESOURCES.resourceId)
				.append(" WHERE ") 
				.append(" avr.").append(PortalDBEnum.APPLICATION_VERSION_RESOURCES.appId).append(" = ").append(dbCon.formatString(applicationId))
				.append(" AND ") 
				.append(" avr.").append(PortalDBEnum.APPLICATION_VERSION_RESOURCES.appVersionId).append(" = ").append(dbCon.formatString(versionId))
				.append(" AND ") 
				.append(" avr.").append(PortalDBEnum.APPLICATION_VERSION_RESOURCES.resourceId).append(" = ").append(dbCon.formatString(resourceId)).toString();
	}

	private String mGet(String applicationId, String versionId, List<String> resourceIds) {
		return new StringBuilder("SELECT ar.*, avr.").append(PortalDBEnum.APPLICATION_VERSION_RESOURCES.appVersionId) 
				.append(" FROM ").append(PortalDBEnum.TABLE_NAMES.applicationVersionResources).append(" AS avr ") 
				.append(" LEFT JOIN ").append(PortalDBEnum.TABLE_NAMES.applicationResources).append(" AS ar ")
				.append(" ON ")
				.append(" ar.").append(PortalDBEnum.APPLICATION_RESOURCES.resourceId).append(" = avr.").append(PortalDBEnum.APPLICATION_VERSION_RESOURCES.resourceId)
				.append(" WHERE ") 
				.append(" avr.").append(PortalDBEnum.APPLICATION_VERSION_RESOURCES.appId).append(" = ").append(dbCon.formatString(applicationId))
				.append(" AND ") 
				.append(" avr.").append(PortalDBEnum.APPLICATION_VERSION_RESOURCES.appVersionId).append(" = ").append(dbCon.formatString(versionId))
				.append(" AND ") 
				.append(" avr.").append(PortalDBEnum.APPLICATION_VERSION_RESOURCES.resourceId).append(" IN (").append(dbCon.formatStringForIn(resourceIds)).append(")").toString();
	}

	private String mAdd(String appId, String appVersionId, String resourceId) {
		return new StringBuilder("INSERT INTO ").append(PortalDBEnum.TABLE_NAMES.applicationVersionResources) 
				.append(" VALUES (")
				.append(dbCon.formatString(resourceId)).append(", ")
				.append(dbCon.formatString(appId)).append(", ")
				.append(dbCon.formatString(appVersionId)).append(", ")
				.append("NOW(), NOW())").toString();
	}

	private List<String> mAdd(String appId, String appVersionId, List<String> resourceIds) {
		List<String> sql = new ArrayList<String>();

		for (String resourceId : resourceIds) {
			sql.add(new StringBuilder("INSERT INTO ").append(PortalDBEnum.TABLE_NAMES.applicationVersionResources) 
					.append(" (")
					.append(PortalDBEnum.APPLICATION_VERSION_RESOURCES.resourceId).append(", ")
					.append(PortalDBEnum.APPLICATION_VERSION_RESOURCES.appId).append(", ")
					.append(PortalDBEnum.APPLICATION_VERSION_RESOURCES.appVersionId).append(", ")
					.append(PortalDBEnum.APPLICATION_VERSION_RESOURCES.createdDate).append(", ")
					.append(PortalDBEnum.APPLICATION_VERSION_RESOURCES.modifiedDate).append(" ")
					.append(") VALUES (")
					.append(dbCon.formatString(resourceId)).append(", ")
					.append(dbCon.formatString(appId)).append(", ")
					.append(dbCon.formatString(appVersionId)).append(", ")
					.append("NOW(), NOW())").toString());
		}

		return sql;
	}

	private String mDelete(String applicationId, String versionId) {
		return new StringBuilder("DELETE FROM ").append(PortalDBEnum.TABLE_NAMES.applicationVersionResources) 
				.append(" WHERE ")
				.append(PortalDBEnum.APPLICATION_VERSION_RESOURCES.appId).append(" = ").append(dbCon.formatString(applicationId))
				.append(" AND ")
				.append(PortalDBEnum.APPLICATION_VERSION_RESOURCES.appVersionId).append(" = ").append(dbCon.formatString(versionId)).toString();
	}*/
}