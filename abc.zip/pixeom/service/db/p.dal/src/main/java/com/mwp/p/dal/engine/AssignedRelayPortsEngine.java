/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal.engine;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.common.vo.QueryVO;
import com.mwp.logger.PALogger;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.common.enums.PortalDBEnum.ASSIGNED_RELAY_PORTS;
import com.mwp.p.common.vo.AssignedRelayPortsVO;
import com.mwp.p.dal.AssignedRelayPortsDB;

/**
 * This class executes the queries related to table {@link ASSIGNED_RELAY_PORTS}
 *
 */
public class AssignedRelayPortsEngine {

	/**
	 * Get maximum of relay ports PortSegment
	 * @param relayServerId
	 * @return
	 * @throws SQLException
	 */
	public int getMaxRelayPort(String relayServerId) throws SQLException{
		return mGetMaxRelayPort(relayServerId);
	}

	/**
	 * Delete assigned  port of a device  
	 * @param deviceId
	 * @throws SQLException throw exception "Unable to delete deviceAssignedPorts, please try again." if device id not found 
	 */
	public void deleteDeviceAssignedPorts(String deviceId) throws SQLException {
		mDeleteDeviceAssignedPorts(deviceId);

	}

	/**
	 * Get all available ports for relay server id 
	 * @param relayServerId
	 * @return  ArrayList<AssignedRelayPortsVO>
	 * @throws SQLException
	 */
	public List<AssignedRelayPortsVO> getAvailablePorts(String relayServerId) throws SQLException {
		return mGetAvailablePorts(relayServerId);
	}

	/**
	 * Get assigned relay ports of device id.
	 * @param deviceId 
	 * @return AssignedRelayPortsVO object
	 * @throws SQLException
	 */
	public AssignedRelayPortsVO getAssignedRelayPortsVO(String deviceId) throws SQLException {	
		return mGetAssignedRelayPortsVO(deviceId);
	}

	/**
	 * Add assigned  relay port for device 
	 * @param deviceId
	 * @param relayServerID
	 * @param portSegmentStart
	 * @throws SQLException
	 */
	public void addAssignedRelayPorts(String deviceId, String relayServerID, int portSegmentStart) throws SQLException {
		mAddAssignedRelayPorts(deviceId, relayServerID, portSegmentStart);
	}

	/**
	 * Get assigned relay port of a device id with relayserce ID
	 * @param deviceId
	 * @param relayServerID
	 * @return
	 * @throws SQLException
	 */
	public AssignedRelayPortsVO getAssignedRelayPortsVO(String deviceId, String relayServerID) throws SQLException {
		return mGetAssignedRelayPortsVO(deviceId, relayServerID);
	}

	/**
	 * Update status of relay server port to 2 for device id.
	 * @param deviceId
	 * @throws SQLException
	 */
	public void updateAssignedPortsStatus(String deviceId) throws SQLException {
		mUpdateAssignedPortsStatus(deviceId);
	}

	/**
	 * Delete all existing relay ports with device id and then update and set device id where device id is macaddress
	 * @param macAddress
	 * @param deviceId
	 * @return
	 */
	public Map<String, String> updateAssignMacdevice(String macAddress, String deviceId) {
		HashMap<String, String> hashresult  = new HashMap<>();
		try{
			deleteDeviceAssignedPorts(deviceId);
		}catch(Exception ex)
		{
			PALogger.ERROR(ex);
		}
		try{
			PALogger.INFO("===== Update deviceid from assignedrelayports ===="+ macAddress +"== to == "+deviceId);

			QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
					.appendQuery(new AssignedRelayPortsDB().updateAssignMacdevice())
					.addParameter(deviceId)
					.addParameter(macAddress).build();
		
			PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
			hashresult.put("Status", "Success");

		}catch(Exception ex){
			hashresult.put("Status", "Failure");
			hashresult.put("ErrorMessage", "Unable to update assignedrelayports, please try again.");
		}
		return hashresult;
	}

	private void mUpdateAssignedPortsStatus(String deviceId) throws SQLException {
	
		QueryVO updateAssignedPortsStatusQueryVO =  new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new AssignedRelayPortsDB().updateAssignedPortsStatus()).addParameter("2").addParameter(deviceId).build();
		
		PortalDatabaseEngine.getInstance().getConnection().executeUpdate(updateAssignedPortsStatusQueryVO);
	}

	private AssignedRelayPortsVO mGetAssignedRelayPortsVO(String deviceId, String relayServerID) throws SQLException {
		AssignedRelayPortsVO assRelayPorts = null;
	
		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new AssignedRelayPortsDB().getAssignedRelayPortsVO())
				.addParameter(relayServerID)
				.addParameter(deviceId)
				.build();
		
		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)){
			while (rs.next()){
				assRelayPorts = new AssignedRelayPortsVO();
				assRelayPorts.setdModified(rs.getTimestamp(PortalDBEnum.ASSIGNED_RELAY_PORTS.dModified.name()).getTime());
				assRelayPorts.setnPortSegmentStart(rs.getInt(PortalDBEnum.ASSIGNED_RELAY_PORTS.nPortSegmentStart.name()));
				assRelayPorts.setnStatus(rs.getInt(PortalDBEnum.ASSIGNED_RELAY_PORTS.nStatus.name()));
				assRelayPorts.setsDeviceID(rs.getString(PortalDBEnum.ASSIGNED_RELAY_PORTS.sDeviceID.name()));
				assRelayPorts.setsRelayServerID(rs.getString(PortalDBEnum.ASSIGNED_RELAY_PORTS.sRelayServerID.name()));
			}
		}
		return assRelayPorts;
	}

	private void mAddAssignedRelayPorts(String deviceId, String relayServerID, int portSegmentStart) throws SQLException {
		
		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new AssignedRelayPortsDB().addAssignedRelayPorts())
				.addParameter(deviceId)
				.addParameter(relayServerID)
				.addParameter(portSegmentStart)
				.addParameter("1")
				//On duplicate key update
				.addParameter(relayServerID)
				.addParameter(portSegmentStart)
				.addParameter("1")
				.build();
		
		int addCount = PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
		if(addCount == 0){
			throw new SQLException("Unable to add AssignedRelayPorts, please try again.");
		}
	}

	private AssignedRelayPortsVO mGetAssignedRelayPortsVO(String deviceId) throws SQLException {
		AssignedRelayPortsVO assRelayPorts = null;
		
		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new AssignedRelayPortsDB().getAssignedRelayPortsVO(deviceId)).addParameter(deviceId).build();
		
		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)){
			while (rs.next()){
				assRelayPorts = new AssignedRelayPortsVO();
				assRelayPorts.setdModified(rs.getTimestamp(PortalDBEnum.ASSIGNED_RELAY_PORTS.dModified.name()).getTime());
				assRelayPorts.setnPortSegmentStart(rs.getInt(PortalDBEnum.ASSIGNED_RELAY_PORTS.nPortSegmentStart.name()));
				assRelayPorts.setnStatus(rs.getInt(PortalDBEnum.ASSIGNED_RELAY_PORTS.nStatus.name()));
				assRelayPorts.setsDeviceID(rs.getString(PortalDBEnum.ASSIGNED_RELAY_PORTS.sDeviceID.name()));
				assRelayPorts.setsRelayServerID(rs.getString(PortalDBEnum.ASSIGNED_RELAY_PORTS.sRelayServerID.name()));
			}
		}
		return assRelayPorts;
	}

	private List<AssignedRelayPortsVO> mGetAvailablePorts(String relayServerId) throws SQLException {
		List<AssignedRelayPortsVO> listAssRelayPorts = new ArrayList<>();
		
		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery( new AssignedRelayPortsDB().getAvailablePorts())
				.addParameter(relayServerId)
				.addParameter("1")
				.build();
	
		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)){
			while (rs.next()){
				AssignedRelayPortsVO assRelayPorts = new AssignedRelayPortsVO();
				assRelayPorts.setdModified(rs.getTimestamp(PortalDBEnum.ASSIGNED_RELAY_PORTS.dModified.name()).getTime());
				assRelayPorts.setnPortSegmentStart(rs.getInt(PortalDBEnum.ASSIGNED_RELAY_PORTS.nPortSegmentStart.name()));
				assRelayPorts.setnStatus(rs.getInt(PortalDBEnum.ASSIGNED_RELAY_PORTS.nStatus.name()));
				assRelayPorts.setsDeviceID(rs.getString(PortalDBEnum.ASSIGNED_RELAY_PORTS.sDeviceID.name()));
				assRelayPorts.setsRelayServerID(rs.getString(PortalDBEnum.ASSIGNED_RELAY_PORTS.sRelayServerID.name()));
				listAssRelayPorts.add(assRelayPorts);
			}
		}
		return listAssRelayPorts;
	}

	private void mDeleteDeviceAssignedPorts(String deviceId) throws SQLException {
		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new AssignedRelayPortsDB().deleteDeviceAssignedPorts()).addParameter(deviceId).build();

		
		int updateCount = PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
		if(updateCount == 0){
			throw new SQLException("Unable to delete deviceAssignedPorts, please try again.");
		}
	}
	
	private int mGetMaxRelayPort(String relayServerId) throws SQLException {
		
		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new AssignedRelayPortsDB().getMaxRelayPort()).addParameter(relayServerId).build();
		
		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)){
			while (rs.next()){
				return rs.getInt("MaxAvailablePortSegment");
			}
		}
		return 0;
	}


}
