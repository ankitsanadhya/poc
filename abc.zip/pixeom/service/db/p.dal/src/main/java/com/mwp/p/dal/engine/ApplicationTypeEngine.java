/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal.engine;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.common.enums.ApplicationDefaultType;
import com.mwp.common.vo.QueryVO;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.common.vo.AppTypeVO;
import com.mwp.p.dal.ApplicationTypeDB;

/**
 * Manages application types.
 *
 */
public class ApplicationTypeEngine 
{
	/**
	 * Get all the type of application
	 * @return
	 * @throws SQLException
	 */
	public List<AppTypeVO> getAllAppType() throws SQLException
	{
		return mGetAllAppType();
	}

	/**
	 * get typeId for given type
	 * @param typeName
	 * @return
	 */
	public String getTypeId(ApplicationDefaultType typeName) throws SQLException 
	{
		return mGetTypeId(typeName);
	}
	private List<AppTypeVO> mGetAllAppType() throws SQLException 
	{
		List<AppTypeVO> lst = new ArrayList<>();
		ApplicationTypeDB typeDb = new ApplicationTypeDB();
		String qry = typeDb.getAllAppType();
		
		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(qry).build();
		
		AppTypeVO obj = null;
		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO))
		{
			while (rs.next())
			{
				obj = new AppTypeVO();
				obj.setTypeId(rs.getString(PortalDBEnum.APPLICATION_TYPE.typeId.name()));
				obj.setType(rs.getString(PortalDBEnum.APPLICATION_TYPE.type.name()));
				obj.setTypeDisplayName(rs.getString(PortalDBEnum.APPLICATION_TYPE.typeDisplayName.name()));
				lst.add(obj);
			}
		}
		
		return lst;
	}
	
	public String mGetTypeId(ApplicationDefaultType typeName) throws SQLException 
	{
		String typeId= "";
		ApplicationTypeDB typeDb = new ApplicationTypeDB();
		
		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
					.appendQuery(typeDb.getTypeId()).addParameter("%"+typeName+"%").build();
	
		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO))
		{
			while (rs.next())
			{
				typeId = rs.getString(PortalDBEnum.APPLICATION_TYPE.typeId.name());
			}
		}		
		return typeId;
	}
}
