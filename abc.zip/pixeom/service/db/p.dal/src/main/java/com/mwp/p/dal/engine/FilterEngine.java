/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal.engine;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.common.vo.QueryVO;
import com.mwp.p.common.enums.PortalDBEnum.FILTERS;
import com.mwp.p.common.vo.FilterVO;
import com.mwp.p.dal.FilterDB;

/**
 * This class give the filter related data comes from different crud operations
 * queries on filters table.
 * 
 * @author root *
 */
public class FilterEngine {

	/*
	 * public methods.
	 */
	/**
	 * This method get details of filters.
	 * 
	 * @return list of FilterVO.
	 * @throws Exception
	 */
	public List<FilterVO> filterDetailsList() throws SQLException {
		return mGetFilters();
	}

	/*
	 * private methods.
	 */

	private List<FilterVO> mGetFilters() throws SQLException {
		List<FilterVO> fliters = new ArrayList<>();
		FilterDB filterDB = new FilterDB();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
						.appendQuery(filterDB.getAllFilters()).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				fliters.add(setFilterObject(rs));
			}
		}

		return fliters;
	}

	private FilterVO setFilterObject(ResultSet rs) throws SQLException {
		FilterVO filterVO = new FilterVO();
		filterVO.setFilterGroupName(rs.getString(FILTERS.filterGroupName.name()));
		filterVO.setFilterName(rs.getString(FILTERS.filterName.name()));
		filterVO.setFilterId(rs.getString(FILTERS.filterId.name()));
		return filterVO;
	}

}
