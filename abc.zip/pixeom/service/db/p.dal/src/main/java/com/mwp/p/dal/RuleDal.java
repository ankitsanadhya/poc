/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal;



import com.mwp.p.common.enums.PortalDBEnum;

/**
 * This class contains query to get email server from emailServers table
 * @author root
 *
 */
public class RuleDal 
{
	String table;
	StringBuilder colList;
	
	/**
	 * Email server Data access layer object
	 * @param conn
	 */
	public RuleDal()
	{
		table= PortalDBEnum.TABLE_NAMES.rule.name();
		
		colList= new StringBuilder(PortalDBEnum.RULE.ruleId.name());
		colList.append(", "	);		
		colList.append(PortalDBEnum.RULE.ruleValue.name()); 
		colList.append( ", ");
		colList.append( PortalDBEnum.RULE.ruleType.name());
		colList.append( " ,");
		colList.append(PortalDBEnum.RULE.serverType.name()); 
		colList.append( ", ");	
		colList.append( PortalDBEnum.RULE.isKub.name());
	}
	
	/**
	 * Method to get rule by servertype
	 * @param serverName
	 * @return
	 */
	public String get()
	{
		StringBuilder qry= new StringBuilder("SELECT ");
		qry.append(colList);
		qry.append(" FROM ");
		qry.append(table);
		qry.append(" WHERE ");
		qry.append(PortalDBEnum.RULE.serverType.name()); 
		qry.append(" = ");
		qry.append( "?");
		return qry.toString();
	}
	
	public String listAll() 
	{
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT * FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.rule.name());
		return sb.toString();
	}

	public String insert() 
	{
		StringBuilder sb = new StringBuilder();
		sb.append("INSERT INTO ");
		sb.append(PortalDBEnum.TABLE_NAMES.rule);
		sb.append(" ( ");
		sb.append(PortalDBEnum.RULE.ruleId.name());
		sb.append(", ");
		sb.append(PortalDBEnum.RULE.ruleValue.name());
		sb.append(", ");
		sb.append(PortalDBEnum.RULE.ruleType.name());
		sb.append(", ");
		sb.append(PortalDBEnum.RULE.serverType.name());
		sb.append(", ");
		sb.append(PortalDBEnum.RULE.isKub.name());
		sb.append(" ) VALUES ( ");
		sb.append("?");
//		sb.append(dbCon.formatString(rulevo.getRuleId()));
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(rulevo.getRuleValue()));
		sb.append(", ");
		sb.append("?");
//		sb.append(rulevo.getRuleType().ordinal());
		sb.append(", ");
		sb.append("?");
//		sb.append(rulevo.getServerType().ordinal());
		sb.append(", ");
		sb.append("?");
//		sb.append(rulevo.getApplianceIsKub());
		sb.append(" ) ");	

		

		return sb.toString();
	}
//  serverId,
//	serverAddress,
//	serverName,
//	status,
//	username,
//	password,
//	port,
//	priority,
	public  String update() 
	{
		StringBuilder sb = new StringBuilder();
		sb.append("UPDATE  ");
		sb.append(PortalDBEnum.TABLE_NAMES.rule);
		sb.append(" set  ");
		sb.append(PortalDBEnum.RULE.ruleValue.name());
		sb.append(" = ");
		sb.append("?");

		sb.append(" WHERE ");
		sb.append(PortalDBEnum.RULE.ruleId.name());sb.append(" = "); sb.append("?");
		return sb.toString();
	}
	
	public String getRule() 
	{
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT * FROM ");sb.append(PortalDBEnum.TABLE_NAMES.rule.name());
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.RULE.ruleId.name());sb.append(" = ");sb.append("?");
		return sb.toString();
	}
	

	
	public String delete() 
	{
		StringBuilder sb = new StringBuilder();
		sb.append("DELETE ");
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.rule.name());
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.RULE.ruleId.name());sb.append(" = ");
		sb.append("?");
		//sb.append(dbCon.formatString(ruleId));
		return sb.toString();
	}
}
