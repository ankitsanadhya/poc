/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal.engine;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mwp.common.Common;
import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.common.enums.ResourceKindEnum;
import com.mwp.common.vo.AppResourceVO;
import com.mwp.common.vo.QueryVO;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.dal.ApplicationResourcesDB;

/**
 * Each application have resources, other than yamls
 * like nginx configs, certificates, build files, env files...
 * This kind of resources are saved on file system and the mapping 
 * with app is stored in this table.
 *
 */
public class ApplicationResourceEngine {

	public AppResourceVO get(String resourceId) throws SQLException {
		return mGet(resourceId);
	}

	public List<AppResourceVO> get(List<String> resourceIds) throws SQLException {
		return mGet(resourceIds);
	}

	public List<AppResourceVO> getForApp(String applicationId) throws SQLException {
		return mGetForApp(applicationId);
	}

	public AppResourceVO get(String applicationId, ResourceKindEnum kind) throws SQLException {
		return mGet(applicationId, kind);
	}

	public AppResourceVO add(AppResourceVO appResourceVO) throws SQLException {
		return mAdd(appResourceVO);
	}

	public List<AppResourceVO> add(List<AppResourceVO> appResourceVOs) throws SQLException {
		return mAdd(appResourceVOs);
	}

	public AppResourceVO delete(String resourceId) throws SQLException {
		return mDelete(resourceId);
	}

	private AppResourceVO mGet(String resourceId) throws SQLException {
		AppResourceVO appResourceVO = null;

		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new ApplicationResourcesDB().get()).addParameter(resourceId).build();

		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)){
			while (rs.next()) {
				appResourceVO = createResourceVofromRs(rs);				
			}
		}

		return appResourceVO;
	}

	private List<AppResourceVO> mGet(List<String> resourceIds) throws SQLException {
		List<AppResourceVO> appResourceVOs = new ArrayList<>();

		String query = new ApplicationResourcesDB().getForResourceIdsListIN(resourceIds.size());

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(query)
						.addParameters(resourceIds).build();

		if (!resourceIds.isEmpty()) {
			try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
				while (rs.next()) {
					appResourceVOs.add(createResourceVofromRs(rs));
				}
			}
		}

		return appResourceVOs;
	}

	private List<AppResourceVO> mGetForApp(String applicationId) throws SQLException {
		List<AppResourceVO> appResourceVOs = new ArrayList<>();

		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new ApplicationResourcesDB().getForApp()).addParameter(applicationId).build();


		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)){
			while (rs.next()) {
				appResourceVOs.add(createResourceVofromRs(rs));				
			}
		}

		return appResourceVOs;
	}

	private AppResourceVO mGet(String applicationId, ResourceKindEnum kind) throws SQLException {
		AppResourceVO appResourceVO = null;
		
		String query =	new ApplicationResourcesDB().getForAppIdAndKind();
		
		List<Object> parameters = new ArrayList<>();

		parameters.add(applicationId);
		parameters.add(kind);
		
		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(query).addParameters(parameters).build();

		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				appResourceVO = createResourceVofromRs(rs);				
			}
		} 

		return appResourceVO;
	}

	private AppResourceVO mAdd(AppResourceVO appResourceVO) throws SQLException {
		appResourceVO.setAppResourceId(Common.getRandomId());

		String query = new ApplicationResourcesDB().add();

		List<Object> parameters = new ArrayList<>();

		parameters.add(appResourceVO.getAppResourceId());
		parameters.add(appResourceVO.getAppId());
		parameters.add(appResourceVO.getKind().getValue());
		parameters.add(appResourceVO.getServiceName());
		parameters.add(appResourceVO.isEncrypted()?1:0);
		parameters.add(appResourceVO.getFilePath());

		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(query).addParameters(parameters).build();

		PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);

		return mGet(appResourceVO.getAppResourceId());
	}

	private List<AppResourceVO> mAdd(List<AppResourceVO> appResourceVOs) throws SQLException {
		List<String> resourcesIds = new ArrayList<>();
		List<QueryVO> queryVOs = new ArrayList<>();

		for (AppResourceVO appResourceVO : appResourceVOs) {
			if(appResourceVO.getKind() != ResourceKindEnum.appYaml) {

				List<Object> parameters = new ArrayList<>();

				parameters.add(appResourceVO.getAppResourceId());
				parameters.add(appResourceVO.getAppId());
				parameters.add(appResourceVO.getKind().getValue());
				parameters.add(appResourceVO.getServiceName());
				parameters.add(appResourceVO.isEncrypted()?1:0);
				parameters.add(appResourceVO.getFilePath());

				queryVOs.add(new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
						.appendQuery(new ApplicationResourcesDB().add()).addParameters(parameters).build());
				resourcesIds.add(appResourceVO.getAppResourceId());
			}
		}
		PortalDatabaseEngine.getInstance().getConnection().executeUpdatesInTransaction(queryVOs);

		return mGet(resourcesIds);
	}

	private AppResourceVO mDelete(String resourceId) throws SQLException {
		AppResourceVO appResourceVO = mGet(resourceId);
		if(appResourceVO != null) {

			QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
					.appendQuery(new ApplicationResourcesDB().delete()).addParameter(resourceId).build();

			PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
		}
		return appResourceVO;
	}

	private AppResourceVO createResourceVofromRs(ResultSet rs) throws SQLException {
		AppResourceVO appResourceVO = new AppResourceVO();

		appResourceVO.setAppResourceId(rs.getString(PortalDBEnum.APPLICATION_RESOURCES.resourceId.name()));
		appResourceVO.setAppId(rs.getString(PortalDBEnum.APPLICATION_RESOURCES.appId.name()));
		appResourceVO.setKind(ResourceKindEnum.GetEnum(rs.getInt(PortalDBEnum.APPLICATION_RESOURCES.kind.name())));
		appResourceVO.setServiceName(rs.getString(PortalDBEnum.APPLICATION_RESOURCES.serviceName.name()));
		appResourceVO.setEncrypted(rs.getBoolean(PortalDBEnum.APPLICATION_RESOURCES.isEncrypted.name()));
		appResourceVO.setFilePath(rs.getString(PortalDBEnum.APPLICATION_RESOURCES.path.name()));
		appResourceVO.setCreateDate(rs.getTimestamp(PortalDBEnum.APPLICATION_RESOURCES.createdDate.name()).getTime());
		appResourceVO.setModifiedDate(rs.getTimestamp(PortalDBEnum.APPLICATION_RESOURCES.modifiedDate.name()).getTime());

		return appResourceVO;
	}
}