/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal;

import com.mwp.db.Interface.IConnection;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.common.enums.PortalDBEnum.DISCOVERY_JAR_DETAILS;
import com.mwp.p.dal.engine.PortalDatabaseEngine;

/**
 * This class creates queries related to table {@link DISCOVERY_JAR_DETAILS}
 *
 */
public class DiscoveryJarDetailsDB {

	private IConnection dbCon= null;
	public DiscoveryJarDetailsDB() {
		dbCon = PortalDatabaseEngine.getInstance().getConnection();
	}

	/**
	 * Add new  discovery jar details on duplicate key update properties.
	 * @param macAddress
	 * @param hostName
	 * @param iPAddress
	 * @param localIPAddress
	 * @param chatInputChannel
	 * @param chatOutputChannel
	 * @param chatSubscriptionChannel
	 * @param nodeCommunicationPort
	 * @param openStackPort
	 * @param tomcatPort
	 * @param port1
	 * @param port2
	 * @param port3
	 * @param port4
	 * @param port5
	 * @param rURLTomcatPort
	 * @param rAddress
	 * @param isSetRURL
	 * @param status
	 * @param networkType
	 * @param relayServerId
	 * @param portSegmentStart
	 * @return
	 */
//	public String addDiscoveryJarDetails(String macAddress, String hostName, String iPAddress, String localIPAddress,
//			String chatInputChannel, String chatOutputChannel, String chatSubscriptionChannel,
//			String nodeCommunicationPort, String openStackPort,String tomcatPort, String port1,
//			String port2, String port3, String port4, String port5, String rURLTomcatPort,
//			String rAddress, int status, NetworkTypeEnum networkType, String relayServerId) {
//		public String addDiscoveryJarDetails() {
//		StringBuilder sb = new StringBuilder();
//		sb.append("INSERT INTO ");sb.append(PortalDBEnum.TABLE_NAMES.discoveryjardetails);
//		sb.append(" ( ");
//		sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sMACAddress);
//		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sHostName);
//		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sRingID);
//		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sMasterID);
//		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.nNodeStatus);
//		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sIPAddress);
//		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sLocalIPAddress);
//		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sChatInputChannel);
//		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sChatOutputChannel);
//		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sChatSubscriptionChannel);
//		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sNodeCommunicationPort);
//		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sOpenStackPort);
//		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sKeyStonePort);
//		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sTomcatPort);
//		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sConnectURL);
//		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sPort1);
//		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sPort2);
//		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sPort3);
//		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sPort4);
//		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sPort5);
//
//		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sRURLTomcatPort);
//		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sRURLKeystonePort);
//		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sRAddress);
//		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.nStatus);
//		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sRelayServerID);
//		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sNetworkType);
//		sb.append(") VALUES (");
////		sb.append(dbCon.formatString(macAddress));
////		sb.append(", ");sb.append(dbCon.formatString(hostName));
////		sb.append(", ");sb.append(dbCon.formatString(""));
////		sb.append(", ");sb.append(dbCon.formatString(macAddress));
////		sb.append(", ");sb.append(0);
////		sb.append(", ");sb.append(dbCon.formatString(iPAddress));
////		sb.append(", ");sb.append(dbCon.formatString(localIPAddress));
////		sb.append(", ");sb.append(dbCon.formatString(chatInputChannel));
////		sb.append(", ");sb.append(dbCon.formatString(chatOutputChannel));
////		sb.append(", ");sb.append(dbCon.formatString(chatSubscriptionChannel));
////		sb.append(", ");sb.append(dbCon.formatString(nodeCommunicationPort));
////		sb.append(", ");sb.append(dbCon.formatString(openStackPort));
////		sb.append(", ");sb.append(dbCon.formatString(""));
////		sb.append(", ");sb.append(dbCon.formatString(tomcatPort));
////		sb.append(", ");sb.append(dbCon.formatString(""));
////
////		sb.append(", ");sb.append(dbCon.formatString(port1));
////		sb.append(", ");sb.append(dbCon.formatString(port2));
////		sb.append(", ");sb.append(dbCon.formatString(port3));
////		sb.append(", ");sb.append(dbCon.formatString(port4));
////		sb.append(", ");sb.append(dbCon.formatString(port5));
////
////		sb.append(", ");sb.append(dbCon.formatString(rURLTomcatPort));
////		sb.append(", ");sb.append(dbCon.formatString(""));
////		sb.append(", ");sb.append(dbCon.formatString(rAddress));
////		sb.append(", ");sb.append(status);
////		sb.append(", ");sb.append(dbCon.formatString(relayServerId));
////		sb.append(", ");sb.append(networkType.ordinal());
//		
//		sb.append("?");
//		sb.append(", ");
//		sb.append("?");
//		//sb.append(dbCon.formatString(hostName));
//		sb.append(", ");
//		sb.append("?");
////		sb.append(dbCon.formatString(""));
//		sb.append(", ");
//		sb.append("?");
////		sb.append(dbCon.formatString(macAddress));
//		sb.append(", ");
//		sb.append("?");
////		sb.append(0);
//		sb.append(", ");
//		sb.append("?");
////		sb.append(dbCon.formatString(iPAddress));
//		sb.append(", ");
//		sb.append("?");
////		sb.append(dbCon.formatString(localIPAddress));
//		sb.append(", ");
//		sb.append("?");
////		sb.append(dbCon.formatString(chatInputChannel));
//		sb.append(", ");
//		sb.append("?");
////		sb.append(dbCon.formatString(chatOutputChannel));
//		sb.append(", ");
//		sb.append("?");
////		sb.append(dbCon.formatString(chatSubscriptionChannel));
//		sb.append(", ");
//		sb.append("?");
////		sb.append(dbCon.formatString(nodeCommunicationPort));
//		sb.append(", ");
//		sb.append("?");
////		sb.append(dbCon.formatString(openStackPort));
//		sb.append(", ");
//		sb.append("?");
////		sb.append(dbCon.formatString(""));
//		sb.append(", ");
//		sb.append("?");
////		sb.append(dbCon.formatString(tomcatPort));
//		sb.append(", ");
//		sb.append("?");
////		sb.append(dbCon.formatString(""));
//		sb.append(", ");
//		sb.append("?");
////		sb.append(dbCon.formatString(port1));
//		sb.append(", ");
//		sb.append("?");
////		sb.append(dbCon.formatString(port2));
//		sb.append(", ");
//		sb.append("?");
////		sb.append(dbCon.formatString(port3));
//		sb.append(", ");
//		sb.append("?");
////		sb.append(dbCon.formatString(port4));
//		sb.append(", ");
//		sb.append("?");
////		sb.append(dbCon.formatString(port5));
//		sb.append(", ");
//		sb.append("?");
////		sb.append(dbCon.formatString(rURLTomcatPort));
//		sb.append(", ");
//		sb.append("?");
////		sb.append(dbCon.formatString(""));
//		sb.append(", ");
//		sb.append("?");
////		sb.append(dbCon.formatString(rAddress));
//		sb.append(", ");
//		sb.append("?");
////		sb.append(status);
//		sb.append(", ");
//		sb.append("?");
////		sb.append(dbCon.formatString(relayServerId));
//		sb.append(", ");
//		sb.append("?");
////		sb.append(networkType.ordinal());
//		
//		sb.append(" ) ON DUPLICATE KEY UPDATE ");
////		sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sHostName);
////		sb.append(" = ");sb.append(dbCon.formatString(hostName));
////		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sIPAddress);
////		sb.append(" = ");sb.append(dbCon.formatString(iPAddress));
////		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sLocalIPAddress);
////		sb.append(" = ");sb.append(dbCon.formatString(localIPAddress));
////		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sChatInputChannel);
////		sb.append(" = ");sb.append(dbCon.formatString(chatInputChannel));
////		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sChatOutputChannel);
////		sb.append(" = ");sb.append(dbCon.formatString(chatOutputChannel));
////		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sChatSubscriptionChannel);
////		sb.append(" = ");sb.append(dbCon.formatString(chatSubscriptionChannel));
////		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sNodeCommunicationPort);
////		sb.append(" = ");sb.append(dbCon.formatString(nodeCommunicationPort));
////		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sOpenStackPort);
////		sb.append(" = ");sb.append(dbCon.formatString(openStackPort));
////		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sKeyStonePort);
////		sb.append(" = ");sb.append(dbCon.formatString(""));
////		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sTomcatPort);
////		sb.append(" = ");sb.append(dbCon.formatString(tomcatPort));
////		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sPort1);
////		sb.append(" = ");sb.append(dbCon.formatString(port1));
////		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sPort2);
////		sb.append(" = ");sb.append(dbCon.formatString(port2));
////		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sPort3);
////		sb.append(" = ");sb.append(dbCon.formatString(port3));
////		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sPort4);
////		sb.append(" = ");sb.append(dbCon.formatString(port4));
////		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sPort5);
////		sb.append(" = ");sb.append(dbCon.formatString(port5));
////		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sRURLTomcatPort);
////		sb.append(" = ");sb.append(dbCon.formatString(rURLTomcatPort));
////		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sRURLKeystonePort);
////		sb.append(" = ");sb.append(dbCon.formatString(""));
////		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sRAddress);
////		sb.append(" = ");sb.append(dbCon.formatString(rAddress));
////		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.nStatus);
////		sb.append(" = ");sb.append(status);
////		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sRelayServerID);
////		sb.append(" = ");sb.append(dbCon.formatString(relayServerId));
////		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sNetworkType);
////		sb.append(" = ");sb.append(networkType.ordinal());
////		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.dHBRdate);
////		sb.append(" = NOW()");
//
//		sb.append(" = ");
//		sb.append("?");
//		//sb.append(dbCon.formatString(hostName));
//		sb.append(", ");
//		sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sIPAddress);
//		sb.append(" = ");
//		sb.append("?");
////		sb.append(dbCon.formatString(iPAddress));
//		sb.append(", ");
//		sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sLocalIPAddress);
//		sb.append(" = ");
//		sb.append("?");
////		sb.append(dbCon.formatString(localIPAddress));
//		sb.append(", ");
//		sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sChatInputChannel);
//		sb.append(" = ");
//		sb.append("?");
////		sb.append(dbCon.formatString(chatInputChannel));
//		sb.append(", ");
//		sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sChatOutputChannel);
//		sb.append(" = ");
//		sb.append("?");
////		sb.append(dbCon.formatString(chatOutputChannel));
//		sb.append(", ");
//		sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sChatSubscriptionChannel);
//		sb.append(" = ");
//		sb.append("?");
////		sb.append(dbCon.formatString(chatSubscriptionChannel));
//		sb.append(", ");
//		sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sNodeCommunicationPort);
//		sb.append(" = ");
//		sb.append("?");
////		sb.append(dbCon.formatString(nodeCommunicationPort));
//		sb.append(", ");
//		sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sOpenStackPort);
//		sb.append(" = ");
//		sb.append("?");
////		sb.append(dbCon.formatString(openStackPort));
//		sb.append(", ");
//		sb.append("?");
//		sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sKeyStonePort);
//		sb.append(" = ");
//		sb.append("?");
////		sb.append(dbCon.formatString(""));
//		sb.append(", ");
//		sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sTomcatPort);
//		sb.append(" = ");
//		sb.append("?");
////		sb.append(dbCon.formatString(tomcatPort));
//		sb.append(", ");
//		sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sPort1);
//		sb.append(" = ");
//		sb.append("?");
////		sb.append(dbCon.formatString(port1));
//		sb.append(", ");
//		sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sPort2);
//		sb.append(" = ");
//		sb.append("?");
////		sb.append(dbCon.formatString(port2));
//		sb.append(", ");
//		sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sPort3);
//		sb.append(" = ");
//		sb.append("?");
////		sb.append(dbCon.formatString(port3));
//		sb.append(", ");
//		sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sPort4);
//		sb.append(" = ");
//		sb.append("?");
////		sb.append(dbCon.formatString(port4));
//		sb.append(", ");
//		sb.append("?");
//		sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sPort5);
//		sb.append(" = ");
//		sb.append("?");
////		sb.append(dbCon.formatString(port5));
//		sb.append(", ");
//		sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sRURLTomcatPort);
//		sb.append(" = ");
//		sb.append("?");
////		sb.append(dbCon.formatString(rURLTomcatPort));
//		sb.append(", ");
//		sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sRURLKeystonePort);
//		sb.append(" = ");
//		sb.append("?");
////		sb.append(dbCon.formatString(""));
//		sb.append(", ");
//		sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sRAddress);
//		sb.append(" = ");
//		sb.append("?");
////		sb.append(dbCon.formatString(rAddress));
//		sb.append(", ");
//		sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.nStatus);
//		sb.append(" = ");
//		sb.append("?");
////		sb.append(status);
//		sb.append(", ");
//		sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sRelayServerID);
//		sb.append(" = ");
//		sb.append("?");
////		sb.append(dbCon.formatString(relayServerId));
//		sb.append(", ");
//		sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sNetworkType);
//		sb.append(" = ");
//		sb.append("?");
////		sb.append(networkType.ordinal());
//		sb.append(", ");
//		sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.dHBRdate);
//		sb.append(" = NOW()");
//		
//		return sb.toString();
//
//	}
	
	public String addDiscoveryJarDetails() {
			StringBuilder sb = new StringBuilder();
			sb.append("INSERT INTO ");sb.append(PortalDBEnum.TABLE_NAMES.discoveryjardetails);
			sb.append(" ( ");
			sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sMACAddress);
			sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sHostName);
			sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sRingID);
			sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sMasterID);
			sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.nNodeStatus);
			sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sIPAddress);
			sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sLocalIPAddress);
			sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sChatInputChannel);
			sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sChatOutputChannel);
			sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sChatSubscriptionChannel);
			sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sNodeCommunicationPort);
			sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sOpenStackPort);
			sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sKeyStonePort);
			sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sTomcatPort);
			sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sConnectURL);
			sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sPort1);
			sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sPort2);
			sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sPort3);
			sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sPort4);
			sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sPort5);

			sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sRURLTomcatPort);
			sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sRURLKeystonePort);
			sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sRAddress);
			sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.nStatus);
			sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sRelayServerID);
			sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sNetworkType);
			sb.append(") VALUES (");
			sb.append("?");
			sb.append(", ");sb.append("?");
			sb.append(", ");sb.append("?");
			sb.append(", ");sb.append("?");
			sb.append(", ");sb.append("?");
			sb.append(", ");sb.append("?");
			sb.append(", ");sb.append("?");
			sb.append(", ");sb.append("?");

			sb.append(", ");sb.append("?");
			sb.append(", ");sb.append("?");
			sb.append(", ");sb.append("?");
			sb.append(", ");sb.append("?");
			sb.append(", ");sb.append("?");
			sb.append(", ");sb.append("?");
			sb.append(", ");sb.append("?");

			sb.append(", ");sb.append("?");
			sb.append(", ");sb.append("?");
			sb.append(", ");sb.append("?");
			sb.append(", ");sb.append("?");
			sb.append(", ");sb.append("?");

			sb.append(", ");sb.append("?");
			sb.append(", ");sb.append("?");
			sb.append(", ");sb.append("?");
			sb.append(", ");sb.append("?");
			sb.append(", ");sb.append("?");
			sb.append(", ");sb.append("?");
			sb.append(" ) ON DUPLICATE KEY UPDATE ");
			sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sHostName);
			sb.append(" = ");sb.append("?");
			sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sIPAddress);
			sb.append(" = ");sb.append("?");
			sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sLocalIPAddress);
			sb.append(" = ");sb.append("?");
			sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sChatInputChannel);
			sb.append(" = ");sb.append("?");
			sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sChatOutputChannel);
			sb.append(" = ");sb.append("?");
			sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sChatSubscriptionChannel);
			sb.append(" = ");sb.append("?");
			sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sNodeCommunicationPort);
			sb.append(" = ");sb.append("?");
			sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sOpenStackPort);
			sb.append(" = ");sb.append("?");
			sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sKeyStonePort);
			sb.append(" = ");sb.append("?");
			sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sTomcatPort);
			sb.append(" = ");sb.append("?");
			sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sPort1);
			sb.append(" = ");sb.append("?");
			sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sPort2);
			sb.append(" = ");sb.append("?");
			sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sPort3);
			sb.append(" = ");sb.append("?");
			sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sPort4);
			sb.append(" = ");sb.append("?");
			sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sPort5);
			sb.append(" = ");sb.append("?");
			sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sRURLTomcatPort);
			sb.append(" = ");sb.append("?");
			sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sRURLKeystonePort);
			sb.append(" = ");sb.append("?");
			sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sRAddress);
			sb.append(" = ");sb.append("?");
			sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.nStatus);
			sb.append(" = ");sb.append("?");
			sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sRelayServerID);
			sb.append(" = ");sb.append("?");
			sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sNetworkType);
			sb.append(" = ");sb.append("?");
			sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.dHBRdate);
			sb.append(" = NOW()");

			return sb.toString();

		}

	/**
	 * Get discovery jar details object by macAddress also set relay server information
	 * @param mACAddress
	 * @return
	 */
	public String getDiscoveryJarDetailsWithRelay() {

		StringBuilder sb = new StringBuilder();
		sb.append("SELECT ");
		sb.append(PortalDBEnum.TABLE_NAMES.discoveryjardetails);
		sb.append(".*, ");
		sb.append(PortalDBEnum.RELAY_SERVERS.sRelayServerAddress);
		sb.append(", ");
		sb.append(PortalDBEnum.RELAY_SERVERS.sRUserName);
		sb.append(", ");
		sb.append(PortalDBEnum.RELAY_SERVERS.sHostKey);
		sb.append(", ");
		sb.append(PortalDBEnum.RELAY_SERVERS.nRPort);
		sb.append(", ");
		sb.append(PortalDBEnum.RELAY_SERVERS.sRPassword);
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.discoveryjardetails);
		sb.append(" INNER JOIN ");
		sb.append(PortalDBEnum.TABLE_NAMES.relayservers);
		sb.append(" ON ");
		sb.append(PortalDBEnum.TABLE_NAMES.discoveryjardetails);
		sb.append(".");
		sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sRelayServerID);
		sb.append(" = ");
		sb.append(PortalDBEnum.TABLE_NAMES.relayservers);
		sb.append(".");
		sb.append(PortalDBEnum.RELAY_SERVERS.sRelayServerID);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.TABLE_NAMES.discoveryjardetails);
		sb.append(".");
		sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sMACAddress);
		sb.append(" = ");
		sb.append("?");
		//sb.append(dbCon.formatString(mACAddress));
		sb.append(" AND (");
		sb.append(PortalDBEnum.TABLE_NAMES.discoveryjardetails);
		sb.append(".");
		sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.nStatus);
		sb.append(" = ");
		sb.append("?");
		//sb.append(1);
		sb.append(" OR ");
		sb.append(PortalDBEnum.TABLE_NAMES.discoveryjardetails);
		sb.append(".");
		sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.nStatus);
		sb.append(" = ");
		sb.append("?");
		//sb.append(4);
		sb.append(" )");
		return sb.toString();

	}

	/**	 
	 * Get discovery jar details object by macAddress  
	 * @param mACAddress
	 * @return
	 */
	public String getDiscoveryJarDetails() {
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT * FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.discoveryjardetails);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sMACAddress);
		sb.append(" = ");
		sb.append("?");
		//sb.append(dbCon.formatString(mACAddress));
		sb.append(" AND ");
		sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.nStatus);
		sb.append(" = ");
		sb.append("?");
//		sb.append(1);
		return sb.toString();
	}

	/**
	 * Get discovery jar details object by hostName  
	 * @param hostName
	 * @return
	 */
	public String getDiscoveryJarDetailsUsingHostName() {
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT * FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.discoveryjardetails);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sHostName);
		sb.append(" = ");
		sb.append("?");
		//sb.append(dbCon.formatString(hostName));
		return sb.toString();
	}

	/**
	 * Get discovery jar details where ipaddress set to given  ExternalIP
	 * @param externalIP
	 * @return
	 */

	public String getNonActivatedDevices() {
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT * FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.discoveryjardetails);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sIPAddress);
		sb.append(" like ");
		sb.append("?");
		//sb.append(dbCon.formatStringForLike(true, externalIP, true));
		return sb.toString();
	}


	/**
	 * Update connectUrl of discovery jar details entry by macAddress
	 * @param connectURL
	 * @param macAddress
	 * @return
	 */
	public String updateDiscoveryDetailsConnectUrl() {
		StringBuilder sb = new StringBuilder();
		sb.append("UPDATE ");
		sb.append(PortalDBEnum.TABLE_NAMES.discoveryjardetails);
		sb.append(" SET ");
		sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sConnectURL);
		sb.append(" = ");
		sb.append("?");
		//sb.append(dbCon.formatString(connectURL));
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sMACAddress);
		sb.append(" = ");
		sb.append("?");
//		sb.append(dbCon.formatString(macAddress));
		return sb.toString();
	}
	
	/**
	 * Delete entry of discovery jar details for device by macAddress
	 * @param macAddress
	 * @return
	 */

	public String deleteDiscoveryJarDetails() {
		StringBuilder sb = new StringBuilder();
		sb.append("DELETE FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.discoveryjardetails);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sMACAddress);
		sb.append(" = ");
		sb.append("?");
		//sb.append(dbCon.formatString(macAddress));
		return sb.toString();
	}


	/**
	 * Update heartbeat of device by macAddress
	 * @param productId
	 * @return
	 */
	public String updateInactiveDeviceHeartbeat() {
		StringBuilder sb = new StringBuilder();
		sb.append("UPDATE ");
		sb.append(PortalDBEnum.TABLE_NAMES.discoveryjardetails);
		sb.append(" SET ");
		sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.dHBRdate);
		sb.append(" = NOW() ");
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sMACAddress);
		sb.append(" = ");
		sb.append("?");
		//sb.append(dbCon.formatString(productId));
		return sb.toString();
	}
}
