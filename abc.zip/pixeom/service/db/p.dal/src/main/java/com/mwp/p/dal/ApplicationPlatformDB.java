/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal;

import com.mwp.db.Interface.IConnection;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.dal.engine.PortalDatabaseEngine;

/*
 * This class manages application platforms saved in applicationplatform database table.Get and add application platforms.
 */
public class ApplicationPlatformDB {

	private IConnection dbCon= null;
	public ApplicationPlatformDB() {
		//set database connection object.
		dbCon = PortalDatabaseEngine.getInstance().getConnection();
	}
	
	/**
	 * select all platform exists in platform table.This query gives result Order by ordervalue.
	 * @return
	 */
	public String getAllPlatForm() {
		return mGetAllPlatForm();
	}
	
	/**
	 * Add new platform entry to platform table. 
	 * @param platform
	 * @return
//	 */
//	public String addPlatForm(PlatformVO platform) {
//		return mAddPlatForm(platform);
//	}
//	
	/**
	 * Get platform object for given platform actual name. 
	 * @param actualName
	 * @return
	 */
	public String getPlatForm() {
		return mGetPlatForm();
	}
	
	/**
	 * Get query to select application platform for given application id and deviceId.The query joins applicationplatform to devices 
	 * @param appId application Id
	 * @param deviceId device Id
	 * @return
	 */
	public String getDeviceApplicationPlatForm() {
		StringBuilder sb = new StringBuilder();
		sb.append("Select appPlatform.* FROM ");sb.append(PortalDBEnum.TABLE_NAMES.applicationplatform);sb.append(" AS appPlatform ");
		sb.append(" JOIN ");
		sb.append(PortalDBEnum.TABLE_NAMES.devices);sb.append(" ON appPlatform.");sb.append(PortalDBEnum.APPLICATION_PLATFORM.platformId.name());
		sb.append(" = ");sb.append("devices.");sb.append(PortalDBEnum.DEVICES.platformId.name());
		sb.append(" WHERE ");
		sb.append("devices.");sb.append(PortalDBEnum.DEVICES.deviceId.name());sb.append(" = ");sb.append("?");
		sb.append(" AND ");
		sb.append(" appPlatform.");sb.append(PortalDBEnum.APPLICATION_PLATFORM.appId.name());sb.append(" = ");sb.append("?");
		return sb.toString();
	}
	
	/**
	 * select all platform exists in platform table.This query gives result Order by ordervalue.
	 * @return
	 */
	private String mGetAllPlatForm() {
		StringBuilder sb = new StringBuilder();
		sb.append("Select * FROM ");sb.append(PortalDBEnum.TABLE_NAMES.platform);
		sb.append(" ORDER BY ");
		sb.append(PortalDBEnum.PLATFORM.ordervalue.name());
		return sb.toString();
	}

	private String mGetPlatForm() {
		StringBuilder sb = new StringBuilder();
		sb.append("Select * FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.platform);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.PLATFORM.platformActualName.name());
		sb.append(" LIKE ");
		sb.append("?");
//		sb.append(dbCon.formatString("%" + actualName + "%"));
		return sb.toString();
	}
	
//	private String mAddPlatForm(PlatformVO platform){
//		StringBuilder sb = new StringBuilder();
//		sb.append("INSERT INTO ");
//		sb.append(PortalDBEnum.TABLE_NAMES.platform);
//		sb.append(" ( ");
//		sb.append(PortalDBEnum.PLATFORM.platformId.name());
//		sb.append(", ");
//		sb.append(PortalDBEnum.PLATFORM.platformName.name());
//		sb.append(", ");
//		sb.append(PortalDBEnum.PLATFORM.platformActualName.name());
//		sb.append(", ");
//		sb.append(PortalDBEnum.PLATFORM.modifiedDate.name());
//		sb.append(" ) VALUES ( ");
//		sb.append(dbCon.formatString(platform.getPlatformId()));
//		sb.append(", ");
//		sb.append(dbCon.formatString(platform.getPlatformName()));
//		sb.append(", ");
//		sb.append(dbCon.formatString(platform.getPlatformActualName()));
//		sb.append(", ");
//		sb.append(" NOW()");
//		sb.append(" ) ");
//		return sb.toString();
//	}

	

	
}
