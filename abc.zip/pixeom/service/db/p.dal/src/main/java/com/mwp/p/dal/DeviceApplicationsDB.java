/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mwp.common.StringFunctions;
import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.common.enums.Operator;
import com.mwp.common.enums.Status;
import com.mwp.common.enums.StatusEnum.VERSION_STATUS;
import com.mwp.common.vo.FilterObject;
import com.mwp.common.vo.QueryVO;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.dal.engine.PortalDatabaseEngine;

/**
 * This class manage queries of DeviceApplication which are installed, invited by user on his device.
 * @author root
 *
 */
public class DeviceApplicationsDB {

	private List<String> queries=new ArrayList<>();
	

	/**
	 *  Create query to list application info, all application which exist on device.
	 * @param pageNo page number
	 * @param pageSize number of page in one page of result
	 * @param deviceId device id
	 * @return
	 */
	public List<String> listDeviceApplication(String deviceId) {
		return mListDeviceApplication(deviceId);
	}

	/**
	 * Create query to list invited application which user are invited on multiple groups.
	 * @param userId  user id
	 * @param groupIds List of group id 
	 * @return
	 */
	public String listInvitedApps(int count){
		return mListInvitedApps(count);
	}

	/**
	 * Create query to add entry in device application
	 * @param deviceAppVO
	 * @return
	 */
	public String addDeviceApplication(){
		return mAddDeviceApplication();
	}

	/**
	 * This method return query for applicable commands of an application on user's device
	 * @param userId
	 * @param appId
	 * @param grpIds
	 * @return
	 */
	public String getApplicationStatusOnUserDevices(List<String> edgeCoreIds) {
		return mGetApplicationStatusOnUserDevices(edgeCoreIds );
	}

	/**
	 *	This method return query for applicable commands on application version.
	 * @param userId id of logged in user.
	 * @param applicationId Application Id which is unique for each application.
	 * @param appVersionId  Version Id of application which is unique for each version.
	 * @param grpIds
	 * @return query
	 * @throws SQLException 
	 */
	public String getAppVersionCommand(List<String> grpIds)	 {
		return mGetAppVersionCommand(grpIds);
	}


	/**
	 * Get Device Application for deviceId and appId provided
	 * @param deviceId
	 * @param appId
	 * @return
	 */
	public String getDeviceApplication(){
		return mGetDeviceApplication();
	}

	/**
	 * Update deviceApplication for deviceId and appId
	 * @param deviceAppVO
	 * @return
	 */
	public String updateDeviceApplication(){
		return mUpdateDeviceApplication();
	}

	
	public String deletFromDeviceApplication(){
		/**
		 * Delete device application entries
		 */
		StringBuilder sb = new StringBuilder();
		sb.append("DELETE FROM ");sb.append(PortalDBEnum.TABLE_NAMES.deviceapplications);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.DEVICE_APPLICATIONS.deviceId.name());
		sb.append(" = ");
		sb.append("?");
		return sb.toString();
	}
//	/**
//	 * This method give queries to factory reset the device.Removes device-application relation from deviceApplication,
//	 * delete device and all jobs.
//	 * if device is not KubernetesCluster then also do following things 
//	 * delete it relation entry from tables : validationInfo, discoverydetails, lockrelayports
//	 * update status as 2 in assignedrelayports
//	 * add activation history with action value as "factoryreset"  
//	 * @param deviceId
//	 * @param userId
//	 * @return
//	 */
//	public List<String> deleteDeviceApplication(String deviceId, String userId, DeviceVO device) {
//		return mDeleteDeviceApplication(deviceId, userId, device);
//	}

//	private List<String> mDeleteDeviceApplication(String deviceId, String userId, DeviceVO device) {
//		List<String> qry = new ArrayList<>();
//		StringBuilder sb = new StringBuilder();
//		sb.append("DELETE FROM ");sb.append(PortalDBEnum.TABLE_NAMES.deviceapplications);
//		sb.append(" WHERE ");
//		sb.append(PortalDBEnum.DEVICE_APPLICATIONS.deviceId.name());sb.append(" = ");sb.append(PortalDatabaseEngine.getInstance().getConnection().formatString(deviceId));
//		qry.add(sb.toString());
//		//		/*
//		//		 * get query for update device status with deleted status.
//		//		 */
//		
//		if(device.getDeviceType()  != DeviceTypeEnum.KubernetesCluster)
//		{
//			
//			  // get query for delete validationInfo using macAddress.
//			qry.add(new ValidationInfoDB().deleteValidationInfo(device.getNodeVO().getMacAddress()));
//
//			
//			qry.add(new DiscoveryDetailsDB().delete(device.getNodeVO().getNodeId()));
//
//			qry.add(new AssignedRelayPortsDB().updateAssignedPortsStatus(device.getNodeVO().getNodeId()));
//
//		
//			qry.add(new LockRelayPortsDB().deleteLockRelayPorts(device.getNodeVO().getNodeId()));
//
//			device.getNodeVO().setAction("factoryreset");
//			qry.add(new DevicesDB().addDeviceDetailsInActivationHistory(device.getUserId(), device.getNodeVO()));
//
//		}
//		qry.add(new DevicesDB().deleteEdgeCoreFromGroups(deviceId));
//		qry.add(new DevicesDB().deleteDevice(deviceId, userId));		
//		qry.add(new InstallJobDB().deleteAllJobs(deviceId, userId));
//
//		return qry;
//	}

	/**
	 * This method give queries for remove device-application relation from deviceApplication, 
	 * and change device status = 'DELETED'.
	 * @param deviceId
	 * @param userId
	 * @return
	 * @throws SQLException 
	 */
	public List<QueryVO> deleteNewDeviceApplication(String deviceId) throws SQLException {
		return mDeleteNewDeviceApplication(deviceId);
	}

	private List<QueryVO> mDeleteNewDeviceApplication(String productId) throws SQLException {
		List<QueryVO> queryVOs = new ArrayList<>();
		
		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
						.appendQuery(new DiscoveryJarDetailsDB().deleteDiscoveryJarDetails()).addParameter(productId).build();
		queryVOs.add(queryVO);
		
		queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
						.appendQuery(new AssignedRelayPortsDB().updateAssignedPortsStatus())
						.addParameter(1)
						.addParameter(productId).build();
		queryVOs.add(queryVO);
		
		queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
						.appendQuery(new LockRelayPortsDB().deleteLockRelayPorts())
						.addParameter(productId).build();
		queryVOs.add(queryVO);
		
//		queries.add(new DiscoveryJarDetailsDB().deleteDiscoveryJarDetails(productId));

		//queries.add(new AssignedRelayPortsDB().updateAssignedPortsStatus(productId));

		//queries.add(new LockRelayPortsDB().deleteLockRelayPorts(productId));

		return queryVOs;
	}


	private String mAddDeviceApplication(){
		StringBuilder sb = new StringBuilder();
		sb.append("INSERT INTO ");
		sb.append(PortalDBEnum.TABLE_NAMES.deviceapplications);
		sb.append(" ( ");
		sb.append(PortalDBEnum.DEVICE_APPLICATIONS.deviceAppId.name());
		sb.append(", ");
		sb.append(PortalDBEnum.DEVICE_APPLICATIONS.deviceId.name());
		sb.append(", ");
		sb.append(PortalDBEnum.DEVICE_APPLICATIONS.appId.name());
		sb.append(", ");
		sb.append(PortalDBEnum.DEVICE_APPLICATIONS.appVersionId.name());
		sb.append(", ");
		sb.append(PortalDBEnum.DEVICE_APPLICATIONS.deviceAppstatus.name());
		sb.append(", ");
		sb.append(PortalDBEnum.DEVICE_APPLICATIONS.createdDate.name());
		sb.append(", ");
		sb.append(PortalDBEnum.DEVICE_APPLICATIONS.modifiedDate.name());
		sb.append(" ) VALUES ( ");
		sb.append("?");
		sb.append(", ");
		sb.append("?");
		sb.append(", ");
		sb.append("?");
		sb.append(", ");
		sb.append("?");
		sb.append(", ");
		sb.append("?");
		sb.append(", ");
		sb.append(" NOW()");
		sb.append(", ");
		sb.append(" NOW()");
		sb.append(" ) ");

		return sb.toString();
	}

	private String mGetDeviceApplication(){
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT * FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.deviceapplications);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.DEVICE_APPLICATIONS.deviceId.name());
		sb.append(" = ");
		sb.append("?");
		sb.append(" AND ");
		sb.append(PortalDBEnum.DEVICE_APPLICATIONS.appId.name());
		sb.append(" = ");
		sb.append("?");

		return sb.toString();
	}

	private String mUpdateDeviceApplication(){
		StringBuilder sb = new StringBuilder();
		sb.append("UPDATE  ");
		sb.append(PortalDBEnum.TABLE_NAMES.deviceapplications);
		sb.append(" SET ");
		sb.append(PortalDBEnum.DEVICE_APPLICATIONS.appVersionId.name());
		sb.append(" = ");
		sb.append("?");
		sb.append(" , ");
		sb.append(PortalDBEnum.DEVICE_APPLICATIONS.deviceAppstatus.name());
		sb.append(" = ");
		sb.append("?");
		sb.append(" , ");
		sb.append(PortalDBEnum.DEVICE_APPLICATIONS.modifiedDate.name());
		sb.append(" = ");
		sb.append("NOW()");
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.DEVICE_APPLICATIONS.deviceId.name());
		sb.append(" = ");
		sb.append("?");
		sb.append(" AND ");
		sb.append(PortalDBEnum.DEVICE_APPLICATIONS.appId.name());
		sb.append(" = ");
		sb.append("?");

		return sb.toString();
	}

	/**
	 * getting application info, all application which are installed by user on multiple devices.
	 * @param userId
	 * @return
	 * @throws Exception
	 */
	public List<String> listDeviceApplicationForUser()  {
		return mListDeviceApplicationForUser();
	}

	public String getInstalledDeviceAppDetail() {
		return mGetInstalledDeviceAppDetail();
	}

	public List<String> getInstalledDeviceAppDetailWithLimitOffset() {
		return mGetInstalledDeviceAppDetailWithLimitOffset();
	}

	/**
	 * getting this application installed on any of user devices,
	 * if getting true then we set isInstalled property "true" = 1 else "false" = 0. 
	 * @param appId
	 * @param userId
	 * @return
	 */
	public String isAppInstalledOnDevice() {
		return mIsAppInstalledOnDevice();
	}

	public String getInstalledApplicatonComposeVersion()
	{
		return mGetInstalledApplicatonComposeVersion();
	}
	
	private String mGetInstalledApplicatonComposeVersion()
	{
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT ");
		sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.composeVersion.name());
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.deviceapplications);
		sb.append(" JOIN ");
		sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);
		sb.append(" ON ");
		sb.append(PortalDBEnum.TABLE_NAMES.deviceapplications);sb.append(".");sb.append(PortalDBEnum.DEVICE_APPLICATIONS.appVersionId.name());
		sb.append(" = ");
		sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.appVersionId.name());

		sb.append(" WHERE ");
		sb.append(PortalDBEnum.TABLE_NAMES.deviceapplications);sb.append(".");sb.append(PortalDBEnum.DEVICE_APPLICATIONS.deviceId.name());
		sb.append(" = ");
		sb.append("?");
		
		sb.append(" AND ");
		
		sb.append(PortalDBEnum.TABLE_NAMES.deviceapplications);sb.append(".");sb.append(PortalDBEnum.DEVICE_APPLICATIONS.appId.name());
		sb.append(" = ");
		sb.append("?");
		
		sb.append(" AND ");
		sb.append(PortalDBEnum.TABLE_NAMES.deviceapplications);sb.append(".");sb.append(PortalDBEnum.DEVICE_APPLICATIONS.deviceAppstatus);sb.append(" != ");sb.append(Status.DELETED.ordinal());
		
		return sb.toString();
	
	}
	
	
	
	/**
	 * getting this application installed on any of user devices,
	 * if getting true then we set isInstalled property "true" = 1 else "false" = 0. 
	 * @param appId
	 * @param userId
	 * @return
	 */
	private String mIsAppInstalledOnDevice() {
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT IF (COUNT(*) = 0,0,1) as isInstalled FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.deviceapplications);
		sb.append(" JOIN ");
		sb.append(PortalDBEnum.TABLE_NAMES.devices);sb.append(" ON deviceapplications.deviceId = devices.deviceId ");
		sb.append(" WHERE ");
		sb.append("devices.userId = ");sb.append("?");
		sb.append(" AND deviceapplications.appId = ");sb.append("?");
		sb.append(" AND deviceapplications.");sb.append(PortalDBEnum.DEVICE_APPLICATIONS.deviceAppstatus.name()); sb.append(" != ");sb.append(Status.DELETED.ordinal());
		return sb.toString();
	}


	private String mGetInstalledDeviceAppDetail() {
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT ");
		sb.append(" a.* ");
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.company);sb.append(".");sb.append(PortalDBEnum.COMPANY.companyName.name());
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.company);sb.append(".");sb.append(PortalDBEnum.COMPANY.webAddress.name());sb.append(" as companyWebAddress");
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.category);sb.append(".");sb.append(PortalDBEnum.CATEGORY.name.name());
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.category);sb.append(".");sb.append(PortalDBEnum.CATEGORY.catId.name());
		sb.append(", applicationimages." + PortalDBEnum.APPLICATION_IMAGES.imagePath);
		sb.append(", applicationimages." + PortalDBEnum.APPLICATION_IMAGES.sequenceNo);
		sb.append(", applicationimages." + PortalDBEnum.APPLICATION_IMAGES.appImageId);
		sb.append(", appplatform." + PortalDBEnum.APPLICATION_PLATFORM.appPlatformId);sb.append(" as appplatform_appPlatformId");
		sb.append(", appplatform." + PortalDBEnum.APPLICATION_PLATFORM.platformId);
		sb.append(", appplatform." + PortalDBEnum.APPLICATION_PLATFORM.repositoryName);
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".*");
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.deviceapplications);sb.append(".");sb.append(PortalDBEnum.DEVICE_APPLICATIONS.modifiedDate.name());sb.append(" as installationDate");
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.deviceapplications);sb.append(".");sb.append(PortalDBEnum.DEVICE_APPLICATIONS.deviceAppstatus.name());
		/*
		 * add device name for display on device,
		 * get device name using left join on device table on deviceId = deviceapplication.deviceId.
		 */
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.devices);sb.append(".");sb.append(PortalDBEnum.DEVICES.deviceName.name());
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.application);sb.append(" as a ");
		sb.append("JOIN ");sb.append(PortalDBEnum.TABLE_NAMES.project);sb.append(" ON a.projectId = project.projectId ");
		sb.append("JOIN ");sb.append(PortalDBEnum.TABLE_NAMES.company);sb.append(" ON project.companyId = company.companyId ");
		sb.append("JOIN ");sb.append(PortalDBEnum.TABLE_NAMES.applicationcategories);sb.append(" ON a.appId = applicationcategories.appId ");
		sb.append("JOIN ");sb.append(PortalDBEnum.TABLE_NAMES.category);sb.append(" ON applicationcategories.catId = category.catId ");
		sb.append(" LEFT JOIN ");sb.append("applicationimages on a.appId = applicationimages.appId");
		sb.append(" LEFT JOIN ");sb.append("deviceapplications on a.appId = deviceapplications.appId");
		sb.append(" LEFT JOIN ");sb.append(" applicationversions ON deviceapplications.appVersionId = applicationversions.appVersionId ");
		sb.append(" LEFT JOIN ");sb.append(PortalDBEnum.TABLE_NAMES.devices);sb.append(" ON devices.deviceId = deviceapplications.deviceId ");
		sb.append(" LEFT JOIN ");sb.append(PortalDBEnum.TABLE_NAMES.applicationplatform);sb.append(" AS appplatform ON appplatform.");sb.append(PortalDBEnum.APPLICATION_PLATFORM.appId);
		sb.append(" = a.");sb.append(PortalDBEnum.APPLICATION.appId);
		sb.append(" WHERE ");
		sb.append(" a.appId = ");sb.append("?");
		sb.append(" AND ");
		sb.append(" deviceapplications.deviceId = ");sb.append("?");
		sb.append(" ORDER BY ");
		sb.append(PortalDBEnum.TABLE_NAMES.devices);sb.append(".");sb.append(PortalDBEnum.DEVICES.deviceName);sb.append(" ASC ");
		return sb.toString();
	}




	private List<String> mGetInstalledDeviceAppDetailWithLimitOffset() {
		
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT SQL_CALC_FOUND_ROWS ");			
		sb.append(" a.* ");
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.company);sb.append(".");sb.append(PortalDBEnum.COMPANY.companyName.name());
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.company);sb.append(".");sb.append(PortalDBEnum.COMPANY.webAddress.name());sb.append(" as companyWebAddress");
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.category);sb.append(".");sb.append(PortalDBEnum.CATEGORY.name.name());
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.category);sb.append(".");sb.append(PortalDBEnum.CATEGORY.catId.name());
		sb.append(", applicationimages." + PortalDBEnum.APPLICATION_IMAGES.imagePath);
		sb.append(", applicationimages." + PortalDBEnum.APPLICATION_IMAGES.sequenceNo);
		sb.append(", applicationimages." + PortalDBEnum.APPLICATION_IMAGES.appImageId);
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".*");
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.deviceapplications);sb.append(".");sb.append(PortalDBEnum.DEVICE_APPLICATIONS.modifiedDate.name());sb.append(" as installationDate");
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.deviceapplications);sb.append(".");sb.append(PortalDBEnum.DEVICE_APPLICATIONS.deviceAppstatus.name());
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.deviceapplications);sb.append(".");sb.append(PortalDBEnum.DEVICE_APPLICATIONS.deviceId.name());
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.deviceapplications);sb.append(".");sb.append(PortalDBEnum.DEVICE_APPLICATIONS.deviceAppstatus.name());
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.deviceapplications);sb.append(".");sb.append(PortalDBEnum.DEVICE_APPLICATIONS.appVersionId.name());
		/*
		 * add device name for display on device,
		 * get device name using left join on device table on deviceId = deviceapplication.deviceId.
		 */
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.devices);sb.append(".");sb.append(PortalDBEnum.DEVICES.deviceName.name());
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.application);sb.append(" as a ");
		sb.append("JOIN ");sb.append(PortalDBEnum.TABLE_NAMES.project);sb.append(" ON a.projectId = project.projectId ");
		sb.append("JOIN ");sb.append(PortalDBEnum.TABLE_NAMES.company);sb.append(" ON project.companyId = company.companyId ");
		sb.append("JOIN ");sb.append(PortalDBEnum.TABLE_NAMES.applicationcategories);sb.append(" ON a.appId = applicationcategories.appId ");
		sb.append("JOIN ");sb.append(PortalDBEnum.TABLE_NAMES.category);sb.append(" ON applicationcategories.catId = category.catId ");
		sb.append(" LEFT JOIN ");sb.append("applicationimages on a.appId = applicationimages.appId");
		sb.append(" LEFT JOIN ");sb.append("deviceapplications on a.appId = deviceapplications.appId");
		sb.append(" LEFT JOIN ");sb.append(" applicationversions ON deviceapplications.appVersionId = applicationversions.appVersionId ");
		sb.append(" LEFT JOIN ");sb.append(PortalDBEnum.TABLE_NAMES.devices);sb.append(" ON devices.deviceId = deviceapplications.deviceId ");
		sb.append(" WHERE ");
		sb.append(" a.appId = ");sb.append("?");
		sb.append(" ORDER BY ");
		sb.append(PortalDBEnum.TABLE_NAMES.devices);sb.append(".");sb.append(PortalDBEnum.DEVICES.deviceName);sb.append(" ASC ");


		sb.append(" limit ");
		sb.append("?");
		sb.append(" offset ");
		sb.append("?");

		queries.add(sb.toString());
		queries.add("SELECT FOUND_ROWS() as appCount");

		return queries;
	}

	/**
	 * getting application info, all application which are exist on device.
	 * @param pageNo
	 * @param pageSize
	 * @param deviceId
	 * @return
	 */
	private List<String> mListDeviceApplication(String deviceId) {
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT SQL_CALC_FOUND_ROWS ");				
		sb.append("app.*");
		sb.append(", dapp."); sb.append(PortalDBEnum.DEVICE_APPLICATIONS.deviceId);
		sb.append(", dev."); sb.append(PortalDBEnum.DEVICES.deviceName);

		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.deviceapplications); sb.append(" AS dapp");

		sb.append(" INNER JOIN ");sb.append(PortalDBEnum.TABLE_NAMES.application);sb.append(" AS app ON app."); sb.append(PortalDBEnum.APPLICATION.appId);
		sb.append(" = dapp."); sb.append(PortalDBEnum.DEVICE_APPLICATIONS.appId);

		sb.append(" INNER JOIN ");sb.append(PortalDBEnum.TABLE_NAMES.devices);sb.append(" AS dev ON dev."); sb.append(PortalDBEnum.DEVICES.deviceId);
		sb.append(" = dapp."); sb.append(PortalDBEnum.DEVICE_APPLICATIONS.deviceId);

		sb.append(" WHERE ");

		if(!StringFunctions.isNullOrWhitespace(deviceId)){
			sb.append("dapp.");sb.append(PortalDBEnum.DEVICE_APPLICATIONS.deviceId);sb.append(" = ");sb.append("?");
		}else {
			sb.append(" dapp."); sb.append(PortalDBEnum.DEVICE_APPLICATIONS.deviceId);
			sb.append(" IN (");
			sb.append("Select ");sb.append(PortalDBEnum.TABLE_NAMES.devices);sb.append(".");sb.append(PortalDBEnum.DEVICES.deviceId);
			sb.append(" FROM ");sb.append(PortalDBEnum.TABLE_NAMES.devices);
			sb.append(" WHERE ");
			sb.append(PortalDBEnum.TABLE_NAMES.devices);sb.append(".");sb.append(PortalDBEnum.DEVICES.userId);sb.append(" = ");sb.append("?");
			sb.append(" AND ");
			sb.append(PortalDBEnum.TABLE_NAMES.devices);sb.append(".");sb.append(PortalDBEnum.DEVICES.deviceStatus);sb.append(" != ");sb.append(Status.DELETED.ordinal());
			sb.append(") ");
		}

		sb.append(" AND ");
		sb.append("dapp.");sb.append(PortalDBEnum.DEVICE_APPLICATIONS.deviceAppstatus);sb.append(" != ");sb.append(Status.DELETED.ordinal());

		sb.append(" ORDER BY ");
		sb.append(" app.");sb.append(PortalDBEnum.APPLICATION.title);sb.append(" ASC ");

		sb.append(" limit ");
		sb.append("?");
		sb.append(" offset ");
		sb.append("?");

		queries.add(sb.toString());
		queries.add("SELECT FOUND_ROWS() as appCount");

		return queries;		
	}

	/**
	 * list all apps for give device and user
	 * @param userId
	 * @param deviceId
	 * @return
	 */
	public List<String> listAllAppsOfDeviceByFilter(String deviceId,List<FilterObject> filters, List<String> deviceIds) {
		return mListAllAppsOfDeviceByFilter(deviceId, filters, deviceIds);
	}



	/**
	 * list all apps for give device and user
	 * @param authVo
	 * @param deviceId
	 * @return
	 */
	public String listAllAppsOfDevice(String deviceId, List<String> deviceIds, List<String> edgeCoreIds) {
		return mListAllAppsOfDevice(deviceId, deviceIds, edgeCoreIds);
	}



	public String isAppUpdateAvilable(List<String> installedAppIds)
	{
		return mIsAppUpdateAvilable(installedAppIds);
	}
	
	private String mListAllAppsOfDevice(String deviceId, List<String> deviceIds, List<String> edgeCoreIds) 
	{
//		String userId = authVo.getUserId();
//		List<String> grpIds = null;
//		if (authVo.getGroupPermissions() != null)
//			grpIds = new ArrayList<>(authVo.getGroupPermissions().keySet());
		
		SqlQueryBuilder queryBuilder = new SqlQueryBuilder();
		queryBuilder.appendQuery("SELECT ");
		queryBuilder.appendQuery("app.*");
		queryBuilder.appendQuery(", dapp.");
		queryBuilder.appendQuery(PortalDBEnum.DEVICE_APPLICATIONS.deviceId);
		queryBuilder.appendQuery(", dapp.");
		queryBuilder.appendQuery(PortalDBEnum.DEVICE_APPLICATIONS.appVersionId);
		queryBuilder.appendQuery(", dev.");
		queryBuilder.appendQuery(PortalDBEnum.DEVICES.deviceName);
		queryBuilder.appendQuery(", appversion.*");
		queryBuilder.appendQuery(" FROM ");
		queryBuilder.appendQuery(PortalDBEnum.TABLE_NAMES.deviceapplications);
		queryBuilder.appendQuery(" AS dapp");
		queryBuilder.appendQuery(" INNER JOIN ");
		queryBuilder.appendQuery(PortalDBEnum.TABLE_NAMES.application);
		queryBuilder.appendQuery(" AS app ON app.");
		queryBuilder.appendQuery(PortalDBEnum.APPLICATION.appId);
		queryBuilder.appendQuery(" = dapp.");
		queryBuilder.appendQuery(PortalDBEnum.DEVICE_APPLICATIONS.appId);
		queryBuilder.appendQuery(" INNER JOIN ");
		queryBuilder.appendQuery(PortalDBEnum.TABLE_NAMES.devices);
		queryBuilder.appendQuery(" AS dev ON dev.");
		queryBuilder.appendQuery(PortalDBEnum.DEVICES.deviceId);
		queryBuilder.appendQuery(" = dapp.");
		queryBuilder.appendQuery(PortalDBEnum.DEVICE_APPLICATIONS.deviceId);
		queryBuilder.appendQuery(" INNER JOIN ");
		queryBuilder.appendQuery(PortalDBEnum.TABLE_NAMES.applicationversions);
		queryBuilder.appendQuery(" AS appversion ON appversion.");
		queryBuilder.appendQuery(PortalDBEnum.APPLICATION_VERSIONS.appVersionId);
		queryBuilder.appendQuery(" = dapp.");
		queryBuilder.appendQuery(PortalDBEnum.DEVICE_APPLICATIONS.appVersionId);
		queryBuilder.appendQuery(" WHERE ");

		if (!StringFunctions.isNullOrWhitespace(deviceId)) {
			queryBuilder.appendQuery("dapp.");
			queryBuilder.appendQuery(PortalDBEnum.DEVICE_APPLICATIONS.deviceId);
			queryBuilder.appendQuery(" = ");
			queryBuilder.appendQuery("?");
//			queryBuilder.appendQuery(PortalDatabaseEngine.getInstance().getConnection().formatString(deviceId));
		} else {
			queryBuilder.appendQuery(" (");
			queryBuilder.appendQuery(" dapp.");
			queryBuilder.appendQuery(PortalDBEnum.DEVICE_APPLICATIONS.deviceId);
			queryBuilder.appendQueryIN(deviceIds);
//			queryBuilder.appendQuery(" IN (");
//			
//			queryBuilder.appendQuery("Select ");
//			queryBuilder.appendQuery(PortalDBEnum.TABLE_NAMES.devices);
//			queryBuilder.appendQuery(".");
//			queryBuilder.appendQuery(PortalDBEnum.DEVICES.deviceId);
//			queryBuilder.appendQuery(" FROM ");
//			queryBuilder.appendQuery(PortalDBEnum.TABLE_NAMES.devices);
//			queryBuilder.appendQuery(" WHERE ");
//			queryBuilder.appendQuery(PortalDBEnum.TABLE_NAMES.devices);
//			queryBuilder.appendQuery(".");
//			queryBuilder.appendQuery(PortalDBEnum.DEVICES.userId);
//			queryBuilder.appendQuery(" = ");
//			queryBuilder.appendQuery(PortalDatabaseEngine.getInstance().getConnection().formatString(userId));
//			queryBuilder.appendQuery(" AND ");
//			queryBuilder.appendQuery(PortalDBEnum.TABLE_NAMES.devices);
//			queryBuilder.appendQuery(".");
//			queryBuilder.appendQuery(PortalDBEnum.DEVICES.deviceStatus);
//			queryBuilder.appendQuery(" != ");
//			queryBuilder.appendQuery(Status.DELETED.ordinal());
//			queryBuilder.appendQuery(") ");
			
			if (edgeCoreIds != null && !edgeCoreIds.isEmpty()) {
				queryBuilder.appendQuery(" OR ");
				queryBuilder.appendQuery(" dapp.");
				queryBuilder.appendQuery(PortalDBEnum.DEVICE_APPLICATIONS.deviceId);
				
//				queryBuilder.appendQuery(" IN (");
//				queryBuilder.appendQuery(new EdgeCoreGroupsDB().listEdgeCoreForGroups(grpIds));
				
				queryBuilder.appendQueryIN(edgeCoreIds);
				
				queryBuilder.appendQuery(") ");
				
			} else {
				queryBuilder.appendQuery(") ");
			}
		}
		
		queryBuilder.appendQuery(" AND ");
		queryBuilder.appendQuery("dapp.");
		queryBuilder.appendQuery(PortalDBEnum.DEVICE_APPLICATIONS.deviceAppstatus);
		queryBuilder.appendQuery(" != ");
		queryBuilder.appendQuery(Status.DELETED.ordinal());
		queryBuilder.appendQuery(" ORDER BY ");
		queryBuilder.appendQuery(" app.");
		queryBuilder.appendQuery(PortalDBEnum.APPLICATION.title);
		queryBuilder.appendQuery(" ASC ");

		return queryBuilder.getQuery().toString();
	}

	public String getDeviceIdsByUserId(){
		SqlQueryBuilder queryBuilder = new SqlQueryBuilder();
		queryBuilder.appendQuery("Select ");
		queryBuilder.appendQuery(PortalDBEnum.TABLE_NAMES.devices);
		queryBuilder.appendQuery(".");
		queryBuilder.appendQuery(PortalDBEnum.DEVICES.deviceId);
		queryBuilder.appendQuery(" FROM ");
		queryBuilder.appendQuery(PortalDBEnum.TABLE_NAMES.devices);
		queryBuilder.appendQuery(" WHERE ");
		queryBuilder.appendQuery(PortalDBEnum.TABLE_NAMES.devices);
		queryBuilder.appendQuery(".");
		queryBuilder.appendQuery(PortalDBEnum.DEVICES.userId);
		queryBuilder.appendQuery(" = ");
		queryBuilder.appendQuery("?");
//		queryBuilder.appendQuery(PortalDatabaseEngine.getInstance().getConnection().formatString(userId));
		queryBuilder.appendQuery(" AND ");
		queryBuilder.appendQuery(PortalDBEnum.TABLE_NAMES.devices);
		queryBuilder.appendQuery(".");
		queryBuilder.appendQuery(PortalDBEnum.DEVICES.deviceStatus);
		queryBuilder.appendQuery(" != ");
		queryBuilder.appendQuery(Status.DELETED.ordinal());
		
		return queryBuilder.getQuery().toString();
		
	}

	private List<String> mListAllAppsOfDeviceByFilter(String deviceId, List<FilterObject> filters, List<String> deviceIds) 
	{
		//int offset = (pageNo - 1) * pageSize;
		StringBuilder sb = new StringBuilder();

		sb.append("SELECT SQL_CALC_FOUND_ROWS ");
		sb.append("app.*");
		sb.append(", dapp.");
		sb.append(PortalDBEnum.DEVICE_APPLICATIONS.deviceId);
		sb.append(", dapp.");
		sb.append(PortalDBEnum.DEVICE_APPLICATIONS.appVersionId);
		sb.append(", dev.");
		sb.append(PortalDBEnum.DEVICES.deviceName);

		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.deviceapplications);
		sb.append(" AS dapp");

		sb.append(" INNER JOIN ");
		sb.append(PortalDBEnum.TABLE_NAMES.application);
		sb.append(" AS app ON app.");
		sb.append(PortalDBEnum.APPLICATION.appId);
		sb.append(" = dapp.");
		sb.append(PortalDBEnum.DEVICE_APPLICATIONS.appId);

		sb.append(" INNER JOIN ");
		sb.append(PortalDBEnum.TABLE_NAMES.devices);
		sb.append(" AS dev ON dev.");
		sb.append(PortalDBEnum.DEVICES.deviceId);
		sb.append(" = dapp.");
		sb.append(PortalDBEnum.DEVICE_APPLICATIONS.deviceId);

		StringBuilder sortOrder = null;
		StringBuilder whereClause = null;

		String searchString = "";
		if (filters != null) {
			for (FilterObject filterObject : filters) {
				switch (filterObject.getFilterType()) {
				case SEARCHTEXT: // This case will be called only once in the
									// loop as there can only be one search
									// string and that will apply on application
									// title.

					whereClause = getWhereClause(whereClause);
					whereClause.append("app.");
					whereClause.append(PortalDBEnum.APPLICATION.title);

					if (filterObject.getOperator().ordinal() == Operator.LIKE.ordinal()) {
						// application title contains search text
						searchString = filterObject.getStartValue();
						whereClause.append(" LIKE ");
						whereClause.append("?");
//						whereClause.append(PortalDatabaseEngine.getInstance().getConnection().formatStringForLike(true,
//								searchString, true));
					} else if (filterObject.getOperator().ordinal() == Operator.EQUAL.ordinal()) {
						whereClause.append(" = ");
						whereClause.append("?");
//						whereClause.append(PortalDatabaseEngine.getInstance().getConnection()
//								.formatString(filterObject.getStartValue()));
					}

					break;
				case SORT: // This case is called once as there can only be one
							// sort order applied. Filter object should give
							// sort field to sort on in start value and sort
							// order in operator.
					sortOrder = new StringBuilder();
					sortOrder.append(" ORDER BY ");
					if (filterObject.getStartValue().trim().equals("title")) {

						// Here assuming that we will always add search filter
						// before the sort filter.
						if (searchString.equals("")) {
							sortOrder.append("app.");
							sortOrder.append(PortalDBEnum.APPLICATION.title);
						} else {
							// sort by best match : Exact equals first then
							// starts with, then contains and then ends with.
							sortOrder.append(" CASE WHEN ");
							sortOrder.append("app.");
							sortOrder.append(PortalDBEnum.APPLICATION.title);
							sortOrder.append(" = ");
							whereClause.append("?");
//							sortOrder.append(
//									PortalDatabaseEngine.getInstance().getConnection().formatString(searchString));
							sortOrder.append(" THEN 0 ");

							sortOrder.append(" WHEN ");
							sortOrder.append("app.");
							sortOrder.append(PortalDBEnum.APPLICATION.title);
							sortOrder.append(" LIKE ");
							whereClause.append("?");
//							sortOrder.append(PortalDatabaseEngine.getInstance().getConnection()
//									.formatStringForLike(false, searchString, true));
							sortOrder.append(" THEN 1 ");

							sortOrder.append(" WHEN ");
							sortOrder.append("app.");
							sortOrder.append(PortalDBEnum.APPLICATION.title);
							sortOrder.append(" LIKE ");
							whereClause.append("?");
//							sortOrder.append(PortalDatabaseEngine.getInstance().getConnection()
//									.formatStringForLike(true, searchString, false));
							sortOrder.append(" THEN 3 ");

							sortOrder.append(" ELSE 2 ");

							sortOrder.append(" END ");
						}
					} else if (filterObject.getStartValue().trim().equals("latest")) {
						sortOrder.append("dapp.");
						sortOrder.append(PortalDBEnum.DEVICE_APPLICATIONS.modifiedDate);
						filterObject.setOperator(Operator.DESC);
					}

					if (filterObject.getOperator().ordinal() == Operator.DESC.ordinal()) {
						sortOrder.append(" DESC");
					}
					break;
				default:
					break;
				}
			}
		}

		whereClause = getWhereClause(whereClause);
		if (!StringFunctions.isNullOrWhitespace(deviceId)) {
			whereClause.append("dapp.");
			whereClause.append(PortalDBEnum.DEVICE_APPLICATIONS.deviceId);
			whereClause.append(" = ");
			whereClause.append("?");
			//whereClause.append(PortalDatabaseEngine.getInstance().getConnection().formatString(deviceId));
		} else {
			whereClause.append(" dapp.");
			whereClause.append(PortalDBEnum.DEVICE_APPLICATIONS.deviceId);
			
			SqlQueryBuilder queryBuilder = new SqlQueryBuilder();
			queryBuilder.appendQueryIN(deviceIds);
			whereClause.append(queryBuilder.getQuery().toString());
//			whereClause.append(" IN (");
//			whereClause.append("Select ");
//			whereClause.append(PortalDBEnum.TABLE_NAMES.devices);
//			whereClause.append(".");
//			whereClause.append(PortalDBEnum.DEVICES.deviceId);
//			whereClause.append(" FROM ");
//			whereClause.append(PortalDBEnum.TABLE_NAMES.devices);
//			whereClause.append(" WHERE ");
//			whereClause.append(PortalDBEnum.TABLE_NAMES.devices);
//			whereClause.append(".");
//			whereClause.append(PortalDBEnum.DEVICES.userId);
//			whereClause.append(" = ");
//			whereClause.append(PortalDatabaseEngine.getInstance().getConnection().formatString(userId));
//			whereClause = getWhereClause(whereClause);
//			whereClause.append(PortalDBEnum.TABLE_NAMES.devices);
//			whereClause.append(".");
//			whereClause.append(PortalDBEnum.DEVICES.deviceStatus);
//			whereClause.append(" != ");
//			whereClause.append(Status.DELETED.ordinal());
//			whereClause.append(") ");
		}

		whereClause = getWhereClause(whereClause);
		whereClause.append("app.");
		whereClause.append(PortalDBEnum.APPLICATION.appStatus);
		whereClause.append(" != ");
		whereClause.append(Status.DELETED.ordinal());

		whereClause = getWhereClause(whereClause);
		whereClause.append("dapp.");
		whereClause.append(PortalDBEnum.DEVICE_APPLICATIONS.deviceAppstatus);
		whereClause.append(" != ");
		whereClause.append(Status.DELETED.ordinal());

		// Add where conditions
		sb.append(whereClause);

		// Add sort order
		if (sortOrder != null) {
			sb.append(sortOrder);
		}

		// Add paging
		sb.append(" limit ");
		sb.append("?");
//		sb.append(pageSize);
		sb.append("?");
		sb.append(" offset ");
//		sb.append(offset);

		queries.add(sb.toString());
		queries.add("SELECT FOUND_ROWS() as rowCount");
		return queries;
	}


	private StringBuilder getWhereClause(StringBuilder whereClause){
		if(whereClause == null){
			whereClause = new StringBuilder();
			whereClause.append(" WHERE ");						
		}
		else{
			whereClause.append(" AND ");
		}
		return whereClause;			
	}



	/**
	 * List invited application which user are invited on multiple groups.
	 * @param userId
	 * @param groupIds
	 * @return
	 */
	private String mListInvitedApps(int count) {
		SqlQueryBuilder queryBuilder = new SqlQueryBuilder();
		queryBuilder.appendQuery("Select ");
		queryBuilder.appendQuery("app.*");
		queryBuilder.appendQuery(" FROM ");
		queryBuilder.appendQuery(PortalDBEnum.TABLE_NAMES.groupapplications);
		queryBuilder.appendQuery(" AS groupapp ");
		queryBuilder.appendQuery(" INNER JOIN ");
		queryBuilder.appendQuery(PortalDBEnum.TABLE_NAMES.application);
		queryBuilder.appendQuery(" AS app ON app.");
		queryBuilder.appendQuery(PortalDBEnum.APPLICATION.appId);
		queryBuilder.appendQuery(" = groupapp.");
		queryBuilder.appendQuery(PortalDBEnum.DEVICE_APPLICATIONS.appId);
		queryBuilder.appendQuery(" WHERE ");
		queryBuilder.appendQuery(" groupapp.");
		queryBuilder.appendQuery(PortalDBEnum.GROUP_APPLICATIONS.groupId);

		queryBuilder.appendQueryIN(count);

		// queryBuilder.appendQuery(" IN (");
		// queryBuilder.appendQuery("?");
		// queryBuilder.appendQuery(getCommaSepratedString(groupIds));
		// queryBuilder.appendQuery(") ");
		queryBuilder.appendQuery(" AND ");
		queryBuilder.appendQuery(" app.");
		queryBuilder.appendQuery(PortalDBEnum.APPLICATION.appStatus);
		queryBuilder.appendQuery(" != ");
		queryBuilder.appendQuery(Status.DELETED.ordinal());
		queryBuilder.appendQuery(" GROUP BY ");
		queryBuilder.appendQuery(" app.");
		queryBuilder.appendQuery(PortalDBEnum.APPLICATION.appId);
		queryBuilder.appendQuery(" ORDER BY ");
		queryBuilder.appendQuery("app.");
		queryBuilder.appendQuery(PortalDBEnum.APPLICATION.title);
		queryBuilder.appendQuery(" ASC ");
		return queryBuilder.getQuery().toString();
	}

	/**
	 * getting deviceapplication info, all application which are installed by user on multiple devices.
	 * @param userId
	 * @return
	 */
	private List<String> mListDeviceApplicationForUser()  {
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT SQL_CALC_FOUND_ROWS ");	
		sb.append("app.*");
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.application);sb.append(" AS app ");
		sb.append(" INNER JOIN ");
		sb.append(PortalDBEnum.TABLE_NAMES.deviceapplications);
		sb.append(" AS deviceapp ON deviceapp."); sb.append(PortalDBEnum.DEVICE_APPLICATIONS.appId);
		sb.append(" = app."); sb.append(PortalDBEnum.APPLICATION.appId);
		sb.append(" WHERE ");
		sb.append(" deviceapp."); sb.append(PortalDBEnum.DEVICE_APPLICATIONS.deviceId);
		sb.append(" IN (");
		sb.append("Select ");sb.append(PortalDBEnum.TABLE_NAMES.devices);sb.append(".");sb.append(PortalDBEnum.DEVICES.deviceId);
		sb.append(" FROM ");sb.append(PortalDBEnum.TABLE_NAMES.devices);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.TABLE_NAMES.devices);sb.append(".");sb.append(PortalDBEnum.DEVICES.userId);sb.append(" = ");sb.append("?");
		sb.append(" AND ");
		sb.append(PortalDBEnum.TABLE_NAMES.devices);sb.append(".");sb.append(PortalDBEnum.DEVICES.deviceStatus);sb.append(" != ");sb.append(Status.DELETED.ordinal());
		sb.append(") ");
		sb.append(" AND ");
		sb.append(" app."); sb.append(PortalDBEnum.APPLICATION.appStatus);sb.append(" != ");sb.append(Status.DELETED.ordinal());
		queries.add(sb.toString());
		queries.add("SELECT FOUND_ROWS() as appCount");
		return queries;
	}

	/**
	 * This method gives comma separated string with sql formated of list of string.
	 * @param collectionOfStrings
	 * @return
	 */
//	private String getCommaSepratedString(List<String> collectionOfStrings){
//		StringBuilder result = new StringBuilder();
//		for(String string : collectionOfStrings) {
//			result.append(PortalDatabaseEngine.getInstance().getConnection().formatString(string));
//			result.append(",");
//		}
//		return result.length() > 0 ? result.substring(0, result.length() - 1): "";
//	}

	private String mGetApplicationStatusOnUserDevices(List<String> edgeCoreIds) {

		StringBuilder sb = new StringBuilder();
		/*
		 * Add deviceAppstatus check if DELETED then also give "install" action
		 * not "uninstall", because we maintain deviceApplication relation in db
		 * with status.
		 */

		sb.append("SELECT a.deviceName, a.deviceId, ")
				.append(" CASE WHEN (a.appId IS NULL OR a.deviceAppstatus = 3) THEN 'install' ")
				.append(" WHEN (b.versionStatus = 4 OR a.appVersionId='null' OR a.appVersionId IS NULL) THEN 'uninstall' ")
				.append(" ELSE 'update,uninstall' END ").append(" AS actions ").append(" FROM ")
				.append(" (select t1.appId, t2.deviceId, t2.deviceName, t1.appVersionId, t1.deviceAppstatus ")
				.append(" FROM ").append(" devices as t2 ").append(" LEFT JOIN deviceapplications AS t1 ")
				.append("ON (t2.deviceId=t1.deviceId and t1.appId = ")
				// PortalDatabaseEngine.getInstance().getConnection().formatString(appId)
				.append("?").append(")").append(" WHERE ").append(" t2.deviceStatus = ").append(Status.ACTIVE.ordinal())
				.append(" AND ").append(" (userId = ")
				// PortalDatabaseEngine.getInstance().getConnection().formatString(userId)
				// +
				.append("?").append(") ");

		if (edgeCoreIds != null && !edgeCoreIds.isEmpty()) {
			SqlQueryBuilder queryBuilder = new SqlQueryBuilder();
			queryBuilder.appendQuery(" Or t2.deviceId  ").appendQueryIN(edgeCoreIds).appendQuery(")");
			sb.append(queryBuilder.getQuery().toString());
		} else {
			sb.append(") ");
		}
		sb.append(" AS a ").append(" LEFT JOIN applicationversions AS b ")
				.append(" ON (a.appVersionId=b.appVersionId)");

		return sb.toString();
	}
	
	private String mGetAppVersionCommand(List<String> grpIds) {
		/*
		 * Add deviceAppstatus check if DELETED then also give "install" action
		 * not "uninstall", because we maintain deviceApplication relation in db
		 * with status.
		 */
		// resolved issue with update app on retain secrets

		SqlQueryBuilder queryBuilder = new SqlQueryBuilder();

		queryBuilder.appendQuery("SELECT a.deviceName, a.deviceId, ")
				.appendQuery(" CASE WHEN (a.appId IS NULL OR a.deviceAppstatus = 3) THEN 'install' ")
				.appendQuery(" WHEN ( a.appVersionID = ").appendQuery("?")
				// .appendQuery(PortalDatabaseEngine.getInstance().getConnection().formatString(appVersionId))
				.appendQuery(") THEN 'uninstall' ").appendQuery(" ELSE 'update'").appendQuery(" END AS actions ")
				.appendQuery(" FROM ")
				.appendQuery(" (SELECT t2.deviceName, t1.appId, t2.deviceId, t1.appVersionId, t1.deviceAppstatus ")
				.appendQuery(" FROM ").appendQuery(" devices AS t2 ").appendQuery(" LEFT JOIN ")
				.appendQuery(" deviceapplications AS t1 ").appendQuery(" ON (t2.deviceId=t1.deviceId AND t1.appId= ")
				.appendQuery("? )")
				// .appendQuery(PortalDatabaseEngine.getInstance().getConnection().formatString(appId)
				// + ") ")
				.appendQuery(" WHERE ").appendQuery(" t2.deviceStatus = 0").appendQuery(" AND ")
				.appendQuery(" (userId = ").appendQuery("?");
		// .appendQuery(PortalDatabaseEngine.getInstance().getConnection().formatString(userId));

		if (grpIds != null && !grpIds.isEmpty()) {
			queryBuilder.appendQuery(" OR ").appendQuery("t2.deviceId ").appendQueryIN(grpIds);
			// /******/.append(new
			// EdgeCoreGroupsDB().listEdgeCoreForGroups(grpIds))
			// /******/.append("))");
			queryBuilder.appendQuery(") ");
		} else {
			queryBuilder.appendQuery(") ");
		}
		queryBuilder.appendQuery(" ) AS a");

		return queryBuilder.getQuery().toString();

	}

	


	private String mIsAppUpdateAvilable(List<String> installedAppIds)
	{
		StringBuilder sb = new StringBuilder();
		
		SqlQueryBuilder queryBuilder = new SqlQueryBuilder();
		
		queryBuilder.appendQuery("SELECT IF (COUNT(*) = 0,0,1) as isUpdateAvailable , da.");
		queryBuilder.appendQuery(PortalDBEnum.DEVICE_APPLICATIONS.appId.name());
		queryBuilder.appendQuery(" as appId ");
		queryBuilder.appendQuery(", ");
		queryBuilder.appendQuery("av.");
		queryBuilder.appendQuery(PortalDBEnum.APPLICATION_VERSIONS.appVersionId.name());
		queryBuilder.appendQuery(" as appVersionId ");
		queryBuilder.appendQuery(" FROM ");
		queryBuilder.appendQuery(PortalDBEnum.TABLE_NAMES.deviceapplications);
		queryBuilder.appendQuery(" da");
		queryBuilder.appendQuery(" JOIN ");
		queryBuilder.appendQuery(PortalDBEnum.TABLE_NAMES.applicationversions);
		queryBuilder.appendQuery(" av");
		queryBuilder.appendQuery(" ON da.");
		queryBuilder.appendQuery(PortalDBEnum.DEVICE_APPLICATIONS.appId.name());
		queryBuilder.appendQuery(" = av.");
		queryBuilder.appendQuery(PortalDBEnum.APPLICATION_VERSIONS.appId.name());
		queryBuilder.appendQuery(" WHERE da.");
		queryBuilder.appendQuery(PortalDBEnum.DEVICE_APPLICATIONS.deviceId.name());
		queryBuilder.appendQuery(" = ");
		queryBuilder.appendQuery("?");
		//queryBuilder.appendQuery(PortalDatabaseEngine.getInstance().getConnection().formatString(deviceId));
		queryBuilder.appendQuery(" AND da.");
		queryBuilder.appendQuery(PortalDBEnum.DEVICE_APPLICATIONS.appId.name());
		queryBuilder.appendQueryIN(installedAppIds);
//		queryBuilder.appendQuery(" IN (");
//		queryBuilder.appendQuery(getCommaSepratedString(installedAppIds));
//		queryBuilder.appendQuery(" )");
		queryBuilder.appendQuery(" AND da.");
		queryBuilder.appendQuery(PortalDBEnum.DEVICE_APPLICATIONS.appVersionId.name());
		queryBuilder.appendQuery(" !=  av.");
		queryBuilder.appendQuery(PortalDBEnum.APPLICATION_VERSIONS.appVersionId.name());
		queryBuilder.appendQuery(" AND da.");
		queryBuilder.appendQuery(PortalDBEnum.DEVICE_APPLICATIONS.deviceAppstatus.name());
		queryBuilder.appendQuery(" = ");
		queryBuilder.appendQuery(Status.ACTIVE.ordinal());
		queryBuilder.appendQuery(" AND av.");
		queryBuilder.appendQuery(PortalDBEnum.APPLICATION_VERSIONS.versionStatus.name());
		queryBuilder.appendQuery(" = ");
		queryBuilder.appendQuery(VERSION_STATUS.LIVE.ordinal());
		queryBuilder.appendQuery(" AND av.");
		queryBuilder.appendQuery(PortalDBEnum.APPLICATION_VERSIONS.appPlatformId.name());
		queryBuilder.appendQuery(" = ");
		queryBuilder.appendQuery("?");
		//queryBuilder.appendQuery(PortalDatabaseEngine.getInstance().getConnection().formatString(appPlatformId));
		return sb.toString();
	}
}

/**
 * History of check-in or issue resolved
 * 
 * 01 - 14-11-2016 AKH_01
 * Add restRedirectUrl, redirectUrl, redirectType and redirectSection these property shift from application to applicationVersion,
 * because may be each version have different redirection param.
 */