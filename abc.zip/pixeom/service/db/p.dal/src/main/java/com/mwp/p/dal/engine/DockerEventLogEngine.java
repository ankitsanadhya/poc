/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal.engine;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.mwp.common.Common;
import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.common.constant.Constant;
import com.mwp.common.vo.DockerEventVO;
import com.mwp.common.vo.QueryVO;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.common.enums.PortalDBEnum.DOCKER_EVENT_LOG;
import com.mwp.p.dal.DockerEventLogDB;

/**
 * This class execute queries related to table {@link DOCKER_EVENT_LOG}
 *
 */
public class DockerEventLogEngine {
	/**
	 * Add list of docker event logs
	 * 
	 * @param events
	 * @return
	 * @throws SQLException
	 */
	public List<String> insert(List<DockerEventVO> events) throws SQLException {
		return mInsert(events);
	}

	/**
	 * add new docker event log
	 * 
	 * @param appId
	 * @param versionId
	 * @param deviceId
	 * @param event
	 * @param systemStatus
	 * @param createdDate
	 * @throws SQLException
	 */
	public void insert(String appId, String versionId, String deviceId, String event, String systemStatus,
			long createdDate) throws SQLException {
		mInsert(appId, versionId, deviceId, event, systemStatus, createdDate);
	}

	/**
	 * List all logs for an application
	 * 
	 * @param appId
	 * @return
	 * @throws SQLException
	 */
	public List<DockerEventVO> listEvent(String appId) throws SQLException {
		return mListEvent(appId);
	}

	/**
	 * List docker event for last number of days
	 * 
	 * @param numberofdays
	 * @return List<DockerEventVO>
	 * @throws SQLException
	 */
	public List<DockerEventVO> listByTime(int numberofdays) throws SQLException {
		return mListByTime(numberofdays);
	}

	/**
	 * List docker event with paging
	 * 
	 * @param pageNum
	 * @param appId
	 * @param pageSize
	 * @return HashMap<String, Object>
	 * @throws SQLException
	 */
	public Map<String, Object> listByPage(int pageNum, String appId, int pageSize) throws SQLException {
		return mListByPage(pageNum, appId, pageSize);
	}

	private void mInsert(String appId, String versionId, String deviceId, String event, String systemStatus,
			long createdDate) throws SQLException {
		DockerEventLogDB dbObj = new DockerEventLogDB();

		String insertQry = dbObj.insert();
		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(insertQry)
						.addParameter(Common.getRandomId()).addParameter(appId).addParameter(versionId)
						.addParameter(deviceId).addParameter(event).addParameter(systemStatus).addParameter(createdDate)
						.build();

		PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
	}

	private List<String> mInsert(List<DockerEventVO> events) throws SQLException {
		List<String> logIds = new ArrayList<>();
		List<QueryVO> insertQueries = new ArrayList<>();
		DockerEventLogDB dbObj = new DockerEventLogDB();

		for (DockerEventVO eventObj : events) {
			String insertQry = dbObj.insert();
			QueryVO queryVO = new SqlQueryBuilder(
					PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
							.appendQuery(insertQry).addParameter(Common.getRandomId())
							.addParameter(eventObj.getApplicationId()).addParameter(eventObj.getVersionId())
							.addParameter(eventObj.getDeviceId()).addParameter(eventObj.getDockerEvent())
							.addParameter(new Gson().toJson(eventObj.getSystemStatus()))
							.addParameter(eventObj.getCreatedDate()).build();
			insertQueries.add(queryVO);

			// insertQueries.add(dbObj.insert(eventObj.getApplicationId(),
			// eventObj.getVersionId(), eventObj.getDeviceId(),
			// eventObj.getDockerEvent(), new
			// Gson().toJson(eventObj.getSystemStatus()),
			// eventObj.getCreatedDate()))

			logIds.add(eventObj.getLogId());
		}

		if (!insertQueries.isEmpty()) {
			PortalDatabaseEngine.getInstance().getConnection().executeUpdatesInTransaction(insertQueries);
		}
		return logIds;
	}

	private List<DockerEventVO> mListEvent(String appId) throws SQLException {
		List<DockerEventVO> lst = new ArrayList<>();
		DockerEventLogDB dbObj = new DockerEventLogDB();

		String sql = dbObj.list();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(appId).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				lst.add(parseEventResult(rs));
			}
		}
		return lst;
	}

	private DockerEventVO parseEventResult(ResultSet rs) throws SQLException {
		DockerEventVO eventVo = new DockerEventVO();
		eventVo.setLogId(rs.getString(PortalDBEnum.DOCKER_EVENT_LOG.id.name()));
		eventVo.setApplicationId(rs.getString(PortalDBEnum.DOCKER_EVENT_LOG.applicationId.name()));
		eventVo.setVersionId(rs.getString(PortalDBEnum.DOCKER_EVENT_LOG.versionId.name()));
		eventVo.setDeviceId(rs.getString(PortalDBEnum.DOCKER_EVENT_LOG.deviceId.name()));
		eventVo.setCreatedDate(rs.getTimestamp(PortalDBEnum.DOCKER_EVENT_LOG.createdDate.name()).getTime());

		String systemStatus = rs.getString(PortalDBEnum.DOCKER_EVENT_LOG.systemStatus.name());
		eventVo.setSystemStatus(new Gson().fromJson(systemStatus, new TypeToken<HashMap<String, Object>>() {
		}.getType()));

		eventVo.setDockerEvent(rs.getString(PortalDBEnum.DOCKER_EVENT_LOG.event.name()));
		return eventVo;
	}

	private List<DockerEventVO> mListByTime(int numberofdays) throws SQLException {
		List<DockerEventVO> lst = new ArrayList<>();
		DockerEventLogDB dbObj = new DockerEventLogDB();

		String lstQry = dbObj.listByTime();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(lstQry)
						.addParameter(numberofdays).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				lst.add(parseEventResult(rs));
			}
		}
		return lst;
	}

	private HashMap<String, Object> mListByPage(int pageNum, String appId, int queryLimit) throws SQLException {
		List<DockerEventVO> lst = new ArrayList<>();
		HashMap<String, Object> hashOutput = new HashMap<>();
		DockerEventLogDB dbObj = new DockerEventLogDB();

		int totalAppEvents = 0;
		int offset = (pageNum - 1) * queryLimit;
		List<String> lstQry = dbObj.listByPaging();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
						.appendQuery(lstQry.get(0)).addParameter(appId).addParameter(queryLimit).addParameter(offset)
						.build();

		QueryVO countQueryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
						.appendQuery(lstQry.get(1)).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO);
				ResultSet rsCount = PortalDatabaseEngine.getInstance().getConnection().executeQuery(countQueryVO)) {
			while (rsCount.next()) {
				if (totalAppEvents <= 0) {
					/*
					 * getting total no of rows without page limit.
					 */
					totalAppEvents = rsCount.getInt("eventCount");
				}
			}
			while (rs.next()) {
				lst.add(parseEventResult(rs));
			}
		}
		int totalPages = totalAppEvents / queryLimit;
		if ((totalAppEvents % queryLimit) > 0) {
			totalPages += 1;
		}
		hashOutput.put(Constant.DATA, lst);
		hashOutput.put("totalPages", totalPages);
		hashOutput.put("pageNo", pageNum);
		hashOutput.put("pageSize", queryLimit);
		return hashOutput;
	}
}
