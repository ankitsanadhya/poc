/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal.engine;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.mwp.common.Common;
import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.common.constant.Constant;
import com.mwp.common.enums.RuleStatus;
import com.mwp.common.enums.RuleType;
import com.mwp.common.vo.QueryVO;
import com.mwp.common.vo.RuleTriggerLogVO;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.dal.RuleTriggerLogDB;

/**
 * This class execute queries related to table {@link ACTIVITY_LOG_LOG}
 *
 */
public class RuleTriggerLogEngine {

	/**
	 * add new activity event log
	 * 
	 * @param appId
	 * @param versionId
	 * @param deviceId
	 * @param event
	 * @param systemStatus
	 * @param createdDate
	 * @throws SQLException
	 */
	public String insert(String ruleId, RuleStatus status, String data) throws SQLException {
		return mInsert(ruleId, status, data);
	}

	/**
	 * List all logs for an application
	 * 
	 * @param appId
	 * @return
	 * @throws SQLException
	 */
	public List<RuleTriggerLogVO> list() throws SQLException {
		return mListEvent();
	}

	/**
	 * List acticity event for last number of days
	 * 
	 * @param numberofdays
	 * @return List<acticityEventVO>
	 * @throws SQLException
	 */
	public List<RuleTriggerLogVO> listByTime(int numberofdays) throws SQLException {
		return mListByTime(numberofdays);
	}

	public RuleTriggerLogVO update(String id, RuleStatus status, int stage, String info) throws SQLException {
		return mUpdate(id, status, stage, info);
	}

	/**
	 * List acticity event wih paging
	 * 
	 * @param pageNum
	 * @param appId
	 * @param pageSize
	 * @return HashMap<String, Object>
	 * @throws SQLException
	 */
	public Map<String, Object> listByPage(int pageNum, int pageSize) throws SQLException {
		return mListByPage(pageNum, pageSize);
	}

	public RuleTriggerLogVO getlog(String id) throws SQLException {

		return mgetLog(id);

	}

	public RuleTriggerLogVO getLatestrec(String ruleId) throws SQLException {
		return mgetLatestrec(ruleId);
	}

	public List<RuleTriggerLogVO> list(RuleType type) throws SQLException {
		return mList(type);
	}

	public List<RuleTriggerLogVO> listlog() throws SQLException {
		return mListlog();
	}

	private List<RuleTriggerLogVO> mListlog() throws SQLException {

		List<RuleTriggerLogVO> lst = new ArrayList<>();
		RuleTriggerLogDB dbObj = new RuleTriggerLogDB();
		String lstQry = dbObj.mListlog();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(lstQry)
						.build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				lst.add(parseEventResult(rs));
			}
		}
		return lst;
	}

	private List<RuleTriggerLogVO> mList(RuleType type) throws SQLException {
		List<RuleTriggerLogVO> lst = new ArrayList<>();
		RuleTriggerLogDB dbObj = new RuleTriggerLogDB();
		String lstQry = dbObj.mListFromType();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(lstQry)
						.addParameter(type).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				lst.add(parseEventResult(rs));
			}
		}
		return lst;
	}

	private RuleTriggerLogVO mgetLatestrec(String ruleId) throws SQLException {

		RuleTriggerLogVO vo = null;
		RuleTriggerLogDB dbObj = new RuleTriggerLogDB();
		String lstQry = dbObj.getLatestrec();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(lstQry)
						.addParameter(ruleId).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				vo = parseEventResult(rs);
			}
		}
		return vo;
	}

	private RuleTriggerLogVO mgetLog(String id) throws SQLException {

		RuleTriggerLogVO vo = new RuleTriggerLogVO();
		RuleTriggerLogDB dbObj = new RuleTriggerLogDB();
		String lstQry = dbObj.get();
		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(lstQry)
						.addParameter(id).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				vo = parseEventResult(rs);
			}
		}
		return vo;
	}

	private String mInsert(String ruleId, RuleStatus status, String data) throws SQLException {
		RuleTriggerLogDB dbObj = new RuleTriggerLogDB();
		String id = Common.getRandomId();

		String insertQry = dbObj.insert();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(insertQry)
						.addParameter(id).addParameter(ruleId).addParameter(status).addParameter(data).build();

		PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
		return id;
	}

	private List<RuleTriggerLogVO> mListEvent() throws SQLException {
		List<RuleTriggerLogVO> lst = new ArrayList<>();
		RuleTriggerLogDB dbObj = new RuleTriggerLogDB();
		String lstQry = dbObj.list();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(lstQry)
						.build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				lst.add(parseEventResult(rs));
			}
		}
		return lst;
	}

	private RuleTriggerLogVO parseEventResult(ResultSet rs) throws SQLException {
		RuleTriggerLogVO eventVo = new RuleTriggerLogVO();
		eventVo.setId(rs.getString(PortalDBEnum.RULE_TRIGGER_LOG.id.name()));
		eventVo.setRuleId(rs.getString(PortalDBEnum.RULE_TRIGGER_LOG.ruleId.name()));
		eventVo.setStatus(RuleStatus.GetEnum(rs.getInt(PortalDBEnum.RULE_TRIGGER_LOG.status.name())));
		eventVo.setStartTime(rs.getTimestamp(PortalDBEnum.RULE_TRIGGER_LOG.startTime.name()).getTime());
		eventVo.setEndTime(rs.getTimestamp(PortalDBEnum.RULE_TRIGGER_LOG.endTime.name()).getTime());
		eventVo.setStage(rs.getInt(PortalDBEnum.RULE_TRIGGER_LOG.stage.name()));
		eventVo.setInfo(rs.getString(PortalDBEnum.RULE_TRIGGER_LOG.info.name()));

		return eventVo;
	}

	private List<RuleTriggerLogVO> mListByTime(int numberofdays) throws SQLException {
		List<RuleTriggerLogVO> lst = new ArrayList<>();
		RuleTriggerLogDB dbObj = new RuleTriggerLogDB();
		String lstQry = dbObj.listByTime();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(lstQry)
						.addParameter(numberofdays).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				lst.add(parseEventResult(rs));
			}
		}
		return lst;
	}

	private Map<String, Object> mListByPage(int pageNum, int queryLimit) throws SQLException {
		List<RuleTriggerLogVO> lst = new ArrayList<>();
		HashMap<String, Object> hashOutput = new HashMap<>();
		RuleTriggerLogDB dbObj = new RuleTriggerLogDB();

		int totalAppEvents = 0;

		int offset = (pageNum - 1) * queryLimit;

		List<String> lstQry = dbObj.listFilter();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
						.appendQuery(lstQry.get(0)).addParameter(queryLimit).addParameter(offset).build();

		QueryVO queryVOCount = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
						.appendQuery(lstQry.get(1)).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO);
				ResultSet rsCount = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVOCount)) {
			while (rsCount.next()) {
				if (totalAppEvents <= 0) {
					/*
					 * getting total no of rows without page limit.
					 */
					totalAppEvents = rsCount.getInt("eventCount");
				}
			}
			while (rs.next()) {
				lst.add(parseEventResult(rs));
			}
		}
		int totalPages = totalAppEvents / queryLimit;
		if ((totalAppEvents % queryLimit) > 0) {
			totalPages += 1;
		}
		hashOutput.put(Constant.DATA, lst);
		hashOutput.put("totalPages", totalPages);
		hashOutput.put("pageNo", pageNum);
		hashOutput.put("pageSize", queryLimit);
		return hashOutput;
	}

	private RuleTriggerLogVO mUpdate(String id, RuleStatus status, int stage, String info) throws SQLException {
		RuleTriggerLogDB ruleDalObj = new RuleTriggerLogDB();
		String sql = ruleDalObj.update();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(status.ordinal()).addParameter(stage).addParameter(info).addParameter(id).build();

		PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);

		return mgetLog(id);
	}
}
