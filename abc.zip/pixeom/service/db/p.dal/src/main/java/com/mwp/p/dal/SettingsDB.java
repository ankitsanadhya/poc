/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.mwp.p.dal;

import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.common.enums.PortalDBEnum.SETTINGS;
import com.mwp.p.common.enums.PortalDBEnum.SETTINGS_KEY;

public class SettingsDB {

	private String tableName = "";

	public SettingsDB() {
		tableName = PortalDBEnum.TABLE_NAMES.settings.name();
	}

	/**
	 * Query for getting all settings.
	 * 
	 * @return select query.
	 */
	public String getSettings() {
		return mGetSettings();
	}

	/**
	 * Query for getting setting value of given param {@link SETTINGS_KEY} -
	 * key.
	 * 
	 * @param key
	 *            {@link SETTINGS_KEY}
	 * @return
	 */
	public String getSettingValue() {
		return mGetSettingsValue();
	}

	public String setSettingsValue() {
		return mSetSettingsValue();
	}

	public String setSettingsValues() {
		return mSetSettingsValues();
	}

	private String mGetSettings() {
		StringBuilder sb = new StringBuilder();

		sb.append("Select *");
		sb.append(" FROM ");
		sb.append(tableName);

		return sb.toString();
	}

	private String mGetSettingsValue() {
		StringBuilder sb = new StringBuilder();

		sb.append("Select ");
		sb.append(SETTINGS.settingsValue);
		sb.append(" FROM ");
		sb.append(tableName);

		sb.append(" WHERE ");

		sb.append(SETTINGS.settingsKey);
		sb.append(" = ");
		sb.append("?");

		return sb.toString();
	}

	private String mSetSettingsValue() {

		StringBuilder sb = new StringBuilder();

		sb.append("Insert");
		sb.append(" INTO ");
		sb.append(tableName);

		sb.append(" ( ");
		sb.append(SETTINGS.settingsKey);
		sb.append(",");
		sb.append(SETTINGS.settingsValue);
		sb.append(" ) ");
		sb.append(" VALUES ");
		sb.append(" (");
		sb.append("?");
		// sb.append(dbCon.formatString(key.name()));
		sb.append(",");
		sb.append("?");
		// sb.append(dbCon.formatString(value));
		sb.append(")");

		sb.append(" ON DUPLICATE KEY UPDATE ");
		sb.append(SETTINGS.settingsValue.name());
		sb.append(" = ");
		sb.append("?");
		// sb.append(dbCon.formatString(value));

		return sb.toString();
	}

	private String mSetSettingsValues() {
		StringBuilder sb;
		// for (Map.Entry<SETTINGS_KEY,String> entry : settings.entrySet())
		// {
		sb = new StringBuilder();
		sb.append("Insert");
		sb.append(" INTO ");
		sb.append(tableName);
		sb.append(" ( ");
		sb.append(SETTINGS.settingsKey);
		sb.append(",");
		sb.append(SETTINGS.settingsValue);
		sb.append(" ) ");
		sb.append(" VALUES ");
		sb.append(" (");
		sb.append("?");
		sb.append(",");
		sb.append("?");
		sb.append(")");
		sb.append(" ON DUPLICATE KEY UPDATE ");
		sb.append(SETTINGS.settingsValue.name());
		sb.append(" = ");
		sb.append("?");
		// }
		return sb.toString();
	}
}
