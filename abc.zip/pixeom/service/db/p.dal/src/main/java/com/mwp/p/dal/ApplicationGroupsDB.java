/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal;

import java.util.ArrayList;
import java.util.List;

import com.mwp.common.StringFunctions;
import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.common.enums.Status;
import com.mwp.p.common.enums.PortalDBEnum;

/**
 * This class manage application group, list of group application, add application to group,
 * add application to group with version list, remove application-group relation, and update application version(add/delete).
 * @author root
 *
 */
public class ApplicationGroupsDB {

	/**
	 * List group of application according to groupId.
	 * @param groupId
	 * @return
	 */
	public String listGroupApp() {
		return mListGroupApp();
	}

	/**
	 * add application group relation in applicationGroup table.
	 * @param appId
	 * @param groupId
	 * @return
	 */
	public String addAppToGroup() {
		return mAddAppToGroup();
	}

	/**
	 * add application-group entry in applicationgroup table and
	 * also add app-version relation in applicationversion table.
	 * @param appId
	 * @param groupId
	 * @param versionIds
	 * @return
	 */
	public List<String> addAppToGroupWithVersion() {
		return mAddAppToGroupWithVersion();
	} 

	/**
	 * remove application-group relation from applicationgroup table.
	 * @param appId
	 * @param groupId
	 * @return
	 */
	public List<String> removeAppFromGroup(String appId) {
		return mRemoveAppFromGroup(appId); 
	}

	/**
	 * update application-version relation add/delete applicationversion entry according to versionIds list.
	 * @param groupAppId
	 * @param addVersionIds
	 * @param deleteVersionIds
	 * @return
	 */
	public List<String> updateGroupVersion(List<String> deleteVersionIds) {
		return mUpdateGroupVersion(deleteVersionIds);
	}

	/**
	 * get groupAppId of applicationGroup according to appId,groupId combination.
	 * @param groupId
	 * @return
	 */
	public String getGroupAppId() {
		return mGetGroupAppId();
	}

	/**
	 * get list of groups of requested app
	 * @param appId
	 * @return
	 */
	public String getGroupsOfApp(String appId, List<String> groupIds) {
		return mGetGroupsOfApp(appId, groupIds);
	}

	private String mGetGroupsOfApp(String appId, List<String> groupIds) {
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT ").append(PortalDBEnum.GROUP_APPLICATIONS.groupId.name()).append(" FROM ")
				.append(PortalDBEnum.TABLE_NAMES.groupapplications).append(" WHERE ")
				.append(PortalDBEnum.GROUP_APPLICATIONS.appId.name()).append(" = ").append("?");
		// .append(dbCon.formatString(appId));
		if (groupIds != null && !groupIds.isEmpty()) {
			sb.append(" AND ").append(PortalDBEnum.GROUP_APPLICATIONS.groupId.name());
			SqlQueryBuilder builder = new SqlQueryBuilder();
			builder.appendQueryIN(groupIds);

			sb.append(builder.getQuery().toString());
			// .append(" IN (").append("?")
			// .append(")");
		}

		return sb.toString();
	}


	private String mGetGroupAppId() {
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT ");
		sb.append(PortalDBEnum.GROUP_APPLICATIONS.groupAppId.name());
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.groupapplications);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.GROUP_APPLICATIONS.appId.name());
		sb.append(" = ");
		sb.append("?");
		//sb.append(dbCon.formatString(appId));
		sb.append(" AND ");
		sb.append(PortalDBEnum.GROUP_APPLICATIONS.groupId.name());
		sb.append(" = ");
		sb.append("?");
		//sb.append(dbCon.formatString(groupId));
		return sb.toString();
	}

	private String mListGroupApp() {
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT ");
		sb.append(PortalDBEnum.TABLE_NAMES.application);sb.append(".* ");
		sb.append(", appplatform." + PortalDBEnum.APPLICATION_PLATFORM.appPlatformId);
		sb.append(", appplatform." + PortalDBEnum.APPLICATION_PLATFORM.platformId);
		sb.append(", appplatform." + PortalDBEnum.APPLICATION_PLATFORM.repositoryName);
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.application);
		sb.append(" LEFT JOIN ");
		sb.append(PortalDBEnum.TABLE_NAMES.applicationplatform);sb.append(" AS appplatform ON appplatform.");
		sb.append(PortalDBEnum.APPLICATION_PLATFORM.appId);
		sb.append(" = ");sb.append(PortalDBEnum.TABLE_NAMES.application);sb.append(".");sb.append(PortalDBEnum.APPLICATION.appId);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.TABLE_NAMES.application);
		sb.append(".");
		sb.append(PortalDBEnum.APPLICATION.appId.name());
		sb.append(" IN ( SELECT ");
		sb.append(PortalDBEnum.TABLE_NAMES.groupapplications);
		sb.append(".");
		sb.append(PortalDBEnum.GROUP_APPLICATIONS.appId.name());
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.groupapplications);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.GROUP_APPLICATIONS.groupId.name());sb.append(" = ");
		sb.append("?");
		//sb.append(dbCon.formatString(groupId));
		/*
		 * Add app status check (that only those app retrieve which have other status except DELETED)
		 */
		sb.append(" AND ");
		sb.append(PortalDBEnum.APPLICATION.appStatus);sb.append(" != ");sb.append(Status.DELETED.ordinal());
		sb.append(" ) ");
		sb.append(" ORDER By ");
		sb.append(PortalDBEnum.TABLE_NAMES.application);sb.append(".");sb.append(PortalDBEnum.APPLICATION.title.name());sb.append(" ASC ");
		return sb.toString();
	}

	private String mAddAppToGroup() {
		StringBuilder sb = new StringBuilder();
		sb.append("INSERT INTO ");
		sb.append(PortalDBEnum.TABLE_NAMES.groupapplications);
		sb.append(" ( ");
		sb.append(PortalDBEnum.GROUP_APPLICATIONS.groupAppId.name());
		sb.append(", ");
		sb.append(PortalDBEnum.GROUP_APPLICATIONS.groupId.name());
		sb.append(", ");
		sb.append(PortalDBEnum.GROUP_APPLICATIONS.appId.name());
		sb.append(" ) VALUES ( ");
		sb.append("?");
		//sb.append(dbCon.formatString(Common.getRandomId()));
		sb.append(", ");
		sb.append("?");
		//sb.append(dbCon.formatString(groupId));
		sb.append(", ");
		sb.append("?");
		//sb.append(dbCon.formatString(appId));
		sb.append(" ) ");
		return sb.toString();
	}

	private ArrayList<String> mAddAppToGroupWithVersion() {
		ArrayList<String> listQuery = new ArrayList<>();
		
		StringBuilder sb = new StringBuilder();
		sb.append("INSERT INTO ");
		sb.append(PortalDBEnum.TABLE_NAMES.groupapplications);
		sb.append(" ( ");
		sb.append(PortalDBEnum.GROUP_APPLICATIONS.groupAppId.name());
		sb.append(", ");
		sb.append(PortalDBEnum.GROUP_APPLICATIONS.groupId.name());
		sb.append(", ");
		sb.append(PortalDBEnum.GROUP_APPLICATIONS.appId.name());
		sb.append(" ) VALUES ( ");
		sb.append("?");
		//sb.append(dbCon.formatString(groupAppId));
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(groupId));
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(appId));
		sb.append(" ) ");
		listQuery.add(sb.toString());
		
		//for (String appVersionId : versionIds) {
			sb = new StringBuilder();
			sb.append("INSERT INTO ");
			sb.append(PortalDBEnum.TABLE_NAMES.groupapplicationversions);
			sb.append(" ( ");
			sb.append(PortalDBEnum.GROUP_APPLICATION_VERSIONS.groupAppVersionId.name());
			sb.append(", ");
			sb.append(PortalDBEnum.GROUP_APPLICATION_VERSIONS.groupAppId.name());
			sb.append(", ");
			sb.append(PortalDBEnum.GROUP_APPLICATION_VERSIONS.appVersionId.name());
			sb.append(" ) VALUES ( ");
			sb.append("?");
			//sb.append(dbCon.formatString(Common.getRandomId()));
			sb.append(", ");
			sb.append("?");
//			sb.append(dbCon.formatString(groupAppId));
			sb.append(", ");
			sb.append("?");
//			sb.append(dbCon.formatString(appVersionId));
			sb.append(" ) ");
			listQuery.add(sb.toString());
		//}
		return listQuery;
	}

	private ArrayList<String> mUpdateGroupVersion(List<String> deleteVersionIds) {
		ArrayList<String> listQuery = new ArrayList<>();

		SqlQueryBuilder queryBuilder = new SqlQueryBuilder();

		if (!deleteVersionIds.isEmpty()) {
			queryBuilder.appendQuery("DELETE ");
			queryBuilder.appendQuery(" FROM ");
			queryBuilder.appendQuery(PortalDBEnum.TABLE_NAMES.groupapplicationversions);
			queryBuilder.appendQuery(" WHERE ");
			queryBuilder.appendQuery(PortalDBEnum.GROUP_APPLICATION_VERSIONS.appVersionId.name());

			queryBuilder.appendQueryIN(deleteVersionIds);
			// queryBuilder.appendQuery(" IN ( ");
			// queryBuilder.appendQuery(dbCon.formatStringForIn(deleteVersionIds));
			// queryBuilder.appendQuery(" ) ");

			queryBuilder.appendQuery(" AND ");
			queryBuilder.appendQuery(PortalDBEnum.GROUP_APPLICATIONS.groupAppId.name());
			queryBuilder.appendQuery(" = ");
			queryBuilder.appendQuery("?");
			// queryBuilder.appendQuery(dbCon.formatString(groupAppId));
			listQuery.add(queryBuilder.getQuery().toString());
		} else {
			listQuery.add("");
		}

		// for (String appVersionId : addVersionIds) {
		// sb = new StringBuilder();
		queryBuilder = new SqlQueryBuilder();
		queryBuilder.appendQuery("INSERT INTO ");
		queryBuilder.appendQuery(PortalDBEnum.TABLE_NAMES.groupapplicationversions);
		queryBuilder.appendQuery(" ( ");
		queryBuilder.appendQuery(PortalDBEnum.GROUP_APPLICATION_VERSIONS.groupAppVersionId.name());
		queryBuilder.appendQuery(", ");
		queryBuilder.appendQuery(PortalDBEnum.GROUP_APPLICATION_VERSIONS.groupAppId.name());
		queryBuilder.appendQuery(", ");
		queryBuilder.appendQuery(PortalDBEnum.GROUP_APPLICATION_VERSIONS.appVersionId.name());
		queryBuilder.appendQuery(" ) VALUES ( ");
		queryBuilder.appendQuery("?");
		// sb.append(dbCon.formatString(Common.getRandomId()));
		queryBuilder.appendQuery(", ");
		queryBuilder.appendQuery("?");
		// sb.append(dbCon.formatString(groupAppId));
		queryBuilder.appendQuery(", ");
		queryBuilder.appendQuery("?");
		// sb.append(dbCon.formatString(appVersionId));
		queryBuilder.appendQuery(" ) ");
		listQuery.add(queryBuilder.getQuery().toString());
		// }
		return listQuery;
	}

	private ArrayList<String> mRemoveAppFromGroup(String appId) {
		ArrayList<String> listQuery = new ArrayList<>();
		listQuery.add(getQueryForRemoveGroupAppVersion(appId));
		listQuery.add(getQueryForRemoveGroupApp(appId));
		return listQuery;
	}

	private String getQueryForRemoveGroupAppVersion(String appId){
		StringBuilder sb = new StringBuilder();
		sb.append("DELETE ");
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.groupapplicationversions);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.TABLE_NAMES.groupapplicationversions);
		sb.append(".");
		sb.append(PortalDBEnum.GROUP_APPLICATION_VERSIONS.groupAppId.name());
		sb.append(" IN ( SELECT ");
		sb.append(PortalDBEnum.TABLE_NAMES.groupapplications);
		sb.append(".");
		sb.append(PortalDBEnum.GROUP_APPLICATIONS.groupAppId.name());
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.groupapplications);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.GROUP_APPLICATIONS.groupId.name());
		sb.append(" = ");
		sb.append("?");
//		sb.append(dbCon.formatString(groupId));
		//app id will be blank in case of delete group(where all apps version in group are to be removed from group)
		if(!StringFunctions.isNullOrWhitespace(appId))
		{
			sb.append(" AND ");
			sb.append(PortalDBEnum.GROUP_APPLICATIONS.appId.name());
			sb.append(" = ");
			sb.append("?");
//			sb.append(dbCon.formatString(appId));
		}
		
		sb.append(" ) ");
		return sb.toString();
	}

	private String getQueryForRemoveGroupApp(String appId) {
		StringBuilder sb = new StringBuilder();
		sb.append("DELETE ");
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.groupapplications);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.GROUP_APPLICATIONS.groupId.name());
		sb.append(" = ");
		sb.append("?");
		// sb.append(dbCon.formatString(groupId));
		// app id will be blank in case of delete group(where all apps in group
		// are to be removed from group)
		if (!StringFunctions.isNullOrWhitespace(appId)) {
			sb.append(" AND ");
			sb.append(PortalDBEnum.GROUP_APPLICATIONS.appId.name());
			sb.append(" = ");
			sb.append(" ? ");
			// sb.append(dbCon.formatString(appId));
		}
		return sb.toString();
	}
}
