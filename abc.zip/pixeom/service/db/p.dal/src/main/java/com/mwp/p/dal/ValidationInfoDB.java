/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal;

import com.mwp.p.common.enums.PortalDBEnum;

/**
 * This class manages validation info.add, delete, update and get validation info. 
 * @author root
 *
 */
public class ValidationInfoDB {

	/*
	 * add ValidationInfo to table.On duplicate key updates following columns sGUIDm, nStatus, nTimestamp, sInternetAddress, sCode, nPreviousTS.
	 */
	public String addValidationInfo() {

		StringBuilder sb = new StringBuilder();
		sb.append("INSERT INTO ");
		sb.append(PortalDBEnum.TABLE_NAMES.validationInfo.name());
		sb.append(" ( ");
		sb.append(PortalDBEnum.VALIDATION_INFO.sMACAddress.name());
		sb.append(", ");
		sb.append(PortalDBEnum.VALIDATION_INFO.sGUID.name());
		sb.append(", ");
		sb.append(PortalDBEnum.VALIDATION_INFO.nStatus.name());
		sb.append(", ");
		sb.append(PortalDBEnum.VALIDATION_INFO.nTimestamp.name());
		sb.append(", ");
		sb.append(PortalDBEnum.VALIDATION_INFO.sInternetAddress.name());
		sb.append(", ");
		sb.append(PortalDBEnum.VALIDATION_INFO.sCode.name());
		sb.append(", ");
		sb.append(PortalDBEnum.VALIDATION_INFO.nPreviousTS.name());
		sb.append(" ) VALUES (");
		sb.append("?");
		//sb.append(dbCon.formatString(infoVO.getsMACAddress()));
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(infoVO.getsGUID()));
		sb.append(", ");
		sb.append("?");
//		sb.append(infoVO.getnStatus());
		sb.append(", ");
		sb.append("?");
//		sb.append(infoVO.getnTimestamp());
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(infoVO.getsInternetAddress()));
		sb.append(", ");
		sb.append("?");
//		sb.append(0);
		sb.append(", ");
		sb.append("?");
//		sb.append(infoVO.getnPreviousTS());
		sb.append(" ) ");
		sb.append(" ON DUPLICATE KEY UPDATE ");
		sb.append(PortalDBEnum.VALIDATION_INFO.sGUID.name());
		sb.append(" = ");
		sb.append("?");
		//sb.append(dbCon.formatString(infoVO.getsGUID()));
		sb.append(",");
		sb.append(PortalDBEnum.VALIDATION_INFO.nStatus.name());
		sb.append(" = ");
		sb.append("?");
		//sb.append(infoVO.getnStatus());
		sb.append(",");
		sb.append(PortalDBEnum.VALIDATION_INFO.nTimestamp.name());
		sb.append(" = ");
		sb.append("?");
		//sb.append(infoVO.getnTimestamp());
		sb.append(",");
		sb.append(PortalDBEnum.VALIDATION_INFO.sInternetAddress.name());
		sb.append(" = ");
		sb.append("?");
		//sb.append(dbCon.formatString(infoVO.getsInternetAddress()));
		sb.append(",");
		sb.append(PortalDBEnum.VALIDATION_INFO.sCode.name());
		sb.append(" = ");
		sb.append("?");
		//sb.append(0);
		sb.append(",");
		sb.append(PortalDBEnum.VALIDATION_INFO.nPreviousTS.name());
		sb.append(" = ");
		sb.append("?");
//		sb.append(infoVO.getnPreviousTS());
		return sb.toString();

	}

	/*
	 * Update existing validation info. 
	 */
	public String updateValidationInfo() {

		StringBuilder sb = new StringBuilder();
		sb.append("UPDATE ");
		sb.append(PortalDBEnum.TABLE_NAMES.validationInfo);
		sb.append(" SET ");

		sb.append(PortalDBEnum.VALIDATION_INFO.sGUID);
		sb.append(" = ");
		sb.append("?");
		//sb.append(dbCon.formatString(infoVO.getsGUID()));
		sb.append(", ");
		sb.append(PortalDBEnum.VALIDATION_INFO.nTimestamp);
		sb.append(" = ");
		sb.append("?");
//		sb.append(infoVO.getnTimestamp());
		sb.append(", ");
		sb.append(PortalDBEnum.VALIDATION_INFO.nStatus);
		sb.append(" = ");
		sb.append("?");
//		sb.append(infoVO.getnStatus());
		sb.append(", ");
		sb.append(PortalDBEnum.VALIDATION_INFO.nPreviousTS);
		sb.append(" = ");
		sb.append("?");
//		sb.append(infoVO.getnPreviousTS());
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.VALIDATION_INFO.sMACAddress);
		sb.append(" = ");
		sb.append("?");
//		sb.append(dbCon.formatString(infoVO.getsMACAddress()));
		return sb.toString();
	}

	/*
	 * Get validation info for given macAddress.
	 */
	public String getValidationInfo() {
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT * FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.validationInfo);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.VALIDATION_INFO.sMACAddress);sb.append(" = ");
		sb.append("?");
		//sb.append(dbCon.formatString(macAddress));
		return sb.toString();
	}

	/*
	 * Delete validation info for given mac Address.
	 */
	public String deleteValidationInfo() {
		StringBuilder sb = new StringBuilder();
		sb.append("DELETE FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.validationInfo);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.VALIDATION_INFO.sMACAddress);sb.append(" = ");sb.append("?");
		return sb.toString();
	}

}
