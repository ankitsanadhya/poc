/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal;

import java.sql.SQLException;

import com.mwp.db.Interface.IConnection;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.dal.engine.PortalDatabaseEngine;

/*
 * This class create queries related to table functionversions 
 */
public class FunctionVersionsDB {

	private IConnection dbCon= null;
	public FunctionVersionsDB() {
		dbCon = PortalDatabaseEngine.getInstance().getConnection();
	}

	/**
	 * Add new function version 
	 * @param functionVO
	 * @return
	 */
	public String addFunctionVersion() {
		return mAddFunctionVersion();
	}

	/**
	 * 
	 * @param functionId
	 * @param version
	 * @return
	 */
	public String getFunctionVersion() {
		return mGetFunctionVersion();
	}
	
	/**
	 * create query to get maximum version number of function
	 * @param functionId
	 * @return
	 * @throws SQLException
	 */
	public String getMaxFunctionVersion() {
		return mGetMaxFunctionVersion();
	}

	/**
	 * create query to list all versions of a given function id.
	 * @param FunctionVO
	 * @return ArrayList<FunctionVersionVO>
	 * @throws Exception 
	 */
	public String listAllVersion() {
		return mListAllVersion();
	}

	/**
	 * Query to delete all versions of a function
	 * @param functionId
	 * @return
	 */
	public String deleteFunctionVersion() {
		return mDeleteFunctionVersion();
	}

	/**
	 * Query to delete single version of function with versionId
	 * @param functionId function Id
	 * @param versionId version Id.
	 * @return 
	 */
	public String deleteFunctionVersionWithVersionId() {
		return mDeleteFunctionVersionWithVersionId();
	}

	//****************************PRIVATE METHODS*************************************

	private String mDeleteFunctionVersion() {
		StringBuilder sb=new StringBuilder();
		sb.append("DELETE FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.functionversions);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.FUNCTION_VERSIONS.functionId);
		sb.append(" = ");
		sb.append("?");
//		sb.append(dbCon.formatString(functionId));
		return sb.toString();
	}

	private String mDeleteFunctionVersionWithVersionId() {
		StringBuilder sb = new StringBuilder();
		sb.append("DELETE FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.functionversions);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.FUNCTION_VERSIONS.functionId);
		sb.append(" = ");
		sb.append("?");
//		sb.append(dbCon.formatString(functionId));
		sb.append(" AND ");
		sb.append(PortalDBEnum.FUNCTION_VERSIONS.functionVersionId);
		sb.append(" = ");
		sb.append("?");
//		sb.append(dbCon.formatString(versionId));
		return sb.toString();
	}

	private String mGetFunctionVersion() {
		StringBuilder sb = new StringBuilder();
		sb.append("Select * FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.functionversions);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.FUNCTION_VERSIONS.functionId);
		sb.append(" = ");
		sb.append("?");
//		sb.append(dbCon.formatString(functionId));
		sb.append(" AND ");
		sb.append(PortalDBEnum.FUNCTION_VERSIONS.version);
		sb.append(" = ");
		sb.append("?");
//		sb.append(version);

		return sb.toString();
	}

	private String mGetMaxFunctionVersion() {
		StringBuilder sb = new StringBuilder();
		sb.append("Select MAX(");
		sb.append(PortalDBEnum.FUNCTION_VERSIONS.version);
		sb.append(") AS max FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.functionversions);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.FUNCTION_VERSIONS.functionId);
		sb.append(" = ");
		sb.append("?");
//		sb.append(dbCon.formatString(functionId));
		return sb.toString();
	}

	private String mAddFunctionVersion() {

		StringBuilder sb = new StringBuilder();
		sb.append("INSERT INTO ");
		sb.append(PortalDBEnum.TABLE_NAMES.functionversions);
		sb.append(" ( ");
		sb.append(PortalDBEnum.FUNCTION_VERSIONS.functionVersionId.name());
		sb.append(", ");
		sb.append(PortalDBEnum.FUNCTION_VERSIONS.functionId.name());
		sb.append(", ");
		sb.append(PortalDBEnum.FUNCTION_VERSIONS.version.name());
		sb.append(", ");
		sb.append(PortalDBEnum.FUNCTION_VERSIONS.body.name());
		sb.append(", ");
		sb.append(PortalDBEnum.FUNCTION_VERSIONS.toExecute.name());
		sb.append(", ");
		sb.append(PortalDBEnum.FUNCTION_VERSIONS.modifiedDate.name());
		sb.append(" ) VALUES ( ");
		sb.append("?");
		//sb.append(dbCon.formatString(functionVO.getFunctionVersionId()));
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(functionVO.getFunctionId()));
		sb.append(", ");
		sb.append("?");
//		sb.append(functionVO.getVersion());
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(functionVO.getFunctionBody()));
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(functionVO.getToExecute()));
		sb.append(", NOW()");
		sb.append(" ) ");
		return sb.toString();
	}

	private String mListAllVersion() {
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT ");
		sb.append(PortalDBEnum.TABLE_NAMES.functionversions);
		sb.append(".");
		sb.append(PortalDBEnum.FUNCTION_VERSIONS.functionVersionId.name());
		sb.append(", ");
		sb.append(PortalDBEnum.TABLE_NAMES.functionversions);
		sb.append(".");
		sb.append(PortalDBEnum.FUNCTION_VERSIONS.functionId.name());
		sb.append(", ");
		sb.append(PortalDBEnum.TABLE_NAMES.functionversions);
		sb.append(".");
		sb.append(PortalDBEnum.FUNCTION_VERSIONS.version.name());
		sb.append(", ");
		sb.append(PortalDBEnum.TABLE_NAMES.functionversions);
		sb.append(".");
		sb.append(PortalDBEnum.FUNCTION_VERSIONS.modifiedDate.name());

		sb.append(", ");
		sb.append(PortalDBEnum.TABLE_NAMES.functionversions);
		sb.append(".");
		sb.append(PortalDBEnum.FUNCTION_VERSIONS.body.name());

		sb.append(", ");
		sb.append(PortalDBEnum.TABLE_NAMES.functionversions);
		sb.append(".");
		sb.append(PortalDBEnum.FUNCTION_VERSIONS.toExecute.name());
		sb.append(", ");
		sb.append(PortalDBEnum.TABLE_NAMES.functionversions);
		sb.append(".");
		sb.append(PortalDBEnum.FUNCTION_VERSIONS.modifiedDate.name());
		sb.append(" as versionModifiedDate ");
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.functionversions);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.TABLE_NAMES.functionversions);
		sb.append(".");
		sb.append(PortalDBEnum.FUNCTION_VERSIONS.functionId.name());
		sb.append(" = ");
		sb.append("?");
//		sb.append(PortalDatabaseEngine.getInstance().getConnection().formatString(functionId));
		sb.append(" ORDER BY ");
		sb.append(PortalDBEnum.FUNCTION_VERSIONS.version);
		sb.append(" ASC ");
		return sb.toString();
	}


}
