/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal.engine;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mwp.common.CredProvider;
import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.common.vo.QueryVO;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.common.vo.LockRelayPortsVO;
import com.mwp.p.common.vo.RelayServerVO;
import com.mwp.p.common.vo.SupportAssignedRelayPortsVO;
import com.mwp.p.dal.SupportAssignedRelayPortsDB;
import com.mwp.p.dal.SupportLockRelayPortsDB;
import com.mwp.p.dal.SupportRelayServersDB;
import com.pa.crypto.StringEncryptionDecryption;

public class SupportRelayServerEngine {

	/**
	 * get assigned relayports for a device
	 * 
	 * @param deviceIds
	 * @return
	 * @throws SQLException
	 */
	public SupportAssignedRelayPortsVO getSupportAssignedRelayPorts(String deviceId) throws SQLException {
		String sql = new SupportAssignedRelayPortsDB().getSupportAssignedRelayPorts();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(deviceId).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				return setSupportAssignedRelayPortsObject(rs);
			}
		}
		return null;
	}

	/**
	 * Get relay server by relay server id
	 * 
	 * @param relayServerId
	 * @return
	 * @throws SQLException
	 */
	public RelayServerVO getSupportRelayServers(String relayServerId, boolean callByAdmin) throws SQLException {
		String sql = new SupportRelayServersDB().getSupportRelayServersFromRelayId();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(relayServerId).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				return setSupportRelayServersObject(rs, callByAdmin);
			}
		}
		return null;
	}

	/**
	 * List all assign relay ports and relay server ports
	 * 
	 * @return ArrayList<RelayServerVO>
	 * @throws SQLException
	 */
	public List<RelayServerVO> getSupportRelayServers(boolean callByAdmin) throws SQLException {
		List<RelayServerVO> listRelayServerVO = new ArrayList<>();
		String sql = new SupportRelayServersDB().getSupportRelayServers();
		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				RelayServerVO relayVO = new RelayServerVO();
				relayVO.setsRelayServerID(rs.getString(PortalDBEnum.RELAY_SERVERS.sRelayServerID.name()));
				relayVO.setsRelayServerAddress(rs.getString(PortalDBEnum.RELAY_SERVERS.sRelayServerAddress.name()));
				relayVO.setsRelayName(rs.getString(PortalDBEnum.RELAY_SERVERS.sRelayName.name()));
				relayVO.setsDeviceLimit(rs.getString(PortalDBEnum.RELAY_SERVERS.sDeviceLimit.name()));
				relayVO.setnPortRangeStart(rs.getInt(PortalDBEnum.RELAY_SERVERS.nPortRangeStart.name()));
				relayVO.setnPortRangeEnd(rs.getInt(PortalDBEnum.RELAY_SERVERS.nPortRangeEnd.name()));
				relayVO.setDeviceCount(rs.getInt("Devices"));
				listRelayServerVO.add(relayVO);
			}
			if (listRelayServerVO.isEmpty()) {
				sql = new SupportRelayServersDB().getAllSupportedRelayServers();
				queryVO = new SqlQueryBuilder(
						PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
								.build();
				try (ResultSet rs1 = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
					while (rs1.next()) {
						listRelayServerVO.add(setSupportRelayServersObject(rs1, callByAdmin));
					}
				}
			}
		}
		return listRelayServerVO;
	}

	/**
	 * List all already assigned ports of device
	 * 
	 * @param deviceId
	 * @param relayServerId
	 * @return
	 * @throws SQLException
	 */
	public Integer getAlreadyAssignedPorts(String deviceId, String relayServerId) throws SQLException {
		String sql = new SupportAssignedRelayPortsDB().getAlreadyAssignedPorts();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(relayServerId).addParameter(deviceId).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				return rs.getInt(PortalDBEnum.ASSIGNED_RELAY_PORTS.nPortSegmentStart.name());
			}
		}
		return null;
	}

	/**
	 * Get max of assigned relay ports
	 * 
	 * @param relayServerID
	 * @return
	 * @throws SQLException
	 */
	public int getMaxRelayPort(String relayServerID) throws SQLException {
		String sql = new SupportAssignedRelayPortsDB().getMaxRelayPort();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(relayServerID).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				return rs.getInt("MaxAvailablePortSegment");
			}
		}
		return 0;
	}

	/**
	 * Get all available ports by relay server id
	 * 
	 * @param relayServerID
	 * @return
	 * @throws SQLException
	 */
	public List<SupportAssignedRelayPortsVO> getAvailablePorts(String relayServerID) throws SQLException {
		ArrayList<SupportAssignedRelayPortsVO> listRelayServerVO = new ArrayList<>();
		String sql = new SupportAssignedRelayPortsDB().getAvailablePorts();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(relayServerID).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				listRelayServerVO.add(setSupportAssignedRelayPortsObject(rs));
			}
		}
		return listRelayServerVO;
	}

	/**
	 * Delete all ports assigned to device
	 * 
	 * @param deviceId
	 * @return
	 * @throws SQLException
	 */
	public boolean deleteDeviceAssignedPorts(String deviceId) throws SQLException {
		String sql = new SupportAssignedRelayPortsDB().deleteDeviceAssignedPorts();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(deviceId).build();

		int rowUpdate = PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
		return rowUpdate > 0;
	}

	/**
	 * Place bid to assign port to device
	 * 
	 * @param deviceId
	 * @param relayServerId
	 * @param portSegmentStart
	 * @return true if bid placed false otherwise
	 * @throws SQLException
	 */
	public boolean placeBid(String deviceId, String relayServerId, int portSegmentStart) throws SQLException {
		deleteDeviceBids(deviceId);
		String sql = new SupportLockRelayPortsDB().placeBid();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(deviceId).addParameter(relayServerId).addParameter(portSegmentStart).build();

		int rowUpdate = PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
		return rowUpdate > 0;
	}

	/**
	 * Delete all bids of a device
	 * 
	 * @param deviceId
	 * @return true if deleted successfully, false otherwise
	 * @throws SQLException
	 */
	public boolean deleteDeviceBids(String deviceId) throws SQLException {
		String sql = new SupportLockRelayPortsDB().deleteDeviceBids();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(deviceId).build();

		int rowUpdate = PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
		return rowUpdate > 0;
	}

	/**
	 * List bids placed for a port and relay server
	 * 
	 * @param relayServerId
	 * @param portSegmentStart
	 * @return
	 * @throws SQLException
	 */
	public List<LockRelayPortsVO> listBids(String relayServerId, int portSegmentStart) throws SQLException {
		ArrayList<LockRelayPortsVO> listLockRelayPort = new ArrayList<>();
		String sql = new SupportLockRelayPortsDB().listBids();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(relayServerId).addParameter(portSegmentStart).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				LockRelayPortsVO detailsVO = new LockRelayPortsVO();
				detailsVO.setsDeviceID(rs.getString(PortalDBEnum.SUPPORT_LOCK_RELAY_PORTS.sDeviceID.name()));
				detailsVO.setsRelayServerID(rs.getString(PortalDBEnum.SUPPORT_LOCK_RELAY_PORTS.sRelayServerID.name()));
				detailsVO.setnPortSegmentStart(
						rs.getInt(PortalDBEnum.SUPPORT_LOCK_RELAY_PORTS.nPortSegmentStart.name()));
				detailsVO.setdModified(
						rs.getTimestamp(PortalDBEnum.SUPPORT_LOCK_RELAY_PORTS.dModified.name()).getTime());
				listLockRelayPort.add(detailsVO);
			}
		}
		return listLockRelayPort;
	}

	/**
	 * delete all expired locks which are older than 5 min
	 * 
	 * @return true if deleted successfully, false otherwise
	 * @throws SQLException
	 */
	public boolean deleteExpiredLocks() throws SQLException {
		String sql = new SupportLockRelayPortsDB().deleteExpiredLocks();
		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.build();
		
		int rowUpdate = PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
		return rowUpdate > 0;
	}

	/**
	 * Assign relay port to a device
	 * 
	 * @param deviceId
	 * @param relayServerId
	 * @param portSegmentStart
	 * @return true if successful , false otherwise
	 * @throws SQLException
	 */
	public boolean addAssignedRelayPorts(String deviceId, String relayServerId, int portSegmentStart)
			throws SQLException {
		String sql = new SupportAssignedRelayPortsDB().addAssignedRelayPorts();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(deviceId).addParameter(relayServerId).addParameter(portSegmentStart)
						.addParameter(relayServerId).addParameter(portSegmentStart).build();

		int rowUpdate = PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
		return rowUpdate > 0;
	}

	/**
	 * Create queries to select relay server if its piority is 1.
	 * 
	 * @param relayServerId
	 * @return
	 * @throws SQLException
	 */
	public boolean isOnePriority(String relayServerId) throws SQLException {
		return mIsOnePriority(relayServerId);
	}

	/**
	 * list all Support relay servers with used and available count
	 * 
	 * @return
	 * @throws SQLException
	 */
	public List<RelayServerVO> listsAllSupportRelayServer(boolean callByAdmin) throws SQLException {
		return mListsAllSupportRelayServer(callByAdmin);
	}

	public RelayServerVO insertSupportRelayServer(String sRelayServerID, String sRelayServerAddress, String sRelayName,
			int nPortRangeStart, int nPortRangeEnd, String sDeviceLimit, int nStatus, String sRUserName,
			String sRPassword, String sHostKey, int nRPort, int sPriority, boolean callByAdmin) throws Exception {
		return mInsertSupportRelayServer(sRelayServerID, sRelayServerAddress, sRelayName, nPortRangeStart,
				nPortRangeEnd, sDeviceLimit, nStatus, sRUserName, sRPassword, sHostKey, nRPort, sPriority, callByAdmin);
	}

	public RelayServerVO updateSupportRelayServer(String sRelayServerID, String sRelayServerAddress, String sRelayName,
			int nStatus, String sRUserName, String sRPassword, String sHostKey, int nRPort, int sPriority,
			boolean callByAdmin) throws SQLException {
		return mUpdateSupportRelayServer(sRelayServerID, sRelayServerAddress, sRelayName, nStatus, sRUserName,
				sRPassword, sHostKey, nRPort, sPriority, callByAdmin);
	}

	public void delete(String sRelayServerID) throws SQLException {
		mDelete(sRelayServerID);
	}

	private SupportAssignedRelayPortsVO setSupportAssignedRelayPortsObject(ResultSet rs) throws SQLException {
		SupportAssignedRelayPortsVO assignedRelayPortsVO = new SupportAssignedRelayPortsVO();
		assignedRelayPortsVO.setsDeviceId(rs.getString(PortalDBEnum.SUPPORT_ASSIGNED_RELAY_PORTS.sDeviceID.name()));
		assignedRelayPortsVO
				.setsRelayServerId(rs.getString(PortalDBEnum.SUPPORT_ASSIGNED_RELAY_PORTS.sRelayServerID.name()));
		assignedRelayPortsVO
				.setnPortSegmentStart(rs.getInt(PortalDBEnum.SUPPORT_ASSIGNED_RELAY_PORTS.nPortSegmentStart.name()));
		assignedRelayPortsVO.setnStatus(rs.getInt(PortalDBEnum.SUPPORT_ASSIGNED_RELAY_PORTS.nStatus.name()));
		assignedRelayPortsVO
				.setdModified(rs.getTimestamp(PortalDBEnum.SUPPORT_ASSIGNED_RELAY_PORTS.dModified.name()).getTime());
		return assignedRelayPortsVO;
	}

	private RelayServerVO setSupportRelayServersObject(ResultSet rs, boolean callByAdmin) throws SQLException {
		RelayServerVO relayVO = new RelayServerVO();
		relayVO.setsRelayServerID(rs.getString(PortalDBEnum.SUPPORT_RELAY_SERVERS.sRelayServerID.name()));
		relayVO.setsRelayServerAddress(rs.getString(PortalDBEnum.SUPPORT_RELAY_SERVERS.sRelayServerAddress.name()));
		relayVO.setsRelayName(rs.getString(PortalDBEnum.SUPPORT_RELAY_SERVERS.sRelayName.name()));
		relayVO.setsDeviceLimit(rs.getString(PortalDBEnum.SUPPORT_RELAY_SERVERS.sDeviceLimit.name()));
		relayVO.setnPortRangeStart(rs.getInt(PortalDBEnum.SUPPORT_RELAY_SERVERS.nPortRangeStart.name()));
		relayVO.setnPortRangeEnd(rs.getInt(PortalDBEnum.SUPPORT_RELAY_SERVERS.nPortRangeEnd.name()));
		relayVO.setnStatus(rs.getInt(PortalDBEnum.SUPPORT_RELAY_SERVERS.nStatus.name()));

		if (callByAdmin) {
			String key = new CredProvider().getEcnKey();
			String userName = StringEncryptionDecryption
					.decrypt(rs.getString(PortalDBEnum.SUPPORT_RELAY_SERVERS.sRUserName.name()), key);
			String pwd = StringEncryptionDecryption
					.decrypt(rs.getString(PortalDBEnum.SUPPORT_RELAY_SERVERS.sRPassword.name()), key);
			String hostkey = StringEncryptionDecryption
					.decrypt(rs.getString(PortalDBEnum.SUPPORT_RELAY_SERVERS.sHostKey.name()), key);

			relayVO.setsRUserName(userName);
			relayVO.setsRPassword(pwd);
			relayVO.setsHostKey(hostkey);
		} else {
			relayVO.setsRUserName(rs.getString(PortalDBEnum.SUPPORT_RELAY_SERVERS.sRUserName.name()));
			relayVO.setsRPassword(rs.getString(PortalDBEnum.SUPPORT_RELAY_SERVERS.sRPassword.name()));
			relayVO.setsHostKey(rs.getString(PortalDBEnum.SUPPORT_RELAY_SERVERS.sHostKey.name()));
		}
		relayVO.setnRPort(rs.getInt(PortalDBEnum.SUPPORT_RELAY_SERVERS.nRPort.name()));
		relayVO.setsPriority(rs.getInt(PortalDBEnum.SUPPORT_RELAY_SERVERS.sPriority.name()));
		relayVO.setdModified(rs.getTimestamp(PortalDBEnum.SUPPORT_RELAY_SERVERS.dModified.name()).getTime());
		return relayVO;

	}

	private boolean mIsOnePriority(String relayServerId) throws SQLException {
		String sql = new SupportRelayServersDB().isOnePriority();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(relayServerId).addParameter(1).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			return rs.next();
		}
	}

	private List<RelayServerVO> mListsAllSupportRelayServer(boolean callByAdmin) throws SQLException {
		List<RelayServerVO> listRelayServer = new ArrayList<>();
		String sql = new SupportRelayServersDB().listAllSupportRelayServer();
		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				RelayServerVO relayVO = setSupportRelayServersObject(rs, callByAdmin);
				relayVO.setDeviceCount(rs.getInt("deviceCount"));
				int totalRangeCount = (relayVO.getnPortRangeEnd() - relayVO.getnPortRangeStart()) + 1;
				int remainingCount = totalRangeCount - relayVO.getDeviceCount();
				relayVO.setFreePort(remainingCount);
				listRelayServer.add(relayVO);

			}
		}
		return listRelayServer;
	}

	private boolean mIsExists(String relayServerId) throws SQLException {
		String sql = new SupportRelayServersDB().isExists();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(relayServerId).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				return true;
			}
		}
		return false;
	}

	private RelayServerVO mInsertSupportRelayServer(String sRelayServerID, String sRelayServerAddress,
			String sRelayName, int nPortRangeStart, int nPortRangeEnd, String sDeviceLimit, int nStatus,
			String sRUserName, String sRPassword, String sHostKey, int nRPort, int sPriority, boolean callByAdmin)
			throws Exception {

		if (!mIsExists(sRelayServerID)) {
			String sql = new SupportRelayServersDB().insertSupportRelayServer();

			QueryVO queryVO = new SqlQueryBuilder(
					PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
							.addParameter(sRelayServerID).addParameter(sRelayServerAddress).addParameter(sRelayName)
							.addParameter(nPortRangeStart).addParameter(nPortRangeEnd).addParameter(sDeviceLimit)
							.addParameter(nStatus).addParameterEncrypted(sRUserName).addParameterEncrypted(sRPassword)
							.addParameterEncrypted(sHostKey).addParameter(nRPort).addParameter(sPriority).build();

			PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);

			return getSupportRelayServers(sRelayServerID, callByAdmin);
		}
		throw new Exception("Id already exists.");

	}

	private RelayServerVO mUpdateSupportRelayServer(String sRelayServerID, String sRelayServerAddress,
			String sRelayName, int nStatus, String sRUserName, String sRPassword, String sHostKey, int nRPort,
			int sPriority, boolean callByAdmin) throws SQLException {
		String sql = new SupportRelayServersDB().updateSupportRelayServer();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(sRelayServerAddress).addParameter(sRelayName).addParameter(nStatus)
						.addParameterEncrypted(sRUserName).addParameterEncrypted(sRPassword)
						.addParameterEncrypted(sHostKey).addParameter(nRPort).addParameter(sPriority)
						.addParameter(sRelayServerID).build();

		PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
		return getSupportRelayServers(sRelayServerID, callByAdmin);
	}

	private void mDelete(String sRelayServerID) throws SQLException {
		String sql = new SupportRelayServersDB().delete();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(sRelayServerID).build();

		PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
	}

}
