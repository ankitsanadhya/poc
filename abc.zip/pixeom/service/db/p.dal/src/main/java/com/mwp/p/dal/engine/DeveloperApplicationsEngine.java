/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal.engine;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import com.mwp.common.Common;
import com.mwp.common.CredProvider;
import com.mwp.common.StringFunctions;
import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.common.enums.SignUpTypeEnum;
import com.mwp.common.enums.Status;
import com.mwp.common.enums.StatusEnum.VERSION_STATUS;
import com.mwp.common.vo.ApplicationDetailsVO;
import com.mwp.common.vo.ApplicationImagesVO;
import com.mwp.common.vo.ApplicationPlatformVO;
import com.mwp.common.vo.AuthorizationsVO;
import com.mwp.common.vo.CategoryVO;
import com.mwp.common.vo.DevAppDetailsVO;
import com.mwp.common.vo.QueryVO;
import com.mwp.common.vo.ServiceEndpointVO;
import com.mwp.common.vo.VersionVO;
import com.mwp.p.common.Constants;
import com.mwp.p.common.PortalCommon;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.common.enums.PortalDBEnum.APPLICATION_VERSIONS;
import com.mwp.p.common.vo.AppCommandVO;
import com.mwp.p.common.vo.DeveloperApplicationVO;
import com.mwp.p.dal.ApplicationDetailsDB;
import com.mwp.p.dal.ApplicationVersionDB;
import com.mwp.p.dal.ApplicationsDB;
import com.mwp.p.dal.DeviceApplicationsDB;
import com.pa.crypto.StringEncryptionDecryption;

/**
 * This class manage Developer application, Create Application, Update Application, 
 * Delete Application, get Details of Application version, List Invited Application of users with associate group.
 * @author root
 *
 */
public class DeveloperApplicationsEngine {

	/**
	 * List invited applications of user associated with given group ids.
	 * @param groupIds
	 * @return
	 * @throws Exception
	 */
	public List<DeveloperApplicationVO> listInvitedApps(List<String> groupIds) throws SQLException {
		return mListInvitedApps(groupIds);
	}

	/**
	 * Add new application in database with related information (images, categories, version).
	 * @param appDetailsVO Object of ApplicationDetailsVO class contains(Version info, app exist in which category, app images with sequence no.)
	 * @return ApplicationDetailsVO object.
	 * @throws Exception
	 */
	public ApplicationDetailsVO createApplication(ApplicationDetailsVO appDetailsVO) throws SQLException{
		return mCreateApplication(appDetailsVO);
	}

	/**
	 * Update application in database with related information (images, categories, version).
	 * @param appDetailsVO Object of ApplicationDetailsVO class contains(Version info, app exist in which category, app images with sequence no.)
	 * @return updated object of ApplicationDetailsVO
	 * @throws Exception
	 */
	public ApplicationDetailsVO updateApplication(ApplicationDetailsVO appDetailsVO) throws SQLException{
		return mUpdateApplication(appDetailsVO);
	}

	/**
	 * Delete application mark application status - DELETED.
	 * @param appId Unique id of application which developer wants to delete
	 * @param userId userId of developer which came for delete app request.
	 * @throws Exception
	 */
	public void deleteApplication(String appId,String userId) throws SQLException{
		mDeleteApplication(appId,userId);
	}

	/**
	 * Get version details for given application and version id.
	 * @param appId
	 * @param versionId
	 * @return
	 * @throws Exception
	 */
	public VersionVO getVersionDetails(String appId, String versionId) throws SQLException{
		return mGetVersionDetails(appId,versionId);
	}

	/**
	 * Get version yml compose filepath for given application and version id.
	 * @param appId
	 * @param versionId
	 * @return
	 * @throws Exception
	 */
	public String getVersionComposeYMLPath(String appId, String versionId) throws SQLException{
		return mGetVersionComposeYMLPath(appId,versionId);
	}

	/**
	 * Get composer version for given application and version id.if version id is empty then it will give LIVE version compose Version
	 * @param appId
	 * @param versionId
	 * @return
	 * @throws Exception
	 */
	public String getComposeVersion(String appId, String version) throws SQLException{
		return mGetComposeVersion(appId,version);
	}

	/**
	 * Get compose version  of installed application on device  
	 * @param appId
	 * @param versionId
	 * @throws Exception
	 */
	public String getInstalledApplicatonComposeVersion(String deviceId, String appId) throws SQLException{
		return mGetInstalledApplicatonComposeVersion(deviceId, appId);
	}

	private String mGetInstalledApplicatonComposeVersion(String deviceId, String appId)throws SQLException{

		String composeVersion = null;
		
		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new DeviceApplicationsDB().getInstalledApplicatonComposeVersion())
				.addParameter(deviceId)
				.addParameter(appId).build();

		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)){
			while (rs.next()) {
				composeVersion = rs.getString(PortalDBEnum.APPLICATION_VERSIONS.composeVersion.name());
			}
		}
		return composeVersion;
	}
	/**
	 * getting installation details of application.
	 * @param appId
	 * @return
	 * @throws Exception
	 */
	public DevAppDetailsVO getDevAppDetails(String appId, AuthorizationsVO authVo,List<VERSION_STATUS> filterVersionStstus) throws SQLException{
		return mGetDeveloperAppDetails(appId, authVo, filterVersionStstus);
	}

	/**
	 * Add image entry for application.
	 * @param imagesVO ApplicationImagesVO object
	 * @return ApplicationImagesVO object
	 * @throws SQLException
	 */
	public ApplicationImagesVO addApplicationImage(ApplicationImagesVO imagesVO) throws SQLException {
		return mAddApplicationImage(imagesVO);
	}

	/**
	 * Update application logo icon.
	 * @param appId
	 * @param logoPath
	 * @throws SQLException
	 */
	public void updateApplicationLogo(String appId, String logoPath) throws SQLException {
		mUpdateApplicationLogo(appId, logoPath);
	}

	/**
	 * This method gives application version command according to requested
	 * applicationId and appVersionId
	 * @param userId id of logged in user.
	 * @param applicationId Application Id which is unique for each application.
	 * @param appVersionId  Version Id of application which is unique for each version.
	 * @return list of AppCommandVO {@link AppCommandVO}
	 * @throws SQLException 
	 */
	public List<AppCommandVO> getAppVersionCommand(String userId, String applicationId,String appVersionId, List<String> grpIds) throws SQLException	{
		return mGetAppVersionCommand(userId, applicationId, appVersionId, grpIds);
	}

	/**
	 * Check update of requested application version.
	 * @param appVersionId version id of application.
	 * @return true if update is available otherwise false
	 * @throws SQLException
	 */
	public boolean checkUpdate(String appVersionId) throws SQLException
	{
		return mCheckUpdate(appVersionId);
	}

	/**
	 * This method gives all available version of application
	 * @param appId Application Id which is unique for each application.
	 * @param userId id of logged in user.
	 * @param appVersionId versionId
	 * @return
	 * @throws SQLException
	 */
	public List<VersionVO> listAppVersion(String appId,String userId,String appVersionId, String appPlatformId, List<VERSION_STATUS> filterVersionStatus) throws SQLException
	{
		return mListAppVersion(appId,userId,appVersionId, appPlatformId, filterVersionStatus);
	}

	/**
	 * Delete application image according to appImageId and appId.
	 * @param appId
	 * @param appImageId
	 * @return id of appImage - appImageId
	 * @throws SQLException
	 */
	public String deleteAppImage(String appId, String appImageId) throws SQLException {
		return mDeleteAppImage(appId, appImageId);
	}

	/**
	 * get title if exists 
	 * @param title
	 * @return appName/title : if application exists null otherwise.
	 * @throws SQLException
	 */
	public String getAppName(String appId) throws SQLException {
		return mGetAppName(appId);
	}

	private String mGetAppName(String appId) throws SQLException {
		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new ApplicationDetailsDB().getAppName()).addParameter(appId).build();

		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)){
			while (rs.next()){
				return rs.getString(PortalDBEnum.APPLICATION.title.name());
			}
		}
		return null;
	}

	/**
	 * Check if application already exists for title and repository name. 
	 * @param title
	 * @return true if application already exists false otherwise.
	 * @throws SQLException
	 */
	public boolean isApplicationExits(String title) throws SQLException {
		return mIsApplicationExits(title);
	}

	private boolean mIsApplicationExits(String title) throws SQLException {
		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new ApplicationDetailsDB().isApplicationExits()).addParameter(title).build();
		
		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)){
			while (rs.next()){
				return true;
			}
		}
		
		return false;
	}

	/**
	 * Check if application exists for given title and app id. 
	 * @param appName
	 * @param appId
	 * @return
	 * @throws SQLException
	 */
	public boolean isAppNameAlreadyExist(String appName, String appId) throws SQLException {
		return mIsAppNameAlreadyExist(appName, appId);
	}

	public List<String> getAppVersionAndUserIdOfApp(String appVersionId) throws SQLException{
		return mGetAppVersionAndUserIdOfApp(appVersionId);
	}

	private boolean mIsAppNameAlreadyExist(String appName, String appId) throws SQLException {
		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new ApplicationDetailsDB().isAppNameAlreadyExist())
				.addParameter(appName)
				.addParameter(appId).build();

		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)){
			while (rs.next()){
				return true;
			}
		}
		return false;
	}
	/**
	 * Delete application image according to appImageId and appId.
	 * @param appId
	 * @param appImageId
	 * @return id of appImage - appImageId
	 * @throws SQLException
	 */
	private String mDeleteAppImage(String appId, String appImageId) throws SQLException {
		/*
		 * getting query for delete appImage according to appId and appImageId.
		 */
		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new ApplicationDetailsDB().deleteAppImage())
				.addParameter(appId)
				.addParameter(appImageId)
				.build();
		/*
		 * executeUpdate query for remove entry from applicationImage table,
		 * if count return 0 then we throw exception image not deleted.
		 */
		int deleteCount = PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
		if(deleteCount == 0){
			throw new SQLException("image not deleted.");
		}
		return appImageId;
	}

	private ApplicationImagesVO mAddApplicationImage(ApplicationImagesVO imagesVO) throws SQLException {
		imagesVO.setAppImageId(Common.getRandomId());

		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new ApplicationDetailsDB().addApplicationImage())
				.addParameter(imagesVO.getAppImageId())
				.addParameter(imagesVO.getAppId())
				.addParameter(imagesVO.getImagePath())
				.addParameter(imagesVO.getSequenceNo())
				.build();

		int addCount = PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
		if(addCount==0){
			throw new SQLException("image not added.");
		}
		return imagesVO;
	}

	/**
	 * Getting developer application detail joining (application/category/applicationcategories/company/applicationserviceendpoints)
	 * @param appId
	 * @param authVo
	 * @return
	 * @throws SQLException
	 */
	private DevAppDetailsVO mGetDeveloperAppDetails(String appId, AuthorizationsVO authVo, List<VERSION_STATUS> filterVersionStstus) throws SQLException{
		//App Detail VO object. This will be returned to UI
		DevAppDetailsVO devAppDetailsVO = null;
		/*
		 * Getting developer application detail query from joining (application/category/applicationcategories/company/applicationserviceendpoints)
		 */
		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new ApplicationDetailsDB().getDeveloperAppDetails()).addParameter(appId).build();

		
		String encKey = new CredProvider().getEcnKey();

		/*
		 * create local hashtable for serviceEndpoints,
		 * to maintain duplicate entry not added in list.
		 */
		HashMap<String, ServiceEndpointVO> hashServiceEndpoints = new HashMap<>();
		HashMap<String, CategoryVO> hashCategory = new HashMap<>();
		HashMap<String, ApplicationPlatformVO> hashAppPlatform = new HashMap<>();
		/*
		 * create local hashtable for applicationImages,
		 * to maintain duplicate entry not added in list.
		 */
		HashMap<String, ApplicationImagesVO> hashAppImage = new HashMap<>();
		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)){
			while (rs.next()){
				if(devAppDetailsVO == null){
					devAppDetailsVO = new DevAppDetailsVO();
					devAppDetailsVO.setApplicationId(rs.getString(PortalDBEnum.APPLICATION.appId.name()));
					devAppDetailsVO.setAppTypeId(rs.getString(PortalDBEnum.APPLICATION.appTypeId.name()));
					devAppDetailsVO.setAppOwnerId(rs.getString(PortalDBEnum.APPLICATION.userId.name()));
					devAppDetailsVO.setAppStatus(Status.GetEnum(rs.getInt(PortalDBEnum.APPLICATION.appStatus.name())));
					devAppDetailsVO.setDescription(rs.getString(PortalDBEnum.APPLICATION.description.name()));
					//AKH_01_1
					devAppDetailsVO.setPrice(rs.getBigDecimal(PortalDBEnum.APPLICATION.price.name()));
					devAppDetailsVO.setRating(rs.getDouble(PortalDBEnum.APPLICATION.rating.name()));
					devAppDetailsVO.setCurrency(rs.getString(PortalDBEnum.APPLICATION.currency.name()));
					devAppDetailsVO.setRunAsService(rs.getBoolean(PortalDBEnum.APPLICATION.runAsService.name()));
					devAppDetailsVO.setIcon(rs.getString(PortalDBEnum.APPLICATION.icon.name()));
					/*
					 * add if check if icon has empty value then created publicURL.
					 */
					if(!StringFunctions.isNullOrWhitespace(devAppDetailsVO.getIcon())){
						devAppDetailsVO.setIcon(PortalCommon.getInstance().createPublicUrl(devAppDetailsVO.getIcon(), Constants.UI_FOLDER_NAME));
					}
					devAppDetailsVO.setProjectId(rs.getString(PortalDBEnum.APPLICATION.projectId.name()));
					//AKH_02, AKH_03
					devAppDetailsVO.setTitle(rs.getString(PortalDBEnum.APPLICATION.title.name()));
					devAppDetailsVO.setUserId(rs.getString(PortalDBEnum.APPLICATION.userId.name()));
					devAppDetailsVO.setWebAddress(rs.getString(PortalDBEnum.APPLICATION.webAddress.name()));

					/*
					 * add Px default config value.
					 */
					devAppDetailsVO.setUsePxAuth(rs.getBoolean(PortalDBEnum.APPLICATION.usePxAuth.name()));
					devAppDetailsVO.setUsePxCloudApi(rs.getBoolean(PortalDBEnum.APPLICATION.usePxCloudApi.name()));
					devAppDetailsVO.setUsePxEventService(rs.getBoolean(PortalDBEnum.APPLICATION.usePxEventService.name()));
					devAppDetailsVO.setSignUpType(SignUpTypeEnum.GetEnum(rs.getInt(PortalDBEnum.APPLICATION.signUpType.name())));

					/*
					 * get companyName from join company table.
					 */
					devAppDetailsVO.setCompanyName(StringEncryptionDecryption.decrypt(rs.getString(PortalDBEnum.COMPANY.companyName.name()), encKey));
					devAppDetailsVO.setCompanyWebAddress(StringEncryptionDecryption.decrypt(rs.getString("companyWebAddress"), encKey));
				}
				/*
				 * create serviceEndpoint new object set values and ADD in serviceEndpoint list.
				 */
				String serviceEndpointId = rs.getString(PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.appServiceEndpointId.name());
				if(!StringFunctions.isNullOrWhitespace(serviceEndpointId) && !hashServiceEndpoints.containsKey(serviceEndpointId)){
					ServiceEndpointVO serviceEndpoint = new ServiceEndpointVO();
					serviceEndpoint.setAppServiceEndpointId(serviceEndpointId);
					serviceEndpoint.setServiceName(rs.getString(PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.serviceName.name()));
					hashServiceEndpoints.put(serviceEndpointId, serviceEndpoint);
				}

				/*
				 * check category object not exist in hashTable of category,
				 * so duplicate entry not added in object.
				 */
				String catId = rs.getString(PortalDBEnum.CATEGORY.catId.name());
				if(!StringFunctions.isNullOrWhitespace(catId) && !hashCategory.containsKey(catId)){
					/*
					 * create category new object set values and ADD in hashCategory.
					 */
					CategoryVO categoryVO = new CategoryVO();
					categoryVO.setCategoryId(catId);
					categoryVO.setName(rs.getString(PortalDBEnum.CATEGORY.name.name()));
					hashCategory.put(catId, categoryVO);
				}
				/*
				 * Check appImageId not empty in resultSet and already not exist in hashTable of image,
				 * so duplicate entry not added in object.  
				 */
				String appImageId = rs.getString(PortalDBEnum.APPLICATION_IMAGES.appImageId.name());
				if(!StringFunctions.isNullOrWhitespace(appImageId) && !hashAppImage.containsKey(appImageId)){
					hashAppImage.put(appImageId, new ApplicationsEngine().setApplicationImageObject(rs));
				}

				String appPlatformId = rs.getString(PortalDBEnum.APPLICATION_PLATFORM.appPlatformId.name());
				if(!StringFunctions.isNullOrWhitespace(appPlatformId) && !hashAppPlatform.containsKey(appPlatformId)){
					/*
					 * create ApplicationPlatformVO new object set values and ADD in hashAppPlatform.
					 */
					ApplicationPlatformVO platformVO = new ApplicationPlatformVO();
					platformVO.setAppId(rs.getString(PortalDBEnum.APPLICATION.appId.name()));
					platformVO.setAppPlatformId(appPlatformId);
					platformVO.setPlatformId(rs.getString(PortalDBEnum.APPLICATION_PLATFORM.platformId.name()));
					platformVO.setRepositoryName(rs.getString(PortalDBEnum.APPLICATION_PLATFORM.repositoryName.name()));
					hashAppPlatform.put(appPlatformId, platformVO);
				}
			}
		}
		if(devAppDetailsVO == null){
			throw new SQLException("Application detail not found.");
		}

		//setting object to be returned to UI
		if (devAppDetailsVO.getAppOwnerId().equals(authVo.getUserId()))  //If owner, get all versions
			devAppDetailsVO.setVersions(new VersionEngine().getVersionsOfApp(appId, authVo.getUserId()));  //get list of versions according to the role
		else if(!authVo.getGroupPermissions().isEmpty()) {
			//load app versions according to permissions
			devAppDetailsVO.setVersions(new VersionEngine().getVersionsOfGroupApp(appId,authVo, "", "", filterVersionStstus));
		}

		/*
		 * add serviceEndpoints values from hashServiceEndpoints which we set in resultSet iterator.
		 */
		devAppDetailsVO.getServiceEndpoints().addAll(hashServiceEndpoints.values());
		/*
		 * add categories values from hashCategory which we set in resultSet iterator.
		 */
		devAppDetailsVO.getCategories().addAll(hashCategory.values());
		/*
		 * set application images object from hashAppImage object which set in ResultSet iteration.
		 */
		devAppDetailsVO.getImages().addAll(hashAppImage.values());

		devAppDetailsVO.getPlatFormList().addAll(hashAppPlatform.values());
		return devAppDetailsVO;
	}


	private List<DeveloperApplicationVO> mListInvitedApps(List<String> groupIds) throws SQLException {
		List<DeveloperApplicationVO> listDevApps = new ArrayList<>();
		DeviceApplicationsDB deviceApplicationsDB = new DeviceApplicationsDB();
		String sql = deviceApplicationsDB.listInvitedApps(groupIds.size());

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameters(groupIds).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				listDevApps.add(setDevApplicationObject(rs));
			}
		}
		return listDevApps;
	}

	/**
	 * Add new application in database with related information (images, categories, version)
	 * @param appDetailsVO Object of ApplicationDetailsVO class contains(Version info, app exist in which category, app images with sequence no.)
	 * @return
	 * @throws Exception
	 */
	private ApplicationDetailsVO mCreateApplication(ApplicationDetailsVO appDetailsVO) throws SQLException{
		//set new randomId in applicationId.
		appDetailsVO.setApplicationId(Common.getRandomId());
		/*
		 * temp set random price and rating for sorting use on UI 
		 * To generate random number between 1 to 100 use following code
		 */
		try{

			appDetailsVO.setPrice(BigDecimal.valueOf(0.00));

			/*
			 * To generate random number between 1 to 5 use following code
			 */
			double dbl = (Math.random()*5);
			if(dbl < 1){
				dbl = 0;
			}
			appDetailsVO.setRating(Double.parseDouble(String.format("%.1f", dbl)));
		}catch(Exception ex){
			appDetailsVO.setPrice(BigDecimal.valueOf(0.00));
			appDetailsVO.setRating(0);
		}
		if(appDetailsVO.getSignUpType() == null){
			appDetailsVO.setSignUpType(SignUpTypeEnum.None);
		}
		//call method for getting create application queries.
		List<QueryVO> queries = mCreateApplicationQueryObjects(appDetailsVO);
		//execute create application queries in transaction.
		PortalDatabaseEngine.getInstance().getConnection().executeUpdatesInTransaction(queries);
		return appDetailsVO;
	}


	/**
	 * add application and related information (applicationcategories) in database.
	 * @param appDetailsVO Object of ApplicationDetailsVO class contains(app exist in which category, app images with sequence no.)
	 * @return
	 * @throws SQLException 
	 */
	private ArrayList<QueryVO> mCreateApplicationQueryObjects(ApplicationDetailsVO appDetailsVO) throws SQLException {
		ArrayList<QueryVO> listQuery = new ArrayList<>();

		//Get Insert query for Application.
		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new ApplicationDetailsDB().getAddApplicationQuery())
				.addParameter(appDetailsVO.getApplicationId())
				.addParameter(appDetailsVO.getProjectId())
				.addParameter(appDetailsVO.getUserId())
				.addParameter(appDetailsVO.getTitle())
				.addParameter(appDetailsVO.getDescription())
				.addParameter(appDetailsVO.getWebAddress())
				//set randomId in secretKey.
				.addParameterEncrypted(Common.getRandomId())
				.addParameter(appDetailsVO.getAppStatus().ordinal())
				.addParameter(appDetailsVO.getAppTypeId())
				.addParameter(appDetailsVO.isUsePxAuth())
				.addParameter(appDetailsVO.isUsePxCloudApi())
				.addParameter(appDetailsVO.isUsePxEventService())
				.addParameter(appDetailsVO.getSignUpType().ordinal())
				.addParameter(appDetailsVO.getPrice())
				.addParameter(appDetailsVO.getRating())
				.addParameter(appDetailsVO.getCurrency())
				.addParameter(appDetailsVO.isRunAsService())
				.build();

		listQuery.add(queryVO);

		//Get Insert query for ApplicationImage images are multiple.
		//Get Insert query for ApplicationCategories( this table maintain app - categories relation) categories are multiple.
		for (CategoryVO cat : appDetailsVO.getCategories()) {
			QueryVO queryVOCat = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
					.appendQuery(new ApplicationDetailsDB().getAddAppCategoryQuery())
					.addParameter(appDetailsVO.getApplicationId())
					.addParameter(cat.getCategoryId())
					.build();

			listQuery.add(queryVOCat);
		}
		return listQuery;
	}

	private ApplicationDetailsVO mUpdateApplication(ApplicationDetailsVO appDetailsVO) throws SQLException{
		//call method for getting update application queries.
		List<QueryVO> queries = mUpdateApplicationQueryObject(appDetailsVO);
		//execute create application queries in transaction.
		PortalDatabaseEngine.getInstance().getConnection().executeUpdatesInTransaction(queries);
		return appDetailsVO;
	}

	/**
	 * update application and related information (application info and applicationcategories) in database.
	 * @param appDetailsVO Object of ApplicationDetailsVO class contains(app exist in which category)
	 * @return
	 * @throws SQLException 
	 */
	private ArrayList<QueryVO> mUpdateApplicationQueryObject(ApplicationDetailsVO appDetailsVO) throws SQLException {
		ArrayList<QueryVO> listQuery = new ArrayList<>();

		QueryVO updateQueryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new ApplicationDetailsDB().getUpdateQueryForApplication())
				.addParameter(appDetailsVO.getTitle())
				.addParameter(appDetailsVO.getDescription())
				.addParameter(appDetailsVO.getWebAddress())
				.addParameter(appDetailsVO.getAppStatus().ordinal())
				.addParameter(appDetailsVO.isUsePxAuth())
				.addParameter(appDetailsVO.isUsePxCloudApi())
				.addParameter(appDetailsVO.isUsePxEventService())
				.addParameter(appDetailsVO.getPrice())
				.addParameter(appDetailsVO.getRating())
				.addParameter(appDetailsVO.getApplicationId())
				.build();


		//Get Insert query for Application.
		listQuery.add(updateQueryVO);

		/**
		 * on update app, delete all app-category relation using appId,
		 * and again add all entries in db which exist in category list,
		 * because if user wants to remove app from some categories.
		 */
		QueryVO deleteAppCategoriesQueryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new ApplicationDetailsDB().deleteAppCategories())
				.addParameter(appDetailsVO.getApplicationId()).build();

		listQuery.add(deleteAppCategoriesQueryVO);
		//Get add query for ApplicationCategories( this table maintain app - categories relation) categories are multiple.
		for (CategoryVO cat : appDetailsVO.getCategories()) {
			
			QueryVO queryVOCat = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
					.appendQuery(new ApplicationDetailsDB().getAddAppCategoryQuery())
					.addParameter(appDetailsVO.getApplicationId())
					.addParameter(cat.getCategoryId())
					.build();
			
			listQuery.add(queryVOCat);
		}
		return listQuery;
	}
	
	private void mUpdateApplicationLogo(String appId, String logoPath) throws SQLException{
		//get query for update application logo.
	
		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new ApplicationDetailsDB().updateApplicationLogo()).addParameter(logoPath).addParameter(appId).build();

		//execute sql.
		PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
	}

	private void mDeleteApplication(String appId,String userId) throws SQLException{

		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new ApplicationsDB().deleteApplication())
				.addParameter(appId)
				.addParameter(userId)
				.build();


		PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
	}

	private VersionVO mGetVersionDetails(String appId, String versionId) throws SQLException{
		VersionVO versionVO = null;
		
		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new ApplicationVersionDB().getVersionDetails()).addParameter(appId).addParameter(versionId).build();
		
		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)){
			while (rs.next()) {
				versionVO = new VersionEngine().setVersionObject(rs);
			}
		}
		return versionVO;
	}

	private String mGetVersionComposeYMLPath(String appId, String versionId) throws SQLException{
		String configYmlPath = null;

		List<String> paramters = new ArrayList<>();
		paramters.add(appId);
		
		if(!StringFunctions.isNullOrWhitespace(versionId)){
			paramters.add(versionId);
		}
		
		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new ApplicationVersionDB().getVersionComposeYMLPath(versionId)).addParameters(paramters).build();
		
		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)){
			while (rs.next()) {
				configYmlPath = rs.getString(PortalDBEnum.APPLICATION_VERSIONS.composerFilePath.name());
			}
		}
		return configYmlPath;
	}

	private String mGetComposeVersion(String appId, String version) throws SQLException{
		String composeVersion = null;

		List<Object> parameters = new ArrayList<>();
		parameters.add(appId);

		if(!StringFunctions.isNullOrWhitespace(version))
			parameters.add(version);

		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new ApplicationVersionDB().getComposeVersion(version))
				.addParameters(parameters).build();

		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)){
			while (rs.next()) {
				composeVersion = rs.getString(PortalDBEnum.APPLICATION_VERSIONS.composeVersion.name());
			}
		}
		return composeVersion;
	}

	private List<AppCommandVO> mGetAppVersionCommand(String userId, String applicationId, String appVersionId,
			List<String> grpIds) throws SQLException {
		// String sql = new DeviceApplicationsDB().getAppVersionCommand(userId,
		// applicationId, appVersionId, grpIds);
		
		List<String> edgeCoreIds = new ApplicationsEngine().getEdgeCoreByGroupIds(grpIds);
		
		String sql = new DeviceApplicationsDB().getAppVersionCommand(edgeCoreIds);

		SqlQueryBuilder queryBuilder = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(appVersionId).addParameter(applicationId).addParameter(userId);
		if (edgeCoreIds != null && !edgeCoreIds.isEmpty()) {
			queryBuilder.addParameters(edgeCoreIds);
		}
		QueryVO queryVO = queryBuilder.build();

		List<AppCommandVO> result = new ArrayList<>();
		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				String[] actions = rs.getString("actions").split(",");
				AppCommandVO appCommandVO = new AppCommandVO();
				appCommandVO.setActions(Arrays.asList(actions));
				appCommandVO.setDeviceId(rs.getString(PortalDBEnum.DEVICE_APPLICATIONS.deviceId.name()));
				appCommandVO.setDeviceName(rs.getString(PortalDBEnum.DEVICES.deviceName.name()));
				result.add(appCommandVO);
			}
		}

		return result;
	}

	private boolean mCheckUpdate(String appVersionId) throws SQLException {

		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new ApplicationsDB().checkUpdate()).addParameter(appVersionId).build();

		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			return rs.next();
		}
	}

	private List<VersionVO> mListAppVersion(String appId, String userId, String appVersionId, String appPlatformId,
			List<VERSION_STATUS> filterVersionStatus) throws SQLException {
		String appOwnerId = null;
		List<VersionVO> versionVOs = new ArrayList<>();

		// find appUserId and appVersion from appVersionId
		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
						.appendQuery(new ApplicationsDB().getAppVersionAndUserIdOfApp()).addParameter(appVersionId)
						.build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				appOwnerId = rs.getString(PortalDBEnum.APPLICATION.userId.name());
			}
		}
		String sql = "";
		QueryVO queryVO2 = null;
		if (appOwnerId != null && appOwnerId.equals(userId)) {
			// owner
			sql = new ApplicationsDB().listAppVersion(true, appPlatformId, filterVersionStatus);
			queryVO2 = getAppVersionObj(sql, appId, appVersionId, true, appPlatformId, filterVersionStatus);
		} else {
			sql = new ApplicationsDB().listAppVersion(false, appPlatformId, filterVersionStatus);
			queryVO2 = getAppVersionObj(sql, appId, appVersionId, false, appPlatformId, filterVersionStatus);
		}

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO2)) {
			while (rs.next()) {
				versionVOs.add(new VersionEngine().setVersionObject(rs));
			}
		}

		return versionVOs;
	}
	
	private QueryVO getAppVersionObj(String sql, String appId, String appVersionId, boolean isOwner,
			String appPlatformId, List<VERSION_STATUS> filterVersionStatus) {
		List<Integer> lstVersionStatus = new ArrayList<>();
		for (VERSION_STATUS version_STATUS : filterVersionStatus) {
			lstVersionStatus.add(version_STATUS.ordinal());
		}

		SqlQueryBuilder queryBuilder = new SqlQueryBuilder();
		queryBuilder.appendQuery(sql);
		if (!isOwner) {
			queryBuilder.addParameter(appId);
			queryBuilder.addParameter(appId);

			queryBuilder.addParameters(filterVersionStatus);
			if (!StringFunctions.isNullOrWhitespace(appPlatformId)) {
				queryBuilder.addParameter(appPlatformId);
			}
			queryBuilder.addParameter(appVersionId);
		} else {
			queryBuilder.addParameter(appId);
			queryBuilder.addParameters(lstVersionStatus);
			if (!StringFunctions.isNullOrWhitespace(appPlatformId)) {
				queryBuilder.addParameter(appPlatformId);
			}
			queryBuilder.addParameter(appVersionId);
		}

		return queryBuilder.build();
	}
	

	private List<String> mGetAppVersionAndUserIdOfApp(String appVersionId) throws SQLException{
		List<String> lstVersion = new ArrayList<>();

		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new ApplicationsDB().getAppVersionAndUserIdOfApp()).addParameter(appVersionId).build();

		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)){
			while (rs.next()){
				lstVersion.add(rs.getString(PortalDBEnum.APPLICATION_VERSIONS.appVersion.name()));
				lstVersion.add(rs.getString(PortalDBEnum.APPLICATION.userId.name()));
				lstVersion.add(rs.getString(APPLICATION_VERSIONS.appPlatformId.name()));
			}
		}
		return lstVersion;
	}

	protected DeveloperApplicationVO setDevApplicationObject(ResultSet rs) throws SQLException{
		DeveloperApplicationVO devAppVO = new DeveloperApplicationVO();
		devAppVO.setApplicationId(rs.getString(PortalDBEnum.APPLICATION.appId.name()));
		devAppVO.setAppTypeId(rs.getString(PortalDBEnum.APPLICATION.appTypeId.name()));
		devAppVO.setProjectId(rs.getString(PortalDBEnum.APPLICATION.projectId.name()));
		devAppVO.setIcon(rs.getString(PortalDBEnum.APPLICATION.icon.name()));
		if(!StringFunctions.isNullOrWhitespace(devAppVO.getIcon())){
			devAppVO.setIcon(PortalCommon.getInstance().createPublicUrl(devAppVO.getIcon(), Constants.UI_FOLDER_NAME));
		}

		devAppVO.setAppStatus(Status.GetEnum(rs.getInt(PortalDBEnum.APPLICATION.appStatus.name())));
		devAppVO.setTitle(rs.getString(PortalDBEnum.APPLICATION.title.name()));
		devAppVO.setUserId(rs.getString(PortalDBEnum.APPLICATION.userId.name()));
		devAppVO.setWebAddress(rs.getString(PortalDBEnum.APPLICATION.webAddress.name()));
		//AKH_02, AKH_03
		devAppVO.setCreatedDate(rs.getTimestamp(PortalDBEnum.APPLICATION.createdDate.name()).getTime());
		devAppVO.setModifiedDate(rs.getTimestamp(PortalDBEnum.APPLICATION.modifiedDate.name()).getTime());
		return devAppVO;
	}

	protected ServiceEndpointVO setServiceEndpointObject(ResultSet rs) throws SQLException{

		ServiceEndpointVO serviceEndpoint = new ServiceEndpointVO();
		serviceEndpoint.setAppServiceEndpointId(rs.getString(PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.appServiceEndpointId.name()));
		serviceEndpoint.setAppVersionId(rs.getString(PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.appVersionId.name()));
		serviceEndpoint.setAppId(rs.getString(PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.appId.name()));
		serviceEndpoint.setPlatformId(rs.getString(PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.platformId.name()));
		serviceEndpoint.setContainerPort(rs.getInt(PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.containerPort.name()));
		serviceEndpoint.setCustomHeaders(rs.getString(PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.customHeaders.name()));
		serviceEndpoint.setImageName(rs.getString(PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.imageName.name()));
		serviceEndpoint.setProtocol(rs.getString(PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.protocol.name()));
		serviceEndpoint.setServiceName(rs.getString(PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.serviceName.name()));
		return serviceEndpoint;
	}

}

/**
 * History of check-in or issue resolved
 * 
 * 01 - 21-10-2016 
 * AKH_01_1
 * set currency, price and rating field for used sorting on UI. 
 * 
 * 02 - 4-11-2016
 * AKH_02
 * set restRedirectUrl and redirectSection in application we save "reverse proxy" and "specific port" in redirect Url and rest Url save in restRedirectUrl.
 * 
 * 03 - 14-11-2016 AKH_03
 * remove restRedirectUrl, redirectUrl, redirectType and redirectSection these property shift to applicationVersion,
 * because may be each version have different redirection param.
 */