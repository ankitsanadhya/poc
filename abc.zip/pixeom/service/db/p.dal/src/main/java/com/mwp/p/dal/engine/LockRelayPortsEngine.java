/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal.engine;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.common.vo.QueryVO;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.common.vo.LockRelayPortsVO;
import com.mwp.p.dal.LockRelayPortsDB;

/**
 * Manages lock on relay server ports 
 *
 */
public class LockRelayPortsEngine {

	/**
	 * Add lock for relay ports
	 * @param deviceId
	 * @param relayServerID
	 * @param portSegmentStart
	 * @return
	 * @throws SQLException
	 */
	public boolean addLockRelayPorts(String deviceId, String relayServerID, int portSegmentStart) throws SQLException {
		return mAddLockRelayPorts(deviceId, relayServerID, portSegmentStart);
	}

	/**
	 * Get list of locks relay server ports 
	 * @param relayServerID
	 * @param portSegmentStart
	 * @return
	 * @throws SQLException
	 */
	public List<LockRelayPortsVO> getListLockRelayPorts(String relayServerID, int portSegmentStart) throws SQLException {
		return mGetListLockRelayPorts(relayServerID, portSegmentStart);
	}
	
	/**
	 * Delete lock for relay server that has time older then 5 minutes.
	 * @return boolean
	 * @throws SQLException
	 */
	public boolean deleteExpiredLocks() throws SQLException {
		return mDeleteExpiredLocks();
	}
	
	/**
	 * delete lock on relay ports for device id
	 * @param deviceId
	 * @return
	 * @throws SQLException
	 */	
	public boolean deleteLockRelayPorts(String deviceId) throws SQLException {
		return mDeleteLockRelayPorts(deviceId);
	}
	
	private boolean mDeleteLockRelayPorts(String deviceId) throws SQLException {
		
		QueryVO deleteLockRelayPortsQueryVO =  new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new LockRelayPortsDB().deleteLockRelayPorts()).addParameter(deviceId).build();
		
		int deleteCount = PortalDatabaseEngine.getInstance().getConnection().executeUpdate(deleteLockRelayPortsQueryVO);
		return deleteCount != 0;
	}
	
	private boolean mDeleteExpiredLocks() throws SQLException {
		String sql = new LockRelayPortsDB().deleteExpiredLocks();
		QueryVO queryVO =  new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(sql).build();
		int deleteCount = PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
		return deleteCount != 0;
	}
	
	private List<LockRelayPortsVO> mGetListLockRelayPorts(String relayServerID, int portSegmentStart)
			throws SQLException {
		List<LockRelayPortsVO> listLockRelayPort = new ArrayList<>();
		String sql = new LockRelayPortsDB().getLockRelayPorts();
		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(relayServerID).addParameter(portSegmentStart).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				LockRelayPortsVO detailsVO = new LockRelayPortsVO();
				detailsVO.setsDeviceID(rs.getString(PortalDBEnum.LOCK_RELAY_PORTS.sDeviceID.name()));
				detailsVO.setsRelayServerID(rs.getString(PortalDBEnum.LOCK_RELAY_PORTS.sRelayServerID.name()));
				detailsVO.setnPortSegmentStart(rs.getInt(PortalDBEnum.LOCK_RELAY_PORTS.nPortSegmentStart.name()));
				detailsVO.setdModified(rs.getTimestamp(PortalDBEnum.LOCK_RELAY_PORTS.dModified.name()).getTime());
				listLockRelayPort.add(detailsVO);
			}
		}
		return listLockRelayPort;
	}

	private boolean mAddLockRelayPorts(String deviceId, String relayServerID, int portSegmentStart)
			throws SQLException {
		String sql = new LockRelayPortsDB().addLockRelayPorts();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(deviceId).addParameter(relayServerID).addParameter(portSegmentStart).build();

		int addCount = PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
		return addCount != 0;
	}
	
}
