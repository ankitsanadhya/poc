/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal;

import com.mwp.p.common.enums.PortalDBEnum.SUPPORT_LOCK_RELAY_PORTS;

/**
 * This class provides queris related to table {@link SUPPORT_LOCK_RELAY_PORTS}
 *
 */
public class SupportLockRelayPortsDB {

	/**
	 * create query to add lock entry for relay ports. 
	 * @param deviceId
	 * @param relayServerId
	 * @param portSegmentStart
	 * @return
	 */
	public String placeBid(){
		return "INSERT INTO supportlockrelayports (sDeviceID, sRelayServerID, nPortSegmentStart, dModified) "
				+ "VALUES ("+ "?" +","+ "?" +", "+ "?" +", NOW()) ";
	}
	
	/**
	 * Delete locks of a device 
	 * @param deviceId
	 * @return
	 */
	public String deleteDeviceBids(){
		return "DELETE FROM supportlockrelayports WHERE sDeviceID = "+ "?";
	}
	
	/**
	 * List bids of relay serverid  
	 * @param relayServerId
	 * @param portSegmentStart
	 * @return
	 */
	public String listBids(){
		return "SELECT * FROM supportlockrelayports "
				+ "WHERE sRelayServerID = "+ "?" +" AND nPortSegmentStart = "+ "?" +" ORDER BY dModified";
	}
	
	/**
	 * delete all expired locks which are older than 5 min 
	 * @return
	 */
	public String deleteExpiredLocks() {
		return "DELETE FROM supportlockrelayports WHERE dModified < (NOW() - INTERVAL 5 MINUTE) ";
	}
}
