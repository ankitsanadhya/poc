/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal.engine;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.common.vo.FunctionVO;
import com.mwp.common.vo.FunctionVersionVO;
import com.mwp.common.vo.QueryVO;
import com.mwp.p.common.Constants;
import com.mwp.p.common.PortalCommon;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.dal.FunctionVersionsDB;
import com.mwp.p.dal.FunctionsDB;

/**
 * This class manages and executes queires related to funcations and versions.Provied functionality to add, delete update functions and its versions.
 */
public class FunctionsEngine {
	//****************************FUNCTION*************************************
	/**
	 * Add new function in database.
	 * @param FunctionVO
	 * @return
	 * @throws Exception 
	 */
	public FunctionVO addFunction(FunctionVO functionVO) throws SQLException {
		return mAddFunction(functionVO);
	}

	/**
	 * Check if function with same name already exists or not.
	 * @param functionName
	 * @param userId
	 * @return
	 * @throws SQLException
	 */
	public boolean checkFunctionNameExist(String functionName, String userId) throws SQLException {
		return mCheckFunctionNameExist(functionName, userId);
	}


	/**
	 * List all functions of user with user id.
	 * @param userId 
	 * @return
	 * @throws SQLException 
	 */
	public List<FunctionVO> listAllFunctions(String userId) throws SQLException {
		return mListAllFunctions(userId);
	}

	/**
	 *  Get function with given function id and  version id
	 * @param functionId
	 * @param versionId
	 * @return FunctionVO object
	 * @throws Exception
	 */
	public FunctionVO getFunction(String functionId, String versionId,String userId) throws SQLException {
		return mGetFunction(functionId, versionId,userId);
	}

	/**
	 * Get all versions of function for given version ids. 
	 * @param versionIds comma seperated list of version ids.
	 * @return List of FunctionVersionVO  object
	 * @throws Exception
	 */
	public List<FunctionVersionVO> getFunctionVersions(List<String> versionIds) throws SQLException {
		return mGetFunctionVersions(versionIds);
	}

	/**
	 * Get object of function for given function id.
	 * @param functionId function id 
	 * @return FunctionVO object
	 * @throws Exception 
	 */
	public FunctionVO getFunction(String functionId) throws SQLException {
		return mGetFunction(functionId);
	}

	/**
	 * delete a function with function Id.
	 * @param functionId 
	 * @return deleted function funcationId
	 * @throws Exception 
	 */
	public void deleteFunction(String functionId) throws SQLException {
		mDeleteFunction(functionId);
	}


	//****************************FUNCTION VERSION*************************************
	/**
	 * Get maximum version number of function
	 * @param functionId
	 * @return
	 * @throws SQLException
	 */
	public int getMaxVersion(String functionId) throws SQLException {
		return mGetMaxVersion(functionId);
	}

	/**
	 * Add version to a function
	 * @param FunctionVO
	 * @return
	 * @throws Exception 
	 */
	public FunctionVersionVO addFunctionVersion(FunctionVersionVO versionVO) throws SQLException {
		return mAddFunctionVersion(versionVO);
	}

	/**
	 * List all versions of a given function id.
	 * @param FunctionVO
	 * @return ArrayList<FunctionVersionVO>
	 * @throws Exception 
	 */
	public List<FunctionVersionVO> listAllVersion(String functionId, boolean isBodyRequired) throws SQLException {
		return mListAllVersion(functionId, isBodyRequired);
	}


	/**
	 * Delete version of function 
	 * @param functionId
	 * @param versionId
	 * @throws SQLException
	 */
	public void deleteFunctionVersion(String functionId, String versionId) throws SQLException {
		mDeleteFunctionVersion(functionId, versionId);
	}
	//****************************PRIVATE METHODS*************************************



	private int mGetMaxVersion(String functionId) throws SQLException {
		FunctionVersionsDB versionsDB = new FunctionVersionsDB();
		String sql = versionsDB.getMaxFunctionVersion();
		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(functionId).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				return rs.getInt("max");
			}
		}
		return 0;
	}

	private boolean mCheckFunctionNameExist(String functionName, String userId) throws SQLException {
		FunctionsDB functionsDB = new FunctionsDB();
		String sql = functionsDB.isFunctionExists();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(functionName).addParameter(userId).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				return true;
			}
		}

		return false;
	}

	private FunctionVO mAddFunction(FunctionVO functionVO) throws SQLException {
		FunctionsDB functionsDB = new FunctionsDB();
		List<QueryVO> queries = new ArrayList<>();

		String sql = functionsDB.addFunction();
		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(functionVO.getFunctionId()).addParameter(functionVO.getUserId())
						.addParameter(functionVO.getName()).build();

		queries.add(queryVO);

		String addFunctionVersionSQL = new FunctionVersionsDB().addFunctionVersion();

		int count = 1;
		for (FunctionVersionVO versionVO : functionVO.getVersions()) {
			versionVO.setFunctionId(functionVO.getFunctionId());
			versionVO.setVersion(count);

			queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
					.appendQuery(addFunctionVersionSQL).addParameter(versionVO.getFunctionVersionId())
					.addParameter(versionVO.getFunctionId()).addParameter(versionVO.getVersion())
					.addParameter(versionVO.getFunctionBody()).addParameter(versionVO.getToExecute()).build();
			queries.add(queryVO);
			count++;
		}

		PortalDatabaseEngine.getInstance().getConnection().executeUpdatesInTransaction(queries);

		return functionVO;
	}
	
	

	private FunctionVersionVO mAddFunctionVersion(FunctionVersionVO versionVO) throws SQLException {
		String sql = new FunctionVersionsDB().addFunctionVersion();
		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(versionVO.getFunctionVersionId()).addParameter(versionVO.getFunctionId())
						.addParameter(versionVO.getVersion()).addParameter(versionVO.getFunctionBody())
						.addParameter(versionVO.getToExecute()).build();
		int updateCount = PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
		if (updateCount == 0) {
			throw new SQLException("FunctionVersion adding failed.");
		}

		return versionVO;
	}

	private List<FunctionVO> mListAllFunctions(String userId) throws SQLException {
		ArrayList<FunctionVO> listFunction = new ArrayList<>();
		HashMap<String, FunctionVO> hashFunction = new HashMap<>();
		FunctionsDB functionsDB = new FunctionsDB();
		String sql = functionsDB.listAllFunctions();
		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(userId).build();
		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				FunctionVO functionVO = null;
				String functionId = rs.getString(PortalDBEnum.FUNCTIONS.functionId.name());
				if (hashFunction.containsKey(functionId)) {
					functionVO = hashFunction.get(functionId);
				} else {
					functionVO = createFunctionVO(rs);
				}
				FunctionVersionVO functionVersionVO = createFunctionVersionVO(rs, false);
				if (functionVersionVO != null) {
					functionVO.getVersions().add(functionVersionVO);
				}

				hashFunction.put(functionId, functionVO);
			}
		}
		listFunction.addAll(hashFunction.values());
		return listFunction;
	}

	private List<FunctionVersionVO> mListAllVersion(String functionId, boolean isBodyRequired) throws SQLException {
		ArrayList<FunctionVersionVO> listFunctionVersion = new ArrayList<>();
		FunctionVersionsDB functionVersionDB = new FunctionVersionsDB();
		String sql = functionVersionDB.listAllVersion();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(functionId).build();
		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()){
				listFunctionVersion.add(createFunctionVersionVO(rs, isBodyRequired));
			}
		}
		return listFunctionVersion;
	}

	private FunctionVO mGetFunction(String functionId, String versionId, String userId) throws SQLException {
		FunctionVO functionVO = null;
		// String sql = new FunctionsDB().getFunctionVersion(functionId,
		// versionId,userId);
		String sql = new FunctionsDB().getFunctionVersion();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(functionId).addParameter(versionId).addParameter(userId).build();
		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				functionVO = createFunctionVO(rs);
				FunctionVersionVO functionVersionVO = createFunctionVersionVO(rs, true);
				if (functionVersionVO != null) {
					functionVO.getVersions().add(functionVersionVO);
				}
			}
		}
		return functionVO;
	}

	private List<FunctionVersionVO> mGetFunctionVersions(List<String> versionIds) throws SQLException {
		List<FunctionVersionVO> functionVersionVOs = new ArrayList<>();

		String sql = new FunctionsDB().getFunctionVersions(versionIds);

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameters(versionIds).build();
		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				functionVersionVOs.add(createFunctionVersionVO(rs, true));
			}
		}
		return functionVersionVOs;
	}

	private FunctionVO mGetFunction(String functionId) throws SQLException {
		FunctionVO functionVO = new FunctionVO();
		String sql = new FunctionsDB().getFunction();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(functionId).build();
		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				functionVO = createFunctionVO(rs);
			}
		}
		return functionVO;
	}

	private void mDeleteFunction(String functionId) throws SQLException {
		List<QueryVO> queries = new ArrayList<>();

		String sql = new FunctionVersionsDB().deleteFunctionVersion();
		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(functionId).build();
		queries.add(queryVO);

		String functionSql = new FunctionsDB().deleteFunction();
		queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(functionSql).addParameter(functionId).build();
		queries.add(queryVO);
		
		PortalDatabaseEngine.getInstance().getConnection().executeUpdatesInTransaction(queries);
	}

	private void mDeleteFunctionVersion(String functionId, String versionId) throws SQLException {
		String sql = new FunctionVersionsDB().deleteFunctionVersionWithVersionId();
		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(functionId).addParameter(versionId).build();
		PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
	}

	private FunctionVO createFunctionVO(ResultSet rs) throws SQLException {
		FunctionVO functionVO = new FunctionVO();
		functionVO.setFunctionId(rs.getString(PortalDBEnum.FUNCTIONS.functionId.name()));
		functionVO.setModifiedDate(rs.getTimestamp(PortalDBEnum.FUNCTIONS.modifiedDate.name()).getTime());
		functionVO.setName(rs.getString(PortalDBEnum.FUNCTIONS.name.name()));
		functionVO.setUserId(rs.getString(PortalDBEnum.FUNCTIONS.userId.name()));
		return functionVO;
	}

	private FunctionVersionVO createFunctionVersionVO(ResultSet rs, boolean isBodyRequired) throws SQLException {
		FunctionVersionVO versionVO = new FunctionVersionVO();
		versionVO.setFunctionVersionId(rs.getString(PortalDBEnum.FUNCTION_VERSIONS.functionVersionId.name()));
		if(versionVO.getFunctionVersionId() == null) {
			return null;
		}
		versionVO.setFunctionId(rs.getString(PortalDBEnum.FUNCTION_VERSIONS.functionId.name()));
		versionVO.setModifiedDate(rs.getTimestamp("versionModifiedDate").getTime());
		versionVO.setVersion(rs.getInt(PortalDBEnum.FUNCTION_VERSIONS.version.name()));
		versionVO.setToExecute(rs.getString(PortalDBEnum.FUNCTION_VERSIONS.toExecute.name()));

		if(isBodyRequired){
			versionVO.setFunctionName(rs.getString(PortalDBEnum.FUNCTIONS.name.name()));
		}
		versionVO.setFunctionBody(PortalCommon.getInstance().createPublicUrl(rs.getString(PortalDBEnum.FUNCTION_VERSIONS.body.name()), Constants.UI_FOLDER_NAME));
		return versionVO;
	}

}
