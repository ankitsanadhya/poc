/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal.engine;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mwp.common.CredProvider;
import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.common.vo.EmailServersVO;
import com.mwp.common.vo.QueryVO;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.dal.EmailServerDal;
import com.pa.crypto.StringEncryptionDecryption;

/**
 * this class contains query executors for get email server from emailServers
 * table and parser to parse result set from emailServers Table
 * 
 * @author root
 *
 */
public class EmailServerEngine {
	/**
	 * method to get email server object to send mail from
	 * 
	 * @return
	 * @throws SQLException
	 */
	public EmailServersVO getEmailServer() throws SQLException {
		return mGetEmailServer();
	}

	/**
	 * list all email servers
	 * 
	 * @return
	 * @throws SQLException
	 */
	public List<EmailServersVO> listsAll(boolean toDecryptResult) throws SQLException {
		return mListsAll(toDecryptResult);
	}

	public List<EmailServersVO> listsAllOrderByPriority() throws SQLException {
		return mListsAllOrderByPriority();
	}

	public EmailServersVO insert(String serverId, String serverAddress, String serverName, int status, String username,
			String password, int port, int priority, boolean istls) throws Exception {
		return mInsert(serverId, serverAddress, serverName, status, username, password, port, priority, istls);
	}

	public EmailServersVO update(String serverId, String serverAddress, String serverName, int status, String username,
			String password, int port, int priority, boolean istls) throws SQLException {
		return mUpdate(serverId, serverAddress, serverName, status, username, password, port, priority, istls);
	}

	public void delete(String serverId) throws SQLException {
		mDelete(serverId);
	}

	private EmailServersVO mGetEmailServer() throws SQLException {
		EmailServerDal emailserverDalObj = new EmailServerDal(PortalDatabaseEngine.getInstance().getConnection());
		EmailServersVO emailServersVO = null;
		// query to get emailserver
		String get = emailserverDalObj.get();
		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(get)
				.addParameter("primaryEmail")
				.build();

		try (ResultSet result = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (result.next()) {
				// parse result set to emailServersVO object
				emailServersVO = parseResultSet(result, false);
			}
		}

		return emailServersVO;
	}

	private List<EmailServersVO> mListsAll(boolean toDecryptResult) throws SQLException
	{
		List<EmailServersVO> lstServer = new ArrayList<>();
		EmailServerDal emailserverDalObj = new EmailServerDal(PortalDatabaseEngine.getInstance().getConnection());
		String sql = emailserverDalObj.listAll();
		EmailServersVO voObj = null;
		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next())
			{
				voObj = parseResultSet(rs, toDecryptResult);
				lstServer.add(voObj);

			}
		}
		return lstServer;
	}

	private List<EmailServersVO> mListsAllOrderByPriority() throws SQLException
	{
		List<EmailServersVO> lstServer = new ArrayList<>();
		EmailServerDal emailserverDalObj = new EmailServerDal(PortalDatabaseEngine.getInstance().getConnection());
		String sql = emailserverDalObj.listsAllOrderByPriority();
		EmailServersVO voObj = null;
		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next())
			{
				voObj = parseResultSet(rs, true);
				lstServer.add(voObj);

			}
		}
		return lstServer;
	}

	private EmailServersVO mGet(String serverID) throws SQLException
	{
		EmailServersVO voObj = null;
		EmailServerDal emailserverDalObj = new EmailServerDal(PortalDatabaseEngine.getInstance().getConnection());
		String sql = emailserverDalObj.getEmailServer();
		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
				.addParameter(serverID)
				.build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next())
			{
				voObj = parseResultSet(rs, false);
			}
		}
		return voObj;
	}

	private boolean mIsExists(String serverID) throws SQLException
	{
		EmailServerDal emailserverDalObj = new EmailServerDal(PortalDatabaseEngine.getInstance().getConnection());
		String sql = emailserverDalObj.isExists();
		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
				.addParameter(serverID)
				.build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next())
			{
				return true;
			}
		}
		return false;
	}

	private EmailServersVO mInsert(String serverId, String serverAddress, String serverName, int status,
			String username, String password, int port, int priority, boolean isTLS) throws Exception {
		EmailServerDal emailserverDalObj = new EmailServerDal(PortalDatabaseEngine.getInstance().getConnection());
		boolean isExists = mIsExists(serverId);
		if (!isExists) {
			String sql = emailserverDalObj.insert();
			
			QueryVO queryVO = new SqlQueryBuilder(
					PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
					.addParameter(serverId)
					.addParameter(serverAddress)
					.addParameter(serverName)
					.addParameter(status)
					.addParameter(username)
					.addParameter(password)
					.addParameter(port)
					.addParameter(priority)
					.addParameter(isTLS)
					//ON DUPLICATE KEY UPDATE
					.addParameter(serverAddress)
					.addParameter(serverName)
					.addParameter(status)
					.addParameter(username)
					.addParameter(password)
					.addParameter(port)
					.addParameter(priority)
					.addParameter(isTLS)
					.build();
			
			PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
			return mGet(serverId);
		}
		throw new Exception("Id already exists.");

	}
	
	private EmailServersVO mUpdate(String serverId, String serverAddress, String serverName, int status,
			String username, String password, int port, int priority, boolean istls) throws SQLException {
		EmailServerDal emailserverDalObj = new EmailServerDal(PortalDatabaseEngine.getInstance().getConnection());

		String sql = emailserverDalObj.Update();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(serverAddress).addParameter(serverName)
						.addParameter(status).addParameter(username).addParameter(password).addParameter(port)
						.addParameter(istls).addParameter(priority).addParameter(serverId).build();

		PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
		return mGet(serverId);
	}

	private void mDelete(String serverId) throws SQLException {
		EmailServerDal emailserverDalObj = new EmailServerDal(PortalDatabaseEngine.getInstance().getConnection());
		String sql = emailserverDalObj.delete();
		
		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
				.addParameter(serverId)
				.build();
		
		PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
	}

	/**
	 * method to parse result set to EmailServersVO object
	 * 
	 * @param result
	 * @return
	 * @throws SQLException
	 */
	private EmailServersVO parseResultSet(ResultSet result, boolean toDecryptResult) throws SQLException {
		EmailServersVO emailServersVO = new EmailServersVO();
		emailServersVO.setServerId(result.getString(PortalDBEnum.EMAIL_SERVERS.serverId.name()));
		emailServersVO.setServerAddress(result.getString(PortalDBEnum.EMAIL_SERVERS.serverAddress.name()));
		emailServersVO.setServerName(result.getString(PortalDBEnum.EMAIL_SERVERS.serverName.name()));
		emailServersVO.setStatus(result.getInt(PortalDBEnum.EMAIL_SERVERS.status.name()));
		if (toDecryptResult) {
			String key = new CredProvider().getEcnKey();
			emailServersVO.setUsername(StringEncryptionDecryption
					.decrypt(result.getString(PortalDBEnum.EMAIL_SERVERS.username.name()), key));
			emailServersVO.setPassword(StringEncryptionDecryption
					.decrypt(result.getString(PortalDBEnum.EMAIL_SERVERS.password.name()), key));
		} else {
			emailServersVO.setUsername(result.getString(PortalDBEnum.EMAIL_SERVERS.username.name()));
			emailServersVO.setPassword(result.getString(PortalDBEnum.EMAIL_SERVERS.password.name()));
		}
		emailServersVO.setPort(result.getInt(PortalDBEnum.EMAIL_SERVERS.port.name()));
		emailServersVO.setPriority(result.getInt(PortalDBEnum.EMAIL_SERVERS.priority.name()));
		emailServersVO.setTLS(result.getBoolean(PortalDBEnum.EMAIL_SERVERS.istls.name()));
		emailServersVO.setModifiedDate(result.getTimestamp(PortalDBEnum.AD_ZONE.modifiedDate.name()).getTime());

		return emailServersVO;
	}

}
