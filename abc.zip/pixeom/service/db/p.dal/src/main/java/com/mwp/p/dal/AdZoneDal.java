/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal;

import com.mwp.db.Interface.IConnection;
import com.mwp.p.common.enums.PortalDBEnum;


/**
 * this class contains query to insert, edit, delete and list zones in adZone table
 * @author root
 *
 */
public class AdZoneDal 
{
	IConnection connection;
	String table;
	StringBuilder colList;

	public AdZoneDal(IConnection conn)
	{
		connection=conn;
		table= PortalDBEnum.TABLE_NAMES.adZone.name();
		
		colList= new StringBuilder(PortalDBEnum.AD_ZONE.adId.name());
		colList.append(", "	);			
		colList.append(PortalDBEnum.AD_ZONE.appId.name()); 
		colList.append( ", ");
		colList.append( PortalDBEnum.AD_ZONE.categoryId.name());
		colList.append( " ,");
		colList.append(PortalDBEnum.AD_ZONE.type.name()); 
		colList.append( ", ");	
		colList.append( PortalDBEnum.AD_ZONE.zoneId.name()); 
		colList.append( ", ");	
		colList.append(PortalDBEnum.AD_ZONE.sortOrder.name());
		colList.append( ", ");
		colList.append(PortalDBEnum.AD_ZONE.modifiedDate.name());

	}
	
	/**
	 * method to insert banner zone in db
	 * @param adId primary key
	 * @param deviceId
	 * @param appId
	 * @param category
	 * @param type
	 * @param zoneId
	 * @param sortOrder
	 * @return
	 */
	public String insert()
	{
		StringBuilder qry= new StringBuilder("INSERT INTO ");
		qry.append(table);
		qry.append( "(");
		qry.append( colList); 
		qry.append( ") VALUES (");	    
		qry.append("?");
		qry.append( ","	);   
		qry.append("?");
		qry.append( ",");
		qry.append("?");
		qry.append( ",");
		qry.append("?");
		qry.append(" ,");
		qry.append("?");
		qry.append( ",");
		qry.append("?");
		qry.append( ",");
		qry.append( "NOW()");
		qry.append( ")");
		return qry.toString();
	}
	
	/**
	 * method to edit sort order of zone
	 * @param sortOrder
	 * @param adId
	 * @return
	 */
	public String editSortOrder()
	{
		StringBuilder qry= new StringBuilder();
		qry.append("UPDATE ");
		qry.append(table);
		qry.append(" SET ");
		qry.append(PortalDBEnum.AD_ZONE.sortOrder.name());
		qry.append( " = ");
		qry.append("?");
		qry.append(" WHERE ");
		qry.append( PortalDBEnum.AD_ZONE.adId.name());
		qry.append( " = ");
		qry.append("?");
		return qry.toString();
	}
	
	/**
	 * method to delete a zone
	 * @param adId
	 * @return
	 */
	public String delete()
	{
		StringBuilder qry= new StringBuilder("DELETE FROM " );
		qry.append(table );
		qry.append(" WHERE " );
		qry.append(PortalDBEnum.AD_ZONE.adId.name());
		qry.append(" = " );
		qry.append("?");
		return qry.toString();

	}
	
	/**
	 * method to get zone for addId and zoneId 
	 * @param adId
	 * @param zoneId
	 * @return
	 */
	public String get()
	{
		StringBuilder qry= new StringBuilder("SELECT ");
		qry.append(colList);
		qry.append(" FROM ");
		qry.append(table);
		qry.append(" WHERE ");
		qry.append(PortalDBEnum.AD_ZONE.adId.name()); 
		qry.append(" = ");
		qry.append("?");
		qry.append(" and ");
		qry.append(PortalDBEnum.AD_ZONE.zoneId.name()); 
		qry.append(" = ");
		qry.append("?");
		return qry.toString();
	}
	
	/**
	 * list all ad zone
	 * @return
	 */
	public String list()
	{
		StringBuilder qry= new StringBuilder("SELECT ");
		qry.append(colList);
		qry.append(" FROM ");
		qry.append(table);
		return qry.toString();
	}
	
	/**
	 * list zone according to given type
	 * @return
	 */
	public String listByType()
	{
		StringBuilder qry= new StringBuilder("SELECT ");
		qry.append(colList);
		qry.append(" FROM ");
		qry.append(table);
		qry.append(" WHERE ");
		qry.append(PortalDBEnum.AD_ZONE.type.name()); 
		qry.append(" = ?");		
		return qry.toString();
	}
	
	/**
	 * list zone according to category
	 * @param categoryId
	 * @return
	 */
	public String listByCategory()
	{
		StringBuilder qry= new StringBuilder("SELECT ");
		qry.append(colList);
		qry.append(" FROM ");
		qry.append(table);
		qry.append(" WHERE ");
		qry.append(PortalDBEnum.AD_ZONE.categoryId.name()); 
		qry.append(" = ?");
		
		return qry.toString();
	}
}
