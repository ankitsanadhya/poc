/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.mwp.p.dal.engine;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import com.google.gson.Gson;
import com.mwp.common.Common;
import com.mwp.common.Utils;
import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.common.enums.MessageType;
import com.mwp.common.enums.NotificationType;
import com.mwp.common.enums.Operator;
import com.mwp.common.vo.AlertsVO;
import com.mwp.common.vo.FilterObject;
import com.mwp.common.vo.QueryVO;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.dal.AlertsDB;

public class AlertsEngine 
{

	/**
	 * Add alerts for system 
	 * @param clusterId
	 * @param nodeId
	 * @param ntype {@link NotificationType}
	 * @param notification
	 * @throws SQLException
	 */
	public void add(NotificationType ntype,Object notification, MessageType messageType, String commandMessage) throws SQLException
	{
		 mAdd(ntype, notification, messageType,commandMessage);
	}
	
	/**
	 * list of alerts according to filters
	 * @param filterObjects
	 * @param pageNo
	 * @param pageSize
	 * @return
	 * @throws SQLException
	 */
	public Map<String, Object>  listFilterAlerts(List<FilterObject> filterObjects,long pageNo, int pageSize) throws SQLException
	{
		return mListFilterAlerts(filterObjects, pageNo, pageSize);
	}
		
		
	private void mAdd( NotificationType ntype,Object notification, MessageType messageType, String commandMessage) throws SQLException
	{
		AlertsDB alertsDB = new AlertsDB();	
		
		String alertQuery =  alertsDB.insert();
		
		List<Object> parameters = new ArrayList<>();
		parameters.add(Common.getRandomId());
		parameters.add(ntype.ordinal());
		parameters.add(messageType.ordinal());
		parameters.add(new Gson().toJson(notification));
		parameters.add(commandMessage);

		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(alertQuery).addParameters(parameters).build();

		
		PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
	}
	
	private Map<String, Object> mListFilterAlerts(List<FilterObject> filterObjects, long pageNo, int pageSize)
			throws SQLException {
		Map<String, Object> hashOutput = new HashMap<>();
		ArrayList<AlertsVO> listAlerts = new ArrayList<>();
		AlertsDB alertsDB = new AlertsDB();

		List<String> queries = alertsDB.listAlertsFilter(filterObjects);

		int totalAlertCount = 0;

		long offset = (pageNo - 1) * pageSize;

		List<Object> parameters = createFilterParameters(filterObjects);
		parameters.add(pageSize);
		parameters.add(offset);

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
						.appendQuery(queries.get(0)).addParameters(parameters).build();

		QueryVO queryVOCount = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
						.appendQuery(queries.get(1)).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO);
				ResultSet rsCount = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVOCount)) {
			while (rsCount.next()) {
				totalAlertCount = rsCount.getInt("rowCount");
			}

			while (rs.next()) {
				listAlerts.add(setAlertObject(rs));
			}

		}

		int totalPages = totalAlertCount / pageSize;
		if ((totalAlertCount % pageSize) > 0) {
			totalPages += 1;
		}

		hashOutput.put("data", listAlerts);
		hashOutput.put("totalPages", totalPages);
		hashOutput.put("pageNo", pageNo);
		hashOutput.put("pageSize", pageSize);
		hashOutput.put("totalAlertCount", totalAlertCount);

		return hashOutput;
	}
	
	private List<Object> createFilterParameters(List<FilterObject> filters) {
		List<Object> parameters = new LinkedList<>();
		//SqlArrayParam sqlArryaParam = null;
		
		if (filters != null) {
			for (FilterObject filterObject : filters) {
				switch (filterObject.getFilterType()) {
				case FILTER:
					switch (filterObject.getFilterkey()) {
					case MessageType:
						List<Integer> lstMsgType = new ArrayList<>();
						for (String msgType : filterObject.getValues()) {
							lstMsgType.add(Integer.valueOf(msgType));
						}
						
						//sqlArryaParam = new SqlArrayParam(lstMsgType.toArray(), SQLConstant.TYPE_NAME_INTEGER);
						parameters.add(lstMsgType);

						break;
					case AlertType:
						List<Integer> lstAlertType = new ArrayList<>();
						for (String alertType : filterObject.getValues()) {
							lstAlertType.add(Integer.valueOf(alertType));
						}

						//sqlArryaParam = new SqlArrayParam(lstAlertType.toArray(), SQLConstant.TYPE_NAME_INTEGER);
						parameters.add(lstAlertType);

						break;
					default:
						break;
					}
					break;
				case SEARCHTEXT:
					if (filterObject.getOperator().ordinal() == Operator.LIKE.ordinal()) {
						parameters.add(Utils.getFormatStringForLike(true, filterObject.getStartValue(), true));
					} else if (filterObject.getOperator().ordinal() == Operator.EQUAL.ordinal()) {
						parameters.add(filterObject.getStartValue());
					}
					break;
				default:
					break;
				}
			}
		}

		return parameters;
	}
	
	private AlertsVO setAlertObject(ResultSet rs) throws SQLException{
		AlertsVO alert = new AlertsVO();
		alert.setAlertId(rs.getString(PortalDBEnum.ALERTS.alertId.name()));
		alert.setAlertType(NotificationType.GetEnum(rs.getInt(PortalDBEnum.ALERTS.alertType.name())));
		alert.setInfo(rs.getObject(PortalDBEnum.ALERTS.info.name()));
		alert.setCreatedDate(rs.getTimestamp(PortalDBEnum.ALERTS.createdDate.name()).getTime());
		alert.setCommandMessage(rs.getString(PortalDBEnum.ALERTS.commandMessage.name()));
		alert.setMessageType(MessageType.GetEnum(rs.getInt(PortalDBEnum.ALERTS.messageType.name())));
		return alert;
	}


}
