/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.mwp.common.StringFunctions;
import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.common.enums.DeviceTypeEnum;
import com.mwp.common.enums.NodeType;
import com.mwp.common.enums.Operator;
import com.mwp.common.enums.OwnershipEnum;
import com.mwp.common.enums.StateEnum;
import com.mwp.common.enums.Status;
import com.mwp.common.vo.FilterObject;
import com.mwp.p.common.enums.DevicesUtilityFilterType;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.common.enums.PortalDBEnum.DEVICES;
import com.mwp.p.common.enums.PortalDBEnum.DEVICES_NODES_VIEW;
import com.mwp.p.common.enums.PortalDBEnum.DEVICE_LABEL_MAP;
import com.mwp.p.common.enums.PortalDBEnum.TABLE_NAMES;
import com.mwp.s.common.enums.UpdateServiceDBEnum;

public class DevicesDB {

	/**
	 * Get list of all devices of user.In case of kubernetes cluster the node device will be in join result.In case of single device single row will be return from this query.
	 * Give device information for single device in case of kubernetes device or dockercompose device.
	 * The method queries from devicesnodes_view to node devices.
	 * @param userId user id 
	 * @param deviceType if to return specific devicetype kubernetes or docker compose if set to null then all type of devices will be return  
	 * @param isListLabels if true then label id will also be listed with device.
	 * @return
	 */
	public String listDevice(boolean isListLabels, DeviceTypeEnum deviceType) {
		return mListDevice(isListLabels, deviceType);
	}

	/**
	 * Add a single kubernetes device or docker compose device in database.
	 * @param deviceVO
	 * @param networkJson
	 * @return
	 */
	public List<String> addDevice() {
		return mAddDevice();
	}


	/**
	 * Get device mac address by matching devicename with cluster device name or node devicename  
	 * @param deviceName
	 * @return
	 */
	public String getMacaddress() {

		return mGetMacaddress();
	}


	/**
	 * Create query to get device type from database.Whether the deviceType is DockerCompose, KubernetesDevice or KubernetesCluster.
	 * @param deviceId
	 * @return
	 */
	public String getDeviceType() 
	{
		return mGetDeviceType();
	}

	/**
	 * Select platformid of device.
	 * @param deviceId
	 * @return
	 */
	public String getPlatformId() {

		return mGetPlatformId();
	}
	/**
	 * get owner id of device
	 * @param deviceId
	 * @return
	 */
	public String getUserIdOfDevice()
	{
		return mGetUserIdOfDevice();
	}

	/**
	 * get owner id of devices
	 * @param deviceId
	 * @return
	 */
	/**
	 * check if all devices of same owner
	 * @param deviceId
	 * @param userId
	 * @return
	 */
	public String isSameOwnerDevice(List<String> deviceId)
	{
		return mIsSameOwnerDevice(deviceId);
	}
	public String getDevicesOwners(List<String> deviceIds)
	{
		return mGetDevicesOwners(deviceIds);
	}
	/**
	 * Get device details by macAddress.Query from devicesnodes_view to get all information
	 * @param macAddress
	 * @return
	 */
	public String getDeviceDetails() {

		return mGetDeviceDetails();
	}

	/*
	 * Commented Method as it is no longer required.
	 * */
	/*
	/**
	 * Get device object for given email and support token.
	 * @param email email id of user
	 * @param supportToken 
	 * @return
	 * @throws SQLException
	 *//*
	public String getDeviceDetails(String email, String supportToken) {
		StringBuilder sb = new StringBuilder();

		sb.append("Select * ");
		sb.append(" FROM ");
		sb.append(PortalDBEnum.VIEW_NAMES.devicesnodes_view);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.DEVICES_NODES_VIEW.nodes_email);sb.append(" = ");sb.append(dbCon.formatString(StringEncryptionDecryption.encrypt(email, new CredProvider().getEcnKey())));
		sb.append(" AND ");
		sb.append(PortalDBEnum.DEVICES_NODES_VIEW.tokens_supporttokens);sb.append(" = ");sb.append(dbCon.formatString(supportToken));

		return sb.toString();
	}*/

	/**
	 * Get support token using device host Name 
	 * @param hostName
	 * @return
	 */
	public String getDeviceDetailsUsingHostname() {
		StringBuilder sb = new StringBuilder();
		sb.append("Select * ");
		sb.append(" FROM ");
		sb.append(PortalDBEnum.VIEW_NAMES.devicesnodes_view);
		sb.append(" WHERE ");
		sb.append(DEVICES_NODES_VIEW.nodes_hostName);
		sb.append(" = ");sb.append("?");
		return sb.toString();
	}

	/**
	 * Add device information in activation history
	 * @param userId
	 * @param deviceNodeVO
	 * @return
	 */
	public String addDeviceDetailsInActivationHistory() {
		return mAddDeviceDetailsInActivationHistory();
	}


	/**
	 * This method give query for check device exist in db,
	 * corresponding to given userId and deviceId param.
	 * @param deviceId
	 * @param userId
	 * @return
	 */
	public String isDeviceExist(String deviceId,String userId) {

		return mIsDeviceExist(deviceId,userId);
	}

	/**
	 * This method give query for check device exist in db,
	 * corresponding to given userId and deviceId param.
	 * @param deviceId
	 * @return
	 */
	public String isDeviceExists() {

		return mIsDeviceExists().toString();
	}

	/**
	 * This method give query which check any device exist in db, corresponding to given deviceIds list.
	 * @param deviceIdList
	 * @return
	 * @author DB, RA
	 */
	public String isDeviceExists(List<String> deviceIdList) {

		return mIsDeviceExists(deviceIdList);
	}


	/**
	 * Check if node device exists with node id.
	 * @param nodeId
	 * @return
	 */
//	public String isNodeExists(String nodeId) {
//
//		return mIsNodeExist(nodeId);
//	}

	/**
	 * This method give query for check device exist in db,
	 * corresponding to given macaddress param.
	 * @param macaddress
	 * @return
	 */
	public String isDeviceExist() {

		return mIsDeviceExist();
	}

	/**
	 * This method give query for check device exist in db,
	 * corresponding to given hostname param.
	 * @param macaddress
	 * @return
	 */
	public String isHostnameExist() {

		return mIsHostnameExists();
	}
	/**
	 * update device status using deviceId and userId.
	 * @param deviceId
	 * @param userId
	 * @param status
	 * @return
	 */
//	public String updateDeviceStatus(String deviceId,String userId, Status status) {
//		return mUpdateDeviceStatus(deviceId, userId, status);
//	}


	/**
	 * update isActivationConfirmed to 1
	 * @param deviceId
	 * @return
	 */
	public String updateActivationStatus()
	{
		return mUpdateActivationStatus();
	}

	//mUpdateActivationStatus

	/**
	 *  Delete device entry from device table so if devicetype is kubernetes cluster then all node device will automatically deleted by foreign key constraints.
	 * @param deviceId
	 * @param userId
	 * @return
	 */
	public String deleteDevice() {
		return mDeleteDevice();
	}

	public String deleteEdgeCoreFromGroups(){
		return mDeleteEdgeCoreFromGroups();
	}

	/**
	 * Delete a node device of kuberbnetes cluster 
	 * @param nodeId node id of device node to be removed.
	 * @param deviceId device id of kuber cluster
	 * @return
	 */
	public String deleteClusterNode() {
		return mDeleteClusterNode();
	}

	/**
	 * Select all information for device id. This query select data object from devices table so can be used for kubernetes cluster and dockercompose 
	 * @param deviceId
	 * @return
	 */
	public String getDevice(String deviceId) {
		return mGetDevice(deviceId);
	}

	/**
	 * select node device info 
	 * @param nodeId
	 * @return
	 */
	public String getNode() {
		return mGetNode();
	}

	/**
	 * Select query to return active master node of cluster for deviceid
	 * @param nodeId
	 * @return
	 */
	public String getActiveMasterNode() {
		return mGetActiveMasterNode();
	}


	/**
	 * Update support token by email id.
	 * @param email
	 * @param supportToken
	 * @return
	 */
	public String updateSupprotToken(){
		StringBuilder sb = new StringBuilder();
		sb.append("UPDATE ");sb.append(PortalDBEnum.TABLE_NAMES.nodes);
		sb.append(" SET ");
		sb.append(PortalDBEnum.NODES.supportToken);sb.append(" = ");sb.append("?");
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.NODES.email);sb.append(" = ");sb.append("?");
		return sb.toString();
	}

	/**
	 * Update support token and email using hostName
	 * @param email
	 * @param supportToken
	 * @param hostName
	 * @return
	 */
	public String update(){
		StringBuilder sb = new StringBuilder();
		sb.append("UPDATE ");sb.append(PortalDBEnum.TABLE_NAMES.nodes);
		sb.append(" SET ");
		sb.append(PortalDBEnum.NODES.supportToken);sb.append(" = ");sb.append("?");
		sb.append(", ");
		sb.append(PortalDBEnum.NODES.email);sb.append(" = ");sb.append("?");
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.NODES.hostName);sb.append(" = ");sb.append("?");
		return sb.toString();
	}

	/**
	 * Search devices using  filters and paging. 
	 * @param pageNo page number
	 * @param pageSize number of result to be returned in one page of result.  
	 * @param filters (sort, search text, start with, start end, etc.).
	 * @return hash map of result with keys-> totalPages,  pageNo, pageSize , data.hashmap value of key "data" contains List<DeviceVO>
	 * @throws Exception
	 */
	public List<String> searchDevice(Map<String, Object> filters) {
		List<String> queries = new ArrayList<>();
		
		StringBuilder query = new StringBuilder();
		query.append("SELECT SQL_CALC_FOUND_ROWS ");		
		query.append(PortalDBEnum.VIEW_NAMES.devicesnodes_view);
		query.append(".*");//Get all columns from device node view.		
		query.append(" FROM ");
		query.append(PortalDBEnum.VIEW_NAMES.devicesnodes_view);

		StringBuilder whereClause = null;
		if(filters != null){
			for (Iterator iterator = filters.keySet().iterator(); iterator.hasNext();) {
				String filterKey = (String) iterator.next();

				switch(filterKey){
				case "hostName" ://"hostName"
					whereClause = getWhereClause(whereClause);
					whereClause.append(DEVICES_NODES_VIEW.nodes_hostName);
					whereClause.append(" = ");
					whereClause.append("?");
//					whereClause.append(dbCon.formatString(filters.get(filterKey).toString()));
					break;
					//SupportToken filter case removed as the support token no longer available here.  	
				case "deviceId"://"deviceId"
					whereClause = getWhereClause(whereClause);
					whereClause.append(DEVICES_NODES_VIEW.devices_deviceId);
					whereClause.append(" = ");
					whereClause.append("?");
//					whereClause.append(dbCon.formatString(filters.get(filterKey).toString()));
					break;
				case "deviceName"://"deviceName"
					whereClause = getWhereClause(whereClause);
					whereClause.append(DEVICES_NODES_VIEW.devices_deviceName);
					whereClause.append(" = ");
					whereClause.append("?");
//					whereClause.append(dbCon.formatString(filters.get(filterKey).toString()));
					break;
				default:
					break;
				}
			}
		}

		//Add where conditions
		if(whereClause != null)
			query.append(whereClause);

		//Add paging 
		query.append(" limit ");
		query.append("?");
//		query.append(pageSize);
		query.append(" offset ");
		query.append("?");
//		query.append(offset);

		queries.add(query.toString());
		queries.add("SELECT FOUND_ROWS() as rowCount");
		return queries;
	}

	/**
	 * Add cluster device new entry. And update node devices deviceid with this cluster device id to link cluster to node device.
	 * After that old kubernetes device entries(i. e exists in listProductId) from will be removed from device table.    
	 * @param clusterDeviceVO object of cluster Device 
	 * @param listProductId List<DeviceNodeMasterVO> Role of device ( Master/Node) , mac Address and device state.
	 * Note: one and only one device in list must have role as MASTER.
	 * if root exist for this user then insert this entry in root otherwise add label
	 * @return new cluster object as DeviceVO that contains DeviceNodeVO in nodes property. 
	 * @return
	 * @throws Exception
	 */
	public Map<String, String> createCluster(List<String> deviceIds, List<String> allMacAddresses,
			List<String> masterMacAddresses, String activeMasterMacAddress) {
		Map<String, String> queries = new HashMap<>();
		/*
		 * Insert into devices table for cluster entry.
		 */
		StringBuilder sb = new StringBuilder();
		sb.append("INSERT INTO ");
		sb.append(PortalDBEnum.TABLE_NAMES.devices);
		sb.append(" ( ");
		sb.append(PortalDBEnum.DEVICES.deviceId.name());
		sb.append(", ");
		sb.append(PortalDBEnum.DEVICES.userId.name());
		sb.append(", ");
		sb.append(PortalDBEnum.DEVICES.platformId.name());
		sb.append(", ");
		sb.append(PortalDBEnum.DEVICES.swPlatformId.name());
		sb.append(", ");
		sb.append(PortalDBEnum.DEVICES.deviceStatus.name());
		sb.append(", ");
		sb.append(PortalDBEnum.DEVICES.deviceName.name());
		sb.append(", ");
		sb.append(PortalDBEnum.DEVICES.deviceType.name());
		sb.append(", ");
		sb.append(PortalDBEnum.DEVICES.isActivationConfirmed.name());
		sb.append(" ) VALUES ( ");
		// sb.append(dbCon.formatString(clusterDeviceVO.getDeviceId()));
		sb.append("?");
		sb.append(", ");
		sb.append("?");
		// sb.append(dbCon.formatString(clusterDeviceVO.getUserId()));
		sb.append(", ");
		sb.append("?");
		// sb.append(dbCon.formatString(clusterDeviceVO.getPlatformId()));
		sb.append(", ");
		sb.append("?");
		// sb.append(dbCon.formatString(clusterDeviceVO.getSwPlatformId()));
		sb.append(", ");
		sb.append("?");
		// sb.append(Status.ACTIVE.ordinal());
		sb.append(", ");
		sb.append("?");
		// sb.append(dbCon.formatString(clusterDeviceVO.getDeviceName()));
		sb.append(", ");
		sb.append("?");
		// sb.append(clusterDeviceVO.getDeviceType().ordinal());
		sb.append(", ");
		sb.append("?");
		// sb.append(clusterDeviceVO.isActivationConfirmed());
		sb.append(" ) ");

		queries.put("InsertDevice", sb.toString());

		queries.putAll(addDevicesToCluster(deviceIds, allMacAddresses, masterMacAddresses, activeMasterMacAddress));

		return queries;
	}

	/**
	 * Add existing kubernetes devices to exsiting cluster device.
	 * Update node devices deviceid with this cluster device id to link cluster to node device.
	 * After that old kubernetes device entries(i. e exists in listProductId) from will be removed from device table.
	 * The sequence of queries to add existing devices in cluster are:
	 * 	1. update foreign key deviceId of nodes table and set by cluster id.
	 * 	2. Update device role column value and set master for all master devices. 
	 *  3. Update device state and set active for Active master and Backup for other masters
	 *  4. Delete from devices table the entries of devices.
	 * @param clusterDeviceVO
	 * @param listProductId  List<DeviceNodeMasterVO> Role of device(Master/Node) , macAddress and Device state
	 * @return
	 * @throws SQLException
	 */
	public Map<String, String> addDevicesToCluster(List<String> deviceIds,
			List<String> allMacAddresses, List<String> masterMacAddresses, String activeMasterMacAddress)
	{
		Map<String, String> queries = new HashMap<>();

		// Update device id as cluster id in existing node entry of device.
		SqlQueryBuilder queryBuilder = new SqlQueryBuilder();
		queryBuilder.appendQuery("Update ");
		queryBuilder.appendQuery(PortalDBEnum.TABLE_NAMES.nodes);
		queryBuilder.appendQuery(" SET ");
		queryBuilder.appendQuery(PortalDBEnum.NODES.deviceId.name());
		queryBuilder.appendQuery(" = ");
		queryBuilder.appendQuery("?");
		// queryBuilder.appendQuery(dbCon.formatString(clusterDeviceVO.getDeviceId()));
		queryBuilder.appendQuery(" WHERE ");
		queryBuilder.appendQuery(PortalDBEnum.NODES.macAddress.name());
		queryBuilder.appendQueryIN(allMacAddresses);
		// queryBuilder.appendQuery(" in (");
		// queryBuilder.appendQuery(dbCon.formatStringForIn(allMacAddresses));
		// queryBuilder.appendQuery(" ) ");

		queries.put("UpdateNode",queryBuilder.getQuery().toString());

		// Update role of master devices
		if (!masterMacAddresses.isEmpty()) {
			SqlQueryBuilder sbUpdateMasterRole = new SqlQueryBuilder();
			sbUpdateMasterRole.appendQuery("Update ");
			sbUpdateMasterRole.appendQuery(PortalDBEnum.TABLE_NAMES.nodes);
			sbUpdateMasterRole.appendQuery(" SET ");
			sbUpdateMasterRole.appendQuery(PortalDBEnum.NODES.deviceRole.name());
			sbUpdateMasterRole.appendQuery(" = ");
			sbUpdateMasterRole.appendQuery(NodeType.MASTER.ordinal());
			sbUpdateMasterRole.appendQuery(" WHERE ");
			sbUpdateMasterRole.appendQuery(PortalDBEnum.NODES.macAddress.name());
			sbUpdateMasterRole.appendQueryIN(masterMacAddresses);
			// sbUpdateMasterRole.appendQuery(" IN( ");
			// sbUpdateMasterRole.appendQuery(dbCon.formatStringForIn(masterMacAddresses));
			// sbUpdateMasterRole.appendQuery(" ) ");

//			queries.add(sbUpdateMasterRole.getQuery().toString());
			queries.put("UpdateMasterRole", sbUpdateMasterRole.getQuery().toString());
		}

		// Update State of Active Master devices
		if (!StringFunctions.isNullOrWhitespace(activeMasterMacAddress)) {
			SqlQueryBuilder sbUpdateActiveMasterState = new SqlQueryBuilder();
			sbUpdateActiveMasterState.appendQuery("Update ");
			sbUpdateActiveMasterState.appendQuery(PortalDBEnum.TABLE_NAMES.nodes);
			sbUpdateActiveMasterState.appendQuery(" SET ");
			sbUpdateActiveMasterState.appendQuery(PortalDBEnum.NODES.deviceState.name());
			sbUpdateActiveMasterState.appendQuery(" = ");
			sbUpdateActiveMasterState.appendQuery(StateEnum.Active.getValue());
			sbUpdateActiveMasterState.appendQuery(" WHERE ");
			sbUpdateActiveMasterState.appendQuery(PortalDBEnum.NODES.macAddress.name());
			sbUpdateActiveMasterState.appendQuery(" = ");
			sbUpdateActiveMasterState.appendQuery("?");
			// sbUpdateActiveMasterState.appendQuery(dbCon.formatString(activeMasterMacAddress));
			queries.put("UpdateActiveMasterState", sbUpdateActiveMasterState.getQuery().toString());
//			queries.add(sbUpdateActiveMasterState.getQuery().toString());

			// Update State of Backup master devices
			SqlQueryBuilder sbUpdateBackUpMasterState = new SqlQueryBuilder();
			sbUpdateBackUpMasterState.appendQuery("Update ");
			sbUpdateBackUpMasterState.appendQuery(PortalDBEnum.TABLE_NAMES.nodes);
			sbUpdateBackUpMasterState.appendQuery(" SET ");
			sbUpdateBackUpMasterState.appendQuery(PortalDBEnum.NODES.deviceState.name());
			sbUpdateBackUpMasterState.appendQuery(" = ");
			sbUpdateBackUpMasterState.appendQuery(StateEnum.Backup.getValue());
			sbUpdateBackUpMasterState.appendQuery(" WHERE ");
			sbUpdateBackUpMasterState.appendQuery(PortalDBEnum.NODES.deviceId.name());
			sbUpdateBackUpMasterState.appendQuery(" = ");
			sbUpdateBackUpMasterState.appendQuery("?");
			// sbUpdateBackUpMasterState.appendQuery(dbCon.formatString(clusterDeviceVO.getDeviceId()));
			sbUpdateBackUpMasterState.appendQuery(" AND ");
			sbUpdateBackUpMasterState.appendQuery(PortalDBEnum.NODES.deviceRole.name());
			sbUpdateBackUpMasterState.appendQuery(" = ");
			sbUpdateBackUpMasterState.appendQuery(NodeType.MASTER.ordinal());
			sbUpdateBackUpMasterState.appendQuery(" AND ");
			sbUpdateBackUpMasterState.appendQuery(PortalDBEnum.NODES.macAddress.name());
			sbUpdateBackUpMasterState.appendQuery(" != ");
			sbUpdateBackUpMasterState.appendQuery("?");
			// sbUpdateBackUpMasterState.appendQuery(dbCon.formatString(activeMasterMacAddress));
			queries.put("UpdateBackUpMasterState", sbUpdateBackUpMasterState.getQuery().toString());
			//queries.add(sbUpdateBackUpMasterState.getQuery().toString());
		}

		if (deviceIds != null && !deviceIds.isEmpty()) {
			// Delete entries from devices table because now the child nodes
			// refer to cluster entry in device tables
			SqlQueryBuilder sbDeleteDevice = new SqlQueryBuilder();
			sbDeleteDevice.appendQuery("DELETE FROM ");
			sbDeleteDevice.appendQuery(PortalDBEnum.TABLE_NAMES.devices);
			sbDeleteDevice.appendQuery(" WHERE ");
			sbDeleteDevice.appendQuery(PortalDBEnum.DEVICES.deviceId.name());
			sbDeleteDevice.appendQueryIN(deviceIds);

			// sbDeleteDevice.appendQuery(" IN( ");
			// sbDeleteDevice.appendQuery(dbCon.formatStringForIn(deviceIds));
			// sbDeleteDevice.appendQuery(" )");
			queries.put("DeleteDevice", sbDeleteDevice.getQuery().toString());
			//queries.add(sbDeleteDevice.getQuery().toString());

			SqlQueryBuilder sbDeleteStatistics = new SqlQueryBuilder();
			sbDeleteStatistics.appendQuery("DELETE FROM ");
			sbDeleteStatistics.appendQuery(PortalDBEnum.TABLE_NAMES.boxStatics);
			sbDeleteStatistics.appendQuery(" WHERE ");
			sbDeleteStatistics.appendQuery(PortalDBEnum.BOX_STATICS.deviceId.name());
			sbDeleteStatistics.appendQueryIN(deviceIds);
			// sbDeleteStatistics.appendQuery(" IN( ");
			// sbDeleteStatistics.appendQuery(dbCon.formatStringForIn(deviceIds));
			// sbDeleteStatistics.appendQuery(" )");
			queries.put("DeleteStatistics", sbDeleteStatistics.getQuery().toString());
//			queries.add(sbDeleteStatistics.getQuery().toString());
		}

		return queries;
	}

	/**
	 * Update cluster device name.
	 * @param clusterDeviceId
	 * @param clusterName
	 * @return
	 */
	public String updateClusterDeviceName()
	{
		return mUpdateClusterDeviceName();
	}

	/**
	 * This method create query to get all applications using paging and 
	 * filters (category, sort, search text, start with, start end, etc.).	
	 * @param userId (not used in case of ownership = none)
	 * @param pageNo page number 
	 * @param pageSize number of applications in one page.
	 * @param filters (category, sort, search text, start with, start end, etc.).
	 * @param listUpdateVersions
	 * @param ownership 
	 * @param groupIds (used only if ownership = invitee/both)
	 * @return hash map of result with keys-> totalPages,  pageNo, pageSize , data.hashmap value of key "data" contains List<DeviceVO>
	 */

	public List<String> listDeviceFilter(String userId, List<FilterObject> filters, boolean listUpdateVersions,OwnershipEnum ownership, List<String> groupIds, int systemUpdateGroupIdsCount) 
	{
		return mListDeviceFilter(userId, filters, listUpdateVersions,ownership,groupIds, systemUpdateGroupIdsCount);
	}

	private String mUpdateClusterDeviceName()
	{
		//Update role and devcie id in existing node entry of device.
		StringBuilder sbNode = new StringBuilder();
		sbNode.append("Update ");
		sbNode.append(PortalDBEnum.TABLE_NAMES.devices);
		sbNode.append(" SET ");			
		sbNode.append(PortalDBEnum.DEVICES.deviceName.name());
		sbNode.append(" = ");
		sbNode.append("?");
//		sbNode.append(dbCon.formatString(clusterName));					
		sbNode.append(" WHERE ");
		sbNode.append(PortalDBEnum.NODES.deviceId.name());
		sbNode.append(" = ");
		sbNode.append("?");
//		sbNode.append(dbCon.formatString(clusterDeviceId));

		return sbNode.toString();
	}

	private String mGetDevice(String deviceId) {
		StringBuilder sb = new StringBuilder();
		sb.append("Select * ");
		sb.append(" FROM ");
		sb.append(PortalDBEnum.VIEW_NAMES.devicesnodes_view);	
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.DEVICES_NODES_VIEW.devices_deviceId);sb.append(" = ");sb.append("?");		
		return sb.toString();
	}

	private String mGetActiveMasterNode() {
		StringBuilder sb = new StringBuilder();
		sb.append("Select * ");
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.nodes);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.NODES.deviceId);sb.append(" = ");sb.append("?");
		sb.append(" AND ");
		sb.append(PortalDBEnum.NODES.deviceRole);sb.append(" = ");sb.append(NodeType.MASTER.ordinal());
		sb.append(" AND ");
		sb.append(PortalDBEnum.NODES.deviceState);sb.append(" = ");sb.append(StateEnum.Active.ordinal());
		return sb.toString();
	}

	private String mGetNode() {
		StringBuilder sb = new StringBuilder();
		sb.append("Select * ");
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.nodes);	
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.NODES.nodeId);sb.append(" = ");sb.append("?");		
		return sb.toString();
	}

//	private String mUpdateDeviceStatus(String deviceId, String userId, Status status)
//	{
//		StringBuilder sb = new StringBuilder();
//		sb.append("UPDATE ");sb.append(PortalDBEnum.TABLE_NAMES.devices);
//		sb.append(" SET ");
//		sb.append(PortalDBEnum.DEVICES.deviceStatus);sb.append(" = ");sb.append(status.ordinal());
//		sb.append(" WHERE ");
//		sb.append(PortalDBEnum.DEVICES.deviceId);sb.append(" = ");sb.append(dbCon.formatString(deviceId));
//		sb.append(" AND ");
//		sb.append(PortalDBEnum.DEVICES.userId);sb.append(" = ");sb.append(dbCon.formatString(userId));
//		return sb.toString();
//	}

	private String mUpdateActivationStatus()
	{
		StringBuilder sb = new StringBuilder();
		sb.append("UPDATE ");sb.append(PortalDBEnum.TABLE_NAMES.devices);
		sb.append(" SET ");
		sb.append(PortalDBEnum.DEVICES.isActivationConfirmed);sb.append(" = ");sb.append(1);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.DEVICES.deviceId);sb.append(" = ");sb.append("?");
		return sb.toString();
	}

	private String mDeleteDevice()
	{
		StringBuilder sb = new StringBuilder();
		sb.append("DELETE FROM ");sb.append(PortalDBEnum.TABLE_NAMES.devices);		
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.DEVICES.deviceId);sb.append(" = ");sb.append("?");
		sb.append(" AND ");
		sb.append(PortalDBEnum.DEVICES.userId);sb.append(" = ");sb.append("?");
		return sb.toString();
	}

	private String mDeleteEdgeCoreFromGroups()
	{
		StringBuilder sb = new StringBuilder();
		sb.append("DELETE ");
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.groupEdgeCore);
		sb.append(" WHERE ");		
		sb.append(PortalDBEnum.GROUP_EDGECORE.edgeCoreId.name());
		sb.append(" = ");
		sb.append("?");
		return sb.toString();
	}

	private String mDeleteClusterNode()
	{
		StringBuilder sb = new StringBuilder();
		sb.append("DELETE FROM ");sb.append(PortalDBEnum.TABLE_NAMES.nodes);		
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.NODES.nodeId);sb.append(" = ");sb.append("?");
		sb.append(" AND ");
		sb.append(PortalDBEnum.NODES.deviceId);sb.append(" = ");sb.append("?");
		return sb.toString();
	}

	public String getCluster()
	{
		return mGetCluster();
	}

	private String mGetCluster()
	{	
		StringBuilder sb = new StringBuilder();
		sb.append("Select * ");
		sb.append(" FROM ");
		sb.append(PortalDBEnum.VIEW_NAMES.devicesnodes_view);
		sb.append(" WHERE ");		
		sb.append(PortalDBEnum.DEVICES_NODES_VIEW.nodes_nodeId);sb.append(" = ");sb.append("?");
		sb.append(" AND ");		
		sb.append(PortalDBEnum.DEVICES_NODES_VIEW.devices_userId);sb.append(" = ");sb.append("?");

		return sb.toString();

	}


	public String getNodeCountInCluster()
	{
		return mGetNodeCountInCluster();
	}

	private String mGetNodeCountInCluster()
	{
		StringBuilder sb = new StringBuilder();
		sb.append("Select count(*) as count");
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.nodes);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.NODES.deviceId);
		sb.append(" = ");
		sb.append("?");

		return sb.toString();
	}


	/**
	 * Update device id i.e. foreign key from devices table and also update role of node to node {@link NodeType} Node ordinal value
	 * @param nodeId
	 * @param deviceId
	 * @return
	 */
	public String updateNodeDeviceId()
	{
		return mUpdateNodeDeviceId();
	}

	private String mUpdateNodeDeviceId()
	{
		StringBuilder sbUpdateMasterRole = new StringBuilder();
		sbUpdateMasterRole.append("Update ");
		sbUpdateMasterRole.append(PortalDBEnum.TABLE_NAMES.nodes);
		sbUpdateMasterRole.append(" SET ");			
		sbUpdateMasterRole.append(PortalDBEnum.NODES.deviceId.name());
		sbUpdateMasterRole.append(" = ");
		sbUpdateMasterRole.append("?");
		sbUpdateMasterRole.append(", ");
		sbUpdateMasterRole.append(PortalDBEnum.NODES.deviceRole.name());
		sbUpdateMasterRole.append(" = ");
		sbUpdateMasterRole.append(NodeType.NODE.ordinal());
		sbUpdateMasterRole.append(" WHERE ");
		sbUpdateMasterRole.append(PortalDBEnum.NODES.nodeId.name());
		sbUpdateMasterRole.append(" = ");
		sbUpdateMasterRole.append("?");
		return sbUpdateMasterRole.toString();
	}
	/**
	 * This method give query for check device exist in db,
	 * corresponding to given userId and deviceId param.
	 * @param deviceId
	 * @param userId
	 * @return
	 */
	private String mIsDeviceExist(String deviceId,String userId)
	{
		StringBuilder sb = mIsDeviceExists();

		sb.append(" AND ");
		sb.append(PortalDBEnum.DEVICES.userId);sb.append(" = ");sb.append("?");

		return sb.toString();
	}

	/**
	 * This method give query for check device exist in db,
	 * corresponding to given userId and deviceId param.
	 * @param deviceId
	 * @return
	 */
	private StringBuilder mIsDeviceExists()
	{
		StringBuilder sb = new StringBuilder();
		sb.append("Select ");sb.append(PortalDBEnum.DEVICES.deviceId);
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.devices);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.DEVICES.deviceId);sb.append(" = ");sb.append("?");

		return sb;
	}

	/**
	 * This method give query which check any device exist in db, corresponding to given deviceIds list.
	 * @param deviceIdList
	 * @return
	 * @author DB, RA
	 */
	private String mIsDeviceExists(List<String> deviceIdList)
	{
		SqlQueryBuilder builder = new SqlQueryBuilder();
		builder.appendQuery("Select ");
		builder.appendQuery(PortalDBEnum.DEVICES.deviceId);
		builder.appendQuery(" FROM ");
		builder.appendQuery(PortalDBEnum.TABLE_NAMES.devices);
		builder.appendQuery(" WHERE ");
		builder.appendQuery(PortalDBEnum.DEVICES.deviceId);
		builder.appendQueryIN(deviceIdList);
		return builder.getQuery().toString();
	}
	/**
	 * This method give query for check node exist in db,
	 * corresponding to given userId and deviceId param.
	 * @param deviceId
	 * @param userId
	 * @return
	 */
//	private String mIsNodeExist(String nodeId)
//	{
//		StringBuilder sb = new StringBuilder();
//		sb.append("Select ");sb.append(PortalDBEnum.NODES.nodeId);
//		sb.append(" FROM ");
//		sb.append(PortalDBEnum.TABLE_NAMES.nodes);
//		sb.append(" WHERE ");
//		sb.append(PortalDBEnum.NODES.nodeId);sb.append(" = ");sb.append(dbCon.formatString(nodeId));
//
//		return sb.toString();
//	}


	/**
	 * This method give query for check device exist in db,
	 * corresponding to given macAddress param.
	 * @param deviceId
	 * @param userId
	 * @return
	 */
	private String mIsDeviceExist()
	{
		StringBuilder sb = new StringBuilder();
		sb.append("Select ");sb.append(PortalDBEnum.NODES.nodeId);
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.nodes);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.NODES.macAddress);sb.append(" = ");sb.append("?");

		return sb.toString();
	}

	/**
	 * This method give query for check device exist in db,
	 * corresponding to given hostname param.
	 * @param hostName
	 * @return
	 */
	private String mIsHostnameExists(){
		StringBuilder sb = new StringBuilder();
		sb.append("Select EXISTS ( SELECT ");		
		sb.append(PortalDBEnum.NODES.nodeId);
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.nodes);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.NODES.hostName);sb.append(" = ");sb.append("?");
		sb.append(" ) OR EXISTS ( SELECT ");

		sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sMACAddress);
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.discoveryjardetails);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sHostName);sb.append(" = ");sb.append("?");

		sb.append(" ) as count");
		return sb.toString();
	}


	/**
	 * Get list of all node devices in case of kubernetes cluster otherwise give device information for single device for deviceid
	 * The method queries from devicesnodes_view to node devices.The result is order by device table devicename
	 * @param userId user id
	 * @param isListLabels if true then label id will also be listed with device.
	 * @return
	 */
	public String listDevice(String userId, String deviceId, boolean isListLabels, DeviceTypeEnum deviceType) {
		StringBuilder sb = new StringBuilder();
		sb.append("Select * ");
		sb.append(" FROM ");
		sb.append(PortalDBEnum.VIEW_NAMES.devicesnodes_view);
		if (isListLabels) {
			sb.append(" INNER JOIN ");
			sb.append(PortalDBEnum.TABLE_NAMES.devicelabelmap);
			sb.append(" ON ");
			sb.append(PortalDBEnum.DEVICES_NODES_VIEW.devices_deviceId);
			sb.append(" = ");
			sb.append(PortalDBEnum.TABLE_NAMES.devicelabelmap);
			sb.append(".");
			sb.append(DEVICE_LABEL_MAP.deviceId);
		}
		sb.append(" WHERE ");
		sb.append(DEVICES_NODES_VIEW.devices_deviceStatus);
		sb.append(" != ");
		sb.append(Status.DELETED.ordinal());
		sb.append(" AND ");
		sb.append(PortalDBEnum.DEVICES_NODES_VIEW.devices_userId);
		sb.append(" = ");
		sb.append("?");
		// sb.append(dbCon.formatString(userId));
		sb.append(" AND ");
		sb.append(PortalDBEnum.DEVICES_NODES_VIEW.devices_deviceId);
		sb.append(" = ");
		sb.append("?");
		// sb.append(dbCon.formatString(deviceId));
		// Added check to return specific devicetype kubernetes or docker
		// compose if set to null then all type of devices will be return - PS
		if (deviceType != null) {
			sb.append(" AND ");
			sb.append(PortalDBEnum.DEVICES_NODES_VIEW.devices_deviceType);
			sb.append(" = ");
			sb.append("?");
			// sb.append(deviceType.getValue());
		}

		sb.append(" ORDER BY ");
		sb.append(PortalDBEnum.DEVICES_NODES_VIEW.devices_deviceName);
		sb.append(" ASC ");
		return sb.toString();
	}

	private String mListDevice(boolean isListLabels, DeviceTypeEnum deviceType) {
		StringBuilder sb = new StringBuilder();
		sb.append("Select * ");
		sb.append(" FROM ");
		sb.append(PortalDBEnum.VIEW_NAMES.devicesnodes_view);
		if (isListLabels) {
			sb.append(" Left JOIN ");
			sb.append(PortalDBEnum.TABLE_NAMES.devicelabelmap);
			sb.append(" ON ");
			sb.append(PortalDBEnum.DEVICES_NODES_VIEW.devices_deviceId);
			sb.append(" = ");
			sb.append(PortalDBEnum.TABLE_NAMES.devicelabelmap);
			sb.append(".");
			sb.append(DEVICE_LABEL_MAP.deviceId);
		}

		sb.append(" WHERE ");
		sb.append(DEVICES_NODES_VIEW.devices_deviceStatus);
		sb.append(" != ");
		sb.append(Status.DELETED.ordinal());
		sb.append(" AND ");
		sb.append(PortalDBEnum.DEVICES_NODES_VIEW.devices_userId);
		sb.append(" = ");
		sb.append("?");
		// Added check to return specific devicetype kubernetes or docker
		// compose if set to null then all type of devices will be return-PS
		if (deviceType != null) {
			sb.append(" AND ");
			sb.append(PortalDBEnum.DEVICES_NODES_VIEW.devices_deviceType);
			sb.append(" = ");
			sb.append("?");
			//sb.append(deviceType.getValue());
		}

		sb.append(" ORDER BY ");
		sb.append(PortalDBEnum.DEVICES_NODES_VIEW.devices_deviceName);
		sb.append(" ASC ");
		return sb.toString();
	}
	/**
	 * List invited device which user are invited on multiple groups.
	 * @param groupIds
	 * @return
	 */
//	public String listInvitedDevices(List<String> groupIds)
//	{
//		return mListInvitedDevices(groupIds);
//	}
//
//	private String mListInvitedDevices(List<String> groupIds)
//	{
//		StringBuilder sb = new StringBuilder();
//		sb.append("Select * ");
//		sb.append(" FROM ");
//		sb.append(PortalDBEnum.TABLE_NAMES.groupEdgeCore);
//		sb.append(" AS groupEdgeCore ");
//
//		sb.append(" INNER JOIN ");
//		sb.append(PortalDBEnum.VIEW_NAMES.devicesnodes_view);
//		sb.append(" ON devicesnodes_view.");
//		sb.append(PortalDBEnum.DEVICES_NODES_VIEW.devices_deviceId);
//		sb.append(" = groupEdgeCore.");
//		sb.append(PortalDBEnum.GROUP_EDGECORE.edgeCoreId);
//
//		sb.append(" Left JOIN ");
//		sb.append(PortalDBEnum.TABLE_NAMES.devicelabelmap);
//		sb.append(" ON ");
//		sb.append(PortalDBEnum.VIEW_NAMES.devicesnodes_view);
//		sb.append(".");
//		sb.append(PortalDBEnum.DEVICES_NODES_VIEW.devices_deviceId);
//		sb.append(" = ");
//		sb.append(PortalDBEnum.TABLE_NAMES.devicelabelmap);
//		sb.append(".");
//		sb.append(DEVICE_LABEL_MAP.deviceId);
//		sb.append(" WHERE ");
//		sb.append(" groupEdgeCore.");
//		sb.append(PortalDBEnum.GROUP_EDGECORE.groupId);
//		sb.append(" IN (");
//		sb.append(dbCon.formatStringForIn(groupIds));
//		sb.append(") ");
//		sb.append(" AND ");
//		sb.append(DEVICES_NODES_VIEW.devices_deviceStatus);
//		sb.append(" != ");
//		sb.append(Status.DELETED.ordinal());
//		sb.append(" GROUP BY ");
//		sb.append(PortalDBEnum.VIEW_NAMES.devicesnodes_view);
//		sb.append(".");
//		sb.append(PortalDBEnum.DEVICES_NODES_VIEW.devices_deviceId);
//		sb.append(" ORDER BY ");
//		sb.append(PortalDBEnum.DEVICES_NODES_VIEW.devices_deviceName);
//		sb.append(" ASC ");
//		return sb.toString();
//	}

	private ArrayList<String> mAddDevice() {

		ArrayList<String> queries = new ArrayList<>();

		queries.add(mInsertIntoDevices());

		StringBuilder sbNode = new StringBuilder();
		sbNode.append("INSERT INTO ");
		sbNode.append(PortalDBEnum.TABLE_NAMES.nodes);
		sbNode.append(" ( ");
		sbNode.append(PortalDBEnum.NODES.nodeId.name());
		sbNode.append(", ");
		sbNode.append(PortalDBEnum.NODES.deviceName.name());
		sbNode.append(", ");	
		sbNode.append(PortalDBEnum.NODES.macAddress.name());
		sbNode.append(", ");
		sbNode.append(PortalDBEnum.NODES.hostName.name());
		sbNode.append(", ");	
		sbNode.append(PortalDBEnum.NODES.machineId.name());
		sbNode.append(", ");
		sbNode.append(PortalDBEnum.NODES.nativeAppId.name());
		sbNode.append(", ");
		sbNode.append(PortalDBEnum.NODES.deviceRole.name());
		sbNode.append(", ");
		sbNode.append(PortalDBEnum.NODES.deviceState.name());
		sbNode.append(", ");
		sbNode.append(PortalDBEnum.NODES.deviceId.name());	
		sbNode.append(", ");
		sbNode.append(PortalDBEnum.NODES.network.name());
		sbNode.append(" ) VALUES ( ");
		sbNode.append("?");
		sbNode.append(", ");
		sbNode.append("?");
		sbNode.append(", ");		
		sbNode.append("?");
		sbNode.append(", ");
		sbNode.append("?");
		sbNode.append(", ");		
		sbNode.append("?");
		sbNode.append(", ");
		sbNode.append("?");
		sbNode.append(", ");
		sbNode.append("?");
		sbNode.append(", ");
		sbNode.append("?");
		sbNode.append(", ");
		sbNode.append("?");
		sbNode.append(", ");
		sbNode.append("?");
		sbNode.append(" ) ");
		sbNode.append(" ON DUPLICATE KEY UPDATE ");
		sbNode.append(PortalDBEnum.NODES.machineId.name());sbNode.append(" = ");sbNode.append("?");
		sbNode.append(", ");sbNode.append(PortalDBEnum.NODES.deviceName.name());sbNode.append(" = ");sbNode.append("?");
		sbNode.append(", ");sbNode.append(PortalDBEnum.NODES.nativeAppId.name());sbNode.append(" = ");sbNode.append("?");
		sbNode.append(", ");sbNode.append(PortalDBEnum.NODES.hostName.name());sbNode.append(" = ");sbNode.append("?");		
		sbNode.append(", ");sbNode.append(PortalDBEnum.NODES.macAddress.name());sbNode.append(" = ");sbNode.append("?");
		sbNode.append(", ");sbNode.append(PortalDBEnum.NODES.network.name());sbNode.append(" = ");sbNode.append("?");
		queries.add(sbNode.toString());

		return queries;
	}

	/**
	 * Create query to insert device entry.This query will update on duplicate key.
	 * @param deviceVO
	 * @return
	 */
	public String insertIntoDevices()
	{
		return mInsertIntoDevices();

	}

	//	private String mInsertIntoDevices(DeviceVO deviceVO)
	//	{
	//		StringBuilder sb = new StringBuilder();
	//		sb.append("INSERT INTO ");
	//		sb.append(PortalDBEnum.TABLE_NAMES.devices);
	//		sb.append(" ( ");
	//		sb.append(PortalDBEnum.DEVICES.deviceId.name());
	//		sb.append(", ");
	//		sb.append(PortalDBEnum.DEVICES.userId.name());
	//		sb.append(", ");
	//		sb.append(PortalDBEnum.DEVICES.platformId.name());
	//		sb.append(", ");
	//		sb.append(PortalDBEnum.DEVICES.swPlatformId.name());
	//		sb.append(", ");
	//		sb.append(PortalDBEnum.DEVICES.deviceStatus.name());
	//		sb.append(", ");
	//		sb.append(PortalDBEnum.DEVICES.deviceName.name());
	//		sb.append(", ");
	//		sb.append(PortalDBEnum.DEVICES.deviceType.name());
	//		sb.append(", ");
	//		sb.append(PortalDBEnum.DEVICES.isActivationConfirmed.name());
	//		sb.append(" ) VALUES ( ");
	//		sb.append(dbCon.formatString(deviceVO.getDeviceId()));
	//		sb.append(", ");
	//		sb.append(dbCon.formatString(deviceVO.getUserId()));
	//		sb.append(", ");
	//		sb.append(dbCon.formatString(deviceVO.getPlatformId()));
	//		sb.append(", ");
	//		sb.append(dbCon.formatString(deviceVO.getSwPlatformId()));
	//		sb.append(", ");
	//		sb.append(Status.ACTIVE.ordinal());
	//		sb.append(", ");
	//		sb.append(dbCon.formatString(deviceVO.getDeviceName()));
	//		sb.append(", ");
	//		sb.append(deviceVO.getDeviceType().ordinal());
	//		sb.append(", ");
	//		sb.append(deviceVO.isActivationConfirmed());
	//		sb.append(" ) ");
	//		sb.append(" ON DUPLICATE KEY UPDATE ");
	//		sb.append(PortalDBEnum.DEVICES.userId.name());sb.append(" = ");sb.append(dbCon.formatString(deviceVO.getUserId()));
	//		sb.append(", ");sb.append(PortalDBEnum.DEVICES.platformId.name());sb.append(" = ");sb.append(dbCon.formatString(deviceVO.getPlatformId()));
	//		sb.append(", ");sb.append(PortalDBEnum.DEVICES.deviceName.name());sb.append(" = ");sb.append(dbCon.formatString(deviceVO.getDeviceName()));
	//		sb.append(", ");sb.append(PortalDBEnum.DEVICES.deviceStatus.name());sb.append(" = ");sb.append(Status.ACTIVE.ordinal());
	//		return sb.toString();
	//	}

	private String mInsertIntoDevices()
	{
		StringBuilder sb = new StringBuilder();
		sb.append("INSERT INTO ");
		sb.append(PortalDBEnum.TABLE_NAMES.devices);
		sb.append(" ( ");
		sb.append(PortalDBEnum.DEVICES.deviceId.name());
		sb.append(", ");
		sb.append(PortalDBEnum.DEVICES.userId.name());
		sb.append(", ");
		sb.append(PortalDBEnum.DEVICES.platformId.name());
		sb.append(", ");
		sb.append(PortalDBEnum.DEVICES.swPlatformId.name());
		sb.append(", ");
		sb.append(PortalDBEnum.DEVICES.deviceStatus.name());
		sb.append(", ");
		sb.append(PortalDBEnum.DEVICES.deviceName.name());
		sb.append(", ");
		sb.append(PortalDBEnum.DEVICES.deviceType.name());
		sb.append(", ");
		sb.append(PortalDBEnum.DEVICES.isActivationConfirmed.name());
		sb.append(" ) VALUES ( ");
		sb.append("?");
		sb.append(", ");
		sb.append("?");
		sb.append(", ");
		sb.append("?");
		sb.append(", ");
		sb.append("?");
		sb.append(", ");
		sb.append("?");
		sb.append(", ");
		sb.append("?");
		sb.append(", ");
		sb.append("?");
		sb.append(", ");
		sb.append("?");
		sb.append(" ) ");
		sb.append(" ON DUPLICATE KEY UPDATE ");
		sb.append(PortalDBEnum.DEVICES.userId.name());sb.append(" = ");sb.append("?");
		sb.append(", ");sb.append(PortalDBEnum.DEVICES.platformId.name());sb.append(" = ");sb.append("?");
		sb.append(", ");sb.append(PortalDBEnum.DEVICES.deviceName.name());sb.append(" = ");sb.append("?");
		sb.append(", ");sb.append(PortalDBEnum.DEVICES.deviceStatus.name());sb.append(" = ");sb.append("?");
		return sb.toString();
	}

	private String mGetMacaddress() {
		StringBuilder sb = new StringBuilder();

		sb.append("Select ");
		sb.append(DEVICES_NODES_VIEW.nodes_macAddress);
		sb.append(" FROM ");
		sb.append(PortalDBEnum.VIEW_NAMES.devicesnodes_view);		
		sb.append(" WHERE ");
		sb.append(DEVICES_NODES_VIEW.nodes_deviceName);
		sb.append(" = ");
		sb.append("?");
		sb.append(" OR ");
		sb.append(DEVICES_NODES_VIEW.devices_deviceName);
		sb.append(" = ");
		sb.append("?");

		return sb.toString();
	}

	private String mGetDeviceType() {
		StringBuilder sb = new StringBuilder();

		sb.append("Select ");
		sb.append(DEVICES.deviceType);
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.devices);		
		sb.append(" WHERE ");
		sb.append(DEVICES.deviceId);
		sb.append(" = ");
		sb.append("?");

		return sb.toString();
	}

	private String mGetPlatformId() {
		StringBuilder sb = new StringBuilder();

		sb.append("Select ");
		sb.append(DEVICES.platformId);
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.devices);		
		sb.append(" WHERE ");
		sb.append(DEVICES.deviceId);
		sb.append(" = ");
		sb.append("?");

		return sb.toString();
	}

	private String mGetUserIdOfDevice()
	{
		StringBuilder sb = new StringBuilder();

		sb.append("Select ");
		sb.append(DEVICES.userId);
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.devices);		
		sb.append(" WHERE ");
		sb.append(DEVICES.deviceId);
		sb.append(" = ");
		sb.append("?");

		return sb.toString();
	}
	
	private String mIsSameOwnerDevice(List<String> deviceIds)
	{
		SqlQueryBuilder queryBuilder = new SqlQueryBuilder();

		queryBuilder.appendQuery("Select COUNT(*) as count ");
		queryBuilder.appendQuery(" FROM ");
		queryBuilder.appendQuery(PortalDBEnum.TABLE_NAMES.devices);
		queryBuilder.appendQuery(" WHERE ");
		queryBuilder.appendQuery(DEVICES.userId);
		queryBuilder.appendQuery(" = ");
		queryBuilder.appendQuery("?");
		// queryBuilder.appendQuery(dbCon.formatString(userId));
		queryBuilder.appendQuery(" AND ");
		queryBuilder.appendQuery(DEVICES.deviceId);

		queryBuilder.appendQueryIN(deviceIds);

		// queryBuilder.appendQuery(" IN( ");
		// queryBuilder.appendQuery(dbCon.formatStringForIn(deviceIds));
		// queryBuilder.appendQuery(") ");

		return queryBuilder.getQuery().toString();
	}

	private String mGetDevicesOwners(List<String> deviceIds)
	{
		SqlQueryBuilder queryBuilder = new SqlQueryBuilder();
		queryBuilder.appendQuery("Select  ");
		queryBuilder.appendQuery(DEVICES.userId);
		queryBuilder.appendQuery(",");
		queryBuilder.appendQuery(DEVICES.deviceId);
		queryBuilder.appendQuery(" FROM ");
		queryBuilder.appendQuery(PortalDBEnum.TABLE_NAMES.devices);	
		queryBuilder.appendQuery(" WHERE ");
		queryBuilder.appendQuery(DEVICES.deviceId);
		
		queryBuilder.appendQueryIN(deviceIds);
		
//		queryBuilder.appendQuery(" IN( ");
//		queryBuilder.appendQuery(dbCon.formatStringForIn(deviceIds));
//		queryBuilder.appendQuery(") ");

		return queryBuilder.getQuery().toString();
		
	}
	/**
	 * Get kubernetes cluster device id by clustername 
	 * @param clusterDeviceName
	 * @return
	 */
	public String getClusterId() 
	{
		return mGetClusterId();
	}

	private String mGetClusterId() 
	{
		StringBuilder sb = new StringBuilder();
		sb.append("Select ");
		sb.append(PortalDBEnum.DEVICES.deviceId);
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.devices);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.DEVICES.deviceName);
		sb.append(" = ");
		sb.append("?");
		//sb.append(dbCon.formatString(clusterDeviceName));
		sb.append(" AND ");
		sb.append(PortalDBEnum.DEVICES.deviceType);
		sb.append(" = ");
		sb.append(DeviceTypeEnum.KubernetesCluster.ordinal());

		return sb.toString();
	}


	private String mGetDeviceDetails() 
	{
		StringBuilder sb = new StringBuilder();
		sb.append("Select * ");
		sb.append(" FROM ");
		sb.append(PortalDBEnum.VIEW_NAMES.devicesnodes_view);
		sb.append(" WHERE ");
		sb.append(DEVICES_NODES_VIEW.nodes_macAddress);
		sb.append(" = ");sb.append("?");

		return sb.toString();
	}

	private String mAddDeviceDetailsInActivationHistory() {
		StringBuilder sb = new StringBuilder();
		sb.append("INSERT INTO ");
		sb.append(PortalDBEnum.TABLE_NAMES.activationhistory);
		sb.append(" ( ");
		sb.append(PortalDBEnum.ACTIVATION_HISTORY.deviceId.name());
		sb.append(", ");
		sb.append(PortalDBEnum.ACTIVATION_HISTORY.userId.name());
		sb.append(", ");
		sb.append(PortalDBEnum.ACTIVATION_HISTORY.macAddress.name());
		sb.append(", ");
		sb.append(PortalDBEnum.ACTIVATION_HISTORY.machineId.name());
		sb.append(", ");
		sb.append(PortalDBEnum.ACTIVATION_HISTORY.nativeAppId.name());
		sb.append(", ");
		sb.append(PortalDBEnum.ACTIVATION_HISTORY.action.name());
		sb.append(" ) VALUES ( ");
		sb.append("?");
		//sb.append(dbCon.formatString(deviceNodeVO.getNodeId()));
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(userId));
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(deviceNodeVO.getMacAddress()));
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(deviceNodeVO.getMachineId()));
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(deviceNodeVO.getNativeAppId()));
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(deviceNodeVO.getAction()));
		sb.append(" ) ");
		return sb.toString();
	}

	private StringBuilder getWhereClause(StringBuilder whereClause){
		if(whereClause == null){
			whereClause = new StringBuilder();
			whereClause.append(" WHERE ");						
		} else{
			whereClause.append(" AND ");
		}
		return whereClause;			
	}

	private StringBuilder joinWithDiscoveryDetails(StringBuilder joinCategories) 
	{
		joinCategories.append(" LEFT JOIN ");		
		joinCategories.append(PortalDBEnum.TABLE_NAMES.discoverydetails);joinCategories.append(" AS dd ");
		joinCategories.append(" ON ");	
		joinCategories.append("dd.");joinCategories.append(PortalDBEnum.DISCOVERY_DETAILS.sDeviceID);
		joinCategories.append(" = ");
		joinCategories.append(PortalDBEnum.VIEW_NAMES.devicesnodes_view);
		joinCategories.append(".");
		joinCategories.append(PortalDBEnum.DEVICES_NODES_VIEW.nodes_nodeId);
		return joinCategories;
	}

	private StringBuilder joinWithGroupEdgeCore(StringBuilder joinCategories) 
	{
		joinCategories.append(" LEFT JOIN ");		
		joinCategories.append(PortalDBEnum.TABLE_NAMES.groupEdgeCore);joinCategories.append(" AS gec ");
		joinCategories.append(" ON ");	
		joinCategories.append("gec.");joinCategories.append(PortalDBEnum.GROUP_EDGECORE.edgeCoreId);
		joinCategories.append(" = ");
		joinCategories.append(PortalDBEnum.VIEW_NAMES.devicesnodes_view);
		joinCategories.append(".");
		joinCategories.append(PortalDBEnum.DEVICES_NODES_VIEW.devices_deviceId);
		return joinCategories;
	}
	private StringBuilder joinWithDeviceLable(StringBuilder joinCategories) 
	{
		joinCategories.append(" LEFT JOIN ");		
		joinCategories.append(PortalDBEnum.TABLE_NAMES.devicelabelmap);joinCategories.append(" AS dl ");
		joinCategories.append(" ON ");	
		joinCategories.append("dl.");joinCategories.append(PortalDBEnum.DEVICE_LABEL_MAP.deviceId);
		joinCategories.append(" = ");
		joinCategories.append(PortalDBEnum.VIEW_NAMES.devicesnodes_view);
		joinCategories.append(".");
		joinCategories.append(PortalDBEnum.DEVICES_NODES_VIEW.devices_deviceId);
		return joinCategories;
	}

	private StringBuilder joinWithUpdatePlatform(StringBuilder joinCategories) 
	{
		joinCategories.append(" LEFT JOIN ");	
		joinCategories.append("SystemUpdate");
		joinCategories.append(".");
		joinCategories.append(UpdateServiceDBEnum.TABLE_NAMES.applicationPlatform);joinCategories.append(" AS ap ");
		joinCategories.append(" ON ");	
		joinCategories.append("ap.");joinCategories.append(UpdateServiceDBEnum.APP_PLATFORM.hwPlatform);
		joinCategories.append(" = ");
		joinCategories.append(PortalDBEnum.VIEW_NAMES.devicesnodes_view);
		joinCategories.append(".");
		joinCategories.append(PortalDBEnum.DEVICES_NODES_VIEW.devices_platformId);
		return joinCategories;
	}

	//to join with group release it is required to join with applicationPlatform first
	private StringBuilder joinWithGroupRelease(StringBuilder joinCategories) 
	{
		joinCategories.append(" LEFT JOIN ");	
		joinCategories.append("SystemUpdate");
		joinCategories.append(".");
		joinCategories.append(UpdateServiceDBEnum.TABLE_NAMES.groupRelease);joinCategories.append(" AS gr ");
		joinCategories.append(" ON ");	
		joinCategories.append("gr.");joinCategories.append(UpdateServiceDBEnum.APP_GROUP_RELEASE.appId);
		joinCategories.append(" = ");
		joinCategories.append("ap.");
		joinCategories.append(UpdateServiceDBEnum.APP_PLATFORM.appId);
		return joinCategories;
	}
	private StringBuilder getJoinClauseWithNodeView(StringBuilder joinCategories, String tableNameToJoin)
	{
		boolean toAddJoin = false;
		if(joinCategories==null)
			joinCategories = new StringBuilder();
		if(!joinCategories.toString().contains(" "+ tableNameToJoin+ " "))
			toAddJoin =true;

		if(toAddJoin)
		{
			if(tableNameToJoin.equalsIgnoreCase(PortalDBEnum.TABLE_NAMES.discoverydetails.name()))
				joinWithDiscoveryDetails(joinCategories);
			else if(tableNameToJoin.equalsIgnoreCase(PortalDBEnum.TABLE_NAMES.devicelabelmap.name()))
				joinWithDeviceLable(joinCategories);
			else if(tableNameToJoin.equalsIgnoreCase(UpdateServiceDBEnum.TABLE_NAMES.applicationPlatform.name()))
				joinWithUpdatePlatform(joinCategories);
			else if(tableNameToJoin.equalsIgnoreCase(UpdateServiceDBEnum.TABLE_NAMES.groupRelease.name()))
			{
				if(!joinCategories.toString().contains(" "+ UpdateServiceDBEnum.TABLE_NAMES.applicationPlatform.name()+ " "))
					joinWithUpdatePlatform(joinCategories);
				joinWithGroupRelease(joinCategories);
			}
			else if(tableNameToJoin.equalsIgnoreCase(PortalDBEnum.TABLE_NAMES.groupEdgeCore.name()))
				joinWithGroupEdgeCore(joinCategories);

		}

		return joinCategories;
	}

	/**
	 * Get parent cluster name from node device id
	 * @param nodeId
	 * @return
	 */
	public String getClusterName()
	{
		return mGetClusterName();
	}

	/**
	 * 
	 * @param nodeId
	 * @return
	 */
	private String mGetClusterName()
	{
		StringBuilder sb = new StringBuilder();
		sb.append("Select ");
		sb.append(DEVICES_NODES_VIEW.devices_deviceName);
		sb.append(" FROM ");
		sb.append(PortalDBEnum.VIEW_NAMES.devicesnodes_view);
		sb.append(" WHERE ");
		sb.append(DEVICES_NODES_VIEW.nodes_nodeId);
		sb.append(" = ");sb.append("?");

		return sb.toString();
	}

	/**
	 * List devices basic information deviceVO, boxStaticsModifiedDate, boxStatics, appInstallTime, dHBRdate.
	 * @param pageNo
	 * @param pageSize
	 * @param userId
	 * @return 
	 */
	public String listDevicesUtility() 
	{
		return mListDevicesUtility();
	}

	private  String  mListDevicesUtility() 
	{

		StringBuilder sb = new StringBuilder();
		sb.append("SELECT ");
		sb.append("dn.*, ");	
		sb.append("dd.");sb.append(PortalDBEnum.DISCOVERY_DETAILS.dHBRdate);
		sb.append(", ");
		sb.append("bs.");sb.append(PortalDBEnum.BOX_STATICS.modifiedDate);
		sb.append(" AS bs_");sb.append(PortalDBEnum.BOX_STATICS.modifiedDate);
		sb.append(", ");
		sb.append("bs.");sb.append(PortalDBEnum.BOX_STATICS.statics);
		sb.append(" AS bs_");sb.append(PortalDBEnum.BOX_STATICS.statics);
		sb.append(", ");	

		sb.append("da.");sb.append(PortalDBEnum.DEVICE_APPLICATIONS.modifiedDate);
		sb.append(" AS da_");sb.append(PortalDBEnum.DEVICE_APPLICATIONS.modifiedDate);

		sb.append(" FROM ");
		sb.append(PortalDBEnum.VIEW_NAMES.devicesnodes_view);sb.append(" AS dn ");

		sb.append(" LEFT JOIN ");		
		sb.append(PortalDBEnum.TABLE_NAMES.discoverydetails);sb.append(" AS dd ");
		sb.append(" ON ");	
		sb.append("dd.");sb.append(PortalDBEnum.DISCOVERY_DETAILS.sDeviceID);sb.append(" = ");sb.append("dn.");sb.append(PortalDBEnum.DEVICES_NODES_VIEW.nodes_nodeId);

		sb.append(" LEFT JOIN ");		
		sb.append(PortalDBEnum.TABLE_NAMES.boxStatics);sb.append(" AS bs ");
		sb.append(" ON ");	
		sb.append("dn.");sb.append(PortalDBEnum.DEVICES_NODES_VIEW.devices_deviceId);sb.append(" = ");sb.append("bs.");sb.append(PortalDBEnum.BOX_STATICS.deviceId);

		sb.append(" LEFT JOIN ");		
		sb.append(PortalDBEnum.TABLE_NAMES.deviceapplications);sb.append(" AS da ");
		sb.append(" ON ");	
		sb.append("dn.");sb.append(PortalDBEnum.DEVICES_NODES_VIEW.devices_deviceId);sb.append(" = ");sb.append("da.");sb.append(PortalDBEnum.DEVICE_APPLICATIONS.deviceId);

		sb.append(" WHERE ");
		sb.append("dn.");sb.append(PortalDBEnum.DEVICES_NODES_VIEW.devices_userId);
		sb.append(" = ");
		sb.append("?");


		sb.append(" ORDER BY cast(");
		sb.append("dn.");sb.append(PortalDBEnum.DEVICES_NODES_VIEW.devices_deviceId);
		sb.append(" as INT) ASC ");

		sb.append(" limit ");
		sb.append("?");
		sb.append(" offset ");
		sb.append("?");
		return sb.toString();

	}

	/**
	 * Create query to search all devices along with boxStaticsModifiedDate, latest boxStatics ,latest appInstallTime , dHBRdate to use in utility that shows devices info using paging.
	 * Basically this method is used to analyze the behavior of devices.  
	 * @param pageNo page number 
	 * @param pageSize number of applications to be returned in one page of result.
	 * @param userId user Id
	 * @param filters filters keys can be "dHBRDate" , "DeviceId" , "BSModifiedDate", "appInstallTime" and value can have start and end value of all the keys.  
	 * @return 
	 */
	public String searchDevicesUtility(Map<String, String> filters) 
	{
		return mSearchDevicesUtility(filters);
	}


	private String mSearchDevicesUtility(Map<String, String> filters) 
	{
		// int offset = (pageNo - 1) * pageSize;

		StringBuilder sb = new StringBuilder();
		sb.append("SELECT ");
		sb.append("dn.*, ");
		sb.append("dd.");
		sb.append(PortalDBEnum.DISCOVERY_DETAILS.dHBRdate);
		sb.append(", ");
		sb.append("bs.");
		sb.append(PortalDBEnum.BOX_STATICS.modifiedDate);
		sb.append(" AS bs_");
		sb.append(PortalDBEnum.BOX_STATICS.modifiedDate);
		sb.append(", ");
		sb.append("bs.");
		sb.append(PortalDBEnum.BOX_STATICS.statics);
		sb.append(" AS bs_");
		sb.append(PortalDBEnum.BOX_STATICS.statics);
		sb.append(", ");

		sb.append("da.");
		sb.append(PortalDBEnum.DEVICE_APPLICATIONS.modifiedDate);
		sb.append(" AS da_");
		sb.append(PortalDBEnum.DEVICE_APPLICATIONS.modifiedDate);

		sb.append(" FROM ");
		sb.append(PortalDBEnum.VIEW_NAMES.devicesnodes_view);
		sb.append(" AS dn ");

		sb.append(" LEFT JOIN ");
		sb.append(PortalDBEnum.TABLE_NAMES.discoverydetails);
		sb.append(" AS dd ");
		sb.append(" ON ");
		sb.append("dd.");
		sb.append(PortalDBEnum.DISCOVERY_DETAILS.sDeviceID);
		sb.append(" = ");
		sb.append("dn.");
		sb.append(PortalDBEnum.DEVICES_NODES_VIEW.nodes_nodeId);

		sb.append(" LEFT JOIN ");
		sb.append(PortalDBEnum.TABLE_NAMES.boxStatics);
		sb.append(" AS bs ");
		sb.append(" ON ");
		sb.append("dn.");
		sb.append(PortalDBEnum.DEVICES_NODES_VIEW.devices_deviceId);
		sb.append(" = ");
		sb.append("bs.");
		sb.append(PortalDBEnum.BOX_STATICS.deviceId);

		sb.append(" LEFT JOIN ");
		sb.append(PortalDBEnum.TABLE_NAMES.deviceapplications);
		sb.append(" AS da ");
		sb.append(" ON ");
		sb.append("dn.");
		sb.append(PortalDBEnum.DEVICES_NODES_VIEW.devices_deviceId);
		sb.append(" = ");
		sb.append("da.");
		sb.append(PortalDBEnum.DEVICE_APPLICATIONS.deviceId);

		sb.append(" WHERE ");
		sb.append("dn.");
		sb.append(PortalDBEnum.DEVICES_NODES_VIEW.devices_userId);
		sb.append(" = ");
		sb.append("?");
		// sb.append(dbCon.formatString(userId));

		if (filters != null) {
			sb.append(" AND ");

			Iterator<String> it = filters.keySet().iterator();
			while (it.hasNext()) {
				String key = it.next();
				String value = filters.get(key);
				DevicesUtilityFilterType filterType = DevicesUtilityFilterType.GetEnum(key);

				String startValue = "";
				String endValue = "";

				if (value.contains(",")) {
					String[] valueArr = value.split(",");
					startValue = valueArr[0];
					endValue = valueArr[1];
				} else {
					startValue = value;
				}

				switch (filterType) {
				case dHBRDate:
					sb.append("(");
					if (!StringFunctions.isNullOrWhitespace(startValue)) {

						sb.append("dd.");
						sb.append(PortalDBEnum.DISCOVERY_DETAILS.dHBRdate);
						sb.append(" >= ");
						sb.append("?");
						// sb.append(dbCon.formatString(Common.sqlDateFormat(Long.valueOf(startValue))));

					}

					if (!StringFunctions.isNullOrWhitespace(endValue)) {
						if (!StringFunctions.isNullOrWhitespace(startValue))
							sb.append(" AND ");

						sb.append("dd.");
						sb.append(PortalDBEnum.DISCOVERY_DETAILS.dHBRdate);
						sb.append(" <= ");
						sb.append("?");
						// sb.append(dbCon.formatString(Common.sqlDateFormat(Long.valueOf(endValue))));

					}

					sb.append(")");
					break;
				case appInstallTime:
					sb.append("(");
					if (!StringFunctions.isNullOrWhitespace(startValue)) {

						sb.append("da.");
						sb.append(PortalDBEnum.DEVICE_APPLICATIONS.modifiedDate);
						sb.append(" >= ");
						sb.append("?");
						// sb.append(dbCon.formatString(Common.sqlDateFormat(Long.valueOf(startValue))));
					}

					if (!StringFunctions.isNullOrWhitespace(endValue)) {
						if (!StringFunctions.isNullOrWhitespace(startValue))
							sb.append(" AND ");

						sb.append("da.");
						sb.append(PortalDBEnum.DEVICE_APPLICATIONS.modifiedDate);

						sb.append(" <= ");
						sb.append("?");
						// sb.append(dbCon.formatString(Common.sqlDateFormat(Long.valueOf(endValue))));
					}
					sb.append(")");

					break;

				case BSModifiedDate:
					sb.append("(");

					if (!StringFunctions.isNullOrWhitespace(startValue)) {

						sb.append("bs.");
						sb.append(PortalDBEnum.BOX_STATICS.modifiedDate);

						sb.append(" >= ");
						sb.append("?");
						// sb.append(dbCon.formatString(Common.sqlDateFormat(Long.valueOf(startValue))));
					}

					if (!StringFunctions.isNullOrWhitespace(endValue)) {
						if (!StringFunctions.isNullOrWhitespace(startValue))
							sb.append(" AND ");

						sb.append("bs.");
						sb.append(PortalDBEnum.BOX_STATICS.modifiedDate);

						sb.append(" <= ");
						sb.append("?");
						// sb.append(dbCon.formatString(Common.sqlDateFormat(Long.valueOf(endValue))));
					}

					sb.append(")");
					break;

				case DeviceId:
					sb.append("(");

					if (!StringFunctions.isNullOrWhitespace(startValue)
							&& !StringFunctions.isNullOrWhitespace(endValue)) {
						int startValueInt = Integer.parseInt(startValue);
						int endValueInt = Integer.parseInt(endValue);

						if (startValueInt > endValueInt) {
							int temp = startValueInt;
							startValueInt = endValueInt;
							endValueInt = temp;
						}

						List<String> list = new ArrayList<>();
						// StringBuilder commaSeperatedDeviceIds = new
						// StringBuilder();
						for (int i = startValueInt; i <= endValueInt; i++) {
							list.add(String.valueOf(i));
							// commaSeperatedDeviceIds.append(String.valueOf(i));
							// if (i != endValueInt)
							// commaSeperatedDeviceIds.append(", ");
						}
						SqlQueryBuilder queryBuilder = new SqlQueryBuilder();

						sb.append("dn.");
						sb.append(PortalDBEnum.DEVICES_NODES_VIEW.devices_deviceId);
						// sb.append(" in (");
						// sb.append(commaSeperatedDeviceIds);
						queryBuilder.appendQueryIN(list);

						sb.append(")");
					}
					break;
				}

				if (it.hasNext())
					sb.append(" OR ");
			}
		}

		sb.append(" ORDER BY cast(");
		sb.append("dn.");
		sb.append(PortalDBEnum.DEVICES_NODES_VIEW.devices_deviceId);
		sb.append(" as INT) ASC ");

		sb.append(" limit ");
		sb.append("?");
		// sb.append(pageSize);
		sb.append(" offset ");
		sb.append("?");
		// sb.append(offset);

		return sb.toString();
	}

	private List<String> mListDeviceFilter(String userId, List<FilterObject> filters, boolean listUpdateVersions,
			OwnershipEnum ownership, List<String> groupIds, int systemUpdateGroupIdsCount) {
		List<String> queries = new ArrayList<>();

		// int offset = (pageNo-1) * pageSize;

		StringBuilder sbOuter = new StringBuilder();
		sbOuter.append("SELECT  ");
		sbOuter.append("*");
		sbOuter.append(" FROM ");
		sbOuter.append(PortalDBEnum.VIEW_NAMES.devicesnodes_view);

		StringBuilder countQuery = new StringBuilder();
		countQuery.append("SELECT COUNT(DISTINCT ");
		countQuery.append(PortalDBEnum.VIEW_NAMES.devicesnodes_view);
		countQuery.append(".");
		countQuery.append(PortalDBEnum.DEVICES_NODES_VIEW.devices_deviceId);
		countQuery.append(") as rowCount FROM ");
		countQuery.append(PortalDBEnum.VIEW_NAMES.devicesnodes_view);

		StringBuilder sb = new StringBuilder();
		sb.append("SELECT DISTINCT ");
		sb.append(PortalDBEnum.VIEW_NAMES.devicesnodes_view);
		sb.append(".");
		sb.append(PortalDBEnum.DEVICES_NODES_VIEW.devices_deviceId);
		sb.append(" FROM ");
		sb.append(PortalDBEnum.VIEW_NAMES.devicesnodes_view);

		StringBuilder sortOrder = null;
		StringBuilder joinCategories = getJoinClauseWithNodeView(null, PortalDBEnum.TABLE_NAMES.devicelabelmap.name());
		StringBuilder whereClause = null;
		String searchString = "";
		SqlQueryBuilder sqlQueryBuilder = new SqlQueryBuilder();

		if (filters != null) {
			for (FilterObject filterObject : filters) {
				switch (filterObject.getFilterType()) {
				case FILTER:
					switch (filterObject.getFilterkey()) {
					case HBRDate:
						joinCategories = getJoinClauseWithNodeView(joinCategories,
								PortalDBEnum.TABLE_NAMES.discoverydetails.name());
						whereClause = getWhereClause(whereClause);

						if (!StringFunctions.isNullOrWhitespace(filterObject.getStartValue())) {
							whereClause.append("dd.");
							whereClause.append(PortalDBEnum.DISCOVERY_DETAILS.dHBRdate);
							whereClause.append(" <= ");
							whereClause.append("?");
							// whereClause.append(dbCon.formatString(Common.sqlDateFormat(Long.valueOf(filterObject.getStartValue()))));
						}
						if (!StringFunctions.isNullOrWhitespace(filterObject.getEndValue())) {
							if (!StringFunctions.isNullOrWhitespace(filterObject.getStartValue()))
								whereClause.append(" AND ");
							whereClause.append("dd.");
							whereClause.append(PortalDBEnum.DISCOVERY_DETAILS.dHBRdate);
							whereClause.append(" >= ");
							whereClause.append("?");
							// whereClause.append(dbCon.formatString(Common.sqlDateFormat(Long.valueOf(filterObject.getEndValue()))));
						}
						break;
					case HWPlatform:
						sqlQueryBuilder = new SqlQueryBuilder();

						whereClause = getWhereClause(whereClause);
						whereClause.append(PortalDBEnum.VIEW_NAMES.devicesnodes_view);
						whereClause.append(".");
						whereClause.append(PortalDBEnum.DEVICES_NODES_VIEW.devices_platformId);
						sqlQueryBuilder.appendQueryIN(filterObject.getValues());
						whereClause.append(sqlQueryBuilder.getQuery());
						// whereClause.append(" IN ( ");
						// whereClause.append(PortalDatabaseEngine.getInstance().getConnection().formatStringForIn(filterObject.getValues()));
						// whereClause.append(")");
						break;
					case SWPlatform:
						whereClause = getWhereClause(whereClause);
						whereClause.append(PortalDBEnum.VIEW_NAMES.devicesnodes_view);
						whereClause.append(".");
						whereClause.append(PortalDBEnum.DEVICES_NODES_VIEW.devices_deviceType);
						sqlQueryBuilder = new SqlQueryBuilder();
						sqlQueryBuilder.appendQueryIN(filterObject.getValues());
						whereClause.append(sqlQueryBuilder.getQuery());
						// whereClause .append(" IN ( ");
						// whereClause.append(PortalDatabaseEngine.getInstance().getConnection().formatStringForIn(filterObject.getValues()));
						// whereClause.append(")");

						break;
					case Labels:
						whereClause = getWhereClause(whereClause);
						whereClause.append("dl.");
						whereClause.append(PortalDBEnum.DEVICE_LABEL_MAP.labelId);

						sqlQueryBuilder = new SqlQueryBuilder();
						sqlQueryBuilder.appendQueryIN(filterObject.getValues());
						whereClause.append(sqlQueryBuilder.getQuery());
						// whereClause .append(" IN ( ");
						// whereClause.append(PortalDatabaseEngine.getInstance().getConnection().formatStringForIn(filterObject.getValues()));
						// whereClause.append(")");
						break;
					default:
						break;
					}
					break;
				case SEARCHTEXT: // This case will be called only once in the
									// loop as there can only be one search
									// string and that will apply on device
									// title.
					whereClause = getWhereClause(whereClause);
					whereClause.append(PortalDBEnum.VIEW_NAMES.devicesnodes_view);
					whereClause.append(".");
					whereClause.append(PortalDBEnum.DEVICES_NODES_VIEW.devices_deviceName);

					if (filterObject.getOperator().ordinal() == Operator.LIKE.ordinal()) {
						// device name contains search text
						searchString = filterObject.getStartValue();
						whereClause.append(" LIKE ");
						whereClause.append("?");
						// whereClause.append(PortalDatabaseEngine.getInstance().getConnection().formatStringForLike(true,searchString
						// , true));
					} else if (filterObject.getOperator().ordinal() == Operator.EQUAL.ordinal()) {
						whereClause.append(" = ");
						whereClause.append("?");
						// whereClause.append(PortalDatabaseEngine.getInstance().getConnection().formatString(filterObject.getStartValue()));
					}
					break;
				case SORT:
					sortOrder = new StringBuilder();
					sortOrder.append(" ORDER BY ");
					switch (filterObject.getSortKey()) {
					case Name:
						// Here assuming that we will always add search filter
						// before the sort filter.
						if (searchString.equals("")) {
							sortOrder.append(PortalDBEnum.VIEW_NAMES.devicesnodes_view);
							sortOrder.append(".");
							sortOrder.append(PortalDBEnum.DEVICES_NODES_VIEW.devices_deviceName);
						} else {
							// sort by best match : Exact equals first then
							// starts with, then contains and then ends with.
							sortOrder.append(" CASE WHEN ");
							sortOrder.append(PortalDBEnum.VIEW_NAMES.devicesnodes_view);
							sortOrder.append(".");
							sortOrder.append(PortalDBEnum.DEVICES_NODES_VIEW.devices_deviceName);
							sortOrder.append(" = ");
							sortOrder.append("?");
							// sortOrder.append(PortalDatabaseEngine.getInstance().getConnection().formatString(searchString));
							sortOrder.append(" THEN 0 ");

							sortOrder.append(" WHEN ");
							sortOrder.append(PortalDBEnum.VIEW_NAMES.devicesnodes_view);
							sortOrder.append(".");
							sortOrder.append(PortalDBEnum.DEVICES_NODES_VIEW.devices_deviceName);
							sortOrder.append(" LIKE ");
							sortOrder.append("?");
							// sortOrder.append(PortalDatabaseEngine.getInstance().getConnection().formatStringForLike(false,
							// searchString, true));
							sortOrder.append(" THEN 1 ");

							sortOrder.append(" WHEN ");
							sortOrder.append(PortalDBEnum.VIEW_NAMES.devicesnodes_view);
							sortOrder.append(".");
							sortOrder.append(PortalDBEnum.DEVICES_NODES_VIEW.devices_deviceName);
							sortOrder.append(" LIKE ");
							sortOrder.append("?");
							// sortOrder.append(PortalDatabaseEngine.getInstance().getConnection().formatStringForLike(true,
							// searchString, false));
							sortOrder.append(" THEN 3 ");

							sortOrder.append(" ELSE 2 ");

							sortOrder.append(" END ");
							sortOrder.append(" , ");
							sortOrder.append(PortalDBEnum.VIEW_NAMES.devicesnodes_view);
							sortOrder.append(".");
							sortOrder.append(PortalDBEnum.DEVICES_NODES_VIEW.devices_deviceName);
						}
						break;
					case Status:
						joinCategories = getJoinClauseWithNodeView(joinCategories,
								PortalDBEnum.TABLE_NAMES.discoverydetails.name());
						sortOrder.append(" IF(");
						sortOrder.append("dd.");
						sortOrder.append(PortalDBEnum.DISCOVERY_DETAILS.dHBRdate);
						sortOrder.append(" IS NULL ,");
						sortOrder.append(PortalDBEnum.VIEW_NAMES.devicesnodes_view);
						sortOrder.append(".");
						sortOrder.append(PortalDBEnum.DEVICES_NODES_VIEW.devices_modifiedDate);
						sortOrder.append(",");
						sortOrder.append("dd.");
						sortOrder.append(PortalDBEnum.DISCOVERY_DETAILS.dHBRdate);
						sortOrder.append(")");
						break;
					case CreationTime:
						sortOrder.append(PortalDBEnum.VIEW_NAMES.devicesnodes_view);
						sortOrder.append(".");
						sortOrder.append(PortalDBEnum.DEVICES_NODES_VIEW.devices_createdDate);
						break;
					default:
						break;
					}
					if (filterObject.getOperator().ordinal() == Operator.DESC.ordinal()) {
						sortOrder.append(" DESC ");
					}
					break;
				default:
					break;

				}
			}
		}
		whereClause = getWhereClause(whereClause);
		whereClause.append(DEVICES_NODES_VIEW.devices_deviceStatus);
		whereClause.append(" != ");
		whereClause.append(Status.DELETED.ordinal());
		StringBuilder grpWhere = new StringBuilder();
		boolean isgroupIdUsed = false;

		SqlQueryBuilder builder = new SqlQueryBuilder();

		switch (ownership) {
		case None:
			break;
		case Owner:
			whereClause = getWhereClause(whereClause);
			whereClause.append(PortalDBEnum.DEVICES_NODES_VIEW.devices_userId);
			whereClause.append(" = ");
			whereClause.append("?");
			// whereClause.append(dbCon.formatString(userId));
			break;
		case Invitee:
			builder = new SqlQueryBuilder();
			isgroupIdUsed = true;
			joinCategories = getJoinClauseWithNodeView(joinCategories, PortalDBEnum.TABLE_NAMES.groupEdgeCore.name());
			whereClause = getWhereClause(whereClause);
			grpWhere.append(" gec.");
			grpWhere.append(PortalDBEnum.GROUP_EDGECORE.groupId);

			if (groupIds != null && !groupIds.isEmpty()) {
				builder.appendQueryIN(groupIds);
			} else {
				builder.appendQueryIN(1);
			}
			grpWhere.append(builder.getQuery());
			// grpWhere.append(" IN (");
			// if(groupIds!=null && !groupIds.isEmpty())
			// grpWhere.append(dbCon.formatStringForIn(groupIds));
			// else
			// grpWhere.append(dbCon.formatString(""));
			// grpWhere.append(") ");

			whereClause.append(grpWhere);
			break;
		case Both:
			builder = new SqlQueryBuilder();
			isgroupIdUsed = true;
			joinCategories = getJoinClauseWithNodeView(joinCategories, PortalDBEnum.TABLE_NAMES.groupEdgeCore.name());
			whereClause = getWhereClause(whereClause);
			grpWhere.append("(");
			grpWhere.append(PortalDBEnum.DEVICES_NODES_VIEW.devices_userId);
			grpWhere.append(" = ");
			grpWhere.append("?");
			// grpWhere.append(dbCon.formatString(userId));
			grpWhere.append(" or ");
			grpWhere.append(" gec.");
			grpWhere.append(PortalDBEnum.GROUP_EDGECORE.groupId);

			if (groupIds != null && !groupIds.isEmpty()) {
				builder.appendQueryIN(groupIds);
			} else {
				builder.appendQueryIN(1);
			}
			grpWhere.append(builder.getQuery());

			// grpWhere.append(" IN (");
			// if(groupIds!=null && !groupIds.isEmpty())
			// grpWhere.append(dbCon.formatStringForIn(groupIds));
			// else
			// grpWhere.append(dbCon.formatString(""));
			//
			// grpWhere.append(") ");

			grpWhere.append(") ");
			whereClause.append(grpWhere);
			break;
		default:
			break;
		}

		// join with categories table if filter on categories applied.
		if (joinCategories != null) {
			sb.append(joinCategories);
			countQuery.append(joinCategories);
		}

		// Add where conditions
		sb.append(whereClause);
		countQuery.append(whereClause);

		// Add sort order
		if (sortOrder != null) {
			sb.append(sortOrder);
			countQuery.append(sortOrder);
		}

		// Add paging
		sb.append(" limit ");
		sb.append("?");
		// sb.append(pageSize);
		sb.append(" offset ");
		sb.append("?");
		// sb.append(offset);

		// only for out query
		joinCategories = getJoinClauseWithNodeView(joinCategories, PortalDBEnum.TABLE_NAMES.discoverydetails.name());
		if (listUpdateVersions)
			joinCategories = getJoinClauseWithNodeView(joinCategories,
					UpdateServiceDBEnum.TABLE_NAMES.groupRelease.name());

		if (joinCategories != null)
			sbOuter.append(joinCategories);
		sbOuter.append(" INNER JOIN (");
		sbOuter.append(sb.toString());
		sbOuter.append(") joinOut on joinOut.");
		sbOuter.append(PortalDBEnum.DEVICES_NODES_VIEW.devices_deviceId);
		sbOuter.append(" = ");
		sbOuter.append(PortalDBEnum.VIEW_NAMES.devicesnodes_view);
		sbOuter.append(".");
		sbOuter.append(PortalDBEnum.DEVICES_NODES_VIEW.devices_deviceId);
		if (isgroupIdUsed) {
			sbOuter.append(" WHERE ");
			sbOuter.append(grpWhere);
		}

		if (listUpdateVersions) {
			if (isgroupIdUsed)
				sbOuter.append(" AND ");
			else
				sbOuter.append(" WHERE ");

			sbOuter.append("ap.");
			sbOuter.append(UpdateServiceDBEnum.APP_PLATFORM.swPlatform);
			sbOuter.append(" = ");
			sbOuter.append(PortalDBEnum.VIEW_NAMES.devicesnodes_view);
			sbOuter.append(".");
			sbOuter.append(PortalDBEnum.DEVICES_NODES_VIEW.devices_swPlatformId);
			sbOuter.append(" AND ");
			sbOuter.append("ap.");
			sbOuter.append(UpdateServiceDBEnum.APP_PLATFORM.name);
			sbOuter.append(" = ");
			sbOuter.append("?");
			// sbOuter.append(dbCon.formatString("Appliance"));
			sbOuter.append(" AND ");
			sbOuter.append("gr.");
			sbOuter.append(UpdateServiceDBEnum.APP_GROUP_RELEASE.groupId);
			builder = new SqlQueryBuilder();
			builder.appendQueryIN(systemUpdateGroupIdsCount);
			sbOuter.append(builder.getQuery().toString());

			// sbOuter.append(" in( ");
			// sbOuter.append("Select distinct ");
			// sbOuter.append(UpdateServiceDBEnum.APP_GROUP_USERS.groupId.name());
			// sbOuter.append(" FROM ");
			// sbOuter.append("SystemUpdate");
			// sbOuter.append(".");
			// sbOuter.append(UpdateServiceDBEnum.TABLE_NAMES.groupUsers);
			// sbOuter.append(" as gu ");
			// sbOuter.append(" WHERE gu.");
			// sbOuter.append(UpdateServiceDBEnum.APP_GROUP_USERS.appUserId);
			// if (StringFunctions.isNullOrWhitespace(userId))
			// sbOuter.append(" <> ");
			// else
			// sbOuter.append(" = ");
			//
			// sbOuter.append("?");
			// // sbOuter.append(dbCon.formatString(userId));
			// sbOuter.append(" UNION ALL (SELECT 'ALL')) and ");

			sbOuter.append(" and ");
			sbOuter.append("INET_ATON(gr.version)");
			sbOuter.append(" >= ");
			sbOuter.append("INET_ATON(");
			sbOuter.append(PortalDBEnum.DISCOVERY_DETAILS.sPort5);
			sbOuter.append(")");
		}

		// Add sort order
		if (sortOrder != null) {
			sbOuter.append(sortOrder);
		}

		queries.add(sbOuter.toString());

		queries.add(countQuery.toString());
		return queries;
	}

	public String getCount() {
		return mGetCount();
	}

	private String mGetCount() {
		StringBuilder qry = new StringBuilder("SELECT count(*) as count, ");
		qry.append(PortalDBEnum.DEVICES.deviceType);
		qry.append(" FROM  ");
		qry.append(PortalDBEnum.TABLE_NAMES.devices.name());
		qry.append(" GROUP BY ");
		qry.append(PortalDBEnum.DEVICES.deviceType);
		return qry.toString();
	}


	/**
	 * Get parent cluster id of a node
	 * @return
	 */
	public String getParentClusterIdForANode(){
		return mGetParentClusterIdForANode(); 
	}

	private String mGetParentClusterIdForANode(){
		/**
		 * Get cluster id from query for nodeId -PS
		 */
		StringBuilder sbGetClusterId = new StringBuilder(); 
		sbGetClusterId.append("Select ");
		sbGetClusterId.append(PortalDBEnum.NODES.deviceId.name());
		sbGetClusterId.append(" from ");
		sbGetClusterId.append(PortalDBEnum.TABLE_NAMES.nodes);
		sbGetClusterId.append(" WHERE ");
		sbGetClusterId.append(PortalDBEnum.NODES.nodeId.name());
		sbGetClusterId.append(" = ");
		sbGetClusterId.append("?");	
		
		return sbGetClusterId.toString();
	}

	/**
	 * Update cluster active master
	 * Set the node with nodeId as active and others a backup 
	 * @param deviceId
	 * @return
	 */
	public List<String>  updateClusterActiveMaster() 
	{
		return mUpdateClusterActiveMaster();
	}

	private List<String>  mUpdateClusterActiveMaster()
	{	
		List<String> queries = new ArrayList<>();

		StringBuilder sbUpdateMasterRole = new StringBuilder();

		sbUpdateMasterRole.append("Update ");
		sbUpdateMasterRole.append(PortalDBEnum.TABLE_NAMES.nodes);
		sbUpdateMasterRole.append(" SET ");			
		sbUpdateMasterRole.append(PortalDBEnum.NODES.deviceState.name());
		sbUpdateMasterRole.append(" = ");
		sbUpdateMasterRole.append(StateEnum.Backup.getValue());								
		sbUpdateMasterRole.append(" WHERE ");
		sbUpdateMasterRole.append(PortalDBEnum.NODES.deviceId.name());
		sbUpdateMasterRole.append(" = ");
		sbUpdateMasterRole.append("?");
		sbUpdateMasterRole.append(" AND ");
		sbUpdateMasterRole.append(PortalDBEnum.NODES.deviceState.name());
		sbUpdateMasterRole.append(" = ");
		sbUpdateMasterRole.append(StateEnum.Active.getValue());
		queries.add(sbUpdateMasterRole.toString());

		sbUpdateMasterRole.setLength(0);

		sbUpdateMasterRole.append("Update ");
		sbUpdateMasterRole.append(PortalDBEnum.TABLE_NAMES.nodes);
		sbUpdateMasterRole.append(" SET ");			
		sbUpdateMasterRole.append(PortalDBEnum.NODES.deviceState.name());
		sbUpdateMasterRole.append(" = ");
		sbUpdateMasterRole.append(StateEnum.Active.getValue());								
		sbUpdateMasterRole.append(" WHERE ");
		sbUpdateMasterRole.append(PortalDBEnum.NODES.nodeId.name());
		sbUpdateMasterRole.append(" = ");
		sbUpdateMasterRole.append("?");	

		queries.add(sbUpdateMasterRole.toString());
		return queries;
	}

	/**
	 * Returns SQL which Checks whether node is part of cluster or not
	 * @param clusterId
	 * @param nodeId
	 * @return
	 * @author ps
	 */
	public String isNodeExistsInCluster()
	{
		return mIsNodeExistsInCluster();
	}

	/**
	 * Returns SQL which Checks whether node is part of cluster or not
	 * @param clusterId
	 * @param nodeId
	 * @return
	 * @author ps
	 */
	private String mIsNodeExistsInCluster()
	{
		StringBuilder sbGetNodeId = new StringBuilder();

		sbGetNodeId.append(" SELECT EXISTS(");
		sbGetNodeId.append(" SELECT 1 FROM ");		
		sbGetNodeId.append(PortalDBEnum.TABLE_NAMES.nodes);
		sbGetNodeId.append(" WHERE ");
		sbGetNodeId.append(PortalDBEnum.NODES.nodeId.name());
		sbGetNodeId.append(" = ");
		sbGetNodeId.append("?");
		sbGetNodeId.append(" AND ");
		sbGetNodeId.append(PortalDBEnum.NODES.deviceId.name());
		sbGetNodeId.append(" = ");
		sbGetNodeId.append("?");
		sbGetNodeId.append(" limit 1 )  as count");

		return sbGetNodeId.toString(); 
	}

	public String getSupportRelayDetails() {
		// TODO Auto-generated method stub
		StringBuilder sb=new StringBuilder();
		sb.append(" SELECT ");
		sb.append(" sr. "); 
		sb.append(PortalDBEnum.SUPPORT_RELAY_SERVERS.sRelayServerID);
		sb.append(", ");
		sb.append(" sr. ");
		sb.append(PortalDBEnum.SUPPORT_RELAY_SERVERS.sRelayServerAddress);
		sb.append(", ");
		sb.append(" sa. ");
		sb.append(PortalDBEnum.SUPPORT_ASSIGNED_RELAY_PORTS.nPortSegmentStart);
		sb.append(" FROM  ");
		sb.append(TABLE_NAMES.supportrelayservers);sb.append("  sr");
		sb.append(" JOIN ");
		sb.append(TABLE_NAMES.supportassignedrelayports);sb.append("  sa");		
		sb.append(" ON ");
		sb.append(" sr. "); 
		sb.append(PortalDBEnum.SUPPORT_RELAY_SERVERS.sRelayServerID);
		sb.append(" = ");
		sb.append(" sa. ");
		sb.append(PortalDBEnum.SUPPORT_ASSIGNED_RELAY_PORTS.sRelayServerID);
		sb.append(" WHERE ");		
		sb.append(" sa. ");sb.append(PortalDBEnum.SUPPORT_ASSIGNED_RELAY_PORTS.sDeviceID);
		sb.append(" = ");
		sb.append("?");
		return sb.toString();		
	}
	
	public String getGroupNames(String userId) {
		StringBuilder sbOuter = new StringBuilder();
		sbOuter.append("Select distinct ");
		sbOuter.append(UpdateServiceDBEnum.APP_GROUP_USERS.groupId.name());
		sbOuter.append(" FROM ");
		sbOuter.append("SystemUpdate");
		sbOuter.append(".");
		sbOuter.append(UpdateServiceDBEnum.TABLE_NAMES.groupUsers);
		sbOuter.append(" as gu ");
		sbOuter.append(" WHERE gu.");
		sbOuter.append(UpdateServiceDBEnum.APP_GROUP_USERS.appUserId);
		if (StringFunctions.isNullOrWhitespace(userId))
			sbOuter.append(" <> ");
		else
			sbOuter.append(" = ");

		sbOuter.append("?");
		// sbOuter.append(dbCon.formatString(userId));
		sbOuter.append(" UNION ALL (SELECT 'ALL')");

		return sbOuter.toString();
	}

}
