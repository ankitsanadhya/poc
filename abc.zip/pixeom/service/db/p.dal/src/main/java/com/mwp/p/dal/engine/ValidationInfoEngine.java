/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal.engine;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.common.vo.QueryVO;
import com.mwp.common.vo.ValidationInfoVO;
import com.mwp.logger.PALogger;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.dal.ValidationInfoDB;

/*
 *  
 */
public class ValidationInfoEngine {

	/**
	 * Insert new validation info this query update validation info if already exists
	 * @param infoVO
	 * @return ValidationInfoVO object
	 * @throws SQLException if can not add validation  
	 */
	public ValidationInfoVO addValidationInfo(ValidationInfoVO infoVO) throws SQLException{
		return mAddValidationInfo(infoVO);
	}

	/**
	 * Update existing validation information
	 * @param validInfoVO
	 * @return update ValidationInfoVO object
	 * @throws SQLException
	 */
	public ValidationInfoVO updateValidationInfo(ValidationInfoVO validInfoVO) throws SQLException {
		return mUpdateValidationInfo(validInfoVO);
	}
	
	/**
	 * Get validation information by macAddress
	 * @param macAddress
	 * @return
	 * @throws SQLException
	 */
	public ValidationInfoVO getValidationInfo(String macAddress) throws SQLException {
		
		return mGetValidationInfo(macAddress);
	}
	
	private ValidationInfoVO mGetValidationInfo(String macAddress) throws SQLException {
		ValidationInfoVO validInfoVO = null;
		String sql = new ValidationInfoDB().getValidationInfo();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(macAddress).build();

		PALogger.INFO("===GetValidationInfo ==" + sql);
		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				validInfoVO = new ValidationInfoVO();
				validInfoVO.setsMACAddress(rs.getString(PortalDBEnum.VALIDATION_INFO.sMACAddress.name()));
				validInfoVO.setsGUID(rs.getString(PortalDBEnum.VALIDATION_INFO.sGUID.name()));
				validInfoVO.setnStatus(rs.getInt(PortalDBEnum.VALIDATION_INFO.nStatus.name()));
				validInfoVO.setnTimestamp(rs.getLong(PortalDBEnum.VALIDATION_INFO.nTimestamp.name()));
				validInfoVO.setsInternetAddress(rs.getString(PortalDBEnum.VALIDATION_INFO.sInternetAddress.name()));
				validInfoVO.setsCode(rs.getString(PortalDBEnum.VALIDATION_INFO.sCode.name()));
				validInfoVO.setnPreviousTS(rs.getLong(PortalDBEnum.VALIDATION_INFO.nPreviousTS.name()));
			}
		}
		return validInfoVO;
	}

	private ValidationInfoVO mAddValidationInfo(ValidationInfoVO infoVO) throws SQLException {
		String sql = new ValidationInfoDB().addValidationInfo();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(infoVO.getsMACAddress()).addParameter(infoVO.getsGUID())
						.addParameter(infoVO.getnStatus()).addParameter(infoVO.getnTimestamp())
						.addParameter(infoVO.getsInternetAddress()).addParameter(0)
						.addParameter(infoVO.getnPreviousTS())
						// ON DUPLICATE
						.addParameter(infoVO.getsGUID()).addParameter(infoVO.getnStatus())
						.addParameter(infoVO.getnTimestamp()).addParameter(infoVO.getsInternetAddress()).addParameter(0)
						.addParameter(infoVO.getnPreviousTS()).build();

		int updateCount = PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
		if (updateCount == 0) {
			throw new SQLException("Unable to add validation info, please try again.");
		}
		return infoVO;
	}

	private ValidationInfoVO mUpdateValidationInfo(ValidationInfoVO infoVO) throws SQLException {
		String sql = new ValidationInfoDB().updateValidationInfo();
		
		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(infoVO.getsGUID())
						.addParameter(infoVO.getnTimestamp())
						.addParameter(infoVO.getnStatus())
						.addParameter(infoVO.getnPreviousTS())
						.addParameter(infoVO.getsMACAddress())
						.build();
		
		int updateCount = PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
		if(updateCount == 0){
			throw new SQLException("Unable to update validation info, please try again.");
		}
		return infoVO;
	}

}
