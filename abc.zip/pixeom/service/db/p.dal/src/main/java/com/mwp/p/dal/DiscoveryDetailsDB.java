/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal;

import com.mwp.common.StringFunctions;
import com.mwp.common.enums.NodeType;
import com.mwp.common.enums.StateEnum;
import com.mwp.common.vo.DiscoveryDetailsVO;
import com.mwp.db.Interface.IConnection;
import com.mwp.logger.PALogger;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.dal.engine.PortalDatabaseEngine;

/**
 * This class create queries related to table discoverydetails
 */
public class DiscoveryDetailsDB {

	private IConnection dbCon= null;
	public DiscoveryDetailsDB() {
		dbCon = PortalDatabaseEngine.getInstance().getConnection();
	}

	/**
	 * Create query to get discovery details of a device
	 * @param deviceId
	 * @return
	 */
	public String getDiscoverDetails(){
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT * FROM ");sb.append(PortalDBEnum.TABLE_NAMES.discoverydetails);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.DISCOVERY_DETAILS.sDeviceID);sb.append(" = ");sb.append("?");
		sb.append(" AND ");
		sb.append(PortalDBEnum.TABLE_NAMES.discoverydetails);sb.append(".");sb.append(PortalDBEnum.DISCOVERY_DETAILS.nStatus);
		sb.append(" = 1 ");
		return sb.toString();
	}

	/**
	 * Create query to get discovery details also join relay server table to get relay server info for a device. 
	 * @param deviceId
	 * @param isCheckStatus
	 * @return
	 */
	public String getDiscoverDetailsVO( boolean isCheckStatus){
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT *, ");
		sb.append(PortalDBEnum.RELAY_SERVERS.sRelayServerAddress);sb.append(",");
		sb.append(PortalDBEnum.RELAY_SERVERS.sRUserName);sb.append(","); 
		sb.append(PortalDBEnum.RELAY_SERVERS.sRPassword);sb.append(",");
		sb.append(PortalDBEnum.RELAY_SERVERS.sHostKey);sb.append(",");
		sb.append(PortalDBEnum.RELAY_SERVERS.nRPort); 

		sb.append(" FROM ");sb.append(PortalDBEnum.TABLE_NAMES.discoverydetails);
		sb.append(" LEFT JOIN ");sb.append(PortalDBEnum.TABLE_NAMES.relayservers); 
		sb.append(" ON ");
		sb.append(PortalDBEnum.TABLE_NAMES.discoverydetails);sb.append(".");sb.append(PortalDBEnum.DISCOVERY_DETAILS.sRelayServerID);
		sb.append(" = ");
		sb.append(PortalDBEnum.TABLE_NAMES.relayservers);sb.append(".");sb.append(PortalDBEnum.RELAY_SERVERS.sRelayServerID);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.DISCOVERY_DETAILS.sDeviceID);sb.append(" = ");sb.append("?");
		sb.append(" AND ");
		if(isCheckStatus){
			sb.append(PortalDBEnum.TABLE_NAMES.discoverydetails);sb.append(".");sb.append(PortalDBEnum.DISCOVERY_DETAILS.nStatus);
			sb.append(" = 1 OR ");
			sb.append(PortalDBEnum.TABLE_NAMES.discoverydetails);sb.append(".");sb.append(PortalDBEnum.DISCOVERY_DETAILS.nStatus);
			sb.append(" = 4");
		}else{
			sb.append(PortalDBEnum.TABLE_NAMES.discoverydetails);sb.append(".");sb.append(PortalDBEnum.DISCOVERY_DETAILS.nStatus);
			sb.append(" = 1 ");
		}
		return sb.toString();
	}
	
	public static void main(String[] args) {
		String deviceName = "ABCD";
		
//		 String s1 = new DiscoveryDetailsDB().getDiscoverDetailsVOByName("Cluster-px-aaee91d540ba", true)
//		 String s2 = new DiscoveryDetailsDB().getDiscoverDetailsVOByName("NKubernetes2", true)		
//		 String s3 = new DiscoveryDetailsDB().getDiscoverDetailsVOByName("MKubernetes1", true)
//		 String s4 = new DiscoveryDetailsDB().getDiscoverDetailsVOByName("px-aaee91d540ba", true)
//		 String s5 = new DiscoveryDetailsDB().getDiscoverDetailsVOByName("px-aaee21184deb", true)
		 
		 
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT dd.*, ");
		sb.append("rs.");sb.append(PortalDBEnum.RELAY_SERVERS.sRelayServerAddress);sb.append(",");
		sb.append("rs.");sb.append(PortalDBEnum.RELAY_SERVERS.sRUserName);sb.append(","); 
		sb.append("rs.");sb.append(PortalDBEnum.RELAY_SERVERS.sRPassword);sb.append(","); 
		sb.append("rs.");sb.append(PortalDBEnum.RELAY_SERVERS.sHostKey);sb.append(","); 
		sb.append("rs.");sb.append(PortalDBEnum.RELAY_SERVERS.nRPort);sb.append(","); 
		
		sb.append("dn.");sb.append(PortalDBEnum.DEVICES_NODES_VIEW.devices_deviceName);sb.append(","); 
		sb.append("dn.");sb.append(PortalDBEnum.DEVICES_NODES_VIEW.nodes_macAddress);sb.append(","); 
		sb.append("dn.");sb.append(PortalDBEnum.DEVICES_NODES_VIEW.nodes_hostName);
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.discoverydetails);sb.append(" AS dd ");
		sb.append(" INNER JOIN ");
		sb.append(PortalDBEnum.TABLE_NAMES.relayservers);sb.append(" AS rs ");
		sb.append(" ON ");
		sb.append("dd.");sb.append(PortalDBEnum.DISCOVERY_DETAILS.sRelayServerID);sb.append(" = ");sb.append("rs.");sb.append(PortalDBEnum.RELAY_SERVERS.sRelayServerID);
		sb.append(" INNER JOIN ");
		sb.append(PortalDBEnum.VIEW_NAMES.devicesnodes_view);sb.append(" AS dn ");
		sb.append(" ON ");
		sb.append("dd.");sb.append(PortalDBEnum.DISCOVERY_DETAILS.sDeviceID);sb.append(" = ");sb.append("dn.");sb.append(PortalDBEnum.DEVICES_NODES_VIEW.nodes_nodeId);		
		sb.append(" WHERE ");
		sb.append(" (( ");
		sb.append("(dn.");sb.append(PortalDBEnum.DEVICES_NODES_VIEW.devices_deviceName);sb.append(" = ");sb.append(deviceName);
		sb.append(" OR ");
		sb.append("dn.");sb.append(PortalDBEnum.DEVICES_NODES_VIEW.nodes_deviceName);sb.append(" = ");sb.append(deviceName);
		sb.append(" ) ");
		sb.append(" AND ");
		sb.append(" dn.");sb.append(PortalDBEnum.DEVICES_NODES_VIEW.nodes_deviceRole);sb.append(" = ");sb.append(NodeType.MASTER.ordinal());
		sb.append(" ) ");
		
		sb.append(" OR ");
		
		sb.append("dn.");sb.append(PortalDBEnum.DEVICES_NODES_VIEW.nodes_hostName);sb.append(" = ");sb.append(deviceName);
		
		sb.append(" OR ");
		
		sb.append("(dn.");sb.append(PortalDBEnum.DEVICES_NODES_VIEW.nodes_deviceName);sb.append(" = ");sb.append(deviceName);
		sb.append(" AND ");
		sb.append(" dn.");sb.append(PortalDBEnum.DEVICES_NODES_VIEW.nodes_deviceRole);sb.append(" = ");sb.append(NodeType.NODE.ordinal());
		sb.append(" ) ");
		
		sb.append(" ) ");
		
		sb.append(" AND ");

	
		sb.append("dd.");sb.append(PortalDBEnum.DISCOVERY_DETAILS.nStatus);sb.append(" = 1 ");
		
		PALogger.INFO(sb.toString());
	}

	/**
	 * Get discovery details information with relay server info where given devicename equal to
	 * kubernetes device MASTER device deviceName or kubernetes cluster deviceName
	 * or host name of any activated device
	 * @param deviceName
	 * @param isCheckStatus if true then check status value should be 1 or 4 otherwise only rows with status 1 return
	 * @return
	 */
	public String getDiscoverDetailsVOByName(boolean isCheckStatus){
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT dd.*, ");
		sb.append("rs.");sb.append(PortalDBEnum.RELAY_SERVERS.sRelayServerAddress);sb.append(",");
		sb.append("rs.");sb.append(PortalDBEnum.RELAY_SERVERS.sRUserName);sb.append(","); 
		sb.append("rs.");sb.append(PortalDBEnum.RELAY_SERVERS.sRPassword);sb.append(","); 
		sb.append("rs.");sb.append(PortalDBEnum.RELAY_SERVERS.sHostKey);sb.append(","); 
		sb.append("rs.");sb.append(PortalDBEnum.RELAY_SERVERS.nRPort);sb.append(","); 
		
		sb.append("dn.");sb.append(PortalDBEnum.DEVICES_NODES_VIEW.devices_deviceName);sb.append(","); 
		sb.append("dn.");sb.append(PortalDBEnum.DEVICES_NODES_VIEW.nodes_macAddress);sb.append(","); 
		sb.append("dn.");sb.append(PortalDBEnum.DEVICES_NODES_VIEW.nodes_hostName);
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.discoverydetails);sb.append(" AS dd ");
		sb.append(" LEFT JOIN ");
		sb.append(PortalDBEnum.TABLE_NAMES.relayservers);sb.append(" AS rs ");
		sb.append(" ON ");
		sb.append("dd.");sb.append(PortalDBEnum.DISCOVERY_DETAILS.sRelayServerID);sb.append(" = ");sb.append("rs.");sb.append(PortalDBEnum.RELAY_SERVERS.sRelayServerID);
		sb.append(" INNER JOIN ");
		sb.append(PortalDBEnum.VIEW_NAMES.devicesnodes_view);sb.append(" AS dn ");
		sb.append(" ON ");
		sb.append("dd.");sb.append(PortalDBEnum.DISCOVERY_DETAILS.sDeviceID);sb.append(" = ");sb.append("dn.");sb.append(PortalDBEnum.DEVICES_NODES_VIEW.nodes_nodeId);		
		sb.append(" WHERE ");
		sb.append(" ( ");
		sb.append("((dn.");sb.append(PortalDBEnum.DEVICES_NODES_VIEW.devices_deviceName);sb.append(" = ");sb.append("?");
		sb.append(" OR ");
		sb.append("dn.");sb.append(PortalDBEnum.DEVICES_NODES_VIEW.nodes_deviceName);sb.append(" = ");sb.append("?");
		sb.append(" ) ");

		sb.append(" AND ");
		sb.append(" dn.");sb.append(PortalDBEnum.DEVICES_NODES_VIEW.nodes_deviceState);sb.append(" = ");sb.append(StateEnum.Active.ordinal());
		sb.append(" ) ");		
		sb.append(" OR ");
		
		sb.append("(dn.");sb.append(PortalDBEnum.DEVICES_NODES_VIEW.nodes_deviceName);sb.append(" = ");sb.append("?");
		sb.append(" AND ");
		sb.append(" dn.");sb.append(PortalDBEnum.DEVICES_NODES_VIEW.nodes_deviceRole);sb.append(" = ");sb.append(NodeType.NODE.ordinal());
		sb.append(" ) ");
		
		sb.append(" OR ");
		sb.append("dn.");sb.append(PortalDBEnum.DEVICES_NODES_VIEW.nodes_hostName);sb.append(" = ");sb.append("?");
		
		sb.append(" ) ");
		
		sb.append(" AND ");

		if(isCheckStatus) {
			sb.append(" ( ");
			sb.append("dd.");sb.append(PortalDBEnum.DISCOVERY_DETAILS.nStatus);sb.append(" = 1");
			sb.append(" OR ");
			sb.append("dd.");sb.append(PortalDBEnum.DISCOVERY_DETAILS.nStatus);sb.append(" = 4");
			sb.append(" ) ");
		} else {
			sb.append("dd.");sb.append(PortalDBEnum.DISCOVERY_DETAILS.nStatus);sb.append(" = 1 ");
		}
		return sb.toString();
	}
	
	/**
	 * Update hearbeat time of device where status is 1
	 * @param deviceId
	 * @return
	 */
	public String updateDeviceHeartbeat() {
		StringBuilder sb = new StringBuilder();
		sb.append("UPDATE ");
		sb.append(PortalDBEnum.TABLE_NAMES.discoverydetails);
		sb.append(" SET ");
		sb.append(PortalDBEnum.DISCOVERY_DETAILS.dHBRdate);sb.append(" = NOW() ");
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.DISCOVERY_DETAILS.sDeviceID);sb.append(" = ");sb.append("?");
		sb.append(" AND ");
		sb.append(PortalDBEnum.TABLE_NAMES.discoverydetails);sb.append(".");sb.append(PortalDBEnum.DISCOVERY_DETAILS.nStatus);
		sb.append(" = 1 ");
		return sb.toString();
	}

	/**
	 * Update discovery details properties which do not empty in in table for a device  
	 * @param connectURL
	 * @param rAddress
	 * @param rURLTomcatPort
	 * @param deviceId
	 * @return
	 */
	public String updateDiscoveryDetails(String connectURL, String rAddress, String rURLTomcatPort) {

		StringBuilder sb = new StringBuilder();
		sb.append("UPDATE ");
		sb.append(PortalDBEnum.TABLE_NAMES.discoverydetails);
		sb.append(" SET ");

		StringBuilder sbUpdate = new StringBuilder();

		if (!StringFunctions.isNullOrWhitespace(connectURL)) {
			sbUpdate.append(PortalDBEnum.DISCOVERY_DETAILS.sConnectURL);
			sbUpdate.append(" = ");
			sbUpdate.append("?");
		}
		
		if (!StringFunctions.isNullOrWhitespace(rAddress)) {
			if (sbUpdate.length() > 0) {
				sbUpdate.append(", ");
			}
			sbUpdate.append(PortalDBEnum.DISCOVERY_DETAILS.sRAddress);
			sbUpdate.append(" = ");
			sbUpdate.append("?");
		}
		
		if (!StringFunctions.isNullOrWhitespace(rURLTomcatPort)) {
			if (sbUpdate.length() > 0) {
				sbUpdate.append(", ");
			}
			sbUpdate.append(PortalDBEnum.DISCOVERY_DETAILS.sRURLTomcatPort);
			sbUpdate.append(" = ");
			sbUpdate.append("?");
		}

		/*
		 * Add last in query before where condition
		 */
		if (sbUpdate.length() > 0) {
			sbUpdate.append(", ");
		}
		
		sbUpdate.append(PortalDBEnum.DISCOVERY_DETAILS.dHBRdate);
		sbUpdate.append(" = NOW()");

		sbUpdate.append(" WHERE ");
		sbUpdate.append(PortalDBEnum.DISCOVERY_DETAILS.sDeviceID);
		sbUpdate.append(" = ");
		sbUpdate.append("?");
		sbUpdate.append(" AND ");
		sbUpdate.append(PortalDBEnum.TABLE_NAMES.discoverydetails);
		sbUpdate.append(".");
		sbUpdate.append(PortalDBEnum.DISCOVERY_DETAILS.nStatus);
		sbUpdate.append(" = 1 ");
		return sb.toString() + sbUpdate.toString();

	}

	/**
//	 * Update RAddress of discovery details and also update heartbeat rate to now()
//	 * @param rAddress
//	 * @param deviceId
//	 * @return
//	 */
//	public String updateDiscoveryDetailsRAddress(String rAddress, String deviceId) {
//		StringBuilder sb = new StringBuilder();
//		sb.append("UPDATE ");
//		sb.append(PortalDBEnum.TABLE_NAMES.discoverydetails);
//		sb.append(" SET ");
//		sb.append(PortalDBEnum.DISCOVERY_DETAILS.sRAddress);sb.append(" = ");sb.append(dbCon.formatString(rAddress));
//		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_DETAILS.dHBRdate);sb.append(" = NOW() ");
//		sb.append(" WHERE ");
//		sb.append(PortalDBEnum.DISCOVERY_DETAILS.sDeviceID);sb.append(" = ");sb.append(dbCon.formatString(deviceId));
//		sb.append(" AND ");
//		sb.append(PortalDBEnum.TABLE_NAMES.discoverydetails);sb.append(".");sb.append(PortalDBEnum.DISCOVERY_DETAILS.nStatus);
//		sb.append(" = 1 ");
//		return sb.toString();
//	}
	
//	/**
//	 * Update statusand heart beat rate of discovery details entry for a device
//	 * @param deviceId
//	 * @param status
//	 * @return
//	 */
//	public String updateStatus(String deviceId, int status) {
//		StringBuilder sb = new StringBuilder();
//		sb.append("UPDATE ");
//		sb.append(PortalDBEnum.TABLE_NAMES.discoverydetails);
//		sb.append(" SET ");
//		sb.append(PortalDBEnum.DISCOVERY_DETAILS.nStatus);sb.append(" = "+status);
//		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_DETAILS.dHBRdate);sb.append(" = NOW() ");
//		sb.append(" WHERE ");
//		sb.append(PortalDBEnum.DISCOVERY_DETAILS.sDeviceID);sb.append(" = ");sb.append(dbCon.formatString(deviceId));
//		return sb.toString();
//	}
	
	/**
	 * Delete discovery details for a device
	 * @param deviceId
	 * @return
	 */
	public String delete() {
		StringBuilder sb = new StringBuilder();
		sb.append("DELETE FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.discoverydetails);		
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.DISCOVERY_DETAILS.sDeviceID);sb.append(" = ");sb.append("?");
		return sb.toString();
	}

	/**
	 * Update discovery details all properties as it is set to parameters.not check for empty values
	 * @param connectURL
	 * @param chatInputChannel
	 * @param networkType
	 * @param relayServerID
	 * @param chatOutputChannel
	 * @param chatSubscriptionChannel
	 * @param nodeCommunicationPort
	 * @param openStackPort
	 * @param tomcatPort
	 * @param port1
	 * @param port2
	 * @param port3
	 * @param port4
	 * @param port5
	 * @param rURLTomcatPort
	 * @param rAddress
	 * @param deviceId
	 * @return
	 */
	public String updateDiscoveryDetails() {
		StringBuilder sbUpdate = new StringBuilder();
		sbUpdate.append("UPDATE ");
		sbUpdate.append(PortalDBEnum.TABLE_NAMES.discoverydetails);
		sbUpdate.append(" SET ");

		sbUpdate.append(PortalDBEnum.DISCOVERY_DETAILS.sConnectURL);sbUpdate.append(" = ");sbUpdate.append("?");
		sbUpdate.append(", ");
		sbUpdate.append(PortalDBEnum.DISCOVERY_DETAILS.sChatInputChannel);sbUpdate.append(" = ");sbUpdate.append("?");
		sbUpdate.append(", ");
		sbUpdate.append(PortalDBEnum.DISCOVERY_DETAILS.sNetworkType);sbUpdate.append(" = ");sbUpdate.append("?");
		sbUpdate.append(", ");
		sbUpdate.append(PortalDBEnum.DISCOVERY_DETAILS.sRelayServerID);sbUpdate.append(" = ");sbUpdate.append("?");
		sbUpdate.append(", ");
		sbUpdate.append(PortalDBEnum.DISCOVERY_DETAILS.sChatOutputChannel);sbUpdate.append(" = ");sbUpdate.append("?");
		sbUpdate.append(", ");
		sbUpdate.append(PortalDBEnum.DISCOVERY_DETAILS.sChatSubscriptionChannel);sbUpdate.append(" = ");sbUpdate.append("?");
		sbUpdate.append(", ");
		sbUpdate.append(PortalDBEnum.DISCOVERY_DETAILS.sNodeCommunicationPort);sbUpdate.append(" = ");sbUpdate.append("?");
		sbUpdate.append(", ");
		sbUpdate.append(PortalDBEnum.DISCOVERY_DETAILS.sOpenStackPort);sbUpdate.append(" = ");sbUpdate.append("?");
		sbUpdate.append(", ");
		sbUpdate.append(PortalDBEnum.DISCOVERY_DETAILS.sKeyStonePort);sbUpdate.append(" = ");sbUpdate.append("?");
		sbUpdate.append(", ");
		sbUpdate.append(PortalDBEnum.DISCOVERY_DETAILS.sTomcatPort);sbUpdate.append(" = ");sbUpdate.append("?");
		sbUpdate.append(", ");
		sbUpdate.append(PortalDBEnum.DISCOVERY_DETAILS.sPort1);sbUpdate.append(" = ");sbUpdate.append("?");
		sbUpdate.append(", ");
		sbUpdate.append(PortalDBEnum.DISCOVERY_DETAILS.sPort2);sbUpdate.append(" = ");sbUpdate.append("?");
		sbUpdate.append(", ");
		sbUpdate.append(PortalDBEnum.DISCOVERY_DETAILS.sPort3);sbUpdate.append(" = ");sbUpdate.append("?");
		sbUpdate.append(", ");
		sbUpdate.append(PortalDBEnum.DISCOVERY_DETAILS.sPort4);sbUpdate.append(" = ");sbUpdate.append("?");
		sbUpdate.append(", ");
		sbUpdate.append(PortalDBEnum.DISCOVERY_DETAILS.sPort5);sbUpdate.append(" = ");sbUpdate.append("?");
		sbUpdate.append(", ");
		sbUpdate.append(PortalDBEnum.DISCOVERY_DETAILS.sRAddress);sbUpdate.append(" = ");sbUpdate.append("?");
		sbUpdate.append(", ");
		sbUpdate.append(PortalDBEnum.DISCOVERY_DETAILS.sRURLTomcatPort);sbUpdate.append(" = ");sbUpdate.append("?");
		sbUpdate.append(", ");
		sbUpdate.append(PortalDBEnum.DISCOVERY_DETAILS.sRURLKeystonePort);sbUpdate.append(" = ");sbUpdate.append("?");
		sbUpdate.append(", ");
		sbUpdate.append(PortalDBEnum.DISCOVERY_DETAILS.dHBRdate);sbUpdate.append(" = NOW()");

		sbUpdate.append(" WHERE ");
		sbUpdate.append(PortalDBEnum.DISCOVERY_DETAILS.sDeviceID);sbUpdate.append(" = ");sbUpdate.append("?");
		sbUpdate.append(" AND ");
		sbUpdate.append(PortalDBEnum.TABLE_NAMES.discoverydetails);sbUpdate.append(".");sbUpdate.append(PortalDBEnum.DISCOVERY_DETAILS.nStatus);
		sbUpdate.append(" = 1 ");
		return sbUpdate.toString();
	}

	/*
	 * Note: in this query we don't update connectUrl.
	 */
	/**
	 * Add new discovery details on duplicate key update all properties  other than connectUrl
	 * @param detailsVO
	 * @return
	 */
	public String addDiscoveryDetails(DiscoveryDetailsVO detailsVO) {
		StringBuilder sb = new StringBuilder();
		sb.append("INSERT INTO ");
		sb.append(PortalDBEnum.TABLE_NAMES.discoverydetails);
		sb.append(" ( ");
		sb.append(PortalDBEnum.DISCOVERY_DETAILS.sDeviceID);
		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_DETAILS.sRingID);
		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_DETAILS.sMasterID);
		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_DETAILS.nNodeStatus);
		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_DETAILS.sIPAddress);
		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_DETAILS.sLocalIPAddress);
		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_DETAILS.sChatInputChannel);
		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_DETAILS.sChatOutputChannel);
		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_DETAILS.sChatSubscriptionChannel);
		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_DETAILS.sNodeCommunicationPort);
		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_DETAILS.sOpenStackPort);
		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_DETAILS.sKeyStonePort);
		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_DETAILS.sTomcatPort);
		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_DETAILS.sPort1);
		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_DETAILS.sPort2);
		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_DETAILS.sPort3);
		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_DETAILS.sPort4);
		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_DETAILS.sPort5);

		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_DETAILS.sRURLTomcatPort);
		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_DETAILS.sRURLKeystonePort);
		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_DETAILS.sRAddress);

		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_DETAILS.nStatus);
		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_DETAILS.sRelayServerID);
		sb.append(", ");sb.append(PortalDBEnum.DISCOVERY_DETAILS.sNetworkType);
		sb.append(" ) VALUES (");
		sb.append("?");
		sb.append(", ");sb.append("?");
		sb.append(", ");sb.append("?");
		sb.append(", ");sb.append("?");
		sb.append(", ");sb.append("?");
		sb.append(", ");sb.append("?");
		sb.append(", ");sb.append("?");
		sb.append(", ");sb.append("?");
		sb.append(", ");sb.append("?");
		sb.append(", ");sb.append("?");
		sb.append(", ");sb.append("?");
		sb.append(", ");sb.append("?");
		sb.append(", ");sb.append("?");
		sb.append(", ");sb.append("?");
		sb.append(", ");sb.append("?");
		sb.append(", ");sb.append("?");
		sb.append(", ");sb.append("?");
		sb.append(", ");sb.append("?");
		sb.append(", ");sb.append("?");
		sb.append(", ");sb.append("?");
		sb.append(", ");sb.append("?");
		sb.append(", ");sb.append("?");
		sb.append(", ");sb.append("?");
		sb.append(", ");sb.append("?"); 
		sb.append(") ON DUPLICATE KEY UPDATE ");
		sb.append(PortalDBEnum.DISCOVERY_DETAILS.sIPAddress);
		sb.append(" = ");sb.append("?");

		sb.append(", ");
		sb.append(PortalDBEnum.DISCOVERY_DETAILS.sLocalIPAddress);
		sb.append(" = ");sb.append("?");

		sb.append(", ");
		sb.append(PortalDBEnum.DISCOVERY_DETAILS.sChatInputChannel);
		sb.append(" = ");
		sb.append("?");

		sb.append(", ");
		sb.append(PortalDBEnum.DISCOVERY_DETAILS.sChatOutputChannel);
		sb.append(" = ");sb.append("?");

		sb.append(", ");
		sb.append(PortalDBEnum.DISCOVERY_DETAILS.sChatSubscriptionChannel);
		sb.append(" = ");sb.append("?");

		sb.append(", ");
		sb.append(PortalDBEnum.DISCOVERY_DETAILS.sNodeCommunicationPort);
		sb.append(" = ");sb.append("?");

		sb.append(", ");
		sb.append(PortalDBEnum.DISCOVERY_DETAILS.sOpenStackPort);
		sb.append(" = ");sb.append("?");


		sb.append(", ");
		sb.append(PortalDBEnum.DISCOVERY_DETAILS.sTomcatPort);
		sb.append(" = ");
		sb.append("?");


		sb.append(", ");
		sb.append(PortalDBEnum.DISCOVERY_DETAILS.sPort1);
		sb.append(" = ");sb.append("?");

		sb.append(", ");
		sb.append(PortalDBEnum.DISCOVERY_DETAILS.sPort2);
		sb.append(" = ");sb.append("?");

		sb.append(", ");
		sb.append(PortalDBEnum.DISCOVERY_DETAILS.sPort3);
		sb.append(" = ");sb.append("?");

		sb.append(", ");
		sb.append(PortalDBEnum.DISCOVERY_DETAILS.sPort4);
		sb.append(" = ");sb.append("?");

		sb.append(", ");
		sb.append(PortalDBEnum.DISCOVERY_DETAILS.sPort5);
		sb.append(" = ");sb.append("?");

		sb.append(", ");
		sb.append(PortalDBEnum.DISCOVERY_DETAILS.sRURLTomcatPort);
		sb.append(" = ");sb.append("?");


		sb.append(", ");
		sb.append(PortalDBEnum.DISCOVERY_DETAILS.sRAddress);
		sb.append(" = ");sb.append("?");

		sb.append(", ");
		sb.append(PortalDBEnum.DISCOVERY_DETAILS.dHBRdate);
		sb.append(" = NOW() ");

		sb.append(", ");
		sb.append(PortalDBEnum.DISCOVERY_DETAILS.nStatus);sb.append(" = ");sb.append("?");

		sb.append(", ");
		sb.append(PortalDBEnum.DISCOVERY_DETAILS.sRelayServerID);
		sb.append(" = ");sb.append("?");

		sb.append(", ");
		sb.append(PortalDBEnum.DISCOVERY_DETAILS.sNetworkType);
		sb.append(" = ");sb.append("?");

		return sb.toString();

	}
}
