/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal;

import java.util.List;

import com.mwp.common.StringFunctions;
import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.common.vo.ApplicationPlatformVO;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.common.enums.PortalDBEnum.APPLICATION_PLATFORM;

/**
 * This class provides queries related to table {@link APPLICATION_PLATFORM}
 *
 */
public class AppRepositoryDB {

	/**
	 * Create query to add repository
	 * @param appRepoVO
	 * @return
	 */
	public String addAppRepo(ApplicationPlatformVO appRepoVO) {
		return mAddAppRepo(appRepoVO);
	}

	private String mAddAppRepo(ApplicationPlatformVO appRepoVO) {
		StringBuilder sb = new StringBuilder();
		sb.append("INSERT INTO ");
		sb.append(PortalDBEnum.TABLE_NAMES.applicationplatform);
		sb.append(" ( ");
		sb.append(PortalDBEnum.APPLICATION_PLATFORM.appPlatformId.name());
		sb.append(", ");
		sb.append(PortalDBEnum.APPLICATION_PLATFORM.platformId.name());
		sb.append(", ");
		sb.append(PortalDBEnum.APPLICATION_PLATFORM.appId.name());
		sb.append(", ");
		sb.append(PortalDBEnum.APPLICATION_PLATFORM.repositoryName.name());
		sb.append(", ");
		sb.append(PortalDBEnum.APPLICATION.modifiedDate.name());
		sb.append(" ) VALUES ( ");
		sb.append("?");
		sb.append(", ");
		sb.append("?");
		sb.append(", ");
		sb.append("?");
		sb.append(", ");
		sb.append("?");
		sb.append(", ");
		sb.append(" NOW()");
		sb.append(" ) ");
		return sb.toString();	
	}

	/**
	 * Create query check if repo id is available
	 * @param appId, repoName  
	 * @return
	 */
	public String isRepoNameAvailable(List<String> repoNames, String appId) {
		return mIsRepoNameAvailable(repoNames, appId);
	}

	private String mIsRepoNameAvailable(List<String> repoNames, String appId) {

		SqlQueryBuilder builder = new SqlQueryBuilder();
		builder.appendQuery("SELECT ").appendQuery(PortalDBEnum.APPLICATION_PLATFORM.repositoryName.name())
				.appendQuery(" FROM ").appendQuery(PortalDBEnum.TABLE_NAMES.applicationplatform).appendQuery(" WHERE ")
				.appendQuery(PortalDBEnum.APPLICATION_PLATFORM.repositoryName.name())

				.appendQueryIN(repoNames);
		// .appendQuery(" IN( ")
		// .appendQuery(PortalDatabaseEngine.getInstance().getConnection().formatStringForIn(repoNames))
		// .appendQuery(")");

		if (!StringFunctions.isNullOrWhitespace(appId)) {
			builder.appendQuery(" AND ").appendQuery(PortalDBEnum.APPLICATION_PLATFORM.appId.name()).appendQuery(" != ")
					.appendQuery("?");
		}

		return builder.getQuery().toString();
	}
}
