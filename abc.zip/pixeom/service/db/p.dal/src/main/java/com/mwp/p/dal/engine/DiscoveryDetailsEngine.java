/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal.engine;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.mwp.common.CredProvider;
import com.mwp.common.StringFunctions;
import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.common.enums.RelayEnum.NetworkTypeEnum;
import com.mwp.common.vo.DiscoveryDetailsVO;
import com.mwp.common.vo.QueryVO;
import com.mwp.logger.PALogger;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.common.enums.PortalDBEnum.DISCOVERY_DETAILS;
import com.mwp.p.dal.DiscoveryDetailsDB;
import com.pa.crypto.StringEncryptionDecryption;

/**
 * This class executes queries related to {@link DISCOVERY_DETAILS} and create required objects
 *
 */
public class DiscoveryDetailsEngine {

	/**
	 * List all discovery details for device 
	 * @param deviceId device id 
	 * @return
	 * @throws SQLException
	 */
	public Map<String, Object> getDiscoveryDetails(String deviceId) throws SQLException{

		return mGetDiscoveryDetails(deviceId);
	}

	/**
	 * Get a discovery details object for device. relay server information also set. 
	 * @param deviceId
	 * @param isCheckStatus_4
	 * @return
	 * @throws SQLException
	 */
	public DiscoveryDetailsVO getDiscoveryDetailsVO(String deviceId, boolean isCheckStatus4) throws SQLException{
		return mGetDiscoveryDetailsVO(deviceId, isCheckStatus4);
	}

	/**
	 * Get discovery details information with relay server info where given devicename equal to
	 * kubernetes device MASTER device deviceName or kubernetes cluster deviceName
	 * or host name of any activated device
	 * @param deviceName
	 * @param isCheckStatus_4 if true then check status value should be 1 or 4 otherwise only rows with status 1 return
	 * @return
	 */
	public DiscoveryDetailsVO getDiscoveryDetailsVOByName(String deviceName, boolean isCheckStatus4) throws SQLException{
		return mGetDiscoveryDetailsVOByName(deviceName, isCheckStatus4);
	}

	/**
	 * Update discovery details properties which do not empty in in table for a device  
	 * @param connectURL
	 * @param rAddress
	 * @param rURLTomcatPort
	 * @param deviceId
	 * @return
	 */
	public void updateDiscoveryDetails(String connectURL, String rAddress, String rURLTomcatPort,  String deviceId) throws SQLException{
		mUpdateDiscoveryDetails(connectURL, rAddress, rURLTomcatPort,  deviceId);
	}

	/**
	 * Update discovery details all properties as it is set to parameters.not check for empty values
	 * @param connectURL
	 * @param chatInputChannel
	 * @param networkType
	 * @param relayServerID
	 * @param chatOutputChannel
	 * @param chatSubscriptionChannel
	 * @param nodeCommunicationPort
	 * @param openStackPort
	 * @param tomcatPort
	 * @param port1
	 * @param port2
	 * @param port3
	 * @param port4
	 * @param port5
	 * @param rURLTomcatPort
	 * @param rAddress
	 * @param deviceId
	 * @throws SQLException
	 */
	public void updateDiscoveryDetails(String connectURL, String chatInputChannel, NetworkTypeEnum networkType,
			String relayServerID, String chatOutputChannel, String chatSubscriptionChannel,
			String nodeCommunicationPort, String openStackPort,  String tomcatPort, String port1,
			String port2, String port3, String port4, String port5, String rURLTomcatPort,
			String rAddress, String deviceId) throws SQLException {
		mUpdateDiscoveryDetails(connectURL, chatInputChannel, networkType, relayServerID, chatOutputChannel, chatSubscriptionChannel, 
				nodeCommunicationPort, openStackPort,  tomcatPort, port1, port2, port3, port4, port5, rURLTomcatPort, 
				rAddress, deviceId);
	}

	/**
	 * Add new discovery details for device
	 * @param detailsVO
	 * @return DiscoveryDetailsVO object
	 * @throws SQLException
	 */
	public DiscoveryDetailsVO addDiscoveryDetails(DiscoveryDetailsVO detailsVO) throws SQLException {
		return mAddDiscoveryDetails(detailsVO);
	}


	private DiscoveryDetailsVO mAddDiscoveryDetails(DiscoveryDetailsVO detailsVO) throws SQLException {


		int updateCount = PortalDatabaseEngine.getInstance().getConnection().executeUpdate(addDiscoveryDetailsQueryObject(detailsVO));
		if(updateCount == 0){
			throw new SQLException("Unable to insert discoverydetails, please try again.");
		}
		return detailsVO;
	}

	private QueryVO addDiscoveryDetailsQueryObject(DiscoveryDetailsVO detailsVO) throws SQLException{
		SqlQueryBuilder builder = new SqlQueryBuilder();
		builder.addParameter(detailsVO.getsDeviceID());
		builder.addParameter("");
		builder.addParameter(detailsVO.getsDeviceID());
		builder.addParameter(0);
		builder.addParameter(detailsVO.getsIPAddress());
		builder.addParameter(detailsVO.getsLocalIPAddress());
		builder.addParameter(detailsVO.getsChatInputChannel());
		builder.addParameter(detailsVO.getsChatOutputChannel());
		builder.addParameter(detailsVO.getsChatSubscriptionChannel());
		builder.addParameter(detailsVO.getsNodeCommunicationPort());
		builder.addParameter(detailsVO.getsOpenStackPort());
		builder.addParameter("");
		builder.addParameter(detailsVO.getsTomcatPort());
		builder.addParameter(detailsVO.getsPort1());
		builder.addParameter(detailsVO.getsPort2());
		builder.addParameter(detailsVO.getsPort3());
		builder.addParameter(detailsVO.getsPort4());
		builder.addParameter(detailsVO.getsPort5());
		builder.addParameter(detailsVO.getsRURLTomcatPort());
		builder.addParameter("");
		builder.addParameter(detailsVO.getsRAddress());
		builder.addParameter(detailsVO.getnStatus());
		builder.addParameter(detailsVO.getsRelayServerID());
		builder.addParameter(detailsVO.getsNetworkType().ordinal()); //24
		builder.addParameter(detailsVO.getsIPAddress());
		builder.addParameter(detailsVO.getsLocalIPAddress());
		builder.addParameter(detailsVO.getsChatInputChannel());
		builder.addParameter(detailsVO.getsChatOutputChannel());
		builder.addParameter(detailsVO.getsChatSubscriptionChannel());
		builder.addParameter(detailsVO.getsNodeCommunicationPort());
		builder.addParameter(detailsVO.getsOpenStackPort());
		builder.addParameter(detailsVO.getsTomcatPort());
		builder.addParameter(detailsVO.getsPort1());
		builder.addParameter(detailsVO.getsPort2());
		builder.addParameter(detailsVO.getsPort3());
		builder.addParameter(detailsVO.getsPort4());
		builder.addParameter(detailsVO.getsPort5());
		builder.addParameter(detailsVO.getsRURLTomcatPort());
		builder.addParameter(detailsVO.getsRAddress());	
		builder.addParameter(detailsVO.getnStatus());
		builder.addParameter(detailsVO.getsRelayServerID());
		builder.addParameter(detailsVO.getsNetworkType().ordinal());//18

		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new DiscoveryDetailsDB().addDiscoveryDetails(detailsVO)).addParameters(builder.getParameters()).build();

		PALogger.INFO("=====AddDiscoveryDetails SQL====" + queryVO.toString());

		return queryVO;
	}
	
	public void updateDeviceHeartbeat(String deviceId) throws SQLException {
		
		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new DiscoveryDetailsDB().updateDeviceHeartbeat()).addParameter(deviceId).build();

		PALogger.INFO("=====UpdateDiscoveryDetails1 SQL====" + queryVO.toString());
		executeUpdateDiscoverDetails(queryVO);
	}

	private void mUpdateDiscoveryDetails(String connectURL, String rAddress, String rURLTomcatPort, String deviceId) throws SQLException {

		List<Object> parameters = new ArrayList<>();
		if(!StringFunctions.isNullOrWhitespace(connectURL))
			parameters.add(connectURL);

		if(!StringFunctions.isNullOrWhitespace(rAddress))
			parameters.add(rAddress);

		if(!StringFunctions.isNullOrWhitespace(rURLTomcatPort))
			parameters.add(rURLTomcatPort);

		parameters.add(deviceId);

		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new DiscoveryDetailsDB().updateDiscoveryDetails(connectURL, rAddress, rURLTomcatPort)).addParameters(parameters).build();

		PALogger.INFO("=====UpdateDiscoveryDetails1 SQL====" + queryVO.toString());
		executeUpdateDiscoverDetails(queryVO);
	}

	private void mUpdateDiscoveryDetails(String connectURL, String chatInputChannel, NetworkTypeEnum networkType,
			String relayServerID, String chatOutputChannel, String chatSubscriptionChannel,
			String nodeCommunicationPort, String openStackPort, String tomcatPort, String port1,
			String port2, String port3, String port4, String port5, String rURLTomcatPort, 
			String rAddress, String deviceId) throws SQLException {

		QueryVO queryVO = UpdateDiscoveryDetailsQueryObject(connectURL, chatInputChannel, networkType,
				relayServerID, chatOutputChannel, chatSubscriptionChannel, 
				nodeCommunicationPort, openStackPort, tomcatPort, port1, 
				port2, port3, port4, port5, rURLTomcatPort, 
				rAddress, deviceId);

		PALogger.INFO("=====UpdateDiscoveryDetails2 SQL====" + queryVO.getSQL() + "============\n " + queryVO.getParameters());//todo print
		executeUpdateDiscoverDetails(queryVO);
	}

	public QueryVO UpdateDiscoveryDetailsQueryObject(String connectURL, String chatInputChannel, NetworkTypeEnum networkType,
			String relayServerID, String chatOutputChannel, String chatSubscriptionChannel,
			String nodeCommunicationPort, String openStackPort,String tomcatPort, String port1,
			String port2, String port3, String port4, String port5, String rURLTomcatPort, 
			String rAddress, String deviceId) throws SQLException{

		SqlQueryBuilder builder = new SqlQueryBuilder();
		
		builder.addParameter(connectURL);
		builder.addParameter(chatInputChannel);
		builder.addParameter(networkType.ordinal());	
		builder.addParameter(relayServerID);
		builder.addParameter(chatOutputChannel);
		builder.addParameter(chatSubscriptionChannel);
		builder.addParameter(nodeCommunicationPort);
		builder.addParameter(openStackPort);
		builder.addParameter("");
		builder.addParameter(tomcatPort);
		builder.addParameter(port1);
		builder.addParameter(port2);
		builder.addParameter(port3);
		builder.addParameter(port4);
		builder.addParameter(port5);
		builder.addParameter(rAddress);
		builder.addParameter(rURLTomcatPort);
		builder.addParameter("");
		builder.addParameter(deviceId);

		String sql = new DiscoveryDetailsDB().updateDiscoveryDetails();

		return new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(sql).addParameters(builder.getParameters()).build();
	}


	private void executeUpdateDiscoverDetails(QueryVO querieVo) throws SQLException{
		PortalDatabaseEngine.getInstance().getConnection().executeUpdate(querieVo);

	}

	private Map<String, Object> mGetDiscoveryDetails(String deviceId) throws SQLException{

		HashMap<String, Object> hashOutput = new HashMap<>();

		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new DiscoveryDetailsDB().getDiscoverDetails()).addParameter(deviceId).build();

		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)){
			while (rs.next()){
				hashOutput.put("ExternalIPAddress", rs.getString(PortalDBEnum.DISCOVERY_DETAILS.sIPAddress.name()));
				hashOutput.put("LANIPAddress", rs.getString(PortalDBEnum.DISCOVERY_DETAILS.sLocalIPAddress.name()));
				hashOutput.put("Port", rs.getString(PortalDBEnum.DISCOVERY_DETAILS.sTomcatPort.name()));
				hashOutput.put("defaultPort", "443");
				hashOutput.put("RelayServerID", rs.getString(PortalDBEnum.DISCOVERY_DETAILS.sRelayServerID.name()));
				hashOutput.put("NetworkType", NetworkTypeEnum.GetEnum(rs.getInt(PortalDBEnum.DISCOVERY_DETAILS.sNetworkType.name())));
				hashOutput.put("ConnectURL", rs.getString(PortalDBEnum.DISCOVERY_DETAILS.sConnectURL.name()));
				hashOutput.put("RelayServerAddress", rs.getString(PortalDBEnum.DISCOVERY_DETAILS.sRelayServerID.name()));
				hashOutput.put("Port5", rs.getString(PortalDBEnum.DISCOVERY_DETAILS.sPort5.name()));
				hashOutput.put("HDRDate", rs.getTimestamp(PortalDBEnum.DISCOVERY_DETAILS.dHBRdate.name()).getTime());				
			}
		}
		return hashOutput;
	}

	private DiscoveryDetailsVO mGetDiscoveryDetailsVO(String deviceId, boolean isCheckStatus4) throws SQLException{
		DiscoveryDetailsVO detailsVO = null;

		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new DiscoveryDetailsDB().getDiscoverDetailsVO(isCheckStatus4)).addParameter(deviceId).build();

		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)){
			while (rs.next()){
				detailsVO = setDiscoveryDetailsVOObject(rs, false);
			}
		}
		return detailsVO;
	}


	private DiscoveryDetailsVO mGetDiscoveryDetailsVOByName(String deviceName, boolean isCheckStatus4) throws SQLException{
		DiscoveryDetailsVO detailsVO = null;

		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new DiscoveryDetailsDB().getDiscoverDetailsVOByName(isCheckStatus4))
				.addParameter(deviceName)
				.addParameter(deviceName)
				.addParameter(deviceName)
				.addParameter(deviceName)
				.build();

		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)){
			while (rs.next()){
				detailsVO = setDiscoveryDetailsVOObject(rs, true);
			}
		}
		return detailsVO;
	}

	private DiscoveryDetailsVO setDiscoveryDetailsVOObject(ResultSet rs, boolean isSetDeviceProperty) throws SQLException {
		DiscoveryDetailsVO detailsVO = setDiscoveryDetailsObj(rs);
		String relayAddress = rs.getString(PortalDBEnum.RELAY_SERVERS.sRelayServerAddress.name());
		if(!StringFunctions.isNullOrWhitespace(relayAddress)){
			detailsVO.setsRelayServerAddress(relayAddress);
			String rUserName =  StringEncryptionDecryption.encrypt(StringEncryptionDecryption.decrypt(rs.getString(PortalDBEnum.RELAY_SERVERS.sRUserName.name()), new CredProvider().getEcnKey()), detailsVO.getsDeviceID());
			String rpwd =  StringEncryptionDecryption.encrypt(StringEncryptionDecryption.decrypt(rs.getString(PortalDBEnum.RELAY_SERVERS.sRPassword.name()), new CredProvider().getEcnKey()), detailsVO.getsDeviceID());
			String hostKey =  StringEncryptionDecryption.encrypt(StringEncryptionDecryption.decrypt(rs.getString(PortalDBEnum.RELAY_SERVERS.sHostKey.name()), new CredProvider().getEcnKey()), detailsVO.getsDeviceID());

			detailsVO.setsRUserName(rUserName);
			detailsVO.setsRPassword(rpwd);
			detailsVO.setsHostKey(hostKey);
			detailsVO.setnRPort(rs.getInt(PortalDBEnum.RELAY_SERVERS.nRPort.name()));
		}
		if(isSetDeviceProperty){
			detailsVO.setsDeviceName(rs.getString(PortalDBEnum.DEVICES_NODES_VIEW.devices_deviceName.name()));
			detailsVO.setsMACAddress(rs.getString(PortalDBEnum.DEVICES_NODES_VIEW.nodes_macAddress.name()));
			detailsVO.setsHostName(rs.getString(PortalDBEnum.DEVICES_NODES_VIEW.nodes_hostName.name()));
		}
		return detailsVO;
	}

	private DiscoveryDetailsVO setDiscoveryDetailsObj(ResultSet rs) throws SQLException{
		DiscoveryDetailsVO detailsVO = new DiscoveryDetailsVO();


		detailsVO.setsDeviceID(rs.getString(PortalDBEnum.DISCOVERY_DETAILS.sDeviceID.name()));
		detailsVO.setsRingID(rs.getString(PortalDBEnum.DISCOVERY_DETAILS.sRingID.name()));
		detailsVO.setsChatInputChannel(rs.getString(PortalDBEnum.DISCOVERY_DETAILS.sChatInputChannel.name()));

		detailsVO.setnNodeStatus(rs.getInt(PortalDBEnum.DISCOVERY_DETAILS.nNodeStatus.name()));
		detailsVO.setnStatus(rs.getInt(PortalDBEnum.DISCOVERY_DETAILS.nStatus.name()));
		detailsVO.setsChatOutputChannel(rs.getString(PortalDBEnum.DISCOVERY_DETAILS.sChatOutputChannel.name()));
		detailsVO.setsChatSubscriptionChannel(rs.getString(PortalDBEnum.DISCOVERY_DETAILS.sChatSubscriptionChannel.name()));
		detailsVO.setsIPAddress(rs.getString(PortalDBEnum.DISCOVERY_DETAILS.sIPAddress.name()));
		detailsVO.setsLocalIPAddress(rs.getString(PortalDBEnum.DISCOVERY_DETAILS.sLocalIPAddress.name()));
		detailsVO.setsMasterID(rs.getString(PortalDBEnum.DISCOVERY_DETAILS.sMasterID.name()));
		detailsVO.setsTomcatPort(rs.getString(PortalDBEnum.DISCOVERY_DETAILS.sTomcatPort.name()));
		detailsVO.setsRURLTomcatPort(rs.getString(PortalDBEnum.DISCOVERY_DETAILS.sRURLTomcatPort.name()));
		detailsVO.setsRelayServerID(rs.getString(PortalDBEnum.DISCOVERY_DETAILS.sRelayServerID.name()));
		detailsVO.setsRAddress(rs.getString(PortalDBEnum.DISCOVERY_DETAILS.sRAddress.name()));
		detailsVO.setsNodeCommunicationPort(rs.getString(PortalDBEnum.DISCOVERY_DETAILS.sNodeCommunicationPort.name()));
		detailsVO.setsOpenStackPort(rs.getString(PortalDBEnum.DISCOVERY_DETAILS.sOpenStackPort.name()));
		detailsVO.setsPort1(rs.getString(PortalDBEnum.DISCOVERY_DETAILS.sPort1.name()));
		detailsVO.setsPort2(rs.getString(PortalDBEnum.DISCOVERY_DETAILS.sPort2.name()));
		detailsVO.setsPort3(rs.getString(PortalDBEnum.DISCOVERY_DETAILS.sPort3.name()));
		detailsVO.setsPort4(rs.getString(PortalDBEnum.DISCOVERY_DETAILS.sPort4.name()));
		detailsVO.setsPort5(rs.getString(PortalDBEnum.DISCOVERY_DETAILS.sPort5.name()));
		detailsVO.setsNetworkType(NetworkTypeEnum.GetEnum(rs.getInt(PortalDBEnum.DISCOVERY_DETAILS.sNetworkType.name())));
		detailsVO.setsConnectURL(rs.getString(PortalDBEnum.DISCOVERY_DETAILS.sConnectURL.name()));
		detailsVO.setdHBRdate(rs.getTimestamp(PortalDBEnum.DISCOVERY_DETAILS.dHBRdate.name()).getTime());
		return detailsVO;
	}
}