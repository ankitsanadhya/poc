/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal.engine;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import com.mwp.common.Common;
import com.mwp.common.StringFunctions;
import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.common.constant.ErrorMessage;
import com.mwp.common.enums.Status;
import com.mwp.common.vo.ApplicationPlatformVO;
import com.mwp.common.vo.ApplicationVO;
import com.mwp.common.vo.DeviceVO;
import com.mwp.common.vo.QueryVO;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.common.enums.ResourceType;
import com.mwp.p.dal.ApplicationGroupsDB;
import com.mwp.p.dal.EdgeCoreGroupsDB;
import com.mwp.p.dal.ResourceGroupDB;

/**
 * This class executes all the queries related to table groupapplicationversions.List apps of a group, add, update remove app in a group etc. 
 *
 */
public class GroupsEngine {

	/**
	 * This method give list of application in group.
	 * @param groupId
	 * @return
	 * @throws Exception
	 */
	public List<ApplicationVO> listGroupApp(String groupId) throws SQLException {
		return mListGroupApp(groupId);
	}
	
	/**
	 * This method add application in group add in applicationgroups.
	 * @param appId
	 * @param groupId
	 * @throws Exception
	 */
	public void addAppToGroup(String appId, String groupId) throws SQLException {
		 mAddAppToGroup(appId,groupId);
	}
	
	/**
	 * This method add application in group add in applicationgroups and add versions in applicationgroupversion.
	 * @param appId
	 * @param groupId
	 * @param versionIds
	 * @throws Exception
	 */
	public void addAppToGroup(String appId, String groupId, List<String> versionIds) throws SQLException {
		 mAddAppToGroup(appId,groupId,versionIds);
	}
	
	/**
	 * This method removes application-group relation from applicationgroup.
	 * @param appId
	 * @param groupId
	 * @return
	 */
	public void removeAppFromGroup(String appId, String groupId) throws SQLException {
		 mRemoveAppFromGroup(appId,groupId);
	}
	
	
	/**
	 * This method give list of device in group.
	 * @param groupId
	 * @return
	 * @throws Exception
	 */
	public List<DeviceVO> listGroupEdgeCore(String groupId) throws SQLException {
		return mListGroupEdgeCore(groupId);
	}
	
	/**
	 * This method add device in group add in EdgeCoregroups.
	 * @param deviceId
	 * @param groupId
	 * @throws Exception
	 */
	public void addEdgeCoreToGroup(String deviceId, String groupId) throws SQLException {
		 mAddEdgeCoreToGroup(deviceId, groupId);
	}
	/**
	 * this method add resource in group
	 * @param resourceId
	 * @param groupId
	 * @param resourceType
	 * @throws SQLException
	 */
	public void addResourceToGroup(String resourceId, String groupId, ResourceType resourceType) throws SQLException
	{
		mAddResourceToGroup(resourceId, groupId, resourceType);
	}
	
	/**
	 * this method delete resource from group
	 * @param resourceId
	 * @param groupId
	 * @throws SQLException
	 */
	public void removeResourceFromGroup(String resourceId, String groupId) throws SQLException {
		 mRemoveResourceFromGroup(resourceId, groupId);
	}
	
	/**
	 * this method delete multiple resources from group
	 * @param resourceIds
	 * @param groupId
	 * @throws SQLException
	 */
	public void removeResourceFromGroup(List<String> resourceIds, String groupId) throws SQLException {
		 mRemoveResourceFromGroup(resourceIds, groupId);
	}
	/**
	 * This method removes device-group relation from edgecoreGroup.
	 * @param appId
	 * @param groupId
	 * @return
	 */
	public void removeEdgeCoreFromGroup(String deviceId, String groupId) throws SQLException {
		 mRemoveEdgeCoreFromGroup(deviceId, groupId);
	}
	
	public void deleteGroupResources(String groupId,String filter)throws SQLException
	{
		mDeleteGroupResources(groupId,filter);
	}
	
	/**
	 * update application-version relation add/delete applicationversion entry according to versionIds HashMap of (String-boolean),
	 * which have versionId in key and true/false means (ADD/DELETE) boolean in value.
	 * @param appId
	 * @param groupId
	 * @param versionIdsWithOperation
	 * @throws Exception
	 */
	public void updateGroupVersion(String appId, String groupId, Map<String,Boolean> versionIdsWithOperation) throws SQLException {
		 mUpdateGroupVersion(appId,groupId,versionIdsWithOperation);
	}
	
	private List<ApplicationVO> mListGroupApp(String groupId) throws SQLException {
		List<ApplicationVO> listApps = new ArrayList<>();
		ApplicationGroupsDB groupsDB = new ApplicationGroupsDB();

		String sql = groupsDB.listGroupApp();
		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(groupId).build();

		HashMap<String, ApplicationVO> hashApplication = new HashMap<>();
		List<String> listAppPlatform = new ArrayList<>();
		String appId = "";
		ApplicationsEngine apEngine = new ApplicationsEngine();
		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				appId = rs.getString(PortalDBEnum.APPLICATION.appId.name());
				if (!StringFunctions.isNullOrWhitespace(appId) && !hashApplication.containsKey(appId)) {
					hashApplication.put(appId, apEngine.setApplicationObject(rs));
				}

				String appPlatformId = rs.getString(PortalDBEnum.APPLICATION_PLATFORM.appPlatformId.name());
				if (!listAppPlatform.contains(appPlatformId)) {
					/*
					 * create ApplicationPlatformVO new object set values and
					 * ADD in hashAppPlatform.
					 */
					ApplicationPlatformVO platformVO = new ApplicationPlatformVO();
					platformVO.setAppId(rs.getString(PortalDBEnum.APPLICATION.appId.name()));
					platformVO.setAppPlatformId(appPlatformId);
					platformVO.setPlatformId(rs.getString(PortalDBEnum.APPLICATION_PLATFORM.platformId.name()));
					platformVO.setRepositoryName(rs.getString(PortalDBEnum.APPLICATION_PLATFORM.repositoryName.name()));
					hashApplication.get(appId).getPlatFormList().add(platformVO);
				}
			}
		}
		listApps.addAll(hashApplication.values());
		return listApps;
	}
	
	private List<DeviceVO> mListGroupEdgeCore(String groupId) throws SQLException 
	{
		List<DeviceVO> listDevices = new ArrayList<>();
		EdgeCoreGroupsDB groupsDB = new EdgeCoreGroupsDB();

		String sql = groupsDB.listGroupEdgeCore();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(groupId).addParameter(Status.DELETED.ordinal()).build();

		DevicesEngine deviceEngine = new DevicesEngine();
		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {

			listDevices = deviceEngine.setDeviceObjectList(rs, true, false, true, false, false, null);

		}
		return listDevices;
	}
	
	
	private void mAddAppToGroup(String appId, String groupId) throws SQLException {
		ApplicationGroupsDB groupsDB = new ApplicationGroupsDB();
		/*
		 * before add we check relation of group-application already exist in db
		 * or not, if exist then we throw exception on UI.
		 */
		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
						.appendQuery(new ApplicationGroupsDB().getGroupAppId()).addParameter(appId)
						.addParameter(groupId).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			if (rs.next()) {
				throw new SQLException(ErrorMessage.GROUP_APPLICATION_EXIST);
			} else {
				/*
				 * if entry not exist then add group-application relation in db.
				 */
				String sql = groupsDB.addAppToGroup();
				
				 queryVO = new SqlQueryBuilder(
							PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
									.appendQuery(sql)
									.addParameter(Common.getRandomId())
									.addParameter(groupId)
									.addParameter(appId).build();
				
				int result = PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
				if (result <= 0) {
					throw new SQLException(ErrorMessage.GROUP_APPLICATION_ADD_FAILED);
				}
			}
		}
	}
	
	private void mAddAppToGroup(String appId, String groupId, List<String> versionIds) throws SQLException {
		ApplicationGroupsDB groupsDB = new ApplicationGroupsDB();
		/*
		 * before add we check relation of group-application already exist in db or not,
		 * if exist then we throw exception on UI.
		 */
		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
						.appendQuery(new ApplicationGroupsDB().getGroupAppId()).addParameter(appId)
						.addParameter(groupId).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			if(rs.next()){
				throw new SQLException(ErrorMessage.GROUP_APPLICATION_EXIST);
			}
		}
		/*
		 * if entry not exist then add group-application relation in db,
		 * also add application-group-version relation in group_application_versions
		 */
		List<QueryVO> queryVOs = new LinkedList<>();
		
		List<String> queries = groupsDB.addAppToGroupWithVersion();
		
		String groupAppId = Common.getRandomId();
		QueryVO addGroupQueryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
						.appendQuery(queries.get(0))
						.addParameter(groupAppId)
						.addParameter(groupId)
						.addParameter(appId)
						.build();
		queryVOs.add(addGroupQueryVO);
		
		for (String versionId : versionIds) {
			QueryVO addGroupVersionQueryVO = new SqlQueryBuilder(
					PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
							.appendQuery(queries.get(1))
							.addParameter(Common.getRandomId())
							.addParameter(groupAppId)
							.addParameter(versionId)
							.build();
			queryVOs.add(addGroupVersionQueryVO);
		}
		
		PortalDatabaseEngine.getInstance().getConnection().executeUpdatesInTransaction(queryVOs);
	}
	
	private void mAddEdgeCoreToGroup(String deviceId, String groupId) throws SQLException
	{
		EdgeCoreGroupsDB groupsDB = new EdgeCoreGroupsDB();
		/*
		 * before add we check relation of group-device already exist in db or
		 * not, if exist then we throw exception on UI.
		 */
		String sql = groupsDB.getGroupEdgeCoreId();
		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(deviceId).addParameter(groupId).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			if (rs.next()) {
				throw new SQLException(ErrorMessage.GROUP_EDGECORE_EXIST);
			} else {
				/*
				 * if entry not exist then add group-device relation in db.
				 */
				sql = groupsDB.addEdgeCoreToGroup();
				queryVO = new SqlQueryBuilder(
						PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
								.addParameter(Common.getRandomId()).addParameter(groupId).addParameter(deviceId)
								.build();

				int result = PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
				if (result <= 0) {
					throw new SQLException(ErrorMessage.GROUP_EDGECORE_ADD_FAILED);
				}
			}
		}
	}
	
	private void mAddResourceToGroup(String resourceId, String groupId, ResourceType resourceType) throws SQLException {
		ResourceGroupDB groupsDB = new ResourceGroupDB();
		/*
		 * before add we check relation of group-resource already exist in db or
		 * not, if exist then we throw exception on UI.
		 */
		String sql = groupsDB.getGroupResourceId();
		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(groupId).addParameter(resourceId).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			if (rs.next()) {
				throw new SQLException(ErrorMessage.GROUP_EDGECORE_EXIST);
			} else {
				/*
				 * if entry not exist then add group-resource relation in db.
				 */
				sql = groupsDB.addResourceToGroup();
				queryVO = new SqlQueryBuilder(
						PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
								.addParameter(Common.getRandomId()).addParameter(groupId).addParameter(resourceId)
								.addParameter(resourceType.ordinal()).build();
				int result = PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
				if (result <= 0) {
					throw new SQLException(ErrorMessage.GROUP_EDGECORE_ADD_FAILED);
				}
			}
		}
	}
	
	private void mRemoveAppFromGroup(String appId, String groupId) throws SQLException {
		ApplicationGroupsDB groupsDB = new ApplicationGroupsDB();
		List<String> queries = groupsDB.removeAppFromGroup(appId);
		
		List<QueryVO> queryVOs = new LinkedList<>();
		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
						.appendQuery(queries.get(0)).addParameter(groupId)
						.addParameter(appId).build();
		queryVOs.add(queryVO);
		
		queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
						.appendQuery(queries.get(1)).addParameter(groupId)
						.addParameter(appId).build();
		queryVOs.add(queryVO);
		
		PortalDatabaseEngine.getInstance().getConnection().executeUpdatesInTransaction(queryVOs);
	}
	
	
	private void mRemoveEdgeCoreFromGroup(String deviceId, String groupId) throws SQLException {
		EdgeCoreGroupsDB groupsDB = new EdgeCoreGroupsDB();
		String query = groupsDB.removeEdgeCoreFromGroup(deviceId);
		
		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
						.appendQuery(query).addParameter(groupId)
						.addParameter(deviceId).build();
		
		PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
	}

	private void mRemoveResourceFromGroup(String resourceId, String groupId) throws SQLException {
		ResourceGroupDB resourceGroupsDB = new ResourceGroupDB();
		String sql = resourceGroupsDB.removeResourceFromGroup(resourceId);
		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(sql).addParameter(groupId)
				.addParameter(resourceId)
				.build();
		PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
	}

	private void mRemoveResourceFromGroup(List<String> resourceIds, String groupId) throws SQLException {
		ResourceGroupDB resourceGroupsDB = new ResourceGroupDB();
		String query = resourceGroupsDB.removeResourceFromGroup(resourceIds);
		
		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(query).addParameter(groupId)
				.addParameters(resourceIds)
				.build();
		
		PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
	}
	
	private void mUpdateGroupVersion(String appId, String groupId, Map<String, Boolean> versionIdsWithOperation)
			throws SQLException {
		ApplicationGroupsDB groupsDB = new ApplicationGroupsDB();
		String groupAppId = null;
		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
						.appendQuery(new ApplicationGroupsDB().getGroupAppId()).addParameter(appId)
						.addParameter(groupId).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				groupAppId = rs.getString(PortalDBEnum.GROUP_APPLICATIONS.groupAppId.name());
			}
		}

		if (groupAppId != null) {
			List<String> addVersionIds = new ArrayList<>();
			List<String> deleteVersionIds = new ArrayList<>();
			for (Map.Entry<String, Boolean> entry : versionIdsWithOperation.entrySet()) {
				if (entry.getValue().booleanValue()) {
					addVersionIds.add(entry.getKey());
				} else {
					deleteVersionIds.add(entry.getKey());
				}
			}

			List<String> queries = groupsDB.updateGroupVersion(deleteVersionIds);

			List<QueryVO> queryVOs = new LinkedList<>();

			if (!deleteVersionIds.isEmpty()) {
				QueryVO addGroupQueryVO = new SqlQueryBuilder(
						PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
								.appendQuery(queries.get(0)).addParameters(deleteVersionIds).addParameter(groupAppId)
								.build();
				queryVOs.add(addGroupQueryVO);
			}
			
			for (String versionId : addVersionIds) {
				QueryVO addGroupVersionQueryVO = new SqlQueryBuilder(
						PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
								.appendQuery(queries.get(1)).addParameter(Common.getRandomId()).addParameter(groupAppId)
								.addParameter(versionId).build();
				queryVOs.add(addGroupVersionQueryVO);
			}

			PortalDatabaseEngine.getInstance().getConnection().executeUpdatesInTransaction(queryVOs);
		}else{
			throw new SQLException("group application not found.");
		}
	}
	
	private void mDeleteGroupResources(String groupId, String filter)throws SQLException
	{
		List<QueryVO> queries = new ArrayList<>();
		QueryVO queryVO = null;
		switch (filter) {
		case "appliances":
			EdgeCoreGroupsDB deviceGroupsDB = new EdgeCoreGroupsDB();
			String query = deviceGroupsDB.removeEdgeCoreFromGroup("");
			queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
					.appendQuery(query).addParameter(groupId).build();
			queries.add(queryVO);
			break;
		case "users":
			ApplicationGroupsDB appGroupsDB = new ApplicationGroupsDB();
			List<String> subQueries = appGroupsDB.removeAppFromGroup("");

			queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
					.appendQuery(subQueries.get(0)).addParameter(groupId).build();
			queries.add(queryVO);

			queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
					.appendQuery(subQueries.get(1)).addParameter(groupId).build();
			queries.add(queryVO);
			break;
		case "resources":
			ResourceGroupDB resourceGroupsDB = new ResourceGroupDB();
			String sql = resourceGroupsDB.removeResourceFromGroup("");
			queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
					.appendQuery(sql).addParameter(groupId).build();
			queries.add(queryVO);
			break;

		default:
			break;
		}

		if (!queries.isEmpty())
			PortalDatabaseEngine.getInstance().getConnection().executeUpdatesInTransaction(queries);
	}
}
