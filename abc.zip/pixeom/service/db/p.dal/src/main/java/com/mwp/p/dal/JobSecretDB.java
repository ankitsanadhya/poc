/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.mwp.p.dal;

import com.mwp.db.Interface.IConnection;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.common.enums.PortalDBEnum.JOB_SECRET;
import com.mwp.p.dal.engine.PortalDatabaseEngine;

public class JobSecretDB {

	private IConnection dbCon= null;
	private String table;
	StringBuilder colList;

	//	jobSecretId,
	//	appSecretId,
	//	edgeCoreId,	
	//	jobId, 
	//	createdDate,
	//	modifiedDate
	public JobSecretDB()
	{
		//set database connection object.
		dbCon = PortalDatabaseEngine.getInstance().getConnection();
		table = PortalDBEnum.TABLE_NAMES.jobSecret.name();
		colList= new StringBuilder(JOB_SECRET.jobSecretId.name());
		colList.append(", "	);			
		colList.append( JOB_SECRET.appSecretVersionId.name() );
		colList.append( ", ");
		colList.append(JOB_SECRET.edgeCoreId.name()); 
		colList.append( ", ");
		colList.append( JOB_SECRET.jobId.name());
		colList.append( " ,");
		colList.append( JOB_SECRET.serviceName.name());
		colList.append( " ,");
		colList.append( JOB_SECRET.createdDate.name());
		colList.append( ", ");
		colList.append(JOB_SECRET.modifiedDate.name());
	}

	public String insert()
	{
		StringBuilder qry= new StringBuilder("INSERT INTO ");
		qry.append(table);
		qry.append( "(");
		qry.append( colList); 
		qry.append( ") VALUES (");	    
		qry.append("?");
		qry.append( ","	);   
		qry.append("?");
		qry.append( ",");
		qry.append("?");
		qry.append( ",");
		qry.append("?");
		qry.append( ",");
		qry.append("?");
		qry.append( ",");
		qry.append( "NOW()");
		qry.append( ",");
		qry.append( "NOW()");
		qry.append( ")");
		return qry.toString();

		//		qry.append( dbCon.formatString(jobSecretId));
		//		qry.append( ","	);   
		//		qry.append( dbCon.formatString(appSecretId));
		//		qry.append( ",");
		//		qry.append( dbCon.formatString(edgeCoreId));
		//		qry.append( ",");
		//		qry.append( dbCon.formatString(jobId));
		//		qry.append( ",");
		//		qry.append( dbCon.formatString(serviceName));
		//		qry.append( ",");
		//		qry.append( "NOW()");
		//		qry.append( ",");
		//		qry.append( "NOW()");
		//		qry.append( ")");
	}
//
//	public String list(String jobId, String edgeCoreId)
//	{
//		StringBuilder qry= new StringBuilder("SELECT ");
//		qry.append(colList);
//		qry.append(" FROM ");
//		qry.append(table );
//		qry.append(" WHERE " );
//		qry.append( JOB_SECRET.jobId.name());
//		qry.append( " = ");
//		qry.append(dbCon.formatString(jobId));
//		qry.append(" AND " );
//		qry.append( JOB_SECRET.edgeCoreId.name());
//		qry.append( " = ");
//		qry.append(dbCon.formatString(edgeCoreId));
//		return qry.toString();
//	}
	//	public String insertMulti(List<SecretVo> lstSecretVo, String edgeCoreId, String jobId)
	//	{
	//
	//		StringBuilder qry= new StringBuilder("INSERT INTO ");
	//		qry.append(table);
	//		qry.append( "(");
	//		qry.append( colList); 
	//		qry.append( ") VALUES ");
	//		for (SecretVo secretVo : lstSecretVo)
	//		{
	//			qry.append("(");	    
	//			qry.append( dbCon.formatString(Common.getRandomId()));
	//			qry.append( ","	);   
	//			qry.append( dbCon.formatString(secretVo.getListSecretVersion().get(0).getAppSecretVersionId()));
	//			qry.append( ",");
	//			qry.append( dbCon.formatString(edgeCoreId));
	//			qry.append( ",");
	//			qry.append( dbCon.formatString(jobId));
	//			qry.append( ",");
	//			qry.append( dbCon.formatString(secretVo.getServiceName()));
	//			qry.append( ",");
	//			qry.append( "NOW()");
	//			qry.append( ",");
	//			qry.append( "NOW()");
	//			qry.append( ")");
	//			
	//			qry.append( ","	);   
	//		}
	//		String insertQry =qry.toString();
	//		
	//		return insertQry.substring(0, insertQry.lastIndexOf(","));
	//	}

	public String insertMulti()
	{

		StringBuilder qry = new StringBuilder("INSERT INTO ");
		qry.append(table);
		qry.append("(");
		qry.append(colList);
		qry.append(") VALUES ");
		// for (int i = 0; i < lstSecretVo.size(); i++) {
		qry.append("(");
		qry.append("?");
		qry.append(",");
		qry.append("?");
		qry.append(",");
		qry.append("?");
		qry.append(",");
		qry.append("?");
		qry.append(",");
		qry.append("?");
		qry.append(",");
		qry.append("NOW()");
		qry.append(",");
		qry.append("NOW()");
		qry.append(")");

		// qry.append( "," );
		// }
		//String insertQry = qry.toString();

		return qry.toString();
	}
}
