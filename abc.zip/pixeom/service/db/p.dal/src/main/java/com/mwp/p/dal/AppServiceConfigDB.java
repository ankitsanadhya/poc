/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal;

import com.mwp.db.Interface.IConnection;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.common.enums.PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS;
import com.mwp.p.dal.engine.PortalDatabaseEngine;

/**
 * This class creates queries related to table {@link APPLICATION_SERVICE_ENDPOINTS} 
 */
public class AppServiceConfigDB {

	private IConnection dbCon= null;
	public AppServiceConfigDB() {
		//set database connection object.
		dbCon = PortalDatabaseEngine.getInstance().getConnection();
	}

	/**
	 * Create query to check if service endpoints with endpointName available for any other application then appId   
	 * @param appId
	 * @param endpointName
	 * @return
	 */
	public String checkServiceEndpointAvailable() {
		return mCheckServiceEndpointAvailable();
	}

	/**
	 * Create query to get service endpoint for application id
	 * @param appId
	 * @param endpointName
	 * @return
	 */
	public String getServiceEndpoint() {
		return mGetServiceEndpoint();
	}

	/**
	 * Query to add service endpoint for an application.It set endpoint id if not set from outside.
	 * @param serviceEndpoint
	 * @return
	 */
	public String reserveServiceEndpoint() {
		return mReserveServiceEndpoint();
	}

	
	public String getServiceEndpoint(String appId) {
		return mGetServiceEndpoint(appId);
	}

	private String mCheckServiceEndpointAvailable() {
		StringBuilder sb = new StringBuilder();

		//Check is Available, IF(case, true condition, false condition)
		sb.append("SELECT IF (COUNT(appServiceEndpointId) = 0,1,0) AS isAvailable FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.applicationserviceendpoints);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.appId); sb.append(" <> "); sb.append("?");
		sb.append(" AND ");
		//Compare lower case because, save value as it is into the DB but while comparing we check for URL path that is case insensitive.   
		sb.append(" LOWER("); sb.append(PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.serviceName); sb.append(") "); 
		sb.append(" = "); 
		sb.append(" LOWER("); sb.append("?"); sb.append(") "); 

		return sb.toString();
	}

	private String mGetServiceEndpoint() {
		StringBuilder sb = new StringBuilder();

		//Check is Available, IF(case, true condition, false condition)
		sb.append("SELECT * FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.applicationserviceendpoints);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.appId); sb.append(" = "); sb.append("?");
		sb.append(" AND ");
		//Compare lower case because, save value as it is into the DB but while comparing we check for URL path that is case insensitive.   
		sb.append(" LOWER("); sb.append(PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.serviceName); sb.append(") "); 
		sb.append(" = "); 
		sb.append(" LOWER("); sb.append("?"); sb.append(") "); 

		return sb.toString();
	}

	private String mReserveServiceEndpoint() {
		return getQueryForAddServiceEndpoint();
	}

	private String mGetServiceEndpoint(String appId) {
		return getQueryForAppSerEndpoint(appId);
	}

	private String getQueryForAddServiceEndpoint(){
		StringBuilder sb = new StringBuilder();
		sb.append("INSERT INTO ");
		sb.append(PortalDBEnum.TABLE_NAMES.applicationserviceendpoints);
		sb.append(" ( ");
		sb.append(PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.appServiceEndpointId.name());
		sb.append(", ");
		sb.append(PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.appId.name());
		sb.append(", ");
		sb.append(PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.appVersionId.name());
		sb.append(", ");
		sb.append(PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.platformId.name());
		sb.append(", ");
		sb.append(PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.serviceName.name());
		sb.append(", ");
		sb.append(PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.protocol.name());
		sb.append(", ");
		sb.append(PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.containerPort.name());
		sb.append(", ");
		sb.append(PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.imageName.name());
		sb.append(", ");
		sb.append(PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.customHeaders.name());
		sb.append(" ) VALUES ( ");
		sb.append("?");
		//sb.append(dbCon.formatString(Common.getRandomId()));
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(serviceEndpoint.getAppId()));
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(""));
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(serviceEndpoint.getPlatformId()));
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(serviceEndpoint.getServiceName()));
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(serviceEndpoint.getProtocol()));
		sb.append(", ");
		sb.append("?");
//		sb.append(serviceEndpoint.getContainerPort());
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(serviceEndpoint.getImageName()));
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(serviceEndpoint.getCustomHeaders()));
		sb.append(" ) ");
		return sb.toString();
	}

	/**
	 * create query to delete application service endpoints where application versionId is empty 
	 * @param appId
	 * @return
	 */
	public String getQueryForDeleteSerEndpointConfigEmpty(){
		StringBuilder sb = new StringBuilder();
		sb.append("DELETE FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.applicationserviceendpoints);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.appId.name());
		sb.append(" = ");
		sb.append("?");
		//sb.append(dbCon.formatString(appId));
		sb.append(" AND ");
		sb.append(PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.appVersionId.name());
		sb.append(" = ");
		sb.append("?");
		//sb.append(dbCon.formatString(""));
		return sb.toString();
	}

	private String getQueryForAppSerEndpoint(String appId){
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT * FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.applicationserviceendpoints);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.appId.name());
		sb.append(" = ");
		sb.append("?");
//		sb.append(dbCon.formatString(appId));
		return sb.toString();
	}
}
