/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.mwp.p.dal;

import com.mwp.common.enums.TokenEnum.TOKENSTATUS;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.common.enums.PortalDBEnum.SUPPORTTOKENS;

public class TokenDB {


	private String table;
	StringBuilder colList;

	public TokenDB() {
		table = PortalDBEnum.TABLE_NAMES.supportTokens.name();
		colList= new StringBuilder(SUPPORTTOKENS.supportTokenId.name());
		colList.append(", "	);			
		colList.append( SUPPORTTOKENS.nodeId.name() );
		colList.append(", "	);			
		colList.append( SUPPORTTOKENS.email.name() );
		colList.append( ", ");
		colList.append(SUPPORTTOKENS.hostName.name()); 
		colList.append( ", ");
		colList.append( SUPPORTTOKENS.expiryTime.name());
		colList.append( " ,");
		colList.append( SUPPORTTOKENS.userId.name());
		colList.append( " ,");
		colList.append( SUPPORTTOKENS.token.name());
		colList.append( " ,");
		colList.append( SUPPORTTOKENS.status.name());
		colList.append( " ,");
		colList.append( SUPPORTTOKENS.createdon.name());
		colList.append( ", ");
		colList.append(SUPPORTTOKENS.modifiedon.name());
	}

	/**
	 * get supporttoken details from hostname and email
	 * @param hostName
	 * @param email
	 * @return
	 */
	public String getTokenDetails() {
		return mGetTokenDetails();
	}	

	private String mGetTokenDetails() {
		StringBuilder sb = new StringBuilder();
		sb.append("Select * ")
		.append(" FROM ")
		.append(PortalDBEnum.TABLE_NAMES.supportTokens)
		.append(" WHERE ")
		.append(SUPPORTTOKENS.email)
		.append(" = ");
		sb.append("?")
		//sb.append(dbCon.formatString(StringEncryptionDecryption.encrypt(email,new CredProvider().getEcnKey())))
		.append(" and ")
		.append(SUPPORTTOKENS.hostName)
		.append(" = ");
		sb.append("?")
		//sb.append(dbCon.formatString(hostname))
		.append(" and ")		
		.append(SUPPORTTOKENS.status)
		.append(" IN ")
		.append(" ( ")
		.append( TOKENSTATUS.ENABLED.ordinal() )
		.append("," )
		.append( TOKENSTATUS.NEW.ordinal() )		
		.append(" ) ");		
		return sb.toString();
	}

	/**
	 * Get support token details from hostname
	 * @param hostName
	 * @return
	 */	
//	public String getTokenDetailsFromHostName(String hostName) {
//		StringBuilder sb = new StringBuilder();
//		sb.append("Select * ");
//		sb.append(" FROM ");
//		sb.append(PortalDBEnum.TABLE_NAMES.supportTokens);
//		sb.append(" WHERE ");
//		sb.append(SUPPORTTOKENS.hostName);
//		sb.append(" = ");sb.append(dbCon.formatString(hostName));
//		return sb.toString();
//	}
	
	
	/**
	 * Get supporttoken details from nodeId
	 * @param hostName
	 * @return
	 */
	
	public String getTokenDetailsFromNodeId() {
		StringBuilder sb = new StringBuilder();
		sb.append("Select * ")
		.append(" FROM ")
		.append(PortalDBEnum.TABLE_NAMES.supportTokens)
		.append(" WHERE ")
		.append(SUPPORTTOKENS.nodeId)
		.append(" = ");
		sb.append("?")		
		.append(" and ")	
		.append(SUPPORTTOKENS.status)
		.append(" IN ")
		.append(" ( ")
		.append( TOKENSTATUS.ENABLED.ordinal() )
		.append("," )
		.append( TOKENSTATUS.NEW.ordinal() )		
		.append(" )" );
		return sb.toString();
	}
	
	/**
	 * Get supporttoken details from token
	 * @param hostName
	 * @return
	 */
	
	public String getTokenDetailsByToken() {
		StringBuilder sb = new StringBuilder();
		sb.append("Select * ")
		.append(" FROM ")
		.append(PortalDBEnum.TABLE_NAMES.supportTokens)
		.append(" WHERE ")
		.append(SUPPORTTOKENS.token)
		.append(" = ");
		sb.append("?")
		//sb.append(dbCon.formatString(token))		
		.append(" and ")	
		.append(SUPPORTTOKENS.status)
		.append(" IN ")
		.append(" ( ")
		.append( TOKENSTATUS.ENABLED.ordinal() )
		.append("," )
		.append( TOKENSTATUS.NEW.ordinal() )		
		.append(" )" );
		return sb.toString();
	}

	/**
	 * Check token is valid.
	 * @param token
	 * @return
	 */
	
	public String checkValidToken() {
		StringBuilder sb = new StringBuilder();
		sb.append("Select * ")
		.append(" FROM ")
		.append(PortalDBEnum.TABLE_NAMES.supportTokens)
		.append(" WHERE ")
		.append(SUPPORTTOKENS.token)
		.append(" = ");
		sb.append("?")
//		sb.append(dbCon.formatString(token))		
		.append(" and ")	
		.append(SUPPORTTOKENS.status)
		.append(" IN ")
		.append(" ( ")
		.append( TOKENSTATUS.ENABLED.ordinal() )
		.append("," )
		.append( TOKENSTATUS.NEW.ordinal() )		
		.append(" )" );
		return sb.toString();
	}


	/**
	 * insert supporttoken details
	 * @param id
	 * @param token
	 * @param nodeId
	 * @param hostName
	 * @param email
	 * @param userId
	 * @param expiryTime
	 * @return
	 */
	public String insert()
	{
		StringBuilder qry= new StringBuilder("INSERT INTO ");
		qry.append(table);
		qry.append( "(");
		qry.append( colList); 
		qry.append( ") VALUES (");
		qry.append("?");
		//qry.append( dbCon.formatString(id));
		qry.append( ","	);   
		qry.append("?");
		//qry.append( dbCon.formatString(nodeId));
		qry.append( ",");
		qry.append("?");
		//qry.append( dbCon.formatString(StringEncryptionDecryption.encrypt(email,new CredProvider().getEcnKey())));
		qry.append( ",");
		qry.append("?");
		//qry.append( dbCon.formatString(hostName));		
		qry.append( ",");
		qry.append("?");
		//qry.append(expiryTime);
		qry.append( ",");
		qry.append("?");
		//qry.append( dbCon.formatString(userId));
		qry.append( ","	);
		qry.append("?");
		//qry.append( dbCon.formatString(token));
		qry.append( ","	);
		qry.append("?");
		//qry.append( TOKENSTATUS.NEW.ordinal());		
		qry.append( ",");
		qry.append( "NOW()");
		qry.append( ",");
		qry.append( "NOW()");
		qry.append( ")");
		return qry.toString();		
	}	

	/**
	 * Update support token status using supportToken
	 * @param email
	 * @param supportToken
	 * @return
	 */
	public String updateTokenStatus() {
		StringBuilder sb = new StringBuilder();

		sb.append("UPDATE ");
		sb.append(PortalDBEnum.TABLE_NAMES.supportTokens).append(" SET ").append(PortalDBEnum.SUPPORTTOKENS.status);
		sb.append(" = ");
		sb.append("?").append(" WHERE ").append(PortalDBEnum.SUPPORTTOKENS.token);
		sb.append(" = ");
		sb.append("?");
		// sb.append(dbCon.formatString(supportToken));

		return sb.toString();
	}
	
	/**
	 * Delete support token details from token.
	 * @param supportToken
	 * @return
	 */
	public String deleteTokenDetails(){
		StringBuilder sb = new StringBuilder();

		sb.append(" DELETE ")
		.append(" FROM ")
		.append(PortalDBEnum.TABLE_NAMES.supportTokens)		
		.append(" WHERE ")
		.append(PortalDBEnum.SUPPORTTOKENS.token)
		.append(" = ")
		.append("?");
		//.append(dbCon.formatString(supportToken));

		return sb.toString();
	}
	
	
}
