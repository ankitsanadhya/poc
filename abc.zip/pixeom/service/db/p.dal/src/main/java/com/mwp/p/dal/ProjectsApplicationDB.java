/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal;

import java.util.ArrayList;
import java.util.List;

import com.mwp.common.enums.Status;
import com.mwp.db.Interface.IConnection;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.common.enums.PortalDBEnum.PROJECT;
import com.mwp.p.dal.engine.PortalDatabaseEngine;

/**
 * This class create queries related to table {@link PROJECT}
 *
 */
public class ProjectsApplicationDB {

	private IConnection dbCon= null;

	public ProjectsApplicationDB() {
		dbCon = PortalDatabaseEngine.getInstance().getConnection();
	}

	/**
	 * Update project status as DELETED in project table and update application status as DELETE in application table.  
	 * @param projectId
	 * @param userId
	 * @return
	 */
	public List<String> deletetProject() {
		return mDeletetProject();
	}

	/**
	 * Create query to mark project status as deleted and application appStatus.
	 * @param projectId
	 * @param userId
	 * @return
	 */
	private List<String> mDeletetProject() {
		List<String> listQuery = new ArrayList<>();
		StringBuilder sb = new StringBuilder();
		sb.append("UPDATE ");
		sb.append(PortalDBEnum.TABLE_NAMES.project);
		sb.append(" SET ");

		sb.append(PortalDBEnum.PROJECT.projectStatus.name());
		sb.append(" = ");
		sb.append(Status.DELETED.ordinal());
		sb.append(", ");

		sb.append(PortalDBEnum.PROJECT.modifiedDate.name());
		sb.append(" = NOW()");

		sb.append(" WHERE ");
		sb.append(PortalDBEnum.PROJECT.projectId.name());
		sb.append(" = ");
		sb.append("?");
		//sb.append(dbCon.formatString(projectId));
		sb.append(" AND ");
		sb.append(PortalDBEnum.PROJECT.userId.name());
		sb.append(" = ");
		sb.append("?");
		//sb.append(dbCon.formatString(userId));
		listQuery.add(sb.toString());

		listQuery.add(mDeleteApplicationOfProject());
		return listQuery;
	}

	/**
	 * Update application set app status as deleted
	 * @param projectId
	 * @param userId
	 * @return
	 */
	private String mDeleteApplicationOfProject() {
		StringBuilder sb = new StringBuilder();
		sb.append("UPDATE ");
		sb.append(PortalDBEnum.TABLE_NAMES.application);
		sb.append(" SET ");

		sb.append(PortalDBEnum.APPLICATION.appStatus.name());
		sb.append(" = ");
		sb.append(Status.DELETED.ordinal());
		sb.append(", ");

		sb.append(PortalDBEnum.APPLICATION.modifiedDate.name());
		sb.append(" = NOW()");

		sb.append(" WHERE ");
		sb.append(PortalDBEnum.APPLICATION.projectId.name());
		sb.append(" = ");
		sb.append("?");
//		sb.append(dbCon.formatString(projectId));
		sb.append(" AND ");
		sb.append(PortalDBEnum.APPLICATION.userId.name());
		sb.append(" = ");
		sb.append("?");
//		sb.append(dbCon.formatString(userId));
		return sb.toString();
	}

}
