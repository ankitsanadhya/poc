/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.mwp.p.dal.engine;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.EnumMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.common.vo.QueryVO;
import com.mwp.p.common.enums.PortalDBEnum.SETTINGS;
import com.mwp.p.common.enums.PortalDBEnum.SETTINGS_KEY;
import com.mwp.p.dal.SettingsDB;

public class SettingsEngine {
	/**
	 * This method for getting setting value using param key
	 * {@link SETTINGS_KEY}
	 * 
	 * @param key
	 * @return setting timer value.
	 * @throws SQLException
	 */
	public String getSettingValue(SETTINGS_KEY key) throws SQLException {
		return mGetSettingValue(key);
	}

	/**
	 * This method for set timer value of given setting key
	 * {@link SETTINGS_KEY}.
	 * 
	 * @param key
	 * @param value
	 * @throws SQLException
	 * @throws Exception
	 */
	public void setSettingsValue(SETTINGS_KEY key, String value) throws SQLException {
		mSetSettingsValue(key, value);
	}

	public void setSettingsValus(Map<SETTINGS_KEY, String> settings) throws SQLException {
		mSetSettingsValues(settings);
	}

	/**
	 * This method for get settings and their values.
	 * 
	 * @return hashtable of settingKeys and Value {@link SETTINGS_KEY}.
	 * @throws SQLException
	 */
	public Map<SETTINGS_KEY, String> getSettings() throws SQLException {
		return mSettings();
	}

	private Map<SETTINGS_KEY, String> mSettings() throws SQLException {
		EnumMap<SETTINGS_KEY, String> ht = new EnumMap<>(SETTINGS_KEY.class);
		String sql = new SettingsDB().getSettings();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				SETTINGS_KEY keyenum = SETTINGS_KEY.valueOf(rs.getString(SETTINGS.settingsKey.name()));
				String value = rs.getString(SETTINGS.settingsValue.name());
				ht.put(keyenum, value);
			}
		}
		return ht;
	}

	private String mGetSettingValue(SETTINGS_KEY key) throws SQLException {
		String sql = new SettingsDB().getSettingValue();

		String retVAl = "";
		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(key.name()).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				retVAl = rs.getString(SETTINGS.settingsValue.name());
			}
		}
		return retVAl;
	}

	private void mSetSettingsValue(SETTINGS_KEY key, String value) throws SQLException {
		String sql = new SettingsDB().setSettingsValue();
		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(key.name()).addParameter(value).addParameter(value).build();

		PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
	}

	private void mSetSettingsValues(Map<SETTINGS_KEY, String> settings) throws SQLException {
		List<QueryVO> queryVOs = new LinkedList<>();
		
		String sql = new SettingsDB().setSettingsValues();
		
		for (Entry<SETTINGS_KEY, String>  entry: settings.entrySet()) {
			
			QueryVO queryVO = new SqlQueryBuilder(
					PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
							.addParameter(entry.getKey().name()).addParameter(entry.getValue()).addParameter(entry.getValue()).build();
			
			queryVOs.add(queryVO);
		}
		
		PortalDatabaseEngine.getInstance().getConnection().executeUpdatesInTransaction(queryVOs);

	}
}
