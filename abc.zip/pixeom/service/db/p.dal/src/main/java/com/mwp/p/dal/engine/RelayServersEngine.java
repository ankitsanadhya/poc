/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal.engine;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import com.mwp.common.CredProvider;
import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.common.vo.QueryVO;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.common.vo.RelayServerVO;
import com.mwp.p.dal.RelayServerDB;
import com.pa.crypto.StringEncryptionDecryption;

/**
 * THuis class manages relay server queries result.Provides facility to list relay servers, get relay server object  etc
 *
 */
public class RelayServersEngine {

	/**
	 * get relay server address by relay server id
	 * @param relayServerId
	 * @return
	 * @throws SQLException
	 */
	public String getRelayServerAddress(String relayServerId) throws SQLException{
		return mGetRelayServerAddress(relayServerId);
	}

	/**
	 * get distinct relay server information and device count from assignedrelayports.
	 * @return
	 * @throws SQLException
	 */
	public List<RelayServerVO> getDistinctRelayServers() throws SQLException {
		return mGetDistinctRelayServers();
	}

	/**
	 * List all relay servers.
	 * @return  ArrayList<RelayServerVO>
	 * @throws SQLException
	 */
	public List<RelayServerVO> getListRelayServer() throws SQLException {
		return mGetListRelayServer();
	}

	/**
	 * list all relay servers with used and available count
	 * @return
	 * @throws SQLException
	 */
	public List<RelayServerVO> listsAllRelayServer(boolean callByAdmin) throws SQLException
	{
		return mListsAllRelayServer(callByAdmin);
	}

	/**
	 * Check if priority is 1 for relay server.
	 * @param relayServerId
	 * @return
	 * @throws SQLException 
	 */
	public boolean isOnePriority(String relayServerId) throws SQLException 
	{
		return mIsOnePriority(relayServerId);
	}

	public RelayServerVO insertRelayServer(String sRelayServerID, String sRelayServerAddress, String sRelayName,
			int nPortRangeStart, int nPortRangeEnd, String sDeviceLimit, int nStatus, String sRUserName,
			String sRPassword, String sHostKey, int nRPort, int sPriority, boolean callByAdmin) throws Exception {
		return mInsertRelayServer(sRelayServerID, sRelayServerAddress, sRelayName, nPortRangeStart, nPortRangeEnd,
				sDeviceLimit, nStatus, sRUserName, sRPassword, sHostKey, nRPort, sPriority, callByAdmin);
	}
	
	public RelayServerVO updateRelayServer(String sRelayServerID, String sRelayServerAddress, String sRelayName,
			int nStatus, String sRUserName, String sRPassword, String sHostKey, int nRPort, int sPriority,
			boolean callByAdmin) throws SQLException {
		return mUpdateRelayServer(sRelayServerID, sRelayServerAddress, sRelayName, nStatus, sRUserName, sRPassword,
				sHostKey, nRPort, sPriority, callByAdmin);
	}
	
	public void delete(String sRelayServerID) throws SQLException 
	{
		 mDelete(sRelayServerID);
	}

	private List<RelayServerVO> mGetListRelayServer() throws SQLException {
		ArrayList<RelayServerVO> listRelayServer = new ArrayList<>();
		String sql = new RelayServerDB().getListRelayServer();
		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				RelayServerVO relayVO = new RelayServerVO();
				relayVO.setsRelayServerID(rs.getString(PortalDBEnum.RELAY_SERVERS.sRelayServerID.name()));
				relayVO.setsRelayServerAddress(rs.getString(PortalDBEnum.RELAY_SERVERS.sRelayServerAddress.name()));
				relayVO.setsRelayName(rs.getString(PortalDBEnum.RELAY_SERVERS.sRelayName.name()));
				relayVO.setsDeviceLimit(rs.getString(PortalDBEnum.RELAY_SERVERS.sDeviceLimit.name()));
				relayVO.setnPortRangeStart(rs.getInt(PortalDBEnum.RELAY_SERVERS.nPortRangeStart.name()));
				relayVO.setnPortRangeEnd(rs.getInt(PortalDBEnum.RELAY_SERVERS.nPortRangeEnd.name()));
				relayVO.setDeviceCount(rs.getInt("deviceCount"));
				listRelayServer.add(relayVO);
			}
		}
		return listRelayServer;
	}


	private List<RelayServerVO> mGetDistinctRelayServers() throws SQLException {
		List<RelayServerVO> listRelayServer = new ArrayList<>();
		String sql = new RelayServerDB().getDistinctRelayServers();
		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				RelayServerVO relayVO = new RelayServerVO();
				relayVO.setsRelayServerID(rs.getString(PortalDBEnum.RELAY_SERVERS.sRelayServerID.name()));
				relayVO.setsRelayServerAddress(rs.getString(PortalDBEnum.RELAY_SERVERS.sRelayServerAddress.name()));
				relayVO.setsRelayName(rs.getString(PortalDBEnum.RELAY_SERVERS.sRelayName.name()));
				relayVO.setsDeviceLimit(rs.getString(PortalDBEnum.RELAY_SERVERS.sDeviceLimit.name()));
				relayVO.setnPortRangeStart(rs.getInt(PortalDBEnum.RELAY_SERVERS.nPortRangeStart.name()));
				relayVO.setnPortRangeEnd(rs.getInt(PortalDBEnum.RELAY_SERVERS.nPortRangeEnd.name()));
				relayVO.setDeviceCount(rs.getInt("deviceCount"));
				listRelayServer.add(relayVO);
			}
		}
		return listRelayServer;
	}

	private String mGetRelayServerAddress(String relayServerId) throws SQLException {
		String relayServerAddress = "";
		String sql = new RelayServerDB().getRelayServerAddress();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(relayServerId).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				relayServerAddress = rs.getString(PortalDBEnum.RELAY_SERVERS.sRelayServerAddress.name());
			}
		}
		return relayServerAddress;
	}

	private boolean mIsOnePriority(String relayServerId) throws SQLException 
	{
		String sql = new RelayServerDB().isOnePriority();
		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(relayServerId).addParameter(1).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next())
				return true;
		} catch (Exception e) {
			return false;
		}

		return false;
	}
	
	private List<RelayServerVO> mListsAllRelayServer(boolean callByAdmin) throws SQLException
	{
		List<RelayServerVO> listRelayServer = new ArrayList<>();
		String sql = new RelayServerDB().ListAllRelayServer();
		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				RelayServerVO relayVO = setRelayserver(rs, callByAdmin);
				relayVO.setDeviceCount(rs.getInt("deviceCount"));
				int totalRangeCount = (relayVO.getnPortRangeEnd() - relayVO.getnPortRangeStart()) + 1;
				int remainingCount = totalRangeCount - relayVO.getDeviceCount();
				relayVO.setFreePort(remainingCount);
				listRelayServer.add(relayVO);

			}
		}
		return listRelayServer;
	}
	
	private RelayServerVO mGet(String relayServerId, boolean callByAdmin) throws SQLException
	{
		RelayServerVO relayVO = null;
		String sql = new RelayServerDB().getRelayServer();
		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
				.addParameter(relayServerId)
				.build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next())
			{
				 relayVO = setRelayserver(rs, callByAdmin);
			}
		}
		return relayVO;
	}
	
	private boolean mIsExists(String relayServerId) throws SQLException
	{
		String sql = new RelayServerDB().isExists();
		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(relayServerId).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				return true;
			}
		}
		return false;
	}
	
	private RelayServerVO mInsertRelayServer(String sRelayServerID, String sRelayServerAddress, String sRelayName,
			int nPortRangeStart, int nPortRangeEnd, String sDeviceLimit, int nStatus, String sRUserName,
			String sRPassword, String sHostKey, int nRPort, int sPriority, boolean callByAdmin) throws Exception {
		boolean isExists = mIsExists(sRelayServerID);
		if (!isExists) {
			String sql = new RelayServerDB().insertRelayServer();
			QueryVO queryVO = new SqlQueryBuilder(
					PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
							.addParameter(sRelayServerID)
							.addParameter(sRelayServerAddress)
							.addParameter(sRelayName)
							.addParameter(nPortRangeStart)
							.addParameter(nPortRangeEnd)
							.addParameter(sDeviceLimit)
							.addParameter(nStatus)
							.addParameterEncrypted(sRUserName)
							.addParameterEncrypted(sRPassword)
							.addParameterEncrypted(sHostKey)
							.addParameter(nRPort)
							.addParameter(sPriority)
							.build();
			
			PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
			return mGet(sRelayServerID, callByAdmin);
		}
		throw new Exception("Id already exists.");
	}

	private RelayServerVO mUpdateRelayServer(String sRelayServerID, String sRelayServerAddress, String sRelayName,
			int nStatus, String sRUserName, String sRPassword, String sHostKey, int nRPort, int sPriority,
			boolean callByAdmin) throws SQLException {
		
		String sql = new RelayServerDB().updateRelayServer();
		
		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(sRelayServerAddress)
						.addParameter(sRelayName)
						.addParameter(nStatus)
						.addParameterEncrypted(sRUserName)
						.addParameterEncrypted(sRPassword)
						.addParameterEncrypted(sHostKey)
						.addParameter(nRPort)
						.addParameter(sPriority)
						.addParameter(sRelayServerID)
						.build();
		
		PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
		return mGet(sRelayServerID, callByAdmin);
	}
	
	private void mDelete(String sRelayServerID) throws SQLException {
		List<String> sql = new RelayServerDB().delete();
		List<QueryVO> queryVOs = new LinkedList<>();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql.get(0))
						.addParameter(sRelayServerID).build();
		queryVOs.add(queryVO);

		queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(sql.get(1)).addParameter(sRelayServerID).build();
		queryVOs.add(queryVO);

		queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(sql.get(2)).addParameter(sRelayServerID).build();
		queryVOs.add(queryVO);

		PortalDatabaseEngine.getInstance().getConnection().executeUpdatesInTransaction(queryVOs);
	}
	
	private RelayServerVO setRelayserver(ResultSet rs, boolean callByAdmin) throws SQLException
	{
		RelayServerVO relayVO = new RelayServerVO();
		relayVO.setsRelayServerID(rs.getString(PortalDBEnum.RELAY_SERVERS.sRelayServerID.name()));
		relayVO.setsRelayServerAddress(rs.getString(PortalDBEnum.RELAY_SERVERS.sRelayServerAddress.name()));
		relayVO.setsRelayName(rs.getString(PortalDBEnum.RELAY_SERVERS.sRelayName.name()));
		relayVO.setsDeviceLimit(rs.getString(PortalDBEnum.RELAY_SERVERS.sDeviceLimit.name()));
		relayVO.setnPortRangeStart(rs.getInt(PortalDBEnum.RELAY_SERVERS.nPortRangeStart.name()));
		relayVO.setnPortRangeEnd(rs.getInt(PortalDBEnum.RELAY_SERVERS.nPortRangeEnd.name()));
		relayVO.setnStatus(rs.getInt(PortalDBEnum.RELAY_SERVERS.nStatus.name()));
		
		
		if(callByAdmin)
		{
			String key = new CredProvider().getEcnKey();
			String username = StringEncryptionDecryption.decrypt(rs.getString(PortalDBEnum.SUPPORT_RELAY_SERVERS.sRUserName.name()),key);
			String pwd = StringEncryptionDecryption.decrypt(rs.getString(PortalDBEnum.SUPPORT_RELAY_SERVERS.sRPassword.name()),key);
			String hostkey = StringEncryptionDecryption.decrypt(rs.getString(PortalDBEnum.SUPPORT_RELAY_SERVERS.sHostKey.name()),key);
			
			relayVO.setsRUserName(username);
			relayVO.setsRPassword(pwd);		
			relayVO.setsHostKey(hostkey);
		}
		else
		{
			relayVO.setsRUserName(rs.getString(PortalDBEnum.SUPPORT_RELAY_SERVERS.sRUserName.name()));
			relayVO.setsRPassword(rs.getString(PortalDBEnum.SUPPORT_RELAY_SERVERS.sRPassword.name()));	
			relayVO.setsHostKey(rs.getString(PortalDBEnum.SUPPORT_RELAY_SERVERS.sHostKey.name()));	
		}
		
		relayVO.setnRPort(rs.getInt(PortalDBEnum.RELAY_SERVERS.nRPort.name()));
		relayVO.setsPriority(rs.getInt(PortalDBEnum.RELAY_SERVERS.sPriority.name()));
		relayVO.setdModified(rs.getTimestamp(PortalDBEnum.RELAY_SERVERS.dModified.name()).getTime());
		return relayVO;
	}

}
