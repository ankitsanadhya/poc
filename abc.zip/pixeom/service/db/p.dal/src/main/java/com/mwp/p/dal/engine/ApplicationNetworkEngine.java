/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal.engine;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mwp.common.Common;
import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.common.constant.ErrorMessage;
import com.mwp.common.vo.QueryVO;
import com.mwp.p.dal.ApplicationNetworkDB;

public class ApplicationNetworkEngine {

	public void linkApp(String appId, String networkId) throws SQLException {
		mLinkApp(appId, networkId);
	}

	private void mLinkApp(String appId, String networkId) throws SQLException {
		ApplicationNetworkDB appNetDB = new ApplicationNetworkDB();
		String getQuery = appNetDB.getAppNet();

		List<String> parameters = new ArrayList<>();

		parameters.add(appId);
		parameters.add(networkId);

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(getQuery)
						.addParameters(parameters).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			if (rs.next())
				throw new SQLException(ErrorMessage.APP_NETWORK_EXIST);
			else {

				String guid = Common.getRandomId();
				QueryVO insertQueryVO = new SqlQueryBuilder(
						PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
								.appendQuery(appNetDB.insert()).addParameter(guid).addParameter(appId)
								.addParameter(networkId).build();

				PortalDatabaseEngine.getInstance().getConnection().executeUpdate(insertQueryVO);
			}
		}
	}
}
