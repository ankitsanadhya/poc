/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal.engine;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.common.vo.QueryVO;
import com.mwp.logger.PALogger;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.dal.BoxStaticsDB;

/**
 * This class manages queries related to boxStatics.
 *
 */
public class BoxStaticsEngine {

	/**
	 * Add box statistics for a device.  
	 * @param deviceId
	 * @param statics statistics object.
	 * @throws SQLException
	 */
	public void addStatics(String deviceId, String statics) throws SQLException{
		mAddStatics(deviceId, statics);
	}

	private void mAddStatics(String deviceId, String statics) throws SQLException{
		PALogger.INFO("##### UPDATE BOX_STATICS_ON_PORTAL ###### deviceId: "+deviceId +" STATICS: " + statics);
		
//		StringBuilder sb = new StringBuilder();
//		sb.append("INSERT INTO ");sb.append(PortalDBEnum.TABLE_NAMES.boxStatics.name());
//		sb.append(" ( ");
//		sb.append(PortalDBEnum.BOX_STATICS.deviceId.name()); 
//		sb.append(", ");
//		sb.append(PortalDBEnum.BOX_STATICS.statics.name());
//		sb.append(", ");
//		sb.append(PortalDBEnum.BOX_STATICS.modifiedDate.name());
//		sb.append(" ) VALUES (");
//		sb.append(dbCon.formatString(deviceId)); 
//		sb.append(", ");
//		sb.append(dbCon.formatString(statics));
//		sb.append(", ");
//		sb.append("NOW()");
//		sb.append(" ) ");
//		sb.append(" ON DUPLICATE KEY UPDATE ");
//		sb.append(PortalDBEnum.BOX_STATICS.statics.name());sb.append(" = ");sb.append(dbCon.formatString(statics));
//		sb.append(", ");
//		sb.append(PortalDBEnum.BOX_STATICS.modifiedDate.name());sb.append(" = ");sb.append("NOW()");		
	
		
		String sql = new BoxStaticsDB().insert();
		
		List<String> parameters = new ArrayList<>();	
		
		parameters.add(deviceId);
		parameters.add(statics);
		parameters.add(statics);//for on update
		
		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(sql).addParameters(parameters).build();
		
		PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
	}
	
	/**
	 * List statistics for given device id. 
	 * @param deviceId
	 * @return Hashmap of modified date as key and statistics text as value. 
	 * @throws SQLException
	 */
	public Object getBoxStatics(String deviceId) throws SQLException{
		return mGetBoxStatics(deviceId);
	}

	private Object mGetBoxStatics(String deviceId) throws SQLException{
		String sql = new BoxStaticsDB().getStatics();
		
		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(sql).addParameter(deviceId).build();

		Map<String, String> staticsList = new HashMap<>();
		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)){
			while (rs.next()){
				staticsList.put(String.valueOf(rs.getTimestamp(PortalDBEnum.BOX_STATICS.modifiedDate.name()).getTime()), rs.getString(PortalDBEnum.BOX_STATICS.statics.name()));
			}
		}
		return staticsList;
	}
}
