/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal.engine;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.management.Query;

import com.mwp.common.StringFunctions;
import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.common.enums.RedirectType;
import com.mwp.common.enums.Status;
import com.mwp.common.enums.StatusEnum.VERSION_STATUS;
import com.mwp.common.vo.AuthorizationsVO;
import com.mwp.common.vo.PortVO;
import com.mwp.common.vo.QueryVO;
import com.mwp.common.vo.VersionVO;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.dal.ApplicationDetailsDB;
import com.mwp.p.dal.ApplicationGroupsDB;
import com.mwp.p.dal.ApplicationVersionDB;

/**
 * This class manage - add application version, application configuration YML file path.
 * @author root
 *
 */
public class VersionEngine {

	/**
	 * add application version, configuration, service endpoints in db.
	 * @param appId
	 * @param appVersion
	 * @param configYmlPath
	 * @param serviceEndpoints
	 * @return
	 * @throws SQLException
	 */
	public VersionVO createAppVersion(String projectId, List<PortVO> ports, VersionVO versionVO) throws SQLException {
		return mCreateAppVersion(projectId, ports, versionVO);
	}

	/**
	 * Get all version number for applicaton id and platform id.This method return version where status is not equal to uploading 
	 * @param appId
	 * @param appPlatformId
	 * @return
	 * @throws SQLException
	 */
	public List<String> getAllVersionNumbers(String appId, String appPlatformId) throws SQLException {
		return mGetAllVersionNumbers(appId, appPlatformId);
	}

	/**
	 * Get latest version of an application 
	 * @param appid
	 * @return
	 * @throws SQLException
	 */
//	public VersionVO getAppVersion(String appid) throws SQLException{
//		return mGetAppVersion(appid);
//	}

	/**
	 * List all versions for an application  
	 * @param appId
	 * @return
	 * @throws SQLException
	 */
	public List<VersionVO> getVersionsOfApp(String appId, String userId) throws SQLException{
		return mGetVersionsOfApp(appId, userId);
	}

	/**
	 * change application version status according to given appversionId.
	 * @param appVersionId
	 * @param status
	 * @return
	 * @throws SQLException 
	 */
	public void changeAppVersionStatus(String appId,String appVersionId, VERSION_STATUS status) throws SQLException {
		mChangeAppVersionStatus( appId,appVersionId, status);
	}

	/**
	 * List of versions with permissions, if user only invited for app not for 
	 * version then list all version of that app with group permission
	 * @param appId : application id of invited or own app
	 * @param authVo : AuthorizationsVO object after login
	 * @return
	 */
	public List<VersionVO> getVersionsOfGroupApp(String appId, AuthorizationsVO authVo, String versionToCheck, String appPlatformId, List<VERSION_STATUS> filterVersionStstus) throws SQLException {
		return mGetVersionsOfGroupApp(appId, authVo, versionToCheck, appPlatformId, filterVersionStstus);
	}

	/**
	 * List of versions without permissions, if user only invited for app not for 
	 * version then list all version of that app
	 * @param appId : application id of invited or own app
	 * @param groupId : group id where app is invited
	 * @return
	 */
	public List<VersionVO> getVersionsOfGroupAppWithoutPermission(String appId, String groupId, List<VERSION_STATUS> filterVersionStstus) throws SQLException {
		return mGetVersionsOfGroupAppWithoutPermission(appId, groupId, filterVersionStstus);
	}

	/**
	 * This method checking that all versions invited in group or not
	 * @param appId : application id of invited or own app
	 * @param groupId : group id where app is invited
	 * @return
	 * @throws SQLException
	 */
	public boolean isAllVersionsInvited(String appId, String groupId) throws SQLException {
		return mIsAllVersionsInvited(appId, groupId);
	}

//	private VersionVO mGetAppVersion(String appId) throws SQLException {
//		String sql =  new ApplicationVersionDB().getLatestVersionOfApp(appId);
//		ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeSelect(sql);
//		try{
//			while (rs.next()){
//				return setVersionObject(rs);
//			}
//		}finally{
//			PortalDatabaseEngine.getInstance().getConnection().closeResultSet(rs);
//		}
//		return null;
//	}

	private List<VersionVO> mGetVersionsOfApp(String appId, String userId) throws SQLException {
		List<VersionVO> versions = new ArrayList<>();
		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new ApplicationVersionDB().getAllAppVersionByOwner()).addParameter(appId).addParameter(userId).build();

		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)){
			while (rs.next()){
				versions.add(setVersionObject(rs));
			}
		}

		return versions;
	}

	private List<VersionVO> mGetVersionsOfGroupApp(String appId, AuthorizationsVO authVo,  String versionToCheck, String appPlatformId, List<VERSION_STATUS> filterVersionStstus) throws SQLException {
		List<VersionVO> versions = new ArrayList<>();

		List<String> groups = new ArrayList<>(authVo.getGroupPermissions().keySet());
		if(groups == null || groups.isEmpty()){
			groups = new ArrayList<String>();
			groups.add("");
		}
		String sql = new ApplicationVersionDB().getVersionsOfGroupApp(appPlatformId, versionToCheck, groups.size(), filterVersionStstus);
		
		SqlQueryBuilder queryBuilder = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(appId).addParameters(groups).addParameter(appId).addParameters(groups);
		
		if (!StringFunctions.isNullOrEmpty(versionToCheck)) {
			queryBuilder.addParameter(versionToCheck);
		}

		if (!StringFunctions.isNullOrEmpty(appPlatformId)) {
			queryBuilder.addParameter(appPlatformId);
		}

		if (filterVersionStstus != null && !filterVersionStstus.isEmpty()) {
			List<Integer> lstFilter = new ArrayList<>();
			for (VERSION_STATUS version_STATUS : filterVersionStstus) {
				lstFilter.add(version_STATUS.ordinal());
			}
			queryBuilder.addParameters(lstFilter);
		}
		
		QueryVO queryVO = queryBuilder.build();
		
		Map<String, VersionVO> versionIds = new HashMap<>();
		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)){
			VersionVO versionVO;
			while (rs.next()){
				/*if version not exist then create a new version, clear permission list (BYDEFAULT PERMISSION HAS * (ALL RIGHTS)),
				 * and set permissions according to group permission-set.
				 */
				if(!versionIds.containsKey(rs.getString(PortalDBEnum.APPLICATION_VERSIONS.appVersionId.name()))) {
					versionVO = setVersionObject(rs);
					versions.add(versionVO);
					versionIds.put(rs.getString(PortalDBEnum.APPLICATION_VERSIONS.appVersionId.name()), versionVO);
					versionVO.getPermissions().clear();
					versionVO.getPermissions().addAll(authVo.getGroupPermissions().get(rs.getString("groupId")));
				}
				else {	
					/* If version already added then check for new group permissions, if permission already added then skip
					 * 
					 */
					versionVO = versionIds.get(rs.getString(PortalDBEnum.APPLICATION_VERSIONS.appVersionId.name()));
					for (String permission : authVo.getGroupPermissions().get(rs.getString("groupId"))) {
						if(!versionVO.getPermissions().contains(permission))
							versionVO.getPermissions().add(permission);
					}
				}
			}
		}

		return versions;
	}

	private List<VersionVO> mGetVersionsOfGroupAppWithoutPermission(String appId, String groupId, List<VERSION_STATUS> filterVersionStstus) throws SQLException 
	{
		List<VersionVO> versions = new ArrayList<>();
		ArrayList<String> groups = new ArrayList<>();
		groups.add(groupId);
		boolean invitationExists = false;

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
						.appendQuery(new ApplicationGroupsDB().getGroupAppId()).addParameter(appId)
						.addParameter(groupId).build();

		try (ResultSet rs1 = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			if (rs1.next()) {
				invitationExists = true;

				String sql = new ApplicationVersionDB().getVersionsOfGroupApp("", "", groups.size(),
						filterVersionStstus);

				SqlQueryBuilder queryBuilder = new SqlQueryBuilder(
						PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
								.addParameter(appId).addParameters(groups).addParameter(appId).addParameters(groups);
				
				if (filterVersionStstus != null && !filterVersionStstus.isEmpty()) {
					List<Integer> lstFilter = new ArrayList<>();
					for (VERSION_STATUS version_STATUS : filterVersionStstus) {
						lstFilter.add(version_STATUS.ordinal());
					}
					queryBuilder.addParameters(lstFilter);
				}

				QueryVO versionQueryVO = queryBuilder.build();

				try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(versionQueryVO)) {
					while (rs.next()) {
						/*
						 * if version not exist then create a new version.
						 */
						VersionVO versionVO = setVersionObject(rs);
						versions.add(versionVO);
					}
				}

			}
		}
		if (invitationExists) {
			return versions;
		} else {
			return null;
		}
	}
	
	private boolean mIsAllVersionsInvited(String appId, String groupId) throws SQLException {
		String sql = new ApplicationVersionDB().groupAppVersionAvailable();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(groupId).addParameter(appId).build();

		/*
		 * If all versions invited in this group then count is 0 > RETURN TRUE
		 * ELSE FALSE
		 */
		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			return !rs.next();
		}
	}


	private VersionVO mCreateAppVersion(String projectId, List<PortVO> ports, VersionVO versionVO) throws SQLException {
		// versionVO object for return param if transaction queries successfully
		// executed.
		versionVO.setStatus(VERSION_STATUS.UPLOADING);
		// add application version, configuration, service endpoints in db.
		List<QueryVO> queries = new ApplicationVersionDB().createAppVersion(versionVO, ports, projectId);
		// execute queries in transaction.
		PortalDatabaseEngine.getInstance().getConnection().executeUpdatesInTransaction(queries);

		return versionVO;
	}

	private ArrayList<String> mGetAllVersionNumbers(String appId, String appPlatformId) throws SQLException {
		ArrayList<String> versions = new ArrayList<>();

		String sql = new ApplicationVersionDB().getAllVersionNumbers();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(appId).addParameter(appPlatformId).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				versions.add(rs.getString(PortalDBEnum.APPLICATION_VERSIONS.appVersion.name()));
			}
		}
		return versions;
	}

	private VERSION_STATUS mGetVersionStatus(String appId, String appVersionId) throws SQLException {
		String sql = new ApplicationVersionDB().getVersionStatus();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(appId).addParameter(appVersionId).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				return VERSION_STATUS.GetEnum(rs.getInt(PortalDBEnum.APPLICATION_VERSIONS.versionStatus.name()));
			}
		}
		return null;

	}
	
	private void mChangeAppVersionStatus(String appId, String appVersionId, VERSION_STATUS status) throws SQLException {
		VERSION_STATUS dbStatus = mGetVersionStatus(appId, appVersionId);

		if (dbStatus == null) {
			throw new SQLException("Version not found.");
		}

		if (dbStatus == status) {
			return;
		} else if (dbStatus == VERSION_STATUS.DELETED) {
			throw new SQLException("Version is already deleted.");
		}

		if (status == VERSION_STATUS.LIVE) {
			changeLiveVersions(appId, appVersionId, status);
		} else if (status == VERSION_STATUS.DELETED) {
			changeDeleteVersion(appId, appVersionId, status);
		} else if (status == VERSION_STATUS.OLDRELEASED) {
			changeOldReleaseStatus(appId, appVersionId, status);
		} else {
			changeAppVersionStatus(appVersionId, status);
		}
	}

	private void changeAppVersionStatus(String appVersionId, VERSION_STATUS status) throws SQLException {
		ApplicationVersionDB applicationVersionDB = new ApplicationVersionDB();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
						.appendQuery(applicationVersionDB.changeAppVersionStatus()).addParameter(status.ordinal())
						.addParameter(appVersionId).build();

		int updateCount = PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
		if (updateCount == 0) {
			throw new SQLException("change application version status failed.");
		}
	}

	private void changeOldReleaseStatus(String appId, String appVersionId, VERSION_STATUS status) throws SQLException {
		VersionVO versionVO = getAppVersionVO(appId, appVersionId);

		ApplicationVersionDB applicationVersionDB = new ApplicationVersionDB();
		List<QueryVO> queries = new LinkedList<>();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
						.appendQuery(applicationVersionDB.changeOldAppVersionStatus())
						.addParameter(VERSION_STATUS.OLDRELEASED.ordinal()).addParameter(appId)
						.addParameter(versionVO.getAppPlatformId()).addParameter(VERSION_STATUS.LIVE.ordinal()).build();
		queries.add(queryVO);

		queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new ApplicationDetailsDB().unpublishApplication()).addParameter(appId).addParameter(appId).build();

		queries.add(queryVO);
		PortalDatabaseEngine.getInstance().getConnection().executeUpdatesInTransaction(queries);
	}

	private void changeDeleteVersion(String appId, String appVersionId, VERSION_STATUS status) throws SQLException {
		List<QueryVO> queries = new LinkedList<>();
		ApplicationVersionDB applicationVersionDB = new ApplicationVersionDB();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
						.appendQuery(applicationVersionDB.changeAppVersionStatus()).addParameter(status.ordinal())
						.addParameter(appVersionId).build();
		queries.add(queryVO);

		queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new ApplicationDetailsDB().unpublishApplication()).addParameter(appId).addParameter(appId).build();

		queries.add(queryVO);

		PortalDatabaseEngine.getInstance().getConnection().executeUpdatesInTransaction(queries);
	}

	private void changeLiveVersions(String appId, String appVersionId, VERSION_STATUS status) throws SQLException {
		VersionVO versionVO = getAppVersionVO(appId, appVersionId);

		List<QueryVO> queries = new LinkedList<>();
		ApplicationVersionDB applicationVersionDB = new ApplicationVersionDB();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
						.appendQuery(applicationVersionDB.changeOldAppVersionStatus())
						.addParameter(VERSION_STATUS.OLDRELEASED.ordinal()).addParameter(appId)
						.addParameter(versionVO.getAppPlatformId()).addParameter(VERSION_STATUS.LIVE.ordinal()).build();
		queries.add(queryVO);

		queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(applicationVersionDB.changeAppVersionStatus()).addParameter(status.ordinal())
				.addParameter(appVersionId).build();
		queries.add(queryVO);

		queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new ApplicationDetailsDB().updateApplicationStatus())
				.addParameter(Status.PUBLISHED.ordinal()).addParameter(appId).build();
		queries.add(queryVO);

		PortalDatabaseEngine.getInstance().getConnection().executeUpdatesInTransaction(queries);
	}

	private VersionVO getAppVersionVO(String appId, String appVersionId) throws SQLException {
		VersionVO versionVO = mGetVersionDetails(appId, appVersionId);
		if (versionVO == null) {
			throw new SQLException("Version not found.");
		}
		return versionVO;
	}

	private VersionVO mGetVersionDetails(String appId, String versionId) throws SQLException {
		VersionVO versionVO = null;
		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
						.appendQuery(new ApplicationVersionDB().getVersionDetails()).addParameter(appId)
						.addParameter(versionId).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				versionVO = new VersionEngine().setVersionObject(rs);
			}
		}
		return versionVO;
	}

	protected VersionVO setVersionObject(ResultSet rs) throws SQLException{
		VersionVO versionVO = new VersionVO();
		versionVO.setVersionId(rs.getString(PortalDBEnum.APPLICATION_VERSIONS.appVersionId.name()));
		versionVO.setConfigYmlPath(rs.getString(PortalDBEnum.APPLICATION_VERSIONS.composerFilePath.name()));

		versionVO.setAppId(rs.getString(PortalDBEnum.APPLICATION_VERSIONS.appId.name()));
		versionVO.setAppPlatformId(rs.getString(PortalDBEnum.APPLICATION_VERSIONS.appPlatformId.name()));
		versionVO.setReleaseNote(rs.getString(PortalDBEnum.APPLICATION_VERSIONS.releaseNotes.name()));
		versionVO.setSize(rs.getLong(PortalDBEnum.APPLICATION_VERSIONS.size.name()));
		versionVO.setStatus(VERSION_STATUS.GetEnum(rs.getInt(PortalDBEnum.APPLICATION_VERSIONS.versionStatus.name())));
		versionVO.setVersionNumber(rs.getString(PortalDBEnum.APPLICATION_VERSIONS.appVersion.name()));
		//AKH_01
		versionVO.setRedirectType(RedirectType.GetEnum(rs.getInt(PortalDBEnum.APPLICATION_VERSIONS.redirectType.name())));
		versionVO.setRedirectUrl(rs.getString(PortalDBEnum.APPLICATION_VERSIONS.redirectUrl.name()));
		versionVO.setRestRedirectUrl(rs.getString(PortalDBEnum.APPLICATION_VERSIONS.restRedirectUrl.name()));
		List<String> list = new ArrayList<>();
		String executionOrder = rs.getString(PortalDBEnum.APPLICATION_VERSIONS.toExecuteOrder.name());
		if(!StringFunctions.isNullOrWhitespace(executionOrder))
			list = new ArrayList<>(Arrays.asList(executionOrder.split(" , ")));
		versionVO.setToExecuteOrder(list);
		versionVO.setComposeVersion(rs.getString(PortalDBEnum.APPLICATION_VERSIONS.composeVersion.name()));

		versionVO.setRedirectSection(rs.getString(PortalDBEnum.APPLICATION_VERSIONS.redirectSection.name()));
		versionVO.setCreatedDate(rs.getTimestamp(PortalDBEnum.APPLICATION_VERSIONS.createdDate.name()).getTime());
		versionVO.setModifiedDate(rs.getTimestamp(PortalDBEnum.APPLICATION_VERSIONS.modifiedDate.name()).getTime());
		return versionVO;
	}

	/**
	 * Method for getting queries for deleting versions,configurations etc
	 * according to given application Id.
	 * 
	 * @param appId
	 * @return
	 */
	public List<String> deleteVersion() {
		return mDeleteVersion();
	}

	private List<String> mDeleteVersion() {
		ApplicationVersionDB applicationVersionDB = new ApplicationVersionDB();
		return applicationVersionDB.deleteVersion();
	}

}

/**
 * History of check-in or issue resolved
 * 
 * 01 - 14-11-2016 AKH_01
 * Add restRedirectUrl, redirectUrl, redirectType and redirectSection property in applicationVersion,
 * because may be each version have different redirection param.
 */