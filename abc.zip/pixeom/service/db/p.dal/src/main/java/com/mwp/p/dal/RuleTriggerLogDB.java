/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal;


import java.util.ArrayList;
import java.util.List;

import com.mwp.db.Interface.IConnection;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.dal.engine.PortalDatabaseEngine;
import com.mwp.p.dal.engine.RuleTriggerLogEngine;

/**
 * This class create queries to log ruleTrigger database related to table {@link RuleTriggerLogEngine}
 *
 */	
public class RuleTriggerLogDB 
{
	private IConnection dbCon = PortalDatabaseEngine.getInstance().getConnection();

	/**
	 * Add new log info in table
	 * 	id,
		ruleId,
		startTime,
		endTime,
		stage,
		status,
		info
	 */
	public String insert() 
	{
		return mInsert();
	}

	public String update()
	{
		return mUpdate();
	}
	
	public String get() 
	{
		return mget();
	}

	
	/**
	 * List all activity. 
	 * @param appId
	 * @return
	 */
	public String list()
	{
		return mList();
	}
	
	/**
	 * query to list log from last given number of days
	 * @param noOfDays
	 * @return
	 */
	public String listByTime()
	{
		return mListByTime();
	}

	/**
	 * List logs with paging
	 * @param pageNum
	 * @param appId
	 * @param queryLimit
	 * @return 
	 */
	public List<String> listFilter()
	{
		return mListFilter();
	}

	public String getLatestrec() 
	{
		return mgetLatestrec();
	}
	
	private String mInsert() 
	{
		StringBuilder sb = new StringBuilder();
		sb.append("INSERT INTO ");
		sb.append(PortalDBEnum.TABLE_NAMES.ruleTriggerLog);
		sb.append(" ( ");
		sb.append(PortalDBEnum.RULE_TRIGGER_LOG.id.name());
		sb.append(", ");
		sb.append(PortalDBEnum.RULE_TRIGGER_LOG.ruleId.name());
		sb.append(", ");
		sb.append(PortalDBEnum.RULE_TRIGGER_LOG.startTime.name());
		sb.append(", ");
		sb.append(PortalDBEnum.RULE_TRIGGER_LOG.status.name());
		sb.append(", ");
		sb.append(PortalDBEnum.RULE_TRIGGER_LOG.info.name());
		sb.append(" ) VALUES ( ");
		//sb.append(dbCon.formatString(id));
		sb.append("?");
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(ruleId));
		sb.append(", ");
		sb.append(" NOW()");
		sb.append(", ");
		sb.append("?");
//		sb.append(status.ordinal());
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(info));
		sb.append(" )");
		return sb.toString();
	}
	
	private String mList() 
	{
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT SQL_CALC_FOUND_ROWS * FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.ruleTriggerLog);
		sb.append(" ORDER BY ");
		sb.append(PortalDBEnum.RULE_TRIGGER_LOG.endTime.name());
		sb.append(" DESC ");
		return sb.toString();
	}
	
	public String mListFromType() 
	{
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT SQL_CALC_FOUND_ROWS * FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.ruleTriggerLog);		
		sb.append(" JOIN ");
		sb.append(PortalDBEnum.TABLE_NAMES.rule);
		sb.append(" ON ");sb.append(PortalDBEnum.TABLE_NAMES.rule);sb.append(".");sb.append(PortalDBEnum.RULE.ruleId);
		sb.append(" = ");
		sb.append(PortalDBEnum.TABLE_NAMES.ruleTriggerLog);sb.append(".");sb.append(PortalDBEnum.RULE_TRIGGER_LOG.ruleId);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.TABLE_NAMES.rule);sb.append(".");sb.append(PortalDBEnum.RULE.ruleType);
		sb.append(" = ");
		sb.append("?");
		//sb.append(type.ordinal());				
		sb.append(" ORDER BY ");
		sb.append(PortalDBEnum.RULE_TRIGGER_LOG.endTime.name());
		sb.append(" DESC ");
		return sb.toString();
	}
	
	
	
	public String mListlog() 
	{
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT SQL_CALC_FOUND_ROWS * FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.ruleTriggerLog);		
		sb.append(" JOIN ");
		sb.append(PortalDBEnum.TABLE_NAMES.rule);
		sb.append(" ON ");sb.append(PortalDBEnum.TABLE_NAMES.rule);sb.append(".");sb.append(PortalDBEnum.RULE.ruleId);
		sb.append(" = ");
		sb.append(PortalDBEnum.TABLE_NAMES.ruleTriggerLog);sb.append(".");sb.append(PortalDBEnum.RULE_TRIGGER_LOG.ruleId);
		sb.append(" ORDER BY ");
		sb.append(PortalDBEnum.RULE_TRIGGER_LOG.endTime.name());
		sb.append(" DESC ");
		return sb.toString();
	}
	
	/**
	 * this will list log from last given number of days
	 * @param noOfDays
	 * @return
	 */
	private String mListByTime() 
	{
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT * FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.ruleTriggerLog);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.RULE_TRIGGER_LOG.startTime.name());
		sb.append(" > ");
		sb.append("NOW() - INTERVAL ");
		sb.append("?");
		//sb.append(noOfDays);
		sb.append(" DAY" );
		return sb.toString();		
	}
	
	private String mgetLatestrec() {
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT * FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.ruleTriggerLog);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.RULE_TRIGGER_LOG.ruleId.name());
		sb.append(" = ");
		sb.append("?");
//		sb.append(dbCon.formatString(ruleId));
		sb.append(" ORDER BY ");
		sb.append(PortalDBEnum.RULE_TRIGGER_LOG.endTime.name());
		sb.append(" DESC ");
		sb.append("LIMIT 1");
		return sb.toString();

	}
	private List<String> mListFilter()
	{
		List<String> eventSql = new ArrayList<>(); 
		
		StringBuilder sb = new StringBuilder();
		sb.append(mList());
		sb.append(" limit ");
		sb.append("?");
		//sb.append(queryLimit);
		sb.append(" offset ");
		sb.append("?");
//		sb.append(offset);

		eventSql.add(sb.toString());
		eventSql.add("SELECT FOUND_ROWS() as eventCount");
		return eventSql;

	}
	
	
	private String mUpdate() 
	{
		StringBuilder sb = new StringBuilder();
		sb.append("UPDATE  ");
		sb.append(PortalDBEnum.TABLE_NAMES.ruleTriggerLog);
		sb.append(" set  ");
		sb.append(PortalDBEnum.RULE_TRIGGER_LOG.endTime.name());
		sb.append(" = ");
		sb.append(" NOW()");
		sb.append(", ");
		sb.append(PortalDBEnum.RULE_TRIGGER_LOG.status.name());
		sb.append(" = ");
		sb.append("?");
		//sb.append(status.ordinal());
		sb.append(", ");
		sb.append(PortalDBEnum.RULE_TRIGGER_LOG.stage.name());
		sb.append(" = ");
		sb.append("?");
		//sb.append(stage);
		sb.append(", ");
		sb.append(PortalDBEnum.RULE_TRIGGER_LOG.info.name());
		sb.append(" = ");
		sb.append("?");
		//sb.append(dbCon.formatString(info));
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.RULE_TRIGGER_LOG.id.name());
		sb.append(" = ");
		sb.append("?");
		//sb.append(dbCon.formatString(id));
		return sb.toString();
	}
	
	
	private String mget() {
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT * FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.ruleTriggerLog);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.RULE_TRIGGER_LOG.id.name());
		sb.append(" = ");
		sb.append("?");
//		sb.append(dbCon.formatString(id));

		return sb.toString();

	}
	
}
