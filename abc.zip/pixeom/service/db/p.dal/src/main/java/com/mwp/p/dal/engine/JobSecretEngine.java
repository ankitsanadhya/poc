/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.mwp.p.dal.engine;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import com.mwp.common.Common;
import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.common.vo.QueryVO;
import com.mwp.common.yamlparser.SecretVo;
import com.mwp.p.dal.JobSecretDB;

public class JobSecretEngine {

	public void insert(String jobSecretId, String appSecretId, String edgeCoreId, String jobId, String serviceName)
			throws SQLException {
		mInsert(jobSecretId, appSecretId, edgeCoreId, jobId, serviceName);
	}

	private void mInsert(String jobSecretId, String appSecretId, String edgeCoreId, String jobId, String serviceName)
			throws SQLException {
		List<String> parameters = new ArrayList<>();
		parameters.add(jobSecretId);
		parameters.add(appSecretId);
		parameters.add(edgeCoreId);
		parameters.add(jobId);
		parameters.add(serviceName);

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
						.appendQuery(new JobSecretDB().insert()).addParameters(parameters).build();

		PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
	}

	public void insertMulti(List<SecretVo> lstSecretVo, String edgeCoreId, String jobId) throws SQLException {
		mInsertMulti(lstSecretVo, edgeCoreId, jobId);
	}

	private void mInsertMulti(List<SecretVo> lstSecretVo, String edgeCoreId, String jobId) throws SQLException {
		String qry = new JobSecretDB().insertMulti();
		List<QueryVO> queryVOs = new LinkedList<>();
		for (SecretVo secretVo : lstSecretVo) {
			QueryVO queryVO = new SqlQueryBuilder(
					PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(qry)
							.addParameter(Common.getRandomId())
							.addParameter(secretVo.getListSecretVersion().get(0).getAppSecretVersionId())
							.addParameter(edgeCoreId).addParameter(jobId).addParameter(secretVo.getServiceName())
							.build();

			queryVOs.add(queryVO);

		}

		PortalDatabaseEngine.getInstance().getConnection().executeUpdatesInTransaction(queryVOs);
	}

}
