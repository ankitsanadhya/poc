/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal.engine;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.mwp.common.Common;
import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.common.enums.AppBackupTaskStatus;
import com.mwp.common.vo.AppBackupTaskVO;
import com.mwp.common.vo.AppBackupTaskVOPortal;
import com.mwp.common.vo.FilterObject;
import com.mwp.common.vo.QueryVO;
import com.mwp.logger.PALogger;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.dal.AppBackupTaskDB;

public class AppBackupTaskEngine {

	/**
	 * Insert new or if already exists update completedTime, status and arkBackupName
	 * @param appBackupTaskVOPortal
	 * @return
	 */
	public AppBackupTaskVOPortal upsert(AppBackupTaskVOPortal appBackupTaskVOPortal) throws SQLException {
		return mUpsert(appBackupTaskVOPortal);
	}

	/**
	 * List all app backup tasks for cluster
	 * @param clusterId
	 * @return
	 */
	public List<AppBackupTaskVOPortal> list(String clusterId) throws SQLException {
		return mList(clusterId);
	}

	/**
	 * List all app backup tasks for cluster with page limits
	 * @param pageNo
	 * @param pageSize
	 * @return - MAP with keys data, totalRows, totalPages, pageNo, pageSize, pageSize
	 */
	//	public Map<String, Object> list(long pageNo, long pageSize) throws SQLException {
	//		Map<String, String> queries = new AppBackupTaskDB().list(pageNo, pageSize);
	//		return mList(queries, pageNo, pageSize, null, null);
	//	}

	/**
	 * List all app backup tasks for cluster with filters provided and page limits
	 * @param clusterIds - For which cluster you  needed for user it's own all cluster ids
	 * @param filters - Filter (AppId, Cluster) and Sort objects
	 * @param sizePerApp - 1 = List latest available backup, else list all backups
	 * @param pageNo - Which page
	 * @param pageSize - data in one page
	 * @return - MAP with keys data, totalRows, totalPages, pageNo, pageSize, pageSize
	 */
	public Map<String, Object> list(List<String> clusterIds, List<FilterObject> filters, int sizePerApp, long pageNo,
			long pageSize) throws SQLException {
		pageNo = (pageNo == 0) ? 1 : pageNo;
		pageSize = (pageSize == 0) ? 20 : pageSize;

		Map<String, String> queries = new AppBackupTaskDB().list(filters, sizePerApp, clusterIds);

		return mList(queries, pageNo, pageSize, filters, clusterIds, sizePerApp);
	}

	private Map<String, List<Object>> createFilterParameters(List<FilterObject> filters, int sizePerApp, List<String> clusterIds, long pageNo, long pageSize) {
		Map<String, List<Object>> map = new HashMap<>();

		long offset = ((pageNo == 0)?1:pageNo - 1) * pageSize;
		long limit = pageSize;

		List<Object> parameters = new LinkedList<>();
		List<Object> parametersSub = new LinkedList<>();
		List<Object> countParams = new ArrayList<>();
		boolean clusterFilterApplied = false;

		if (filters != null) {

			for (FilterObject filterObject : filters) {
				switch (filterObject.getFilterType()) {
				case FILTER:
					switch (filterObject.getFilterkey()) {
					case App:
						switch (filterObject.getValueType()) {
						case Single:
							parameters.add(filterObject.getStartValue());
							parametersSub.add(filterObject.getStartValue());
							countParams.add(filterObject.getStartValue());
							break;
						case List:
							parameters.addAll(filterObject.getValues());
							parametersSub.addAll(filterObject.getValues());
							countParams.addAll(filterObject.getValues());
							break;
						default:
							break;
						}
						break;
					case Cluster:
						switch (filterObject.getValueType()) {
						case Single:
							clusterFilterApplied = true;
							if (StringUtils.isEmpty(filterObject.getStartValue()) || "global".equalsIgnoreCase(filterObject.getStartValue())) {
								parameters.addAll(clusterIds);
								parametersSub.addAll(clusterIds);
								countParams.addAll(clusterIds);
							} else {
								parameters.add(filterObject.getStartValue());
								parametersSub.add(filterObject.getStartValue());
								countParams.add(filterObject.getStartValue());
							}
							break;
						case List:
							clusterFilterApplied = true;
							parameters.addAll(filterObject.getValues());
							parametersSub.addAll(filterObject.getValues());
							countParams.addAll(filterObject.getValues());
							break;
						default:
							break;
						}
						break;
					case Status:
						switch (filterObject.getValueType()) {
						case Single:
							parameters.add(filterObject.getStartValue());
							parametersSub.add(filterObject.getStartValue());
							countParams.add(filterObject.getStartValue());
							break;
						case List:
							parameters.addAll(filterObject.getValues());
							parametersSub.addAll(filterObject.getValues());
							countParams.addAll(filterObject.getValues());
							break;
						default:
							break;
						}
						break;
					default:
						break;
					}
					break;
				case SORT:

					break;
				default:
					break;
				}
			}
		}

		if (!clusterFilterApplied) {
			parameters.addAll(clusterIds);
			parametersSub.addAll(clusterIds);
		}

		if(sizePerApp != 0) {
			parameters.addAll(parametersSub);
		}

		parameters.add(limit);
		parameters.add(offset);

		map.put("parameters", parameters);
		map.put("countParam", countParams);

		return map;
	}

	/**
	 * Delete app Backup task with it's backup name
	 * @param arkBackupName
	 * @return - database rows affected
	 */
	public int delete(String arkBackupName) throws SQLException {
		return mDelete(arkBackupName);
	}

	private List<AppBackupTaskVOPortal> mList(String clusterId) throws SQLException {
		List<AppBackupTaskVOPortal> appBackupTaskVOPortals = new LinkedList<>();

		String query = new AppBackupTaskDB().listByClusterId();

		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(query).addParameter(clusterId).build();

		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				appBackupTaskVOPortals.add(setAppBackupTaskObject(rs));
			}
		}

		return appBackupTaskVOPortals;
	}

	private Map<String, Object> mList(Map<String, String> queries, long pageNo, long pageSize, List<FilterObject> filters, List<String> clusterIds, int sizePerApp) throws SQLException {
		List<AppBackupTaskVOPortal> appBackupTaskVOPortals = new LinkedList<>();

		Map<String, List<Object>> map = createFilterParameters(filters, sizePerApp, clusterIds, pageNo, pageSize);

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(queries.get("data")).addParameters(map.get("parameters")).build();

		PALogger.TRACE("List app backup tasks: data : " + queryVO.toString());

		QueryVO queryVOCount = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(queries.get("count")).addParameters(map.get("countParam")).build();

		PALogger.TRACE("List app backup tasks: count : " + queryVOCount.toString());

		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			List<String> appBackupIds = new LinkedList<>();

			while (rs.next()) {

				AppBackupTaskVOPortal appBackupTaskVOPortal = setAppBackupTaskObject(rs);
				if(sizePerApp == 1 && !appBackupIds.contains(appBackupTaskVOPortal.getAppBackupTaskVO().getBackupTaskId())) {
					appBackupTaskVOPortals.add(appBackupTaskVOPortal);
					appBackupIds.add(appBackupTaskVOPortal.getAppBackupTaskVO().getBackupTaskId());
				} else {
					appBackupTaskVOPortals.add(appBackupTaskVOPortal);
				}
			}
		}


		long totalRows = 0; 
		try(ResultSet rsCount = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVOCount)) {
			while (rsCount.next()) {
				totalRows = rsCount.getLong("totalRows");
			} 
		} 

		long totalPages = totalRows / pageSize;
		if((totalRows % pageSize) > 0) {
			totalPages += 1;			
		}

		Map<String, Object> paginatedMap = new HashMap<>();
		paginatedMap.put("data", appBackupTaskVOPortals);
		paginatedMap.put("totalRows", totalRows);
		paginatedMap.put("totalPages", totalPages);
		paginatedMap.put("pageNo", pageNo);
		paginatedMap.put("pageSize", pageSize);

		return paginatedMap;
	}

	private AppBackupTaskVOPortal mUpsert(AppBackupTaskVOPortal appBackupTaskVOPortal) throws SQLException {

		if(StringUtils.isEmpty(appBackupTaskVOPortal.getAppBackupTaskVO().getBackupTaskId())) {
			appBackupTaskVOPortal.getAppBackupTaskVO().setBackupTaskId(Common.getRandomId());
		}
		if(appBackupTaskVOPortal.getAppBackupTaskVO().getStartedTime() == 0) {
			appBackupTaskVOPortal.getAppBackupTaskVO().setStartedTime(1);
		}
		if(appBackupTaskVOPortal.getAppBackupTaskVO().getCompletedTime() == 0) {
			appBackupTaskVOPortal.getAppBackupTaskVO().setCompletedTime(1);
		}

		List<Object> parameters = new ArrayList<>();

		parameters.add(appBackupTaskVOPortal.getAppBackupTaskVO().getBackupTaskId());
		parameters.add(appBackupTaskVOPortal.getAppBackupTaskVO().getArkBackupName());
		parameters.add(appBackupTaskVOPortal.getAppBackupTaskVO().getPlatformName());
		parameters.add(appBackupTaskVOPortal.getClusterId());
		parameters.add(appBackupTaskVOPortal.getClusterName());
		parameters.add(appBackupTaskVOPortal.getAppBackupTaskVO().getApplicationId());
		parameters.add(appBackupTaskVOPortal.getAppBackupTaskVO().getAppName());
		parameters.add(appBackupTaskVOPortal.getAppBackupTaskVO().getAppVersionId());
		parameters.add(appBackupTaskVOPortal.getAppBackupTaskVO().getAppVersion());
		parameters.add(appBackupTaskVOPortal.getAppBackupTaskVO().getStatus().getStatusValue());
		parameters.add(new Timestamp(appBackupTaskVOPortal.getAppBackupTaskVO().getStartedTime()).toString());
		parameters.add(new Timestamp(appBackupTaskVOPortal.getAppBackupTaskVO().getCompletedTime()).toString());
		parameters.add(new Timestamp(appBackupTaskVOPortal.getAppBackupTaskVO().getCompletedTime()).toString());
		parameters.add(appBackupTaskVOPortal.getAppBackupTaskVO().getStatus().getStatusValue());
		parameters.add(appBackupTaskVOPortal.getAppBackupTaskVO().getArkBackupName());

		String upsertQuery = new AppBackupTaskDB().upsert(appBackupTaskVOPortal);


		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(upsertQuery).addParameters(parameters).build();

		PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);

		return appBackupTaskVOPortal;
	}

	private int mDelete(String arkBackupName) throws SQLException {

		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new AppBackupTaskDB().delete()).addParameter(arkBackupName).build();

		return PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
	}

	/**
	 * Create AppBackupTaskVOPortal object through given Resultset
	 * @param rs
	 * @return AppBackupTaskVOPortal
	 * @throws SQLException 
	 */
	private AppBackupTaskVOPortal setAppBackupTaskObject(ResultSet rs) throws SQLException{

		AppBackupTaskVOPortal appBackupTaskVOPortal = new AppBackupTaskVOPortal();

		AppBackupTaskVO appBackupTaskVO = new AppBackupTaskVO();
		appBackupTaskVO.setBackupTaskId(rs.getString(PortalDBEnum.APP_BACKUP_TASK.backupTaskId.name()));
		appBackupTaskVO.setArkBackupName(rs.getString(PortalDBEnum.APP_BACKUP_TASK.arkBackupName.name()));
		appBackupTaskVO.setPlatformName(rs.getString(PortalDBEnum.APP_BACKUP_TASK.platformName.name()));
		appBackupTaskVO.setApplicationId(rs.getString(PortalDBEnum.APP_BACKUP_TASK.applicationId.name()));
		appBackupTaskVO.setAppName(rs.getString(PortalDBEnum.APP_BACKUP_TASK.appName.name()));
		appBackupTaskVO.setAppVersionId(rs.getString(PortalDBEnum.APP_BACKUP_TASK.appVersionId.name()));
		appBackupTaskVO.setAppVersion(rs.getString(PortalDBEnum.APP_BACKUP_TASK.appVersion.name()));
		appBackupTaskVO.setStatus(AppBackupTaskStatus.byDescription(rs.getInt(PortalDBEnum.APP_BACKUP_TASK.status.name())));
		appBackupTaskVO.setStartedTime(rs.getTimestamp(PortalDBEnum.APP_BACKUP_TASK.startedTime.name()).getTime());
		if(rs.getTimestamp(PortalDBEnum.APP_BACKUP_TASK.completedTime.name()) == null) {
			appBackupTaskVO.setCompletedTime(1);
		} else {
			appBackupTaskVO.setCompletedTime(rs.getTimestamp(PortalDBEnum.APP_BACKUP_TASK.completedTime.name()).getTime());
		}

		appBackupTaskVOPortal.setAppBackupTaskVO(appBackupTaskVO);
		appBackupTaskVOPortal.setClusterId(rs.getString(PortalDBEnum.APP_BACKUP_TASK.clusterId.name()));
		appBackupTaskVOPortal.setClusterName(rs.getString(PortalDBEnum.APP_BACKUP_TASK.clusterName.name()));

		return appBackupTaskVOPortal;
	}
}
