/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal.engine;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.mwp.common.Common;
import com.mwp.common.StringFunctions;
import com.mwp.common.Utils;
import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.common.constant.Constant;
import com.mwp.common.constant.ErrorMessage;
import com.mwp.common.enums.DeviceTypeEnum;
import com.mwp.common.enums.NodeType;
import com.mwp.common.enums.Operator;
import com.mwp.common.enums.OwnershipEnum;
import com.mwp.common.enums.StateEnum;
import com.mwp.common.enums.Status;
import com.mwp.common.vo.ApplicationVO;
import com.mwp.common.vo.AuthorizationsVO;
import com.mwp.common.vo.DeviceNodeVO;
import com.mwp.common.vo.DeviceUtilityVO;
import com.mwp.common.vo.DeviceVO;
import com.mwp.common.vo.DiscoveryDetailsVO;
import com.mwp.common.vo.FilterObject;
import com.mwp.common.vo.LabelVO;
import com.mwp.common.vo.QueryVO;
import com.mwp.logger.PALogger;
import com.mwp.p.common.Constants;
import com.mwp.p.common.PortalCommon;
import com.mwp.p.common.enums.DevicesUtilityFilterType;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.common.enums.PortalDBEnum.DEVICES;
import com.mwp.p.common.enums.PortalDBEnum.DEVICES_NODES_VIEW;
import com.mwp.p.common.enums.PortalDBEnum.NODES;
import com.mwp.p.common.vo.DeviceApplicationVO;
import com.mwp.p.dal.AssignedRelayPortsDB;
import com.mwp.p.dal.BoxStaticsDB;
import com.mwp.p.dal.DeviceApplicationsDB;
import com.mwp.p.dal.DeviceLabelMapDB;
import com.mwp.p.dal.DevicesDB;
import com.mwp.p.dal.DiscoveryDetailsDB;
import com.mwp.p.dal.EdgeCoreGroupsDB;
import com.mwp.p.dal.InstallJobDB;
import com.mwp.p.dal.LockRelayPortsDB;
import com.mwp.p.dal.ValidationInfoDB;
import com.mwp.s.common.enums.UpdateServiceDBEnum;

/**
 * This class executes all queries related to device and node tables. manipulates and return results returned from queries.   
 *
 */
public class DevicesEngine {

	/**
	 * List device of user. 
	 * @param userId user id
	 * @param deviceId if deviceId is empty or null then all devices of user will be listed with nodes otherwise all kubernetes node devices will be list for single cluster with devcieId.
	 * @param isListLabels Also list labels with device objects if this param is true.
	 * @return List<DeviceVO> object with all node devices set in nodes property.
	 * @throws Exception
	 */
	public List<DeviceVO> listDevice(String userId, String deviceId, boolean isListLabels) throws SQLException {
		return listDevice(userId, deviceId,isListLabels, null);
	}


	/**
	 *  List cluster of a user. 
	 * @param userId user id
	 * @return
	 * @throws SQLException
	 * @author PS
	 */
	public List<DeviceVO> listKubenetesClusterForUser(String userId) throws SQLException {		
		return mListDevice(userId, null,false,DeviceTypeEnum.KubernetesCluster);
	}

	/**
	 *  List cluster of a user. 
	 * @param userId user id
	 * @return
	 * @throws SQLException
	 * @author PS
	 */
	public List<DeviceVO> listKubenetesClusterForUser(String userId, String clusterId) throws SQLException {		
		return mListDevice(userId, clusterId,false,DeviceTypeEnum.KubernetesCluster);
	}


	/**
	 * List device of user. 
	 * @param userId user id
	 * @param deviceId if deviceId is empty or null then all devices of user will be listed with nodes otherwise all kubernetes node devices will be list for single cluster with devcieId.
	 * @param isListLabels Also list labels with device objects if this param is true.
	 * @param deviceType deviceType to return specific type of devices deockercompose or kubernetes.if null then all type of devices would return.Note this parameter only used if deviceId null of empty.   
	 * @return List<DeviceVO> object with all node devices set in nodes property.
	 * @throws Exception
	 */
	public List<DeviceVO> listDevice(String userId, String deviceId, boolean isListLabels, DeviceTypeEnum deviceType) throws SQLException {		
		return mListDevice(userId, deviceId,isListLabels,deviceType);
	}

	/**
	 * List all application info, all application that exist on device using paging.
	 * @param pageNo page number
	 * @param pageSize number of applications to be returned in one page of result
	 * @param userId user Id
	 * @param deviceId device Id 
	 * @return hash map of result with keys-> totalPages,  pageNo, pageSize , data.hashmap value of key "data" contains List<DeviceApplicationVO>
	 * @throws Exception
	 */
	public Map<String, Object> listDeviceApplication(int pageNo, int pageSize,String userId, String deviceId) throws SQLException {
		return mListDeviceApplication(pageNo, pageSize, userId, deviceId);
	}

	/**
	 * List all applications of device for given device Id.
	 * @param  authVo
	 * @param deviceId device id 
	 * @return  List<DeviceApplicationVO> 
	 * @throws Exception
	 */
	public List<DeviceApplicationVO> listAllAppOfDevice(AuthorizationsVO authVo, String deviceId) throws SQLException
	{
		return mListAllAppOfDevice(authVo, deviceId);
	}


	public Map<String, Object> listAppOfDevice(String userId, String deviceId,List<FilterObject> filters,int pageNo, int pageSize) throws SQLException
	{
		return mListAppOfDevice(userId, deviceId, filters, pageNo, pageSize);
	}
	/**
	 * 
	 * @param pageNo
	 * @param pageSize
	 * @param userId
	 * @return
	 * @throws Exception
	 */
	public Map<String, Object> listDeviceApplicationForUser(int pageNo, int pageSize,String userId) throws SQLException {
		return mListDeviceApplicationForUser(pageNo, pageSize, userId);
	}
	/**
	 * Add new device.If device type is DockerCompose then the device will be added in default root label.  
	 * @param deviceVO
	 * @return
	 * @throws Exception
	 */
	public DeviceVO addDevice(DeviceVO deviceVO,String networkJson) throws Exception {
		return mAddDevice(deviceVO,networkJson);
	}

	/**
	 * add or update device application in deviceapplicationDB. Exists check is on appId and deviceId keys.
	 * @param deviceApplication
	 * @return
	 * @throws SQLException
	 */
	public DeviceApplicationVO addDeviceApplication(DeviceApplicationVO deviceApplication) throws SQLException{
		return mAddDeviceApplication(deviceApplication);
	}

	/**
	 * This method give boolean result for device exist in db,
	 * corresponding to given userId and deviceId param.
	 * @param deviceId
	 * @param userId
	 * @return boolean
	 */	
	public boolean isDeviceExist(String deviceId, String userId) throws SQLException{
		return mIsdeviceExist(deviceId, userId);
	} 

	/**
	 * This method give boolean result for device exist in db,
	 * corresponding to given deviceId param.
	 * @param deviceId	 
	 * @return boolean
	 */	
	public boolean isDeviceExistsByDeviceId(String deviceId) throws SQLException
	{
		return mIsdeviceExistsByDeviceId(deviceId);
	} 

	/**
	 * This method give boolean result for device exist in db,
	 * corresponding to given macaddress param.
	 * @param macaddress
	 * @return boolean
	 */
	public boolean isDeviceExistByMacAddress(String macaddress) throws SQLException{
		return mIsdeviceExistByMacAddress(macaddress);
	}

	/**
	 * This method give boolean result for device exist in db,
	 * corresponding to given hostname param.
	 * @param macaddress
	 * @return boolean
	 */
	public boolean isHostNameExists(String hostname) throws SQLException{
		return mIsHostnameExists(hostname);
	}

	/**
	 * This method remove device-application relation from deviceApplication, 
	 * and change device status = 'DELETED'.
	 * @param deviceId
	 * @param userId
	 * @return
	 * @throws SQLException 
	 */
	public DeviceVO deleteDeviceApplication(String deviceId, String userId) throws SQLException {
		return mDeleteDeviceApplication(deviceId, userId);
	}

	/**
	 * Delete node device from cluster
	 * @param nodeId node id of device cluster entry.
	 * @param deviceId device id (cluster id)
	 * @param userId user id
	 * @param canDeleteMaster if true then throw error on master device deletion otherwise delete master /node
	 * @return the deleted node object 
	 * @throws SQLException if node to be deleted role is master and   canDeleteMaster is false.
	 */
	public DeviceNodeVO deleteClusterNode(String nodeId, String deviceId, boolean canDeleteMaster) throws SQLException {
		return mDeleteClusterNode(nodeId, deviceId, canDeleteMaster);
	}

	/**
	 * Get all information of device by device id.if device id is of kubernetescluster then the child node devices will set in nodes property.   
	 * @param deviceId
	 * @param setDiscoveryDetails if true then discovery details properties will be set for each device node by joining of discovery details table.
	 * @return DeviceVO object 
	 * @throws SQLException
	 */
	public DeviceVO getDevice(String deviceId, boolean setDiscoveryDetails) throws SQLException {
		return mGetDevice(deviceId, setDiscoveryDetails);
	}


	/**
	 * Get object of active master node object for cluster.
	 * @param nodeId node id
	 * @param setDiscoveryDetails if true then discovery details properties will be set for node by joining of discovery details table.
	 * @return
	 * @throws SQLException
	 */
	public DeviceNodeVO getActiveMasterNode(String deviceId, boolean setDiscoveryDetails) throws SQLException {
		return mGetActiveMasterNode(deviceId, setDiscoveryDetails);
	}

	/**
	 * Get object of device node by nodeid.
	 * @param nodeId node id
	 * @param setDiscoveryDetails if true then discovery details properties will be set for node by joining of discovery details table.
	 * @return
	 * @throws SQLException
	 */
	public DeviceNodeVO getNode(String nodeId, boolean setDiscoveryDetails) throws SQLException {
		return mGetClusterNode(nodeId, setDiscoveryDetails);
	}

	/**
	 * update support token and set to empty for given email  
	 * @param email
	 * @return true if updated successfully.
	 * @throws SQLException 
	 */
	public boolean updateSupprotToken(String email) throws SQLException{		

		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new DevicesDB().updateSupprotToken())
				.addParameter("")
				.addParameterEncrypted(email)
				.build();

		int updateCount = PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
		return updateCount != 0;

	}

	/**
	 * Get device information using hostName then update support token with new random id if support token is empty 
	 * @param email email id
	 * @param hostName host name
	 * @return support token 
	 * @throws Exception 1. if device not found for given host name 2. if fail to update entry
	 *  
	 */
	public String generateSupportToken(String email, String hostName) throws Exception {
		String supportToken = "";
		boolean deviceFound = false;
		String sql = new DevicesDB().getDeviceDetailsUsingHostname();

		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(sql).addParameter(hostName).build();

		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)){
			while (rs.next()){
				supportToken = rs.getString(DEVICES_NODES_VIEW.nodes_supportToken.name());
				deviceFound = true;
			}
		}

		if(!deviceFound){
			throw new Exception("No device found with this Host Name.");
		}
		if(StringFunctions.isNullOrWhitespace(supportToken)){
			supportToken = Utils.randomUUID();

			sql = new DevicesDB().update();

			QueryVO queryVO1 = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
					.appendQuery(sql)
					.addParameter(supportToken)
					.addParameterEncrypted(email)
					.addParameter(hostName)
					.build();

			int updateCount = PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO1);
			if(updateCount == 0){
				throw new Exception("Unable to update devicedetails, please try again.");
			}
		}
		return supportToken;
	}

	/**
	 * Search devices using  filters and paging. 
	 * @param pageNo page number
	 * @param pageSize number of result to be returned in one page of result.  
	 * @param filters (sort, search text, start with, start end, etc.).
	 * @return hash map of result with keys-> totalPages,  pageNo, pageSize , data.hashmap value of key "data" contains List<DeviceVO>
	 * @throws Exception
	 */
	public Map<String, Object> searchDevice(int pageNo, int pageSize, Map<String, Object> filters) throws SQLException {
		HashMap<String, Object> hashOutput = new HashMap<>();
		List<DeviceVO> listDevice = new ArrayList<>();

		List<String> queries = new DevicesDB().searchDevice(filters);
		int offset = (pageNo - 1) * pageSize;

		List<Object> parameters = createFilterObject(filters);
		parameters.add(pageSize);
		parameters.add(offset);

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(queries.get(0)).addParameters(parameters).build();

		QueryVO countQueryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(queries.get(1)).build();

		int totalDeviceCount = 0;
		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO);
				ResultSet rsCount = PortalDatabaseEngine.getInstance().getConnection().executeQuery(countQueryVO)) {
			while (rsCount.next()) {
				totalDeviceCount = rsCount.getInt("rowCount");
			}
			listDevice = setDeviceObjectList(rs, false, false, false, false, false, null);
		}
		int totalPages = totalDeviceCount / pageSize;
		if ((totalDeviceCount % pageSize) > 0) {
			totalPages += 1;
		}
		hashOutput.put(Constant.DATA, listDevice);
		hashOutput.put("totalPages", totalPages);
		hashOutput.put("pageNo", pageNo);
		hashOutput.put("pageSize", pageSize);
		return hashOutput;
	}

	private List<Object> createFilterObject(Map<String, Object> filters){
		List<Object> params = new ArrayList<>();
		if(filters != null){
			for (Iterator iterator = filters.keySet().iterator(); iterator.hasNext();) {
				String filterKey = (String) iterator.next();

				switch(filterKey){
				case "hostName" :
					params.add(filters.get(filterKey).toString());
					break;
				case "deviceId":
					params.add(filters.get(filterKey).toString());
					break;
				case "deviceName":
					params.add(filters.get(filterKey).toString());
					break;
				default:
					break;
				}
			}
		}
		return params;
	}

	public DeviceVO getDeviceByHostName(String hostName) throws SQLException {
		return mGetDeviceByHostName(hostName);
	}

	private DeviceVO mGetDeviceByHostName(String hostName) throws SQLException {
		DeviceVO device = null;

		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new DevicesDB().getDeviceDetailsUsingHostname()).addParameter(hostName).build();

		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)){
			while (rs.next()){
				device = setDeviceObject(rs, false, false);
			}
		}
		return device;
	}

	private DeviceVO mGetDevice(String deviceId, boolean setDiscoveryDetails) throws SQLException {
		DeviceVO device = null;

		QueryVO getDeviceQueryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new DevicesDB().getDevice(deviceId)).addParameter(deviceId).build();

		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(getDeviceQueryVO)){

			List<DeviceVO> listDevice = setDeviceObjectList(rs, setDiscoveryDetails, false, false,false,false,null);
			if(!listDevice.isEmpty())
			{
				return listDevice.get(0);
			}
		}
		return device;
	}

	private DeviceNodeVO mGetClusterNode(String nodeId, boolean setDiscoveryDetails) throws SQLException {
		DeviceNodeVO nodeVO = null;

		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new DevicesDB().getNode()).addParameter(nodeId).build();

		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)){
			if(rs.next())
				nodeVO = setNodeObject(rs, setDiscoveryDetails);
		}
		return nodeVO;
	}

	private DeviceNodeVO mGetActiveMasterNode(String deviceId, boolean setDiscoveryDetails) throws SQLException {
		DeviceNodeVO nodeVO = null;

		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new DevicesDB().getActiveMasterNode()).addParameter(deviceId).build();

		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)){
			if(rs.next())
				nodeVO = setNodeObject(rs, setDiscoveryDetails);
		}
		return nodeVO;
	}

	/**
	 * This method give queries to factory reset the device.Removes device-application relation from deviceApplication,
	 * delete device and all jobs.
	 * if device is not KubernetesCluster then also do following things 
	 * delete it relation entry from tables : validationInfo, discoverydetails, lockrelayports
	 * update status as 2 in assignedrelayports
	 * add activation history with action value as "factoryreset"  
	 * @param deviceId
	 * @param userId
	 * @return
	 */
	private  DeviceVO mDeleteDeviceApplication(String deviceId, String userId) throws SQLException {
		if(mIsdeviceExist(deviceId, userId)){

			//Select Device
			DeviceVO deviceVO = new DevicesEngine().getDevice(deviceId, true);

			List<QueryVO> queries =  new ArrayList<>();		
			if(deviceVO.getDeviceType() == DeviceTypeEnum.KubernetesCluster)
			{
				for (DeviceNodeVO nodeVO : deviceVO.getNodes())
				{
					queries.addAll(mDeleteClusterNodeQueryObject(nodeVO.getNodeId(), deviceId, nodeVO));
				}
			}

			queries.addAll(deleteDeviceApplicationQueryObject(deviceId, userId, deviceVO));

			//			QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
			//					.appendQuery(new VirtualURLDal().deleteDevice()).addParameter(deviceId).build();

			//queries.add(queryVO);

			PortalDatabaseEngine.getInstance().getConnection().executeUpdatesInTransaction(queries);

			return deviceVO;			
		}else{
			throw new SQLException(ErrorMessage.DEVICE_NOT_FOUND);
		}
	}

	/**
	 * This method give queries to factory reset the device.Removes device-application relation from deviceApplication,
	 * delete device and all jobs.
	 * if device is not KubernetesCluster then also do following things 
	 * delete it relation entry from tables : validationInfo, discoverydetails, lockrelayports
	 * update status as 2 in assignedrelayports
	 * add activation history with action value as "factoryreset"  
	 * @param deviceId
	 * @param userId
	 * @return
	 * @throws SQLException 
	 */
	private List<QueryVO> deleteDeviceApplicationQueryObject(String deviceId, String userId, DeviceVO device) throws SQLException{
		List<QueryVO> qry = new ArrayList<>();
		StringBuilder sb = new StringBuilder();
		sb.append("DELETE FROM ");sb.append(PortalDBEnum.TABLE_NAMES.deviceapplications);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.DEVICE_APPLICATIONS.deviceId.name());sb.append(" = ");sb.append("?");

		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(sb.toString()).addParameter(deviceId).build();

		qry.add(queryVO);
		//		/*
		//		 * get query for update device status with deleted status.
		//		 */

		if(device.getDeviceType()  != DeviceTypeEnum.KubernetesCluster)
		{
			// get query for delete validationInfo using macAddress.
			QueryVO validationQueryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
					.appendQuery(new ValidationInfoDB().deleteValidationInfo()).addParameter(device.getNodeVO().getMacAddress()).build();
			qry.add(validationQueryVO);

			QueryVO deleteDiscoveryDetailsQueryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
					.appendQuery(new DiscoveryDetailsDB().delete()).addParameter(device.getNodeVO().getNodeId()).build();
			qry.add(deleteDiscoveryDetailsQueryVO);

			QueryVO updateAssignedPortsStatusQueryVO =  new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
					.appendQuery(new AssignedRelayPortsDB().updateAssignedPortsStatus()).addParameter("2").addParameter(device.getNodeVO().getNodeId()).build();
			qry.add(updateAssignedPortsStatusQueryVO);

			QueryVO deleteLockRelayPortsQueryVO =  new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
					.appendQuery(new LockRelayPortsDB().deleteLockRelayPorts()).addParameter(device.getNodeVO().getNodeId()).build();
			qry.add(deleteLockRelayPortsQueryVO);

			device.getNodeVO().setAction("factoryreset");

			QueryVO addInActivationHistoryQueryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
					.appendQuery(new DevicesDB().addDeviceDetailsInActivationHistory())
					.addParameter(device.getNodeVO().getNodeId())
					.addParameter(userId)
					.addParameter(device.getNodeVO().getMacAddress())
					.addParameter(device.getNodeVO().getMachineId())
					.addParameter(device.getNodeVO().getNativeAppId())
					.addParameter(device.getNodeVO().getAction())
					.build();

			qry.add(addInActivationHistoryQueryVO);

		}
		QueryVO deleteEdgeCoreFromGroupsQueryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new DevicesDB().deleteEdgeCoreFromGroups()).addParameter(deviceId).build();
		qry.add(deleteEdgeCoreFromGroupsQueryVO);

		QueryVO deleteDeviceQueryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new DevicesDB().deleteDevice())
				.addParameter(deviceId)
				.addParameter(userId)
				.build();

		qry.add(deleteDeviceQueryVO);

		QueryVO deleteAllJobsQueryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new InstallJobDB().deleteAllJobs())
				.addParameter(userId)
				.addParameter(deviceId)
				.build();

		qry.add(deleteAllJobsQueryVO);

		return qry;
	}

	private DeviceNodeVO mDeleteClusterNode(String nodeId, String deviceId, boolean canDeleteMaster) throws SQLException 
	{
		PALogger.INFO("********** mDeleteClusterNode ****** nodeId: "+ nodeId + " deviceId: "+deviceId);
		DeviceNodeVO nodeVO = mGetClusterNode(nodeId, true);

		if(nodeVO != null)
		{	
			if(!canDeleteMaster &&  nodeVO.getDeviceRole() == NodeType.MASTER &&  nodeVO.getDeviceState() == StateEnum.Active)
				throw new SQLException(ErrorMessage.MASTER_DELETE_REQUEST);

			PALogger.INFO("**********Start mDeleteClusterNode ******");
			List<QueryVO> queries = mDeleteClusterNodeQueryObject(nodeId, deviceId, nodeVO);
			PortalDatabaseEngine.getInstance().getConnection().executeUpdatesInTransaction(queries);
			PALogger.INFO("**********END mDeleteClusterNode ******");
		}
		return nodeVO;			


	}

	/**
	 * This method give queries for remove device-application relation from deviceApplication.
	 * and change device status = 'DELETED'.
	 * @param deviceId
	 * @param userId
	 * @return
	 */
	private List<QueryVO> mDeleteClusterNodeQueryObject(String nodeId, String deviceId, DeviceNodeVO nodeVO) throws SQLException {
		List<QueryVO> qry = new ArrayList<>();

		QueryVO validationQueryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new ValidationInfoDB().deleteValidationInfo()).addParameter(nodeVO.getMacAddress()).build();
		qry.add(validationQueryVO);


		QueryVO deleteDiscoveryDetailsQueryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new DiscoveryDetailsDB().delete()).addParameter(nodeId).build();
		qry.add(deleteDiscoveryDetailsQueryVO);


		QueryVO updateAssignedPortsStatusQueryVO =  new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new AssignedRelayPortsDB().updateAssignedPortsStatus()).addParameter("2").addParameter(nodeId).build();
		qry.add(updateAssignedPortsStatusQueryVO);


		QueryVO deleteLockRelayPortsQueryVO =  new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new LockRelayPortsDB().deleteLockRelayPorts()).addParameter(nodeId).build();
		qry.add(deleteLockRelayPortsQueryVO);


		QueryVO deleteClusterNodeQueryVO =  new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new DevicesDB().deleteClusterNode()).addParameter(nodeId).addParameter(deviceId).build();
		qry.add(deleteClusterNodeQueryVO);


		return qry;
	}


	/**
	 * This method give boolean result for device exist in db,
	 * corresponding to given userId and deviceId param.
	 * @param deviceId
	 * @param userId
	 * @return
	 */
	private boolean mIsdeviceExist(String deviceId,String userId) throws SQLException
	{
		DevicesDB devicesDB=new DevicesDB();

		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery( devicesDB.isDeviceExist(deviceId, userId))
				.addParameter(deviceId)
				.addParameter(userId).build();

		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			return rs.next();
		}
	}

	/**
	 * This method give boolean result for device exist in db,
	 * corresponding to given deviceId param.
	 * @param deviceId
	 * @return
	 */
	private boolean mIsdeviceExistsByDeviceId(String deviceId) throws SQLException
	{
		DevicesDB devicesDB=new DevicesDB();
		String sql = devicesDB.isDeviceExists();

		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(sql).addParameter(deviceId).build();

		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			return rs.next();
		}
	}


	/**
	 * This method give query which check any device exist in db, corresponding to given deviceIds list.
	 * @param deviceIdList
	 * @return
	 * @author DB, RA
	 */
	private boolean mIsdeviceExists(List<String> deviceIdList) throws SQLException
	{
		DevicesDB devicesDB = new DevicesDB();
		String sql = devicesDB.isDeviceExists(deviceIdList);

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
				.addParameters(deviceIdList).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			return rs.next();
		}
	}



	/**
	 * This method give boolean result for device exist in db,
	 * corresponding to given userId and deviceId param.
	 * @param deviceId
	 * @param userId
	 * @return
	 */
	private boolean mIsdeviceExistByMacAddress(String macaddress) throws SQLException
	{
		DevicesDB devicesDB=new DevicesDB();

		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery( devicesDB.isDeviceExist()).addParameter(macaddress).build();

		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			return rs.next();
		}
	}


	/**
	 * This method give boolean result for device exist in db,
	 * corresponding to given hostname param.
	 * @param deviceId
	 * @return
	 */
	private boolean mIsHostnameExists(String hostname) throws SQLException
	{
		DevicesDB devicesDB=new DevicesDB();
		int count = 0;

		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(devicesDB.isHostnameExist())
				.addParameter(hostname)
				.addParameter(hostname).build();

		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)){
			while(rs.next()){
				count = rs.getInt("count");
			}
		}
		return count>0;
	}

	private DeviceApplicationVO mAddDeviceApplication(DeviceApplicationVO deviceApplication) throws SQLException{
		DeviceApplicationsDB db = new DeviceApplicationsDB();

		List<Object> getDeviceParameters = new ArrayList<>();
		getDeviceParameters.add(deviceApplication.getDeviceId());
		getDeviceParameters.add(deviceApplication.getApplicationId());

		QueryVO queryVOGetDeviceApplication = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(db.getDeviceApplication()).addParameters(getDeviceParameters).build();

		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVOGetDeviceApplication)) {
			if(rs.next()) {

				List<Object> updateDeviceParam = new ArrayList<>();

				updateDeviceParam.add(deviceApplication.getVersion());
				updateDeviceParam.add(deviceApplication.getStatus().ordinal());
				updateDeviceParam.add(deviceApplication.getDeviceId());
				updateDeviceParam.add(deviceApplication.getApplicationId());

				QueryVO updateQueryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
						.appendQuery(db.updateDeviceApplication()).addParameters(updateDeviceParam).build();

				int modifyCount = PortalDatabaseEngine.getInstance().getConnection().executeUpdate(updateQueryVO);
				if(modifyCount == 0){
					throw new SQLException("changing application device details failed.");
				}
			} else {
				deviceApplication.setDeviceApplicationId(Common.getRandomId());
				List<Object> addDeviceAppParameters = new ArrayList<>();
				addDeviceAppParameters.add(deviceApplication.getDeviceApplicationId());
				addDeviceAppParameters.add(deviceApplication.getDeviceId());
				addDeviceAppParameters.add(deviceApplication.getApplicationId());
				addDeviceAppParameters.add(deviceApplication.getVersion());
				addDeviceAppParameters.add(deviceApplication.getStatus().ordinal());

				QueryVO addDeviceAppQueryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
						.appendQuery(db.addDeviceApplication()).addParameters(addDeviceAppParameters).build();


				int insertCount = PortalDatabaseEngine.getInstance().getConnection().executeUpdate(addDeviceAppQueryVO);
				if(insertCount == 0){
					throw new SQLException("adding application to device failed.");
				}
			}
		}
		return deviceApplication;
	}


	/**
	 * update isActivationConfirmed to 1
	 * @param deviceId
	 * @throws Exception 
	 */
	public void updateActivationStatus(String deviceId) throws SQLException 
	{
		mUpdateActivationStatus(deviceId);
	}

	private List<DeviceVO> mListDevice(String userId, String deviceId, boolean isListLabels, DeviceTypeEnum deviceType) throws SQLException {
		List<DeviceVO> listDevice = new ArrayList<>();
		QueryVO queryVO;
		if(StringFunctions.isNullOrWhitespace(deviceId)){

			List<Object> parameters = new ArrayList<>();
			parameters.add(userId);			
			if(deviceType != null)
				parameters.add(deviceType.getValue());

			queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
					.appendQuery(new DevicesDB().listDevice(isListLabels, deviceType))
					.addParameters(parameters)
					.build();		
		}else{
			List<Object> parameters = new ArrayList<>();
			parameters.add(userId);
			parameters.add(deviceId);
			if(deviceType != null)
				parameters.add(deviceType.getValue());

			queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
					.appendQuery(new DevicesDB().listDevice(userId, deviceId, isListLabels, deviceType))
					.addParameters(parameters)
					.build();
		}

		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)){
			listDevice = setDeviceObjectList(rs, true, false, isListLabels,false,false,null);			
		}
		return listDevice;
	}

	private List<String> getDeviceIdsByUserIds(String userId) throws SQLException {
		String sql = new DeviceApplicationsDB().getDeviceIdsByUserId();
		List<String> deviceIds = new ArrayList<>();
		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
				.addParameter(userId).build();
		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				deviceIds.add(rs.getString(PortalDBEnum.DEVICES.deviceId.name()));
			}
		}

		return deviceIds;
	}

	private List<String> getEdgeCoreByGroupIds(List<String> grpIds) throws SQLException {
		if(grpIds == null || grpIds.isEmpty()){
			grpIds = new ArrayList<>();
			grpIds.add("");
		}
		String sql = new EdgeCoreGroupsDB().listEdgeCoreForGroups(grpIds);
		List<String> edgeCoreIds = new ArrayList<>();
		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
				.addParameters(grpIds).build();
		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				edgeCoreIds.add(rs.getString(PortalDBEnum.GROUP_EDGECORE.edgeCoreId.name()));
			}

		}

		return edgeCoreIds;
	}

	private List<DeviceApplicationVO> mListAllAppOfDevice(AuthorizationsVO authVo, String deviceId) throws SQLException
	{
		List<DeviceApplicationVO> listDeviceApp = new ArrayList<>();

		List<String> devicesIds = getDeviceIdsByUserIds(authVo.getUserId());

		List<String> grpIds = null;
		if (authVo.getGroupPermissions() != null) {
			grpIds = new ArrayList<>(authVo.getGroupPermissions().keySet());
		}

		List<String> edgeCoreIds = getEdgeCoreByGroupIds(grpIds);

		if(devicesIds.isEmpty()){
			devicesIds.add("");
		}

		String sql = new DeviceApplicationsDB().listAllAppsOfDevice(deviceId, devicesIds, edgeCoreIds);
		SqlQueryBuilder queryBuilder = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql);

		if (!StringFunctions.isNullOrWhitespace(deviceId)) {
			queryBuilder.addParameter(deviceId);
		} else {
			queryBuilder.addParameters(devicesIds);
		}

		QueryVO queryVO = queryBuilder.addParameters(edgeCoreIds).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {

				DeviceApplicationVO deviceAppVO = new DeviceApplicationVO();
				/*
				 * set basic applicationVO detail.
				 */
				deviceAppVO.setApplicationId(rs.getString(PortalDBEnum.APPLICATION.appId.name()));
				deviceAppVO.setAppTypeId(rs.getString(PortalDBEnum.APPLICATION.appTypeId.name()));
				deviceAppVO.setIcon(rs.getString(PortalDBEnum.APPLICATION.icon.name()));
				if (!StringFunctions.isNullOrWhitespace(deviceAppVO.getIcon())) {
					deviceAppVO.setIcon(PortalCommon.getInstance().createPublicUrl(deviceAppVO.getIcon(),
							Constants.UI_FOLDER_NAME));
				}
				deviceAppVO.setProjectId(rs.getString(PortalDBEnum.APPLICATION.projectId.name()));
				// deviceAppVO.setRepositoryName(rs.getString(PortalDBEnum.APPLICATION.repositoryName.name()));
				// //***pschange***
				deviceAppVO.setTitle(rs.getString(PortalDBEnum.APPLICATION.title.name()));
				deviceAppVO.setUserId(rs.getString(PortalDBEnum.APPLICATION.userId.name()));
				deviceAppVO.setWebAddress(rs.getString(PortalDBEnum.APPLICATION.webAddress.name()));
				deviceAppVO.setAppStatus(Status.GetEnum(rs.getInt(PortalDBEnum.APPLICATION.appStatus.name())));

				// /**
				// * Added APPLICATION_VERSIONS joining to show version number
				// in My Installed Apps - PS bug 548
				// */
				deviceAppVO.setVersionVO(new VersionEngine().setVersionObject(rs));

				// AKH_01, AKH_02
				/*
				 * set deviceId for UI so they use deviceId in getting appdetail
				 * and return deviceApplicationVO object.
				 */
				deviceAppVO.setDeviceId(rs.getString(PortalDBEnum.DEVICE_APPLICATIONS.deviceId.name()));
				deviceAppVO.setVerionId(rs.getString(PortalDBEnum.DEVICE_APPLICATIONS.appVersionId.name()));
				/*
				 * for show on UI device name.
				 */
				deviceAppVO.setDeviceName(rs.getString(PortalDBEnum.DEVICES.deviceName.name()));
				listDeviceApp.add(deviceAppVO);
			}
		}
		return listDeviceApp;
	}


	/**
	 * 
	 * @param userId id of user
	 * @param deviceId
	 * @return hashtable with key := applicatioID, Value:= DeviceApplicationVO
	 * @throws SQLException
	 */
	private Map<String, Object>  mListAppOfDevice(String userId, String deviceId,List<FilterObject> filters,int pageNo, int pageSize) throws SQLException
	{
		HashMap<String,DeviceApplicationVO> listDeviceApp = new HashMap<>();

		List<String> devicesIds = getDeviceIdsByUserIds(userId);

		List<String> sql = new DeviceApplicationsDB().listAllAppsOfDeviceByFilter(deviceId, filters, devicesIds);

		List<Object> parameters = createFilterObject(filters);

		if (!StringFunctions.isNullOrWhitespace(deviceId)) {
			parameters.add(deviceId);
		} else {
			parameters.add(devicesIds);
		}

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql.get(0))
				.addParameters(parameters).build();

		QueryVO countQueryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql.get(1))
				.build();

		HashMap<String, Object>  hashOutput = new HashMap<>();

		int totalAppCount = 0; 
		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO);
				ResultSet rsCount = PortalDatabaseEngine.getInstance().getConnection().executeQuery(countQueryVO)) {
			while (rsCount.next()){
				totalAppCount = rsCount.getInt("rowCount");    
			}
			while (rs.next()){

				String appid = rs.getString(PortalDBEnum.APPLICATION.appId.name());
				String deviceid = rs.getString(PortalDBEnum.DEVICE_APPLICATIONS.deviceId.name());
				if(listDeviceApp.containsKey(appid))// to show count of Devices where application installed.
				{
					listDeviceApp.get(appid).getDeviceIds().add(deviceId);
				}
				else
				{
					DeviceApplicationVO deviceAppVO = new DeviceApplicationVO();
					/*
					 * set basic applicationVO detail.
					 */
					deviceAppVO.setApplicationId(appid);
					deviceAppVO.setAppTypeId(rs.getString(PortalDBEnum.APPLICATION.appTypeId.name()));
					deviceAppVO.setIcon(rs.getString(PortalDBEnum.APPLICATION.icon.name()));
					if(!StringFunctions.isNullOrWhitespace(deviceAppVO.getIcon())){
						deviceAppVO.setIcon(PortalCommon.getInstance().createPublicUrl(deviceAppVO.getIcon(), Constants.UI_FOLDER_NAME));
					}
					deviceAppVO.setProjectId(rs.getString(PortalDBEnum.APPLICATION.projectId.name()));
					//			deviceAppVO.setRepositoryName(rs.getString(PortalDBEnum.APPLICATION.repositoryName.name()));	//***pschange***
					deviceAppVO.setTitle(rs.getString(PortalDBEnum.APPLICATION.title.name()));
					deviceAppVO.setUserId(rs.getString(PortalDBEnum.APPLICATION.userId.name()));
					deviceAppVO.setWebAddress(rs.getString(PortalDBEnum.APPLICATION.webAddress.name()));
					//AKH_01, AKH_02
					/*
					 * set deviceId for UI so they use deviceId in getting appdetail and return deviceApplicationVO object.
					 */
					deviceAppVO.setDeviceId(deviceid);
					deviceAppVO.setVerionId(rs.getString(PortalDBEnum.DEVICE_APPLICATIONS.appVersionId.name()));
					/*
					 * for show on UI device name.
					 */
					deviceAppVO.setDeviceName(rs.getString(PortalDBEnum.DEVICES.deviceName.name()));
					listDeviceApp.put(deviceAppVO.getApplicationId(), deviceAppVO);
				}

			}
		}

		int totalPages = totalAppCount / pageSize;
		if((totalAppCount % pageSize) > 0){
			totalPages += 1;			
		}
		hashOutput.put(Constant.DATA, listDeviceApp);
		hashOutput.put("totalPages", totalPages);
		hashOutput.put("pageNo", pageNo);
		hashOutput.put("pageSize", pageSize);

		return hashOutput;
	}


	private List<Object> createFilterObject(List<FilterObject> filters){
		String searchString = "";
		List<Object> parameters = new ArrayList<>();
		SqlQueryBuilder queryBuilder = new SqlQueryBuilder();
		if (filters != null) {
			for (FilterObject filterObject : filters) {
				switch (filterObject.getFilterType()) {
				case SEARCHTEXT: 
					if (filterObject.getOperator().ordinal() == Operator.LIKE.ordinal()) {
						searchString = filterObject.getStartValue();
						queryBuilder.addParameterForLike(true, searchString, true);
					} else if (filterObject.getOperator().ordinal() == Operator.EQUAL.ordinal()) {
						queryBuilder.addParameter(filterObject.getStartValue());
					}
					break;
				case SORT: 
					if (filterObject.getStartValue().trim().equals("title")) {

						// Here assuming that we will always add search filter
						// before the sort filter.
						if (searchString.equals("")) {

						} else {
							queryBuilder.addParameter(searchString);
							queryBuilder.addParameterForLike(false, searchString, true);
							queryBuilder.addParameterForLike(true, searchString, false);
						}
					}
					break;
				default:
					break;
				}
			}
		}
		return parameters;
	}



	/**
	 * getting application info, all application which are exist on device.
	 * @param pageNo
	 * @param pageSize
	 * @param userId
	 * @param deviceId
	 * @return
	 */
	private HashMap<String, Object> mListDeviceApplication(int pageNo, int pageSize, String userId, String deviceId) throws SQLException {
		/*
		 * hash object which is return to UI contains: 
		 * DATA-list of DeviceApplication Object
		 * totalPages
		 * pageNo
		 * pageSize
		 */
		HashMap<String, Object> hashOutput = new HashMap<>();
		/*
		 * object of list DeviceApplication which is set by querying.
		 */
		List<DeviceApplicationVO> listDeviceApp = new ArrayList<>();

		/*
		 * getting queries from DeviceApplicationDB 
		 * (deviceId (optional) - getting all application of required device).
		 * (userId - if deviceId = empty/null then list application of user's all devices).
		 *  
		 */

		int offset = (pageNo-1) * pageSize;

		List<Object> parameters = new ArrayList<>();
		if (!StringFunctions.isNullOrWhitespace(deviceId)) {
			parameters.add(deviceId);
		} else {
			parameters.add(userId);
		}
		parameters.add(pageSize);
		parameters.add(offset);

		QueryVO queryVOData = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new DeviceApplicationsDB().listDeviceApplication(deviceId).get(0))
				.addParameters(parameters).build();


		QueryVO queryVOCount = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new DeviceApplicationsDB().listDeviceApplication(deviceId).get(1))
				.build();


		int totalCategoryCount = 0;

		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVOData);
				ResultSet rsCount = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVOCount)) {
			while (rsCount.next()) {
				if (totalCategoryCount <= 0) {
					/*
					 * getting total no of rows without page limit.
					 */
					totalCategoryCount = rsCount.getInt("appCount");
				}
			}
			while (rs.next()) {

				DeviceApplicationVO deviceAppVO = new DeviceApplicationVO();
				/*
				 * set basic applicationVO detail.
				 */
				deviceAppVO.setApplicationId(rs.getString(PortalDBEnum.APPLICATION.appId.name()));
				deviceAppVO.setAppStatus(Status.GetEnum(rs.getInt(PortalDBEnum.APPLICATION.appStatus.name())));
				deviceAppVO.setAppTypeId(rs.getString(PortalDBEnum.APPLICATION.appTypeId.name()));
				deviceAppVO.setIcon(rs.getString(PortalDBEnum.APPLICATION.icon.name()));
				if (!StringFunctions.isNullOrWhitespace(deviceAppVO.getIcon())) {
					deviceAppVO.setIcon(PortalCommon.getInstance().createPublicUrl(deviceAppVO.getIcon(),
							Constants.UI_FOLDER_NAME));
				}
				deviceAppVO.setProjectId(rs.getString(PortalDBEnum.APPLICATION.projectId.name()));
				deviceAppVO.setTitle(rs.getString(PortalDBEnum.APPLICATION.title.name()));
				deviceAppVO.setUserId(rs.getString(PortalDBEnum.APPLICATION.userId.name()));
				deviceAppVO.setWebAddress(rs.getString(PortalDBEnum.APPLICATION.webAddress.name()));
				// AKH_01, AKH_02
				/*
				 * set deviceId for UI so they use deviceId in getting appdetail
				 * and return deviceApplicationVO object.
				 */
				deviceAppVO.setDeviceId(rs.getString(PortalDBEnum.DEVICE_APPLICATIONS.deviceId.name()));
				/*
				 * for show on UI device name.
				 */
				deviceAppVO.setDeviceName(rs.getString(PortalDBEnum.DEVICES.deviceName.name()));
				listDeviceApp.add(deviceAppVO);
			}

		}
		/*
		 * calculate total pages count send to UI for next iteration.
		 */
		int totalPages = totalCategoryCount / pageSize;
		if((totalCategoryCount % pageSize) > 0){
			totalPages += 1;			
		}
		hashOutput.put(Constant.DATA, listDeviceApp);
		hashOutput.put("totalPages", totalPages);
		hashOutput.put("pageNo", pageNo);
		hashOutput.put("pageSize", pageSize);

		return hashOutput;
	}

	/**
	 * Get mac address from db 
	 * @param deviceName
	 * @throws SQLException 
	 */
	public String getMacAddress(String deviceName) throws SQLException {

		return mGetMacAddress(deviceName);

	}

	/**
	 * Get PlatformId from db 
	 * @param deviceId
	 * @throws SQLException 
	 */
	public String getPlatformId(String deviceId) throws SQLException {

		return mGetPlatformId(deviceId);

	}


	/**
	 * Get device type for device id 
	 * @param deviceId
	 * @return
	 * @throws SQLException
	 */
	public DeviceTypeEnum getDeviceType(String deviceId) throws SQLException {
		return mGetDeviceType(deviceId);
	}
	/**
	 * get owner id of device
	 * @param deviceId
	 * @return
	 * @throws SQLException
	 */
	public String getUserId(String deviceId) throws SQLException {
		return mGetUserId(deviceId);
	}


	/**
	 * this method return true if all devices belong to same owner else false
	 * @param deviceIds
	 * @param userId
	 * @return
	 * @throws SQLException
	 */
	public boolean isSameOwnerDevice(List<String> deviceIds,String userId) throws SQLException
	{
		return mIsSameOwnerDevice(deviceIds, userId);
	}

	public Map<String, String> getDevicesOwner(List<String> deviceIds) throws SQLException {
		return mGetDevicesOwner(deviceIds);
	}
	/**
	 * Get device object for given mac address
	 * @param macAddress
	 * @return
	 * @throws SQLException
	 */
	public DeviceVO getDeviceDetails(String macAddress) throws SQLException {

		return mGetDeviceDetails(macAddress);
	}

	/**
	 * Insert device details in activation history
	 * @param deviceVO
	 * @throws SQLException
	 */
	public void addDeviceDetailsInActivationHistory(DeviceVO deviceVO) throws SQLException {
		mAddDeviceDetailsInActivationHistory(deviceVO);
	}

	private Map<String, Object> mListDeviceApplicationForUser(int pageNo, int pageSize, String userId) throws SQLException {
		HashMap<String, Object> hashOutput = new HashMap<>();
		List<ApplicationVO> listApplication = new ArrayList<>();

		QueryVO queryVOData = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new DeviceApplicationsDB().listDeviceApplicationForUser().get(0))
				.addParameter(userId).build();

		QueryVO queryVOCount = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new DeviceApplicationsDB().listDeviceApplicationForUser().get(1))
				.addParameter(userId).build();

		int totalAppCount = 0; 

		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVOData);
				ResultSet rsCount = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVOCount)){
			while (rsCount.next()){
				if(totalAppCount <= 0){
					totalAppCount = rsCount.getInt("appCount");
				}
			}
			while (rs.next()){
				listApplication.add(new ApplicationsEngine().setApplicationObject(rs));
			}		

		}

		int totalPages = totalAppCount / pageSize;
		if((totalAppCount % pageSize) > 0){
			totalPages += 1;			
		}
		hashOutput.put(Constant.DATA, listApplication);
		hashOutput.put("totalPages", totalPages);
		hashOutput.put("pageNo", pageNo);
		hashOutput.put("pageSize", pageSize);
		return hashOutput;
	}

	private DeviceVO mAddDevice(DeviceVO deviceVO,String networkJson) throws Exception {
		ArrayList<QueryVO> queryVOList = new ArrayList<>();

		DevicesDB devicesDB = new DevicesDB();
		List<String> Queries = devicesDB.addDevice();

		QueryVO queryVODevice = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(Queries.get(0)).addParameters(insertIntoDevicesParameterList(deviceVO)).build();

		QueryVO queryVONode = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(Queries.get(1)).addParameters(insertIntoNodesParameterList(deviceVO, networkJson)).build();

		/**
		 * Add device query
		 */
		queryVOList.add(queryVODevice);
		/**
		 * Add in node table query
		 */
		queryVOList.add(queryVONode);

		if(deviceVO.getDeviceType() == DeviceTypeEnum.DockerCompose)
		{
			LabelEngine labelEngine = new LabelEngine();
			String rootId = labelEngine.getRootId(deviceVO.getUserId());
			if(StringFunctions.isNullOrWhitespace(rootId))
			{	
				LabelVO labelRoot = labelEngine.addRoot(deviceVO.getUserId());
				rootId = labelRoot.getLabelId();
			}
			//if root exist for this user then insert this entry in root otherwise add label
			DeviceLabelMapDB deviceMap = new DeviceLabelMapDB();
			if(!getDeviceLabelExist(deviceVO.getDeviceId(), rootId)){

				List<Object> parameters = new ArrayList<>();
				parameters.add(rootId);
				parameters.add( deviceVO.getDeviceId());	

				QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
						.appendQuery(deviceMap.addDeviceLabel()).addParameters(parameters).build();

				/**
				 * Add device label query
				 */
				queryVOList.add(queryVO);
			}
		}	
		PortalDatabaseEngine.getInstance().getConnection().executeUpdatesInTransaction(queryVOList);

		return deviceVO;
	}


	/**
	 * check if device is exists in a label or not.
	 * @param deviceId
	 * @param labelId
	 * @return true if device exist in label false otherwise.
	 * @throws Exception 
	 */
	public boolean getDeviceLabelExist(String deviceId, String labelId) throws SQLException{
		boolean isExist = false;
		String sql = new DeviceLabelMapDB().getDeviceLabel();

		List<Object> parameters = new ArrayList<>();
		parameters.add(deviceId);
		parameters.add(labelId);	

		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(sql).addParameters(parameters).build();

		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)){
			while (rs.next()){
				isExist = true;
			}
		} 
		return isExist;
	}

	private void mUpdateActivationStatus(String deviceId) throws SQLException
	{
		DevicesDB devicesDB = new DevicesDB();

		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery( devicesDB.updateActivationStatus()).addParameter(deviceId).build();

		int updateCount = PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
		if(updateCount == 0){
			throw new SQLException("update device failed.");
		}

	}
	private String mGetMacAddress(String deviceName) throws SQLException {

		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new DevicesDB().getMacaddress()).addParameter(deviceName).addParameter(deviceName).build();

		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)){
			while (rs.next()){
				return rs.getString(DEVICES_NODES_VIEW.nodes_macAddress.name());
			}
		}
		return "";
	}

	private String mGetPlatformId(String deviceId) throws SQLException {

		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new DevicesDB().getPlatformId()).addParameter(deviceId).build();

		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)){
			while (rs.next()){
				return rs.getString(DEVICES.platformId.name());
			}
		}

		return "";
	}

	private DeviceTypeEnum mGetDeviceType(String deviceId) throws SQLException {

		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new DevicesDB().getDeviceType()).addParameter(deviceId).build();


		DeviceTypeEnum deviceType = DeviceTypeEnum.DockerCompose;

		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)){
			while (rs.next())
			{
				deviceType = DeviceTypeEnum.GetEnum(rs.getInt(DEVICES.deviceType.name()));
			}
		}	

		return deviceType;
	}



	private String mGetUserId(String deviceId) throws SQLException {

		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new DevicesDB().getUserIdOfDevice()).addParameter(deviceId).build();

		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)){
			while (rs.next()){
				return rs.getString(DEVICES.userId.name());
			}
		}
		return "";
	}


	private boolean mIsSameOwnerDevice(List<String> deviceIds,String userId) throws SQLException
	{

		int count = 0;
		String sql = new DevicesDB().isSameOwnerDevice(deviceIds);

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
				.addParameter(userId).addParameters(deviceIds).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				count = rs.getInt("count");
			}
			if (deviceIds.size() == count)
				return true;
		}

		return false;
	}
	/**
	 * 
	 * @param deviceIds
	 * @return hashmap of deviceid as key and owner as value
	 * @throws SQLException
	 */
	private HashMap<String, String> mGetDevicesOwner(List<String> deviceIds) throws SQLException {

		HashMap<String, String> mapreturn = new HashMap<>();
		String sql = new DevicesDB().getDevicesOwners(deviceIds);

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
				.addParameters(deviceIds).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				mapreturn.put(rs.getString(DEVICES.deviceId.name()), rs.getString(DEVICES.userId.name()));
			}
		}

		return mapreturn;
	}

	private DeviceVO mGetDeviceDetails(String macAddress) throws SQLException {

		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery( new DevicesDB().getDeviceDetails()).addParameter(macAddress).build();


		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)){

			List<DeviceVO> listDevice = setDeviceObjectList(rs, false, false, false,false,false,null);
			if(!listDevice.isEmpty())
			{
				return listDevice.get(0);
			}
		}

		return null;
	}

	private void mAddDeviceDetailsInActivationHistory(DeviceVO deviceVO) throws SQLException {
		String sql = new DevicesDB().addDeviceDetailsInActivationHistory();

		DeviceNodeVO deviceNodeVO = deviceVO.getNodeVO();
		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
				.addParameter(deviceNodeVO.getNodeId()).addParameter(deviceVO.getUserId())
				.addParameter(deviceNodeVO.getMacAddress()).addParameter(deviceNodeVO.getMachineId())
				.addParameter(deviceNodeVO.getNativeAppId()).addParameter(deviceNodeVO.getAction()).build();

		int updateCount = PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
		if (updateCount == 0) {
			throw new SQLException("activation history not added.");
		}
	}


	/**
	 * AuthorizationsVO authVo,
	 * @param rs
	 * @param setDiscoveryDetails
	 * @param setLabelId
	 * @param isListLabels set label ids 
	 * @param setVersion
	 * @param toParseGrpPermission (will set list of permission for given device,list of groupIds to which device is invited)
	 * @param authVo use only if toParseGrpPermission is set true
	 * @return
	 * @throws SQLException
	 */
	protected List<DeviceVO> setDeviceObjectList(ResultSet rs, boolean setDiscoveryDetails, boolean setLabelId, boolean isListLabels,boolean setVersion, boolean toParseGrpPermission, AuthorizationsVO authVo) throws SQLException
	{	
		LinkedHashMap<String, DeviceVO> hashDeviceVO = new LinkedHashMap<>();
		HashMap<String, String> hashNodeIds = new HashMap<>();
		HashMap<String, String> hashDeviceLabelIds = new HashMap<>();
		while (rs.next()) 
		{		
			String deviceId =rs.getString(PortalDBEnum.DEVICES_NODES_VIEW.devices_deviceId.name());

			if(hashDeviceVO.containsKey(deviceId))
			{
				if(setVersion)
				{
					String version = rs.getString(UpdateServiceDBEnum.APP_GROUP_RELEASE.version.name());
					if(!hashDeviceVO.get(deviceId).getAvailableVersion().contains(version))
						hashDeviceVO.get(deviceId).getAvailableVersion().add(version);
				}
				if(toParseGrpPermission && !authVo.getUserId().equals(hashDeviceVO.get(deviceId).getUserId()))
				{
					String groupId = rs.getString("groupId");
					if(!StringFunctions.isNullOrWhitespace(groupId) && !hashDeviceVO.get(deviceId).getGroups().contains(groupId))
					{
						hashDeviceVO.get(deviceId).getGroups().add(groupId);
						hashDeviceVO.get(deviceId).setInvitee(true);
						for (String permission : authVo.getGroupPermissions().get(groupId)) 
						{
							if(!hashDeviceVO.get(deviceId).getPermissions().contains(permission))
								hashDeviceVO.get(deviceId).getPermissions().add(permission);
						}
					}



				}

				String nodeId = rs.getString(DEVICES_NODES_VIEW.nodes_nodeId.name());
				if(!hashNodeIds.containsKey(nodeId)){
					DeviceNodeVO nodeVO = setNodeObjectForView(rs, setDiscoveryDetails);
					hashDeviceVO.get(deviceId).getNodes().add(nodeVO);
					hashNodeIds.put(nodeVO.getNodeId(), deviceId);
				}
				if(setLabelId) {
					hashDeviceVO.get(deviceId).setLabelId(rs.getString(PortalDBEnum.LABELS.labelId.name()));
				}
				if(isListLabels){
					String labelId = rs.getString(PortalDBEnum.LABELS.labelId.name());
					if(!StringFunctions.isNullOrWhitespace(labelId) && !hashDeviceLabelIds.containsKey(deviceId + "-px-" +  labelId)){
						if(!labelId.equals(Constant.ROOT_LABEL_ID))
							hashDeviceVO.get(deviceId).getLstLabels().add(labelId);
						hashDeviceLabelIds.put(deviceId + "-px-" +  labelId, labelId);
					}
				}
			}
			else
			{			
				DeviceVO deviceVO = setDeviceObject(rs, setDiscoveryDetails, setVersion);
				if(toParseGrpPermission && !authVo.getUserId().equals(deviceVO.getUserId()))
				{
					String groupId = rs.getString("groupId");
					if(!StringFunctions.isNullOrWhitespace(groupId))
					{
						deviceVO.setPermissions(authVo.getGroupPermissions().get(groupId));
						deviceVO.setInvitee(true);
						List<String> groups = new ArrayList<>();
						groups.add(groupId);
						deviceVO.setGroups(groups);
					}

				}

				hashDeviceVO.put(deviceVO.getDeviceId(), deviceVO);
				String nodeId = rs.getString(DEVICES_NODES_VIEW.nodes_nodeId.name());
				hashNodeIds.put(nodeId, deviceId);
				if(setLabelId) {
					hashDeviceVO.get(deviceId).setLabelId(rs.getString(PortalDBEnum.LABELS.labelId.name()));
				}
				if(isListLabels){
					String labelId = rs.getString(PortalDBEnum.LABELS.labelId.name());
					if(!StringFunctions.isNullOrWhitespace(labelId)){
						if(!labelId.equals(Constant.ROOT_LABEL_ID))
							hashDeviceVO.get(deviceId).getLstLabels().add(labelId);
						hashDeviceLabelIds.put(deviceId + "-px-" +  labelId, labelId);
					}
				}
			}
		}
		return new ArrayList<>(hashDeviceVO.values());
	}


	public DeviceVO setDeviceObject(ResultSet rs, boolean setDicoveryDetails, boolean setVersion) throws SQLException
	{	
		DeviceVO deviceVO = new DeviceVO();
		DeviceTypeEnum deviceType = DeviceTypeEnum.GetEnum(rs.getInt(DEVICES_NODES_VIEW.devices_deviceType.name()));

		deviceVO.setDeviceId(rs.getString(DEVICES_NODES_VIEW.devices_deviceId.name()));
		deviceVO.setDeviceName(rs.getString(DEVICES_NODES_VIEW.devices_deviceName.name()));			
		deviceVO.setUserId(rs.getString(DEVICES_NODES_VIEW.devices_userId.name()));			
		deviceVO.setDescription(rs.getString(DEVICES_NODES_VIEW.devices_description.name()));
		deviceVO.setDeviceStatus(Status.GetEnum(rs.getInt(DEVICES_NODES_VIEW.devices_deviceStatus.name())));			
		deviceVO.setTags(rs.getString(DEVICES_NODES_VIEW.devices_tags.name()));			
		deviceVO.setPlatformId(rs.getString(DEVICES_NODES_VIEW.devices_platformId.name()));
		deviceVO.setSwPlatformId(rs.getString(DEVICES_NODES_VIEW.devices_swPlatformId.name()));
		deviceVO.setActivationConfirmed(rs.getBoolean(DEVICES_NODES_VIEW.devices_isActivationConfirmed.name()));
		deviceVO.setCreatedDate(rs.getTimestamp(DEVICES_NODES_VIEW.devices_createdDate.name()).getTime());
		deviceVO.setModifiedDate(rs.getTimestamp(DEVICES_NODES_VIEW.devices_modifiedDate.name()).getTime());
		deviceVO.setDeviceType(deviceType);

		deviceVO.getNodes().add(setNodeObjectForView(rs, setDicoveryDetails));
		if(setVersion)
		{
			List<String> avilVersions= new ArrayList<>();
			avilVersions.add(rs.getString(UpdateServiceDBEnum.APP_GROUP_RELEASE.version.name()));
			deviceVO.setAvailableVersion(avilVersions);
		}


		return deviceVO;
	}

	public DeviceNodeVO setNodeObjectForView(ResultSet rs, boolean setDiscoveryDetails) throws SQLException
	{

		DeviceNodeVO nodeVO = new DeviceNodeVO();	
		nodeVO.setNodeId(rs.getString(DEVICES_NODES_VIEW.nodes_nodeId.name()));
		nodeVO.setDeviceName(rs.getString(DEVICES_NODES_VIEW.nodes_deviceName.name()));
		nodeVO.setSwVersion(rs.getString(DEVICES_NODES_VIEW.nodes_softwareVersion.name()));
		nodeVO.setHwProfile(rs.getString(DEVICES_NODES_VIEW.nodes_hardwareInfo.name()));
		nodeVO.setHostName(rs.getString(DEVICES_NODES_VIEW.nodes_hostName.name()));		
		nodeVO.setMacAddress(rs.getString(DEVICES_NODES_VIEW.nodes_macAddress.name()));
		nodeVO.setMachineId(rs.getString(DEVICES_NODES_VIEW.nodes_machineId.name()));
		nodeVO.setAction(rs.getString(DEVICES_NODES_VIEW.nodes_action.name()));
		nodeVO.setDeviceRole(NodeType.values()[rs.getInt(DEVICES_NODES_VIEW.nodes_deviceRole.name())]);	
		nodeVO.setDeviceState(StateEnum.values()[rs.getInt(DEVICES_NODES_VIEW.nodes_deviceState.name())]);
		nodeVO.setDeviceId(rs.getString(DEVICES_NODES_VIEW.nodes_deviceId.name()));
		nodeVO.setCreatedDate(rs.getTimestamp(DEVICES_NODES_VIEW.nodes_createdDate.name()).getTime());
		nodeVO.setModifiedDate(rs.getTimestamp(DEVICES_NODES_VIEW.nodes_modifiedDate.name()).getTime());
		nodeVO.setNativeAppId(rs.getString(DEVICES_NODES_VIEW.nodes_nativeAppId.name()));

		//Set also discovery details of device
		if(setDiscoveryDetails)
		{
			DiscoveryDetailsVO discoveryDetailsVO = new DiscoveryDetailsEngine().getDiscoveryDetailsVO(nodeVO.getNodeId(), false);
			nodeVO.setDiscoveryDetailsVO(discoveryDetailsVO);
		}
		return nodeVO;
	}


	private DeviceNodeVO setNodeObject(ResultSet rs, boolean setDiscoveryDetails) throws SQLException
	{
		DeviceNodeVO nodeVO = new DeviceNodeVO();	
		nodeVO.setNodeId(rs.getString(NODES.nodeId.name()));
		nodeVO.setDeviceName(rs.getString(NODES.deviceName.name()));
		nodeVO.setSwVersion(rs.getString(NODES.softwareVersion.name()));
		nodeVO.setHwProfile(rs.getString(NODES.hardwareInfo.name()));
		nodeVO.setHostName(rs.getString(NODES.hostName.name()));
		nodeVO.setMacAddress(rs.getString(NODES.macAddress.name())); 		
		nodeVO.setMachineId(rs.getString(NODES.machineId.name()));
		nodeVO.setAction(rs.getString(NODES.action.name()));
		nodeVO.setDeviceRole(NodeType.values()[rs.getInt(NODES.deviceRole.name())]);			
		nodeVO.setDeviceState(StateEnum.values()[rs.getInt(NODES.deviceState.name())]);
		nodeVO.setDeviceId(rs.getString(NODES.deviceId.name()));
		nodeVO.setCreatedDate(rs.getTimestamp(NODES.createdDate.name()).getTime());
		nodeVO.setModifiedDate(rs.getTimestamp(NODES.modifiedDate.name()).getTime());
		nodeVO.setNativeAppId(rs.getString(NODES.nativeAppId.name()));

		//Set also discovery details of device
		if(setDiscoveryDetails)
		{
			DiscoveryDetailsVO discoveryDetailsVO = new DiscoveryDetailsEngine().getDiscoveryDetailsVO(nodeVO.getNodeId(), false);
			nodeVO.setDiscoveryDetailsVO(discoveryDetailsVO);
		}
		return nodeVO;
	}



	/**
	 * Get parent cluster name from node ndoe id
	 * @param nodeId
	 * @return
	 */
	public String getClusterName(String nodeId) throws SQLException
	{
		String clusterName = null;
		String sql = new DevicesDB().getClusterName();

		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(sql).addParameter(nodeId).build();


		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO))
		{	
			if(rs.next()){	
				clusterName = rs.getString(PortalDBEnum.DEVICES_NODES_VIEW.devices_deviceName.name());
			}
		}

		return clusterName;
	}

	/**
	 * List all devices along with boxStaticsModifiedDate, latest boxStatics ,latest appInstallTime , dHBRdate to use in utility that shows devices info using paging.
	 * Basically this method is used to analyze the behavior of devices.  
	 * @param pageNo page number 
	 * @param pageSize number of applications to be returned in one page of result.
	 * @param userId user Id
	 * @return hash map of result with keys-> totalPages,  pageNo, pageSize , data.hashmap value of key "data" contains List<DeviceUtilityVO> 
	 * @throws Exception
	 */
	public Map<String, Object> listDevicesUtility(int pageNo, int pageSize, String userId) throws SQLException
	{
		return mListDevicesUtility(pageNo, pageSize, userId);	
	}

	private Map<String, Object> mListDevicesUtility(int pageNo, int pageSize , String userId) throws SQLException {

		/*
		 * hash object wshich is return to UI contains:
		 * totalPages
		 * pageNo
		 * pageSize
		 */
		HashMap<String, Object> hashOutput = new HashMap<>();

		List<DeviceUtilityVO> listDeviceUtlity = new ArrayList<>();

		int offset = (pageNo-1) * pageSize;

		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery( new DevicesDB().listDevicesUtility())
				.addParameter(userId)
				.addParameter(pageSize)
				.addParameter(offset)
				.build();

		/*
		 * execute query for listing deviceapplication according to page limit.
		 * execute query for getting all rows count without limit.
		 */	

		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)){

			while (rs.next()){

				DeviceUtilityVO deviceUtilityVO = new DeviceUtilityVO();

				deviceUtilityVO.setDeviceVO(setDeviceObject(rs, false, false));

				if(rs.getTimestamp(PortalDBEnum.DISCOVERY_DETAILS.dHBRdate.name()) != null)
					deviceUtilityVO.setdHBRdate(rs.getTimestamp(PortalDBEnum.DISCOVERY_DETAILS.dHBRdate.name()).getTime());

				if(rs.getTimestamp("bs_" + PortalDBEnum.BOX_STATICS.modifiedDate) != null)
					deviceUtilityVO.setBoxStaticsModifiedDate(rs.getTimestamp("bs_" + PortalDBEnum.BOX_STATICS.modifiedDate).getTime());

				if(rs.getTimestamp("da_" + PortalDBEnum.DEVICE_APPLICATIONS.modifiedDate)  != null)
					deviceUtilityVO.setAppInstallTime(rs.getTimestamp("da_" + PortalDBEnum.DEVICE_APPLICATIONS.modifiedDate).getTime());

				deviceUtilityVO.setBoxStatics(rs.getString("bs_" + PortalDBEnum.BOX_STATICS.statics));

				listDeviceUtlity.add(deviceUtilityVO);
			}	
		}

		hashOutput.put(Constant.DATA, listDeviceUtlity);
		hashOutput.put("NextPage", String.valueOf(listDeviceUtlity.size() >= pageSize));
		hashOutput.put("pageNo", pageNo);
		hashOutput.put("pageSize", pageSize);

		return hashOutput;

	}


	/**
	 * Search all devices along with boxStaticsModifiedDate, latest boxStatics ,latest appInstallTime , dHBRdate to use in utility that shows devices info using paging.
	 * Basically this method is used to analyze the behavior of devices.  
	 * @param pageNo page number 
	 * @param pageSize number of applications to be returned in one page of result.
	 * @param userId user Id
	 * @param filters filters keys can be "dHBRDate" , "DeviceId" , "BSModifiedDate", "appInstallTime" and value can have start and end value of all the keys.  
	 * @return hash map of result with keys-> totalPages,  pageNo, pageSize , data.hashmap value of key "data" contains List<DeviceUtilityVO> 
	 * @throws Exception
	 */
	public Map<String, Object> searchDevicesUtility(int pageNo, int pageSize, String userId, Map<String,String> filters) throws SQLException
	{
		return mSearchDevicesUtility(pageNo, pageSize, userId,filters);	
	}

	private Map<String, Object> mSearchDevicesUtility(int pageNo, int pageSize , String userId, Map<String,String> filters) throws SQLException 
	{
		HashMap<String, Object> hashOutput = new HashMap<>();

		List<DeviceUtilityVO> listDeviceUtlity = new ArrayList<>();

		String sql = new DevicesDB().searchDevicesUtility(filters);
		List<Object> parameters = createDeviceUtillityFilterObject(filters);

		int offset = (pageNo - 1) * pageSize;

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
				.addParameter(userId).addParameters(parameters).addParameter(pageSize).addParameter(offset)
				.build();

		PALogger.INFO("SQL :" + sql);
		/*
		 * execute query for listing deviceapplication according to page limit.
		 */
		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {

			while (rs.next()) {

				DeviceUtilityVO deviceUtilityVO = new DeviceUtilityVO();

				deviceUtilityVO.setDeviceVO(setDeviceObject(rs, false, false));

				if (rs.getTimestamp(PortalDBEnum.DISCOVERY_DETAILS.dHBRdate.name()) != null)
					deviceUtilityVO
					.setdHBRdate(rs.getTimestamp(PortalDBEnum.DISCOVERY_DETAILS.dHBRdate.name()).getTime());

				if (rs.getTimestamp("bs_" + PortalDBEnum.BOX_STATICS.modifiedDate) != null)
					deviceUtilityVO.setBoxStaticsModifiedDate(
							rs.getTimestamp("bs_" + PortalDBEnum.BOX_STATICS.modifiedDate).getTime());

				if (rs.getTimestamp("da_" + PortalDBEnum.DEVICE_APPLICATIONS.modifiedDate) != null)
					deviceUtilityVO.setAppInstallTime(
							rs.getTimestamp("da_" + PortalDBEnum.DEVICE_APPLICATIONS.modifiedDate).getTime());

				deviceUtilityVO.setBoxStatics(rs.getString("bs_" + PortalDBEnum.BOX_STATICS.statics));

				listDeviceUtlity.add(deviceUtilityVO);
			}

		}
		hashOutput.put(Constant.DATA, listDeviceUtlity);
		hashOutput.put("NextPage", String.valueOf(listDeviceUtlity.size() >= pageSize));
		hashOutput.put("pageNo", pageNo);
		hashOutput.put("pageSize", pageSize);

		return hashOutput;

	}

	private List<Object> createDeviceUtillityFilterObject(Map<String, String> filters){

		List<Object> parameters = new ArrayList<>();

		if (filters != null) {
			Iterator<String> it = filters.keySet().iterator();
			while (it.hasNext()) {
				String key = it.next();
				String value = filters.get(key);
				DevicesUtilityFilterType filterType = DevicesUtilityFilterType.GetEnum(key);

				String startValue = "";
				String endValue = "";

				if (value.contains(",")) {
					String[] valueArr = value.split(",");
					startValue = valueArr[0];
					endValue = valueArr[1];
				} else {
					startValue = value;
				}

				switch (filterType) {
				case dHBRDate:
					if (!StringFunctions.isNullOrWhitespace(startValue)) {
						parameters.add(Common.sqlDateFormat(Long.valueOf(startValue)));
					}

					if (!StringFunctions.isNullOrWhitespace(endValue)) {
						parameters.add(Common.sqlDateFormat(Long.valueOf(endValue)));
						// sb.append(dbCon.formatString(Common.sqlDateFormat(Long.valueOf(endValue))));
					}
					break;
				case appInstallTime:
					if (!StringFunctions.isNullOrWhitespace(startValue)) {
						parameters.add(Common.sqlDateFormat(Long.valueOf(startValue)));
						// sb.append(dbCon.formatString(Common.sqlDateFormat(Long.valueOf(startValue))));
					}

					if (!StringFunctions.isNullOrWhitespace(endValue)) {
						parameters.add(Common.sqlDateFormat(Long.valueOf(endValue)));
						// sb.append(dbCon.formatString(Common.sqlDateFormat(Long.valueOf(endValue))));
					}
					break;

				case BSModifiedDate:
					if (!StringFunctions.isNullOrWhitespace(startValue)) {
						parameters.add(Common.sqlDateFormat(Long.valueOf(startValue)));
						// sb.append(dbCon.formatString(Common.sqlDateFormat(Long.valueOf(startValue))));
					}

					if (!StringFunctions.isNullOrWhitespace(endValue)) {
						parameters.add(Common.sqlDateFormat(Long.valueOf(endValue)));
						// sb.append(dbCon.formatString(Common.sqlDateFormat(Long.valueOf(endValue))));
					}
					break;

				case DeviceId:
					if (!StringFunctions.isNullOrWhitespace(startValue)
							&& !StringFunctions.isNullOrWhitespace(endValue)) {
						int startValueInt = Integer.parseInt(startValue);
						int endValueInt = Integer.parseInt(endValue);

						if (startValueInt > endValueInt) {
							int temp = startValueInt;
							startValueInt = endValueInt;
							endValueInt = temp;
						}

						List<String> list = new ArrayList<>();
						for (int i = startValueInt; i <= endValueInt; i++) {
							list.add(String.valueOf(i));
						}
						parameters.addAll(list);
					}
					break;
				}
			}
		}

		return parameters;
	}

	/**
	 * Get the updates of applications available for device. 
	 * @param deviceId device id
	 * @param installedAppIds installed application ids on device
	 * @param platformId
	 * @return ArrayList<HashMap<String, String>> HashMap<String, String> contains "appId", and "appVersionId" as key. 
	 * @throws SQLException
	 */
	public List<HashMap<String, String>> isUpdateAvilable(String deviceId,List<String> installedAppIds,String platformId) throws SQLException
	{
		return mIsUpdateAvilable(deviceId, installedAppIds,platformId);
	}

	private List<HashMap<String, String>> mIsUpdateAvilable(String deviceId,List<String> installedAppIds,String platformId) throws SQLException
	{
		ArrayList<HashMap<String, String>> returnList = new ArrayList<>();
		HashMap<String, String> appVersions = new HashMap<>();
		DeviceApplicationsDB appObj = new DeviceApplicationsDB();

		String sql = appObj.isAppUpdateAvilable(installedAppIds);

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
				.addParameter(deviceId).addParameters(installedAppIds).addParameter(platformId).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				boolean isUpdateFound = rs.getBoolean("isUpdateAvailable");
				if (isUpdateFound) {
					appVersions = new HashMap<>();
					appVersions.put("appId", rs.getString("appId"));
					appVersions.put("appVersionId", rs.getString("appVersionId"));
					returnList.add(appVersions);

				}
			}
		}
		return returnList;
	}



	/**
	 *  This method gives all devices using paging and 
	 * filters (category, sort, search text, start with, start end, etc.).	
	 * @param userId
	 * @param pageNo
	 * @param pageSize  number of device in one page.
	 * @param filters  (category, sort, search text, start with, start end, etc.).
	 * @param listUpdateVersions
	 * @parma ownership
	 * @param authVo used only for invitee/both ownership
	 * @return  hash map of result with keys-> totalPages,  pageNo, pageSize , data.hashmap value of key "data" contains List<DeviceVO>
	 * @throws SQLException
	 */
	public Map<String, Object> listDeviceFilter(String userId,int pageNo, int pageSize, List<FilterObject> filters ,boolean listUpdateVersions,OwnershipEnum ownership, AuthorizationsVO authVo) throws SQLException 
	{
		return mListDeviceFilter(userId, pageNo, pageSize, filters, listUpdateVersions,ownership,authVo);
	}

	private List<String> getGroupNames(String userId) throws SQLException {
		String sql = new DevicesDB().getGroupNames(userId);
		List<String> strings = new ArrayList<>();
		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
				.addParameter(userId).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				strings.add(rs.getString(UpdateServiceDBEnum.APP_GROUP_USERS.groupId.name()));
			}
		}

		return strings;
	}


	private Map<String, Object> mListDeviceFilter(String userId,int pageNo, int pageSize, List<FilterObject> filters, boolean listUpdateVersions,OwnershipEnum ownership,AuthorizationsVO authVo) throws SQLException 
	{
		List<DeviceVO> listDevice = new ArrayList<>();
		List<String> groupIds = new ArrayList<>();
		boolean toParseGrpPermission = false;
		if (ownership.name().equals(OwnershipEnum.Invitee.name())
				|| ownership.name().equals(OwnershipEnum.Both.name())) {
			toParseGrpPermission = true;
			if (authVo.getGroupPermissions() != null)
				groupIds = new ArrayList<>(authVo.getGroupPermissions().keySet());
		}

		List<String> groupNames = getGroupNames(userId);

		List<String> queries = new DevicesDB().listDeviceFilter(userId, filters, listUpdateVersions, ownership,
				groupIds, groupNames.size());

		HashMap<String, List<Object>> parameters = createListDeviceFilterObject(userId, filters, listUpdateVersions,
				ownership, groupIds, groupNames, pageSize, pageNo);

		HashMap<String, Object> hashOutput = new HashMap<>();
		int totalDevice = 0;
		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(queries.get(0)).addParameters(parameters.get("parameters")).build();

		QueryVO countQueryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(queries.get(1)).addParameters(parameters.get("parametersofQuery2")).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO);
				ResultSet rsCount = PortalDatabaseEngine.getInstance().getConnection().executeQuery(countQueryVO)) {
			while (rsCount.next()) {
				// getting total no of rows without page limit.
				if (totalDevice <= 0)
					totalDevice = rsCount.getInt("rowCount");
			}

			listDevice = setDeviceObjectList(rs, true, false, true, listUpdateVersions, toParseGrpPermission, authVo);

		}
		int totalPages = totalDevice / pageSize;
		if ((totalDevice % pageSize) > 0) {
			totalPages += 1;
		}
		hashOutput.put(Constant.DATA, listDevice);
		hashOutput.put("totalPages", totalPages);
		hashOutput.put("pageNo", pageNo);
		hashOutput.put("pageSize", pageSize);
		hashOutput.put("totalCount", totalDevice);

		return hashOutput;
	}

	private HashMap<String,List<Object>> createListDeviceFilterObject(String userId, List<FilterObject> filters, 
			boolean listUpdateVersions, OwnershipEnum ownership, List<String> groupIds, List<String> group,
			int pageSize, int pageNo) {
		int offset = (pageNo - 1) * pageSize;

		HashMap<String, List<Object>> hashMap = new HashMap<>();
		List<Object> parameters = new ArrayList<>();
		List<Object> parametersofQuery2 = new ArrayList<>();

		SqlQueryBuilder sqlQueryBuilder = null;
		String searchString = "";
		if (filters != null) {
			for (FilterObject filterObject : filters) {
				switch (filterObject.getFilterType()) {
				case FILTER:
					switch (filterObject.getFilterkey()) {
					case HBRDate:
						if (!StringFunctions.isNullOrWhitespace(filterObject.getStartValue())) {
							parameters.add(Common.sqlDateFormat(Long.valueOf(filterObject.getStartValue())));
						}

						if (!StringFunctions.isNullOrWhitespace(filterObject.getEndValue())) {
							if (!StringFunctions.isNullOrWhitespace(filterObject.getStartValue())) {
								parameters.add(Common.sqlDateFormat(Long.valueOf(filterObject.getEndValue())));
								parametersofQuery2.add(Common.sqlDateFormat(Long.valueOf(filterObject.getEndValue())));
							}
						}
						break;
					case HWPlatform:
						parameters.addAll(filterObject.getValues());
						parametersofQuery2.addAll(filterObject.getValues());
						break;
					case SWPlatform:
						parameters.addAll(filterObject.getValues());
						parametersofQuery2.addAll(filterObject.getValues());
						break;
					case Labels:
						parameters.addAll(filterObject.getValues());
						parametersofQuery2.addAll(filterObject.getValues());
						break;
					default:
						break;
					}
					break;
				case SEARCHTEXT:
					if (filterObject.getOperator().ordinal() == Operator.LIKE.ordinal()) {
						searchString = filterObject.getStartValue();
						parameters.add(Utils.getFormatStringForLike(true, searchString, true));
						parametersofQuery2.add(Utils.getFormatStringForLike(true, searchString, true));
					} else if (filterObject.getOperator().ordinal() == Operator.EQUAL.ordinal()) {
						parameters.add(filterObject.getStartValue());
						parametersofQuery2.add(filterObject.getStartValue());
					}
					break;
				case SORT:
					switch (filterObject.getSortKey()) {
					case Name:
						if (searchString.equals("")) {
						} else {

							parameters.add(searchString);
							parameters.add(Utils.getFormatStringForLike(false, searchString, true));
							parameters.add(Utils.getFormatStringForLike(true, searchString, false));

							parametersofQuery2.add(searchString);
							parametersofQuery2.add(Utils.getFormatStringForLike(false, searchString, true));
							parametersofQuery2.add(Utils.getFormatStringForLike(true, searchString, false));
						}
						break;
					case Status:
						break;
					case CreationTime:
						break;
					default:
						break;
					}
					break;
				default:
					break;

				}
			}
		}
		boolean isgroupIdUsed = false;
		switch (ownership) {
		case None:
			break;
		case Owner:
			parametersofQuery2.add(userId);

			parameters.add(userId);
			break;
		case Invitee:
			isgroupIdUsed = true;
			if (groupIds != null && !groupIds.isEmpty()) {
				parameters.addAll(groupIds);
				parametersofQuery2.addAll(groupIds);
			} else {
				parameters.add("");
				parametersofQuery2.add("");
			}
			break;
		case Both:
			isgroupIdUsed = true;
			parameters.add(userId);
			parametersofQuery2.add(userId);
			if (groupIds != null && !groupIds.isEmpty()) {
				parameters.addAll(groupIds);
				parametersofQuery2.addAll(groupIds);
			} else {
				parameters.add("");
				parametersofQuery2.add("");
			}
			break;
		default:
			break;
		}
		parameters.add(pageSize);
		parameters.add(offset);

		if (isgroupIdUsed) {
			if (ownership == OwnershipEnum.Both) {
				parameters.add(userId);
			}
			if (groupIds != null && !groupIds.isEmpty()) {
				parameters.addAll(groupIds);
			} else {
				parameters.add("");
			}
		}

		if (listUpdateVersions) {
			parameters.add("Appliance");
			parameters.addAll(group);
		}

		hashMap.put("parameters", parameters);
		hashMap.put("parametersofQuery2", parametersofQuery2);

		return hashMap;
	}

	public int getNodeCountInCluster(String clusterId) throws SQLException
	{
		return mGetNodeCountInCluster(clusterId);
	}

	private int mGetNodeCountInCluster(String clusterId) throws SQLException
	{
		int count = 0 ;
		DevicesDB deviceDB =  new DevicesDB();

		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(deviceDB.getNodeCountInCluster()).addParameter(clusterId).build();

		PALogger.TRACE("mGetNodeCountInCluster using clusterId : " + queryVO.toString());


		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				count = rs.getInt("count");
			} 
		}

		PALogger.TRACE("mGetNodeCountInCluster using clusterId count : " + count);
		return count;
	}

	/**
	 * Remove a nodeDevice added in cluster device.Add removed device entry as individual kubernetes device.
	 * @param nodeId node id of device  to be removed.
	 * @param deviceId cluster id from which the node to be removed.
	 * @param userId user id.
	 * @throws Exception 
	 */
	public void removeNodeFromCluster(String nodeId, String deviceId, String userId) throws Exception
	{
		mRemoveNodeFromCluster(nodeId, deviceId, userId);
	}

	private void mRemoveNodeFromCluster(String nodeId, String deviceId, String userId) throws Exception
	{
		PALogger.INFO("mRemoveNodeFromCluster called"
				+ " nodeId "
				+ nodeId 
				+ " deviceId "
				+ deviceId
				+ " userId "
				+ userId);

		DevicesDB deviceDB =  new DevicesDB();
		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(deviceDB.getCluster())
				.addParameter(nodeId)
				.addParameter(userId)
				.build();

		PALogger.TRACE("mRemoveNodeFromCluster get cluster node with nodeId  " + queryVO.toString());

		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)){
			String nodeName = "";
			String platformId = "";
			DeviceTypeEnum deviceType = DeviceTypeEnum.DockerCompose;
			DeviceVO deviceNodeObject = null;

			if (rs.next())
			{
				PALogger.TRACE("mRemoveNodeFromCluster found cluster node with nodeId ");
				deviceNodeObject = setDeviceObject(rs, false, false);

			}
			else
			{
				// Trying to look for the device with old device id exists in database as while removing/deleting cluster the clusterid (nodeId) entry in database is wiped out once the last node is soft factory resetted
				// and during removal if one node is off then it will soft reset once it is powered on but it will not find any node with nodeId supplied in this function
				// Bug 1104 - Kubernetes - Delete a four node cluster three nodes will get soft reset and one node will get factory reset

				QueryVO queryVODevice = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
						.appendQuery(deviceDB.getCluster())
						.addParameter(deviceId)
						.addParameter(userId)
						.build();

				PALogger.TRACE("mRemoveNodeFromCluster cluster node with nodeId not found, get by deviceId. " + queryVODevice.toString());
				try(ResultSet rs1 = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVODevice))
				{
					if (rs1.next())
					{						
						deviceNodeObject = setDeviceObject(rs1, false, false);
					}
				}
			}


			if(deviceNodeObject == null)
			{
				PALogger.TRACE("mRemoveNodeFromCluster cluster node with nodeId or deviceId not found");
				throw new Exception(ErrorMessage.DEVICE_NOT_FOUND);
			}

			platformId = deviceNodeObject.getPlatformId();
			/**
			 * node devicename is name of individual device.
			 */
			nodeName = deviceNodeObject.getNodeVO().getDeviceName();
			deviceType = deviceNodeObject.getDeviceType();

			PALogger.INFO("mRemoveNodeFromCluster NODE info: DeviceType " + deviceNodeObject.getDeviceType().toString() ); 

			ArrayList<QueryVO> queries = new ArrayList<>();
			if(deviceType == DeviceTypeEnum.KubernetesCluster)
			{
				deviceType = DeviceTypeEnum.KubernetesDevice;//Setting device type to KubernetesDevice as after activation of node DeviceType is set to KubernetesDevice not KubernetesCluster - DB

				/**
				 * Get count of nodes in cluster
				 */
				int countNodes = this.getNodeCountInCluster(deviceNodeObject.getDeviceId());


				DeviceVO deviceVO = new DeviceVO();
				deviceVO.setDeviceId(deviceId);
				deviceVO.setUserId(userId);
				deviceVO.setPlatformId(platformId);
				deviceVO.setDeviceStatus(Status.ACTIVE);
				deviceVO.setDeviceName(nodeName);
				deviceVO.setDeviceType(deviceType);
				deviceVO.setActivationConfirmed(true);

				//Added as the new constraint `devices_ibfk_2` is added into devices table so adding device with proper `SwPlatformId` from old object 
				deviceVO.setSwPlatformId(deviceNodeObject.getSwPlatformId());

				/*
				 * Insert device entry into devices table  
				 */
				QueryVO queryVOInsertDevice = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
						.appendQuery(deviceDB.insertIntoDevices()).addParameters(insertIntoDevicesParameterList(deviceVO)).build();
				queries.add(queryVOInsertDevice);


				/*
				 * Update foriegn key deviceId in nodes table 
				 */
				QueryVO queryVOUpdateNode = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
						.appendQuery(deviceDB.updateNodeDeviceId()).addParameter(deviceId)
						.addParameter(nodeId).build();

				queries.add(queryVOUpdateNode);


				/**
				 * if the node which is being removed from cluster is last node then delete the cluster entry from device table.  -PS
				 */
				if(countNodes == 1)
				{
					/**
					 * Delete device application entries
					 */
					QueryVO queryVODeleteDeviceApplication = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
							.appendQuery(new DeviceApplicationsDB().deletFromDeviceApplication()).addParameter(deviceNodeObject.getDeviceId()).build();
					queries.add(queryVODeleteDeviceApplication);					

					/**
					 * Delete boxstatics of device
					 */					

					QueryVO queryVOBoxStatics = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
							.appendQuery(new BoxStaticsDB().deleteBoxStatics()).addParameter(deviceNodeObject.getDeviceId()).build();

					queries.add(queryVOBoxStatics);


					QueryVO queryVODeleteJobs = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
							.appendQuery(new InstallJobDB().deleteAllJobs())
							.addParameter(userId)
							.addParameter(deviceNodeObject.getDeviceId())
							.build();

					queries.add(queryVODeleteJobs);					

					QueryVO deleteEdgeCoreFromGroupsQueryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
							.appendQuery(new DevicesDB().deleteEdgeCoreFromGroups()).addParameter(deviceNodeObject.getDeviceId()).build();
					queries.add(deleteEdgeCoreFromGroupsQueryVO);


					//Added delete device SQL at last as foreign key constraints fails with error for deviceapplication table			
					QueryVO deleteDeviceQueryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
							.appendQuery(new DevicesDB().deleteDevice())
							.addParameter(deviceNodeObject.getDeviceId())
							.addParameter(userId)
							.build();

					queries.add(deleteDeviceQueryVO);
				}			

			}
			else //DockerCompose
			{
				/**
				 * Delete device application entries
				 */
				QueryVO queryVODeleteDeviceApplication = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
						.appendQuery(new DeviceApplicationsDB().deletFromDeviceApplication()).addParameter(deviceNodeObject.getDeviceId()).build();
				queries.add(queryVODeleteDeviceApplication);					

				/**
				 * Delete boxstatics of device
				 */					

				QueryVO queryVOBoxStatics = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
						.appendQuery(new BoxStaticsDB().deleteBoxStatics()).addParameter(deviceNodeObject.getDeviceId()).build();

				queries.add(queryVOBoxStatics);

				/**
				 * delete all jobs
				 */
				QueryVO queryVODeleteJobs = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
						.appendQuery(new InstallJobDB().deleteAllJobs())
						.addParameter(userId)
						.addParameter(deviceNodeObject.getDeviceId())
						.build();

				queries.add(queryVODeleteJobs);				
			}

			for (QueryVO qry : queries) {
				PALogger.INFO("mRemoveNodeFromCluster  SQL " + qry.toString());
			}

			PortalDatabaseEngine.getInstance().getConnection().executeUpdatesInTransaction(queries);
		}	
	}


	private List<Object> insertIntoDevicesParameterList(DeviceVO deviceVO) throws SQLException
	{
		List<Object> parameters = new ArrayList<>();

		parameters.add(deviceVO.getDeviceId());
		parameters.add(deviceVO.getUserId());
		parameters.add(deviceVO.getPlatformId());
		parameters.add(deviceVO.getSwPlatformId());
		parameters.add(Status.ACTIVE.ordinal());
		parameters.add(deviceVO.getDeviceName());
		parameters.add(deviceVO.getDeviceType().ordinal());
		parameters.add(deviceVO.isActivationConfirmed());

		//On update parameters
		parameters.add(deviceVO.getUserId());
		parameters.add(deviceVO.getPlatformId());
		parameters.add(deviceVO.getDeviceName());
		parameters.add(Status.ACTIVE.ordinal());

		return parameters;
	}


	private List<Object> insertIntoNodesParameterList(DeviceVO deviceVO, String networkJson) throws SQLException
	{
		List<Object> parameters = new ArrayList<>();
		parameters.add(deviceVO.getNodeVO().getNodeId());
		parameters.add(deviceVO.getNodeVO().getDeviceName());
		parameters.add(deviceVO.getNodeVO().getMacAddress());	
		parameters.add(deviceVO.getNodeVO().getHostName());
		parameters.add(deviceVO.getNodeVO().getMachineId());
		parameters.add(deviceVO.getNodeVO().getNativeAppId());
		parameters.add(deviceVO.getNodeVO().getDeviceRole().ordinal());
		parameters.add(deviceVO.getNodeVO().getDeviceState().ordinal());
		parameters.add(deviceVO.getNodeVO().getDeviceId());
		parameters.add(networkJson);
		//On duplicate key update
		parameters.add(deviceVO.getNodeVO().getMachineId());
		parameters.add(deviceVO.getNodeVO().getDeviceName());
		parameters.add(deviceVO.getNodeVO().getNativeAppId());
		parameters.add(deviceVO.getNodeVO().getHostName());		
		parameters.add(deviceVO.getNodeVO().getMacAddress());
		parameters.add(networkJson);

		return parameters;
	}

	public List<HashMap<String, String>> getCount() throws SQLException
	{
		return mGetCount();
	}

	public List<HashMap<String, String>> mGetCount() throws SQLException
	{
		DevicesDB devicesDb= new DevicesDB();

		String status="";
		int count = 0;
		HashMap<String, String> mapVal= new HashMap<>();
		ArrayList<HashMap<String, String>> returnList= new ArrayList<>();

		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(devicesDb.getCount()).build();

		try(ResultSet result =  PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO))
		{	
			while(result.next())
			{
				mapVal= new HashMap<>();
				status=  DeviceTypeEnum.GetEnum(result.getInt(PortalDBEnum.DEVICES.deviceType.name())).name();
				count= result.getInt("count");
				mapVal.put("Status", status);
				mapVal.put("Count",String.valueOf(count));
				returnList.add(mapVal);

			}
		}

		return returnList;
	}
	/**
	 * Get list of groups of requested device
	 * @param deviceId
	 * @param groupIds if group Ids not null or empty then group returned where group ids in this list. 
	 * @return
	 * @throws SQLException
	 */
	public List<String> listGroupsOfDevice(String deviceId, List<String> groupIds) throws SQLException {
		return mListGroupsOfDevice(deviceId, groupIds);
	}
	private List<String> mListGroupsOfDevice(String deviceId, List<String> groupIds) throws SQLException 
	{
		List<String> listGroupIds = new ArrayList<>();
		String query = new EdgeCoreGroupsDB().getGroupsOfEdgeCore(groupIds);

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(query)
				.addParameter(deviceId).addParameters(groupIds).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				listGroupIds.add(rs.getString(PortalDBEnum.GROUP_EDGECORE.groupId.name()));
			}
		}
		return listGroupIds;
	}

	/**
	 * this method returns hashmap with deviceids and list of group in which that device is added
	 * @param deviceIds
	 * @return
	 * @throws SQLException
	 */
	public Map<String, List<String>>  listGroupsOfDevices(List<String> deviceIds) throws SQLException {
		return mListGroupsOfDevices( deviceIds);
	}
	private HashMap<String, List<String>>  mListGroupsOfDevices(List<String> deviceIds) throws SQLException 
	{
		HashMap<String, List<String>> deviceGroups = new HashMap<>();
		String query = new EdgeCoreGroupsDB().listEdgeCoreGroupsForDeviceIds(deviceIds);
		String deviceId="";

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(query)
				.addParameters(deviceIds).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (	rs.next())
			{
				deviceId =rs.getString(PortalDBEnum.GROUP_EDGECORE.edgeCoreId.name());
				if(!deviceGroups.containsKey(deviceId))
				{
					List<String> grps= new ArrayList<>();
					grps.add(rs.getString(PortalDBEnum.GROUP_EDGECORE.groupId.name()));
					deviceGroups.put(deviceId, grps);	
				}
				else
					deviceGroups.get(deviceId).add(rs.getString(PortalDBEnum.GROUP_EDGECORE.groupId.name()));
			}
		}
		return deviceGroups;
	}

	/**
	 * this method returns hashmap with deviceids and list of group in which that device is added
	 * @param deviceIds
	 * @return
	 * @throws SQLException
	 */
	public Map<String, String>  listSupportRelayDetails(String deviceId) throws SQLException {
		return mlistSupportRelayDetails(deviceId);
	}
	private HashMap<String, String>  mlistSupportRelayDetails(String deviceId) throws SQLException 
	{
		HashMap<String, String> suportrelaydetails= new HashMap<>();

		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new DevicesDB().getSupportRelayDetails()).addParameter(deviceId).build();

		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)){
			while (	rs.next()){

				String sRelayServerIDValue = rs.getString(PortalDBEnum.SUPPORT_RELAY_SERVERS.sRelayServerID.toString());
				String sRelayServerAddressValue = rs.getString(PortalDBEnum.SUPPORT_RELAY_SERVERS.sRelayServerAddress.toString());
				String nPortSegmentStartValue = rs.getInt(PortalDBEnum.SUPPORT_ASSIGNED_RELAY_PORTS.nPortSegmentStart.toString())+"";

				suportrelaydetails.put(PortalDBEnum.SUPPORT_RELAY_SERVERS.sRelayServerID.toString(), sRelayServerIDValue);
				suportrelaydetails.put(PortalDBEnum.SUPPORT_RELAY_SERVERS.sRelayServerAddress.toString(), sRelayServerAddressValue);
				suportrelaydetails.put(PortalDBEnum.SUPPORT_ASSIGNED_RELAY_PORTS.nPortSegmentStart.toString(),nPortSegmentStartValue);

			}
		}

		return suportrelaydetails;
	}



	/**
	 * Update cluster active master state.Make the node as active master with id nodeId and make other as backup master. 
	 * @param nodeId
	 * @return
	 * @throws SQLException
	 */
	public  boolean updateClusterActiveMaster(String nodeId) throws SQLException {
		return mUpdateClusterActiveMaster(nodeId);
	}

	private boolean mUpdateClusterActiveMaster(String nodeId) throws SQLException {

		String clusterId = getParentClusterIdForANode(nodeId);

		QueryVO queryVO1 = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new DevicesDB().updateClusterActiveMaster().get(0))
				.addParameter(clusterId)
				.build();


		QueryVO queryVO2 = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new DevicesDB().updateClusterActiveMaster().get(1))
				.addParameter(nodeId)
				.build();		

		List<QueryVO> queries =  new ArrayList<>();

		queries.add(queryVO1);

		queries.add(queryVO2);

		PortalDatabaseEngine.getInstance().getConnection().executeUpdatesInTransaction(queries);
		return true; 
	}

	/**
	 * Get parent cluster id of a node
	 * @return
	 * @throws SQLException 
	 */
	public String getParentClusterIdForANode(String nodeId) throws SQLException{
		return mGetParentClusterIdForANode(nodeId); 
	}

	private String mGetParentClusterIdForANode(String nodeId) throws SQLException{
		String clusterId = null;
		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new DevicesDB().getParentClusterIdForANode()).addParameter(nodeId).build();

		try(ResultSet rsDeviceId = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO))
		{	
			while(rsDeviceId.next())
			{
				clusterId = rsDeviceId.getString(PortalDBEnum.NODES.deviceId.name());
			}
		}
		return clusterId;
	}

	/**
	 * Function checks whether cluster exists and also checks whether the relationship between cluster and node exists when cluster is available
	 * @param clusterId
	 * @param nodeId
	 * @author ps
	 * @throws Exception with error message containing {@link ErrorMessage} CLUSTER_NOT_FOUND when cluster with cluster id does not exists in database or DEVICE_NOT_FOUND when deviceId is not associated with cluster id 
	 */
	public void checkClusterNodeExsitance(String clusterId, String nodeId) throws Exception
	{
		mCheckClusterNodeExsitance(clusterId, nodeId);
	}

	/**
	 * Function checks whether cluster exists and also checks whether the relationship between cluster and node exists when cluster is available
	 * @param clusterId
	 * @param nodeId
	 * @author ps
	 * @throws Exception with error message containing {@link ErrorMessage} CLUSTER_NOT_FOUND when cluster with cluster id does not exists in database or DEVICE_NOT_FOUND when deviceId is not associated with cluster id 
	 */
	private void mCheckClusterNodeExsitance(String clusterId, String nodeId) throws Exception 
	{
		boolean isDeviceExists = this.isDeviceExistsByDeviceId(clusterId);

		if(isDeviceExists)
		{
			List<Object> parameters = new ArrayList<>();
			parameters.add(nodeId);
			parameters.add(clusterId);

			QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
					.appendQuery(new DevicesDB().isNodeExistsInCluster()).addParameters(parameters).build();

			boolean isNodeExists = false;
			try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO))
			{
				while(rs.next())
				{	
					if(rs.getInt("count") > 0)
					{
						isNodeExists = true;
					}
				}
				if(!isNodeExists)
				{
					throw new Exception(ErrorMessage.DEVICE_NOT_FOUND);

				}
			}			
		}
		else
		{
			throw new Exception(ErrorMessage.CLUSTER_NOT_FOUND);
		}

	}


	/**
	 * Function checks whether cluster exists and also checks whether the relationship between cluster and node exists when cluster is available
	 * @param deviceIdList
	 * @author DB
	 * @throws Exception with error message containing {@link ErrorMessage} DEVICE_NOT_FOUND when entry in database with any of deviceId in list is found 
	 */
	public void checkDeviceExists(List<String> deviceIdList) throws Exception
	{
		mcheckDeviceExists(deviceIdList);
	}

	/**
	 * This method give query which check any device exist in db, corresponding to given deviceIds list.
	 * @param deviceIdList
	 * @author DB
	 * @throws Exception with error message containing {@link ErrorMessage} DEVICE_NOT_FOUND when entry in database with any of deviceId in list is found  
	 */
	private void mcheckDeviceExists(List<String> deviceIdList) throws Exception 
	{
		boolean isDeviceExists = this.mIsdeviceExists(deviceIdList);

		if(!isDeviceExists)
		{
			throw new Exception(ErrorMessage.DEVICE_NOT_FOUND);
		}

	}


}

/**
 * History of check-in or issue resolved
 * 
 * 01 - 4-11-2016
 * AKH_01
 * set restRedirectUrl and redirectSection in application we save "reverse proxy" and "specific port" in redirect Url and rest Url save in restRedirectUrl.
 * 
 * 02 - 14-11-2016 AKH_02
 * remove restRedirectUrl, redirectUrl, redirectType and redirectSection these property shift to applicationVersion,
 * because may be each version have different redirection param.
 * 
 * 03 - 22-2-2018 PS
 *  Added method updateClusterActiveMaster
 */
