/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.mwp.p.dal;

import com.mwp.common.yamlparser.SecretVo;
import com.mwp.db.Interface.IConnection;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.common.enums.PortalDBEnum.APP_SECRET;
import com.mwp.p.common.enums.PortalDBEnum.APP_SECRET_VERSION;
import com.mwp.p.dal.engine.PortalDatabaseEngine;

public class AppSecretDB 
{
	private IConnection dbCon= null;
	private String table;
	StringBuilder colList;
	public AppSecretDB()
	{
		//set database connection object.
		dbCon = PortalDatabaseEngine.getInstance().getConnection();
		table = PortalDBEnum.TABLE_NAMES.appSecret.name();
		colList= new StringBuilder(APP_SECRET.appSecretId.name());
		colList.append(", "	);			
		colList.append( APP_SECRET.appId.name() );
		colList.append( ", ");
		colList.append(APP_SECRET.serviceName.name()); 
		colList.append( ", ");
		colList.append( APP_SECRET.secretKey.name());
		colList.append( " ,");
		/*
		 * displayName and secretValue shift to APP_SECRET_VERSION table.
		 */
//		colList.append( APP_SECRET.displayName.name()); 
//		colList.append( ", ");	
		colList.append( APP_SECRET.configType.name()); 
		colList.append( ", ");
//		colList.append( APP_SECRET.type.name()); 
//		colList.append( ", ");	
//		colList.append( APP_SECRET.secretValue.name()); 
//		colList.append( ", ");	
		colList.append( APP_SECRET.createdDate.name());
		colList.append( ", ");
		colList.append(APP_SECRET.modifiedDate.name());
	}

//	appSecretId,
//	appId,	
//	serviceName, 
//	secretKey,
//	displayName,
//	type,
//	secretValue,
//	createdDate,
//	modifiedDate
	public String insert(SecretVo secretObj)
	{
		StringBuilder qry= new StringBuilder("INSERT INTO ");
		qry.append(table);
		qry.append( "(");
		qry.append( colList); 
		qry.append( ") VALUES (");	    
		qry.append("?");
		qry.append( ","	);   
		qry.append("?");
		qry.append( ",");
		qry.append("?");
		qry.append( ",");
		qry.append("?");
		qry.append( ",");
		qry.append("?");
		qry.append( ",");
		qry.append( "NOW()");
		qry.append( ",");
		qry.append( "NOW()");
		qry.append( ")");
		return qry.toString();
	}
	
	
//	public String edit(SecretVo secretObj)
//	{
//		StringBuilder qry= new StringBuilder();
//		qry.append("UPDATE ");
//		qry.append(table);
//		qry.append(" SET ");
//		qry.append( APP_SECRET.secretKey.name());
//		qry.append( " = ");
//		qry.append( dbCon.formatString(secretObj.getKey()));
//		/*
//		 * comment this code because of displayName and secretValue shift to child table.
//		 * APP_SECRET.type not change.
//		 */
////		qry.append(" , ");
////		qry.append( APP_SECRET.displayName.name());
////		qry.append( " = ");
////		qry.append( dbCon.formatString(secretObj.getDisplayName()));
////		qry.append(", ");
////		qry.append( APP_SECRET.type.name());
////		qry.append( " = ");
////		qry.append( secretObj.getType().ordinal());
////		qry.append(", ");
////		qry.append( APP_SECRET.secretValue.name());
////		qry.append( " = ");
////		qry.append( dbCon.formatString(secretObj.getValue()));
//		qry.append(" WHERE ");
//		qry.append( APP_SECRET.appSecretId.name());
//		qry.append( " = ");
//		qry.append(dbCon.formatString(secretObj.getAppSecretId()));
//		return qry.toString();
//	}
	
	public String delete()
	{
		StringBuilder qry= new StringBuilder("DELETE FROM " );
		qry.append(table );
		qry.append(" WHERE " );
		qry.append( APP_SECRET.appSecretId.name());
		qry.append( " = ");
		qry.append("?");
		return qry.toString();

	}
	
	/*
	 * Secret List using AppId- from appSecret and join from appSecretVersion table.
	 */
	public String listByAppId()
	{
		StringBuilder qry= new StringBuilder("SELECT *, ");
		qry.append(" appSecVersion.");qry.append(APP_SECRET_VERSION.appSecretVersionId.name());
		qry.append(", "	);			
		qry.append(" appSecVersion.");qry.append(APP_SECRET_VERSION.appUserId.name()); 
		qry.append( ", ");
		qry.append(" appSecVersion.");qry.append( APP_SECRET_VERSION.displayName.name()); 
		qry.append( ", ");	
		qry.append(" appSecVersion.");qry.append( APP_SECRET_VERSION.secretValue.name()); 
		qry.append( ", ");	
		qry.append(" appSecVersion.");qry.append( APP_SECRET_VERSION.type.name()); 
		qry.append(" FROM ");
		qry.append(table );
		qry.append(" JOIN ");
		qry.append(PortalDBEnum.TABLE_NAMES.appSecretVersion);qry.append(" AS appSecVersion ");
		qry.append(" ON ");qry.append(" appSecVersion.");qry.append(APP_SECRET_VERSION.appSecretId);
		qry.append(" = ");
		qry.append(PortalDBEnum.TABLE_NAMES.appSecret);qry.append(".");qry.append(APP_SECRET.appSecretId);
		qry.append(" WHERE " );
		qry.append( APP_SECRET.appId.name());
		qry.append( " = ");
		qry.append("?");
		qry.append(" ORDER BY " );
		qry.append( APP_SECRET.secretKey.name());
		return qry.toString();
	}
	
	/*
	 * This method give uniqueName "displayName" query using appSecret and Join appSecretVersion table.
	 */
	public String uniqueName(boolean toCheckinAppSecret)
	{
		StringBuilder qry= new StringBuilder("SELECT * FROM ");
		qry.append(table );
		qry.append(" JOIN ");
		qry.append(PortalDBEnum.TABLE_NAMES.appSecretVersion);qry.append(" AS appSecVersion ");
		qry.append(" ON ");qry.append(" appSecVersion.");qry.append(APP_SECRET_VERSION.appSecretId);
		qry.append(" = ");
		qry.append(PortalDBEnum.TABLE_NAMES.appSecret);qry.append(".");qry.append(APP_SECRET.appSecretId);
		qry.append(" WHERE (" );
		qry.append("appSecVersion.");qry.append(APP_SECRET_VERSION.displayName.name());
		qry.append( " = ");
		qry.append("?");
		qry.append(" AND " );
		qry.append( APP_SECRET.appId.name());
		qry.append( " = ");
		qry.append("?");
		qry.append(" AND " );
		qry.append(PortalDBEnum.TABLE_NAMES.appSecret);
		qry.append(".");
		qry.append( APP_SECRET.appSecretId.name());
		qry.append( " = ");
		qry.append("?");
		qry.append(" AND " );
		qry.append("appSecVersion.");qry.append(APP_SECRET_VERSION.appSecretVersionId.name());
		qry.append( "!= ");
		qry.append("?");
		//add unique constaint for either appid + displayname or appid + secret key
		qry.append( ") ");
		if(toCheckinAppSecret)
		{
			qry.append( "|| (");
			qry.append(APP_SECRET.secretKey.name());
			qry.append( " = ");
			qry.append("?");
			qry.append(" AND " );
			qry.append( APP_SECRET.appId.name());
			qry.append( " = ");
			qry.append("?");
			qry.append(" AND " );
			qry.append(PortalDBEnum.TABLE_NAMES.appSecret);qry.append(".");qry.append( APP_SECRET.appSecretId.name());
			qry.append( " != ");
			qry.append("?");
			qry.append( ")" );
		}
		
		return qry.toString();
	}
	
	/*
	 * This method give query for getting appSecret using join appSecretVersion.
	 */
	public String get()
	{
		StringBuilder qry= new StringBuilder("SELECT *, ");
		qry.append(" appSecVersion.");qry.append(APP_SECRET_VERSION.appSecretVersionId.name());
		qry.append(", "	);			
		qry.append(" appSecVersion.");qry.append(APP_SECRET_VERSION.appUserId.name()); 
		qry.append( ", ");
		qry.append(" appSecVersion.");qry.append( APP_SECRET_VERSION.displayName.name()); 
		qry.append( ", ");	
		qry.append(" appSecVersion.");qry.append( APP_SECRET_VERSION.secretValue.name()); 
		qry.append( ", ");	
		qry.append(" appSecVersion.");qry.append( APP_SECRET_VERSION.type.name()); 
		qry.append(" FROM ");
		qry.append(table );
		qry.append(" JOIN ");
		qry.append(PortalDBEnum.TABLE_NAMES.appSecretVersion);qry.append(" AS appSecVersion ");
		qry.append(" ON ");qry.append(" appSecVersion.");qry.append(APP_SECRET_VERSION.appSecretId);
		qry.append(" = ");
		qry.append(PortalDBEnum.TABLE_NAMES.appSecret);qry.append(".");qry.append(APP_SECRET.appSecretId);
		qry.append(" WHERE " );
		qry.append(PortalDBEnum.TABLE_NAMES.appSecret);qry.append(".");qry.append( APP_SECRET.appSecretId.name());
		qry.append( " = ");
		qry.append("?");
		return qry.toString();
	}
	
}
