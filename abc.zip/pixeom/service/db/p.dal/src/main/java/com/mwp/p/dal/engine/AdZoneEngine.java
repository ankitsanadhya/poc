/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal.engine;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mwp.common.Common;
import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.common.vo.QueryVO;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.common.enums.PortalDBEnum.AD_TYPE;
import com.mwp.p.common.vo.AdZoneVO;
import com.mwp.p.dal.AdZoneDal;

/**
 * this class contains query executors for insert, edit sort order, delete and list zones in adZone table and parser to parse result set from adZone Table
 * @author root
 *
 */
public class AdZoneEngine 
{
	/**
	 * method to insert ad zone
	 * @param adZoneObj{@link AdZoneVO}
	 * @return {@link AdZoneVO}
	 * @throws SQLException 
	 */
	public AdZoneVO add(AdZoneVO adZoneObj) throws SQLException
	{
		return mAdd(adZoneObj);
	}
	
	/**
	 * method to edit sort order of zone
	 * @param sortOrder
	 * @param adId
	 * @return
	 * @throws SQLException 
	 */
	public boolean editSortOrder(int sortOrder, String adId) throws SQLException
	{
		return mEditSortOrder(sortOrder, adId);
	}
	
	/**
	 * method to delete a zone
	 * @param adId
	 * @return
	 * @throws SQLException 
	 */
	public boolean delete(String adId) throws SQLException
	{
		return mDelete(adId);
	}
	/**
	 * method to get ad zone for given adId and zoneId
	 * @param adId
	 * @param zoneId
	 * @return {@link AdZoneVO}
	 * @throws SQLException 
	 */
	public AdZoneVO get(String adId, String zoneId) throws SQLException
	{
		return mGet(adId, zoneId);
	}
	/**
	 * list all ad zones
	 * @return List<{@link AdZoneVO}>
	 * @throws SQLException 
	 */
	public List<AdZoneVO> list() throws SQLException
	{
		return mList();
	}
	

	/**
	 * list zone according to type
	 * @param type
	 *  @return List<{@link AdZoneVO}>
	 * @throws SQLException
	 */
	public List<AdZoneVO> listByType(AD_TYPE type) throws SQLException
	{
		return mListByType(type);
	}
	
	/**
	 * list zone by categoryId
	 * @param categoryId
	 * @return
	 * @throws SQLException
	 */
	public List<AdZoneVO> listByCategory(String categoryId) throws SQLException
	{
		return mListByCategory(categoryId);
	}
	
	//PRIVATE METHOD
	
	private AdZoneVO mAdd(AdZoneVO adZoneObj) throws SQLException
	{
		// get random id for adId
		String adId = Common.getRandomId();
		AdZoneDal adZoneDalObj = new AdZoneDal(PortalDatabaseEngine.getInstance().getConnection());

		String insertQuery = adZoneDalObj.insert();
		// execute insert query

		List<Object> parameters = new ArrayList<>();
		parameters.add(adId);
		parameters.add(adZoneObj.getAppId());
		parameters.add(adZoneObj.getCategoryId());
		parameters.add(adZoneObj.getType().ordinal());
		parameters.add(adZoneObj.getZoneId());
		parameters.add(adZoneObj.getSortOrder());

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(insertQuery)
						.addParameters(parameters).build();

		PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
		// get insetred object from db
		return get(adId, adZoneObj.getZoneId());
	}
	
	
	private boolean mEditSortOrder(int sortOrder, String adId) throws SQLException
	{
		AdZoneDal adZoneDalObj = new AdZoneDal(PortalDatabaseEngine.getInstance().getConnection());

		//query to edit sort order
		String qry= adZoneDalObj.editSortOrder();
		
		List<Object> parameters =  new ArrayList<>();
		parameters.add(sortOrder);
		parameters.add(adId);
		
		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(qry).addParameters(parameters).build();
		
		//execute sort query
		int i =	PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
		//return true if sort order updated successfully
		return (i > 0);
	}
	
	
	private boolean mDelete(String adId) throws SQLException
	{
		AdZoneDal adZoneDalObj = new AdZoneDal(PortalDatabaseEngine.getInstance().getConnection());
		
		//query to delete zone
		String qry= adZoneDalObj.delete();
		
		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(qry).addParameter(adId).build();
		
		//execute delete query
		int i =	PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
		//return true if entry deleted successfully
		return (i > 0);
	}
	
	private AdZoneVO mGet(String adId, String zoneId) throws SQLException
	{
		AdZoneDal adZoneDalObj = new AdZoneDal(PortalDatabaseEngine.getInstance().getConnection());
		AdZoneVO adZoneObj = null;
		// query to get adZone
		String getQuery = adZoneDalObj.get();

		List<Object> parameters = new ArrayList<>();
		parameters.add(adId);
		parameters.add(zoneId);

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(getQuery)
						.addParameters(parameters).build();

		try (ResultSet result = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {

			while (result.next()) {
				adZoneObj = parseResultSet(result);
			}
		}

		return adZoneObj;
	}
	
	
	private List<AdZoneVO> mList() throws SQLException
	{
		AdZoneDal adZoneDalObj = new AdZoneDal(PortalDatabaseEngine.getInstance().getConnection());
		//query to get all entries from adZone table
		String listQry = adZoneDalObj.list();
		return executeList(listQry, null);
	}
	
	private List<AdZoneVO> mListByType(AD_TYPE type) throws SQLException
	{
		AdZoneDal adZoneDalObj = new AdZoneDal(PortalDatabaseEngine.getInstance().getConnection());
		// query to get all entries of given type
		String listQry = adZoneDalObj.listByType();
		return executeList(listQry, type.ordinal());
	}
	
	private List<AdZoneVO> mListByCategory(String categoryId) throws SQLException
	{
		AdZoneDal adZoneDalObj = new AdZoneDal(PortalDatabaseEngine.getInstance().getConnection());
		//query to get all zones for given category
		String listQry = adZoneDalObj.listByCategory();
		return executeList(listQry, categoryId);
	}
	
	/**
	 * this method will execute any type of list query and will return list of adZoneVO
	 * @param listQry List<{@link AdZoneVO}>
	 * @return List<{@link AdZoneVO}>
	 * @throws SQLException 
	 */
	private List<AdZoneVO> executeList(String listQry, Object parameter) throws SQLException
	{
		AdZoneVO adZoneObj = null;
		List<AdZoneVO> lstAdZone = new ArrayList<>();

		SqlQueryBuilder sqlQueryBuilder = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(listQry);

		if (parameter != null) {
			sqlQueryBuilder.addParameter(parameter);
		}

		QueryVO queryVO = sqlQueryBuilder.build();

		try (ResultSet result = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {

			while (result.next()) {
				adZoneObj = parseResultSet(result);
				lstAdZone.add(adZoneObj);
			}
		}

		return lstAdZone;
	}
	
	/**
	 * method to parse result set to AdZone object
	 * @param result
	 * @return {@link AdZoneVO}
	 * @throws SQLException
	 */
	private AdZoneVO parseResultSet(ResultSet result) throws SQLException
	{
		AdZoneVO adZoneObj= new AdZoneVO();
		adZoneObj.setAdId(result.getString(PortalDBEnum.AD_ZONE.adId.name()));
		adZoneObj.setAppId(result.getString(PortalDBEnum.AD_ZONE.appId.name()));
		adZoneObj.setCategoryId(result.getString(PortalDBEnum.AD_ZONE.categoryId.name()));
		adZoneObj.setType(AD_TYPE.values()[result.getInt(PortalDBEnum.AD_ZONE.type.name())]);
		adZoneObj.setZoneId(result.getString(PortalDBEnum.AD_ZONE.zoneId.name()));
		adZoneObj.setSortOrder(result.getInt(PortalDBEnum.AD_ZONE.sortOrder.name()));
		adZoneObj.setModifiedDate(result.getTimestamp(PortalDBEnum.AD_ZONE.modifiedDate.name()).getTime());

		return adZoneObj;
	}

}
