/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import com.mwp.common.Common;
import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.common.constant.Constant;
import com.mwp.common.enums.ApplicationDefaultType;
import com.mwp.common.enums.Status;
import com.mwp.common.vo.QueryVO;
import com.mwp.db.Interface.IDatabaseScript;
import com.mwp.db.engine.vo.DatabaseScriptVO;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.common.enums.PortalDBEnum.AD_TYPE;
import com.mwp.p.common.enums.PortalDBEnum.LABELS;
import com.mwp.p.common.enums.PortalDBEnum.NODES;
import com.mwp.p.common.enums.PortalDBEnum.SETTINGS_KEY;

/**
 * This class give create database script, update script, get database version
 * query.
 * 
 * @author root
 *
 */
public class PortalDatabaseScript implements IDatabaseScript {

	private String dbName = "";

	public PortalDatabaseScript(String dbName) {
		this.dbName = dbName;
	}

	DatabaseScriptVO updateScript;

	/**
	 * This method give creation script of portal database and default category
	 * insertion script.
	 * 
	 * @return
	 */
	@Override
	public DatabaseScriptVO getDatabaseScript(int currentVersion) {
		return mGetDatabaseScript(currentVersion);
	}

	/**
	 * This method give latest update script of database, compare from db
	 * version and latest version of db from code.
	 * 
	 * @param dbVersion
	 * @param currentVersion
	 * @return Hashtable<Integer, DatabaseScriptVO>
	 */
	public Map<Integer, DatabaseScriptVO> getUpdateScript(int dbVersion, int currentVersion) {
		return mGetUpdateScript(dbVersion, currentVersion);
	}

	/**
	 * get query for select db version from t999.
	 * 
	 * @return
	 */
	@Override
	public String getDBVersionQuery() {
		return mGetDBVersionQuery();
	}

	/**
	 * create query string of update version from t999.
	 * 
	 * @return query string
	 */
	public String getDBUpdateVersionQuery(int currentVersion) {
		return mGetDBUpdateVersionQuery(currentVersion);
	}

	/**
	 * create query string of update version from t999.
	 * 
	 * @return query string
	 */
	private String mGetDBUpdateVersionQuery(int currentVersion) {
		return "UPDATE t999 SET version = " + currentVersion;
	}

	/**
	 * get query for select db version from t999.
	 * 
	 * @return
	 */
	private String mGetDBVersionQuery() {
		return "SELECT version FROM t999";
	}

	/**
	 * This method give creation script of portal database and default category
	 * insertion script.
	 * 
	 * @return
	 */
	private DatabaseScriptVO mGetDatabaseScript(int currentVersion) {
		DatabaseScriptVO databaseScript = new DatabaseScriptVO();

		List<String> ddlQueries = new ArrayList<String>();
		String collation = "COLLATE utf8mb4_unicode_ci"; // Bug 745 - Issues on
															// creating "My User
															// Group and My
															// Projects" with
															// ASCII characters
															// - changed charset
															// to utf8mb4

		ddlQueries.add("USE " + this.dbName);
		ddlQueries
				.add("CREATE TABLE IF NOT EXISTS `company` (`companyId` varchar(32) NOT NULL,`userId` varchar(32) NOT NULL,`projectId` varchar(32) NOT NULL,`companyName` text "
						+ collation + " NOT NULL,`icon` varchar(100) DEFAULT NULL,`address` text " + collation
						+ " NOT NULL,`city` text " + collation + " NOT NULL,`state` text " + collation
						+ " NOT NULL,`country` text " + collation
						+ " NOT NULL,`postalCode` text NOT NULL,`webAddress` text " + collation
						+ " DEFAULT NULL,`phone` text NOT NULL,`email` text NOT NULL, `companyStatus` tinyint(1) NOT NULL, `createdDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ,`modifiedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,PRIMARY KEY (`companyId`),KEY `userId` (`userId`)) ENGINE=InnoDB DEFAULT CHARSET=utf8");
		ddlQueries
				.add("CREATE TABLE IF NOT EXISTS `project` (`projectId` varchar(32) NOT NULL, `companyId` varchar(32) NOT NULL,`userId` varchar(32) NOT NULL,`name` varchar(50) "
						+ collation + " NOT NULL,`description` text " + collation
						+ " NOT NULL,`icon` varchar(100) DEFAULT NULL,`projectStatus` tinyint(1) NOT NULL,`createdDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ,`modifiedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,PRIMARY KEY (`projectId`),KEY `uid` (`userId`), KEY `companyId` (`companyId`), CONSTRAINT `project_ibfk_1` FOREIGN KEY (`companyId`) REFERENCES `company` (`companyId`)) ENGINE=InnoDB DEFAULT CHARSET=utf8");
		ddlQueries.add(createAppTypeTable());
		ddlQueries.add(createPlatFormTable());
		/**
		 * add secretKey column maximum length -50 char in application table,
		 * AKH_01_3, AKH_02_1, AKH_03
		 */
		ddlQueries
				.add("CREATE TABLE IF NOT EXISTS `application` (`appId` varchar(32) NOT NULL,`projectId` varchar(32) NOT NULL,`userId` varchar(32) NOT NULL,`title` varchar(50) "
						+ collation + " NOT NULL, `description` text " + collation + " NOT NULL,`webAddress` text "
						+ collation
						+ " NOT NULL,`icon` text DEFAULT NULL,`secretKey` text NULL,`appStatus` tinyint(1) NOT NULL,`appTypeId` varchar(32) NOT NULL,`usePxAuth` TINYINT(1) NULL, `usePxEventService` TINYINT(1) NULL , `usePxCloudApi` TINYINT(1) NULL , `signUpType` TINYINT(1) DEFAULT 4 ,`price` DECIMAL(10,2) NULL DEFAULT 0, `rating` DECIMAL(3,2) NULL DEFAULT 0,`currency` VARCHAR(50) NULL DEFAULT NULL, `runasservice` TINYINT DEFAULT false,  `createdDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ,`modifiedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,PRIMARY KEY (`appId`),KEY `uId` (`userId`),KEY `pId` (`projectId`),KEY `prId` (`price` ASC),KEY `rId` (`rating` ASC),CONSTRAINT `application_ibfk_1` FOREIGN KEY (`projectId`) REFERENCES `project` (`projectId`) ON DELETE CASCADE ON UPDATE CASCADE, CONSTRAINT `application_ibfk_2` FOREIGN KEY (`appTypeId`) REFERENCES `applicationType` (`typeId`))  ENGINE=InnoDB DEFAULT CHARSET=utf8");
		ddlQueries.add(
				"CREATE TABLE IF NOT EXISTS `category` (`catId` varchar(32) NOT NULL,`name` varchar(32) NOT NULL,`type` smallint(4) NOT NULL,`catStatus` tinyint(1) NOT NULL,`createdDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ,`modifiedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,PRIMARY KEY (`catId`),UNIQUE KEY `name` (`name`)) ENGINE=InnoDB DEFAULT CHARSET=utf8");
		ddlQueries.add(
				"CREATE TABLE IF NOT EXISTS `groupapplications` (`groupAppId` varchar(32) NOT NULL,`groupId` varchar(32) NOT NULL,`appId` varchar(32) NOT NULL,PRIMARY KEY (`groupAppId`),KEY `gId` (`groupId`),KEY `aId` (`appId`),CONSTRAINT `groupapplications_ibfk_1` FOREIGN KEY (`appId`) REFERENCES `application` (`appId`)) ENGINE=InnoDB DEFAULT CHARSET=utf8");
		ddlQueries.add(
				"CREATE TABLE IF NOT EXISTS `applicationcategories` (`appId` varchar(32) NOT NULL,`catId` varchar(32) NOT NULL,KEY `aId` (`appId`),KEY `cId` (`catId`),CONSTRAINT `applicationcategories_ibfk_1` FOREIGN KEY (`catId`) REFERENCES `category` (`catId`) ON DELETE CASCADE ON UPDATE CASCADE,CONSTRAINT `applicationcategories_ibfk_2` FOREIGN KEY (`appId`) REFERENCES `application` (`appId`) ON DELETE CASCADE ON UPDATE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8");

		ddlQueries.add("CREATE TABLE IF NOT EXISTS `devices` (" + "`deviceId` varchar(32) NOT NULL,"
				+ "`userId` varchar(32) NOT NULL," + "`platformId` varchar(32) NOT NULL,"

				+ "`swPlatformId` varchar(32) NOT NULL,"

				+ "`deviceName` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,"
				+ "`deviceStatus` tinyint(1) DEFAULT NULL," + "`tags` text,"
				+ "`description` text COLLATE utf8mb4_unicode_ci," + "`action` varchar(50) DEFAULT NULL,"
				+ "`isActivationConfirmed` tinyint(1) DEFAULT 0," + "`deviceType` tinyint(1) DEFAULT 0,"
				+ "`createdDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ,"
				+ "`modifiedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,"
				+ "PRIMARY KEY (`deviceId`)," + "UNIQUE KEY `deviceName_UNIQUE` (`deviceName`),"
				+ "KEY `uId` (`userId`),"
				+ "CONSTRAINT `devices_ibfk_1` FOREIGN KEY (`platformId`) REFERENCES `platform` (`platformId`) ON DELETE CASCADE,"
				+ "CONSTRAINT `devices_ibfk_2` FOREIGN KEY (`swPlatformId`) REFERENCES `applicationType` (`typeId`) ON DELETE CASCADE"
				+ ") ENGINE=InnoDB DEFAULT CHARSET=utf8");

		ddlQueries.add("CREATE TABLE IF NOT EXISTS `nodes` (" + "`nodeId` varchar(32) NOT NULL,"
				+ "`deviceName` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,"
				+ "`softwareVersion` varchar(50) DEFAULT NULL," + "`hardwareInfo` text,"
				+ "`macAddress` varchar(50) NOT NULL," + "`hostName` varchar(500) DEFAULT NULL,"
				+ "`tags` text," + "`description` text," + "`machineId` varchar(50) DEFAULT NULL,"
				+ "`nativeAppId` varchar(500) DEFAULT NULL," + "`action` varchar(50) DEFAULT NULL,"
				+ "`deviceRole` tinyint(1) DEFAULT 0," + "`deviceState` tinyint(1) DEFAULT 0,"
				+ "`deviceId` varchar(32) NOT NULL," + "`network` text,"
				+ "`createdDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ,"
				+ "`modifiedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,"
				+ "PRIMARY KEY (`nodeId`)," + "UNIQUE KEY `deviceName_UNIQUE` (`deviceName`),"
				+ "UNIQUE KEY `macAddress_UNIQUE` (`macAddress`),"
				+ "CONSTRAINT `devices_nodesfk_1` FOREIGN KEY (`deviceId`) REFERENCES `devices` (`deviceId`) ON DELETE CASCADE"
				+ ") ENGINE=InnoDB DEFAULT CHARSET=utf8");

		ddlQueries.add("CREATE VIEW " + PortalDBEnum.VIEW_NAMES.devicesnodes_view + " AS (" + " SELECT "
				+ PortalDBEnum.TABLE_NAMES.devices + "." + PortalDBEnum.DEVICES.deviceId + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.devices_deviceId + ", " + PortalDBEnum.TABLE_NAMES.devices + "."
				+ PortalDBEnum.DEVICES.userId + " as " + PortalDBEnum.DEVICES_NODES_VIEW.devices_userId + ", "
				+ PortalDBEnum.TABLE_NAMES.devices + "." + PortalDBEnum.DEVICES.platformId + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.devices_platformId + ", "

				+ PortalDBEnum.TABLE_NAMES.devices + "." + PortalDBEnum.DEVICES.swPlatformId + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.devices_swPlatformId + ", "

				+ PortalDBEnum.TABLE_NAMES.devices + "." + PortalDBEnum.DEVICES.deviceName + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.devices_deviceName + ", " + PortalDBEnum.TABLE_NAMES.devices + "."
				+ PortalDBEnum.DEVICES.deviceStatus + " as " + PortalDBEnum.DEVICES_NODES_VIEW.devices_deviceStatus
				+ ", " + PortalDBEnum.TABLE_NAMES.devices + "." + PortalDBEnum.DEVICES.tags + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.devices_tags + ", " + PortalDBEnum.TABLE_NAMES.devices + "."
				+ PortalDBEnum.DEVICES.description + " as " + PortalDBEnum.DEVICES_NODES_VIEW.devices_description + ", "
				+ PortalDBEnum.TABLE_NAMES.devices + "." + PortalDBEnum.DEVICES.action + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.devices_action + ", " + PortalDBEnum.TABLE_NAMES.devices + "."
				+ PortalDBEnum.DEVICES.isActivationConfirmed + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.devices_isActivationConfirmed + ", "
				+ PortalDBEnum.TABLE_NAMES.devices + "." + PortalDBEnum.DEVICES.deviceType + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.devices_deviceType + ", " + PortalDBEnum.TABLE_NAMES.devices + "."
				+ PortalDBEnum.DEVICES.createdDate + " as " + PortalDBEnum.DEVICES_NODES_VIEW.devices_createdDate + ", "
				+ PortalDBEnum.TABLE_NAMES.devices + "." + PortalDBEnum.DEVICES.modifiedDate + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.devices_modifiedDate + ", "

				+ PortalDBEnum.TABLE_NAMES.nodes + "." + PortalDBEnum.NODES.nodeId + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.nodes_nodeId + ", " + PortalDBEnum.TABLE_NAMES.nodes + "."
				+ PortalDBEnum.NODES.deviceName + " as " + PortalDBEnum.DEVICES_NODES_VIEW.nodes_deviceName + ", "
				+ PortalDBEnum.TABLE_NAMES.nodes + "." + PortalDBEnum.NODES.softwareVersion + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.nodes_softwareVersion + ", " + PortalDBEnum.TABLE_NAMES.nodes + "."
				+ PortalDBEnum.NODES.hardwareInfo + " as " + PortalDBEnum.DEVICES_NODES_VIEW.nodes_hardwareInfo + ", "
				+ PortalDBEnum.TABLE_NAMES.nodes + "." + PortalDBEnum.NODES.macAddress + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.nodes_macAddress + ", " + PortalDBEnum.TABLE_NAMES.nodes + "."
				+ PortalDBEnum.NODES.hostName + " as " + PortalDBEnum.DEVICES_NODES_VIEW.nodes_hostName + ", "
				+ PortalDBEnum.TABLE_NAMES.nodes + "." + PortalDBEnum.NODES.tags + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.nodes_tags + ", " + PortalDBEnum.TABLE_NAMES.nodes + "."
				+ PortalDBEnum.NODES.description + " as " + PortalDBEnum.DEVICES_NODES_VIEW.nodes_description + ", "
				+ PortalDBEnum.TABLE_NAMES.nodes + "." + PortalDBEnum.NODES.machineId + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.nodes_machineId + ", " + PortalDBEnum.TABLE_NAMES.nodes + "."
				+ PortalDBEnum.NODES.nativeAppId + " as " + PortalDBEnum.DEVICES_NODES_VIEW.nodes_nativeAppId + ", "
				+ PortalDBEnum.TABLE_NAMES.nodes + "." + PortalDBEnum.NODES.action + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.nodes_action + ", " + PortalDBEnum.TABLE_NAMES.nodes + "."
				+ PortalDBEnum.NODES.deviceRole + " as " + PortalDBEnum.DEVICES_NODES_VIEW.nodes_deviceRole + ", "
				+ PortalDBEnum.TABLE_NAMES.nodes + "." + PortalDBEnum.NODES.deviceState + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.nodes_deviceState + ", " + PortalDBEnum.TABLE_NAMES.nodes + "."
				+ PortalDBEnum.NODES.deviceId + " as " + PortalDBEnum.DEVICES_NODES_VIEW.nodes_deviceId + ", "
				+ PortalDBEnum.TABLE_NAMES.nodes + "." + PortalDBEnum.NODES.createdDate + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.nodes_createdDate + ", " + PortalDBEnum.TABLE_NAMES.nodes + "."
				+ PortalDBEnum.NODES.modifiedDate + " as " + PortalDBEnum.DEVICES_NODES_VIEW.nodes_modifiedDate

				+ " FROM " + PortalDBEnum.TABLE_NAMES.devices + " JOIN " + PortalDBEnum.TABLE_NAMES.nodes + " ON "
				+ PortalDBEnum.TABLE_NAMES.devices + "." + PortalDBEnum.DEVICES.deviceId + " = "
				+ PortalDBEnum.TABLE_NAMES.nodes + "." + PortalDBEnum.NODES.deviceId + ")");

		/**
		 * AKH_01_1
		 */
		ddlQueries.add(
				"CREATE TABLE IF NOT EXISTS `applicationfilter` (`filterId` varchar(32) NOT NULL,`filterName` varchar(50) NOT NULL,`filterDetails` text NOT NULL,`appFilterStatus` tinyint(1) NOT NULL,`createdDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP  ,`modifiedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,PRIMARY KEY (`filterId`)) ENGINE=InnoDB DEFAULT CHARSET=utf8");
		ddlQueries.add(
				"CREATE TABLE IF NOT EXISTS `applicationimages` (`appImageId` VARCHAR(32) NOT NULL, `appId` varchar(32) NOT NULL,`imagePath` varchar(100) NOT NULL,`sequenceNo` int(11) NOT NULL, PRIMARY KEY (`appImageId`), KEY `aid` (`appId`),CONSTRAINT `applicationimages_ibfk_1` FOREIGN KEY (`appId`) REFERENCES `application` (`appId`) ON DELETE CASCADE ON UPDATE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8");
		// AKH_01_2
		ddlQueries.add(createApplicationServiceEndpointsTable());

		ddlQueries.add(createApplicationPlatformTable());

		// AKH_01_1
		ddlQueries
				.add("CREATE TABLE IF NOT EXISTS `applicationversions` (`appVersionId` varchar(32) NOT NULL,`appId` varchar(32) NOT NULL, `"
						+ PortalDBEnum.APPLICATION_VERSIONS.appPlatformId
						+ "` varchar(32) NOT NULL,`projectId` varchar(32) NOT NULL,`appVersion` varchar(32) DEFAULT NULL,`versionStatus` tinyint(1) NOT NULL,`releaseNotes` text "
						+ collation
						+ " NOT NULL,`size` BIGINT DEFAULT 0,`composerFilePath` TEXT NOT NULL , `redirectType` VARCHAR(100) NOT NULL,`redirectUrl` TEXT NOT NULL,`restRedirectUrl` TEXT NULL, `redirectSection` VARCHAR(100) NULL,`toExecuteOrder` TEXT NOT NULL, `composeVersion` varchar(32) DEFAULT '', `createdDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ,`modifiedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,PRIMARY KEY (`appVersionId`),KEY `aId` (`appId`),KEY `pId` (`projectId`),CONSTRAINT `applicationversions_ibfk_1` FOREIGN KEY (`appId`) REFERENCES `application` (`appId`) ON DELETE CASCADE ON UPDATE CASCADE,CONSTRAINT `applicationversions_ibfk_2` FOREIGN KEY (`projectId`) REFERENCES `project` (`projectId`) ON DELETE CASCADE ON UPDATE CASCADE ,CONSTRAINT `applicationversions_ibfk_3` FOREIGN KEY (`appPlatformId`) REFERENCES `applicationplatform` (`appPlatformId`) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8");
		ddlQueries.add(
				"CREATE TABLE IF NOT EXISTS `deviceapplications` (`deviceAppId` varchar(32) NOT NULL,`deviceId` varchar(32) NOT NULL,`appId` varchar(32) NOT NULL,`appVersionId` varchar(32) NOT NULL,`deviceAppstatus` tinyint(1) NOT NULL,`createdDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ,`modifiedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,PRIMARY KEY (`deviceAppId`),KEY `dId` (`deviceId`),KEY `aId` (`appId`),KEY `avId` (`appVersionId`),CONSTRAINT `deviceapplications_ibfk_1` FOREIGN KEY (`deviceId`) REFERENCES `devices` (`deviceId`),CONSTRAINT `deviceapplications_ibfk_3` FOREIGN KEY (`appVersionId`) REFERENCES `applicationversions` (`appVersionId`),CONSTRAINT `deviceapplications_ibfk_4` FOREIGN KEY (`appId`) REFERENCES `application` (`appId`)) ENGINE=InnoDB DEFAULT CHARSET=utf8");
		ddlQueries.add(
				"CREATE TABLE IF NOT EXISTS `groupapplicationversions` (`groupAppVersionId` varchar(32) NOT NULL,`groupAppId` varchar(32) NOT NULL,`appVersionId` varchar(32) NOT NULL,PRIMARY KEY (`groupAppVersionId`),KEY `gaId` (`groupAppId`),KEY `avId` (`appVersionId`),CONSTRAINT `groupapplicationversions_ibfk_1` FOREIGN KEY (`groupAppId`) REFERENCES `groupapplications` (`groupAppId`),CONSTRAINT `groupapplicationversions_ibfk_2` FOREIGN KEY (`appVersionId`) REFERENCES `applicationversions` (`appVersionId`)) ENGINE=InnoDB DEFAULT CHARSET=utf8");
		ddlQueries.add(
				"CREATE TABLE IF NOT EXISTS `activationhistory` (`activationHistoryId` int(50) NOT NULL AUTO_INCREMENT,`deviceId` varchar(50) NOT NULL,`userId` varchar(50) NOT NULL,`macAddress` varchar(50) NOT NULL,`machineId` varchar(50) NOT NULL,`nativeAppId` TEXT NOT NULL,`action` varchar(50) NOT NULL,`actionON` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,PRIMARY KEY (`activationHistoryId`),KEY `deviceId` (`deviceId`,`userId`)) ENGINE=InnoDB AUTO_INCREMENT=541 DEFAULT CHARSET=utf8");

		// create filter table to store different types of filters.
		ddlQueries.add("CREATE TABLE IF NOT EXISTS `filters` (`filterId` INT NOT NULL AUTO_INCREMENT,"
				+ "`filterGroupName` varchar(100) NOT NULL," + "`filterName` varchar(100) NOT NULL,"
				+ " PRIMARY KEY (filterId))" + " ENGINE=InnoDB DEFAULT CHARSET=utf8 ");
		// create sortorders table to store different types of sorting.
		ddlQueries.add("CREATE TABLE IF NOT EXISTS `sortorders` (`sortId` INT NOT NULL AUTO_INCREMENT,"
				+ "`sortGroupName` varchar(100) NOT NULL," + "`sortName` varchar(100) NOT NULL,"
				+ "PRIMARY KEY (sortId))" + " ENGINE=InnoDB DEFAULT CHARSET=utf8   ");

		ddlQueries
				.add("CREATE TABLE IF NOT EXISTS `functions` (`functionId` varchar(32) NOT NULL,`userId` varchar(32) NOT NULL,`name` varchar(50) "
						+ collation
						+ " NOT NULL,`modifiedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,PRIMARY KEY (`functionId`),KEY `uid` (`userId`)) ENGINE=InnoDB DEFAULT CHARSET=utf8");

		ddlQueries.add(
				"CREATE TABLE IF NOT EXISTS `functionversions` (`functionVersionId` varchar(32) NOT NULL,`functionId` varchar(32) NOT NULL,`version` varchar(32) NOT NULL,`body` TEXT NOT NULL, `toExecute` varchar(50) NOT NULL,`modifiedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,PRIMARY KEY (`functionVersionId`),KEY `uid` (`functionId`)) ENGINE=InnoDB DEFAULT CHARSET=utf8");

		ddlQueries.addAll(createLabelTable());
		ddlQueries.add(createDeviceLabelTable());
		ddlQueries.add(createInstallJobTable());
		// create adZone table
		ddlQueries.add(createAdZoneTable());

		// create emailServer table
		ddlQueries.add(createEmailServersTable());

		ddlQueries.add(createAssignedRelayPortsTable());
		ddlQueries.add(createDiscoveryDetailsTable());
		ddlQueries.add(createDiscoveryJarDetailsTable());
		ddlQueries.add(createLockRelayPortsTable());
		ddlQueries.add(createRelayServersTable());
		ddlQueries.add(createValidationInfoTable());
		ddlQueries.add(createBoxStaticsTable()); // PSH_1

		ddlQueries.add(createSupportRelayServersTable());
		ddlQueries.add(createSupportAssignedRelayPortsTable());
		ddlQueries.add(createSupportLockRelayPortsTable());
		/*
		 * Add query for create table applicationserviceports.
		 */
		ddlQueries.add(createApplicationServicePorts());

		ddlQueries.add(createDockerEventLoggerTable());
		ddlQueries.add(createActivityLoggerTable());
		ddlQueries.add(createVirtualURLTable());
		ddlQueries.add(createRuleTable());
		ddlQueries.add(createRuleTriggerLoggerTable());
		ddlQueries.add(createGroupEdgeCoreTable());
		ddlQueries.add(createSettingsTable());
		ddlQueries.add(createAlertsTable());
		ddlQueries.add(createNetworkTable());
		ddlQueries.add(createApplicationNetworkTable());
		ddlQueries.add(createAppSecret());
		ddlQueries.add(createAppSecretVersion());
		ddlQueries.add(createJobSecret());
		ddlQueries.add(createDownloadTable());
		ddlQueries.add(createGroupResourceTable());

		/**
		 * Application resources table
		 */
		ddlQueries.add(new PortalUpdateScripts(dbName).applicationResourceTables());
		/**
		 * Application Backup Table
		 */
		ddlQueries.add(new PortalUpdateScripts(dbName).applicationBackupTable());
		/**
		 * Application Backup to sync Table
		 */
		ddlQueries.add(new PortalUpdateScripts(dbName).applicationBackupSyncTable());

		ddlQueries.add("CREATE TABLE IF NOT EXISTS `t999` (version int(4) DEFAULT 0)");

		ddlQueries.add(getSupportTokensTables());
		List<QueryVO> dmlQueries = new ArrayList<>();
		List<String> lstAppCategories = Constant.getDefaultAppCategories();
		dmlQueries.addAll(insertCategory(lstAppCategories));
		
//		if (!lstAppCategories.isEmpty()) {
//			for (String category : lstAppCategories) {
//				dmlQueries
//						.add("INSERT INTO `platformportal`.`category` (`catId`,`name`,`type`,`catStatus`) SELECT * FROM (SELECT '"
//								+ Common.getRandomId() + "','" + category
//								+ "',1,0) AS tmp WHERE NOT EXISTS (SELECT name FROM `platformportal`.`category` WHERE name = '"
//								+ category + "') LIMIT 1; ");
//			}
//		} else {
//			dmlQueries
//					.add("INSERT INTO `platformportal`.`category` (`catId`,`name`,`type`,`catStatus`) SELECT * FROM (SELECT '"
//							+ Common.getRandomId()
//							+ "','Pixeom',1,0) AS tmp WHERE NOT EXISTS (SELECT name FROM `platformportal`.`category` WHERE name = 'Pixeom') LIMIT 1; ");
//			dmlQueries
//					.add("INSERT INTO `platformportal`.`category` (`catId`,`name`,`type`,`catStatus`) SELECT * FROM (SELECT '"
//							+ Common.getRandomId()
//							+ "','Internet of Things',1,0) AS tmp WHERE NOT EXISTS (SELECT name FROM `platformportal`.`category` WHERE name = 'Internet of Things') LIMIT 1; ");
//			dmlQueries
//					.add("INSERT INTO `platformportal`.`category` (`catId`,`name`,`type`,`catStatus`) SELECT * FROM (SELECT '"
//							+ Common.getRandomId()
//							+ "','Business',1,0) AS tmp WHERE NOT EXISTS (SELECT name FROM `platformportal`.`category` WHERE name = 'Business') LIMIT 1; ");
//			dmlQueries
//					.add("INSERT INTO `platformportal`.`category` (`catId`,`name`,`type`,`catStatus`) SELECT * FROM (SELECT '"
//							+ Common.getRandomId()
//							+ "','Education',1,0) AS tmp WHERE NOT EXISTS (SELECT name FROM `platformportal`.`category` WHERE name = 'Education') LIMIT 1; ");
//			dmlQueries
//					.add("INSERT INTO `platformportal`.`category` (`catId`,`name`,`type`,`catStatus`) SELECT * FROM (SELECT '"
//							+ Common.getRandomId()
//							+ "','Media',1,0) AS tmp WHERE NOT EXISTS (SELECT name FROM `platformportal`.`category` WHERE name = 'Media') LIMIT 1; ");
//		}

		// dmlQueries.add("INSERT INTO t999 (version) VALUES
		// ("+currentVersion+")");
		dmlQueries.add(insertDBVersion(currentVersion));

		dmlQueries.addAll(insertFilter());
		// inserted default filter data in filter table.
		// dmlQueries.add("INSERT INTO filters(filterGroupName,filterName)
		// VALUES('All prices','Free')");
		// dmlQueries.add("INSERT INTO filters(filterGroupName,filterName)
		// VALUES('All prices','Paid')");
		// dmlQueries.add("INSERT INTO filters(filterGroupName,filterName)
		// VALUES('All ratings','4 stars and above')");
		// dmlQueries.add("INSERT INTO filters(filterGroupName,filterName)
		// VALUES('All ratings','3 stars and above')");

		// inserted default sorting data in sortorder table.
		dmlQueries.addAll(insertSortOrder());
		// dmlQueries.add("INSERT INTO sortorders(sortGroupName,sortName)
		// VALUES('Price','Low to High')");
		// dmlQueries.add("INSERT INTO sortorders(sortGroupName,sortName)
		// VALUES('Price','High to Low')");
		// dmlQueries.add("INSERT INTO sortorders(sortGroupName,sortName)
		// VALUES('Most popular','Most popular')");
		// dmlQueries.add("INSERT INTO sortorders(sortGroupName,sortName)
		// VALUES('Latest first','Latest first')");

		// inserted default ad zone data in adZone table.
		dmlQueries.addAll(insertDefaultEntriesInAdZone());

		// inserted default entries in email server table.
		// dmlQueries.addAll(insertDefaultEntriesInEmailServers());

		dmlQueries.addAll(insertDefaultPlatForm());
		dmlQueries.addAll(insertDefaultAppType());

		dmlQueries.addAll(insertDefaultSettings());

		databaseScript.setDdlQueries(ddlQueries);
		databaseScript.setDmlQueries(dmlQueries);

		return databaseScript;
	}
	
	private List<QueryVO> insertCategory(List<String> lstAppCategories) {
		List<QueryVO> queryVOs = new ArrayList<>();
		String sql = "INSERT INTO `platformportal`.`category` (`catId`,`name`,`type`,`catStatus`) SELECT * FROM (SELECT ?,?,1,0) AS tmp WHERE NOT EXISTS (SELECT name FROM `platformportal`.`category` WHERE name = ?) LIMIT 1";
		if (lstAppCategories.isEmpty()) {
			queryVOs.add(new SqlQueryBuilder().appendQuery(sql).addParameter(Common.getRandomId())
					.addParameter("Pixeom").addParameter("Pixeom").build());
			
			queryVOs.add(new SqlQueryBuilder().appendQuery(sql).addParameter(Common.getRandomId())
					.addParameter("Internet of Things").addParameter("Internet of Things").build());
			
			queryVOs.add(new SqlQueryBuilder().appendQuery(sql).addParameter(Common.getRandomId())
					.addParameter("Business").addParameter("Business").build());
			
			queryVOs.add(new SqlQueryBuilder().appendQuery(sql).addParameter(Common.getRandomId())
					.addParameter("Education").addParameter("Education").build());
			
			queryVOs.add(new SqlQueryBuilder().appendQuery(sql).addParameter(Common.getRandomId())
					.addParameter("Media").addParameter("Media").build());
			
		} else {
			for (String category : lstAppCategories) {
				queryVOs.add(new SqlQueryBuilder().appendQuery(sql).addParameter(Common.getRandomId())
						.addParameter(category).addParameter(category).build());
			}
		}

		return queryVOs;
	}

	private QueryVO insertDBVersion(int currentVersion) {
		String sql = "INSERT INTO t999 (version) VALUES (" + "?" + ")";
		return new SqlQueryBuilder().appendQuery(sql).addParameter(currentVersion).build();
	}

	private List<QueryVO> insertFilter() {
		List<QueryVO> list = new LinkedList<>();
		String sql = "INSERT INTO filters(filterGroupName,filterName) VALUES(?,?)";
		list.add(new SqlQueryBuilder().appendQuery(sql).addParameter("All prices").addParameter("Free").build());
		list.add(new SqlQueryBuilder().appendQuery(sql).addParameter("All prices").addParameter("Paid").build());
		list.add(new SqlQueryBuilder().appendQuery(sql).addParameter("All ratings").addParameter("4 stars and above")
				.build());
		list.add(new SqlQueryBuilder().appendQuery(sql).addParameter("All ratings").addParameter("3 stars and above")
				.build());
		return list;
	}

	private List<QueryVO> insertSortOrder() {
		List<QueryVO> list = new LinkedList<>();
		String sql = "INSERT INTO sortorders(sortGroupName,sortName) VALUES(?,?)";
		list.add(new SqlQueryBuilder().appendQuery(sql).addParameter("Price").addParameter("Low to High").build());
		list.add(new SqlQueryBuilder().appendQuery(sql).addParameter("Price").addParameter("High to Low").build());
		list.add(new SqlQueryBuilder().appendQuery(sql).addParameter("Most popular").addParameter("Most popular")
				.build());
		list.add(new SqlQueryBuilder().appendQuery(sql).addParameter("Latest first").addParameter("Latest first")
				.build());
		return list;
	}

	/**
	 * This method give latest update script of database, compare from db
	 * version and latest version of db from code.
	 * 
	 * @param dbVersion
	 * @param currentVersion
	 * @return Hashtable<Integer, DatabaseScriptVO>
	 */
	private Map<Integer, DatabaseScriptVO> mGetUpdateScript(int dbVersion, int currentVersion) {
		LinkedHashMap<Integer, DatabaseScriptVO> hashDbScriptVO = new LinkedHashMap<>();
		/**
		 * getting all upgrade ddl queries.
		 */
		HashMap<Integer, List<String>> upgradeDDL = getUpgradeDDLQueries();
		/**
		 * getting all upgrade dml queries.
		 */
		HashMap<Integer, List<String>> upgradeDML = getUpgradeDMLQueries();

		// Fill only those ddl and dml queries which are new for DB. Skip
		// already Exceuted queries.
		for (int i = dbVersion + 1; i <= currentVersion; i++) {
			DatabaseScriptVO databaseScript = new DatabaseScriptVO();
			List<String> ddlQueries = new ArrayList<>();
			List<String> dmlQueries = new ArrayList<>();

			// Fill ddlQueries here
			if (upgradeDDL.containsKey(i)) {
				ddlQueries.addAll(upgradeDDL.get(i));
			}
			// Fill dmlQueries here
			if (upgradeDML.containsKey(i)) {
				dmlQueries.addAll(upgradeDML.get(i));
			}
			// databaseScript.setDdlQueries(ddlQueries);
			// databaseScript.setDmlQueries(dmlQueries);
			hashDbScriptVO.put(i, databaseScript);
		}
		return hashDbScriptVO;
	}

	/**
	 * always put all ddl values in hashtable in form of ArrayList<String>. The
	 * key of hashtable are version(1,2,3...) and value are the list of dml
	 * queries
	 * 
	 * @return Hashtable<Integer,ArrayList<String>>
	 */

	/**
	 * this method is deprecated, refer updateDatabase from PortalDatabaseEngine
	 * 
	 * @return
	 */
	@Deprecated
	private HashMap<Integer, List<String>> getUpgradeDDLQueries() {
		HashMap<Integer, List<String>> upgradeMap = new HashMap<>();
		String characterset = "CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci"; // Bug
																					// 745
																					// -
																					// Issues
																					// on
																					// creating
																					// "My
																					// User
																					// Group
																					// and
																					// My
																					// Projects"
																					// with
																					// ASCII
																					// characters
																					// -
																					// changed
																					// charset
																					// to
																					// utf8mb4

		/*** Version 1 ***/
		ArrayList<String> ddl1 = new ArrayList<>();
		ddl1.add("CREATE TABLE IF NOT EXISTS `t999` (version int(4) DEFAULT 0)");
		ddl1.add(
				"ALTER TABLE `platformportal`.`applicationversions` ADD COLUMN `size` BIGINT DEFAULT 0 AFTER `releaseNotes`");
		ddl1.add(
				"ALTER TABLE `platformportal`.`application` CHANGE COLUMN `repositoryName` `repositoryName` VARCHAR(200) NOT NULL ,CHANGE COLUMN `webAddress` `webAddress` TEXT NOT NULL ,CHANGE COLUMN `icon` `icon` TEXT DEFAULT NULL");
		ddl1.add(
				"ALTER TABLE `platformportal`.`applicationconfigurations` CHANGE COLUMN `composerFilePath` `composerFilePath` TEXT NOT NULL");
		upgradeMap.put(1, ddl1);

		/*** Version 2 ***/
		ArrayList<String> ddl2 = new ArrayList<>();
		ddl2.add(
				"ALTER TABLE `platformportal`.`application` ADD COLUMN `redirectUrl` TEXT NOT NULL AFTER `webAddress`,ADD COLUMN `redirectType` VARCHAR(100) NULL AFTER `redirectUrl`");
		upgradeMap.put(2, ddl2);

		/*
		 * Version 3 increased version as tables added for filtering and
		 * sorting.
		 */
		ArrayList<String> ddl3 = new ArrayList<>();
		ddl3.add("CREATE TABLE IF NOT EXISTS `filters` (`filterId` INT NOT NULL AUTO_INCREMENT,"
				+ "`filterGroupName` varchar(100) NOT NULL," + "`filterName` varchar(100) NOT NULL,"
				+ " PRIMARY KEY (filterId))" + " ENGINE=InnoDB DEFAULT CHARSET=utf8 ");
		ddl3.add("CREATE TABLE IF NOT EXISTS `sortorders` (`sortId` INT NOT NULL AUTO_INCREMENT,"
				+ "`sortGroupName` varchar(100) NOT NULL," + "`sortName` varchar(100) NOT NULL,"
				+ "PRIMARY KEY (sortId))" + " ENGINE=InnoDB DEFAULT CHARSET=utf8   ");
		upgradeMap.put(3, ddl3);

		/*** Version 4 ***/
		/**
		 * add secretKey column maximum length -50 char in application table,
		 */
		ArrayList<String> ddl4 = new ArrayList<>();
		ddl4.add("ALTER TABLE `platformportal`.`application` ADD COLUMN `secretKey` text NULL AFTER `icon`");
		upgradeMap.put(4, ddl4);

		/*** Version 5 ***/
		/**
		 * change column type varchar to TEXT because nativeAppId is too long.
		 */
		ArrayList<String> ddl5 = new ArrayList<>();
		ddl5.add(
				"ALTER TABLE `platformportal`.`activationhistory` CHANGE COLUMN `nativeAppId` `nativeAppId` TEXT NOT NULL");
		upgradeMap.put(5, ddl5);

		/*** Version 6 ***/
		/**
		 * added table for ad Zone
		 */
		ArrayList<String> ddl6 = new ArrayList<>();
		ddl6.add(createAdZoneTable());
		upgradeMap.put(6, ddl6);

		/*** Version 7 ***/
		/** AKH_01_1, AKH_01_2 ***/
		ArrayList<String> ddl7 = new ArrayList<>();
		ddl7.add(
				"ALTER TABLE `platformportal`.`applicationversions` ADD COLUMN `composerFilePath` TEXT NULL AFTER `size`");
		ddl7.add(
				"ALTER TABLE `platformportal`.`applicationserviceendpoints` CHANGE COLUMN `appConfigId` `appVersionId` VARCHAR(32) NOT NULL");
		ddl7.add(
				"ALTER TABLE `platformportal`.`application` ADD COLUMN `usePxAuth` TINYINT(1) NULL AFTER `appStatus`,ADD COLUMN `usePxEventService` TINYINT(1) NULL AFTER `usePxAuth`,ADD COLUMN `usePxCloudApi` TINYINT(1) NULL AFTER `usePxEventService`,ADD COLUMN `signUpType` TINYINT(1) DEFAULT 4 AFTER `usePxCloudApi`");

		upgradeMap.put(7, ddl7);

		/*** Version 8 ***/
		/** AKH_01_1 ***/
		ArrayList<String> ddl8 = new ArrayList<>();
		ddl8.add("ALTER TABLE `platformportal`.`applicationversions` DROP FOREIGN KEY `applicationversions_ibfk_3`");
		ddl8.add("ALTER TABLE `platformportal`.`applicationversions` DROP COLUMN `appConfigId`,DROP INDEX `acId`");
		ddl8.add("DROP TABLE `platformportal`.`applicationconfigurations`");
		upgradeMap.put(8, ddl8);

		/*** Version 9 ***/
		/** AKH_02_1 ***/
		ArrayList<String> ddl9 = new ArrayList<>();
		ddl9.add(
				"ALTER TABLE `platformportal`.`application` ADD COLUMN `price` DECIMAL(10,2) NULL DEFAULT 0 AFTER `signUpType`,ADD COLUMN `rating` DECIMAL(3,2) NULL DEFAULT 0 AFTER `price`, ADD COLUMN `currency` VARCHAR(50) NULL DEFAULT NULL AFTER `rating`");
		upgradeMap.put(9, ddl9);

		/*** Version 10 ***/
		ArrayList<String> ddl10 = new ArrayList<>();
		ddl10.add(
				"ALTER TABLE `platformportal`.`application` ADD INDEX `prId` (`price` ASC),ADD INDEX `rId` (`rating` ASC)");
		upgradeMap.put(10, ddl10);

		/*** Version 11 ***/
		// AKH_03
		ArrayList<String> ddl11 = new ArrayList<>();
		ddl11.add(
				"ALTER TABLE `platformportal`.`application` ADD COLUMN `restRedirectUrl` TEXT NULL AFTER `redirectUrl`,ADD COLUMN `redirectSection` VARCHAR(100) NULL AFTER `restRedirectUrl`");
		upgradeMap.put(11, ddl11);

		/*** Version 12 ***/
		/**
		 * added table for emailServer
		 */
		ArrayList<String> ddl12 = new ArrayList<>();
		ddl12.add(createEmailServersTable());
		upgradeMap.put(12, ddl12);

		/*** Version 13 ***/ // AKH_04
		ArrayList<String> ddl13 = new ArrayList<>();
		ddl13.add(
				"ALTER TABLE `platformportal`.`applicationversions` ADD COLUMN `redirectType` VARCHAR(100) NOT NULL AFTER `composerFilePath`, ADD COLUMN `redirectUrl` TEXT NOT NULL AFTER `redirectType`, ADD COLUMN `restRedirectUrl` TEXT NULL AFTER `redirectUrl`,ADD COLUMN `redirectSection` VARCHAR(100) NULL AFTER `restRedirectUrl`");
		upgradeMap.put(13, ddl13);

		/*** Version 14 ***/ // AKH_04
		ArrayList<String> ddl14 = new ArrayList<>();
		ddl14.add(
				"ALTER TABLE `platformportal`.`application` DROP COLUMN `redirectType`, DROP COLUMN `redirectUrl`, DROP COLUMN `restRedirectUrl`, DROP COLUMN `redirectSection`");
		upgradeMap.put(14, ddl14);

		/*** Version 15 ***/ // AKH_05
		ArrayList<String> ddl15 = new ArrayList<>();
		ddl15.add(createAssignedRelayPortsTable());
		ddl15.add(createDiscoveryDetailsTable());
		ddl15.add(createDiscoveryJarDetailsTable());
		ddl15.add(createLockRelayPortsTable());
		ddl15.add(createRelayServersTable());
		ddl15.add(createValidationInfoTable());
		upgradeMap.put(15, ddl15);

		/*** Version 16 ***/
		ArrayList<String> ddl16 = new ArrayList<>();
		ddl16.add(createAssignedRelayPortsTable());
		ddl16.add(
				"CREATE TABLE IF NOT EXISTS `functions` (`functionId` varchar(32) NOT NULL,`userId` varchar(32) NOT NULL,`name` varchar(50) NOT NULL,`modifiedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,PRIMARY KEY (`functionId`),KEY `uid` (`userId`)) ENGINE=InnoDB DEFAULT CHARSET=utf8");
		ddl16.add(
				"CREATE TABLE IF NOT EXISTS `functionversions` (`functionVersionId` varchar(32) NOT NULL,`functionId` varchar(32) NOT NULL,`version` varchar(32) NOT NULL,`body` TEXT NOT NULL, `toExecute` varchar(50) NOT NULL,`modifiedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,PRIMARY KEY (`functionVersionId`),KEY `uid` (`functionId`)) ENGINE=InnoDB DEFAULT CHARSET=utf8");
		upgradeMap.put(16, ddl16);

		ArrayList<String> ddl17 = new ArrayList<>();
		ddl17.add(createBoxStaticsTable());
		upgradeMap.put(17, ddl17);

		ArrayList<String> ddl18 = new ArrayList<>();
		ddl18.add("ALTER TABLE " + PortalDBEnum.TABLE_NAMES.boxStatics.name() + " ADD COLUMN "
				+ PortalDBEnum.BOX_STATICS.modifiedDate
				+ " timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP");
		upgradeMap.put(18, ddl18);

		ArrayList<String> ddl21 = new ArrayList<>();
		ddl21.add(createSupportRelayServersTable());
		ddl21.add(createSupportAssignedRelayPortsTable());
		ddl21.add(createSupportLockRelayPortsTable());
		upgradeMap.put(21, ddl21);

		ArrayList<String> ddl22 = new ArrayList<>();
		ddl22.addAll(createLabelTable());
		ddl22.add(createDeviceLabelTable());
		ddl22.add(createInstallJobTable());
		upgradeMap.put(22, ddl22);

		ArrayList<String> ddl25 = new ArrayList<>();
		ddl25.add(createPlatFormTable());
		ddl25.add(createApplicationPlatformTable());
		ddl25.add("ALTER TABLE " + PortalDBEnum.TABLE_NAMES.applicationversions.name() + " ADD COLUMN "
				+ PortalDBEnum.APPLICATION_VERSIONS.appPlatformId + " varchar(32) NOT NULL AFTER `appId`");
		upgradeMap.put(25, ddl25);

		ArrayList<String> ddl26 = new ArrayList<>();
		ddl26.add("ALTER TABLE " + PortalDBEnum.TABLE_NAMES.applicationserviceendpoints.name() + " ADD COLUMN "
				+ PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.platformId + " varchar(32) NOT NULL AFTER `appVersionId`");
		ddl26.add("ALTER TABLE " + PortalDBEnum.TABLE_NAMES.applicationserviceendpoints.name()
				+ " DROP INDEX `serviceName`");
		ddl26.add("ALTER TABLE " + PortalDBEnum.TABLE_NAMES.applicationserviceendpoints.name()
				+ " ADD UNIQUE KEY `my_unique_key` (" + PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.serviceName + ","
				+ PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.platformId + ","
				+ PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.appId + ")");
		ddl26.add("ALTER TABLE " + PortalDBEnum.TABLE_NAMES.devices.name() + " ADD COLUMN "
				+ PortalDBEnum.DEVICES.platformId + " varchar(32) NOT NULL AFTER `userId`");
		upgradeMap.put(26, ddl26);

		ArrayList<String> ddl29 = new ArrayList<>();
		ddl29.add("ALTER TABLE `platformportal`.`application` DROP COLUMN `repositoryName`");
		upgradeMap.put(29, ddl29);

		ArrayList<String> ddl30 = new ArrayList<>();
		ddl30.add(
				"ALTER TABLE `platformportal`.`devices` ADD COLUMN `isActivationConfirmed` TINYINT(1) default 1 AFTER `action`");
		ddl30.add("DROP TABLE IF EXISTS `platformportal`.`applicationserviceports`");
		ddl30.add(createApplicationServicePorts());
		upgradeMap.put(30, ddl30);

		ArrayList<String> ddl31 = new ArrayList<>();
		ddl31.add("DROP TABLE IF EXISTS `platformportal`.`applicationserviceports`");
		ddl31.add(createApplicationServicePorts());
		upgradeMap.put(31, ddl31);

		ArrayList<String> ddl32 = new ArrayList<>();
		ddl32.add(createDockerEventLoggerTable());
		upgradeMap.put(32, ddl32);

		ArrayList<String> ddl33 = new ArrayList<>();
		ddl33.add(createAppTypeTable());
		ddl33.add(
				"ALTER TABLE `platformportal`.`application` ADD COLUMN `appTypeId` varchar(32) NOT NULL AFTER `appStatus`");
		upgradeMap.put(33, ddl33);

		ArrayList<String> ddl34 = new ArrayList<>();

		ddl34.add(
				"ALTER TABLE `platformportal`.`application` ADD FOREIGN KEY (`appTypeId`) REFERENCES `applicationType` (`typeId`)");
		upgradeMap.put(34, ddl34);

		ArrayList<String> ddl35 = new ArrayList<>();
		ddl35.add("ALTER TABLE " + PortalDBEnum.TABLE_NAMES.applicationversions.name() + " ADD COLUMN "
				+ PortalDBEnum.APPLICATION_VERSIONS.toExecuteOrder + " TEXT AFTER `redirectSection`");
		upgradeMap.put(35, ddl35);

		ArrayList<String> ddl36 = new ArrayList<>();
		ddl36.add("ALTER TABLE " + PortalDBEnum.TABLE_NAMES.installJobs + " MODIFY COLUMN "
				+ PortalDBEnum.INSTALL_JOBS.lastModified
				+ " timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP");

		ddl36.add("UPDATE " + PortalDBEnum.TABLE_NAMES.installJobs + " SET " + PortalDBEnum.INSTALL_JOBS.lastModified
				+ " = NOW()");

		ddl36.add("DELETE FROM " + PortalDBEnum.TABLE_NAMES.boxStatics.name());
		ddl36.add("ALTER TABLE " + PortalDBEnum.TABLE_NAMES.boxStatics.name() + " ADD PRIMARY KEY("
				+ PortalDBEnum.BOX_STATICS.deviceId + ")");
		upgradeMap.put(36, ddl36);

		ArrayList<String> ddl37 = new ArrayList<>();
		ddl37.add("ALTER TABLE application DROP INDEX title");
		upgradeMap.put(37, ddl37);

		// Drop FOREIGN key
		ArrayList<String> ddl38 = new ArrayList<>();
		ddl38.add("ALTER TABLE `platformportal`.`company` DROP FOREIGN KEY `company_ibfk_1`");
		ddl38.add("ALTER TABLE `platformportal`.`company` drop index projectId");
		ddl38.add(
				"ALTER TABLE `platformportal`.`project` ADD COLUMN `companyId` VARCHAR(32) NOT NULL AFTER `projectId`");
		upgradeMap.put(38, ddl38);

		/*** Version 41 ***/
		ArrayList<String> ddl41 = new ArrayList<>();
		ddl41.add("ALTER TABLE `platformportal`.`nodes` ADD COLUMN `network` TEXT  AFTER `deviceId`");
		upgradeMap.put(41, ddl41);

		ArrayList<String> ddl42 = new ArrayList<>();
		ddl42.add("ALTER TABLE " + PortalDBEnum.TABLE_NAMES.platform.name() + " ADD COLUMN "
				+ PortalDBEnum.PLATFORM.ordervalue.name() + " INTEGER AFTER "
				+ PortalDBEnum.PLATFORM.platformActualName.name());
		upgradeMap.put(42, ddl42);

		/*** Version 44 ***/
		ArrayList<String> ddl44 = new ArrayList<>();
		ddl44.add(
				"ALTER TABLE `platformportal`.`company` ADD COLUMN `companyStatus` tinyint(1) NOT NULL AFTER `email`");
		upgradeMap.put(44, ddl44);

		/*** Version 48 ***/
		/**
		 * change column statics longtext in boxStatics table,
		 */
		ArrayList<String> ddl48 = new ArrayList<>();
		ddl48.add("ALTER TABLE `platformportal`.`boxStatics` CHANGE COLUMN `statics` `statics` LONGTEXT NOT NULL");
		upgradeMap.put(48, ddl48);

		/*** Version 49 ***/
		ArrayList<String> ddl49 = new ArrayList<>();
		ddl49.add("ALTER TABLE `platformportal`.`installJobs` " + " ADD COLUMN `message` TEXT  AFTER `timeStamp` , "
				+ " ADD COLUMN `detail` TEXT  AFTER `message` ");

		upgradeMap.put(49, ddl49);

		/*** Version 50 ***/
		ArrayList<String> ddl50 = new ArrayList<>();
		ddl50.add("ALTER TABLE `platformportal`.`discoverydetails` CHANGE COLUMN `sPort1` `sPort1` TEXT NOT NULL");
		ddl50.add("ALTER TABLE `platformportal`.`discoverydetails` CHANGE COLUMN `sPort2` `sPort2` TEXT DEFAULT NULL");
		ddl50.add("ALTER TABLE `platformportal`.`discoverydetails` CHANGE COLUMN `sPort3` `sPort3` TEXT DEFAULT NULL");
		ddl50.add("ALTER TABLE `platformportal`.`discoverydetails` CHANGE COLUMN `sPort4` `sPort4` TEXT DEFAULT NULL");
		ddl50.add("ALTER TABLE `platformportal`.`discoverydetails` CHANGE COLUMN `sPort5` `sPort5` TEXT DEFAULT NULL");

		ddl50.add(
				"ALTER TABLE `platformportal`.`discoveryjardetails` CHANGE COLUMN `sPort1` `sPort1` TEXT DEFAULT NULL");
		ddl50.add(
				"ALTER TABLE `platformportal`.`discoveryjardetails` CHANGE COLUMN `sPort2` `sPort2` TEXT DEFAULT NULL");
		ddl50.add(
				"ALTER TABLE `platformportal`.`discoveryjardetails` CHANGE COLUMN `sPort3` `sPort3` TEXT DEFAULT NULL");
		ddl50.add(
				"ALTER TABLE `platformportal`.`discoveryjardetails` CHANGE COLUMN `sPort4` `sPort4` TEXT DEFAULT NULL");
		ddl50.add(
				"ALTER TABLE `platformportal`.`discoveryjardetails` CHANGE COLUMN `sPort5` `sPort5` TEXT DEFAULT NULL");

		upgradeMap.put(50, ddl50);

		/**
		 * Add column deviceState in node table to store Master node State
		 * whether ActiveMaster or Backup.
		 */
		ArrayList<String> ddl51 = new ArrayList<>();
		ddl51.add(createActivityLoggerTable());

		upgradeMap.put(51, ddl51);

		ArrayList<String> ddl52 = new ArrayList<>();
		ddl52.add("ALTER TABLE `functionversions` MODIFY COLUMN " + PortalDBEnum.FUNCTION_VERSIONS.version.name()
				+ " INTEGER");
		upgradeMap.put(52, ddl52);

		ArrayList<String> ddl53 = new ArrayList<>();
		ddl53.add(createVirtualURLTable());
		upgradeMap.put(53, ddl53);

		ArrayList<String> ddl54 = new ArrayList<>();
		ddl54.add("ALTER TABLE " + PortalDBEnum.TABLE_NAMES.devices.name() + " ADD COLUMN "
				+ PortalDBEnum.DEVICES.swPlatformId + " varchar(32) NOT NULL AFTER `platformId`");

		ddl54.add("ALTER VIEW " + PortalDBEnum.VIEW_NAMES.devicesnodes_view + " AS ("

				+ " SELECT "

				+ PortalDBEnum.TABLE_NAMES.devices + "." + PortalDBEnum.DEVICES.deviceId + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.devices_deviceId + ", "

				+ PortalDBEnum.TABLE_NAMES.devices + "." + PortalDBEnum.DEVICES.userId + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.devices_userId + ", "

				+ PortalDBEnum.TABLE_NAMES.devices + "." + PortalDBEnum.DEVICES.platformId + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.devices_platformId + ", "

				+ PortalDBEnum.TABLE_NAMES.devices + "." + PortalDBEnum.DEVICES.swPlatformId + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.devices_swPlatformId + ", "

				+ PortalDBEnum.TABLE_NAMES.devices + "." + PortalDBEnum.DEVICES.deviceName + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.devices_deviceName + ", "

				+ PortalDBEnum.TABLE_NAMES.devices + "." + PortalDBEnum.DEVICES.deviceStatus + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.devices_deviceStatus + ", "

				+ PortalDBEnum.TABLE_NAMES.devices + "." + PortalDBEnum.DEVICES.tags + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.devices_tags + ", "

				+ PortalDBEnum.TABLE_NAMES.devices + "." + PortalDBEnum.DEVICES.description + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.devices_description + ", "

				+ PortalDBEnum.TABLE_NAMES.devices + "." + PortalDBEnum.DEVICES.action + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.devices_action + ", "

				+ PortalDBEnum.TABLE_NAMES.devices + "." + PortalDBEnum.DEVICES.isActivationConfirmed + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.devices_isActivationConfirmed + ", "

				+ PortalDBEnum.TABLE_NAMES.devices + "." + PortalDBEnum.DEVICES.deviceType + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.devices_deviceType + ", "

				+ PortalDBEnum.TABLE_NAMES.devices + "." + PortalDBEnum.DEVICES.createdDate + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.devices_createdDate + ", "

				+ PortalDBEnum.TABLE_NAMES.devices + "." + PortalDBEnum.DEVICES.modifiedDate + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.devices_modifiedDate + ", "

				+ PortalDBEnum.TABLE_NAMES.nodes + "." + PortalDBEnum.NODES.nodeId + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.nodes_nodeId + ", "

				+ PortalDBEnum.TABLE_NAMES.nodes + "." + PortalDBEnum.NODES.deviceName + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.nodes_deviceName + ", "

				+ PortalDBEnum.TABLE_NAMES.nodes + "." + PortalDBEnum.NODES.softwareVersion + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.nodes_softwareVersion + ", "

				+ PortalDBEnum.TABLE_NAMES.nodes + "." + PortalDBEnum.NODES.hardwareInfo + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.nodes_hardwareInfo + ", "

				+ PortalDBEnum.TABLE_NAMES.nodes + "." + PortalDBEnum.NODES.macAddress + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.nodes_macAddress + ", "

				+ PortalDBEnum.TABLE_NAMES.nodes + "." + PortalDBEnum.NODES.hostName + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.nodes_hostName + ", "

				// + PortalDBEnum.TABLE_NAMES.nodes + "." +
				// PortalDBEnum.NODES.email + " as " +
				// PortalDBEnum.DEVICES_NODES_VIEW.nodes_email + ", "

				// + PortalDBEnum.TABLE_NAMES.nodes + "." +
				// PortalDBEnum.NODES.supportToken + " as " +
				// PortalDBEnum.DEVICES_NODES_VIEW.nodes_supportToken + ", "

				+ PortalDBEnum.TABLE_NAMES.nodes + "." + PortalDBEnum.NODES.tags + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.nodes_tags + ", "

				+ PortalDBEnum.TABLE_NAMES.nodes + "." + PortalDBEnum.NODES.description + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.nodes_description + ", "

				+ PortalDBEnum.TABLE_NAMES.nodes + "." + PortalDBEnum.NODES.machineId + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.nodes_machineId + ", "

				+ PortalDBEnum.TABLE_NAMES.nodes + "." + PortalDBEnum.NODES.nativeAppId + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.nodes_nativeAppId + ", "

				+ PortalDBEnum.TABLE_NAMES.nodes + "." + PortalDBEnum.NODES.action + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.nodes_action + ", "

				+ PortalDBEnum.TABLE_NAMES.nodes + "." + PortalDBEnum.NODES.deviceRole + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.nodes_deviceRole + ", "

				+ PortalDBEnum.TABLE_NAMES.nodes + "." + PortalDBEnum.NODES.deviceId + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.nodes_deviceId + ", "

				+ PortalDBEnum.TABLE_NAMES.nodes + "." + PortalDBEnum.NODES.createdDate + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.nodes_createdDate + ", "

				+ PortalDBEnum.TABLE_NAMES.nodes + "." + PortalDBEnum.NODES.modifiedDate + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.nodes_modifiedDate + " FROM "

				+ PortalDBEnum.TABLE_NAMES.devices

				+ " JOIN "

				+ PortalDBEnum.TABLE_NAMES.nodes

				+ " ON "

				+ PortalDBEnum.TABLE_NAMES.devices + "." + PortalDBEnum.DEVICES.deviceId

				+ " = "

				+ PortalDBEnum.TABLE_NAMES.nodes + "." + PortalDBEnum.NODES.deviceId

				+ ")");
		upgradeMap.put(54, ddl54);

		ArrayList<String> ddl56 = new ArrayList<>();
		ddl56.add("ALTER TABLE " + PortalDBEnum.TABLE_NAMES.relayservers.name() + " MODIFY COLUMN "
				+ PortalDBEnum.RELAY_SERVERS.nPortRangeStart.name() + " int(11) not null");
		ddl56.add("ALTER TABLE " + PortalDBEnum.TABLE_NAMES.relayservers.name() + " MODIFY COLUMN "
				+ PortalDBEnum.RELAY_SERVERS.nPortRangeEnd.name() + " int(11) not null");
		ddl56.add("ALTER TABLE " + PortalDBEnum.TABLE_NAMES.relayservers.name() + " MODIFY COLUMN "
				+ PortalDBEnum.RELAY_SERVERS.sPriority.name() + " tinyint(4)");

		ddl56.add("ALTER TABLE " + PortalDBEnum.TABLE_NAMES.supportrelayservers.name() + " MODIFY COLUMN "
				+ PortalDBEnum.SUPPORT_RELAY_SERVERS.nPortRangeStart.name() + " int(11) not null");
		ddl56.add("ALTER TABLE " + PortalDBEnum.TABLE_NAMES.supportrelayservers.name() + " MODIFY COLUMN "
				+ PortalDBEnum.SUPPORT_RELAY_SERVERS.nPortRangeEnd.name() + " int(11) not null");
		ddl56.add("ALTER TABLE " + PortalDBEnum.TABLE_NAMES.supportrelayservers.name() + " MODIFY COLUMN "
				+ PortalDBEnum.SUPPORT_RELAY_SERVERS.sPriority.name() + " tinyint(4)");

		ddl56.add("ALTER TABLE " + PortalDBEnum.TABLE_NAMES.emailServers.name() + " MODIFY COLUMN "
				+ PortalDBEnum.EMAIL_SERVERS.priority.name() + " tinyint(4)");

		upgradeMap.put(56, ddl56);

		/*** Version 57 ***/
		/**
		 * Add column deviceState in node table to store Master node State
		 * whether ActiveMaster or Backup.
		 */
		ArrayList<String> ddl57 = new ArrayList<>();
		ddl57.add("ALTER TABLE " + PortalDBEnum.TABLE_NAMES.nodes.name() + " ADD COLUMN "
				+ PortalDBEnum.NODES.deviceState.name() + " tinyint(1) DEFAULT 0 AFTER "
				+ PortalDBEnum.NODES.deviceRole.name());
		ddl57.add(" ALTER VIEW " + PortalDBEnum.VIEW_NAMES.devicesnodes_view + " AS (" + " SELECT "
				+ PortalDBEnum.TABLE_NAMES.devices + "." + PortalDBEnum.DEVICES.deviceId + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.devices_deviceId + ", " + PortalDBEnum.TABLE_NAMES.devices + "."
				+ PortalDBEnum.DEVICES.userId + " as " + PortalDBEnum.DEVICES_NODES_VIEW.devices_userId + ", "
				+ PortalDBEnum.TABLE_NAMES.devices + "." + PortalDBEnum.DEVICES.platformId + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.devices_platformId + ", " + PortalDBEnum.TABLE_NAMES.devices + "."
				+ PortalDBEnum.DEVICES.swPlatformId + " as " + PortalDBEnum.DEVICES_NODES_VIEW.devices_swPlatformId
				+ ", " + PortalDBEnum.TABLE_NAMES.devices + "." + PortalDBEnum.DEVICES.deviceName + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.devices_deviceName + ", " + PortalDBEnum.TABLE_NAMES.devices + "."
				+ PortalDBEnum.DEVICES.deviceStatus + " as " + PortalDBEnum.DEVICES_NODES_VIEW.devices_deviceStatus
				+ ", " + PortalDBEnum.TABLE_NAMES.devices + "." + PortalDBEnum.DEVICES.tags + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.devices_tags + ", " + PortalDBEnum.TABLE_NAMES.devices + "."
				+ PortalDBEnum.DEVICES.description + " as " + PortalDBEnum.DEVICES_NODES_VIEW.devices_description + ", "
				+ PortalDBEnum.TABLE_NAMES.devices + "." + PortalDBEnum.DEVICES.action + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.devices_action + ", " + PortalDBEnum.TABLE_NAMES.devices + "."
				+ PortalDBEnum.DEVICES.isActivationConfirmed + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.devices_isActivationConfirmed + ", "
				+ PortalDBEnum.TABLE_NAMES.devices + "." + PortalDBEnum.DEVICES.deviceType + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.devices_deviceType + ", " + PortalDBEnum.TABLE_NAMES.devices + "."
				+ PortalDBEnum.DEVICES.createdDate + " as " + PortalDBEnum.DEVICES_NODES_VIEW.devices_createdDate + ", "
				+ PortalDBEnum.TABLE_NAMES.devices + "." + PortalDBEnum.DEVICES.modifiedDate + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.devices_modifiedDate + ", "

				+ PortalDBEnum.TABLE_NAMES.nodes + "." + PortalDBEnum.NODES.nodeId + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.nodes_nodeId + ", " + PortalDBEnum.TABLE_NAMES.nodes + "."
				+ PortalDBEnum.NODES.deviceName + " as " + PortalDBEnum.DEVICES_NODES_VIEW.nodes_deviceName + ", "
				+ PortalDBEnum.TABLE_NAMES.nodes + "." + PortalDBEnum.NODES.softwareVersion + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.nodes_softwareVersion + ", " + PortalDBEnum.TABLE_NAMES.nodes + "."
				+ PortalDBEnum.NODES.hardwareInfo + " as " + PortalDBEnum.DEVICES_NODES_VIEW.nodes_hardwareInfo + ", "
				+ PortalDBEnum.TABLE_NAMES.nodes + "." + PortalDBEnum.NODES.macAddress + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.nodes_macAddress + ", " + PortalDBEnum.TABLE_NAMES.nodes + "."
				+ PortalDBEnum.NODES.hostName + " as " + PortalDBEnum.DEVICES_NODES_VIEW.nodes_hostName + ", "
				// + PortalDBEnum.TABLE_NAMES.nodes + "." +
				// PortalDBEnum.NODES.email + " as " +
				// PortalDBEnum.DEVICES_NODES_VIEW.nodes_email + ", "
				// + PortalDBEnum.TABLE_NAMES.nodes + "." +
				// PortalDBEnum.NODES.supportToken + " as " +
				// PortalDBEnum.DEVICES_NODES_VIEW.nodes_supportToken + ", "
				+ PortalDBEnum.TABLE_NAMES.nodes + "." + PortalDBEnum.NODES.tags + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.nodes_tags + ", " + PortalDBEnum.TABLE_NAMES.nodes + "."
				+ PortalDBEnum.NODES.description + " as " + PortalDBEnum.DEVICES_NODES_VIEW.nodes_description + ", "
				+ PortalDBEnum.TABLE_NAMES.nodes + "." + PortalDBEnum.NODES.machineId + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.nodes_machineId + ", " + PortalDBEnum.TABLE_NAMES.nodes + "."
				+ PortalDBEnum.NODES.nativeAppId + " as " + PortalDBEnum.DEVICES_NODES_VIEW.nodes_nativeAppId + ", "
				+ PortalDBEnum.TABLE_NAMES.nodes + "." + PortalDBEnum.NODES.action + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.nodes_action + ", " + PortalDBEnum.TABLE_NAMES.nodes + "."
				+ PortalDBEnum.NODES.deviceRole + " as " + PortalDBEnum.DEVICES_NODES_VIEW.nodes_deviceRole + ", "
				+ PortalDBEnum.TABLE_NAMES.nodes + "." + PortalDBEnum.NODES.deviceState + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.nodes_deviceState + ", " + PortalDBEnum.TABLE_NAMES.nodes + "."
				+ PortalDBEnum.NODES.deviceId + " as " + PortalDBEnum.DEVICES_NODES_VIEW.nodes_deviceId + ", "
				+ PortalDBEnum.TABLE_NAMES.nodes + "." + PortalDBEnum.NODES.createdDate + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.nodes_createdDate + ", " + PortalDBEnum.TABLE_NAMES.nodes + "."
				+ PortalDBEnum.NODES.modifiedDate + " as " + PortalDBEnum.DEVICES_NODES_VIEW.nodes_modifiedDate

				+ " FROM " + PortalDBEnum.TABLE_NAMES.devices + " JOIN " + PortalDBEnum.TABLE_NAMES.nodes + " ON "
				+ PortalDBEnum.TABLE_NAMES.devices + "." + PortalDBEnum.DEVICES.deviceId + " = "
				+ PortalDBEnum.TABLE_NAMES.nodes + "." + PortalDBEnum.NODES.deviceId + ")");

		upgradeMap.put(57, ddl57);

		/*** Version 58 ***/
		/**
		 * added table for Rule and ruleTriggerLog
		 */
		ArrayList<String> ddl58 = new ArrayList<>();
		ddl58.add("ALTER TABLE " + PortalDBEnum.TABLE_NAMES.supportrelayservers.name() + " MODIFY COLUMN "
				+ PortalDBEnum.SUPPORT_RELAY_SERVERS.sRPassword.name() + " varchar(50) NOT NULL");
		ddl58.add("ALTER TABLE " + PortalDBEnum.TABLE_NAMES.relayservers.name() + " MODIFY COLUMN "
				+ PortalDBEnum.RELAY_SERVERS.sRPassword.name() + "  varchar(50) NOT NULL");
		/**
		 * added table for Rule and ruleTriggerLog
		 */
		ddl58.add(createRuleTable());
		ddl58.add(createRuleTriggerLoggerTable());
		upgradeMap.put(58, ddl58);

		ArrayList<String> ddl59 = new ArrayList<>();
		ddl59.add("ALTER IGNORE TABLE " + PortalDBEnum.TABLE_NAMES.labels.name() + " ADD UNIQUE (`" + LABELS.labelName
				+ "`,`" + LABELS.parentLabelId + "`,`" + LABELS.userId + "`)");
		upgradeMap.put(59, ddl59);

		ArrayList<String> ddl60 = new ArrayList<>();
		ddl60.add("ALTER TABLE " + PortalDBEnum.TABLE_NAMES.rule.name() + " ADD UNIQUE ("
				+ PortalDBEnum.RULE.ruleType.name() + ")");
		upgradeMap.put(60, ddl60);

		ArrayList<String> ddl61 = new ArrayList<>();
		ddl61.add(createGroupEdgeCoreTable());
		upgradeMap.put(61, ddl61);

		ArrayList<String> ddl62 = new ArrayList<>();
		ddl62.add("ALTER TABLE " + PortalDBEnum.TABLE_NAMES.rule.name() + " DROP INDEX "
				+ PortalDBEnum.RULE.ruleType.name());
		ddl62.add("ALTER TABLE " + PortalDBEnum.TABLE_NAMES.rule.name() + " ADD UNIQUE combrule ("
				+ PortalDBEnum.RULE.ruleType.name() + "," + PortalDBEnum.RULE.serverType.name() + ")");
		upgradeMap.put(62, ddl62);

		ArrayList<String> ddl63 = new ArrayList<>();
		ddl63.add(createSettingsTable());
		upgradeMap.put(63, ddl63);

		ArrayList<String> ddl65 = new ArrayList<>();
		ddl65.add(createAlertsTable());
		upgradeMap.put(65, ddl65);

		ArrayList<String> ddl66 = new ArrayList<>();
		ddl66.add("ALTER TABLE " + PortalDBEnum.TABLE_NAMES.emailServers.name() + " ADD COLUMN "
				+ PortalDBEnum.EMAIL_SERVERS.istls + " tinyint DEFAULT FALSE AFTER `priority`");
		upgradeMap.put(66, ddl66);

		/**
		 * //Bug 745 - Issues on creating "My User Group and My Projects" with
		 * ASCII characters - changed charset to utf8mb4
		 */

		ArrayList<String> ddl67 = new ArrayList<>();
		ddl67.add("ALTER TABLE application MODIFY title VARCHAR(50) " + characterset
				+ " NOT NULL, MODIFY description TEXT " + characterset + " NOT NULL, MODIFY webAddress TEXT "
				+ characterset + " NOT NULL");

		ddl67.add("ALTER TABLE applicationType MODIFY typeDisplayName Varchar(100) " + characterset + " NOT NULL");

		ddl67.add("ALTER TABLE applicationserviceports MODIFY serviceName Varchar(100) " + characterset + " NOT NULL");

		ddl67.add("ALTER TABLE applicationversions MODIFY releaseNotes TEXT " + characterset + " NOT NULL");

		ddl67.add("ALTER TABLE company MODIFY companyName VARCHAR(50) " + characterset + " NOT NULL,"
				+ " MODIFY address VARCHAR(100) " + characterset + " NOT NULL," + " MODIFY city VARCHAR(25) "
				+ characterset + " NOT NULL," + " MODIFY state VARCHAR(25) " + characterset + " NOT NULL,"
				+ " MODIFY country VARCHAR(50) " + characterset + " NOT NULL, " + " MODIFY webAddress VARCHAR(100) "
				+ characterset);

		ddl67.add("ALTER TABLE devices MODIFY deviceName VARCHAR(50) " + characterset + " NOT NULL,"
				+ " MODIFY description TEXT " + characterset);

		ddl67.add("ALTER TABLE emailServers MODIFY serverName VARCHAR(50) " + characterset + " NOT NULL");

		ddl67.add("ALTER TABLE functions MODIFY name VARCHAR(50) " + characterset + " NOT NULL");

		ddl67.add("ALTER TABLE installJobs MODIFY message TEXT " + characterset);

		ddl67.add("ALTER TABLE labels MODIFY labelName VARCHAR(32) " + characterset + " NOT NULL");

		ddl67.add("ALTER TABLE nodes MODIFY deviceName VARCHAR(50) " + characterset + " NOT NULL");

		ddl67.add("ALTER TABLE project MODIFY name VARCHAR(50) " + characterset + " NOT NULL,"
				+ " MODIFY description TEXT " + characterset + " NOT NULL");

		ddl67.add("ALTER TABLE relayservers MODIFY sRelayName VARCHAR(100) " + characterset + " NOT NULL");

		ddl67.add("ALTER TABLE supportrelayservers MODIFY sRelayName VARCHAR(100) " + characterset + " NOT NULL");

		upgradeMap.put(67, ddl67);

		ArrayList<String> ddl68 = new ArrayList<>();
		ddl68.add(createNetworkTable());
		ddl68.add(createApplicationNetworkTable());
		upgradeMap.put(68, ddl68);

		ArrayList<String> ddl69 = new ArrayList<>();
		ddl69.add(
				"Alter table emailServers modify column userName text NOT NULL, modify column password text NOT NULL");
		ddl69.add(
				"Alter table supportrelayservers modify column sRUserName text NOT NULL, modify column sRPassword text NOT NULL");
		ddl69.add(
				"Alter table relayservers modify column sRUserName text NOT NULL, modify column sRPassword text NOT NULL");
		upgradeMap.put(69, ddl69);

		ArrayList<String> ddl70 = new ArrayList<>();
		ddl70.add("ALTER TABLE " + PortalDBEnum.TABLE_NAMES.application.name() + " ADD COLUMN "
				+ PortalDBEnum.APPLICATION.runAsService + " tinyint DEFAULT FALSE AFTER `currency`");
		upgradeMap.put(70, ddl70);

		ArrayList<String> ddl71 = new ArrayList<>();
		ddl71.add("ALTER TABLE " + PortalDBEnum.TABLE_NAMES.applicationversions.name() + " ADD COLUMN "
				+ PortalDBEnum.APPLICATION_VERSIONS.composeVersion + " varchar(32) DEFAULT '' AFTER "
				+ PortalDBEnum.APPLICATION_VERSIONS.toExecuteOrder);
		upgradeMap.put(71, ddl71);

		ArrayList<String> ddl72 = new ArrayList<>();
		ddl72.add(
				"ALTER TABLE `platformportal`.`applicationplatform` CHANGE COLUMN `repositoryName` `repositoryName` VARCHAR(255) NOT NULL");
		upgradeMap.put(72, ddl72);

		ArrayList<String> ddl73 = new ArrayList<>();
		ddl73.add(createAppSecret());
		ddl73.add(createJobSecret());
		upgradeMap.put(73, ddl73);

		ArrayList<String> ddl74 = new ArrayList<>();
		ddl74.add("ALTER TABLE " + PortalDBEnum.TABLE_NAMES.appSecret.name() + " MODIFY COLUMN "
				+ PortalDBEnum.APP_SECRET.serviceName.name() + " varchar(255)");
		// ddl74.add("ALTER TABLE " + PortalDBEnum.TABLE_NAMES.jobSecret.name()
		// + " ADD COLUMN " + PortalDBEnum.JOB_SECRET.serviceName + "
		// varchar(255) NOT NULL AFTER " + PortalDBEnum.JOB_SECRET.jobId);
		upgradeMap.put(74, ddl74);

		ArrayList<String> ddl75 = new ArrayList<>();
		ddl75.addAll(modifyUniqueContraint());
		upgradeMap.put(75, ddl75);

		ArrayList<String> ddl76 = new ArrayList<>();

		ddl76.add(getSupportTokensTables());
		ddl76.add(AlterNodesTable());

		ddl76.addAll(AlterDeviceNodesTokenView());

		upgradeMap.put(76, ddl76);

		// added hostkey column in relay server and support relay server
		ArrayList<String> ddl77 = new ArrayList<>();
		ddl77.add("ALTER TABLE " + PortalDBEnum.TABLE_NAMES.relayservers.name() + " ADD COLUMN "
				+ PortalDBEnum.RELAY_SERVERS.sHostKey + " TEXT NOT NULL  AFTER "
				+ PortalDBEnum.RELAY_SERVERS.sRPassword);
		ddl77.add("ALTER TABLE " + PortalDBEnum.TABLE_NAMES.supportrelayservers.name() + " ADD COLUMN "
				+ PortalDBEnum.SUPPORT_RELAY_SERVERS.sHostKey + " TEXT NOT NULL  AFTER "
				+ PortalDBEnum.SUPPORT_RELAY_SERVERS.sRPassword);
		upgradeMap.put(77, ddl77);

		// version 78 sot order on resources
		ArrayList<String> ddl78 = new ArrayList<>();
		ddl78.add("ALTER TABLE " + PortalDBEnum.TABLE_NAMES.downloads.name() + " ADD COLUMN "
				+ PortalDBEnum.DOWNLOADS.sortOrder + " int not NULL DEFAULT 1 AFTER " + PortalDBEnum.DOWNLOADS.details);
		upgradeMap.put(78, ddl78);

		/*** Version 79 ***/
		// modify id column to varchar 32 in activityLog table
		ArrayList<String> ddl79 = new ArrayList<>();
		ddl79.add("ALTER TABLE " + PortalDBEnum.TABLE_NAMES.activityLog.name() + " MODIFY COLUMN "
				+ PortalDBEnum.ACTIVITY_LOG.id.name() + " varchar(32) not null");
		upgradeMap.put(79, ddl79);

		return upgradeMap;
	}

	public List<String> AlterDeviceNodesTokenView() {

		List<String> lstAlterDeviceNodesView = new ArrayList<>();
		lstAlterDeviceNodesView.add(" DROP VIEW " + PortalDBEnum.VIEW_NAMES.devicesnodes_view + " ");
		StringBuilder alterView = new StringBuilder();
		alterView.append("CREATE VIEW " + PortalDBEnum.VIEW_NAMES.devicesnodes_view + " AS (" + " SELECT "
				+ PortalDBEnum.TABLE_NAMES.devices + "." + PortalDBEnum.DEVICES.deviceId + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.devices_deviceId + ", " + PortalDBEnum.TABLE_NAMES.devices + "."
				+ PortalDBEnum.DEVICES.userId + " as " + PortalDBEnum.DEVICES_NODES_VIEW.devices_userId + ", "
				+ PortalDBEnum.TABLE_NAMES.devices + "." + PortalDBEnum.DEVICES.platformId + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.devices_platformId + ", "

				+ PortalDBEnum.TABLE_NAMES.devices + "." + PortalDBEnum.DEVICES.swPlatformId + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.devices_swPlatformId + ", "

				+ PortalDBEnum.TABLE_NAMES.devices + "." + PortalDBEnum.DEVICES.deviceName + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.devices_deviceName + ", " + PortalDBEnum.TABLE_NAMES.devices + "."
				+ PortalDBEnum.DEVICES.deviceStatus + " as " + PortalDBEnum.DEVICES_NODES_VIEW.devices_deviceStatus
				+ ", " + PortalDBEnum.TABLE_NAMES.devices + "." + PortalDBEnum.DEVICES.tags + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.devices_tags + ", " + PortalDBEnum.TABLE_NAMES.devices + "."
				+ PortalDBEnum.DEVICES.description + " as " + PortalDBEnum.DEVICES_NODES_VIEW.devices_description + ", "
				+ PortalDBEnum.TABLE_NAMES.devices + "." + PortalDBEnum.DEVICES.action + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.devices_action + ", " + PortalDBEnum.TABLE_NAMES.devices + "."
				+ PortalDBEnum.DEVICES.isActivationConfirmed + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.devices_isActivationConfirmed + ", "
				+ PortalDBEnum.TABLE_NAMES.devices + "." + PortalDBEnum.DEVICES.deviceType + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.devices_deviceType + ", " + PortalDBEnum.TABLE_NAMES.devices + "."
				+ PortalDBEnum.DEVICES.createdDate + " as " + PortalDBEnum.DEVICES_NODES_VIEW.devices_createdDate + ", "
				+ PortalDBEnum.TABLE_NAMES.devices + "." + PortalDBEnum.DEVICES.modifiedDate + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.devices_modifiedDate + ", "

				+ PortalDBEnum.TABLE_NAMES.nodes + "." + PortalDBEnum.NODES.nodeId + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.nodes_nodeId + ", " + PortalDBEnum.TABLE_NAMES.nodes + "."
				+ PortalDBEnum.NODES.deviceName + " as " + PortalDBEnum.DEVICES_NODES_VIEW.nodes_deviceName + ", "
				+ PortalDBEnum.TABLE_NAMES.nodes + "." + PortalDBEnum.NODES.softwareVersion + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.nodes_softwareVersion + ", " + PortalDBEnum.TABLE_NAMES.nodes + "."
				+ PortalDBEnum.NODES.hardwareInfo + " as " + PortalDBEnum.DEVICES_NODES_VIEW.nodes_hardwareInfo + ", "
				+ PortalDBEnum.TABLE_NAMES.nodes + "." + PortalDBEnum.NODES.macAddress + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.nodes_macAddress + ", " + PortalDBEnum.TABLE_NAMES.nodes + "."
				+ PortalDBEnum.NODES.hostName + " as " + PortalDBEnum.DEVICES_NODES_VIEW.nodes_hostName + ", "
				+ PortalDBEnum.TABLE_NAMES.nodes + "." + PortalDBEnum.NODES.tags + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.nodes_tags + ", " + PortalDBEnum.TABLE_NAMES.nodes + "."
				+ PortalDBEnum.NODES.description + " as " + PortalDBEnum.DEVICES_NODES_VIEW.nodes_description + ", "
				+ PortalDBEnum.TABLE_NAMES.nodes + "." + PortalDBEnum.NODES.machineId + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.nodes_machineId + ", " + PortalDBEnum.TABLE_NAMES.nodes + "."
				+ PortalDBEnum.NODES.nativeAppId + " as " + PortalDBEnum.DEVICES_NODES_VIEW.nodes_nativeAppId + ", "
				+ PortalDBEnum.TABLE_NAMES.nodes + "." + PortalDBEnum.NODES.action + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.nodes_action + ", " + PortalDBEnum.TABLE_NAMES.nodes + "."
				+ PortalDBEnum.NODES.deviceRole + " as " + PortalDBEnum.DEVICES_NODES_VIEW.nodes_deviceRole + ", "
				+ PortalDBEnum.TABLE_NAMES.nodes + "." + PortalDBEnum.NODES.deviceState + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.nodes_deviceState + ", " + PortalDBEnum.TABLE_NAMES.nodes + "."
				+ PortalDBEnum.NODES.deviceId + " as " + PortalDBEnum.DEVICES_NODES_VIEW.nodes_deviceId + ", "
				+ PortalDBEnum.TABLE_NAMES.nodes + "." + PortalDBEnum.NODES.createdDate + " as "
				+ PortalDBEnum.DEVICES_NODES_VIEW.nodes_createdDate + ", " + PortalDBEnum.TABLE_NAMES.nodes + "."
				+ PortalDBEnum.NODES.modifiedDate + " as " + PortalDBEnum.DEVICES_NODES_VIEW.nodes_modifiedDate
				+ " FROM " + PortalDBEnum.TABLE_NAMES.devices + " JOIN " + PortalDBEnum.TABLE_NAMES.nodes + " ON "
				+ PortalDBEnum.TABLE_NAMES.devices + "." + PortalDBEnum.DEVICES.deviceId + " = "
				+ PortalDBEnum.TABLE_NAMES.nodes + "." + PortalDBEnum.NODES.deviceId + ")");
		lstAlterDeviceNodesView.add(alterView.toString());
		return lstAlterDeviceNodesView;
	}

	/**
	 * DML for supportTokens table.
	 */
	public String getSupportTokensTables() {
		StringBuilder sb = new StringBuilder();

		sb.append("CREATE TABLE IF NOT EXISTS `supportTokens` (").append("`supportTokenId` varchar(32) NOT NULL,")
				.append("`nodeId` varchar(32) NOT NULL,").append("`hostName` varchar(32) NOT NULL,")
				.append("`email` text DEFAULT NULL,").append("`token` varchar(200) NOT NULL,")
				.append("`userId` varchar(32) NOT NULL,").append("`expirytime` long NOT NULL ,")
				.append("`status` tinyint(1) DEFAULT 0,")
				.append("`createdon` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ,")
				.append("`modifiedon` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,")
				.append("PRIMARY KEY (`supportTokenId`),").append("UNIQUE KEY `supportToken_UNIQUE` (`token`),")
				.append("CONSTRAINT `nodes_supporttokenfk_1` FOREIGN KEY (`nodeId`) REFERENCES `nodes` (`nodeId`) ON DELETE CASCADE")
				.append(") ENGINE=InnoDB DEFAULT CHARSET=utf8");

		return sb.toString();
	}

	/**
	 * DML for nodes table.
	 */
	public String AlterNodesTable() {
		StringBuilder sb = new StringBuilder();

		sb.append("Alter Table nodes ").append("DROP COLUMN ").append(NODES.email.name()).append(" , ")
				.append("DROP COLUMN ").append(NODES.supportToken.name());

		return sb.toString();
	}

	// public static void main(String[] args) {
	// String query = " ALTER VIEW " + PortalDBEnum.VIEW_NAMES.devicesnodes_view
	// + " AS ("
	// + " SELECT "
	// + PortalDBEnum.TABLE_NAMES.devices + "." + PortalDBEnum.DEVICES.deviceId
	// + " as " + PortalDBEnum.DEVICES_NODES_VIEW.devices_deviceId + ", "
	// + PortalDBEnum.TABLE_NAMES.devices + "." + PortalDBEnum.DEVICES.userId +
	// " as " + PortalDBEnum.DEVICES_NODES_VIEW.devices_userId + ", "
	// + PortalDBEnum.TABLE_NAMES.devices + "." +
	// PortalDBEnum.DEVICES.platformId + " as " +
	// PortalDBEnum.DEVICES_NODES_VIEW.devices_platformId + ", "
	// + PortalDBEnum.TABLE_NAMES.devices + "." +
	// PortalDBEnum.DEVICES.swPlatformId + " as " +
	// PortalDBEnum.DEVICES_NODES_VIEW.devices_swPlatformId + ", "
	// + PortalDBEnum.TABLE_NAMES.devices + "." +
	// PortalDBEnum.DEVICES.deviceName + " as " +
	// PortalDBEnum.DEVICES_NODES_VIEW.devices_deviceName + ", "
	// + PortalDBEnum.TABLE_NAMES.devices + "." +
	// PortalDBEnum.DEVICES.deviceStatus + " as " +
	// PortalDBEnum.DEVICES_NODES_VIEW.devices_deviceStatus + ", "
	// + PortalDBEnum.TABLE_NAMES.devices + "." + PortalDBEnum.DEVICES.tags + "
	// as " + PortalDBEnum.DEVICES_NODES_VIEW.devices_tags + ", "
	// + PortalDBEnum.TABLE_NAMES.devices + "." +
	// PortalDBEnum.DEVICES.description + " as " +
	// PortalDBEnum.DEVICES_NODES_VIEW.devices_description + ", "
	// + PortalDBEnum.TABLE_NAMES.devices + "." + PortalDBEnum.DEVICES.action +
	// " as " + PortalDBEnum.DEVICES_NODES_VIEW.devices_action + ", "
	// + PortalDBEnum.TABLE_NAMES.devices + "." +
	// PortalDBEnum.DEVICES.isActivationConfirmed + " as " +
	// PortalDBEnum.DEVICES_NODES_VIEW.devices_isActivationConfirmed + ", "
	// + PortalDBEnum.TABLE_NAMES.devices + "." +
	// PortalDBEnum.DEVICES.deviceType + " as " +
	// PortalDBEnum.DEVICES_NODES_VIEW.devices_deviceType + ", "
	// + PortalDBEnum.TABLE_NAMES.devices + "." +
	// PortalDBEnum.DEVICES.createdDate + " as " +
	// PortalDBEnum.DEVICES_NODES_VIEW.devices_createdDate + ", "
	// + PortalDBEnum.TABLE_NAMES.devices + "." +
	// PortalDBEnum.DEVICES.modifiedDate + " as " +
	// PortalDBEnum.DEVICES_NODES_VIEW.devices_modifiedDate + ", "
	//
	// + PortalDBEnum.TABLE_NAMES.nodes + "." + PortalDBEnum.NODES.nodeId + " as
	// " + PortalDBEnum.DEVICES_NODES_VIEW.nodes_nodeId + ", "
	// + PortalDBEnum.TABLE_NAMES.nodes + "." + PortalDBEnum.NODES.deviceName +
	// " as " + PortalDBEnum.DEVICES_NODES_VIEW.nodes_deviceName + ", "
	// + PortalDBEnum.TABLE_NAMES.nodes + "." +
	// PortalDBEnum.NODES.softwareVersion + " as " +
	// PortalDBEnum.DEVICES_NODES_VIEW.nodes_softwareVersion + ", "
	// + PortalDBEnum.TABLE_NAMES.nodes + "." + PortalDBEnum.NODES.hardwareInfo
	// + " as " + PortalDBEnum.DEVICES_NODES_VIEW.nodes_hardwareInfo + ", "
	// + PortalDBEnum.TABLE_NAMES.nodes + "." + PortalDBEnum.NODES.macAddress +
	// " as " + PortalDBEnum.DEVICES_NODES_VIEW.nodes_macAddress + ", "
	// + PortalDBEnum.TABLE_NAMES.nodes + "." + PortalDBEnum.NODES.hostName + "
	// as " + PortalDBEnum.DEVICES_NODES_VIEW.nodes_hostName + ", "
	// //+ PortalDBEnum.TABLE_NAMES.nodes + "." + PortalDBEnum.NODES.email + "
	// as " + PortalDBEnum.DEVICES_NODES_VIEW.nodes_email + ", "
	// //+ PortalDBEnum.TABLE_NAMES.nodes + "." +
	// PortalDBEnum.NODES.supportToken + " as " +
	// PortalDBEnum.DEVICES_NODES_VIEW.nodes_supportToken + ", "
	// + PortalDBEnum.TABLE_NAMES.nodes + "." + PortalDBEnum.NODES.tags + " as "
	// + PortalDBEnum.DEVICES_NODES_VIEW.nodes_tags + ", "
	// + PortalDBEnum.TABLE_NAMES.nodes + "." + PortalDBEnum.NODES.description +
	// " as " + PortalDBEnum.DEVICES_NODES_VIEW.nodes_description + ", "
	// + PortalDBEnum.TABLE_NAMES.nodes + "." + PortalDBEnum.NODES.machineId + "
	// as " + PortalDBEnum.DEVICES_NODES_VIEW.nodes_machineId + ", "
	// + PortalDBEnum.TABLE_NAMES.nodes + "." + PortalDBEnum.NODES.nativeAppId +
	// " as " + PortalDBEnum.DEVICES_NODES_VIEW.nodes_nativeAppId + ", "
	// + PortalDBEnum.TABLE_NAMES.nodes + "." + PortalDBEnum.NODES.action + " as
	// " + PortalDBEnum.DEVICES_NODES_VIEW.nodes_action + ", "
	// + PortalDBEnum.TABLE_NAMES.nodes + "." + PortalDBEnum.NODES.deviceRole +
	// " as " + PortalDBEnum.DEVICES_NODES_VIEW.nodes_deviceRole + ", "
	// + PortalDBEnum.TABLE_NAMES.nodes + "." + PortalDBEnum.NODES.deviceState +
	// " as " + PortalDBEnum.DEVICES_NODES_VIEW.nodes_deviceState + ", "
	// + PortalDBEnum.TABLE_NAMES.nodes + "." + PortalDBEnum.NODES.deviceId + "
	// as " + PortalDBEnum.DEVICES_NODES_VIEW.nodes_deviceId + ", "
	// + PortalDBEnum.TABLE_NAMES.nodes + "." + PortalDBEnum.NODES.createdDate +
	// " as " + PortalDBEnum.DEVICES_NODES_VIEW.nodes_createdDate+ ", "
	// + PortalDBEnum.TABLE_NAMES.nodes + "." + PortalDBEnum.NODES.modifiedDate
	// + " as " + PortalDBEnum.DEVICES_NODES_VIEW.nodes_modifiedDate
	//
	// + " FROM "
	// + PortalDBEnum.TABLE_NAMES.devices
	// + " JOIN "
	// + PortalDBEnum.TABLE_NAMES.nodes
	// + " ON "
	// + PortalDBEnum.TABLE_NAMES.devices + "." + PortalDBEnum.DEVICES.deviceId
	// + " = "
	// + PortalDBEnum.TABLE_NAMES.nodes + "." + PortalDBEnum.NODES.deviceId
	// + ")";
	//
	// PALogger.INFO(query+"");
	// }

	/**
	 * always put all dml values in hashtable in form of ArrayList<String>. The
	 * key of hashtable are version(1,2,3...) and value are the list of dml
	 * queries
	 * 
	 * @return Hashtable<Integer,ArrayList<String>>
	 */

	/**
	 * this method is deprecated, refer updateDatabase from PortalDatabaseEngine
	 * 
	 * @return
	 */
	@Deprecated
	private HashMap<Integer, List<String>> getUpgradeDMLQueries() {
		HashMap<Integer, List<String>> upgradeMap = new HashMap<>();
		/*** Version 1 ***/
		ArrayList<String> dml1 = new ArrayList<>();
		dml1.add("INSERT INTO t999 (version) VALUES (0)");
		upgradeMap.put(1, dml1);

		/*
		 * Version 3 increased version and inserted default entries in filters
		 * and sortorder tables.
		 */
		ArrayList<String> dml3 = new ArrayList<>();

		dml3.add("INSERT INTO filters(filterGroupName,filterName) VALUES('All prices','Free')");
		dml3.add("INSERT INTO filters(filterGroupName,filterName) VALUES('All prices','Paid')");
		dml3.add("INSERT INTO filters(filterGroupName,filterName) VALUES('All ratings','4 stars and above')");
		dml3.add("INSERT INTO filters(filterGroupName,filterName) VALUES('All ratings','3 stars and above')");

		dml3.add("INSERT INTO sortorders(sortGroupName,sortName) VALUES('Price','Low to High')");
		dml3.add("INSERT INTO sortorders(sortGroupName,sortName) VALUES('Price','High to Low')");
		dml3.add("INSERT INTO sortorders(sortGroupName,sortName) VALUES('Most popular','Most popular')");
		dml3.add("INSERT INTO sortorders(sortGroupName,sortName) VALUES('Latest first','Latest first')");
		upgradeMap.put(3, dml3);

		/*** Version 6 ***/
		/**
		 * inserted default entries in adZone table
		 */
		ArrayList<String> dml6 = new ArrayList<>();
		// dml6.addAll(insertDefaultEntriesInAdZone());
		upgradeMap.put(6, dml6);

		/*** Version 7 ***/
		// AKH_01_1
		ArrayList<String> dml7 = new ArrayList<>();
		dml7.add(
				"update platformportal.applicationversions av join platformportal.applicationconfigurations ac ON ac.appConfId = av.appConfigId set av.composerFilePath = ac.composerFilePath");
		upgradeMap.put(7, dml7);

		/*** Version 12 ***/
		/**
		 * inserted default entries in emailServer table
		 */
		ArrayList<String> dml12 = new ArrayList<>();
		// dml12.addAll(insertDefaultEntriesInEmailServers());
		upgradeMap.put(12, dml12);

		/*** Version 13 ***/ // AKH_04
		ArrayList<String> dml13 = new ArrayList<>();
		dml13.add(
				"update platformportal.applicationversions av join platformportal.application a ON a.appId = av.appId "
						+ "set av.redirectUrl = a.redirectUrl" + ", av.restRedirectUrl = a.restRedirectUrl"
						+ ", av.redirectSection = a.redirectSection" + ", av.redirectType = a.redirectType");
		upgradeMap.put(13, dml13);

		/*** Version 19 ***/
		ArrayList<String> dml19 = new ArrayList<>();
		dml19.add("INSERT INTO `platformportal`.`category` (`catId`,`name`,`type`,`catStatus`) SELECT * FROM (SELECT '"
				+ Common.getRandomId()
				+ "','Internet of Things',1,0) AS tmp WHERE NOT EXISTS (SELECT name FROM `platformportal`.`category` WHERE name = 'Internet of Things') LIMIT 1; ");
		upgradeMap.put(19, dml19);

		/*** Version 20 ***/
		ArrayList<String> dml20 = new ArrayList<>();
		dml20.add("SET FOREIGN_KEY_CHECKS = 0");
		dml20.add("Truncate table `platformportal`.`category`");
		dml20.add("SET FOREIGN_KEY_CHECKS = 1");
		dml20.add("INSERT INTO `platformportal`.`category` (`catId`,`name`,`type`,`catStatus`) SELECT * FROM (SELECT '"
				+ Common.getRandomId()
				+ "','Pixeom',1,0) AS tmp WHERE NOT EXISTS (SELECT name FROM `platformportal`.`category` WHERE name = 'Pixeom') LIMIT 1; ");
		dml20.add("INSERT INTO `platformportal`.`category` (`catId`,`name`,`type`,`catStatus`) SELECT * FROM (SELECT '"
				+ Common.getRandomId()
				+ "','Internet of Things',1,0) AS tmp WHERE NOT EXISTS (SELECT name FROM `platformportal`.`category` WHERE name = 'Internet of Things') LIMIT 1; ");
		dml20.add("INSERT INTO `platformportal`.`category` (`catId`,`name`,`type`,`catStatus`) SELECT * FROM (SELECT '"
				+ Common.getRandomId()
				+ "','Business',1,0) AS tmp WHERE NOT EXISTS (SELECT name FROM `platformportal`.`category` WHERE name = 'Business') LIMIT 1; ");
		dml20.add("INSERT INTO `platformportal`.`category` (`catId`,`name`,`type`,`catStatus`) SELECT * FROM (SELECT '"
				+ Common.getRandomId()
				+ "','Education',1,0) AS tmp WHERE NOT EXISTS (SELECT name FROM `platformportal`.`category` WHERE name = 'Education') LIMIT 1; ");
		dml20.add("INSERT INTO `platformportal`.`category` (`catId`,`name`,`type`,`catStatus`) SELECT * FROM (SELECT '"
				+ Common.getRandomId()
				+ "','Media',1,0) AS tmp WHERE NOT EXISTS (SELECT name FROM `platformportal`.`category` WHERE name = 'Media') LIMIT 1; ");
		upgradeMap.put(20, dml20);

		/*** Version 23 ***/
		ArrayList<String> dml23 = new ArrayList<>();
		dml23.add(addRootForAllUsers());// Add root entries for existing users
		dml23.add(addDeviceToRootInitially());
		upgradeMap.put(23, dml23);

		/*** Version 26 ***/
		ArrayList<String> dml25 = new ArrayList<>();
		// dml25.addAll(insertDefaultPlatForm());
		upgradeMap.put(25, dml25);

		ArrayList<String> dml28 = new ArrayList<>();
		dml28.add("INSERT INTO applicationplatform (appPlatformId, platformId, appId, repositoryName, modifiedDate) "
				+ "SELECT  appId," + "(SELECT platformId from platform WHERE platformName LIKE 'x86%'),"
				+ "appId, repositoryName ,now() from application");
		dml28.add(
				"Update applicationversions set appPlatformId = (SELECT appPlatformId FROM applicationplatform where applicationplatform.appId = applicationversions.appId)");
		dml28.add("Update devices set platformId = (SELECT platformId from platform WHERE platformName LIKE 'x86%')");
		upgradeMap.put(28, dml28);

		ArrayList<String> dml33 = new ArrayList<>();
		// dml33.addAll(insertDefaultAppType());
		dml33.add(updateAppTypeId());
		upgradeMap.put(33, dml33);

		ArrayList<String> dml39 = new ArrayList<>();
		dml39.add(
				"Update project set companyId = (SELECT companyId from company WHERE company.projectId = project.projectId)");
		upgradeMap.put(39, dml39);

		ArrayList<String> dml43 = new ArrayList<>();
		dml43.add(
				"Update " + PortalDBEnum.TABLE_NAMES.platform.name() + " set " + PortalDBEnum.PLATFORM.ordervalue.name()
						+ " = 1  WHERE " + PortalDBEnum.PLATFORM.platformActualName.name() + " = 'x86_64'");
		dml43.add(
				"Update " + PortalDBEnum.TABLE_NAMES.platform.name() + " set " + PortalDBEnum.PLATFORM.ordervalue.name()
						+ " = 2  WHERE " + PortalDBEnum.PLATFORM.platformActualName.name() + " = 'ARM64'");
		dml43.add(
				"Update " + PortalDBEnum.TABLE_NAMES.platform.name() + " set " + PortalDBEnum.PLATFORM.ordervalue.name()
						+ " = 3  WHERE " + PortalDBEnum.PLATFORM.platformActualName.name() + " = 'ARM32'");
		upgradeMap.put(43, dml43);

		ArrayList<String> dml45 = new ArrayList<>();
		dml45.add(updateCompanyStatus());
		upgradeMap.put(45, dml45);

		ArrayList<String> dml46 = new ArrayList<>();
		dml46.add("UPDATE " + PortalDBEnum.TABLE_NAMES.applicationType.name() + " SET "
				+ PortalDBEnum.APPLICATION_TYPE.typeDisplayName.name() + " = '"
				+ ApplicationDefaultType.dockercompose.getValue() + "' WHERE "
				+ PortalDBEnum.APPLICATION_TYPE.type.name() + " = '" + ApplicationDefaultType.dockercompose.name()
				+ "'");
		dml46.add("UPDATE " + PortalDBEnum.TABLE_NAMES.applicationType.name() + " SET "
				+ PortalDBEnum.APPLICATION_TYPE.typeDisplayName.name() + " = '"
				+ ApplicationDefaultType.kubernetes.getValue() + "' WHERE " + PortalDBEnum.APPLICATION_TYPE.type.name()
				+ " = '" + ApplicationDefaultType.kubernetes.name() + "'");
		upgradeMap.put(46, dml46);

		ArrayList<String> dml47 = new ArrayList<>();
		dml47.add("UPDATE " + PortalDBEnum.TABLE_NAMES.labels + " SET " + PortalDBEnum.LABELS.labelName.name() + " = '"
				+ Constant.ROOT_LABEL_NAME + "' WHERE " + PortalDBEnum.LABELS.parentLabelId.name() + " = '"
				+ Constant.ROOT_PARENT_LABEL_ID + "'");
		upgradeMap.put(47, dml47);

		ArrayList<String> dml55 = new ArrayList<>();

		dml55.add(updateSoftwarePtId());

		upgradeMap.put(55, dml55);

		// upgradeMap.put(64, insertDefaultSettings());

		return upgradeMap;
	}

	/**
	 * -- Table structure for table `adZone`
	 */
	private String createAdZoneTable() {
		StringBuilder qry = new StringBuilder();
		qry.append("CREATE TABLE IF NOT EXISTS ");
		qry.append(PortalDBEnum.TABLE_NAMES.adZone.name());
		qry.append(" (");
		qry.append(PortalDBEnum.AD_ZONE.adId.name());
		qry.append(" varchar(50) NOT NULL,");
		qry.append(PortalDBEnum.AD_ZONE.appId.name());
		qry.append(" varchar(50)  NOT NULL,");
		qry.append(PortalDBEnum.AD_ZONE.categoryId.name());
		qry.append(" varchar(50)  NOT NULL,");
		qry.append(PortalDBEnum.AD_ZONE.type.name());
		qry.append(" int NOT NULL,");
		qry.append(PortalDBEnum.AD_ZONE.zoneId.name());
		qry.append(" varchar(50)  NOT NULL,");
		qry.append(PortalDBEnum.AD_ZONE.sortOrder.name());
		qry.append(" int  NOT NULL,");
		qry.append(PortalDBEnum.AD_ZONE.modifiedDate.name());
		qry.append(" timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP ,");
		qry.append(" PRIMARY KEY( ");
		qry.append(PortalDBEnum.AD_ZONE.adId.name());
		qry.append("))");
		qry.append(" ENGINE=InnoDB DEFAULT CHARSET=utf8  ");
		return qry.toString();
	}

	/**
	 * method to generate query to insert banner zone in AdZone
	 * 
	 * @param adId
	 *            primary key
	 * @param deviceId
	 * @param appId
	 * @param category
	 * @param type
	 * @param zoneId
	 * @param sortOrder
	 * @return
	 */
	private String insertIntoAdZone() {
		StringBuilder qry = new StringBuilder("INSERT INTO ");
		qry.append(PortalDBEnum.TABLE_NAMES.adZone.name());
		qry.append("(");
		qry.append(PortalDBEnum.AD_ZONE.adId.name());
		qry.append(", ");
		qry.append(PortalDBEnum.AD_ZONE.appId.name());
		qry.append(", ");
		qry.append(PortalDBEnum.AD_ZONE.categoryId.name());
		qry.append(" ,");
		qry.append(PortalDBEnum.AD_ZONE.type.name());
		qry.append(", ");
		qry.append(PortalDBEnum.AD_ZONE.zoneId.name());
		qry.append(", ");
		qry.append(PortalDBEnum.AD_ZONE.sortOrder.name());
		qry.append(", ");
		qry.append(PortalDBEnum.AD_ZONE.modifiedDate.name());
		qry.append(") VALUES (");
		qry.append("?");
		// qry.append(adId);
		qry.append(", ");
		qry.append("?");
		// qry.append(appId);
		qry.append(", ");
		qry.append("?");
		// qry.append(categoryId);
		qry.append(",");
		qry.append("?");
		// qry.append( type.ordinal());
		qry.append(" ,");
		qry.append("?");
		// qry.append( zoneId);
		qry.append(",");
		qry.append("?");
		// qry.append( sortOrder);
		qry.append(",");
		qry.append("NOW()");
		qry.append(")");
		return qry.toString();
	}

	/**
	 * method to generate query to insert default entries
	 * 
	 * @return
	 */
	private List<QueryVO> insertDefaultEntriesInAdZone() {
		List<QueryVO> insertlist = new ArrayList<>();

		String sql = insertIntoAdZone();
		insertlist.add(new SqlQueryBuilder().appendQuery(sql).addParameter(Common.getRandomId()).addParameter("")
				.addParameter("0e7f63de11c44bda9b4f91782110b852").addParameter(AD_TYPE.defaultBanner.ordinal()).addParameter("16")
				.addParameter(1).build());

		insertlist.add(new SqlQueryBuilder().appendQuery(sql).addParameter(Common.getRandomId()).addParameter("")
				.addParameter("ddbeccf05a934d4ba0a192f39ab26aee").addParameter(AD_TYPE.defaultBanner.ordinal()).addParameter("17")
				.addParameter(2).build());

		insertlist.add(new SqlQueryBuilder().appendQuery(sql).addParameter(Common.getRandomId()).addParameter("")
				.addParameter("a2d13fa0b2b14dbfa1cd5f41e0f50427").addParameter(AD_TYPE.defaultBanner.ordinal()).addParameter("18")
				.addParameter(3).build());
		return insertlist;

	}

	/**
	 * -- Table structure for table `discoveryjardetails`
	 */
	private String createEmailServersTable() {
		StringBuilder qry = new StringBuilder();
		qry.append("CREATE TABLE IF NOT EXISTS ");
		qry.append(PortalDBEnum.TABLE_NAMES.emailServers.name());
		qry.append(" (");
		qry.append(PortalDBEnum.EMAIL_SERVERS.serverId.name());
		qry.append(" varchar(50) NOT NULL,");
		qry.append(PortalDBEnum.EMAIL_SERVERS.serverAddress.name());
		qry.append(" varchar(50)  NOT NULL,");
		qry.append(PortalDBEnum.EMAIL_SERVERS.serverName.name());
		qry.append(" varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,");
		qry.append(PortalDBEnum.EMAIL_SERVERS.status.name());
		qry.append(" int NOT NULL,");
		qry.append(PortalDBEnum.EMAIL_SERVERS.username.name());
		qry.append(" text  NOT NULL,");
		qry.append(PortalDBEnum.EMAIL_SERVERS.password.name());
		qry.append(" text NOT NULL,");
		qry.append(PortalDBEnum.EMAIL_SERVERS.port.name());
		qry.append(" int  NOT NULL,");
		qry.append(PortalDBEnum.EMAIL_SERVERS.priority.name());
		qry.append("  tinyint(4) ,");
		qry.append(PortalDBEnum.EMAIL_SERVERS.istls.name());
		qry.append(" tinyint,");
		qry.append(PortalDBEnum.EMAIL_SERVERS.modifiedDate.name());
		qry.append(" timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP ,");
		qry.append(" PRIMARY KEY( ");
		qry.append(PortalDBEnum.EMAIL_SERVERS.serverId.name());
		qry.append("))");
		qry.append(" ENGINE=InnoDB DEFAULT CHARSET=utf8  ");
		return qry.toString();
	}

	/**
	 * -- Table structure for table `Rule`
	 */
	private String createRuleTable() {
		StringBuilder qry = new StringBuilder();
		qry.append("CREATE TABLE IF NOT EXISTS ");
		qry.append(PortalDBEnum.TABLE_NAMES.rule.name());
		qry.append(" (");
		qry.append(PortalDBEnum.RULE.ruleId.name());
		qry.append(" varchar(50) NOT NULL,");
		qry.append(PortalDBEnum.RULE.ruleValue.name());
		qry.append(" TEXT  NOT NULL,");
		qry.append(PortalDBEnum.RULE.ruleType.name());
		qry.append(" int  NOT NULL,");
		qry.append(PortalDBEnum.RULE.serverType.name());
		qry.append(" int NOT NULL,");
		qry.append(PortalDBEnum.RULE.isKub.name());
		qry.append(" tinyint(1) DEFAULT 0,");
		qry.append(" PRIMARY KEY( ");
		qry.append(PortalDBEnum.RULE.ruleId.name());
		qry.append("),");
		qry.append(" UNIQUE (");
		qry.append(PortalDBEnum.RULE.ruleType.name());
		qry.append(",");
		qry.append(PortalDBEnum.RULE.serverType.name());
		qry.append(" ))");
		qry.append(" ENGINE=InnoDB DEFAULT CHARSET=utf8  ");
		return qry.toString();
	}

	private String createRuleTriggerLoggerTable() {
		StringBuilder qry = new StringBuilder("CREATE TABLE IF NOT EXISTS ");
		qry.append(PortalDBEnum.TABLE_NAMES.ruleTriggerLog.name());
		qry.append(" (");
		qry.append(PortalDBEnum.RULE_TRIGGER_LOG.id.name());
		qry.append(" varchar(50) NOT NULL,");
		qry.append(PortalDBEnum.RULE_TRIGGER_LOG.ruleId.name());
		qry.append(" varchar(50) NOT NULL,");
		qry.append(PortalDBEnum.RULE_TRIGGER_LOG.startTime.name());
		qry.append(" timestamp  NOT NULL DEFAULT CURRENT_TIMESTAMP,");
		qry.append(PortalDBEnum.RULE_TRIGGER_LOG.endTime.name());
		qry.append(" timestamp  NOT NULL DEFAULT CURRENT_TIMESTAMP,");
		qry.append(PortalDBEnum.RULE_TRIGGER_LOG.stage.name());
		qry.append(" int DEFAULT NULL,");
		qry.append(PortalDBEnum.RULE_TRIGGER_LOG.status.name());
		qry.append(" int,");
		qry.append(PortalDBEnum.RULE_TRIGGER_LOG.info.name());
		qry.append(" TEXT DEFAULT NULL,");
		qry.append(" UNIQUE (");
		qry.append(PortalDBEnum.RULE_TRIGGER_LOG.id.name());
		qry.append(" ))");
		return qry.toString();
	}

	/**
	 * method to generate query to insert email server in emailServers
	 * 
	 * @param serverId
	 * @param serverAddress
	 * @param serverName
	 * @param status
	 * @param username
	 * @param password
	 * @param port
	 * @param priority
	 * @return
	 */
	private String insertIntoEmailServers(String serverId, String serverAddress, String serverName, int status,
			String username, String password, int port, String priority) {
		StringBuilder qry = new StringBuilder("INSERT INTO ");
		qry.append(PortalDBEnum.TABLE_NAMES.emailServers.name());
		qry.append("(");
		qry.append(PortalDBEnum.EMAIL_SERVERS.serverId.name());
		qry.append(", ");
		qry.append(PortalDBEnum.EMAIL_SERVERS.serverAddress.name());
		qry.append(", ");
		qry.append(PortalDBEnum.EMAIL_SERVERS.serverName.name());
		qry.append(" ,");
		qry.append(PortalDBEnum.EMAIL_SERVERS.status.name());
		qry.append(", ");
		qry.append(PortalDBEnum.EMAIL_SERVERS.username.name());
		qry.append(", ");
		qry.append(PortalDBEnum.EMAIL_SERVERS.password.name());
		qry.append(", ");
		qry.append(PortalDBEnum.EMAIL_SERVERS.port.name());
		qry.append(", ");
		qry.append(PortalDBEnum.EMAIL_SERVERS.priority.name());
		qry.append(", ");
		qry.append(PortalDBEnum.EMAIL_SERVERS.modifiedDate.name());
		qry.append(") VALUES (");
		qry.append("'");
		qry.append(serverId);
		qry.append("'");
		qry.append(", ");
		qry.append("'");
		qry.append(serverAddress);
		qry.append("'");
		qry.append(", ");
		qry.append("'");
		qry.append(serverName);
		qry.append("'");
		qry.append(",");
		qry.append(status);
		qry.append(" ,");
		qry.append("'");
		qry.append(username);
		qry.append("'");
		qry.append(" ,");
		qry.append("'");
		qry.append(password);
		qry.append("'");
		qry.append(",");
		qry.append(port);
		qry.append(" ,");
		qry.append("'");
		qry.append(priority);
		qry.append("'");
		qry.append(",");
		qry.append("NOW()");
		qry.append(")");
		return qry.toString();
	}

	/**
	 * insert default entries in email server table.
	 */
	// private ArrayList<String> insertDefaultEntriesInEmailServers()
	// {
	//
	// return new ArrayList<>();
	//
	// }

	/**
	 * -- Table structure for table `discoveryjardetails`
	 */
	private String createDiscoveryJarDetailsTable() {
		StringBuilder qry = new StringBuilder();
		qry.append("CREATE TABLE IF NOT EXISTS ");
		qry.append(PortalDBEnum.TABLE_NAMES.discoveryjardetails.name());
		qry.append(" (");
		qry.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sMACAddress);
		qry.append(" varchar(50) NOT NULL,");
		qry.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sHostName);
		qry.append(" varchar(500) NOT NULL,");
		qry.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sRingID);
		qry.append(" varchar(50) DEFAULT NULL,");
		qry.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sMasterID);
		qry.append(" varchar(50) DEFAULT NULL,");
		qry.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.nNodeStatus);
		qry.append(" tinyint(4) DEFAULT 0,");
		qry.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sIPAddress);
		qry.append(" varchar(500) NOT NULL,");
		qry.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sLocalIPAddress);
		qry.append(" varchar(500) NOT NULL,");

		qry.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sChatInputChannel);
		qry.append(" varchar(50) NOT NULL,");

		qry.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sChatOutputChannel);
		qry.append(" varchar(50) NOT NULL,");

		qry.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sChatSubscriptionChannel);
		qry.append(" varchar(50) NOT NULL,");

		qry.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sNodeCommunicationPort);
		qry.append(" varchar(50) NOT NULL,");

		qry.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sOpenStackPort);
		qry.append(" varchar(50) NOT NULL,");
		qry.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sKeyStonePort);
		qry.append(" varchar(50) DEFAULT NULL,");
		qry.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sTomcatPort);
		qry.append(" varchar(50) NOT NULL,");
		qry.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sPort1);
		qry.append(" TEXT DEFAULT NULL,");

		qry.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sPort2);
		qry.append(" TEXT DEFAULT NULL,");
		qry.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sPort3);
		qry.append(" TEXT DEFAULT NULL,");
		qry.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sPort4);
		qry.append(" TEXT DEFAULT NULL,");
		qry.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sPort5);
		qry.append(" TEXT DEFAULT NULL,");
		qry.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sRURLTomcatPort);
		qry.append(" varchar(50) NOT NULL,");
		qry.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sRURLKeystonePort);
		qry.append(" varchar(50) DEFAULT NULL,");
		qry.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sRAddress);
		qry.append(" varchar(50) NOT NULL,");

		qry.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.nStatus);
		qry.append(" tinyint(4) NOT NULL,");
		qry.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.nIsDeleted);
		qry.append(" tinyint(1) DEFAULT 0,");
		qry.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sConnectURL);
		qry.append(" varchar(500) DEFAULT NULL,");

		qry.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.nAdult);
		qry.append(" tinyint(4) DEFAULT 0,");
		qry.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.dHBRdate);
		qry.append(" timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,");

		qry.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sNetworkType);
		qry.append(" varchar(500) DEFAULT NULL,");
		qry.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sRelayServerID);
		qry.append(" varchar(500) DEFAULT NULL,");
		qry.append(" PRIMARY KEY( ");
		qry.append(PortalDBEnum.DISCOVERY_JAR_DETAILS.sMACAddress.name());
		qry.append(")) ENGINE=InnoDB DEFAULT CHARSET=utf8 ");
		return qry.toString();
	}

	/**
	 * -- Table structure for table `assignedrelayports`
	 */
	private String createAssignedRelayPortsTable() {
		StringBuilder qry = new StringBuilder();
		qry.append("CREATE TABLE IF NOT EXISTS ");
		qry.append(PortalDBEnum.TABLE_NAMES.assignedrelayports.name());
		qry.append(" (");
		qry.append(PortalDBEnum.ASSIGNED_RELAY_PORTS.sDeviceID);
		qry.append(" varchar(50) NOT NULL,");
		qry.append(PortalDBEnum.ASSIGNED_RELAY_PORTS.sRelayServerID);
		qry.append(" varchar(500) NOT NULL,");
		qry.append(PortalDBEnum.ASSIGNED_RELAY_PORTS.nPortSegmentStart);
		qry.append(" int(11) NOT NULL,");
		qry.append(PortalDBEnum.ASSIGNED_RELAY_PORTS.nStatus);
		qry.append(" tinyint(4) NOT NULL,");
		qry.append(PortalDBEnum.ASSIGNED_RELAY_PORTS.dModified);
		qry.append(" timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,");
		qry.append(" PRIMARY KEY( ");
		qry.append(PortalDBEnum.ASSIGNED_RELAY_PORTS.sDeviceID.name());
		qry.append(")) ENGINE=InnoDB DEFAULT CHARSET=utf8 ");
		return qry.toString();
	}

	/**
	 * -- Table structure for table `discoverydetails`
	 */
	private String createDiscoveryDetailsTable() {
		StringBuilder qry = new StringBuilder();
		qry.append("CREATE TABLE IF NOT EXISTS ");
		qry.append(PortalDBEnum.TABLE_NAMES.discoverydetails.name());
		qry.append(" (");
		qry.append(PortalDBEnum.DISCOVERY_DETAILS.sDeviceID);
		qry.append(" varchar(50) NOT NULL,");
		qry.append(PortalDBEnum.DISCOVERY_DETAILS.sRingID);
		qry.append(" varchar(50) DEFAULT NULL,");
		qry.append(PortalDBEnum.DISCOVERY_DETAILS.sMasterID);
		qry.append(" varchar(50) DEFAULT NULL,");
		qry.append(PortalDBEnum.DISCOVERY_DETAILS.nNodeStatus);
		qry.append(" tinyint(4) DEFAULT 0,");
		qry.append(PortalDBEnum.DISCOVERY_DETAILS.sIPAddress);
		qry.append(" varchar(500) NOT NULL,");
		qry.append(PortalDBEnum.DISCOVERY_DETAILS.sLocalIPAddress);
		qry.append(" varchar(500) NOT NULL,");
		qry.append(PortalDBEnum.DISCOVERY_DETAILS.sChatInputChannel);
		qry.append(" varchar(50) NOT NULL,");
		qry.append(PortalDBEnum.DISCOVERY_DETAILS.sChatOutputChannel);
		qry.append(" varchar(50) NOT NULL,");
		qry.append(PortalDBEnum.DISCOVERY_DETAILS.sChatSubscriptionChannel);
		qry.append(" varchar(50) NOT NULL,");
		qry.append(PortalDBEnum.DISCOVERY_DETAILS.sNodeCommunicationPort);
		qry.append(" varchar(50) NOT NULL,");
		qry.append(PortalDBEnum.DISCOVERY_DETAILS.sOpenStackPort);
		qry.append(" varchar(50) NOT NULL,");
		qry.append(PortalDBEnum.DISCOVERY_DETAILS.sKeyStonePort);
		qry.append(" varchar(50) DEFAULT NULL,");
		qry.append(PortalDBEnum.DISCOVERY_DETAILS.sTomcatPort);
		qry.append(" varchar(50) NOT NULL,");
		qry.append(PortalDBEnum.DISCOVERY_DETAILS.sPort1);
		qry.append(" TEXT NOT NULL,");
		qry.append(PortalDBEnum.DISCOVERY_DETAILS.sPort2);
		qry.append(" TEXT DEFAULT NULL,");
		qry.append(PortalDBEnum.DISCOVERY_DETAILS.sPort3);
		qry.append(" TEXT DEFAULT NULL,");
		qry.append(PortalDBEnum.DISCOVERY_DETAILS.sPort4);
		qry.append(" TEXT DEFAULT NULL,");
		qry.append(PortalDBEnum.DISCOVERY_DETAILS.sPort5);
		qry.append(" TEXT DEFAULT NULL,");
		qry.append(PortalDBEnum.DISCOVERY_DETAILS.sRURLTomcatPort);
		qry.append(" varchar(50) NOT NULL,");
		qry.append(PortalDBEnum.DISCOVERY_DETAILS.sRURLKeystonePort);
		qry.append(" varchar(50) NOT NULL,");
		qry.append(PortalDBEnum.DISCOVERY_DETAILS.sRAddress);
		qry.append(" varchar(500) NOT NULL,");
		qry.append(PortalDBEnum.DISCOVERY_DETAILS.nStatus);
		qry.append(" tinyint(4) DEFAULT 0,");
		qry.append(PortalDBEnum.DISCOVERY_DETAILS.sConnectURL);
		qry.append(" varchar(500) DEFAULT NULL,");
		qry.append(PortalDBEnum.DISCOVERY_DETAILS.nAdult);
		qry.append(" tinyint(4) DEFAULT 0,");
		qry.append(PortalDBEnum.DISCOVERY_DETAILS.dHBRdate);
		qry.append(" timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,");
		qry.append(PortalDBEnum.DISCOVERY_DETAILS.sRelayServerID);
		qry.append(" varchar(500) NOT NULL,");
		qry.append(PortalDBEnum.DISCOVERY_DETAILS.sNetworkType);
		qry.append(" varchar(500) NOT NULL,");
		qry.append(" PRIMARY KEY( ");
		qry.append(PortalDBEnum.DISCOVERY_DETAILS.sDeviceID.name());
		qry.append(")) ENGINE=InnoDB DEFAULT CHARSET=utf8 ");
		return qry.toString();
	}

	/**
	 * -- Table structure for table `lockrelayports`
	 */
	private String createLockRelayPortsTable() {
		StringBuilder qry = new StringBuilder();
		qry.append("CREATE TABLE IF NOT EXISTS ");
		qry.append(PortalDBEnum.TABLE_NAMES.lockrelayports.name());
		qry.append(" (");

		qry.append(PortalDBEnum.LOCK_RELAY_PORTS.sDeviceID);
		qry.append(" varchar(50) NOT NULL,");
		qry.append(PortalDBEnum.LOCK_RELAY_PORTS.sRelayServerID);
		qry.append(" varchar(500) NOT NULL,");
		qry.append(PortalDBEnum.LOCK_RELAY_PORTS.nPortSegmentStart);
		qry.append(" varchar(500) NOT NULL,");
		qry.append(PortalDBEnum.LOCK_RELAY_PORTS.dModified);
		qry.append(" timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,");
		qry.append(" PRIMARY KEY( ");
		qry.append(PortalDBEnum.LOCK_RELAY_PORTS.sDeviceID.name());
		qry.append(")) ENGINE=InnoDB DEFAULT CHARSET=utf8 ");
		return qry.toString();
	}

	/**
	 * -- Table structure for table `relayservers`
	 */
	private String createRelayServersTable() {
		StringBuilder qry = new StringBuilder();
		qry.append("CREATE TABLE IF NOT EXISTS ");
		qry.append(PortalDBEnum.TABLE_NAMES.relayservers.name());
		qry.append(" (");

		qry.append(PortalDBEnum.RELAY_SERVERS.sRelayServerID);
		qry.append(" varchar(500) NOT NULL,");
		qry.append(PortalDBEnum.RELAY_SERVERS.sRelayServerAddress);
		qry.append(" varchar(500) NOT NULL,");
		qry.append(PortalDBEnum.RELAY_SERVERS.sRelayName);
		qry.append(" varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,");
		qry.append(PortalDBEnum.RELAY_SERVERS.nPortRangeStart);
		qry.append(" int(11) NOT NULL,");
		qry.append(PortalDBEnum.RELAY_SERVERS.nPortRangeEnd);
		qry.append(" int(11) NOT NULL,");
		qry.append(PortalDBEnum.RELAY_SERVERS.sDeviceLimit);
		qry.append(" varchar(500) NOT NULL,");
		qry.append(PortalDBEnum.RELAY_SERVERS.nStatus);
		qry.append(" tinyint(4) DEFAULT 0,");
		qry.append(PortalDBEnum.RELAY_SERVERS.sRUserName);
		qry.append(" text NOT NULL,");
		qry.append(PortalDBEnum.RELAY_SERVERS.sRPassword);
		qry.append(" text NOT NULL,");
		qry.append(PortalDBEnum.RELAY_SERVERS.sHostKey);
		qry.append(" text NOT NULL,");
		qry.append(PortalDBEnum.RELAY_SERVERS.nRPort);
		qry.append(" int(5) NOT NULL,");
		qry.append(PortalDBEnum.RELAY_SERVERS.sPriority);
		qry.append(" tinyint(4) ,");
		qry.append(PortalDBEnum.RELAY_SERVERS.dModified);
		qry.append(" timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP");
		qry.append(") ENGINE=InnoDB DEFAULT CHARSET=utf8 ");
		return qry.toString();
	}

	/**
	 * -- Table structure for table `validationInfo`
	 */
	private String createValidationInfoTable() {
		StringBuilder qry = new StringBuilder();
		qry.append("CREATE TABLE IF NOT EXISTS ");
		qry.append(PortalDBEnum.TABLE_NAMES.validationInfo.name());
		qry.append(" (");

		qry.append(PortalDBEnum.VALIDATION_INFO.sMACAddress);
		qry.append(" varchar(50) NOT NULL,");
		qry.append(PortalDBEnum.VALIDATION_INFO.sGUID);
		qry.append(" varchar(500) NOT NULL,");
		qry.append(PortalDBEnum.VALIDATION_INFO.nStatus);
		qry.append(" int(4) NOT NULL,");
		qry.append(PortalDBEnum.VALIDATION_INFO.nTimestamp);
		qry.append(" BIGINT NOT NULL DEFAULT 0,");
		qry.append(PortalDBEnum.VALIDATION_INFO.sInternetAddress);
		qry.append(" varchar(500) NOT NULL,");
		qry.append(PortalDBEnum.VALIDATION_INFO.dCreated);
		qry.append(" timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,");
		qry.append(PortalDBEnum.VALIDATION_INFO.sCode);
		qry.append(" int(2) NOT NULL,");
		qry.append(PortalDBEnum.VALIDATION_INFO.nPreviousTS);
		qry.append(" BIGINT NOT NULL DEFAULT 0,");

		qry.append(" PRIMARY KEY( ");
		qry.append(PortalDBEnum.VALIDATION_INFO.sMACAddress.name());
		qry.append(")) ENGINE=InnoDB DEFAULT CHARSET=utf8 ");
		return qry.toString();
	}

	/**
	 * -- Table structure for table `boxStatics`
	 */
	private String createBoxStaticsTable() {
		StringBuilder qry = new StringBuilder();
		qry.append("CREATE TABLE IF NOT EXISTS ");
		qry.append(PortalDBEnum.TABLE_NAMES.boxStatics.name());
		qry.append(" (");
		qry.append(PortalDBEnum.BOX_STATICS.deviceId);
		qry.append(" varchar(50) NOT NULL,");
		qry.append(PortalDBEnum.BOX_STATICS.statics);
		qry.append(" longtext NOT NULL, ");
		qry.append(PortalDBEnum.BOX_STATICS.modifiedDate);
		qry.append(" timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, ");
		qry.append(" PRIMARY KEY( ");
		qry.append(PortalDBEnum.BOX_STATICS.deviceId.name());
		qry.append(")) ENGINE=InnoDB DEFAULT CHARSET=utf8 ");
		return qry.toString();
	}

	/**
	 * -- Table structure for table `supportrelayservers` --
	 */
	private String createSupportRelayServersTable() {
		StringBuilder qry = new StringBuilder();
		qry.append("CREATE TABLE IF NOT EXISTS ");
		qry.append(PortalDBEnum.TABLE_NAMES.supportrelayservers.name());
		qry.append(" (");

		qry.append(PortalDBEnum.SUPPORT_RELAY_SERVERS.sRelayServerID);
		qry.append(" varchar(500) NOT NULL,");
		qry.append(PortalDBEnum.SUPPORT_RELAY_SERVERS.sRelayServerAddress);
		qry.append(" varchar(500) NOT NULL,");
		qry.append(PortalDBEnum.SUPPORT_RELAY_SERVERS.sRelayName);
		qry.append(" varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,");
		qry.append(PortalDBEnum.SUPPORT_RELAY_SERVERS.nPortRangeStart);
		qry.append(" int(11) NOT NULL,");
		qry.append(PortalDBEnum.SUPPORT_RELAY_SERVERS.nPortRangeEnd);
		qry.append(" int(11) NOT NULL,");
		qry.append(PortalDBEnum.SUPPORT_RELAY_SERVERS.sDeviceLimit);
		qry.append(" varchar(500) NOT NULL,");
		qry.append(PortalDBEnum.SUPPORT_RELAY_SERVERS.nStatus);
		qry.append(" tinyint(4) DEFAULT 0,");
		qry.append(PortalDBEnum.SUPPORT_RELAY_SERVERS.sRUserName);
		qry.append(" text NOT NULL,");
		qry.append(PortalDBEnum.SUPPORT_RELAY_SERVERS.sRPassword);
		qry.append(" text NOT NULL,");
		qry.append(PortalDBEnum.SUPPORT_RELAY_SERVERS.sHostKey);
		qry.append(" text NOT NULL,");
		qry.append(PortalDBEnum.SUPPORT_RELAY_SERVERS.nRPort);
		qry.append(" int(5) NOT NULL,");
		qry.append(PortalDBEnum.SUPPORT_RELAY_SERVERS.sPriority);
		qry.append(" tinyint(4) ,");
		qry.append(PortalDBEnum.SUPPORT_RELAY_SERVERS.dModified);
		qry.append(" timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP");

		qry.append(") ENGINE=InnoDB DEFAULT CHARSET=utf8 ");
		return qry.toString();

	}

	/**
	 * -- Table structure for table `supportlockrelayports`
	 */
	private String createSupportLockRelayPortsTable() {
		StringBuilder qry = new StringBuilder();
		qry.append("CREATE TABLE IF NOT EXISTS ");
		qry.append(PortalDBEnum.TABLE_NAMES.supportlockrelayports.name());
		qry.append(" (");
		qry.append(PortalDBEnum.SUPPORT_LOCK_RELAY_PORTS.sDeviceID);
		qry.append(" varchar(50) NOT NULL,");
		qry.append(PortalDBEnum.SUPPORT_LOCK_RELAY_PORTS.sRelayServerID);
		qry.append(" varchar(500) NOT NULL,");
		qry.append(PortalDBEnum.SUPPORT_LOCK_RELAY_PORTS.nPortSegmentStart);
		qry.append(" int(11) NOT NULL,");
		qry.append(PortalDBEnum.SUPPORT_LOCK_RELAY_PORTS.dModified);
		qry.append(" timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,");
		qry.append(" PRIMARY KEY( ");
		qry.append(PortalDBEnum.SUPPORT_LOCK_RELAY_PORTS.sDeviceID.name());
		qry.append(")) ENGINE=InnoDB DEFAULT CHARSET=utf8 ");
		return qry.toString();
	}

	/**
	 * -- Table structure for table `supportassignedrelayports`
	 */
	private String createSupportAssignedRelayPortsTable() {
		StringBuilder qry = new StringBuilder();
		qry.append("CREATE TABLE IF NOT EXISTS ");
		qry.append(PortalDBEnum.TABLE_NAMES.supportassignedrelayports.name());
		qry.append(" (");
		qry.append(PortalDBEnum.SUPPORT_LOCK_RELAY_PORTS.sDeviceID);
		qry.append(" varchar(50) NOT NULL,");
		qry.append(PortalDBEnum.SUPPORT_LOCK_RELAY_PORTS.sRelayServerID);
		qry.append(" varchar(500) NOT NULL,");
		qry.append(PortalDBEnum.SUPPORT_LOCK_RELAY_PORTS.nPortSegmentStart);
		qry.append(" int(11) NOT NULL,");
		qry.append(PortalDBEnum.RELAY_SERVERS.nStatus);
		qry.append(" tinyint(4) DEFAULT 0,");
		qry.append(PortalDBEnum.SUPPORT_LOCK_RELAY_PORTS.dModified);
		qry.append(" timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,");
		qry.append(" PRIMARY KEY( ");
		qry.append(PortalDBEnum.SUPPORT_LOCK_RELAY_PORTS.sDeviceID.name());
		qry.append(")) ENGINE=InnoDB DEFAULT CHARSET=utf8 ");
		return qry.toString();
	}

	/*
	 * -- Table structure for table `labels`
	 */
	private ArrayList<String> createLabelTable() {
		ArrayList<String> ddlQueries = new ArrayList<>();
		ddlQueries.add("CREATE TABLE IF NOT EXISTS " + PortalDBEnum.TABLE_NAMES.labels
				+ " (`labelId` varchar(32) NOT NULL,`labelName` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,`parentLabelId` varchar(32) NOT NULL, `userId` varchar(32) NOT NULL, PRIMARY KEY (`labelId`, `userId`), UNIQUE KEY (`labelName`, `parentLabelId`,`userId` )) ENGINE=InnoDB DEFAULT CHARSET=utf8");
		return ddlQueries;
	}

	/**
	 * -- Table structure for table `devicelabelmap`
	 */
	private String createDeviceLabelTable() {
		StringBuilder qry = new StringBuilder();
		qry.append("CREATE TABLE IF NOT EXISTS ");
		qry.append(PortalDBEnum.TABLE_NAMES.devicelabelmap.name());
		qry.append(" ( ");
		qry.append(PortalDBEnum.DEVICE_LABEL_MAP.labelId.name());
		qry.append(" varchar(32) NOT NULL,");
		qry.append(PortalDBEnum.DEVICE_LABEL_MAP.deviceId.name());
		qry.append(" varchar(32) NOT NULL,");

		qry.append(" CONSTRAINT `deviceLbl_1` FOREIGN KEY (");
		qry.append(PortalDBEnum.DEVICE_LABEL_MAP.deviceId.name());
		qry.append(")");
		qry.append(" REFERENCES ");
		qry.append(PortalDBEnum.TABLE_NAMES.devices.name());
		qry.append(" (");
		qry.append(PortalDBEnum.DEVICES.deviceId.name());
		qry.append(") ON DELETE CASCADE, ");
		qry.append(" CONSTRAINT `deviceLbl_2` FOREIGN KEY (");
		qry.append(PortalDBEnum.DEVICE_LABEL_MAP.labelId.name());
		qry.append(")");
		qry.append(" REFERENCES ");
		qry.append(PortalDBEnum.TABLE_NAMES.labels.name());
		qry.append(" (");
		qry.append(PortalDBEnum.LABELS.labelId.name());
		qry.append(") ON DELETE CASCADE ");

		qry.append(") ENGINE=InnoDB DEFAULT CHARSET=utf8");
		return qry.toString();
	}

	/**
	 * -- Table structure for table `installJobs`
	 */
	private String createInstallJobTable() {
		return "CREATE TABLE IF NOT EXISTS " + PortalDBEnum.TABLE_NAMES.installJobs + " ( "
				+ PortalDBEnum.INSTALL_JOBS.uId.name() + " varchar(40) NOT NULL, "
				+ PortalDBEnum.INSTALL_JOBS.objectId.name() + " varchar(40) NOT NULL, "
				+ PortalDBEnum.INSTALL_JOBS.type.name() + " TINYINT, " + PortalDBEnum.INSTALL_JOBS.status.name()
				+ " TINYINT, " + PortalDBEnum.INSTALL_JOBS.userId.name() + " varchar(40) NOT NULL, "
				+ PortalDBEnum.INSTALL_JOBS.appId.name() + " varchar(40) NOT NULL, "
				+ PortalDBEnum.INSTALL_JOBS.operation.name() + " varchar(50) NOT NULL, "
				+ PortalDBEnum.INSTALL_JOBS.appVersion.name() + " varchar(40) DEFAULT NULL, "
				+ PortalDBEnum.INSTALL_JOBS.timeStamp.name() + " BIGINT DEFAULT 0, "
				+ PortalDBEnum.INSTALL_JOBS.message.name() + " TEXT COLLATE utf8mb4_unicode_ci, "
				+ PortalDBEnum.INSTALL_JOBS.detail.name() + " TEXT , " + PortalDBEnum.INSTALL_JOBS.lastModified.name()
				+ " timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, " + " PRIMARY KEY ("
				+ PortalDBEnum.INSTALL_JOBS.uId.name() + ")) ENGINE=InnoDB DEFAULT CHARSET=utf8";

	}

	/**
	 * --create query to add default root label entry
	 */
	private String addRootForAllUsers() {
		StringBuilder sb = new StringBuilder();
		sb.append("INSERT INTO ");
		sb.append(PortalDBEnum.TABLE_NAMES.labels);
		sb.append(" ( ");
		sb.append(PortalDBEnum.LABELS.labelId.name());
		sb.append(", ");
		sb.append(PortalDBEnum.LABELS.labelName.name());
		sb.append(", ");
		sb.append(PortalDBEnum.LABELS.parentLabelId.name());
		sb.append(", ");
		sb.append(PortalDBEnum.LABELS.userId.name());
		sb.append(" ) ");
		sb.append("(SELECT DISTINCT '0', 'All Appliances', '-1'");
		sb.append(", ");
		sb.append(PortalDBEnum.DEVICES.userId.name());
		sb.append(" FROM  ");
		sb.append(PortalDBEnum.TABLE_NAMES.devices);
		sb.append(" ) ");
		return sb.toString();
	}

	/**
	 * -- create query to add all existing devices to default root label
	 * 
	 * @return
	 */
	private String addDeviceToRootInitially() {

		return "Insert INTO " + PortalDBEnum.TABLE_NAMES.devicelabelmap.name() + "(" + " SELECT " + " '0' " + ", "
				+ PortalDBEnum.DEVICE_LABEL_MAP.deviceId.name() + " FROM " + PortalDBEnum.TABLE_NAMES.devices
				+ " WHERE " + PortalDBEnum.DEVICE_LABEL_MAP.deviceId.name() + " NOT IN " + "(" + " SELECT "
				+ PortalDBEnum.DEVICE_LABEL_MAP.deviceId.name() + " FROM "
				+ PortalDBEnum.TABLE_NAMES.devicelabelmap.name() + "))";

	}

	/**
	 * -- Table structure for table `platform`
	 */
	private String createPlatFormTable() {
		StringBuilder qry = new StringBuilder();
		qry.append("CREATE TABLE IF NOT EXISTS ");
		qry.append(PortalDBEnum.TABLE_NAMES.platform.name());
		qry.append(" (");
		qry.append(PortalDBEnum.PLATFORM.platformId);
		qry.append(" varchar(32) NOT NULL,");
		qry.append(PortalDBEnum.PLATFORM.platformName);
		qry.append(" varchar(100) NOT NULL,");
		qry.append(PortalDBEnum.PLATFORM.platformActualName);
		qry.append(" varchar(100) NOT NULL,");
		qry.append(PortalDBEnum.PLATFORM.ordervalue);
		qry.append(" INTEGER, ");
		qry.append(PortalDBEnum.PLATFORM.modifiedDate);
		qry.append(" timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,");
		qry.append(" PRIMARY KEY( ");
		qry.append(PortalDBEnum.PLATFORM.platformId.name());
		qry.append(")) ENGINE=InnoDB DEFAULT CHARSET=utf8 ");
		return qry.toString();
	}

	/**
	 * -- Table structure for table `applicationplatform`
	 */
	private String createApplicationPlatformTable() {
		StringBuilder qry = new StringBuilder();
		qry.append("CREATE TABLE IF NOT EXISTS ");
		qry.append(PortalDBEnum.TABLE_NAMES.applicationplatform.name());
		qry.append(" (");
		qry.append(PortalDBEnum.APPLICATION_PLATFORM.appPlatformId);
		qry.append(" varchar(32) NOT NULL,");
		qry.append(PortalDBEnum.APPLICATION_PLATFORM.platformId);
		qry.append(" varchar(32) NOT NULL,");
		qry.append(PortalDBEnum.APPLICATION_PLATFORM.appId);
		qry.append(" varchar(32) NOT NULL,");
		qry.append(PortalDBEnum.APPLICATION_PLATFORM.repositoryName);
		qry.append(" varchar(255) NOT NULL,");
		qry.append(PortalDBEnum.APPLICATION_PLATFORM.modifiedDate);
		qry.append(" timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,");
		qry.append(" PRIMARY KEY( ");
		qry.append(PortalDBEnum.APPLICATION_PLATFORM.appPlatformId.name());
		qry.append("),");

		qry.append(" CONSTRAINT `appPt_1` FOREIGN KEY (");
		qry.append(PortalDBEnum.APPLICATION_PLATFORM.appId.name());
		qry.append(")");
		qry.append(" REFERENCES ");
		qry.append(PortalDBEnum.TABLE_NAMES.application.name());
		qry.append(" (");
		qry.append(PortalDBEnum.APPLICATION.appId.name());
		qry.append(") ON DELETE CASCADE, ");
		qry.append(" CONSTRAINT `appPt_2` FOREIGN KEY (");
		qry.append(PortalDBEnum.APPLICATION_PLATFORM.platformId.name());
		qry.append(")");
		qry.append(" REFERENCES ");
		qry.append(PortalDBEnum.TABLE_NAMES.platform.name());
		qry.append(" (");
		qry.append(PortalDBEnum.PLATFORM.platformId.name());
		qry.append(") ON DELETE CASCADE ");

		qry.append(") ENGINE=InnoDB DEFAULT CHARSET=utf8 ");
		return qry.toString();
	}

	/**
	 * method to generate query to insert default entries
	 * 
	 * @return
	 */
	private List<QueryVO> insertDefaultPlatForm() {

		List<QueryVO> insertlist = new ArrayList<>();
		String sql = insertIntoPlatForm();
		insertlist.add(new SqlQueryBuilder().appendQuery(sql).addParameter(Common.getRandomId()).addParameter("x86-64")
				.addParameter("x86_64").addParameter(1).build());

		insertlist.add(new SqlQueryBuilder().appendQuery(sql).addParameter(Common.getRandomId()).addParameter("ARM64")
				.addParameter("ARM64").addParameter(2).build());

		insertlist.add(new SqlQueryBuilder().appendQuery(sql).addParameter(Common.getRandomId()).addParameter("ARM32")
				.addParameter("ARM32").addParameter(3).build());

		return insertlist;
	}

	/**
	 * -- create query to add default platform entries.
	 * 
	 * @return
	 */
	private String insertIntoPlatForm() {
		StringBuilder qry = new StringBuilder("INSERT INTO ");
		qry.append(PortalDBEnum.TABLE_NAMES.platform.name());
		qry.append("(");
		qry.append(PortalDBEnum.PLATFORM.platformId.name());
		qry.append(", ");
		qry.append(PortalDBEnum.PLATFORM.platformName.name());
		qry.append(", ");
		qry.append(PortalDBEnum.PLATFORM.platformActualName.name());
		qry.append(", ");
		qry.append(PortalDBEnum.PLATFORM.ordervalue.name());
		qry.append(", ");
		qry.append(PortalDBEnum.PLATFORM.modifiedDate.name());
		qry.append(") VALUES (");
		qry.append("?");
		// qry.append(Common.getRandomId());
		qry.append(", ");
		qry.append("?");
		// qry.append(platformName);
		qry.append(", ");
		qry.append("?");
		// qry.append(platformActualName);
		qry.append(", ");
		qry.append("?");
		// qry.append(order);
		qry.append(", ");
		qry.append("NOW()");
		qry.append(")");
		return qry.toString();
	}

	/**
	 * -- Table structure for table `applicationserviceendpoints`
	 * 
	 * @return
	 */
	private String createApplicationServiceEndpointsTable() {
		StringBuilder qry = new StringBuilder();
		qry.append("CREATE TABLE IF NOT EXISTS ");
		qry.append(PortalDBEnum.TABLE_NAMES.applicationserviceendpoints.name());
		qry.append(" (");
		qry.append(PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.appServiceEndpointId);
		qry.append(" varchar(32) NOT NULL,");
		qry.append(PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.appId);
		qry.append(" varchar(32) NOT NULL,");
		qry.append(PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.appVersionId);
		qry.append(" varchar(32) NOT NULL,");
		qry.append(PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.platformId);
		qry.append(" varchar(32) NOT NULL,");
		qry.append(PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.serviceName);
		qry.append(" varchar(50) NOT NULL,");
		qry.append(PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.protocol);
		qry.append(" varchar(20) NOT NULL,");
		qry.append(PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.containerPort);
		qry.append(" int(11) NOT NULL,");
		qry.append(PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.imageName);
		qry.append(" varchar(500) NOT NULL,");
		qry.append(PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.customHeaders);
		qry.append(" text NOT NULL,");
		qry.append(" PRIMARY KEY( ");
		qry.append(PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.appServiceEndpointId.name());
		qry.append("),");
		qry.append(" UNIQUE KEY `my_unique_key` (");
		qry.append(PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.serviceName);
		qry.append(",");
		qry.append(PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.platformId + ","
				+ PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.appId);
		qry.append("),");
		qry.append(" KEY `aId` (");
		qry.append(PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.appId);
		qry.append("),");
		qry.append(" KEY `avId` (");
		qry.append(PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.appVersionId);
		qry.append(")");
		qry.append(") ENGINE=InnoDB DEFAULT CHARSET=utf8 ");
		return qry.toString();
	}

	/*
	 * -- Table structure for table `applicationserviceports`
	 */
	private String createApplicationServicePorts() {
		StringBuilder qry = new StringBuilder();
		qry.append("CREATE TABLE IF NOT EXISTS ");
		qry.append(PortalDBEnum.TABLE_NAMES.applicationserviceports.name());
		qry.append(" (");
		qry.append(PortalDBEnum.APPLICATION_SERVICE_PORTS.appServicePortId);
		qry.append(" varchar(50) NOT NULL,");
		qry.append(PortalDBEnum.APPLICATION_SERVICE_PORTS.appVersionId);
		qry.append(" varchar(50) NOT NULL,");
		qry.append(PortalDBEnum.APPLICATION_SERVICE_PORTS.serviceName);
		qry.append("  varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,");
		qry.append(PortalDBEnum.APPLICATION_SERVICE_PORTS.internalPort);
		qry.append(" varchar(500) NOT NULL,");
		qry.append(PortalDBEnum.APPLICATION_SERVICE_PORTS.externalPort);
		qry.append(" text NOT NULL,");
		qry.append(" PRIMARY KEY( ");
		qry.append(PortalDBEnum.APPLICATION_SERVICE_PORTS.appServicePortId.name());
		qry.append("),");

		qry.append(" CONSTRAINT `appSerPort_1` FOREIGN KEY (");
		qry.append(PortalDBEnum.APPLICATION_SERVICE_PORTS.appVersionId.name());
		qry.append(")");
		qry.append(" REFERENCES ");
		qry.append(PortalDBEnum.TABLE_NAMES.applicationversions.name());
		qry.append(" (");
		qry.append(PortalDBEnum.APPLICATION_VERSIONS.appVersionId.name());
		qry.append(") ON DELETE CASCADE ");
		qry.append(") ENGINE=InnoDB DEFAULT CHARSET=utf8 ");
		return qry.toString();

	}

	/**
	 * -- Table structure for table `dockerEventLog`
	 * 
	 * @return
	 */
	private String createDockerEventLoggerTable() {
		StringBuilder qry = new StringBuilder("CREATE TABLE IF NOT EXISTS ");
		qry.append(PortalDBEnum.TABLE_NAMES.dockerEventLog.name());
		qry.append(" (");
		qry.append(PortalDBEnum.DOCKER_EVENT_LOG.id.name());
		qry.append(" varchar(32) NOT NULL,");
		qry.append(PortalDBEnum.DOCKER_EVENT_LOG.applicationId.name());
		qry.append(" varchar(32) NOT NULL,");
		qry.append(PortalDBEnum.DOCKER_EVENT_LOG.versionId.name());
		qry.append(" varchar(32) NOT NULL,");
		qry.append(PortalDBEnum.DOCKER_EVENT_LOG.deviceId.name());
		qry.append(" varchar(32) NOT NULL,");
		qry.append(PortalDBEnum.DOCKER_EVENT_LOG.event.name());
		qry.append(" TEXT,");
		qry.append(PortalDBEnum.DOCKER_EVENT_LOG.systemStatus.name());
		qry.append(" TEXT,");
		qry.append(PortalDBEnum.DOCKER_EVENT_LOG.createdDate.name());
		qry.append(" timestamp  NOT NULL DEFAULT CURRENT_TIMESTAMP,");
		qry.append(" UNIQUE (");
		qry.append(PortalDBEnum.DOCKER_EVENT_LOG.id.name());
		qry.append(" ))");
		return qry.toString();
	}

	/**
	 * -- Table structure for table `dockerEventLog`
	 * 
	 * @return
	 */
	private String createActivityLoggerTable() {
		StringBuilder qry = new StringBuilder("CREATE TABLE IF NOT EXISTS ");
		qry.append(PortalDBEnum.TABLE_NAMES.activityLog.name());
		qry.append(" (");
		qry.append(PortalDBEnum.ACTIVITY_LOG.id.name());
		qry.append(" varchar(32) NOT NULL,");
		qry.append(PortalDBEnum.ACTIVITY_LOG.userId.name());
		qry.append(" varchar(32) NOT NULL,");
		qry.append(PortalDBEnum.ACTIVITY_LOG.param.name());
		qry.append(" TEXT,");
		qry.append(PortalDBEnum.ACTIVITY_LOG.action.name());
		qry.append(" varchar(32) NOT NULL,");
		qry.append(PortalDBEnum.ACTIVITY_LOG.timeStamp.name());
		qry.append(" timestamp  NOT NULL DEFAULT CURRENT_TIMESTAMP,");
		qry.append(" UNIQUE (");
		qry.append(PortalDBEnum.ACTIVITY_LOG.id.name());
		qry.append(" ))");
		return qry.toString();
	}

	/**
	 * -- Table structure for table `applicationType`
	 * 
	 * @return
	 */
	private String createAppTypeTable() {
		StringBuilder qry = new StringBuilder();
		qry.append("CREATE TABLE IF NOT EXISTS ");
		qry.append(PortalDBEnum.TABLE_NAMES.applicationType.name());
		qry.append(" (");
		qry.append(PortalDBEnum.APPLICATION_TYPE.typeId);
		qry.append(" varchar(32) NOT NULL,");
		qry.append(PortalDBEnum.APPLICATION_TYPE.type);
		qry.append(" varchar(100) NOT NULL,");
		qry.append(PortalDBEnum.APPLICATION_TYPE.typeDisplayName);
		qry.append(" varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,");
		qry.append(" PRIMARY KEY( ");
		qry.append(PortalDBEnum.APPLICATION_TYPE.typeId.name());
		qry.append(")) ENGINE=InnoDB DEFAULT CHARSET=utf8 ");
		return qry.toString();
	}

	// virtualMapId,
	// virtualDomainName,
	// deviceId,
	// createdDate,
	// modifiedDate
	private String createVirtualURLTable() {
		StringBuilder qry = new StringBuilder("CREATE TABLE IF NOT EXISTS ");
		qry.append(PortalDBEnum.TABLE_NAMES.virtualURLMap.name());
		qry.append(" (");
		qry.append(PortalDBEnum.VIRTUAL_URL_MAP.virtualMapId.name());
		qry.append(" varchar(32) NOT NULL,");
		qry.append(PortalDBEnum.VIRTUAL_URL_MAP.virtualDomainName.name());
		qry.append(" varchar(50) NOT NULL,");
		qry.append(PortalDBEnum.VIRTUAL_URL_MAP.deviceId.name());
		qry.append(" varchar(32) NOT NULL,");
		qry.append(PortalDBEnum.VIRTUAL_URL_MAP.userId.name());
		qry.append(" varchar(32) NOT NULL,");
		qry.append(PortalDBEnum.VIRTUAL_URL_MAP.createdDate.name());
		qry.append(" timestamp  NOT NULL DEFAULT CURRENT_TIMESTAMP,");
		qry.append(PortalDBEnum.VIRTUAL_URL_MAP.modifiedDate);
		qry.append(" timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,");
		qry.append(" PRIMARY KEY( ");
		qry.append(PortalDBEnum.VIRTUAL_URL_MAP.virtualMapId.name());
		qry.append("),");
		qry.append(" UNIQUE (");
		qry.append(PortalDBEnum.VIRTUAL_URL_MAP.virtualDomainName.name());
		qry.append(" ))");
		return qry.toString();
	}

	/**
	 * method to generate query to insert default app types
	 * 
	 * @return
	 */
	private List<QueryVO> insertDefaultAppType() {
		List<QueryVO> insertlist = new ArrayList<>();

		String sql = insertIntoAppType();
		insertlist.add(new SqlQueryBuilder().appendQuery(sql).addParameter(Common.getRandomId())
				.addParameter(ApplicationDefaultType.dockercompose.name())
				.addParameter(ApplicationDefaultType.dockercompose.getValue()).build());

		insertlist.add(new SqlQueryBuilder().appendQuery(sql).addParameter(Common.getRandomId())
				.addParameter(ApplicationDefaultType.kubernetes.name())
				.addParameter(ApplicationDefaultType.kubernetes.getValue()).build());

		return insertlist;
	}

	/**
	 * create query to update application type for dockercompose devices app in
	 * application table.
	 * 
	 * @return
	 */
	private String updateAppTypeId() {
		StringBuilder qry = new StringBuilder("UPDATE ");
		qry.append(PortalDBEnum.TABLE_NAMES.application.name());
		qry.append(" SET ");
		qry.append(PortalDBEnum.APPLICATION.appTypeId.name());
		qry.append(" = ");
		qry.append("( SELECT ");
		qry.append(PortalDBEnum.APPLICATION_TYPE.typeId.name());
		qry.append(" FROM ");
		qry.append(PortalDBEnum.TABLE_NAMES.applicationType.name());
		qry.append(" WHERE ");
		qry.append(PortalDBEnum.APPLICATION_TYPE.type.name());
		qry.append(" = ");
		qry.append(ApplicationDefaultType.dockercompose.name());
		qry.append(")");
		return qry.toString();

	}

	/**
	 * create query to update company status and set ACTIVE
	 * 
	 * @return
	 */
	private String updateCompanyStatus() {
		StringBuilder qry = new StringBuilder("UPDATE ");
		qry.append(PortalDBEnum.TABLE_NAMES.company.name());
		qry.append(" SET ");
		qry.append(PortalDBEnum.COMPANY.companyStatus.name());
		qry.append(" = ");
		qry.append(Status.ACTIVE.ordinal());
		return qry.toString();
	}

	/**
	 * create query to insert applicator type default entry
	 * 
	 * @param type
	 * @param typeDisplayName
	 * @return
	 */
	private String insertIntoAppType() {
		StringBuilder qry = new StringBuilder("INSERT INTO ");
		qry.append(PortalDBEnum.TABLE_NAMES.applicationType.name());
		qry.append("(");
		qry.append(PortalDBEnum.APPLICATION_TYPE.typeId.name());
		qry.append(", ");
		qry.append(PortalDBEnum.APPLICATION_TYPE.type.name());
		qry.append(", ");
		qry.append(PortalDBEnum.APPLICATION_TYPE.typeDisplayName.name());
		qry.append(") VALUES (");
		qry.append("?");
		// qry.append(Common.getRandomId());
		qry.append(", ");
		qry.append("?");
		// qry.append(type);
		qry.append(", ");
		qry.append("?");
		// qry.append(typeDisplayName);
		qry.append(")");
		return qry.toString();
	}

	private String updateSoftwarePtId()

	{

		StringBuilder qry = new StringBuilder("UPDATE ");

		qry.append(PortalDBEnum.TABLE_NAMES.devices.name());

		qry.append(" SET ");

		qry.append(PortalDBEnum.DEVICES.swPlatformId.name());

		qry.append(" = ");

		qry.append(" CASE WHEN ");

		qry.append(PortalDBEnum.DEVICES.deviceType.name());

		qry.append(" = ");

		qry.append(0);

		qry.append(" THEN ");

		qry.append("(Select ");

		qry.append(PortalDBEnum.APPLICATION_TYPE.typeId);

		qry.append(" FROM ");

		qry.append(PortalDBEnum.TABLE_NAMES.applicationType);

		qry.append(" WHERE ");

		qry.append(PortalDBEnum.APPLICATION_TYPE.type);

		qry.append(" = ");

		qry.append("'");

		qry.append(ApplicationDefaultType.dockercompose.name());

		qry.append("')");

		qry.append(" ELSE ");

		qry.append("(Select ");

		qry.append(PortalDBEnum.APPLICATION_TYPE.typeId);

		qry.append(" FROM ");

		qry.append(PortalDBEnum.TABLE_NAMES.applicationType);

		qry.append(" WHERE ");

		qry.append(PortalDBEnum.APPLICATION_TYPE.type);

		qry.append(" = ");

		qry.append("'");

		qry.append(ApplicationDefaultType.kubernetes.name());

		qry.append("')");

		qry.append(" END ");

		return qry.toString();

	}

	private String createGroupEdgeCoreTable() {
		StringBuilder qry = new StringBuilder();
		qry.append("CREATE TABLE IF NOT EXISTS ");
		qry.append(PortalDBEnum.TABLE_NAMES.groupEdgeCore.name());
		qry.append(" (");
		qry.append(PortalDBEnum.GROUP_EDGECORE.groupEdgeCoreId);
		qry.append(" varchar(32) NOT NULL,");
		qry.append(PortalDBEnum.GROUP_EDGECORE.groupId);
		qry.append(" varchar(32) NOT NULL,");
		qry.append(PortalDBEnum.GROUP_EDGECORE.edgeCoreId);
		qry.append(" varchar(32) NOT NULL,");
		qry.append(" PRIMARY KEY( ");
		qry.append(PortalDBEnum.GROUP_EDGECORE.groupEdgeCoreId.name());
		qry.append("),");
		qry.append(" CONSTRAINT `groupedgecore_ibfk_1` FOREIGN KEY (");
		qry.append(PortalDBEnum.GROUP_EDGECORE.edgeCoreId);
		qry.append(")");
		qry.append(" REFERENCES ");
		qry.append(PortalDBEnum.TABLE_NAMES.devices.name());
		qry.append(" (");
		qry.append(PortalDBEnum.DEVICES.deviceId);
		qry.append(")) ENGINE=InnoDB DEFAULT CHARSET=utf8 ");
		return qry.toString();
	}

	private String createDownloadTable() {
		StringBuilder qry = new StringBuilder();
		qry.append("CREATE TABLE IF NOT EXISTS ");
		qry.append(PortalDBEnum.TABLE_NAMES.downloads.name());
		qry.append(" (");
		qry.append(PortalDBEnum.DOWNLOADS.resourceId);
		qry.append(" varchar(32) NOT NULL,");
		qry.append(PortalDBEnum.DOWNLOADS.resourceType);
		qry.append(" int NOT NULL,");
		qry.append(PortalDBEnum.DOWNLOADS.details);
		qry.append(" TEXT ,");
		qry.append(PortalDBEnum.DOWNLOADS.sortOrder);
		qry.append(" int NOT NULL DEFAULT 1,");
		qry.append(" PRIMARY KEY( ");
		qry.append(PortalDBEnum.DOWNLOADS.resourceId.name());
		qry.append(")) ENGINE=InnoDB DEFAULT CHARSET=utf8 ");
		return qry.toString();
	}

	private String createGroupResourceTable() {
		StringBuilder qry = new StringBuilder();
		qry.append("CREATE TABLE IF NOT EXISTS ");
		qry.append(PortalDBEnum.TABLE_NAMES.groupResources.name());
		qry.append(" (");
		qry.append(PortalDBEnum.GROUP_RESOURCES.groupResouceId);
		qry.append(" varchar(32) NOT NULL,");
		qry.append(PortalDBEnum.GROUP_RESOURCES.groupId);
		qry.append(" varchar(32) NOT NULL,");
		qry.append(PortalDBEnum.GROUP_RESOURCES.resourceId);
		qry.append(" varchar(32) NOT NULL,");
		qry.append(PortalDBEnum.GROUP_RESOURCES.resourceType);
		qry.append(" int NOT NULL,");
		qry.append(" PRIMARY KEY( ");
		qry.append(PortalDBEnum.GROUP_RESOURCES.groupResouceId.name());
		qry.append("),");
		qry.append(" CONSTRAINT `groupresource_ibfk_1` FOREIGN KEY (");
		qry.append(PortalDBEnum.GROUP_RESOURCES.resourceId);
		qry.append(")");
		qry.append(" REFERENCES ");
		qry.append(PortalDBEnum.TABLE_NAMES.downloads.name());
		qry.append(" (");
		qry.append(PortalDBEnum.DOWNLOADS.resourceId);
		qry.append(") ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8 ");
		return qry.toString();
	}

	private String createSettingsTable() {
		return "CREATE TABLE IF NOT EXISTS `settings` ( `settingsKey` varchar(32) NOT NULL, `settingsValue` text NOT NULL, UNIQUE KEY `settingsKey_UNIQUE` (`settingsKey`)) ENGINE=InnoDB DEFAULT CHARSET=utf8";
	}

	private List<QueryVO> insertDefaultSettings() {

		List<QueryVO> list = new LinkedList<>();
		String sql = "Insert INTO settings ( settingsKey,settingsValue )  VALUES  (?,?)";
		list.add(new SqlQueryBuilder().appendQuery(sql).addParameter(SETTINGS_KEY.logLevelError.name())
				.addParameter("true").build());
		list.add(new SqlQueryBuilder().appendQuery(sql).addParameter(SETTINGS_KEY.logLevelInfo.name())
				.addParameter("true").build());
		list.add(new SqlQueryBuilder().appendQuery(sql).addParameter(SETTINGS_KEY.logLevelTrace.name())
				.addParameter("true").build());
		list.add(new SqlQueryBuilder().appendQuery(sql).addParameter(SETTINGS_KEY.logLevelWarn.name())
				.addParameter("true").build());

		return list;
	}

	private String createAlertsTable() {
		StringBuilder qry = new StringBuilder();
		qry.append("CREATE TABLE IF NOT EXISTS ");
		qry.append(PortalDBEnum.TABLE_NAMES.alerts.name());
		qry.append(" (");
		qry.append(PortalDBEnum.ALERTS.alertId);
		qry.append(" varchar(32) NOT NULL,");
		qry.append(PortalDBEnum.ALERTS.alertType);
		qry.append(" TINYINT,");
		qry.append(PortalDBEnum.ALERTS.messageType);
		qry.append(" TINYINT,");
		qry.append(PortalDBEnum.ALERTS.info);
		qry.append(" TEXT,");
		qry.append(PortalDBEnum.ALERTS.commandMessage);
		qry.append(" TEXT,");
		qry.append(PortalDBEnum.ALERTS.createdDate);
		qry.append(" timestamp  NOT NULL DEFAULT CURRENT_TIMESTAMP,");
		qry.append(" PRIMARY KEY( ");
		qry.append(PortalDBEnum.ALERTS.alertId.name());
		qry.append(")) ENGINE=InnoDB DEFAULT CHARSET=utf8 ");
		return qry.toString();
	}

	private String createNetworkTable() {
		StringBuilder qry = new StringBuilder();
		qry.append("CREATE TABLE IF NOT EXISTS ");
		qry.append(PortalDBEnum.TABLE_NAMES.network.name());
		qry.append(" (");
		qry.append(PortalDBEnum.NETWORK.networkId);
		qry.append(" varchar(32) NOT NULL,");
		qry.append(PortalDBEnum.NETWORK.networkName);
		qry.append(" TEXT,");
		qry.append(PortalDBEnum.NETWORK.userId);
		qry.append(" varchar(32) NOT NULL,");
		qry.append(PortalDBEnum.NETWORK.networkType);
		qry.append(" TINYINT,");
		qry.append(PortalDBEnum.NETWORK.createdDate);
		qry.append(" timestamp  NOT NULL DEFAULT CURRENT_TIMESTAMP,");
		qry.append(" PRIMARY KEY( ");
		qry.append(PortalDBEnum.NETWORK.networkId.name());
		qry.append(")) ENGINE=InnoDB DEFAULT CHARSET=utf8 ");
		return qry.toString();
	}

	private String createApplicationNetworkTable() {
		StringBuilder qry = new StringBuilder();
		qry.append("CREATE TABLE IF NOT EXISTS ");
		qry.append(PortalDBEnum.TABLE_NAMES.applicationNetwork.name());
		qry.append(" (");
		qry.append(PortalDBEnum.APPLICATION_NETWORK.appNetId);
		qry.append(" varchar(32) NOT NULL,");
		qry.append(PortalDBEnum.APPLICATION_NETWORK.appId);
		qry.append(" varchar(32) NOT NULL,");
		qry.append(PortalDBEnum.APPLICATION_NETWORK.networkId);
		qry.append(" varchar(32) NOT NULL,");
		qry.append(" PRIMARY KEY( ");
		qry.append(PortalDBEnum.APPLICATION_NETWORK.appNetId.name());
		qry.append("),");
		qry.append(" CONSTRAINT `applicationNetwork_ibfk_1` FOREIGN KEY (");
		qry.append(PortalDBEnum.APPLICATION_NETWORK.networkId);
		qry.append(")");
		qry.append(" REFERENCES ");
		qry.append(PortalDBEnum.TABLE_NAMES.network.name());
		qry.append(" (");
		qry.append(PortalDBEnum.NETWORK.networkId);
		qry.append(")) ENGINE=InnoDB DEFAULT CHARSET=utf8 ");
		return qry.toString();
	}

	// appSecretId,
	// appId,
	// serviceName,
	// secretKey,
	// displayName,
	// type,
	// secretValue,
	// createdDate,
	// modifiedDate

	private String createAppSecret() {
		StringBuilder qry = new StringBuilder("CREATE TABLE IF NOT EXISTS ");
		qry.append(PortalDBEnum.TABLE_NAMES.appSecret.name());
		qry.append(" (");
		qry.append(PortalDBEnum.APP_SECRET.appSecretId.name());
		qry.append(" varchar(32) NOT NULL,");
		qry.append(PortalDBEnum.APP_SECRET.appId.name());
		qry.append(" varchar(32) NOT NULL,");
		qry.append(PortalDBEnum.APP_SECRET.serviceName.name());
		qry.append(" varchar(255),");
		qry.append(PortalDBEnum.APP_SECRET.secretKey.name());
		qry.append(" varchar(64) NOT NULL,");
		qry.append(PortalDBEnum.APP_SECRET.configType.name());
		qry.append(" varchar(64) DEFAULT NULL,");
		qry.append(PortalDBEnum.APP_SECRET.createdDate.name());
		qry.append(" timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP, ");
		qry.append(PortalDBEnum.APP_SECRET.modifiedDate.name());
		qry.append(" timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, ");
		qry.append(" PRIMARY KEY (");
		qry.append(PortalDBEnum.APP_SECRET.appSecretId.name());
		qry.append(") ");
		// add unique constraint for appid+secretkey
		qry.append(",");
		qry.append(" UNIQUE KEY app_secret_key_Unique (");
		qry.append(PortalDBEnum.APP_SECRET.secretKey.name());
		qry.append(",");
		qry.append(PortalDBEnum.APP_SECRET.appId.name());
		qry.append(")");
		// qry.append( ",");
		// qry.append( " UNIQUE KEY app_secret_Unique (");
		// qry.append( PortalDBEnum.APP_SECRET.appId.name());
		// qry.append( "),");
		// qry.append( " CONSTRAINT `app_secret_ibfk` FOREIGN KEY (");
		// qry.append( PortalDBEnum.APP_SECRET.appId.name());
		// qry.append( " )REFERENCES ");
		// qry.append(PortalDBEnum.TABLE_NAMES.application.name());
		// qry.append( " (" );
		// qry.append( PortalDBEnum.APPLICATION.appId.name());
		// qry.append( ") ON DELETE CASCADE" );
		qry.append(") ENGINE=InnoDB DEFAULT CHARSET=utf8 ");
		return qry.toString();
	}

	private List<String> modifyUniqueContraint() {
		List<String> queries = new ArrayList<>();
		StringBuilder sbDrop = new StringBuilder();
		sbDrop.append("ALTER TABLE ");
		sbDrop.append(PortalDBEnum.TABLE_NAMES.appSecret.name());
		sbDrop.append(" DROP INDEX app_secret_Unique");
		queries.add(sbDrop.toString());

		// StringBuilder sbAdd= new StringBuilder();
		//
		// sbAdd.append("ALTER TABLE ");
		// sbAdd.append(PortalDBEnum.TABLE_NAMES.appSecret.name());
		// sbAdd.append(" ADD CONSTRAINT app_secret_Unique UNIQUE (");
		// sbAdd.append( PortalDBEnum.APP_SECRET.displayName.name());
		// sbAdd.append( ",");
		// sbAdd.append( PortalDBEnum.APP_SECRET.appId.name());
		// sbAdd.append( ")");
		// queries.add(sbAdd.toString());

		return queries;
	}

	// jobSecretId,
	// appSecretId,
	// edgeCoreId,
	// jobId,
	// createdDate,
	// modifiedDate
	private String createJobSecret() {
		StringBuilder qry = new StringBuilder("CREATE TABLE IF NOT EXISTS ");
		qry.append(PortalDBEnum.TABLE_NAMES.jobSecret.name());
		qry.append(" (");
		qry.append(PortalDBEnum.JOB_SECRET.jobSecretId.name());
		qry.append(" varchar(32) NOT NULL,");
		qry.append(PortalDBEnum.JOB_SECRET.appSecretVersionId.name());
		qry.append(" varchar(32) NOT NULL,");
		qry.append(PortalDBEnum.JOB_SECRET.edgeCoreId.name());
		qry.append(" varchar(32) NOT NULL,");
		qry.append(PortalDBEnum.JOB_SECRET.jobId.name());
		qry.append(" varchar(32) NOT NULL,");
		qry.append(PortalDBEnum.JOB_SECRET.serviceName.name());
		qry.append(" varchar(255) NOT NULL,");
		qry.append(PortalDBEnum.JOB_SECRET.createdDate.name());
		qry.append(" timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP, ");
		qry.append(PortalDBEnum.JOB_SECRET.modifiedDate.name());
		qry.append(" timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, ");
		qry.append(" PRIMARY KEY (");
		qry.append(PortalDBEnum.JOB_SECRET.jobSecretId.name());
		qry.append("),");

		qry.append(" CONSTRAINT `job_secret_ibfk_1` FOREIGN KEY (");
		qry.append(PortalDBEnum.JOB_SECRET.appSecretVersionId.name());
		qry.append(" )REFERENCES ");
		qry.append(PortalDBEnum.TABLE_NAMES.appSecretVersion.name());
		qry.append(" (");
		qry.append(PortalDBEnum.APP_SECRET_VERSION.appSecretVersionId.name());
		qry.append(") ON DELETE CASCADE");
		qry.append(",");

		qry.append(" CONSTRAINT `job_secret_ibfk_2` FOREIGN KEY (");
		qry.append(PortalDBEnum.JOB_SECRET.edgeCoreId.name());
		qry.append(" )REFERENCES ");
		qry.append(PortalDBEnum.TABLE_NAMES.devices.name());
		qry.append(" (");
		qry.append(PortalDBEnum.DEVICES.deviceId.name());
		qry.append(") ON DELETE CASCADE");
		qry.append(",");

		qry.append(" CONSTRAINT `job_secret_ibfk_3` FOREIGN KEY (");
		qry.append(PortalDBEnum.JOB_SECRET.jobId.name());
		qry.append(" )REFERENCES ");
		qry.append(PortalDBEnum.TABLE_NAMES.installJobs.name());
		qry.append(" (");
		qry.append(PortalDBEnum.INSTALL_JOBS.uId.name());
		qry.append(") ON DELETE CASCADE");

		qry.append(") ENGINE=InnoDB DEFAULT CHARSET=utf8 ");
		return qry.toString();
	}

	// appSecretVersionId,
	// appSecretId,
	// appUserId,
	// configType,
	// displayName,
	// secretValue,
	// createdDate,
	// modifiedDate
	protected String createAppSecretVersion() {
		StringBuilder qry = new StringBuilder("CREATE TABLE IF NOT EXISTS ");
		qry.append(PortalDBEnum.TABLE_NAMES.appSecretVersion.name());
		qry.append(" (");
		qry.append(PortalDBEnum.APP_SECRET_VERSION.appSecretVersionId.name());
		qry.append(" varchar(32) NOT NULL,");
		qry.append(PortalDBEnum.APP_SECRET_VERSION.appSecretId.name());
		qry.append(" varchar(32) NOT NULL,");
		qry.append(PortalDBEnum.APP_SECRET_VERSION.appUserId.name());
		qry.append(" varchar(32) NOT NULL,");
		qry.append(PortalDBEnum.APP_SECRET_VERSION.displayName.name());
		qry.append(" varchar(100) NOT NULL,");
		qry.append(PortalDBEnum.APP_SECRET_VERSION.type.name());
		qry.append(" int NOT NULL,");
		qry.append(PortalDBEnum.APP_SECRET_VERSION.secretValue.name());
		qry.append(" TEXT NOT NULL,");
		qry.append(PortalDBEnum.APP_SECRET_VERSION.createdDate.name());
		qry.append(" timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP, ");
		qry.append(PortalDBEnum.APP_SECRET_VERSION.modifiedDate.name());
		qry.append(" timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, ");
		qry.append(" PRIMARY KEY (");
		qry.append(PortalDBEnum.APP_SECRET_VERSION.appSecretVersionId.name());
		qry.append("),");
		qry.append(" UNIQUE KEY app_secret_Unique (");
		qry.append(PortalDBEnum.APP_SECRET_VERSION.displayName.name());
		qry.append(",");
		qry.append(PortalDBEnum.APP_SECRET_VERSION.appSecretId.name());
		qry.append("),");
		qry.append(" CONSTRAINT `app_secret_version_ibfk` FOREIGN KEY (");
		qry.append(PortalDBEnum.APP_SECRET_VERSION.appSecretId.name());
		qry.append(" )REFERENCES ");
		qry.append(PortalDBEnum.TABLE_NAMES.appSecret.name());
		qry.append(" (");
		qry.append(PortalDBEnum.APP_SECRET.appSecretId.name());
		qry.append(") ON DELETE CASCADE");
		qry.append(") ENGINE=InnoDB DEFAULT CHARSET=utf8 ");
		return qry.toString();
	}

	@Override
	public String getDBUpdateVersionQuery() {
		// TODO Auto-generated method stub
		return null;
	}

}

/**
 * History of check-in or issue resolved
 * 
 * 01 - 7-10-2016 AKH_01_1 Remove applicationconfigurations table from
 * platformportal database, because only composerFilePath is used from this
 * table so we add this field in applicationversions table, and remove
 * appConfigId from applicationversions table. AKH_01_2 change coulmn name
 * appConfigId to appVersionId of applicationserviceendpoints table. AKH_01_3
 * Add coulmn (usePxAuth, usePxEventService, usePxCloudApi, signUpType) in
 * applications table. 02 - 20-10-2016 AKH_02_1 Add field currency, price and
 * rating in application table for use sorting on UI.
 * 
 * 03 - 4-11-2016 AKH_03 Add field restRedirectUrl and redirectSection in
 * application table we save "reverse proxy" and "specific port" in redirect Url
 * and rest Url save in restRedirectUrl.
 * 
 * 04 - 14-11-2016 AKH_04 remove restRedirectUrl, redirectUrl, redirectType and
 * redirectSection these property shift to applicationVersion, because may be
 * each version have different redirection param.
 * 
 * PSH_1 (26-6-2017) Added new database Box Statics.
 */