/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal;

import com.mwp.p.common.enums.PortalDBEnum;

/**
 * This class generate queries related to table boxStatics
 *
 */
public class BoxStaticsDB {
	public BoxStaticsDB() {
	}
		
	/**
	 * create query to insert into box statics 
	 * @param deviceId
	 * @param statics
	 * @return
	 */
	public String insert(){
		StringBuilder sb = new StringBuilder();
		sb.append("INSERT INTO ");sb.append(PortalDBEnum.TABLE_NAMES.boxStatics.name());
		sb.append(" ( ");
		sb.append(PortalDBEnum.BOX_STATICS.deviceId.name()); 
		sb.append(", ");
		sb.append(PortalDBEnum.BOX_STATICS.statics.name());
		sb.append(", ");
		sb.append(PortalDBEnum.BOX_STATICS.modifiedDate.name());
		sb.append(" ) VALUES (");
		sb.append("?"); 
		sb.append(", ");
		sb.append("?");
		sb.append(", ");
		sb.append("NOW()");
		sb.append(" ) ");
		sb.append(" ON DUPLICATE KEY UPDATE ");
		sb.append(PortalDBEnum.BOX_STATICS.statics.name());sb.append(" = ");sb.append("?");
		sb.append(", ");
		sb.append(PortalDBEnum.BOX_STATICS.modifiedDate.name());sb.append(" = ");sb.append("NOW()");		
	
		return sb.toString();
	}
	
	/**
	 * Get latest statistics entry of device 
	 * @param deviceId
	 * @return
	 */
	public String getStatics() {
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT * FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.boxStatics);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.BOX_STATICS.deviceId);
		sb.append(" = ");
		sb.append("?");
		sb.append(" order by ");
		sb.append(PortalDBEnum.BOX_STATICS.modifiedDate.name());
		sb.append(" desc limit 1 ");
//		order by  modifiedDate desc limit 1
		return sb.toString();
	}
	
	
	public String deleteBoxStatics(){
		StringBuilder sb = new StringBuilder();
		sb.append("DELETE FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.boxStatics);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.BOX_STATICS.deviceId.name());sb.append(" = ");
		sb.append("?");
		return sb.toString();
		
	}
	
}
