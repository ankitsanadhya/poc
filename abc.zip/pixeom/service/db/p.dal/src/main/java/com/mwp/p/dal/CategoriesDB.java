/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal;

import java.util.ArrayList;
import java.util.List;

import com.mwp.common.enums.Status;
import com.mwp.db.Interface.IConnection;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.dal.engine.PortalDatabaseEngine;

/**
 * This class manage categories, add/edit/delete/list
 * search and suggested categories.
 * @author root
 *
 */
public class CategoriesDB {


	private List<String> queries=new ArrayList<>();
	private IConnection dbCon= null;
	public CategoriesDB() {
		dbCon = PortalDatabaseEngine.getInstance().getConnection();
	}


	/**
	 * get category according to categoryId.
	 * @param categoryId
	 * @return
	 */
	public String getCategory(){
		return mGetCategory();
	}

	/**
	 * edit category name and status.
	 * @param categoryVO
	 * @return
	 */
	public String editCategory(){
		return mEditCategory();
	}

	/**
	 * change status of catgeory in db DELETED.
	 * @param categoryId
	 * @return
	 */
	public String deleteCategory(){
		return mDeleteCategory();
	}

	/**
	 * add category in db
	 * @param categoryVO
	 * @return
	 */
	public String addCategory(){
		return mAddCategory();
	}

	/**
	 * search categories according to searchText with limit of pageSize.
	 * @param pageNo
	 * @param pageSize
	 * @param searchText
	 * @return
	 */
	public List<String> searchCategories(){
		return mSearchCategories();
	}

	/**
	 * List default categories which marked isDefault in db.
	 * @return
	 */
	public String listDefaultCategories(){
		return mListDefaultCategories();
	}

	/**
	 * this method gives list of suggested categories according to searchText.
	 * @param searchText
	 * @return
	 */
	public String suggestedCategories(){
		return mSuggestedCategories();
	}

	

	private String mGetCategory(){
		StringBuilder sb = new StringBuilder();
		sb.append("Select * ");
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.category);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.TABLE_NAMES.category);
		sb.append(".");
		sb.append(PortalDBEnum.CATEGORY.catStatus);
		sb.append(" != ");
		sb.append(Status.DELETED.ordinal());
		sb.append(" AND ");
		sb.append(PortalDBEnum.CATEGORY.catId);
		sb.append(" = ");
		sb.append("?");
		return sb.toString();
	}

	private String mEditCategory(){
		StringBuilder sb = new StringBuilder();
		sb.append("UPDATE ");
		sb.append(PortalDBEnum.TABLE_NAMES.category);
		sb.append(" SET ");

		sb.append(PortalDBEnum.CATEGORY.name.name());
		sb.append(" = ");
		sb.append("?");
		//sb.append(dbCon.formatString(categoryVO.getName()));
		sb.append(", ");

		sb.append(PortalDBEnum.CATEGORY.catStatus.name());
		sb.append(" = ");
		sb.append("?");
//		sb.append(categoryVO.getStatus().ordinal());
		sb.append(", ");

		sb.append(PortalDBEnum.CATEGORY.type.name());
		sb.append(" = ");
		sb.append("?");
//		sb.append(categoryVO.isDefaultCategory());
		sb.append(", ");

		sb.append(PortalDBEnum.CATEGORY.modifiedDate.name());
		sb.append(" = NOW()");

		sb.append(" WHERE ");
		sb.append(PortalDBEnum.CATEGORY.catId.name());
		sb.append(" = ");
		sb.append("?");
//		sb.append(dbCon.formatString(categoryVO.getCategoryId()));
		return sb.toString();
	}

	private String mDeleteCategory(){

		StringBuilder sb = new StringBuilder();
		sb.append("UPDATE ");
		sb.append(PortalDBEnum.TABLE_NAMES.category);
		sb.append(" SET ");


		sb.append(PortalDBEnum.CATEGORY.catStatus.name());
		sb.append(" = ");
		sb.append(Status.DELETED.ordinal());
		sb.append(", ");


		sb.append(PortalDBEnum.CATEGORY.modifiedDate.name());
		sb.append(" = NOW()");

		sb.append(" WHERE ");
		sb.append(PortalDBEnum.CATEGORY.catId.name());
		sb.append(" = ");
		sb.append("?");
		return sb.toString();
	}

	private String mAddCategory(){

		StringBuilder sb = new StringBuilder();
		sb.append("INSERT INTO ");
		sb.append(PortalDBEnum.TABLE_NAMES.category);
		sb.append(" ( ");
		sb.append(PortalDBEnum.CATEGORY.catId.name());
		sb.append(", ");
		sb.append(PortalDBEnum.CATEGORY.name.name());
		sb.append(", ");
		sb.append(PortalDBEnum.CATEGORY.catStatus.name());
		sb.append(", ");
		sb.append(PortalDBEnum.CATEGORY.type.name());
		sb.append(", ");
		sb.append(PortalDBEnum.CATEGORY.modifiedDate.name());
		sb.append(", ");
		sb.append(PortalDBEnum.CATEGORY.createdDate.name());
		sb.append(" ) VALUES ( ");
		sb.append("?");
		sb.append(", ");
		sb.append("?");
		sb.append(", ");
		sb.append("?");
		sb.append(", ");
		sb.append("?");
		sb.append(", ");
		sb.append(" NOW()");
		sb.append(", ");
		sb.append(" NOW()");
		sb.append(" ) ");
		return sb.toString();
	}

	private List<String> mSearchCategories(){
		
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT SQL_CALC_FOUND_ROWS ");
		sb.append(PortalDBEnum.TABLE_NAMES.category);
		sb.append(".*");//Get all columns from category table.		
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.category);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.TABLE_NAMES.category);
		sb.append(".");
		sb.append(PortalDBEnum.CATEGORY.catStatus);
		sb.append(" != ");
		sb.append(Status.DELETED.ordinal());
		sb.append(" AND ");
		sb.append(PortalDBEnum.TABLE_NAMES.category);
		sb.append(".");
		sb.append(PortalDBEnum.CATEGORY.name);
		sb.append(" like ");
		sb.append("?");
		//sb.append(dbCon.formatString(searchText+"%"));

		sb.append(" ORDER BY ");
		sb.append(PortalDBEnum.CATEGORY.name);sb.append(" ASC ");

		sb.append(" limit ");
		sb.append("?");
		//sb.append(pageSize);
		sb.append(" offset ");
		sb.append("?");
		//sb.append(offset);

		queries.add(sb.toString());
		queries.add("SELECT FOUND_ROWS() as categoryCount");

		return queries;		
	}
	private String mListDefaultCategories(){
		StringBuilder sb = new StringBuilder();
		sb.append("Select * ");
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.category);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.TABLE_NAMES.category);
		sb.append(".");
		sb.append(PortalDBEnum.CATEGORY.catStatus);
		sb.append(" != ");
		sb.append(Status.DELETED.ordinal());
		sb.append(" AND ");
		sb.append(PortalDBEnum.TABLE_NAMES.category);
		sb.append(".");
		sb.append(PortalDBEnum.CATEGORY.type);
		sb.append(" = true");
		sb.append(" ORDER BY ");
		sb.append(PortalDBEnum.CATEGORY.name);sb.append(" ASC ");

		return sb.toString();
	}
	private String mSuggestedCategories(){

		StringBuilder sb = new StringBuilder();
		sb.append("Select *, (select Count(*) FROM ");
		//SubQuery for getting total count of category without deleted status.
		sb.append(PortalDBEnum.TABLE_NAMES.category);
		sb.append(" as cat  WHERE ");
		sb.append(" cat.");
		sb.append(PortalDBEnum.CATEGORY.catStatus);
		sb.append(" != ");
		sb.append(Status.DELETED.ordinal());
		sb.append(") AS categoryCount ");

		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.category);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.TABLE_NAMES.category);
		sb.append(".");
		sb.append(PortalDBEnum.CATEGORY.catStatus);
		sb.append(" != ");
		sb.append(Status.DELETED.ordinal());
		sb.append(" AND ");
		sb.append(PortalDBEnum.TABLE_NAMES.category);
		sb.append(".");
		sb.append(PortalDBEnum.CATEGORY.name);
		sb.append(" like ");
		sb.append("?");
		//sb.append(dbCon.formatString(searchText+"%"));
		sb.append(" ORDER BY ");
		sb.append(PortalDBEnum.CATEGORY.name);sb.append(" ASC ");
		return sb.toString();
	}
}
