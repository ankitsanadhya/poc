/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mwp.common.StringFunctions;
import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.common.enums.Operator;
import com.mwp.common.enums.Status;
import com.mwp.common.enums.StatusEnum.VERSION_STATUS;
import com.mwp.common.vo.FilterObject;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.common.enums.PortalDBEnum.APPLICATION_VERSIONS;

/**
 * This class manage application, delete, list application, list project application,
 * search application according to filters(via- category, sort, search text, size) 
 * @author root
 *
 */
public class ApplicationsDB {

	/**
	 * This method gives all applications using paging and 
	 * filters (category, sort, search text, start with, start end, etc.).
	 * @param pageNo
	 * @param pageSize
	 * @param filters
	 * @return
	 */
	public List<String> searchApps(List<FilterObject> filters,boolean toListAllApps) {
		return mSearchApps(filters, toListAllApps);
	}

	/**
	 * list application using search text.
	 * @param searchText
	 * @return
	 */
	public String listApp() {
		return mListApp();
	}

	/**
	 * list project application according to given projectId.
	 * @param projectId
	 * @param userId   // add User Id if same user came for listing request.
	 * @return
	 */
	public String listProjectApp() {
		return mListProjectApps();
	}

	/**
	 * list project application accoprding to given projectId  (if it is empty then list application according to status).
	 * @param projectId
	 * @return
	 */

	public String listofAppsOfDeleteProject(String projectId)
	{
		return mlistAppsOfDeleteProject(projectId);
	}
	
	/**
	 * This method gives query for basic application detail without any status check,
	 * according to appId param.
	 * @param appId
	 * @return ApplicationVO object.
	 */
	public String getApplicationBasicDetail(){
		return mGetApplicationBasicDetail();
	}
	

	
	/**
	 * delete application change application status - DELETED in db.
	 * @param appId
	 * @param userId   // add User Id if same user came for delete request.
	 * @return
	 */
	public String deleteApplication() {
		return mDeleteApplication();
	}

	/**
	 * add User Id if same user came for delete request.
	 * @param userId
	 * @return
	 */
	public String listApplicationOfUser() {
		return mListApplicationOfUser();
	}

	/**
	 * This method give query for getting secretKey from db,
	 * using applicationId and userId. 
	 * @param appId
	 * @param userId
	 * @return query string.
	 */
	public String getSecretKey() {
		return mGetSecretKey();
	}
	/**
	 * This method give query string for getting userId of application,
	 * which is saved in db when app created.
	 * @param appId
	 * @return userId of application.
	 * @throws SQLException
	 */
	public String getUserIdOfApp() {
		return mGetUserIdOfApp();
	}

	private String mGetUserIdOfApp() {
		StringBuilder sb = new StringBuilder();
		sb.append("Select ");sb.append(PortalDBEnum.APPLICATION.userId);
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.application);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.APPLICATION.appId);sb.append(" = ");sb.append("?");
		sb.append(" AND ");
		sb.append(PortalDBEnum.APPLICATION.appStatus);sb.append(" != ");sb.append(Status.DELETED.ordinal());
		return sb.toString();
	}

	/**
	 * This method gives query to find appVersion and userId from appVersionId
	 * @param appVersionId versionId
	 * @return
	 */
	public String getAppVersionAndUserIdOfApp() {
		return mGetAppVersionAndUserIdOfApp();
	}

	/**
	 *  This method give query for check update(if return a result set then update is available otherwise not. )
	 * @param appVersionId
	 * @return
	 */
	public String checkUpdate() {

		return mCheckUpdate();
	}

	/**
	 *  This method give query of list application version of Owner or invitee.
	 * @param appId application id of application.
	 * @param appVersionId version Id of application.
	 * @param isOwner true if appUserid is equal to loggedinUserId otherwise false.
	 * @return query string
	 */
	public String listAppVersion(boolean isOwner, String appPlatformId, List<VERSION_STATUS> filterVersionStatus) {

		return mListAppVersion(isOwner, appPlatformId, filterVersionStatus);
	}

	/**
	 * delete application from DB.(if projectid is given then Check for projectId else check form Status).
	 * @param projectId is optional
	 * @return
	 */

	public String deleteAppsFromDb(String projectId)
	{
		return mDeleteAppsFromDb(projectId);
	}

	private String mGetAppVersionAndUserIdOfApp() {
		//SELECT appVersion from  applicationversions WHERE appVersionId='50633c68d32d41078bd039ad9ac1246b'
		StringBuilder sb = new StringBuilder();
		sb.append("Select appVersion.appVersion, ");
		sb.append("appVersion.").append(APPLICATION_VERSIONS.appPlatformId.name())
		.append(",")
		.append("app.");
		sb.append(PortalDBEnum.APPLICATION.userId);
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(" AS appVersion ");
		sb.append(" JOIN ");
		sb.append(PortalDBEnum.TABLE_NAMES.application);sb.append(" AS app ");
		sb.append(" ON ");sb.append(" app.");sb.append(PortalDBEnum.APPLICATION.appId);
		sb.append(" = ");
		sb.append(" appVersion.");sb.append(PortalDBEnum.APPLICATION_VERSIONS.appId);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.APPLICATION_VERSIONS.appVersionId);sb.append(" = ");sb.append("?");
		return sb.toString();
	}
	
	public static void main(String[] args) {
		
	}

	/**
	 * This method give query for getting secretKey from db,
	 * using applicationId and userId. 
	 * @param appId
	 * @param userId
	 * @return query string.
	 */
	private String mGetSecretKey() {
		StringBuilder sb = new StringBuilder();
		sb.append("Select ");sb.append(PortalDBEnum.APPLICATION.secretKey);
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.application);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.APPLICATION.appId);sb.append(" = ");sb.append("?");
		sb.append(" AND ");
		sb.append(PortalDBEnum.APPLICATION.userId);sb.append(" = ");sb.append("?");
		return sb.toString();
	}

	private List<String> mSearchApps(List<FilterObject> filters,boolean toListAllApp) {
		List<String> queries = new ArrayList<>();
		//int offset = (pageNo-1) * pageSize;
		StringBuilder query = new StringBuilder();
		query.append("SELECT SQL_CALC_FOUND_ROWS ");
		query.append(PortalDBEnum.TABLE_NAMES.application);
		query.append(".*");//Get all columns from application table.


		query.append(" FROM ");
		query.append(PortalDBEnum.TABLE_NAMES.application);

		StringBuilder sortOrder = null;
		StringBuilder joinCategories = null;
		StringBuilder whereClause = null;
		String searchString = "";
		SqlQueryBuilder builder = null;
		if(filters!=null){
			for (FilterObject filterObject : filters) {
				switch (filterObject.getFilterType()) {
				case CATEGORY:
					//if there are multiple categories in filters then AND condition in join will be "IN" otherwise it will be "="
					//So if filter type is category then value type must be multiple.

					joinCategories = new StringBuilder();
					joinCategories .append(" JOIN ");
					joinCategories .append(PortalDBEnum.TABLE_NAMES.applicationcategories);
					joinCategories .append(" ON (");
					joinCategories .append(PortalDBEnum.TABLE_NAMES.application);
					joinCategories .append(".");
					joinCategories .append(PortalDBEnum.APPLICATION.appId);
					joinCategories .append(" = ");
					joinCategories .append(PortalDBEnum.TABLE_NAMES.applicationcategories);
					joinCategories .append(".");
					joinCategories .append(PortalDBEnum.APPLICATION_CATEGORIES.appId);
					joinCategories .append(" AND ");
					joinCategories .append(PortalDBEnum.TABLE_NAMES.applicationcategories);
					joinCategories .append(".");
					joinCategories .append(PortalDBEnum.APPLICATION_CATEGORIES.catId);
					if(filterObject.getValues().size()>1){
						builder = new SqlQueryBuilder();
						builder.appendQueryIN(filterObject.getValues());
						joinCategories .append(builder.getQuery().toString());
						//joinCategories .append(" IN ( ");
						//joinCategories.append("?");
						//joinCategories.append(PortalDatabaseEngine.getInstance().getConnection().formatStringForIn(filterObject.getValues()));
						//joinCategories.append(")");
					}
					else{
						joinCategories .append(" = ");
						joinCategories.append("?");
						//joinCategories .append(PortalDatabaseEngine.getInstance().getConnection().formatString(filterObject.getValues().get(0)));	
					}

					joinCategories .append(")");
					break;
				case FILTER:
					whereClause = getWhereClause(whereClause);
					switch(filterObject.getStartValue().trim()){
					/*
					 * Added new Filter on application 
					 * "Free" - according to price which have price = 0.
					 * "Paid" - according to price which have price > 0.
					 * "4 stars and above" - according to rating which have rating >= 4.
					 * "3 stars and above" - according to rating which have rating >= 3.
					 */
					case "1"://"Free"
						whereClause.append("(");
						whereClause.append(PortalDBEnum.TABLE_NAMES.application);
						whereClause.append(".");
						whereClause.append(PortalDBEnum.APPLICATION.price);
						whereClause.append(" = 0");
						whereClause.append(" OR ");
						whereClause.append(PortalDBEnum.TABLE_NAMES.application);
						whereClause.append(".");
						whereClause.append(PortalDBEnum.APPLICATION.price);
						whereClause.append(" IS NULL");
						whereClause.append(")");
						break;
					case "2"://"Paid"
						whereClause.append(PortalDBEnum.TABLE_NAMES.application);
						whereClause.append(".");
						whereClause.append(PortalDBEnum.APPLICATION.price);
						whereClause.append(" > 0");
						break;
					case "3"://"4 stars and above"
						whereClause.append(PortalDBEnum.TABLE_NAMES.application);
						whereClause.append(".");
						whereClause.append(PortalDBEnum.APPLICATION.rating);
						whereClause.append(" >= 4");
						break;
					case "4"://"3 stars and above"
						whereClause.append(PortalDBEnum.TABLE_NAMES.application);
						whereClause.append(".");
						whereClause.append(PortalDBEnum.APPLICATION.rating);
						whereClause.append(" >= 3");
						break;
					case "status":
						whereClause.append(PortalDBEnum.TABLE_NAMES.application);
						whereClause.append(".");
						whereClause.append(PortalDBEnum.APPLICATION.appStatus);
						//whereClause.append(" IN (");
						List<Integer> lstStatus = new ArrayList<>();
						for (String appStatus : filterObject.getValues()) {
							lstStatus.add(Status.valueOf(appStatus).ordinal());
						}
						
						builder = new SqlQueryBuilder();
						builder.appendQueryIN(lstStatus);
						whereClause.append(builder.getQuery().toString());
						
						//whereClause.append("?");
						//whereClause.append(PortalDatabaseEngine.getInstance().getConnection().formatIntForIn(lstStatus));
						//whereClause.append(") ");
						break;
					case "appType":
						whereClause.append(PortalDBEnum.TABLE_NAMES.application);
						whereClause.append(".");
						whereClause.append(PortalDBEnum.APPLICATION.appTypeId);
						
						builder = new SqlQueryBuilder();
						builder.appendQueryIN(filterObject.getValues());
						whereClause.append(builder.getQuery().toString());
						
						//whereClause.append(" IN (");
						//whereClause.append("?");
						//whereClause.append(PortalDatabaseEngine.getInstance().getConnection().formatStringForIn(filterObject.getValues()));
						//whereClause.append(") ");
						break;
						default:
						break;
						
					}
					break;
				case SEARCHTEXT: // This case will be called only once in the loop as there can only be one search string and that will apply on application title. 

					whereClause = getWhereClause(whereClause);
					whereClause.append(PortalDBEnum.TABLE_NAMES.application);
					whereClause.append(".");
					whereClause.append(PortalDBEnum.APPLICATION.title);

					if(filterObject.getOperator().ordinal()== Operator.LIKE.ordinal()){
						//application title contains search text
						searchString = filterObject.getStartValue();
						whereClause.append(" LIKE ");
						whereClause.append("?");
						//whereClause.append(PortalDatabaseEngine.getInstance().getConnection().formatStringForLike(true,searchString , true));						
					}else if(filterObject.getOperator().ordinal()== Operator.EQUAL.ordinal()) {
						whereClause.append(" = ");
						whereClause.append("?");
						//whereClause.append(PortalDatabaseEngine.getInstance().getConnection().formatString(filterObject.getStartValue()));
					}

					break;
				case SORT: //This case is called once as there can only be one sort order applied. Filter object should give sort field to sort on in start value and sort order in operator.  
					sortOrder = new StringBuilder();
					sortOrder.append(" ORDER BY ");
					switch(filterObject.getStartValue().trim()){
					case "title":
						//Here assuming that we will always add search filter before the sort filter.
						if(searchString.equals("")){
							sortOrder.append(PortalDBEnum.TABLE_NAMES.application);
							sortOrder.append(".");
							sortOrder.append(PortalDBEnum.APPLICATION.title);
						}
						else{
							//sort by best match : Exact equals first then starts with, then contains and then ends with.
							sortOrder.append(" CASE WHEN ");
							sortOrder.append(PortalDBEnum.TABLE_NAMES.application);
							sortOrder.append(".");
							sortOrder.append(PortalDBEnum.APPLICATION.title);
							sortOrder.append(" = ");
							sortOrder.append("?");
							//sortOrder.append(PortalDatabaseEngine.getInstance().getConnection().formatString(searchString));
							sortOrder.append(" THEN 0 ");

							sortOrder.append(" WHEN ");
							sortOrder.append(PortalDBEnum.TABLE_NAMES.application);
							sortOrder.append(".");
							sortOrder.append(PortalDBEnum.APPLICATION.title);
							sortOrder.append(" LIKE ");
							sortOrder.append("?");
							//sortOrder.append(PortalDatabaseEngine.getInstance().getConnection().formatStringForLike(false, searchString, true));
							sortOrder.append(" THEN 1 ");

							sortOrder.append(" WHEN ");
							sortOrder.append(PortalDBEnum.TABLE_NAMES.application);
							sortOrder.append(".");
							sortOrder.append(PortalDBEnum.APPLICATION.title);
							sortOrder.append(" LIKE ");
							sortOrder.append("?");
							//sortOrder.append(PortalDatabaseEngine.getInstance().getConnection().formatStringForLike(true, searchString, false));
							sortOrder.append(" THEN 3 ");

							sortOrder.append(" ELSE 2 ");

							sortOrder.append(" END ");
							sortOrder.append(" , ");
							sortOrder.append(PortalDBEnum.TABLE_NAMES.application);
							sortOrder.append(".");
							sortOrder.append(PortalDBEnum.APPLICATION.title);
						}						
						break;
						/*
						 * Added new sorting on application 
						 * "Latest first" - according to createdDate in desc order.
						 * "Most popular" - according to rating in desc order.
						 * "Low to High" - according to price '0'/FREE is on first asc order.
						 * "High to Low" - according to price MAX price is on first desc order.
						 */
					case "1"://"Low to High"
						sortOrder.append(PortalDBEnum.TABLE_NAMES.application);
						sortOrder.append(".");
						sortOrder.append(PortalDBEnum.APPLICATION.price);
						filterObject.setOperator(Operator.ASC);
						break;
					case "2"://"High to Low"
						sortOrder.append(PortalDBEnum.TABLE_NAMES.application);
						sortOrder.append(".");
						sortOrder.append(PortalDBEnum.APPLICATION.price);
						filterObject.setOperator(Operator.DESC);
						break;
					case "3"://"Most popular"
						sortOrder.append(PortalDBEnum.TABLE_NAMES.application);
						sortOrder.append(".");
						sortOrder.append(PortalDBEnum.APPLICATION.rating);
						filterObject.setOperator(Operator.DESC);
						break;
					case "4"://"Latest first"
						sortOrder.append(PortalDBEnum.TABLE_NAMES.application);
						sortOrder.append(".");
						sortOrder.append(PortalDBEnum.APPLICATION.createdDate);
						filterObject.setOperator(Operator.DESC);
						break;
					case "status":
						sortOrder.append(PortalDBEnum.TABLE_NAMES.application);
						sortOrder.append(".");
						sortOrder.append(PortalDBEnum.APPLICATION.appStatus);
						break;
					case "creationTime":
						sortOrder.append(PortalDBEnum.TABLE_NAMES.application);
						sortOrder.append(".");
						sortOrder.append(PortalDBEnum.APPLICATION.createdDate);
						break;
					default:
						break;
					}
					if(filterObject.getOperator().ordinal()==Operator.DESC.ordinal()){
						sortOrder.append(" DESC");
					}
					break;
				
				default:
					break;
				}
			}
		}

		//Add application status check - return apps which are njot marked as deleted.
		if(!toListAllApp)
		{
			whereClause = getWhereClause(whereClause);
			whereClause.append(PortalDBEnum.TABLE_NAMES.application);
			whereClause.append(".");
			whereClause.append(PortalDBEnum.APPLICATION.appStatus);
			whereClause.append(" = ");
			whereClause.append(Status.PUBLISHED.ordinal());//Only published apps should be listed
		}

		//join with categories table if filter on categories applied. 
		if(joinCategories != null){
			query.append(joinCategories);
		}
		//Add where conditions
		if(whereClause != null)
			query.append(whereClause);

		//Add sort order
		if(sortOrder != null){
			query.append(sortOrder);
		}

		//Add paging 
		query.append(" limit ");
		query.append("?");
		//query.append(pageSize);
		query.append(" offset ");
		query.append("?");
		//query.append(offset);

		queries.add(query.toString());
		queries.add("SELECT FOUND_ROWS() as rowCount");
		return queries;
	}



	private StringBuilder getWhereClause(StringBuilder whereClause){
		if(whereClause == null){
			whereClause = new StringBuilder();
			whereClause.append(" WHERE ");						
		}
		else{
			whereClause.append(" AND ");
		}
		return whereClause;			
	}

	private String mListApp() {
		StringBuilder sb = new StringBuilder();
		sb.append("Select *");
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.application);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.TABLE_NAMES.application);
		sb.append(".");
		sb.append(PortalDBEnum.APPLICATION.appStatus);
		sb.append(" = ");
		sb.append(Status.PUBLISHED.ordinal()); //Only published apps should be listed
		sb.append(" AND ");
		sb.append(PortalDBEnum.TABLE_NAMES.application);
		sb.append(".");
		sb.append(PortalDBEnum.APPLICATION.title);
		sb.append(" like ");
		sb.append("?");
		//sb.append(PortalDatabaseEngine.getInstance().getConnection().formatString(searchText+"%"));
		return sb.toString();
	}

	// add User Id if same user came for listing request.
	private String mListProjectApps() {
		StringBuilder sb = new StringBuilder();
		sb.append("Select a.* ");
		sb.append(", appplatform." + PortalDBEnum.APPLICATION_PLATFORM.appPlatformId);
		sb.append(", appplatform." + PortalDBEnum.APPLICATION_PLATFORM.platformId);
		sb.append(", appplatform." + PortalDBEnum.APPLICATION_PLATFORM.repositoryName);
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.application);
		sb.append(" as a ");
		sb.append(" LEFT JOIN ");
		sb.append(PortalDBEnum.TABLE_NAMES.applicationplatform);
		sb.append(" AS appplatform ON appplatform.");
		sb.append(PortalDBEnum.APPLICATION_PLATFORM.appId);
		sb.append(" = a.");
		sb.append(PortalDBEnum.APPLICATION.appId);
		sb.append(" WHERE ");
		sb.append("a.");
		sb.append(PortalDBEnum.APPLICATION.appStatus);
		sb.append(" != ");
		sb.append(Status.DELETED.ordinal());
		sb.append(" AND ");
		sb.append("a.");
		sb.append(PortalDBEnum.APPLICATION.projectId);
		sb.append(" = ");
		sb.append("?");
		//sb.append(PortalDatabaseEngine.getInstance().getConnection().formatString(projectId));
		sb.append(" AND ");
		sb.append("a.");
		sb.append(PortalDBEnum.APPLICATION.userId);
		sb.append(" = ");
		sb.append("?");
//		sb.append(PortalDatabaseEngine.getInstance().getConnection().formatString(userId));
		sb.append(" ORDER BY ");
		sb.append(PortalDBEnum.APPLICATION.title);
		sb.append(" ASC ");
		return sb.toString();
	}

	// list project application according to given projectId  (if it is empty then list application according to status).
	private String mlistAppsOfDeleteProject(String projectId) {
		StringBuilder sb = new StringBuilder();
		sb.append("Select a.* ");
		sb.append(", appplatform." + PortalDBEnum.APPLICATION_PLATFORM.appPlatformId);
		sb.append(", appplatform." + PortalDBEnum.APPLICATION_PLATFORM.platformId);
		sb.append(", appplatform." + PortalDBEnum.APPLICATION_PLATFORM.repositoryName);
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.application);
		sb.append(" as a ");
		sb.append(" LEFT JOIN ");
		sb.append(PortalDBEnum.TABLE_NAMES.applicationplatform);
		sb.append(" AS appplatform ON appplatform.");
		sb.append(PortalDBEnum.APPLICATION_PLATFORM.appId);
		sb.append(" = a.");
		sb.append(PortalDBEnum.APPLICATION.appId);
		sb.append(" WHERE ");
		sb.append("a.");
		sb.append(PortalDBEnum.APPLICATION.appStatus);
		sb.append(" = ");
		sb.append(Status.DELETED.ordinal());
		if (!StringFunctions.isNullOrWhitespace(projectId)) {
			sb.append(" AND ");
			sb.append("a.");
			sb.append(PortalDBEnum.APPLICATION.projectId);
			sb.append(" = ");
			sb.append("?");
//			sb.append(PortalDatabaseEngine.getInstance().getConnection().formatString(projectId));
		}
		return sb.toString();
	}
	
	private String mGetApplicationBasicDetail() {
		StringBuilder sb = new StringBuilder();
		sb.append("Select app.* ");
		sb.append(", appplatform." + PortalDBEnum.APPLICATION_PLATFORM.appPlatformId);
		sb.append(", appplatform." + PortalDBEnum.APPLICATION_PLATFORM.platformId);
		sb.append(", appplatform." + PortalDBEnum.APPLICATION_PLATFORM.repositoryName);
		sb.append(" FROM ");sb.append(PortalDBEnum.TABLE_NAMES.application);sb.append(" AS app ");
		sb.append(" LEFT JOIN ");
		sb.append(PortalDBEnum.TABLE_NAMES.applicationplatform);sb.append(" AS appplatform ON appplatform.");
		sb.append(PortalDBEnum.APPLICATION_PLATFORM.appId);
		sb.append(" = app.");sb.append(PortalDBEnum.APPLICATION.appId);
		sb.append(" WHERE app.");
		sb.append(PortalDBEnum.APPLICATION.appId);sb.append(" = ");sb.append("?");
		return sb.toString();
	}
	
	// add User Id if same user came for delete request.
	private String mDeleteApplication() {
		StringBuilder sb = new StringBuilder();
		sb.append("UPDATE ");
		sb.append(PortalDBEnum.TABLE_NAMES.application);
		sb.append(" SET ");


		sb.append(PortalDBEnum.APPLICATION.appStatus.name());
		sb.append(" = ");
		sb.append(Status.DELETED.ordinal());
		sb.append(", ");


		sb.append(PortalDBEnum.APPLICATION.modifiedDate.name());
		sb.append(" = NOW()");

		sb.append(" WHERE ");
		sb.append(PortalDBEnum.APPLICATION.appId.name());
		sb.append(" = ");
		sb.append("?");
		sb.append(" AND ");
		sb.append(PortalDBEnum.APPLICATION.userId.name());
		sb.append(" = ");
		sb.append("?");
		return sb.toString();
	}

	private String mListApplicationOfUser() {
		StringBuilder sb = new StringBuilder();
		sb.append("Select a.* ");
		sb.append(", appplatform." + PortalDBEnum.APPLICATION_PLATFORM.appPlatformId);
		sb.append(", appplatform." + PortalDBEnum.APPLICATION_PLATFORM.platformId);
		sb.append(", appplatform." + PortalDBEnum.APPLICATION_PLATFORM.repositoryName);
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.application);sb.append(" as a ");
		sb.append(" LEFT JOIN ");sb.append(PortalDBEnum.TABLE_NAMES.applicationplatform);sb.append(" AS appplatform ON appplatform.");sb.append(PortalDBEnum.APPLICATION_PLATFORM.appId);
		sb.append(" = a.");sb.append(PortalDBEnum.APPLICATION.appId);
		sb.append(" WHERE ");
		sb.append(" a.");sb.append(PortalDBEnum.APPLICATION.appStatus);
		sb.append(" != ");
		sb.append(Status.DELETED.ordinal());
		sb.append(" AND ");
		sb.append(" a.");sb.append(PortalDBEnum.APPLICATION.userId);
		sb.append(" = ");
		sb.append("?");
		return sb.toString();
	}

	private String mCheckUpdate() {
		StringBuilder sb = new StringBuilder();
		sb.append("Select appVersion");
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.APPLICATION_VERSIONS.appVersionId);
		sb.append(" = ");
		sb.append("?");
		sb.append(" AND ");
		sb.append(PortalDBEnum.APPLICATION_VERSIONS.versionStatus);
		sb.append(" != ");
		sb.append(VERSION_STATUS.LIVE.ordinal());

		return sb.toString();
	}

	private String mListAppVersion(boolean isOwner, String appPlatformId,
			List<VERSION_STATUS> filterVersionStatus) {
		List<Integer> lstVersionStatus = new ArrayList<>();
		for (VERSION_STATUS version_STATUS : filterVersionStatus) {
			lstVersionStatus.add(version_STATUS.ordinal());
		}
		
		SqlQueryBuilder queryBuilder = new SqlQueryBuilder();
		
		if (!isOwner) {
			queryBuilder.appendQuery("Select * FROM ");
			queryBuilder.appendQuery(PortalDBEnum.TABLE_NAMES.applicationversions);
			queryBuilder.appendQuery(" as a1, ");
			queryBuilder.appendQuery(" (SELECT a.groupId, a.appId, b.appVersionId");
			queryBuilder.appendQuery(" FROM ");
			queryBuilder.appendQuery(PortalDBEnum.TABLE_NAMES.groupapplications);
			queryBuilder.appendQuery(" a ");
			queryBuilder.appendQuery("LEFT JOIN ");
			queryBuilder.appendQuery(PortalDBEnum.TABLE_NAMES.groupapplicationversions);
			queryBuilder.appendQuery(" b ON a.groupAppId");
			queryBuilder.appendQuery(" = ");
			queryBuilder.appendQuery(" b.groupAppId");
			queryBuilder.appendQuery(" WHERE ");
			queryBuilder.appendQuery(" a.appId ");
			queryBuilder.appendQuery(" = ");
			queryBuilder.appendQuery("?");
//			queryBuilder.appendQuery(dbCon.formatString(appId));
			queryBuilder.appendQuery(" AND ");
			queryBuilder.appendQuery(" b.appVersionId is not null  ");
			queryBuilder.appendQuery(" UNION ");
			queryBuilder.appendQuery(" SELECT b.groupId,b.appId,a.appVersionId ");
			queryBuilder.appendQuery(" FROM ");
			queryBuilder.appendQuery(PortalDBEnum.TABLE_NAMES.applicationversions);
			queryBuilder.appendQuery(" a, (SELECT a.groupId, a.appId, b.appVersionId");
			queryBuilder.appendQuery(" FROM ");
			queryBuilder.appendQuery(PortalDBEnum.TABLE_NAMES.groupapplications);
			queryBuilder.appendQuery(" a LEFT JOIN ");
			queryBuilder.appendQuery(PortalDBEnum.TABLE_NAMES.groupapplicationversions);
			queryBuilder.appendQuery(" b ON a.groupAppId");
			queryBuilder.appendQuery(" = ");
			queryBuilder.appendQuery(" b.groupAppId");
			queryBuilder.appendQuery(" WHERE ");
			queryBuilder.appendQuery(" a.appId ");
			queryBuilder.appendQuery(" = ");
			queryBuilder.appendQuery("?");
//			queryBuilder.appendQuery(dbCon.formatString(appId));
			queryBuilder.appendQuery(" AND ");
			queryBuilder.appendQuery(" b.appVersionId is null ) as b  ");
			queryBuilder.appendQuery(" WHERE ");
			queryBuilder.appendQuery(" a.appId ");
			queryBuilder.appendQuery(" = ");
			queryBuilder.appendQuery(" b.appId) as b1");
			queryBuilder.appendQuery(" WHERE ");
			queryBuilder.appendQuery(" a1.appVersionId ");
			queryBuilder.appendQuery(" = ");
			queryBuilder.appendQuery(" b1.appVersionId ");
			queryBuilder.appendQuery(" AND ");
			queryBuilder.appendQuery(PortalDBEnum.APPLICATION_VERSIONS.versionStatus);
			
			queryBuilder.appendQueryIN(filterVersionStatus);
			
//			queryBuilder.appendQuery(" IN (");
//			queryBuilder.appendQuery(dbCon.formatIntForIn(lstVersionStatus));
//			queryBuilder.appendQuery(")");
			if (!StringFunctions.isNullOrWhitespace(appPlatformId)) {
				queryBuilder.appendQuery(" AND ");
				queryBuilder.appendQuery(PortalDBEnum.APPLICATION_VERSIONS.appPlatformId);
				queryBuilder.appendQuery(" = ");
				queryBuilder.appendQuery("?");
//				queryBuilder.appendQuery(dbCon.formatString(appPlatformId));
			}
			queryBuilder.appendQuery(" AND ");
			queryBuilder.appendQuery(" a1.");
			queryBuilder.appendQuery(PortalDBEnum.APPLICATION_VERSIONS.createdDate);
			queryBuilder.appendQuery(" > ");
			queryBuilder.appendQuery("(SELECT createdDate from applicationversions where appVersionId = ");
			queryBuilder.appendQuery("?");
//			queryBuilder.appendQuery(dbCon.formatString(appVersion));
			queryBuilder.appendQuery(")");
			queryBuilder.appendQuery(" ORDER BY a1.createdDate DESC");
		} else {
			queryBuilder.appendQuery("Select * FROM ");
			queryBuilder.appendQuery(PortalDBEnum.TABLE_NAMES.applicationversions);
			queryBuilder.appendQuery(" WHERE ");
			queryBuilder.appendQuery(" appId ");
			queryBuilder.appendQuery(" = ");
			queryBuilder.appendQuery("?");
//			queryBuilder.appendQuery(dbCon.formatString(appId));
			queryBuilder.appendQuery(" AND ");
			queryBuilder.appendQuery(PortalDBEnum.APPLICATION_VERSIONS.versionStatus);
			queryBuilder.appendQueryIN(lstVersionStatus);
//			queryBuilder.appendQuery(" IN (");
//			queryBuilder.appendQuery(dbCon.formatIntForIn(lstVersionStatus));
//			queryBuilder.appendQuery(")");

			if (!StringFunctions.isNullOrWhitespace(appPlatformId)) {
				queryBuilder.appendQuery(" AND ");
				queryBuilder.appendQuery(PortalDBEnum.APPLICATION_VERSIONS.appPlatformId);
				queryBuilder.appendQuery(" = ");
				queryBuilder.appendQuery("?");
//				queryBuilder.appendQuery(dbCon.formatString(appPlatformId));
			}
			queryBuilder.appendQuery(" AND ");
			queryBuilder.appendQuery(PortalDBEnum.APPLICATION_VERSIONS.createdDate);
			queryBuilder.appendQuery(" > ");
			queryBuilder.appendQuery("(SELECT createdDate from applicationversions where appVersionId = ");
			queryBuilder.appendQuery("?");
//			queryBuilder.appendQuery(dbCon.formatString(appVersion));
			queryBuilder.appendQuery(")");
			queryBuilder.appendQuery(" ORDER BY createdDate DESC");
		}
		return queryBuilder.getQuery().toString();
	}

	private String mDeleteAppsFromDb(String projectId)
	{
		StringBuilder sb=new StringBuilder();
		sb.append("DELETE FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.application);
		sb.append(" WHERE ");
		// 
		if(!StringFunctions.isNullOrWhitespace(projectId))
		{
			sb.append(PortalDBEnum.APPLICATION.projectId);
			sb.append(" = ");
			sb.append("?");
//			sb.append(PortalDatabaseEngine.getInstance().getConnection().formatString(projectId));
		}
		else
		{
			sb.append(PortalDBEnum.APPLICATION.appStatus);
			sb.append(" = ");
			sb.append(Status.DELETED.ordinal());
		}
		return sb.toString();
	}
	public String getCount()
	{
		return mGetCount();
	}
	private String mGetCount()
	{
		StringBuilder qry= new StringBuilder("SELECT count(*) as count, ");
		qry.append(PortalDBEnum.APPLICATION.appStatus.name());
		qry.append(" FROM  "); 
		qry.append(PortalDBEnum.TABLE_NAMES.application );
		qry.append(" GROUP BY " );
		qry.append(PortalDBEnum.APPLICATION.appStatus.name());
		return qry.toString();
	}
}