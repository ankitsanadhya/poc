/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal.engine;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.common.constant.Constant;
import com.mwp.common.vo.LabelVO;
import com.mwp.common.vo.QueryVO;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.dal.LabelDB;

/**
 * This class manages labels hierarchy for devices 
 */
public class LabelEngine 
{
	//	************************************ PUBLIC METHODS *****************************************

	/**
	 * List all labels hierarchy of user.
	 * @param userId
	 * @param parentLabelId
	 * @return List<LabelVO> 
	 * @throws Exception
	 */
	public List<LabelVO> listLabels(String userId) throws SQLException {
		return this.mListLabels(userId);
	}

	/**
	 * Add root label for a user with id 0 ,  label name "All Appliances" , and parent label id as -1
	 * @param userId
	 * @return
	 * @throws Exception
	 */
	public LabelVO addRoot(String userId) throws SQLException
	{
		LabelVO labelRoot = new LabelVO(Constant.ROOT_LABEL_ID, Constant.ROOT_LABEL_NAME, Constant.ROOT_PARENT_LABEL_ID, userId);
		return mAddLabel(labelRoot, false);		
	}

	/**
	 * add new label 
	 * @param labelVO
	 * @return
	 * @throws Exception
	 */
	public LabelVO addLabel(LabelVO labelVO) throws SQLException
	{
		return this.mAddLabel(labelVO, true);		
	}

	/**
	 * Edit existing label name
	 * @param labelVO
	 * @return
	 * @throws Exception "edit label failed." if not label exists 
	 */
	public LabelVO editLabel(LabelVO labelVO) throws SQLException
	{	
		return this.mEditLabel(labelVO);		
	}

	/**
	 * This method will delete all labels that belong to this label id and shift all the child devices in root.The devices in labels will be shift on root label.    
	 * @param labelId
	 * @return
	 * @throws Exception
	 */
	public void deleteLabelRecursive(String labelId, String userId) throws SQLException
	{
		List<String> lstLabelsToDelete = new ArrayList<>();
		new LabelEngine().mDeleteLabel(labelId, userId, lstLabelsToDelete);
		List<String> queries = new LabelDB().deleteLabel(lstLabelsToDelete.size());
		
		List<QueryVO> queryVOs = new LinkedList<>();
		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(queries.get(0))
				.addParameter(Constant.ROOT_LABEL_ID)
				.addParameters(lstLabelsToDelete).build();
		queryVOs.add(queryVO);
		
		 queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
					.appendQuery(queries.get(1))
					.addParameters(lstLabelsToDelete).addParameter(userId).build();
			queryVOs.add(queryVO);
			
		PortalDatabaseEngine.getInstance().getConnection().executeUpdatesInTransaction(queryVOs);
	}

	//	************************************ PRIVATE METHODS *****************************************
	
	private LabelVO mAddLabel(LabelVO labelVO, boolean checkParent) throws SQLException
	{
		int insertCount = PortalDatabaseEngine.getInstance().getConnection().executeUpdate(getAddLableQueries(labelVO, checkParent));
		if(insertCount == 0){
			throw new SQLException("add label failed.");
		}
		return labelVO;
	}
	
	private QueryVO getAddLableQueries(LabelVO labelVO, boolean checkParent) throws SQLException{
		
		String sql  = new LabelDB().addLabel(checkParent);

		List<String> parameters = new LinkedList<>();
		if (checkParent) {
			parameters.add(labelVO.getLabelId());
			parameters.add(labelVO.getLabelName());
			parameters.add(labelVO.getParentLabelId());
			parameters.add(labelVO.getUserId());
			parameters.add(labelVO.getParentLabelId());
			parameters.add(labelVO.getParentLabelId());
			parameters.add(labelVO.getLabelId());
			parameters.add(labelVO.getUserId());
		} else {
			parameters.add(labelVO.getLabelId());
			parameters.add(labelVO.getLabelName());
			parameters.add(labelVO.getParentLabelId());
			parameters.add(labelVO.getUserId());
		}
		return new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
		.appendQuery(sql)
		.addParameters(parameters).build();
	}
	
	
	
	public static void main(String[] args) throws Exception {
//		List<String> lstLabelsToDelete = new ArrayList<>();
//		new LabelEngine().mDeleteLabel("282eb4d9fc1e47c6bd93b0ab8f31446e", "97651e7c16e541f1a5deb4d1318393e4", lstLabelsToDelete);
//		List<String> queries = new LabelDB().deleteLabel(lstLabelsToDelete, "97651e7c16e541f1a5deb4d1318393e4");
//		PALogger.INFO(queries+"");
		
	}

	private void mDeleteLabel(String labelId, String userId, List<String> lstLabelsToDelete) throws SQLException
	{
		LabelDB labelDB = new LabelDB();
		String sql = labelDB.listLabelId();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(labelId).addParameter(userId).build();

		String childLabelId = null;
		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				childLabelId = rs.getString(PortalDBEnum.LABELS.labelId.name());
				mDeleteLabel(childLabelId, userId, lstLabelsToDelete);
			}
		}
		lstLabelsToDelete.add(labelId);
	}

	private List<LabelVO> mListLabels(String userId) throws SQLException {
		List<LabelVO> listLabels = new ArrayList<>();
		String sql = new LabelDB().listLabel();
		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(userId).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				LabelVO labelVO = setLabelObject(rs);
				listLabels.add(labelVO);
			}
		}
		return listLabels;
	}

	public String getRootId(String userId) throws SQLException
	{
		return mGetRootId(userId);
	}

	private String mGetRootId(String userId) throws SQLException {							
		String sql = new LabelDB().getRootId(userId);
	
		List<Object> parameters = new ArrayList<>();
		parameters.add(userId);
		parameters.add(Constant.ROOT_PARENT_LABEL_ID);

		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(sql).addParameters(parameters).build();
		
		String rootId = "";
		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)){
			while (rs.next())
			{
				rootId = rs.getString(PortalDBEnum.LABELS.labelId.name());
			}
		}
		return rootId;
	}

	private LabelVO setLabelObject(ResultSet rs) throws SQLException
	{
		LabelVO labelVO = new LabelVO();
		labelVO.setLabelId(rs.getString(PortalDBEnum.LABELS.labelId.name()));
		labelVO.setLabelName(rs.getString(PortalDBEnum.LABELS.labelName.name()));
		labelVO.setParentLabelId(rs.getString(PortalDBEnum.LABELS.parentLabelId.name()));
		labelVO.setUserId(rs.getString(PortalDBEnum.LABELS.userId.name()));		
		return labelVO;
	}

	private LabelVO mEditLabel(LabelVO labelVO) throws SQLException
	{	
		String sql = new LabelDB().editLabel();
		
		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(sql)
				.addParameter(labelVO.getLabelName())
				.addParameter(labelVO.getLabelId())
				.addParameter(labelVO.getUserId())
				.build();
		
		int insertCount = PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
		if(insertCount == 0){
			throw new SQLException("edit label failed.");
		}

		return labelVO;
	}


	
}
