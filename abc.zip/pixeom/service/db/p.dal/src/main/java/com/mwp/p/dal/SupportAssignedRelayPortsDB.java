/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal;

import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.common.enums.PortalDBEnum.SUPPORT_ASSIGNED_RELAY_PORTS;

/**
 * This class provides queries related to {@link SUPPORT_ASSIGNED_RELAY_PORTS}
 *
 */
public class SupportAssignedRelayPortsDB {

	/**
	 * Create query to get assigned relayports for device
	 * @param deviceId
	 * @return
	 */
	public String getSupportAssignedRelayPorts()
	{
		StringBuilder sb = new StringBuilder();
		sb.append("Select * ");
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.supportassignedrelayports);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.SUPPORT_ASSIGNED_RELAY_PORTS.sDeviceID);
		sb.append(" = ");
		sb.append("?");
		//sb.append(dbCon.formatString(deviceId));
		return sb.toString();
	}
	
	/**
	 * Create query to list already assigned ports for a device.
	 * nPortSegmentStart
	 * @param deviceId
	 * @param relayServerId
	 * @return
	 */
	public String getAlreadyAssignedPorts() {
		return "SELECT nPortSegmentStart FROM supportassignedrelayports WHERE sRelayServerID = "+ "?" +" AND sDeviceID = "+ "?";
	}
	
	/**
	 * Create query to get max assigned port number.
	 * @param relayServerID
	 * @return
	 */
	public String getMaxRelayPort() {
		return "SELECT MAX(nPortSegmentStart) as MaxAvailablePortSegment FROM supportassignedrelayports WHERE sRelayServerID = "+ "?";
	}
	
	/**
	 * Create query to get all available ports for relay server id.
	 * @param relayServerID
	 * @return
	 */
	public String getAvailablePorts() {
		return "SELECT sDeviceID, nPortSegmentStart FROM supportassignedrelayports "
				+ "WHERE sRelayServerID = "+ "?" +" AND nStatus != 1 ";
	}
	
	/**
	 * Delete all ports assigned to device id  
	 * @param deviceId
	 * @return
	 */
	public String deleteDeviceAssignedPorts() {
		return "DELETE FROM supportassignedrelayports WHERE sDeviceID = "+ "?";
	}
	
	/** 
	 * create query to add assigned relay ports
	 * @param deviceId
	 * @param relayServerId
	 * @param portSegmentStart
	 * @return
	 */
	public String addAssignedRelayPorts(){
		return "INSERT INTO supportassignedrelayports(sDeviceID, sRelayServerID, nPortSegmentStart, nStatus, dModified) "
				+ "VALUES ("+ "?" +","+ "?" +", "+ "?" +",1,NOW()) "
				+ "ON DUPLICATE KEY UPDATE sRelayServerID = "+ "?" +", nPortSegmentStart = "+ "?" +", "
				+ "nStatus = '1', dModified = NOW()";
	}
}
