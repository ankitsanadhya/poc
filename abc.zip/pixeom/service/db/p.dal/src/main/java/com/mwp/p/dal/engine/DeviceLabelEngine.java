/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal.engine;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.common.constant.Constant;
import com.mwp.common.vo.DeviceVO;
import com.mwp.common.vo.QueryVO;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.dal.DeviceLabelMapDB;

/**
 * This class executes the queries relatd to table devicelabelmap keeps relation between devices and labels. 
 */
public class DeviceLabelEngine {

	/**
	 * Add devices in label with label id.
	 * @param labelId label id
	 * @param deviceIds list of devices.
	 * @throws Exception
	 */
	public void addDeviceLabel(String labelId, List<String> deviceIds) throws Exception{
		mAddDeviceLabel(labelId, deviceIds);
	}
	
	/**
	 * Update device label. change device label id.
	 * @param labelId
	 * @param deviceId
	 * @return
	 * @throws Exception
	 */
	public DeviceVO updateDeviceLabel(String labelId,  String deviceId) throws SQLException{
		return this.mUpdateDeviceLabel(labelId, deviceId);  
	}
	
	/**
	 * Update label for list of devices.
	 * @param labelId label id.
	 * @param deviceIds list of devices
	 * @throws Exception
	 */
	public void updateDeviceLabel(String labelId, List<String> deviceIds) throws Exception{
		this.mMoveDeviceLabel(labelId, deviceIds);  
	}
	
	/**
	 * Delete device from label 
	 * @param deviceId
	 * @param labelId
	 * @return
	 * @throws Exception
	 */
	public boolean deleteDeviceFromLabel(String deviceId, String labelId) throws SQLException{
		return this.mDeleteDeviceFromLabel(deviceId, labelId);  
	}
	
	/**
	 * Delete label from device.
	 * @param labelId
	 * @param deviceId
	 * @throws Exception
	 */
	public void deleteDeviceLabel(String labelId, String deviceId) throws SQLException{
		mDeleteDeviceLabel(labelId, deviceId);  
	}
	
	/**
	 * List all devices associated with labels.
	 * @param labelId 
	 * @param deviceId 
	 * @return
	 * @throws Exception
	 */
	public List<DeviceVO> getDeviceFromLabel(String labelId, String userId) throws SQLException{
		return this.mGetDeviceFromLabel(labelId, userId);  
	}
	
	private void mAddDeviceLabel(String labelId, List<String> deviceIds) throws Exception{
		List<QueryVO> queries = new ArrayList<>();
		
		if(deviceIds.size() == 1 && mGetDeviceLabelExist(deviceIds.get(0), labelId)){
				throw new Exception("device already exist in existing group.");
		}
		
		DeviceLabelMapDB labelMapDB  = new DeviceLabelMapDB();
		for (String deviceId : deviceIds) {
			QueryVO queryVO = new SqlQueryBuilder(
					PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
							.appendQuery(labelMapDB.addDeviceLabel()).addParameter(labelId).addParameter(deviceId)
							.build();
			queries.add(queryVO);
		}
		PortalDatabaseEngine.getInstance().getConnection().executeUpdatesInTransaction(queries);
	}

	private DeviceVO mUpdateDeviceLabel(String labelId, String deviceId) throws SQLException {
		String sql = new DeviceLabelMapDB().updateDeviceLabel();
		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(labelId).addParameter(deviceId).build();
		int insertCount = PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
		if (insertCount == 0) {
			throw new SQLException("add device to label failed.");
		}
		DeviceVO deviceVO = new DevicesEngine().getDevice(deviceId, false);
		deviceVO.setLabelId(labelId);
		return deviceVO;
	}

	private void mMoveDeviceLabel(String labelId, List<String> deviceIds) throws Exception {

		if (deviceIds.size() == 1 && mGetDeviceLabelExist(deviceIds.get(0), labelId)) {
			throw new Exception("device already exist in existing group.");
		}
		List<QueryVO> queries = new ArrayList<>();
		DeviceLabelMapDB labelMapDB = new DeviceLabelMapDB();
		for (String deviceId : deviceIds) {
			QueryVO queryVO = new SqlQueryBuilder(
					PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
							.appendQuery(labelMapDB.deleteDeviceLabel()).addParameter(deviceId).build();

			queries.add(queryVO);
		}
		
		for (String deviceId : deviceIds) {

			QueryVO queryVO = new SqlQueryBuilder(
					PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
							.appendQuery(labelMapDB.addDeviceLabel()).addParameter(labelId).addParameter(deviceId)
							.build();

			queries.add(queryVO);
		}

		PortalDatabaseEngine.getInstance().getConnection().executeUpdatesInTransaction(queries);
	}

	private void mDeleteDeviceLabel(String labelId, String deviceId) throws SQLException{
		String sql = new DeviceLabelMapDB().deleteDeviceByLabelId();
		
		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
						.appendQuery(sql).addParameter(labelId).addParameter(deviceId)
						.build();
		
		PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
	}
	
	private boolean mDeleteDeviceFromLabel(String deviceId, String labelId) throws SQLException{
		int insertCount = 0;
		if(mGetDeviceLabel(deviceId).size() <= 1){
			//Constant.ROOT_LABEL_ID
			String sql = new DeviceLabelMapDB().updateDeviceLabel();//Add device to root
			QueryVO queryVO = new SqlQueryBuilder(
					PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
							.appendQuery(sql).addParameter(labelId).addParameter(deviceId)
							.build();
			insertCount = PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
			
		}else{
			String sql = new DeviceLabelMapDB().deleteDeviceByLabelId();
			
			QueryVO queryVO = new SqlQueryBuilder(
					PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
							.appendQuery(sql).addParameter(labelId).addParameter(deviceId)
							.build();
			insertCount = PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
		}
		if(insertCount == 0){
			throw new SQLException("delete device from label failed.");
		}
		return true;
	}

	private List<String> mGetDeviceLabel(String deviceId) throws SQLException {
		String sql = new DeviceLabelMapDB().getDeviceLabelByDeviceId();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(deviceId).build();

		List<String> lstLabel = new ArrayList<>();
		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {

				lstLabel.add(rs.getString(PortalDBEnum.LABELS.labelId.name()));
			}
		}
		return lstLabel;
	}
	
	private boolean mGetDeviceLabelExist(String deviceId, String labelId) throws SQLException{
		boolean isExist = false;
		String sql = new DeviceLabelMapDB().getDeviceLabel();

		List<Object> parameters = new ArrayList<>();
		parameters.add(deviceId);
		parameters.add(labelId);	

		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(sql).addParameters(parameters).build();

		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)){
			while (rs.next()){
				isExist = true;
			}
		}
		return isExist;
	}
	
	private ArrayList<DeviceVO> mGetDeviceFromLabel(String labelId, String userId) throws SQLException {
		String sql = new DeviceLabelMapDB().getDevicesofLabel();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(labelId).addParameter(userId).build();

		ArrayList<DeviceVO> lst = new ArrayList<>();
		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {

			lst.addAll(new DevicesEngine().setDeviceObjectList(rs, false, true, true, false, false, null));

		}
		return lst;
	}
	

	
	/**
	 * Add existing device to all the labels in labelIds.Firstly remove device from all existing labels then add with list of labels in parameters. 
	 * @param labelIds list of label ids.
	 * @param deviceId device id to be added in labels.
	 * @return true if successfully inserted false otherwise.
	 * @throws Exception
	 */
	public boolean addDeviceToLabels(List<String> labelIds, String deviceId) throws SQLException
	{
		return mAddDeviceToLabels(labelIds, deviceId);
	}
	
	private boolean mAddDeviceToLabels(List<String> labelIds, String deviceId) throws SQLException
	{
		List<String> listQueries = new DeviceLabelMapDB().addDeviceToLabels();

		List<QueryVO> queryVOs = new ArrayList<>();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
						.appendQuery(listQueries.get(0)).addParameter(deviceId).build();
		queryVOs.add(queryVO);

		if (labelIds.isEmpty()) {
			labelIds.add(Constant.ROOT_LABEL_ID);
		}

		for (String lableId : labelIds) {
			queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
					.appendQuery(listQueries.get(1)).addParameter(lableId).addParameter(deviceId).build();
			queryVOs.add(queryVO);
		}

		PortalDatabaseEngine.getInstance().getConnection().executeUpdatesInTransaction(queryVOs);
		
		return true;
	}
	
}
