/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.mwp.p.dal.engine;



import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.common.enums.SecretTypeEnum;
import com.mwp.common.vo.QueryVO;
import com.mwp.common.yamlparser.SecretVersionVO;
import com.mwp.common.yamlparser.SecretVo;
import com.mwp.p.common.enums.PortalDBEnum.APP_SECRET;
import com.mwp.p.common.enums.PortalDBEnum.APP_SECRET_VERSION;
import com.mwp.p.dal.AppSecretDB;
import com.mwp.p.dal.AppSecretVersionDB;

public class AppSecretEngine
{

	/*
	 * This method have one more param isAddSecretVO for only appSecretVersion save or secretVO.
	 */
	public SecretVo insert(SecretVo secretObj, boolean isAddSecretVO)throws Exception
	{
		return mInsert(secretObj, isAddSecretVO);
	}

	public SecretVo edit(SecretVo secretObj)throws Exception
	{
		return mEdit(secretObj);
	}

	public boolean delete(String appSecertId)throws SQLException
	{
		return mDelete(appSecertId);
	}

	/*
	 * Add method deleteAppSecretVersion using appSecretVersionId.
	 */
	public boolean deleteAppSecretVersion(String appSecertVersionId)throws SQLException
	{
		return mDeleteAppSecretVersion(appSecertVersionId);
	}

	public List<SecretVo> listByAppId(String appId)throws SQLException
	{
		return mListByAppId(appId);
	}

	public SecretVo get(String appSecretId) throws SQLException
	{
		return mGet(appSecretId);
	}

	/**
	 * this method returns app secret id if given appSecretVersionId is the only app secret version for appSecret
	 * @param appSecretVersionId
	 * @return
	 * @throws SQLException
	 */
	public String getAppSecretIdIfLastVersion(String appSecretVersionId)throws SQLException
	{
		return mGetAppSecretIdIfLastVersion(appSecretVersionId);
	}
	private SecretVo mInsert(SecretVo secretObj, boolean isAddSecretVO) throws Exception
	{
		/*
		 * Only single secretVersion object exist in list so use zeroth element displayName.
		 */
		if(isUnique(secretObj.getAppSecretId(),secretObj.getListSecretVersion().get(0).getAppSecretVersionId(),secretObj.getKey(), secretObj.getListSecretVersion().get(0).getDisplayName(), secretObj.getAppId(),isAddSecretVO))
		{
			ArrayList<QueryVO> queryVOList = new ArrayList<>();
			/*
			 * if isAddSecretVO = true then insert secret object otherwise secretVersion object add in db.
			 */
			if(isAddSecretVO){
				String query = new AppSecretDB().insert(secretObj);

				List<String> parameters = new ArrayList<>();
				parameters.add(secretObj.getAppSecretId());
				parameters.add(secretObj.getAppId());
				parameters.add(secretObj.getServiceName());
				parameters.add(secretObj.getKey());
				parameters.add(secretObj.getConfigType());

				QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
						.appendQuery(query).addParameters(parameters).build();

				queryVOList.add(queryVO);
			}
			for (SecretVersionVO svo : secretObj.getListSecretVersion()) {
				String query = new AppSecretVersionDB().insert(svo);
				List<Object> parameters = new ArrayList<>();
				parameters.add(svo.getAppSecretVersionId());
				parameters.add(svo.getAppSecretId());
				parameters.add(svo.getAppUserId());
				parameters.add(svo.getDisplayName());
				parameters.add(svo.getType().ordinal());
				parameters.add(svo.getValue());
				
				QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
						.appendQuery(query).addParameters(parameters).build();

				queryVOList.add(queryVO);
			}
			PortalDatabaseEngine.getInstance().getConnection().executeUpdatesInTransaction(queryVOList);
			return get(secretObj.getAppSecretId());
		}
		return null;
	}

	private SecretVo mEdit(SecretVo secretObj) throws Exception
	{
		/*
		 * Only single secretVersion object exist in list so use zeroth element displayName.
		 */
		if(isUnique(secretObj.getAppSecretId(),secretObj.getListSecretVersion().get(0).getAppSecretVersionId(), secretObj.getKey(), secretObj.getListSecretVersion().get(0).getDisplayName(), secretObj.getAppId(),false))
		{
			List<QueryVO> queryVOList = new ArrayList<>();

			for (SecretVersionVO svo : secretObj.getListSecretVersion()) {

				String query = new AppSecretVersionDB().edit();

				List<String> parameters = new ArrayList<>();
				parameters.add(svo.getDisplayName());
				parameters.add(svo.getValue());
				parameters.add(svo.getAppSecretVersionId());

				QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
						.appendQuery(query).addParameters(parameters).build();

				queryVOList.add(queryVO);
			}
			PortalDatabaseEngine.getInstance().getConnection().executeUpdatesInTransaction(queryVOList);
			return get(secretObj.getAppSecretId());
		}
		return null;
	}

	private boolean mDelete(String appSecertId) throws SQLException
	{
		String qry = new AppSecretDB().delete();

		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(qry).addParameter(appSecertId).build();

		return (PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO)>0);
	}

	private boolean mDeleteAppSecretVersion(String appSecertVersionId) throws SQLException
	{
		String qry = new AppSecretVersionDB().delete();

		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(qry).addParameter(appSecertVersionId).build();

		return (PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO)>0);
	}

	private List<SecretVo> mListByAppId(String appId) throws SQLException
	{
		List<SecretVo> lstSecrets = new ArrayList<>();
		AppSecretDB dbObj = new AppSecretDB();
		String qry = dbObj.listByAppId();
		HashMap<String, SecretVo> hashSecrets = new HashMap<>();
		
		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(qry).addParameter(appId).build();
		
		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)){
			while (rs.next())
			{
				SecretVo secretVo = hashSecrets.get(rs.getString(APP_SECRET.appSecretId.name()));
				secretVo = setAppsecret(rs, secretVo);
				hashSecrets.put(secretVo.getAppSecretId(), secretVo);
			}
		}
		lstSecrets.addAll(hashSecrets.values());
		return lstSecrets;
	}

	private boolean isUnique(String appSecretId,String appSecretVersionId,String secretKey, String displayName, String appId,boolean toCheckInAppSecret) throws Exception
	{
		AppSecretDB dbObj = new AppSecretDB();
		String qry = dbObj.uniqueName(toCheckInAppSecret);

		List<String> parameters = new ArrayList<>();

		parameters.add(displayName);
		parameters.add(appId);
		parameters.add(appSecretId);
		parameters.add(appSecretVersionId);

		if(toCheckInAppSecret)
		{
			parameters.add(secretKey);
			parameters.add(appId);
			parameters.add(appSecretId);
		}

		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(qry).addParameters(parameters).build();

		String key= "";
		String name = "";
		String msg ="";
		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)){
			while (rs.next())
			{
				key = rs.getString(APP_SECRET.secretKey.name());
				name = rs.getString(APP_SECRET_VERSION.displayName.name());
				if(!toCheckInAppSecret)
				{
					msg = "Display name " + displayName + " already exists.";
				}
				else
				{
					if(secretKey.equalsIgnoreCase(key) && displayName.equalsIgnoreCase(name))
						msg = "Secret key " + secretKey + " and display name " + displayName + " already exists.";
					else if(secretKey.equalsIgnoreCase(key))
						msg = "Secret key " + secretKey + " already exists.";
					else
						msg = "Display name " + displayName + " already exists.";
				}

				throw new Exception(msg);
			}
		}
		return true;
	}

	private SecretVo mGet(String appSecretId) throws SQLException
	{
		AppSecretDB dbObj = new AppSecretDB();
		String qry = dbObj.get();

		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(qry).addParameter(appSecretId).build();
		/*
		 * set secretObj = null if not found return null, multiple SecretVersionVO list return with secretObj.
		 */
		SecretVo secretObj = null;
		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)){
			while (rs.next())
			{
				secretObj = setAppsecret(rs, secretObj);
			}
		}
		return secretObj;
	}
	
	private List<String> getAppSecretId(String appSecretVersionId) throws SQLException {
		AppSecretVersionDB dbObj = new AppSecretVersionDB();
		dbObj.getAppSecretId();
		List<String> appSecretIds = new LinkedList<>();
		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
						.appendQuery(dbObj.getAppSecretId()).addParameter(appSecretVersionId).build();
		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)){
			while (rs.next())
			{
				appSecretIds.add(rs.getString(APP_SECRET.appSecretId.name()));
			}
		}
		
		return appSecretIds;
	}

	/**
	 * this method return appsecret id if its last version
	 * @param appSecretVersionId
	 * @return
	 * @throws SQLException
	 */
	private String mGetAppSecretIdIfLastVersion(String appSecretVersionId) throws SQLException {
		AppSecretVersionDB dbObj = new AppSecretVersionDB();
		String qry = dbObj.countVersions();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(qry)
						.addParameters(getAppSecretId(appSecretVersionId)).build();

		String appSecretId = "";
		int count = 0;
		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				count = rs.getInt("secretVersionCount");
				if (count == 1)
					appSecretId = rs.getString(APP_SECRET.appSecretId.name());
			}
		}
		return appSecretId;
	}
	
	private SecretVo setAppsecret(ResultSet rs, SecretVo secretObj) throws SQLException
	{
		if(secretObj == null)
		{
			secretObj = new SecretVo();

			secretObj.setAppSecretId(rs.getString(APP_SECRET.appSecretId.name()));
			secretObj.setAppId(rs.getString(APP_SECRET.appId.name()));
			secretObj.setKey(rs.getString(APP_SECRET.secretKey.name()));
			//secretObj.setType(SecretTypeEnum.values()[rs.getInt(APP_SECRET.type.name())]);
		}

		SecretVersionVO svo = new SecretVersionVO();
		svo.setAppSecretVersionId(rs.getString(APP_SECRET_VERSION.appSecretVersionId.name()));
		svo.setDisplayName(rs.getString(APP_SECRET_VERSION.displayName.name()));
		svo.setAppUserId(rs.getString(APP_SECRET_VERSION.appUserId.name()));
		svo.setAppSecretId(secretObj.getAppSecretId());
		svo.setType(SecretTypeEnum.values()[rs.getInt(APP_SECRET_VERSION.type.name())]);

		if(svo.getType().name().equals(SecretTypeEnum.file.name()))
		{
			String path = rs.getString(APP_SECRET_VERSION.secretValue.name());
			svo.setPath(path);
			svo.setFileName(path.substring(path.lastIndexOf("/") + 1));
		}
		else
			svo.setValue(rs.getString(APP_SECRET_VERSION.secretValue.name()));
		secretObj.getListSecretVersion().add(svo);
		return secretObj;
	}
}
