/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal;


import java.util.ArrayList;
import java.util.List;

import com.mwp.common.enums.Operator;
import com.mwp.common.vo.FilterObject;
import com.mwp.db.Interface.IConnection;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.dal.engine.ActivityLogEngine;
import com.mwp.p.dal.engine.PortalDatabaseEngine;

/**
 * This class create queries to log activities database related to table {@link ActivityLogEngine}
 *
 */	
public class ActivityLogDB 
{
	private IConnection dbCon = PortalDatabaseEngine.getInstance().getConnection();

	/**
	 * Add new log info in table
	 * @param logId
	 * @param userId
	 * @param action
	 * @param param
	 * @return
	 */
	public String insert() 
	{
		return mInsert();
	}

	/**
	 * List all activity. 
	 * @param appId
	 * @return
	 */
	public String list()
	{
		return mList();
	}
	
	/**
	 * query to list log from last given number of days
	 * @param noOfDays
	 * @return
	 */
	public String listByTime()
	{
		return mListByTime();
	}

	/**
	 * List logs with paging
	 * @param pageNum
	 * @param appId
	 * @param queryLimit
	 * @return 
	 */
	public List<String> listWithEventCount()
	{
		return mListWithEventCount();
	}

	/**
	 * query to delete all activity older than given number of days
	 * @param noOfDays
	 * @return
	 */
	public String purgeActivity()
	{
		return mPurgeActivity();	
	}
	/**
	 * list activity acc to filter
	 * @param pageNo
	 * @param pageSize
	 * @param filters
	 * @return
	 */
	public List<String> listFilter(List<FilterObject> filters)
	{
		return mListFilter(filters);
	}
	
	private String mInsert() 
	{

		StringBuilder sb = new StringBuilder();
		sb.append("INSERT INTO ");
		sb.append(PortalDBEnum.TABLE_NAMES.activityLog);
		sb.append(" ( ");
		sb.append(PortalDBEnum.ACTIVITY_LOG.id.name());
		sb.append(", ");
		sb.append(PortalDBEnum.ACTIVITY_LOG.userId.name());
		sb.append(", ");
		sb.append(PortalDBEnum.ACTIVITY_LOG.action.name());
		sb.append(", ");
		sb.append(PortalDBEnum.ACTIVITY_LOG.param.name());
		sb.append(", ");
		sb.append(PortalDBEnum.ACTIVITY_LOG.timeStamp.name());
		sb.append(" ) VALUES ( ");
		sb.append("?");
		sb.append(", ");
		sb.append("?");
		sb.append(", ");
		sb.append("?");
		sb.append(", ");
		sb.append("?");
		sb.append(", ");
		sb.append(" NOW()");
		sb.append(" )");
		return sb.toString();
	}
	
	private String mList() 
	{
		StringBuilder sb = new StringBuilder();
		
		sb.append("SELECT SQL_CALC_FOUND_ROWS * FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.activityLog);
		
		return sb.toString();
	}
	/**
	 * this will list log from last given number of days
	 * @param noOfDays
	 * @return
	 */
	private String mListByTime() 
	{
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT * FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.activityLog);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.ACTIVITY_LOG.timeStamp.name());
		sb.append(" > ");
		sb.append("NOW() - INTERVAL ");
		sb.append("?");
		sb.append(" DAY" );
		return sb.toString();		
	}

	/**
	 * query to delete all activity older than given number of days
	 * @param noOfDays
	 * @return
	 */
	private String mPurgeActivity()
	{
		StringBuilder sb = new StringBuilder();
		sb.append("DELEET FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.activityLog);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.ACTIVITY_LOG.timeStamp.name());
		sb.append(" < ");
		sb.append("NOW() - INTERVAL ");
		sb.append("?");
		sb.append(" DAY" );
		return sb.toString();		
	}

	private List<String> mListWithEventCount()
	{
		List<String> eventSql = new ArrayList<>(); 
		StringBuilder sb = new StringBuilder();
		sb.append(mList());
		sb.append(" limit ");
		sb.append("?");
		//sb.append(queryLimit);
		sb.append(" offset ");
		sb.append("?");
		//sb.append(offset);

		eventSql.add(sb.toString());
		eventSql.add("SELECT FOUND_ROWS() as eventCount");
		return eventSql;

	}

	private List<String> mListFilter(List<FilterObject> filters)
	{
		List<String> queries = new ArrayList<>();
		//int offset = (pageNo-1) * pageSize;
		StringBuilder sbOuter = new StringBuilder();
		sbOuter.append("SELECT  SQL_CALC_FOUND_ROWS ");	
		sbOuter.append("*");
		sbOuter.append(" FROM ");
		sbOuter.append(PortalDBEnum.TABLE_NAMES.activityLog);

		StringBuilder sortOrder = null;
		StringBuilder whereClause = null;
		String searchString = "";
		if(filters!=null)
		{
			for (FilterObject filterObject : filters)
			{
				switch (filterObject.getFilterType()) 
				{
				case FILTER:
					whereClause = getWhereClause(whereClause);
					switch(filterObject.getFilterkey())
					{
					case User:
						whereClause.append(PortalDBEnum.ACTIVITY_LOG.userId.name());
						whereClause.append(" = ");
						whereClause.append("?");
						break;
					case Time:
						whereClause.append(PortalDBEnum.ACTIVITY_LOG.timeStamp.name());
						whereClause.append(" > ");
						whereClause.append("NOW() - INTERVAL ");
						whereClause.append("?");
						whereClause.append(" DAY " );
						break;
					default:
						break;

					}
					break;
				case SEARCHTEXT: //search by operation 
					whereClause = getWhereClause(whereClause);
					whereClause.append(PortalDBEnum.ACTIVITY_LOG.action);

					if(filterObject.getOperator().ordinal()== Operator.LIKE.ordinal())
					{
						whereClause.append(" LIKE ");
						whereClause.append("?");						
					}else if(filterObject.getOperator().ordinal()== Operator.EQUAL.ordinal()) {
						whereClause.append(" = ");
						whereClause.append("?");
					}
					break;
				case SORT:
					sortOrder = new StringBuilder();
					sortOrder.append(" ORDER BY ");
					switch(filterObject.getSortKey())
					{
					case Operation:
						//Here assuming that we will always add search filter before the sort filter.
						if(searchString.equals(""))
						{
							sortOrder.append(PortalDBEnum.ACTIVITY_LOG.action);
						}
						else{
							//sort by best match : Exact equals first then starts with, then contains and then ends with.
							sortOrder.append(" CASE WHEN ");
							sortOrder.append(PortalDBEnum.ACTIVITY_LOG.action);
							sortOrder.append(" = ");
							sortOrder.append("?");
							sortOrder.append(" THEN 0 ");

							sortOrder.append(" WHEN ");
							sortOrder.append(PortalDBEnum.ACTIVITY_LOG.action);
							sortOrder.append(" LIKE ");
							sortOrder.append("?");
							sortOrder.append(" THEN 1 ");

							sortOrder.append(" WHEN ");
							sortOrder.append(PortalDBEnum.ACTIVITY_LOG.action);
							sortOrder.append(" LIKE ");
							sortOrder.append("?");
							sortOrder.append(" THEN 3 ");

							sortOrder.append(" ELSE 2 ");

							sortOrder.append(" END ");
							sortOrder.append(" , ");
							sortOrder.append(PortalDBEnum.ACTIVITY_LOG.action);
						}	
						break;
					case CreationTime:
						sortOrder.append(PortalDBEnum.ACTIVITY_LOG.timeStamp);
						break;
					default:
						break;
					}
					if(filterObject.getOperator().ordinal()==Operator.DESC.ordinal()){
						sortOrder.append(" DESC");
					}
					break;
				default:
					break;
				}
			}
		}

		//Add where conditions
		if(whereClause != null)
			sbOuter.append(whereClause);

		//Add sort order
		if(sortOrder != null){
			sbOuter.append(sortOrder);
		}

		//Add paging 
		sbOuter.append(" limit ");
		sbOuter.append("?");
		//sbOuter.append(pageSize);
		sbOuter.append(" offset ");
		sbOuter.append("?");
		//sbOuter.append(offset);

		queries.add(sbOuter.toString());
		queries.add("SELECT FOUND_ROWS() as rowCount");
		return queries;
	}

	private StringBuilder getWhereClause(StringBuilder whereClause){
		if(whereClause == null){
			whereClause = new StringBuilder();
			whereClause.append(" WHERE ");						
		}
		else{
			whereClause.append(" AND ");
		}
		return whereClause;			
	}
}
