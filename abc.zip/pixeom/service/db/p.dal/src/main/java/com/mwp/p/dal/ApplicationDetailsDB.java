/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal;

import com.mwp.common.StringFunctions;
import com.mwp.common.enums.Status;
import com.mwp.common.enums.StatusEnum.VERSION_STATUS;
import com.mwp.p.common.enums.PortalDBEnum;

/**
 * This class manage Application/ApplicationImages/ApplicationCategories/ApplicationVersions,
 * get details of application, create/update application.
 * @author root
 *
 */
public class ApplicationDetailsDB {

	/**
	 * Get details of application with images.
	 * @param appId
	 * @param userId is optional if user wants this application installed on my device or not.
	 * @return
	 */
//	public String getAppDetails(String appId, String userId ) {
//		return mGetAppDetails(appId,userId);
//	}

//	/**
//	 * update application and related information (application info and applicationcategories) in database.
//	 * @param appDetailsVO Object of ApplicationDetailsVO class contains(app exist in which category)
//	 * @return
//	 * @throws SQLException 
//	 */
//	public List<QueryVO> updateApplication(ApplicationDetailsVO appDetailsVO) throws SQLException {
//		return mUpdateApplication(appDetailsVO);
//	}

	/**
	 * Add application image in applicationimages table.
	 * @param imagesVO object of ApplicationImagesVO class 
	 * @return
	 */
	public String addApplicationImage() {
		return getAddAppImageQuery();
	}

	/**
	 * update application image logo.
	 * @param appId
	 * @param logoPath
	 * @return
	 */
	public String updateApplicationLogo() {
		return mUpdateApplicationLogo();
	}


	/**
	 * Update application status.
	 * @param appId
	 * @param status
	 * @return
	 */
	public String updateApplicationStatus(){
		return mUpdateApplicationStatus();
	}

	/**
	 * This query return details of application (Title, CompanyName, categoryId, imagePath, appVersion).
	 * This query has JOIN ON (company/applicationcategories/category),
	 * LEFT JOIN ON (applicationimages/applicationversions).
	 * @param appId
	 * @return
	 */
	public String getApplicationDetails() {
		return mGetApplicationDetails();
	}

	/**
	 * This query return details of developer application (Title, CompanyName, categoryId, serviceName).
	 * This query has JOIN ON (company/applicationcategories/category),
	 * LEFT JOIN ON (applicationserviceendpoints).
	 * @param appId
	 * @return
	 */
	public String getDeveloperAppDetails() {
		return mGetDeveloperAppDetails();
	}

	/**
	 * This query return Install application detail(Title, companyName, companyWebAddress appVersion, composerFilePath, serviceName),
	 * Main Table application, LEFT JOIN (company/applicationserviceendpoints/applicationversions).
	 * @param appId
	 * @param appVersionId optional param,
	 * if empty then get LIVE appVersion,
	 * else not empty then get appVersion according to appVersionId 
	 * @return
	 */
	public String getInstallAppDetails(String appId, String appVersionId, String appPlatformId) {
		return mGetInstallAppDetails(appId, appVersionId, appPlatformId);
	}

	/**
	 * Getting query for new updated application version available,
	 * query return boolean true/false, check that this app has other LIVE version,
	 * except this appVersionId.  
	 * @param appId
	 * @param appVersionId
	 * @return
	 */
	public String getUpdateAvailableForInstalledApp() {
		return mGetUpdateAvailableForInstalledApp();
	}

	/**
	 * This query return application detail with version(Title, appVersion, composerFilePath, size),
	 * Main Table application, LEFT JOIN (applicationversions).
	 * @param appId
	 * @param appVersionId optional param,
	 * if empty then get LIVE appVersion,
	 * else not empty then get appVersion according to appVersionId 
	 * @return
	 */
	public String getAppDetailsWithVersion(String appVersionId) {
		return mGetAppDetailsWithVersion(appVersionId);
	}

	/**
	 * getting query for delete appImage according to appId and appImageId.
	 * @param appId
	 * @param appImageId
	 * @return query string for delete appImage row from applicationimages table.
	 */
	public String deleteAppImage() {
		return mDeleteAppImage();
	}

	private String mDeleteAppImage() {
		StringBuilder sb = new StringBuilder();
		sb.append("DELETE FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.applicationimages);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.APPLICATION_IMAGES.appId.name());sb.append(" = ");sb.append("?");
		sb.append(" AND ");
		sb.append(PortalDBEnum.APPLICATION_IMAGES.appImageId.name());sb.append(" = ");sb.append("?");
		return sb.toString();
	}

	/**
	 * Get application title if app exists 
	 * @param title
	 * @return
	 */
	public String getAppName() {
		return mGetAppName();
	}

	private String mGetAppName() {
		StringBuilder sb = new StringBuilder();
		sb.append("Select ");
		sb.append(PortalDBEnum.APPLICATION.title);
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.application);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.APPLICATION.appId.name());sb.append(" = ");sb.append("?");
		sb.append(" AND ");
		sb.append(PortalDBEnum.APPLICATION.appStatus.name());sb.append(" != ");sb.append(Status.DELETED.ordinal());
		return sb.toString();
	}

	/**
	 * check that application exists or not for given title 
	 * @param title
	 * @return
	 */
	public String isApplicationExits() {
		return mIsApplicationExits();
	}

	private String mIsApplicationExits() {
		StringBuilder sb = new StringBuilder();
		sb.append("Select * FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.application);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.APPLICATION.title.name());sb.append(" = ");sb.append("?");
		sb.append(" AND ");
		sb.append(PortalDBEnum.APPLICATION.appStatus.name());sb.append(" != ");sb.append(Status.DELETED.ordinal());
		return sb.toString();
	}

	/**
	 * method checks if application name already exists 
	 * @param appName 
	 * @param appId
	 * @return
	 */
	public String isAppNameAlreadyExist()
	{
		return mIsAppNameAlreadyExist();
	}
	public String unpublishApplication()
	{
		return mUnpublishApplication();
	}


	/**
	 * This query return application detail with version(Title, appVersion, composerFilePath, size),
	 * Main Table application, LEFT JOIN (applicationversions).
	 * @param appId
	 * @param appVersionId optional param,
	 * if empty then get LIVE appVersion,
	 * else not empty then get appVersion according to appVersionId 
	 * @return
	 */
	private String mGetAppDetailsWithVersion(String appVersionId) {
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT ");
		sb.append(" a.* ");
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.appVersionId.name());
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.appVersion.name());
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.releaseNotes.name());
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.composerFilePath.name());
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.size.name());
		//AKH_04
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.redirectType.name());
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.redirectSection.name());
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.redirectUrl.name());
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.restRedirectUrl.name());
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.composerFilePath.name());
		sb.append(" FROM ");sb.append(PortalDBEnum.TABLE_NAMES.application);sb.append(" as a ");
		sb.append(" JOIN ");sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(" ON a.appId = applicationversions.appId ");
		sb.append(" WHERE ");
		sb.append(" a.appId = ");sb.append("?");
		sb.append(" AND ");
		if(StringFunctions.isNullOrWhitespace(appVersionId)){
			sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.versionStatus.name());
			sb.append(" = ");sb.append(VERSION_STATUS.LIVE.ordinal());
		}else{
			sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.appVersionId.name());
			sb.append(" = ");sb.append("?");
		}
		return sb.toString();
	}

	private String mGetUpdateAvailableForInstalledApp() {
		StringBuilder sb = new StringBuilder();
		/*
		 * This select query return 1/0 (true/false) boolean value if update available.
		 */
		sb.append("SELECT IF (COUNT(*) = 0,0,1) as isUpdateAvailable FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.APPLICATION_VERSIONS.versionStatus.name());sb.append(" = ");sb.append(VERSION_STATUS.LIVE.ordinal());
		sb.append(" AND ");
		sb.append(PortalDBEnum.APPLICATION_VERSIONS.appPlatformId.name());sb.append(" = ");sb.append("?");
		sb.append(" AND ");
		sb.append(PortalDBEnum.APPLICATION_VERSIONS.appId.name());sb.append(" = ");sb.append("?");
		sb.append(" AND ");
		sb.append(PortalDBEnum.APPLICATION_VERSIONS.appVersionId.name());sb.append(" != ");sb.append("?");

		return sb.toString();
	}

	/**
	 * This query return details of application (Title, CompanyName, categoryId, imagePath, appVersion).
	 * This query has JOIN ON (company/applicationcategories/category),
	 * LEFT JOIN ON (applicationimages/applicationversions).
	 * @param appId
	 * @return
	 */
	private String mGetApplicationDetails() {
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT ");
		sb.append(" a.* ");
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.company);sb.append(".");sb.append(PortalDBEnum.COMPANY.companyName.name());
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.company);sb.append(".");sb.append(PortalDBEnum.COMPANY.webAddress.name());sb.append(" as companyWebAddress");
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.category);sb.append(".");sb.append(PortalDBEnum.CATEGORY.name.name());
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.category);sb.append(".");sb.append(PortalDBEnum.CATEGORY.catId.name());
		sb.append(", applicationimages." + PortalDBEnum.APPLICATION_IMAGES.imagePath);
		sb.append(", applicationimages." + PortalDBEnum.APPLICATION_IMAGES.sequenceNo);
		sb.append(", applicationimages." + PortalDBEnum.APPLICATION_IMAGES.appImageId);
		sb.append(", appplatform." + PortalDBEnum.APPLICATION_PLATFORM.appPlatformId);
		sb.append(", appplatform." + PortalDBEnum.APPLICATION_PLATFORM.platformId);
		sb.append(", appplatform." + PortalDBEnum.APPLICATION_PLATFORM.repositoryName);
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.appVersionId.name());
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.appVersion.name());
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.releaseNotes.name());
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.size.name());
		//AKH_04
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.redirectType.name());
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.redirectSection.name());
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.redirectUrl.name());
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.restRedirectUrl.name());
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.composeVersion.name());
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.modifiedDate.name());sb.append(" as versionModifiedDate");
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.appPlatformId.name());sb.append(" as appPlatformIdVersion");
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.application);sb.append(" as a ");
		sb.append("JOIN ");sb.append(PortalDBEnum.TABLE_NAMES.project);sb.append(" ON a.projectId = project.projectId ");
		sb.append("JOIN ");sb.append(PortalDBEnum.TABLE_NAMES.company);sb.append(" ON project.companyId = company.companyId ");
		sb.append("JOIN ");sb.append(PortalDBEnum.TABLE_NAMES.applicationcategories);sb.append(" ON a.appId = applicationcategories.appId ");
		sb.append("JOIN ");sb.append(PortalDBEnum.TABLE_NAMES.category);sb.append(" ON applicationcategories.catId = category.catId ");
		sb.append(" LEFT JOIN ");sb.append(PortalDBEnum.TABLE_NAMES.applicationimages);sb.append(" ON a.appId = applicationimages.appId");  
		sb.append(" LEFT JOIN ");sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append("  ON a.appId = applicationversions.appId ");
		sb.append(" LEFT JOIN ");sb.append(PortalDBEnum.TABLE_NAMES.applicationplatform);sb.append(" AS appplatform ON appplatform.");sb.append(PortalDBEnum.APPLICATION_PLATFORM.appId);
		sb.append(" = a.");sb.append(PortalDBEnum.APPLICATION.appId);
		sb.append(" WHERE ");
		sb.append(" a.appId = ");sb.append("?");
		sb.append(" AND ");
		sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.versionStatus.name());
		sb.append(" = ");sb.append(VERSION_STATUS.LIVE.ordinal());
		return sb.toString();
	}

	/**
	 * This query return Install application detail(Title, companyName, companyWebAddress, appVersion, composerFilePath, serviceName),
	 * Main Table application, LEFT JOIN (compnay,applicationserviceendpoints/applicationversions).
	 * @param appId
	 * @param appVersionId optional param,
	 * if empty then get LIVE appVersion,
	 * else not empty then get appVersion according to appVersionId 
	 * @return
	 */
	private String mGetInstallAppDetails(String appId, String appVersionId, String appPlatformId) 
	{
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT ");
		sb.append(" a.* ");
		sb.append(", ");
		sb.append(PortalDBEnum.TABLE_NAMES.company);sb.append(".");sb.append(PortalDBEnum.COMPANY.companyName.name());
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.company);sb.append(".");sb.append(PortalDBEnum.COMPANY.webAddress.name());sb.append(" as companyWebAddress");

		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.appVersionId.name());
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.appVersion.name());
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.releaseNotes.name());
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.composerFilePath.name());
		//AKH_04
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.redirectType.name());
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.redirectSection.name());
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.redirectUrl.name());
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.restRedirectUrl.name());

		//AKH_02_1
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.size.name());
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.toExecuteOrder.name());
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.applicationserviceendpoints);sb.append(".");sb.append(PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.serviceName.name());
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.applicationserviceendpoints);sb.append(".");sb.append(PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.appServiceEndpointId.name());

		sb.append(", appplatform." + PortalDBEnum.APPLICATION_PLATFORM.appPlatformId);
		sb.append(", appplatform." + PortalDBEnum.APPLICATION_PLATFORM.platformId);
		sb.append(", appplatform." + PortalDBEnum.APPLICATION_PLATFORM.repositoryName);

		//AKH add applicationserviceports value.
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.applicationserviceports);sb.append(".");sb.append(PortalDBEnum.APPLICATION_SERVICE_PORTS.appServicePortId.name());
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.applicationserviceports);sb.append(".");sb.append(PortalDBEnum.APPLICATION_SERVICE_PORTS.serviceName.name());
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.applicationserviceports);sb.append(".");sb.append(PortalDBEnum.APPLICATION_SERVICE_PORTS.internalPort.name());
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.applicationserviceports);sb.append(".");sb.append(PortalDBEnum.APPLICATION_SERVICE_PORTS.externalPort.name());

		sb.append(" FROM ");sb.append(PortalDBEnum.TABLE_NAMES.application);sb.append(" as a ");
		sb.append(" JOIN ");sb.append(PortalDBEnum.TABLE_NAMES.project);sb.append(" ON a.projectId = project.projectId ");
		sb.append(" JOIN ");sb.append(PortalDBEnum.TABLE_NAMES.company);sb.append(" ON project.companyId = company.companyId ");
		sb.append(" LEFT JOIN ");sb.append(PortalDBEnum.TABLE_NAMES.applicationserviceendpoints);sb.append(" ON a.appId = applicationserviceendpoints.appId ");
		sb.append(" LEFT JOIN ");sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(" ON a.appId = applicationversions.appId ");
		sb.append(" LEFT JOIN ");sb.append(PortalDBEnum.TABLE_NAMES.applicationserviceports);sb.append(" ON applicationversions.");sb.append(PortalDBEnum.APPLICATION_VERSIONS.appVersionId);
		sb.append(" = applicationserviceports.");sb.append(PortalDBEnum.APPLICATION_SERVICE_PORTS.appVersionId);
		sb.append(" LEFT JOIN ");sb.append(PortalDBEnum.TABLE_NAMES.applicationplatform);sb.append(" AS appplatform ON appplatform.");sb.append(PortalDBEnum.APPLICATION_PLATFORM.appPlatformId);
		sb.append(" = applicationversions.");sb.append(PortalDBEnum.APPLICATION_VERSIONS.appPlatformId);
		sb.append(" WHERE ");
		sb.append(" a.appId = ");
		sb.append("?");
		//sb.append(PortalDatabaseEngine.getInstance().getConnection().formatString(appId));
		/*
		 * Added status check for deleted app in application details because deleted apps is being install by schedular.- PS 679
		 */
		sb.append(" AND ");
		sb.append("a.");sb.append(PortalDBEnum.APPLICATION.appStatus);sb.append(" != ");sb.append(Status.DELETED.ordinal());

		sb.append(" AND ");
		if(!StringFunctions.isNullOrWhitespace(appPlatformId) && StringFunctions.isNullOrWhitespace(appVersionId)){
			sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.appPlatformId.name());
			sb.append(" = ");
			sb.append("?");
//			sb.append(dbCon.formatString(appPlatformId));
			sb.append(" AND ");
			sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.versionStatus.name());
			sb.append(" = ");sb.append(VERSION_STATUS.LIVE.ordinal());
		}else if(StringFunctions.isNullOrWhitespace(appVersionId)){
			sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.versionStatus.name());
			sb.append(" = ");sb.append(VERSION_STATUS.LIVE.ordinal());
		} else{
			sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.appVersionId.name());
			sb.append(" = ");
			sb.append("?");
//			sb.append(PortalDatabaseEngine.getInstance().getConnection().formatString(appVersionId));
			/*
			 * Added status check for deleted version in  application version details because deleted version is being install by schedular.- PS  refre 714
			 */
			sb.append(" AND ");
			sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.versionStatus.name());
			sb.append(" != ");
			sb.append(VERSION_STATUS.DELETED.ordinal());
		}
		return sb.toString();
	}

	/**
	 * This query return details of developer application (Title, CompanyName, categoryId, serviceName).
	 * This query has JOIN ON (company/applicationcategories/category),
	 * LEFT JOIN ON (applicationserviceendpoints).
	 * @param appId
	 * @return
	 */
	private String mGetDeveloperAppDetails() {
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT ");
		sb.append(" a.* ");
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.company);sb.append(".");sb.append(PortalDBEnum.COMPANY.companyName.name());
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.company);sb.append(".");sb.append(PortalDBEnum.COMPANY.webAddress.name());sb.append(" as companyWebAddress");
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.category);sb.append(".");sb.append(PortalDBEnum.CATEGORY.name.name());
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.category);sb.append(".");sb.append(PortalDBEnum.CATEGORY.catId.name());
		/*
		 * get application images.
		 */
		sb.append(", applicationimages." + PortalDBEnum.APPLICATION_IMAGES.imagePath);
		sb.append(", applicationimages." + PortalDBEnum.APPLICATION_IMAGES.sequenceNo);
		sb.append(", applicationimages." + PortalDBEnum.APPLICATION_IMAGES.appImageId);

		sb.append(", appplatform." + PortalDBEnum.APPLICATION_PLATFORM.appPlatformId);
		sb.append(", appplatform." + PortalDBEnum.APPLICATION_PLATFORM.platformId);
		sb.append(", appplatform." + PortalDBEnum.APPLICATION_PLATFORM.repositoryName);

		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.applicationserviceendpoints);sb.append(".");sb.append(PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.serviceName.name());
		sb.append(", ");sb.append(PortalDBEnum.TABLE_NAMES.applicationserviceendpoints);sb.append(".");sb.append(PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.appServiceEndpointId.name());

		sb.append(" FROM ");sb.append(PortalDBEnum.TABLE_NAMES.application);sb.append(" as a ");

		sb.append(" JOIN ");
		sb.append(PortalDBEnum.TABLE_NAMES.project);sb.append(" ON a.projectId = project.projectId ");
		sb.append(" JOIN ");
		sb.append(PortalDBEnum.TABLE_NAMES.company);sb.append(" ON project.companyId = company.companyId ");
		sb.append("JOIN ");sb.append(PortalDBEnum.TABLE_NAMES.applicationcategories);sb.append(" ON a.appId = applicationcategories.appId ");
		sb.append("JOIN ");sb.append(PortalDBEnum.TABLE_NAMES.category);sb.append(" ON applicationcategories.catId = category.catId ");
		sb.append(" LEFT JOIN ");sb.append(PortalDBEnum.TABLE_NAMES.applicationserviceendpoints);sb.append(" ON a.appId = applicationserviceendpoints.appId ");
		sb.append(" LEFT JOIN ");sb.append(PortalDBEnum.TABLE_NAMES.applicationimages);sb.append(" ON a.appId = applicationimages.appId ");
		sb.append(" LEFT JOIN ");sb.append(PortalDBEnum.TABLE_NAMES.applicationplatform);sb.append(" AS appplatform ON appplatform.");sb.append(PortalDBEnum.APPLICATION_PLATFORM.appId);
		sb.append(" = a.");sb.append(PortalDBEnum.APPLICATION.appId);
		sb.append(" WHERE ");
		sb.append("a.appId = ");sb.append("?");
		/*
		 * Added status check for deleted app in device details because from box side detail should not show for delete apps.- PS 661
		 */
		sb.append(" AND ");
		sb.append("a.");sb.append(PortalDBEnum.APPLICATION.appStatus);sb.append(" != ");sb.append(Status.DELETED.ordinal());

		return sb.toString();
	}

	private String mUpdateApplicationStatus(){
		StringBuilder sb = new StringBuilder();
		sb.append("UPDATE ");
		sb.append(PortalDBEnum.TABLE_NAMES.application);
		sb.append(" SET ");
		sb.append(PortalDBEnum.APPLICATION.appStatus.name());
		sb.append(" = ");
		sb.append("?");
		//sb.append(status.ordinal());
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.APPLICATION.appId.name());
		sb.append(" = ");
		sb.append("?");
		//sb.append(PortalDatabaseEngine.getInstance().getConnection().formatString(appId));
		return sb.toString();
	}

	private String mUnpublishApplication(){
		StringBuilder sb = new StringBuilder();
		sb.append("UPDATE ");
		sb.append(PortalDBEnum.TABLE_NAMES.application);
		sb.append(" SET ");
		sb.append(PortalDBEnum.APPLICATION.appStatus.name());
		sb.append(" = ");
		sb.append(Status.ACTIVE.ordinal());
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.APPLICATION.appId.name());
		sb.append(" = ");
		sb.append("?");
		//sb.append(PortalDatabaseEngine.getInstance().getConnection().formatString(appId));
		sb.append(" AND ");
		sb.append(" 0 = (SELECT ");
		sb.append(" COUNT(");
		sb.append(PortalDBEnum.APPLICATION_VERSIONS.appVersionId.name());
		sb.append(") as count");
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.APPLICATION_VERSIONS.appId.name());
		sb.append(" = ");
		sb.append("?");
		//sb.append(dbCon.formatString(appId));
		sb.append(" AND ");
		sb.append(PortalDBEnum.APPLICATION_VERSIONS.versionStatus.name());
		sb.append(" = ");
		sb.append(VERSION_STATUS.LIVE.ordinal());
		sb.append(" ) ");

		return sb.toString();
	}



	private String mUpdateApplicationLogo() {
		StringBuilder sb = new StringBuilder();
		sb.append("UPDATE ");
		sb.append(PortalDBEnum.TABLE_NAMES.application);
		sb.append(" SET ");
		sb.append(PortalDBEnum.APPLICATION.icon.name());
		sb.append(" = ");
		sb.append("?");
//		sb.append(PortalDatabaseEngine.getInstance().getConnection().formatString(logoPath));
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.APPLICATION.appId.name());
		sb.append(" = ");
		sb.append("?");
//		sb.append(PortalDatabaseEngine.getInstance().getConnection().formatString(appId));
		return sb.toString();
	}

	/**
	 * Get details of application with images.
	 * @param appId
	 * @return
	 */
	private String mGetAppDetails(String userId) {
		StringBuilder sb = new StringBuilder();
		sb.append("Select app.* ");
		sb.append(", appimage." + PortalDBEnum.APPLICATION_IMAGES.imagePath);
		sb.append(", appimage." + PortalDBEnum.APPLICATION_IMAGES.sequenceNo);
		sb.append(", appimage." + PortalDBEnum.APPLICATION_IMAGES.appImageId);
		if (!StringFunctions.isNullOrWhitespace(userId)) {
			// SubQuery for getting application installed on user device or not.
			// (first getting user devices list then check application installed
			// on these device,
			// if one of them app installed then count return as boolean)
			sb.append(", (select IF (COUNT(*) = 0,0,1) FROM ");
			sb.append(PortalDBEnum.TABLE_NAMES.deviceapplications);
			sb.append(" WHERE ");
			sb.append(PortalDBEnum.TABLE_NAMES.deviceapplications);
			sb.append(".");
			sb.append(PortalDBEnum.DEVICE_APPLICATIONS.deviceId);
			sb.append(" IN (");
			sb.append("Select ");
			sb.append(PortalDBEnum.TABLE_NAMES.devices);
			sb.append(".");
			sb.append(PortalDBEnum.DEVICES.deviceId);
			sb.append(" FROM ");
			sb.append(PortalDBEnum.TABLE_NAMES.devices);
			sb.append(" WHERE ");
			sb.append(PortalDBEnum.TABLE_NAMES.devices);
			sb.append(".");
			sb.append(PortalDBEnum.DEVICES.userId);
			sb.append(" = ");
			sb.append("?");
			//sb.append(PortalDatabaseEngine.getInstance().getConnection().formatString(userId));
			sb.append(" AND ");
			sb.append(PortalDBEnum.TABLE_NAMES.devices);
			sb.append(".");
			sb.append(PortalDBEnum.DEVICES.deviceStatus);
			sb.append(" != ");
			sb.append(Status.DELETED.ordinal());
			sb.append(") AND ");
			sb.append(PortalDBEnum.TABLE_NAMES.deviceapplications);
			sb.append(".");
			sb.append(PortalDBEnum.DEVICE_APPLICATIONS.appId);
			sb.append(" = ");
			sb.append("?");
//			sb.append(PortalDatabaseEngine.getInstance().getConnection().formatString(appId));
			sb.append(") AS isInstalled ");
		}

		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.application);
		sb.append(" AS app ");
		sb.append(" LEFT JOIN ");
		sb.append(PortalDBEnum.TABLE_NAMES.applicationimages);
		sb.append(" AS appimage ON appimage.");
		sb.append(PortalDBEnum.APPLICATION_IMAGES.appId);
		sb.append(" = app.");
		sb.append(PortalDBEnum.APPLICATION.appId);
		sb.append(" WHERE app.");
		sb.append(PortalDBEnum.APPLICATION.appStatus);

		// COMMENT THIS CODE... IF USER INSTALL ANY NON PUBLISHED APP THEN
		// APPLICATION DETAILS NOT GETTING - BY RA/

		sb.append(" != ");
		sb.append(Status.DELETED.ordinal());

		sb.append(" AND app.");
		sb.append(PortalDBEnum.APPLICATION.appId);
		sb.append(" = ");
		sb.append("?");
//		sb.append(PortalDatabaseEngine.getInstance().getConnection().formatString(appId));
		return sb.toString();
	}

//	/**
//	 * update application and related information (application info and applicationcategories) in database.
//	 * @param appDetailsVO Object of ApplicationDetailsVO class contains(app exist in which category)
//	 * @return
//	 * @throws SQLException 
//	 */
//	private ArrayList<QueryVO> mUpdateApplication(ApplicationDetailsVO appDetailsVO) throws SQLException {
//		ArrayList<QueryVO> listQuery = new ArrayList<>();
//
//		QueryVO updateQueryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
//				.appendQuery(getUpdateQueryForApplication(appDetailsVO))
//				.addParameter(appDetailsVO.getTitle())
//				.addParameter(appDetailsVO.getDescription())
//				.addParameter(appDetailsVO.getWebAddress())
//				.addParameter(appDetailsVO.getAppStatus().ordinal())
//				.addParameter(appDetailsVO.isUsePxAuth())
//				.addParameter(appDetailsVO.isUsePxCloudApi())
//				.addParameter(appDetailsVO.isUsePxEventService())
//				.addParameter(appDetailsVO.getPrice())
//				.addParameter(appDetailsVO.getRating())
//				.addParameter(appDetailsVO.getApplicationId())
//				.build();
//
//
//		//Get Insert query for Application.
//		listQuery.add(updateQueryVO);
//
//		/**
//		 * on update app, delete all app-category relation using appId,
//		 * and again add all entries in db which exist in category list,
//		 * because if user wants to remove app from some categories.
//		 */
//		QueryVO deleteAppCategoriesQueryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
//				.appendQuery(deleteAppCategories()).addParameter(appDetailsVO.getApplicationId()).build();
//
//		listQuery.add(deleteAppCategoriesQueryVO);
//		//Get add query for ApplicationCategories( this table maintain app - categories relation) categories are multiple.
//		for (CategoryVO cat : appDetailsVO.getCategories()) {
//			
//			QueryVO queryVOCat = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
//					.appendQuery(new ApplicationDetailsDB().getAddAppCategoryQuery())
//					.addParameter(appDetailsVO.getApplicationId())
//					.addParameter(cat.getCategoryId())
//					.build();
//			
//			listQuery.add(queryVOCat);
//		}
//		return listQuery;
//	}

	public String getAddApplicationQuery(){
		StringBuilder sb = new StringBuilder();
		sb.append("INSERT INTO ");
		sb.append(PortalDBEnum.TABLE_NAMES.application);
		sb.append(" ( ");
		sb.append(PortalDBEnum.APPLICATION.appId.name());
		sb.append(", ");
		sb.append(PortalDBEnum.APPLICATION.projectId.name());
		sb.append(", ");
		sb.append(PortalDBEnum.APPLICATION.userId.name());
		sb.append(", ");
		sb.append(PortalDBEnum.APPLICATION.title.name());
		sb.append(", ");
		sb.append(PortalDBEnum.APPLICATION.description.name());
		sb.append(", ");
		sb.append(PortalDBEnum.APPLICATION.webAddress.name());
		//AKH_04
		sb.append(", ");
		//add secretKey field in application db.
		sb.append(PortalDBEnum.APPLICATION.secretKey.name());
		sb.append(", ");
		sb.append(PortalDBEnum.APPLICATION.appStatus.name());
		sb.append(", ");
		sb.append(PortalDBEnum.APPLICATION.appTypeId.name());
		sb.append(", ");
		sb.append(PortalDBEnum.APPLICATION.usePxAuth.name());
		sb.append(", ");
		sb.append(PortalDBEnum.APPLICATION.usePxCloudApi.name());
		sb.append(", ");
		sb.append(PortalDBEnum.APPLICATION.usePxEventService.name());
		sb.append(", ");
		sb.append(PortalDBEnum.APPLICATION.signUpType.name());
		sb.append(", ");
		//AKH_01_1
		sb.append(PortalDBEnum.APPLICATION.price.name());
		sb.append(", ");
		sb.append(PortalDBEnum.APPLICATION.rating.name());
		sb.append(", ");
		sb.append(PortalDBEnum.APPLICATION.currency.name());
		sb.append(", ");
		sb.append(PortalDBEnum.APPLICATION.runAsService.name());
		sb.append(", ");
		sb.append(PortalDBEnum.APPLICATION.modifiedDate.name());
		sb.append(", ");
		sb.append(PortalDBEnum.APPLICATION.createdDate.name());
		sb.append(" ) VALUES ( ");
		sb.append("?");
		sb.append(", ");
		sb.append("?");
		sb.append(", ");
		sb.append("?");
		sb.append(", ");
		sb.append("?");
		sb.append(", ");
		sb.append("?");
		sb.append(", ");
		sb.append("?");
		//AKH_04
		sb.append(", ");
		//set randomId in secretKey.
		sb.append("?");
		sb.append(", ");
		sb.append("?");
		sb.append(", ");
		sb.append("?");
		sb.append(", ");
		sb.append("?");
		sb.append(", ");
		sb.append("?");
		sb.append(", ");
		sb.append("?");
		sb.append(", ");
		sb.append("?");
		sb.append(", ");
		sb.append("?");
		sb.append(", ");
		sb.append("?");
		sb.append(", ");
		sb.append("?");
		sb.append(", ");
		sb.append("?");
		sb.append(", ");
		sb.append(" NOW()");
		sb.append(", ");
		sb.append(" NOW()");
		sb.append(" ) ");
		return sb.toString();
	}

	private String getAddAppImageQuery(){

		StringBuilder sb = new StringBuilder();
		sb.append("INSERT INTO ");
		sb.append(PortalDBEnum.TABLE_NAMES.applicationimages);
		sb.append(" ( ");
		sb.append(PortalDBEnum.APPLICATION_IMAGES.appImageId.name());
		sb.append(", ");
		sb.append(PortalDBEnum.APPLICATION_IMAGES.appId.name());
		sb.append(", ");
		sb.append(PortalDBEnum.APPLICATION_IMAGES.imagePath.name());
		sb.append(", ");
		sb.append(PortalDBEnum.APPLICATION_IMAGES.sequenceNo.name());
		sb.append(" ) VALUES ( ");
		sb.append("?");
//		sb.append(PortalDatabaseEngine.getInstance().getConnection().formatString(appImg.getAppImageId()));
		sb.append(", ");
		sb.append("?");
//		sb.append(PortalDatabaseEngine.getInstance().getConnection().formatString(appImg.getAppId()));
		sb.append(", ");
		sb.append("?");
//		sb.append(PortalDatabaseEngine.getInstance().getConnection().formatString(appImg.getImagePath()));
		sb.append(", ");
		sb.append("?");
//		sb.append(appImg.getSequenceNo());
		sb.append(" ) ");
		return sb.toString();
	}

	public String getAddAppCategoryQuery(){
		StringBuilder sb = new StringBuilder();
		sb.append("INSERT INTO ");
		sb.append(PortalDBEnum.TABLE_NAMES.applicationcategories);
		sb.append(" ( ");
		sb.append(PortalDBEnum.APPLICATION_CATEGORIES.appId.name());
		sb.append(", ");
		sb.append(PortalDBEnum.APPLICATION_CATEGORIES.catId.name());
		sb.append(" ) VALUES ( ");
		sb.append("?");
		sb.append(", ");
		sb.append("?");
		sb.append(" ) ");
		return sb.toString();
	}
	private String mIsAppNameAlreadyExist()
	{
		StringBuilder sb = new StringBuilder();
		sb.append("Select * FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.application);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.APPLICATION.title.name());sb.append(" = ");sb.append("?");
		sb.append(" AND ");
		sb.append(PortalDBEnum.APPLICATION.appStatus.name());sb.append(" != ");sb.append(Status.DELETED.ordinal());
		sb.append(" AND ");
		sb.append(PortalDBEnum.APPLICATION.appId.name());sb.append(" != ");sb.append("?");
		return sb.toString();
	}
	public String getUpdateQueryForApplication(){
		StringBuilder sb = new StringBuilder();
		sb.append("UPDATE ");
		sb.append(PortalDBEnum.TABLE_NAMES.application);
		sb.append(" SET ");
		sb.append(PortalDBEnum.APPLICATION.title.name());
		sb.append(" = ");
		sb.append("?");
		sb.append(", ");
		sb.append(PortalDBEnum.APPLICATION.description.name());
		sb.append(" = ");
		sb.append("?");
		sb.append(", ");
		sb.append(PortalDBEnum.APPLICATION.webAddress.name());
		sb.append(" = ");
		sb.append("?");
		sb.append(", ");
		//AKH_03, AKH_04
		sb.append(PortalDBEnum.APPLICATION.appStatus.name());
		sb.append(" = ");
		sb.append("?");
		sb.append(", ");
		sb.append(PortalDBEnum.APPLICATION.usePxAuth.name());
		sb.append(" = ");
		sb.append("?");
		sb.append(", ");
		sb.append(PortalDBEnum.APPLICATION.usePxCloudApi.name());
		sb.append(" = ");
		sb.append("?");
		sb.append(", ");
		sb.append(PortalDBEnum.APPLICATION.usePxEventService.name());
		sb.append(" = ");
		sb.append("?");
		sb.append(", ");
		//AKH_01_1
		sb.append(PortalDBEnum.APPLICATION.price.name());
		sb.append(" = ");
		sb.append("?");
		sb.append(", ");
		sb.append(PortalDBEnum.APPLICATION.rating.name());
		sb.append(" = ");
		sb.append("?");
		sb.append(", ");
		sb.append(PortalDBEnum.APPLICATION.modifiedDate.name());
		sb.append(" = NOW()");
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.APPLICATION.appId.name());
		sb.append(" = ");
		sb.append("?");
		return sb.toString();
	}

	public String deleteAppCategories(){
		StringBuilder sb = new StringBuilder();
		sb.append("DELETE FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.applicationcategories);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.APPLICATION_CATEGORIES.appId.name());
		sb.append(" = ");
		sb.append("?");
		return sb.toString();
	}
}

/**
 * History of check-in or issue resolved
 * 
 * 01 - 21-10-2016 
 * AKH_01_1
 * Added currency, price and rating field for used sorting on UI. 
 * AKH_02_1
 * add size field because we required in notification message on execute method call.
 * 
 * 03 - 4-11-2016
 * AKH_03
 * set and get restRedirectUrl and redirectSection in application we save "reverse proxy" and "specific port" in redirect Url and rest Url save in restRedirectUrl.
 * 
 * 04 - 14-11-2016 AKH_04
 * remove restRedirectUrl, redirectUrl, redirectType and redirectSection these property shift to applicationVersion,
 * because may be each version have different redirection param.
 */
