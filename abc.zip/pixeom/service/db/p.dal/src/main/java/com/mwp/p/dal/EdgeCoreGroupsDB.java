/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.mwp.p.dal;

import java.util.ArrayList;
import java.util.List;

import com.mwp.common.StringFunctions;
import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.db.Interface.IConnection;
import com.mwp.logger.PALogger;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.common.enums.PortalDBEnum.DEVICES_NODES_VIEW;
import com.mwp.p.common.enums.PortalDBEnum.DEVICE_LABEL_MAP;
import com.mwp.p.dal.engine.DevicesEngine;
import com.mwp.p.dal.engine.GroupsEngine;
import com.mwp.p.dal.engine.PortalDatabaseEngine;

public class EdgeCoreGroupsDB 
{
	private IConnection dbCon= null;
	public EdgeCoreGroupsDB() {
		dbCon = PortalDatabaseEngine.getInstance().getConnection();
	}

	/**
	 * List group of device according to groupId.
	 * @param groupId
	 * @return
	 */
	public String listGroupEdgeCore() {
		return mListGroupEdgeCore();
	}

	

	/**
	 * add device group relation in edgecoreGroup table.
	 * @param deviceId
	 * @param groupId
	 * @return
	 */
	public String addEdgeCoreToGroup() {
		return mAddEdgeCoreToGroup();
	}
	
	/**
	 * remove Appliance -group relation from edgecoreGroup tables
	 * @param deviceId
	 * @param groupId
	 * @return
	 */
	public String removeEdgeCoreFromGroup(String deviceId) {
		return mRemoveEdgeCoreFromGroup(deviceId); 
	}

	/**
	 * get groupEdgeCoreId of edgecoreGroup according to deviceId,groupId combination.
	 * @param groupId
	 * @return
	 */
	public String getGroupEdgeCoreId() {
		return mGetGroupEdgeCoreId();
	}
		

	/**
	 * get list of groups of requested device
	 * @param deviceId
	 * @param groupIds
	 * @return
	 */
	public String getGroupsOfEdgeCore(List<String> groupIds) {
		return mGetGroupsOfEdgeCore(groupIds);
	}
	
	
	/**
	 * this method returns groups for given device ids
	 * @param deviceIds
	 * @return
	 */
	public String listEdgeCoreGroupsForDeviceIds(List<String> deviceIds) 
	{
		return mListEdgeCoreGroups(deviceIds);
	}
	/**
	 * this method list deviceid for given groups
	 * @param grpIds
	 * @return
	 */
	public String listEdgeCoreForGroups(List<String> grpIds) 
	{
		return mListEdgeCoreForGroups(grpIds);
	}
	
	private String mAddEdgeCoreToGroup() 
	{
		StringBuilder sb = new StringBuilder();
		sb.append("INSERT INTO ");
		sb.append(PortalDBEnum.TABLE_NAMES.groupEdgeCore);
		sb.append(" ( ");
		sb.append(PortalDBEnum.GROUP_EDGECORE.groupEdgeCoreId.name());
		sb.append(", ");
		sb.append(PortalDBEnum.GROUP_EDGECORE.groupId.name());
		sb.append(", ");
		sb.append(PortalDBEnum.GROUP_EDGECORE.edgeCoreId.name());
		sb.append(" ) VALUES ( ");
		sb.append("?");
		//sb.append(dbCon.formatString(Common.getRandomId()));
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(groupId));
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(deviceId));
		sb.append(" ) ");
		return sb.toString();
	}

	private String mRemoveEdgeCoreFromGroup(String deviceId)
	{
		StringBuilder sb = new StringBuilder();
		sb.append("DELETE ");
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.groupEdgeCore);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.GROUP_EDGECORE.groupId.name());
		sb.append(" = ");
		sb.append("?");
		// sb.append(dbCon.formatString(groupId));
		// deviceId will be blank in case of delete group(where all device in
		// group are to be removed from group)
		if (!StringFunctions.isNullOrWhitespace(deviceId)) {
			sb.append(" AND ");
			sb.append(PortalDBEnum.GROUP_EDGECORE.edgeCoreId.name());
			sb.append(" = ");
			sb.append("?");
			// sb.append(dbCon.formatString(deviceId));
		}
		return sb.toString();
	}
	
	private String mListGroupEdgeCore() 
	{
		StringBuilder sb = new StringBuilder();
		sb.append("Select * ");
		sb.append(" FROM ");
		sb.append(PortalDBEnum.VIEW_NAMES.devicesnodes_view);

		sb.append(" INNER JOIN ");
		sb.append(PortalDBEnum.TABLE_NAMES.devicelabelmap);
		sb.append(" ON ");
		sb.append(PortalDBEnum.DEVICES_NODES_VIEW.devices_deviceId);
		sb.append(" = ");
		sb.append(PortalDBEnum.TABLE_NAMES.devicelabelmap);
		sb.append(".");
		sb.append(DEVICE_LABEL_MAP.deviceId);

		sb.append(" WHERE ");
		sb.append(PortalDBEnum.DEVICES_NODES_VIEW.devices_deviceId.name());
		sb.append(" IN ( SELECT ");
		sb.append(PortalDBEnum.TABLE_NAMES.groupEdgeCore);
		sb.append(".");
		sb.append(PortalDBEnum.GROUP_EDGECORE.edgeCoreId.name());
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.groupEdgeCore);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.GROUP_EDGECORE.groupId.name());
		sb.append(" = ");
		sb.append("?");
		// sb.append(dbCon.formatString(groupId));
		sb.append(") ");
		/*
		 * Add app status check (that only those app retrieve which have other
		 * status except DELETED)
		 */
		sb.append(" AND ");
		sb.append(DEVICES_NODES_VIEW.devices_deviceStatus);
		sb.append(" != ");
		sb.append("?");
		// sb.append(Status.DELETED.ordinal());

		sb.append(" ORDER BY ");
		sb.append(PortalDBEnum.DEVICES_NODES_VIEW.devices_deviceName);
		sb.append(" ASC ");
		return sb.toString();
	}
	
	private String mGetGroupEdgeCoreId() 
	{
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT ");
		sb.append(PortalDBEnum.GROUP_EDGECORE.groupEdgeCoreId.name());
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.groupEdgeCore);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.GROUP_EDGECORE.edgeCoreId.name());sb.append(" = ");
		sb.append("?");
		//sb.append(dbCon.formatString(deviceId));
		sb.append(" AND ");
		sb.append(PortalDBEnum.GROUP_EDGECORE.groupId.name());sb.append(" = ");
		sb.append("?");
//		sb.append(dbCon.formatString(groupId));
		return sb.toString();
	}
	
	private String mGetGroupsOfEdgeCore(List<String> groupIds) 
	{
		StringBuilder sb = new StringBuilder();
		
		SqlQueryBuilder queryBuilder = new SqlQueryBuilder();
		
		sb.append("SELECT ").append(PortalDBEnum.GROUP_EDGECORE.groupId.name()).append(" FROM ")
				.append(PortalDBEnum.TABLE_NAMES.groupEdgeCore).append(" WHERE ")
				.append(PortalDBEnum.GROUP_EDGECORE.edgeCoreId.name()).append(" = ")
				//.append(dbCon.formatString(deviceId));
				.append("?");
		if (groupIds != null && !groupIds.isEmpty()) {
			sb.append(" AND ").append(PortalDBEnum.GROUP_EDGECORE.groupId.name());
			queryBuilder.appendQueryIN(groupIds);
			sb.append(queryBuilder.getQuery().toString());
//			.append(" IN (")
//					.append(dbCon.formatStringForIn(groupIds)).append(")");
		}

		return sb.toString();
	}
	private String mListEdgeCoreGroups(List<String> deviceIds) 
	{
		
		SqlQueryBuilder queryBuilder = new SqlQueryBuilder();
		
		queryBuilder.appendQuery("SELECT ");
		queryBuilder.appendQuery(PortalDBEnum.GROUP_EDGECORE.groupId.name());
		queryBuilder.appendQuery(", ");
		queryBuilder.appendQuery(PortalDBEnum.GROUP_EDGECORE.edgeCoreId.name());
		queryBuilder.appendQuery(" FROM ");
		queryBuilder.appendQuery(PortalDBEnum.TABLE_NAMES.groupEdgeCore);
		queryBuilder.appendQuery(" WHERE ");
		queryBuilder.appendQuery(PortalDBEnum.GROUP_EDGECORE.edgeCoreId.name());
		
		queryBuilder.appendQueryIN(deviceIds);
//		queryBuilder.appendQuery(" IN( ");
//		queryBuilder.appendQuery(dbCon.formatStringForIn(deviceIds));
//		queryBuilder.appendQuery(")");
		
		return queryBuilder.getQuery().toString();
	}
	
	private String mListEdgeCoreForGroups(List<String> grpIds) 
	{
		SqlQueryBuilder queryBuilder = new SqlQueryBuilder();
		
		queryBuilder.appendQuery("SELECT ");
		queryBuilder.appendQuery(PortalDBEnum.GROUP_EDGECORE.edgeCoreId.name());
		queryBuilder.appendQuery(" FROM ");
		queryBuilder.appendQuery(PortalDBEnum.TABLE_NAMES.groupEdgeCore);
		queryBuilder.appendQuery(" WHERE ");
		queryBuilder.appendQuery(PortalDBEnum.GROUP_EDGECORE.groupId.name());
		
		queryBuilder.appendQueryIN(grpIds);
//		sb.append(" IN( ");
//		sb.append(dbCon.formatStringForIn(grpIds));
//		sb.append(")");
		
		return queryBuilder.getQuery().toString();
	}
	
	public static void main(String[] args)
	{
		try
		{
			//pkw user 8081fb5d72084cd5a8f62c1d41ed7c9f
		DevicesEngine dEngg = new DevicesEngine();
		String deviceId = "9807e1c411fa44cfa8a5a2d96b5ade3c";
		String groupId0 ="3136127db807431f9a9c63a7fe09a07a";
		String groupId ="898e33c634f84140a07f6ffa80bd2c78";
		List<String> groupIds = new ArrayList<>();
		groupIds.add(groupId0);
		groupIds.add(groupId);
		 dEngg.getUserId(deviceId);
		
		GroupsEngine gEngg = new GroupsEngine();
			
		gEngg.addEdgeCoreToGroup(deviceId, groupId);
		 gEngg.listGroupEdgeCore(groupId);
		 dEngg.listGroupsOfDevice(deviceId, groupIds);
		}
		catch (Exception e)
		{
			PALogger.ERROR(e.getMessage());
		}
	}


}
