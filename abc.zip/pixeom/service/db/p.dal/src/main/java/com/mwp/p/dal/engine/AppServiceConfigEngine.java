/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal.engine;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mwp.common.Common;
import com.mwp.common.CredProvider;
import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.common.constant.Constant;
import com.mwp.common.vo.PortVO;
import com.mwp.common.vo.QueryVO;
import com.mwp.common.vo.ServiceEndpointVO;
import com.mwp.logger.PALogger;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.dal.AppServiceConfigDB;
import com.mwp.p.dal.ApplicationServicePortDB;
import com.pa.crypto.StringEncryptionDecryption;

/**
 * This class executes queries related application service endpoints. 
 *
 */
public class AppServiceConfigEngine {

	/**
	 * check from name of endpoint and appId that is exist in db or not.
	 * @param appId
	 * @param endpointName
	 * @return
	 * @throws SQLException
	 */
	public boolean checkServiceEndpointAvailable(String appId, String endpointName) throws SQLException {
		return mCheckServiceEndpointAvailable(appId, endpointName);
	}

	/**
	 * check from name of endpoint and appId that is exist in db or not.
	 * @param appId
	 * @param endpointName
	 * @return
	 * @throws SQLException
	 */
	public ServiceEndpointVO getServiceEndpoint(String appId, String endpointName) throws SQLException {
		return mGetServiceEndpoint(appId, endpointName);
	}

	/**
	 * Reserve service endpoint for application.
	 * @param serviceEndpoint
	 * @return
	 * @throws SQLException
	 */
	public ServiceEndpointVO reserveServiceEndpoint(ServiceEndpointVO serviceEndpoint) throws SQLException {
		return mReserveServiceEndpoint(serviceEndpoint);
	}

	/**
	 * check application external port range exist between default port range,
	 * and port not assigned to another application.
	 * @param serviceEndpointVO
	 * @return
	 * @throws Exception
	 */
	public boolean checkPortRangeExist(List<PortVO> ports, String appId) throws Exception {
		boolean isPortRangeExist = false;
		List<String> listExternalPort = new ArrayList<>();
		for (PortVO portVO : ports) {
			int externalPort = portVO.getPort();
			if (externalPort < Constant.SERVICE_PORT_START_RANGE || externalPort > Constant.SERVICE_PORT_END_RANGE) {
				throw new Exception("port range not exist in default port range.");
			}
			listExternalPort.add(StringEncryptionDecryption.encrypt(String.valueOf(portVO.getPort()),
					new CredProvider().getEcnKey()));
		}

		String sql = new ApplicationServicePortDB().checkPortRangeExist(listExternalPort);

		//SqlArrayParam sqlArrayParam = new SqlArrayParam(listExternalPort.toArray(), SQLConstant.TYPE_NAME_VARCHAR);

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameters(listExternalPort).addParameter(appId).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {

			while (rs.next()) {
				isPortRangeExist = rs.getBoolean("isAvailable");
			}

		}
		return isPortRangeExist;
	}

	/**
	 * check application external port range exist between default port range,
	 * and port not assigned to another application.
	 * @param serviceEndpointVO
	 * @return
	 * @throws Exception
	 */
	public boolean checkPortRangeExist(String appId, int externalPort) throws Exception {
		boolean isPortRangeExist = false;
		List<String> listExternalPort = new ArrayList<>();
		/*
		 * check external port exist in default port range (55000 - 60000)
		 */
		// 55000 - Constants.SERVICE_PORT_START_RANGE
		// 60000 - Constants.SERVICE_PORT_END_RANGE
		if (externalPort < Constant.SERVICE_PORT_START_RANGE || externalPort > Constant.SERVICE_PORT_END_RANGE) {
			throw new Exception("port range not exist in default port range.");
		}
		listExternalPort
				.add(StringEncryptionDecryption.encrypt(String.valueOf(externalPort), new CredProvider().getEcnKey()));
		
		String sql = new ApplicationServicePortDB().checkPortRangeExist(listExternalPort);

		//SqlArrayParam sqlArrayParam = new SqlArrayParam(listExternalPort.toArray(), SQLConstant.TYPE_NAME_VARCHAR);

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameters(listExternalPort).addParameter(appId).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				isPortRangeExist = rs.getBoolean("isAvailable");
			}
		}
		return isPortRangeExist;
	}

	/**
	 * check from name of endpoint and appId that is exist in db or not.
	 * @param appId
	 * @param endpointName
	 * @return
	 * @throws SQLException
	 */
	private boolean mCheckServiceEndpointAvailable(String appId, String endpointName) throws SQLException {
		boolean isAvailable = false;
		String sql = new AppServiceConfigDB().checkServiceEndpointAvailable();

		List<String> parameters = new ArrayList<>();

		parameters.add(appId);
		parameters.add(endpointName);

		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(sql).addParameters(parameters).build();

		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)){
			while (rs.next()){
				isAvailable = rs.getBoolean("isAvailable");
			}
		}
		return isAvailable;
	}

	private ServiceEndpointVO mGetServiceEndpoint(String appId, String endpointName) throws SQLException {
		ServiceEndpointVO serviceEndpoint = new ServiceEndpointVO();
		String sql = new AppServiceConfigDB().getServiceEndpoint();

		List<String> parameters = new ArrayList<>();

		parameters.add(appId);
		parameters.add(endpointName);

		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(sql).addParameters(parameters).build();

		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)){
			while (rs.next()) {
				serviceEndpoint.setAppServiceEndpointId(rs.getString(PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.appServiceEndpointId.name()));
				serviceEndpoint.setAppVersionId(rs.getString(PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.appVersionId.name()));
				serviceEndpoint.setAppId(rs.getString(PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.appId.name()));
				serviceEndpoint.setPlatformId(rs.getString(PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.platformId.name()));
				serviceEndpoint.setContainerPort(rs.getInt(PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.containerPort.name()));
				serviceEndpoint.setCustomHeaders(rs.getString(PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.customHeaders.name()));
				serviceEndpoint.setImageName(rs.getString(PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.imageName.name()));
				serviceEndpoint.setProtocol(rs.getString(PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.protocol.name()));
				serviceEndpoint.setServiceName(rs.getString(PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.serviceName.name()));

				break;
			}
		}
		return serviceEndpoint;
	}

	/*
	 * Reserve service endpoint for application.
	 */
	private ServiceEndpointVO mReserveServiceEndpoint(ServiceEndpointVO serviceEndpoint) throws SQLException {
		serviceEndpoint.setAppServiceEndpointId(Common.getRandomId());
		
		String sql = new AppServiceConfigDB().reserveServiceEndpoint();

		List<Object> parameters = new ArrayList<>();

		parameters.add(serviceEndpoint.getAppServiceEndpointId());
		parameters.add(serviceEndpoint.getAppId());
		parameters.add("");
		parameters.add(serviceEndpoint.getPlatformId());
		parameters.add(serviceEndpoint.getServiceName());
		parameters.add(serviceEndpoint.getProtocol());
		parameters.add(serviceEndpoint.getContainerPort());
		parameters.add(serviceEndpoint.getImageName());
		parameters.add(serviceEndpoint.getCustomHeaders());
		
		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(sql).addParameters(parameters).build();

		int isAdd = PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
		if(isAdd == 0){
			throw new SQLException("ServiceEndpoint not added.");
		}
		return serviceEndpoint;
	}

	public void addApplicationServicePort(PortVO portVO){
		try {
			String sql = new ApplicationServicePortDB().getQueryForAddApplicationServicePort();

			List<Object> parameters1 = new ArrayList<>();

			parameters1.add(Common.getRandomId());
			parameters1.add(portVO.getAppVersionId());
			parameters1.add(portVO.getImageId());
			parameters1.add(portVO.getInternalPort());

			QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
					.appendQuery(sql).addParameters(parameters1).addParameterEncrypted(String.valueOf(portVO.getPort())).build();

			PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
		} catch (SQLException e) {
			PALogger.ERROR(e);	
		}
	}
}
