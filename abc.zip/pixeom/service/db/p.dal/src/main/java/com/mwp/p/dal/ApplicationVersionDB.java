/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.mwp.common.Common;
import com.mwp.common.StringFunctions;
import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.common.enums.StatusEnum.VERSION_STATUS;
import com.mwp.common.vo.PortVO;
import com.mwp.common.vo.QueryVO;
import com.mwp.common.vo.VersionVO;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.common.enums.PortalDBEnum.APPLICATION_VERSIONS;
import com.mwp.p.dal.engine.PortalDatabaseEngine;

/**
 * This class manage - add application version, application configuration YML file path. 
 * @author root
 *
 */
public class ApplicationVersionDB {

	/**
	 * Create query to get details of version from version db.
	 * @param appId
	 * @param versionId
	 * @return
	 */
	public String getVersionDetails() {
		return mGetVersionDetails();
	}
	
	/**
	 * Create query to get status of version from version db.
	 * @param appId
	 * @param versionId
	 * @return
	 */
	public String getVersionStatus() {
		return mGetVersionStatus();
	}

	/**
	 * Create query to get compose yml file path of version from version db.
	 * @param appId
	 * @param versionId
	 * @return
	 */
	public String getVersionComposeYMLPath(String versionId) {
		return mGetVersionComposeYMLPath(versionId);
	}
	
	public String getComposeVersion(String version) {
		return mGetComposeVersion(version);
	}
	/**
	 * This method gives latest version info for an application.
	 * @param appId
	 * @return
	 */
//	public String getLatestVersionOfApp(String appId) {
//		return mGetLatestVersionOfApp(appId, true);
//	}

	/**
	 * create application version, configuration, service end points in db.
	 * @param versionVO version object 
	 * @param ports list of ports
	 * @param projectId
	 * @return
	 * @throws SQLException 
	 */
	public List<QueryVO> createAppVersion(VersionVO versionVO, List<PortVO> ports, String projectId) throws SQLException {
		return mCreateAppVersion(versionVO, ports, projectId);
	}

	/**
	 * create query to get all versions of an application and platform
	 * @param appId
	 * @param appPlatformId
	 * @return
	 */
	public String getAllVersionNumbers() {
		return mGetAllVersionNumbers();
	}

	

	/**
	 * create query to change application version status according to given appversionId.
	 * @param appVersionId application version id 
	 * @param status new status
	 * @return
	 */
	public String changeAppVersionStatus() {
		return mChangeAppVersionStatus();
	}

	/**
	 * create query to change old application version status according to given appversionId.
	 * @param appVersionId
	 * @param status
	 * @return
	 */
	public String changeOldAppVersionStatus() {
		return mChangeOldAppVersionStatus();
	}

	/**
	 * Create query to get versions of an application
	 * @param appId
	 * @return
	 */
//	public String getVersionsOfApp(String appId) {
//		return mGetVersionsOfApp(appId);
//	}

	/**
	 * Create query to get version of app which status is LIVE. 
	 * @param appId
	 * @param appRepoId
	 * @return
	 */
	public String getLiveVersionOfApp(String appId, String appRepoId){
		return mGetLiveVersionOfApp(appId, appRepoId);
	}

	/**
	 * Create query to get all versions of an application
	 * @param appId
	 * @param userId
	 * @return
	 */
	public String getAllAppVersionByOwner(){
		return mGetAllAppVersionByOwner();
	}

	/**
	 * List of versions with permissions, if user only invited for app not for 
	 * version then list all version of that app with group permission
	 * @param appId : application id of invited or own app
	 * @param groupIds : comma separated string of group ids
	 * @return
	 */
	public String getVersionsOfGroupApp(String appPlatformId, String versionToCheck, int groupCount,
			List<VERSION_STATUS> filterVersionStstus){
		return mGetVersionsOfGroupApp(appPlatformId, versionToCheck, groupCount, filterVersionStstus);
	}

	/**
	 * create query to get all versions of application belong to group id.
	 * @param appId
	 * @param groupId
	 * @return
	 */
	public String groupAppVersionAvailable() {
		return mGroupAppVersionAvailable();
	}

	/**
	 * Delete all versions of application, images of application and service endpoints 
	 * @param appId
	 * @return
	 */
	public List<String> deleteVersion()
	{
		return mDeleteVersion();
	}
	
	/**
	 * this return query to get all latest version of all app on different platform
	 * @param pageNo
	 * @param pageSize
	 * @return
	 */
	public List<String> getAllLatestVersion()
	{
		return mGetAllLatestVersion();
	}

	

	private String mGetVersionDetails() {
		StringBuilder sb = new StringBuilder();
		sb.append("Select * ");
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.appId);
		sb.append(" = ");
		sb.append("?");
		sb.append(" AND ");
		sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.appVersionId);
		sb.append(" = ");
		sb.append("?");
		return sb.toString();
	}
	
	private String mGetVersionStatus() {
		StringBuilder sb = new StringBuilder();
		sb.append("Select ");
		sb.append(PortalDBEnum.APPLICATION_VERSIONS.versionStatus);		
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.appId);
		sb.append(" = ");
		sb.append("?");
		//sb.append(dbCon.formatString(appId));
		sb.append(" AND ");
		sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.appVersionId);
		sb.append(" = ");
		sb.append("?");
//		sb.append(dbCon.formatString(versionId));
		return sb.toString();
	}

	private String mGetVersionComposeYMLPath(String versionId) {
		StringBuilder sb = new StringBuilder();
		sb.append("Select ");
		sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.composerFilePath);
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.appId);
		sb.append(" = ");
		sb.append("?");

		if(StringFunctions.isNullOrWhitespace(versionId)){			
			sb.append(" AND ");
			sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.versionStatus.name());
			sb.append(" = ");sb.append(VERSION_STATUS.LIVE.ordinal());
		}
		else
		{
			sb.append(" AND ");
			sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.appVersionId);
			sb.append(" = ");
			sb.append("?");
		}
		return sb.toString();
	}
	
	private String mGetComposeVersion(String version) {
		StringBuilder sb = new StringBuilder();
		sb.append("Select ");
		sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.composeVersion);
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.appId);
		sb.append(" = ");
		sb.append("?");

		if(StringFunctions.isNullOrWhitespace(version)){			
			sb.append(" AND ");
			sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.versionStatus.name());
			sb.append(" = ");sb.append(VERSION_STATUS.LIVE.ordinal());
		}
		else
		{
			sb.append(" AND ");
			sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.appVersionId);
			sb.append(" = ");
			sb.append("?");
		}
		return sb.toString();
	}

//	private String mGetVersionsOfApp(String appId) {
//		return mGetLatestVersionOfApp(appId);
//	}

//	/**
//	 * If required all version of app then set isLatestReq = FALSE,
//	 * other it gives latest one row according to creation date.
//	 * @param appId
//	 * @param isLatestReq
//	 * @return
//	 */
//	private String mGetLatestVersionOfApp(String appId) {
//		StringBuilder sb = new StringBuilder();
//		sb.append("Select * ");
//		sb.append(" FROM ");
//		sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);
//		sb.append(" WHERE ");
//		sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);
//		sb.append(".");
//		sb.append(PortalDBEnum.APPLICATION_VERSIONS.appId);
//		sb.append(" = ");
//		sb.append(dbCon.formatString(appId));		
//		sb.append(" ORDER BY ");
//		sb.append(PortalDBEnum.APPLICATION_VERSIONS.createdDate);
//		sb.append(" DESC ");
//		
//		return sb.toString();
//	}

	private String mGetLiveVersionOfApp(String appId, String appPlatformId) {
		StringBuilder sb = new StringBuilder();
		sb.append("Select * ");
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);
		sb.append(".");
		sb.append(PortalDBEnum.APPLICATION_VERSIONS.appId);
		sb.append(" = ");
		sb.append("?");
//		sb.append(dbCon.formatString(appId));
		sb.append(" AND ");
		sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.appPlatformId);
		sb.append(" = ");
		sb.append("?");
//		sb.append(dbCon.formatString(appPlatformId));
		sb.append(" AND ");
		sb.append(PortalDBEnum.APPLICATION_VERSIONS.versionStatus);
		sb.append(" = ");
		sb.append(VERSION_STATUS.LIVE.ordinal());

		return sb.toString();
	}

	private List<QueryVO> mCreateAppVersion(VersionVO versionVO, List<PortVO> ports, String projectId)
			throws SQLException {
		List<QueryVO> listQuery = new ArrayList<>();

		listQuery.add(getQueryVOForAddAppVersion(versionVO, projectId));

		listQuery.add(getQueryForDeleteSerEndpointConfigEmpty(versionVO.getAppId()));

		for (PortVO portVO : ports) {
			portVO.setAppVersionId(versionVO.getVersionId());
			listQuery.add(getQueryForAddApplicationServicePort(portVO));
		}
		return listQuery;
	}

	private QueryVO getQueryForAddApplicationServicePort(PortVO portVO) throws SQLException {
		String sql = new ApplicationServicePortDB().getQueryForAddApplicationServicePort();

		List<Object> parameters1 = new LinkedList<>();

		parameters1.add(Common.getRandomId());
		parameters1.add(portVO.getAppVersionId());
		parameters1.add(portVO.getImageId());
		parameters1.add(portVO.getInternalPort());

		return new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(sql).addParameters(parameters1).addParameterEncrypted(String.valueOf(portVO.getPort()))
				.build();
	}

	private QueryVO getQueryVOForAddAppVersion(VersionVO versionVO, String projectId) throws SQLException {

		String sql = getQueryForAddAppVersion();
		return new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(sql).addParameter(versionVO.getVersionId()).addParameter(versionVO.getAppId())
				.addParameter(versionVO.getAppPlatformId()).addParameter(projectId)
				.addParameter(versionVO.getConfigYmlPath()).addParameter(versionVO.getVersionNumber())
				.addParameter(versionVO.getReleaseNote()).addParameter(versionVO.getSize())
				.addParameter(versionVO.getStatus().ordinal()).addParameter(versionVO.getRedirectUrl())
				.addParameter(versionVO.getRestRedirectUrl())
				.addParameter(StringUtils.join(versionVO.getToExecuteOrder(), ","))
				.addParameter(versionVO.getRedirectSection()).addParameter(versionVO.getRedirectType().getValue())
				.addParameter(versionVO.getComposeVersion()).build();
	}

	private QueryVO getQueryForDeleteSerEndpointConfigEmpty(String appId) throws SQLException {

		String sql = new AppServiceConfigDB().getQueryForDeleteSerEndpointConfigEmpty();
		return new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(sql).addParameter(appId).addParameter("").build();
	}

	private String mGetAllVersionNumbers() {
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT ");
		sb.append(PortalDBEnum.APPLICATION_VERSIONS.appVersion);
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.APPLICATION_VERSIONS.appId.name());
		sb.append(" = ");
		sb.append("?");
		//sb.append(dbCon.formatString(appId));
		sb.append(" AND ");
		sb.append(PortalDBEnum.APPLICATION_VERSIONS.appPlatformId.name());
		sb.append(" = ");
		sb.append("?");
//		sb.append(dbCon.formatString(appPlatformId));
		sb.append(" AND ");
		sb.append(PortalDBEnum.APPLICATION_VERSIONS.versionStatus.name());
		sb.append(" <> ");
		sb.append(VERSION_STATUS.UPLOADING.ordinal());
		return sb.toString();
	}

	private String mChangeAppVersionStatus() 
	{
		StringBuilder sb = new StringBuilder();
		sb.append("UPDATE ");
		sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);
		sb.append(" SET ");
		sb.append(PortalDBEnum.APPLICATION_VERSIONS.versionStatus.name());
		sb.append(" = ");
		sb.append("?");
		//sb.append(status.ordinal());
		sb.append(", ");
		sb.append(PortalDBEnum.APPLICATION_VERSIONS.modifiedDate.name());
		sb.append(" = NOW()");
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.APPLICATION_VERSIONS.appVersionId.name());
		sb.append(" = ");
		sb.append("?");
		//sb.append(dbCon.formatString(appVersionId));
		return sb.toString();
	}


	private String mChangeOldAppVersionStatus() {
		StringBuilder sb = new StringBuilder();
		sb.append("UPDATE ");
		sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);
		sb.append(" SET ");
		sb.append(PortalDBEnum.APPLICATION_VERSIONS.versionStatus.name());
		sb.append(" = ");
		sb.append("?");
		// sb.append(status.ordinal());
		sb.append(", ");
		sb.append(PortalDBEnum.APPLICATION_VERSIONS.modifiedDate.name());
		sb.append(" = NOW()");
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.APPLICATION_VERSIONS.appId.name());
		sb.append(" = ");
		sb.append("?");
		// sb.append(dbCon.formatString(appId));
		sb.append(" AND ");
		sb.append(PortalDBEnum.APPLICATION_VERSIONS.appPlatformId.name());
		sb.append(" = ");
		sb.append("?");
		// sb.append(dbCon.formatString(appPlatformId));
		sb.append(" AND ");
		sb.append(PortalDBEnum.APPLICATION_VERSIONS.versionStatus.name());
		sb.append(" = ");
		sb.append("?");
		// sb.append(VERSION_STATUS.LIVE.ordinal());
		return sb.toString();
	}

	private String mGetAllAppVersionByOwner() {
		StringBuilder sb = new StringBuilder();
		sb.append("Select * ");
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);
		sb.append(" INNER JOIN ");
		sb.append(PortalDBEnum.TABLE_NAMES.application);
		sb.append(" AS app ON app.");sb.append(PortalDBEnum.APPLICATION.appId);
		sb.append(" = ");
		sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION.appId);

		sb.append(" WHERE ");
		sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.appId);
		sb.append(" = ");
		sb.append("?");
		sb.append(" AND ");
		sb.append(" app.");sb.append(PortalDBEnum.APPLICATION.userId);
		sb.append(" = ");
		sb.append("?");
		sb.append(" ORDER BY ");
		sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.createdDate);
		sb.append(" DESC ");
		return sb.toString();
	}

	private String getQueryForAddAppVersion(){
		StringBuilder sb = new StringBuilder();
		sb.append("INSERT INTO ");
		sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);
		sb.append(" ( ");
		sb.append(PortalDBEnum.APPLICATION_VERSIONS.appVersionId.name());
		sb.append(", ");
		sb.append(PortalDBEnum.APPLICATION_VERSIONS.appId.name());
		sb.append(", ");
		sb.append(PortalDBEnum.APPLICATION_VERSIONS.appPlatformId.name());
		sb.append(", ");
		sb.append(PortalDBEnum.APPLICATION_VERSIONS.projectId.name());
		sb.append(", ");
		sb.append(PortalDBEnum.APPLICATION_VERSIONS.composerFilePath.name());
		sb.append(", ");
		sb.append(PortalDBEnum.APPLICATION_VERSIONS.appVersion.name());
		sb.append(", ");
		sb.append(PortalDBEnum.APPLICATION_VERSIONS.releaseNotes.name());
		sb.append(", ");
		sb.append(PortalDBEnum.APPLICATION_VERSIONS.size.name());
		sb.append(", ");
		sb.append(PortalDBEnum.APPLICATION_VERSIONS.versionStatus.name());
		sb.append(", ");
		//AKH_02
		sb.append(PortalDBEnum.APPLICATION_VERSIONS.redirectUrl.name());
		sb.append(", ");
		sb.append(PortalDBEnum.APPLICATION_VERSIONS.restRedirectUrl.name());
		sb.append(", ");
		sb.append(PortalDBEnum.APPLICATION_VERSIONS.toExecuteOrder.name());
		sb.append(", ");
		sb.append(PortalDBEnum.APPLICATION_VERSIONS.redirectSection.name());
		sb.append(", ");
		sb.append(PortalDBEnum.APPLICATION_VERSIONS.redirectType.name());
		sb.append(", ");
		sb.append(PortalDBEnum.APPLICATION_VERSIONS.composeVersion.name());
		sb.append(", ");
		sb.append(PortalDBEnum.APPLICATION_VERSIONS.modifiedDate.name());
		sb.append(", ");
		sb.append(PortalDBEnum.APPLICATION_VERSIONS.createdDate.name());
		sb.append(" ) VALUES ( ");
		sb.append("?");
		//sb.append(dbCon.formatString(versionVO.getVersionId()));
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(versionVO.getAppId()));
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(versionVO.getAppPlatformId()));
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(projectId));
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(versionVO.getConfigYmlPath()));
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(versionVO.getVersionNumber()));
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(versionVO.getReleaseNote()));
		sb.append(", ");
		sb.append("?");
//		sb.append(versionVO.getSize());
		sb.append(", ");
		sb.append("?");
//		sb.append(versionVO.getStatus().ordinal());
		sb.append(", ");
		sb.append("?");
//		sb.append(PortalDatabaseEngine.getInstance().getConnection().formatString(versionVO.getRedirectUrl()));
		sb.append(", ");
		sb.append("?");
//		sb.append(PortalDatabaseEngine.getInstance().getConnection().formatString(versionVO.getRestRedirectUrl()));
		sb.append(", ");
		sb.append("?");
//		sb.append(PortalDatabaseEngine.getInstance().getConnection().formatString(StringUtils.join(versionVO.getToExecuteOrder(), ",")));
		sb.append(", ");
		sb.append("?");
//		sb.append(PortalDatabaseEngine.getInstance().getConnection().formatString(versionVO.getRedirectSection()));
		sb.append(", ");
		sb.append("?");
//		sb.append(versionVO.getRedirectType().getValue());
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(versionVO.getComposeVersion()));
		sb.append(", ");
		sb.append(" NOW()");
		sb.append(", ");
		sb.append(" NOW()");
		sb.append(" ) ");
		return sb.toString();
	}

	private String mGetVersionsOfGroupApp(String appPlatformId, String versionToCheck, int groupCount,
			List<VERSION_STATUS> filterVersionStstus) {
		SqlQueryBuilder queryBuilder = new SqlQueryBuilder();
		
		queryBuilder.appendQuery("SELECT * FROM applicationversions as a1, ")
				.appendQuery("(SELECT a.groupId, a.appId, b.appVersionId ")
				.appendQuery("FROM groupapplications a LEFT JOIN groupapplicationversions b ")
				.appendQuery("ON a.groupAppId = b.groupAppId ").appendQuery("WHERE a.appId = ").appendQuery("?")
				// .append(dbCon.formatString(appId))
				.appendQuery(" and b.appVersionId is not null ").appendQuery("and a.groupId ").appendQueryIN(groupCount)
				// .append(dbCon.formatStringForIn(groupIds)).append(") ")
				.appendQuery("UNION SELECT b.groupId,b.appId,a.appVersionId ")
				.appendQuery("FROM applicationversions a, (select distinct a.groupId, a.appId ")
				.appendQuery("FROM groupapplications a LEFT JOIN groupapplicationversions b ")
				.appendQuery("ON a.groupAppId = b.groupAppId ").appendQuery("WHERE a.appId = ").appendQuery("?")
				// .append(dbCon.formatString(appId))
				.appendQuery(" AND b.appVersionId is null and a.groupId ").appendQueryIN(groupCount)
				// .append(dbCon.formatStringForIn(groupIds)).append(")) ")
				.appendQuery(" ) b WHERE a.appId = b.appId) as b1 ")
				.appendQuery("WHERE a1.appVersionId = b1.appVersionId");
		
		if (!StringFunctions.isNullOrWhitespace(versionToCheck)) {
			queryBuilder.appendQuery(" AND ");
			queryBuilder.appendQuery(" a1.");
			queryBuilder.appendQuery(PortalDBEnum.APPLICATION_VERSIONS.createdDate);
			queryBuilder.appendQuery(" > ");
			queryBuilder.appendQuery("(SELECT createdDate from applicationversions where appVersionId = ");
			queryBuilder.appendQuery("?");
			// sb.append(dbCon.formatString(versionToCheck))
			queryBuilder.appendQuery(")");

		}
		
		if (!StringFunctions.isNullOrWhitespace(appPlatformId)) {
			queryBuilder.appendQuery(" AND " + APPLICATION_VERSIONS.appPlatformId + " = ").appendQuery("?");
		}

		if(filterVersionStstus != null && !filterVersionStstus.isEmpty() ){
			queryBuilder.appendQuery(" AND ").appendQuery(APPLICATION_VERSIONS.versionStatus)
					.appendQueryIN(filterVersionStstus);
		}
		
		queryBuilder.appendQuery(" ORDER BY a1.createdDate DESC");
		return queryBuilder.getQuery().toString();
	}
	
	public static void main(String[] args)
	{
		//new ApplicationVersionDB().mGetVersionsOfGroupApp("fgfgfgfg", "etrrtrtrtrt", 3, 6);
	}

	private String mGroupAppVersionAvailable() {
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT groupAppId FROM groupapplicationversions WHERE groupAppId = ")
				.append("(SELECT groupAppId FROM groupapplications WHERE groupId = ")
				.append("?")
				//.append(dbCon.formatString(groupId))
				.append(" AND appId = ")
				.append("?" + ")");
		return sb.toString();
	}

	private List<String> mDeleteVersion()
	{
		List< String> lstQueries=new ArrayList<>();
		StringBuilder sb = new StringBuilder();
		sb.append("DELETE FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.APPLICATION_VERSIONS.appId);
		sb.append(" = ");
		sb.append("?");
		//sb.append(dbCon.formatString(appId));
		lstQueries.add(sb.toString());

		StringBuilder sb2 = new StringBuilder();
		sb2.append("DELETE FROM ");
		sb2.append(PortalDBEnum.TABLE_NAMES.applicationimages);
		sb2.append(" WHERE ");
		sb2.append(PortalDBEnum.APPLICATION_IMAGES.appId);
		sb2.append(" = ");
		sb.append("?");
//		sb2.append(dbCon.formatString(appId));
		lstQueries.add(sb2.toString());

		StringBuilder sb3 = new StringBuilder();
		sb3.append("DELETE FROM ");
		sb3.append(PortalDBEnum.TABLE_NAMES.applicationserviceendpoints);
		sb3.append(" WHERE ");
		sb3.append(PortalDBEnum.APPLICATION_SERVICE_ENDPOINTS.appId);
		sb3.append(" = ");
		sb.append("?");
//		sb3.append(dbCon.formatString(appId));
		lstQueries.add(sb3.toString());

		return lstQueries;
	}
	
//	private String mLatestVersion() {
//		StringBuilder sb = new StringBuilder();
//		sb.append("Select * ");
//		sb.append(" FROM ");
//		sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);
//		sb.append(" INNER JOIN ");
//		sb.append(PortalDBEnum.TABLE_NAMES.application);
//		sb.append(" AS app ON app.");sb.append(PortalDBEnum.APPLICATION.appId);
//		sb.append(" = ");
//		sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.appId);
//		sb.append(" GROUP BY ");
//		sb.append("app");sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.appId);
//		sb.append(" ORDER BY ");
//		sb.append(" INET_ATON(SUBSTRING_INDEX(CONCAT(appVersion,'.0.0.0'),'.',4)) DESC");
//
//		return sb.toString();
//	}
	
	private List<String> mGetAllLatestVersion()
	{
		List<String> queries = new ArrayList<>();
		StringBuilder sb = new StringBuilder();
		sb.append("Select SQL_CALC_FOUND_ROWS ");
		sb.append(PortalDBEnum.TABLE_NAMES.application);sb.append(".");sb.append(PortalDBEnum.APPLICATION.appId);
		sb.append(", ");
		sb.append(PortalDBEnum.TABLE_NAMES.application);sb.append(".");sb.append(PortalDBEnum.APPLICATION.icon);
		sb.append(", ");
		sb.append(PortalDBEnum.TABLE_NAMES.application);sb.append(".");sb.append(PortalDBEnum.APPLICATION.appTypeId);
		sb.append(", ");
		sb.append(PortalDBEnum.TABLE_NAMES.application);sb.append(".");sb.append(PortalDBEnum.APPLICATION.webAddress);
		sb.append(", ");
		sb.append(PortalDBEnum.TABLE_NAMES.application);sb.append(".");sb.append(PortalDBEnum.APPLICATION.title);
		sb.append(", max(");
		sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.appVersion);
		sb.append(") as versionNumber,");
		sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.appPlatformId);
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.application);
		sb.append(" INNER JOIN ");
		sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);
		sb.append(" ON ");
		sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);
		sb.append(".");
		sb.append(PortalDBEnum.APPLICATION_VERSIONS.appId);
		sb.append(" = ");
		sb.append(PortalDBEnum.TABLE_NAMES.application);sb.append(".");sb.append(PortalDBEnum.APPLICATION.appId);
		sb.append(" GROUP BY ");
		sb.append(PortalDBEnum.TABLE_NAMES.application);sb.append(".");sb.append(PortalDBEnum.APPLICATION.appId);
		sb.append(",");
		sb.append(PortalDBEnum.TABLE_NAMES.applicationversions);sb.append(".");sb.append(PortalDBEnum.APPLICATION_VERSIONS.appPlatformId);
		sb.append(" limit ");
		sb.append("?");
		sb.append(" offset ");
		sb.append("?");
		queries.add(sb.toString());
		queries.add("SELECT FOUND_ROWS() as rowCount");
		return queries;
	}
	
}

/**
 * History of check-in or issue resolved
 * 
 * 01 - 18-10-2016 
 * AKH_01_1
 * Remove OrderBy from created date because it is orderby versions (Major/Minor/Patch) max value (RA Sir). 
 * 
 * 02 - 14-11-2016 AKH_02
 * Add restRedirectUrl, redirectUrl, redirectType and redirectSection these property shift from application to applicationVersion,
 * because may be each version have different redirection param.
 */