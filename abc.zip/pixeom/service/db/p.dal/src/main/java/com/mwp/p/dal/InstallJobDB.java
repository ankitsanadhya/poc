/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal;

import java.util.List;

import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.common.enums.InstallJobStatusEnum;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.common.enums.PortalDBEnum.APP_SECRET;
import com.mwp.p.common.enums.PortalDBEnum.APP_SECRET_VERSION;
import com.mwp.p.common.enums.PortalDBEnum.JOB_SECRET;

/**
 * This class create queries related to table installJobs 
 */
public class InstallJobDB
{
	/**
	 * Query to add new job to database 
	 * @param installJobVO
	 * @return
	 */
	public String insertJob()
	{
		StringBuilder sb =  new StringBuilder();
		sb.append("INSERT INTO ");
		sb.append(PortalDBEnum.TABLE_NAMES.installJobs);
		sb.append("(");
		sb.append(PortalDBEnum.INSTALL_JOBS.uId.name());
		sb.append(",");
		sb.append(PortalDBEnum.INSTALL_JOBS.objectId.name());
		sb.append(",");
		sb.append(PortalDBEnum.INSTALL_JOBS.type.name());
		sb.append(",");
		sb.append(PortalDBEnum.INSTALL_JOBS.timeStamp.name());
		sb.append(",");
		sb.append(PortalDBEnum.INSTALL_JOBS.status.name());
		sb.append(",");
		sb.append(PortalDBEnum.INSTALL_JOBS.userId.name());
		sb.append(",");
		sb.append(PortalDBEnum.INSTALL_JOBS.appId.name());
		sb.append(",");
		sb.append(PortalDBEnum.INSTALL_JOBS.operation.name());
		sb.append(",");
		sb.append(PortalDBEnum.INSTALL_JOBS.appVersion.name());
		sb.append(",");
		sb.append(PortalDBEnum.INSTALL_JOBS.message.name());
		sb.append(",");
		sb.append(PortalDBEnum.INSTALL_JOBS.detail.name());
		sb.append(")  VALUES (");
		sb.append("?");
		sb.append(",");	
		sb.append("?");
		sb.append(",");
		sb.append("?");
		sb.append(",");
		sb.append("?");
		sb.append(",");
		sb.append("?");
		sb.append(",");
		sb.append("?");
		sb.append(",");
		sb.append("?");
		sb.append(",");
		sb.append("?");
		sb.append(",");
		sb.append("?");
		sb.append(",");
		sb.append("?");
		sb.append(",");
		sb.append("?");
		sb.append(")");
		return sb.toString();
	}

	/**
	 * Query to update satus of job
	 * @param jobId
	 * @param status
	 * @return
	 */
	public String updateJobStatus()
	{
		StringBuilder sb =  new StringBuilder();
		sb.append("UPDATE ");
		sb.append(PortalDBEnum.TABLE_NAMES.installJobs);
		sb.append(" SET ");	

		sb.append(PortalDBEnum.INSTALL_JOBS.status.name());
		sb.append(" = ");
		sb.append("?");
		sb.append(" WHERE ");

		sb.append(PortalDBEnum.INSTALL_JOBS.uId.name());
		sb.append(" = ");
		sb.append("?");

		return sb.toString();
	}

	/**
	 * Update job status and timestamp of job
	 * @param jobId
	 * @param status
	 * @param timestamp
	 * @return
	 */
	public String updateJobStatusAndTimestamp()
	{
		StringBuilder sb =  new StringBuilder();
		sb.append("UPDATE ");
		sb.append(PortalDBEnum.TABLE_NAMES.installJobs);
		sb.append(" SET ");	

		sb.append(PortalDBEnum.INSTALL_JOBS.timeStamp.name());
		sb.append(" = ");
		sb.append("?");
		//		sb.append(timestamp);
		sb.append(",");

		sb.append(PortalDBEnum.INSTALL_JOBS.status.name());
		sb.append(" = ");
		sb.append("?");
		//		sb.append(status.getValue());
		sb.append(" WHERE ");

		sb.append(PortalDBEnum.INSTALL_JOBS.uId.name());
		sb.append(" = ");
		sb.append("?");
		//		sb.append(dbCon.formatString(jobId));

		return sb.toString();
	}

	/**
	 * Update job timestamp scheduled ticks to perform job.
	 * @param jobIds
	 * @param timeStamp scheduled ticks to perform job.
	 * @return
	 */
	public String updateJobTimeStamp(int size)
	{	
		SqlQueryBuilder builder = new SqlQueryBuilder();

		builder.appendQuery("UPDATE ");
		builder.appendQuery(PortalDBEnum.TABLE_NAMES.installJobs);
		builder.appendQuery(" SET ");	
		builder.appendQuery(PortalDBEnum.INSTALL_JOBS.timeStamp.name());
		builder.appendQuery(" = ");
		builder.appendQuery("?");
		builder.appendQuery(" WHERE ");
		builder.appendQuery(PortalDBEnum.INSTALL_JOBS.uId.name());

		builder.appendQueryIN(size);
		//		sb.append(" IN (");
		//		sb.append("?");
		//		sb.append(" ) ");
		return builder.getQuery().toString();
	}

	/**
	 * Get all the jobs of a user
	 * @param userId
	 * @param grpIds
	 * @return
	 */
	public String getAllJobs(List<String> grpIds)	
	{
		String query = " SELECT " + PortalDBEnum.TABLE_NAMES.installJobs  + ".*, "  
				+ PortalDBEnum.TABLE_NAMES.application + "." + PortalDBEnum.APPLICATION.title+","
				+ PortalDBEnum.TABLE_NAMES.application + "." + PortalDBEnum.APPLICATION.icon
				+ " FROM " + PortalDBEnum.TABLE_NAMES.installJobs 
				+ " LEFT JOIN  " 
				+ PortalDBEnum.TABLE_NAMES.application
				+ " ON "
				+ PortalDBEnum.TABLE_NAMES.application + "." + PortalDBEnum.APPLICATION.appId + " = "
				+ PortalDBEnum.TABLE_NAMES.installJobs  + "." +  PortalDBEnum.INSTALL_JOBS.appId 
				+ " LEFT JOIN  " 
				+ PortalDBEnum.TABLE_NAMES.groupEdgeCore
				+ " ON "
				+ PortalDBEnum.TABLE_NAMES.groupEdgeCore + "." + PortalDBEnum.GROUP_EDGECORE.edgeCoreId + " = "
				+ PortalDBEnum.TABLE_NAMES.installJobs  + "." +  PortalDBEnum.INSTALL_JOBS.objectId 
				+ " WHERE " + PortalDBEnum.TABLE_NAMES.installJobs  + "." + PortalDBEnum.INSTALL_JOBS.userId.name()+ " = ?";
		if(grpIds!= null && !grpIds.isEmpty())
		{
			query +=" OR " +  PortalDBEnum.TABLE_NAMES.groupEdgeCore + "." + PortalDBEnum.GROUP_EDGECORE.groupId;
			SqlQueryBuilder queryBuilder = new SqlQueryBuilder();
			queryBuilder.appendQueryIN(grpIds);

			query += queryBuilder.getQuery().toString();
		}
		return query;
	}



	/**
	 * delete a job of user
	 * @param jobIds
	 * @return
	 */
	public String deleteJob(int i)	
	{
		SqlQueryBuilder queryBuilder = new SqlQueryBuilder();
		queryBuilder.appendQuery("DELETE FROM " + PortalDBEnum.TABLE_NAMES.installJobs);
		queryBuilder.appendQuery(" WHERE " );
		queryBuilder.appendQuery(PortalDBEnum.INSTALL_JOBS.uId.name());
		queryBuilder.appendQueryIN(i);
		//		sb.append(" IN (");
		//		sb.append("?");
		//		sb.append(" ) ");
		return queryBuilder.getQuery().toString();
	}

	/**
	 * Delete job with which have Status = status if status is not equal to  UNASSIGNED
	 * @param userId
	 * @param status
	 * @return
	 */
	public String deleteJob(String userId, InstallJobStatusEnum status)	
	{
		StringBuilder sb = new StringBuilder();
		sb.append("DELETE FROM " + PortalDBEnum.TABLE_NAMES.installJobs);
		sb.append(" WHERE " + PortalDBEnum.INSTALL_JOBS.userId.name() + " = ?");
		if (status != InstallJobStatusEnum.UNASSIGNED) {
			sb.append(" AND ");
			sb.append(PortalDBEnum.INSTALL_JOBS.status.name());
			sb.append(" = ");
			sb.append(status.ordinal());
		}
		return sb.toString();
	}

	/**
	 * Delete all jobs related to a devices objectId
	 * @param objectId device id
	 * @param userId
	 * @return
	 */
	public String deleteAllJobs()	
	{		
		StringBuilder sb = new StringBuilder();
		sb.append("DELETE FROM " + PortalDBEnum.TABLE_NAMES.installJobs);
		sb.append(" WHERE " + PortalDBEnum.INSTALL_JOBS.userId.name() + " = ?");
		sb.append(" AND ");
		sb.append(PortalDBEnum.INSTALL_JOBS.objectId.name());
		sb.append(" = ");
		sb.append("?");		
		return sb.toString();
	}

	/**
	 * Get all jobs for an application to a device objectId.
	 * @param userid user id
	 * @param appid application 
	 * @param objectid device id
	 * @return
	 */
	public String getJobs(String userid, String appid, String objectid )	
	{
		String query = "SELECT * FROM " + PortalDBEnum.TABLE_NAMES.installJobs;
		query += " Where "+	PortalDBEnum.INSTALL_JOBS.objectId.name()+" = ?"+" and "+
				PortalDBEnum.INSTALL_JOBS.userId.name()+" = ?"+" and "+
				PortalDBEnum.INSTALL_JOBS.appId.name()+" = ?";
		return query;
	}

	/**
	 * Get all jobs with status PENDING 
	 * @return
	 */
	public String getAllPendingJobs() {
		String query = "SELECT * FROM " + PortalDBEnum.TABLE_NAMES.installJobs;
		query += " Where " + PortalDBEnum.INSTALL_JOBS.status.name() + " = " + InstallJobStatusEnum.PENDING.getValue();
		return query;
	}

	/**
	 * Get all pending jobs of a device  for a user using table appSecret, appSecretVersion, installJobs, jobSecret with deviceId where condition 
	 * @return
	 */
	public String getAllPendingJobsByDeviceId()
	{
		return mGetAllPendingJobs(false); 
	}

	/**
	 * Get all pending jobs of a device  for a user using table appSecret, appSecretVersion, installJobs, jobSecret  with deviceId and userid where condition
	 * @return
	 */
	public String getAllPendingJobsByUserNDeviceId() {
		return mGetAllPendingJobs(true);
	}

	/**
	 * Get all pending jobs of a device  for a user using table appSecret, appSecretVersion, installJobs, jobSecret.
	 * @return
	 */
	private String mGetAllPendingJobs(boolean addUserIdCondition)
	{
		StringBuilder colList = new StringBuilder();
		colList.append(PortalDBEnum.TABLE_NAMES.installJobs);
		colList.append(".");
		colList.append(PortalDBEnum.INSTALL_JOBS.uId.name());
		colList.append(",");
		colList.append(PortalDBEnum.TABLE_NAMES.installJobs);
		colList.append(".");
		colList.append(PortalDBEnum.INSTALL_JOBS.objectId.name());
		colList.append(",");
		colList.append(PortalDBEnum.TABLE_NAMES.installJobs);
		colList.append(".");
		colList.append(PortalDBEnum.INSTALL_JOBS.type.name());
		colList.append(",");
		colList.append(PortalDBEnum.TABLE_NAMES.installJobs);
		colList.append(".");
		colList.append(PortalDBEnum.INSTALL_JOBS.timeStamp.name());
		colList.append(",");
		colList.append(PortalDBEnum.TABLE_NAMES.installJobs);
		colList.append(".");
		colList.append(PortalDBEnum.INSTALL_JOBS.status.name());
		colList.append(",");
		colList.append(PortalDBEnum.TABLE_NAMES.installJobs);
		colList.append(".");
		colList.append(PortalDBEnum.INSTALL_JOBS.userId.name());
		colList.append(",");
		colList.append(PortalDBEnum.TABLE_NAMES.installJobs);
		colList.append(".");
		colList.append(PortalDBEnum.INSTALL_JOBS.appId.name());
		colList.append(",");
		colList.append(PortalDBEnum.TABLE_NAMES.installJobs);
		colList.append(".");
		colList.append(PortalDBEnum.INSTALL_JOBS.operation.name());
		colList.append(",");
		colList.append(PortalDBEnum.TABLE_NAMES.installJobs);
		colList.append(".");
		colList.append(PortalDBEnum.INSTALL_JOBS.appVersion.name());
		colList.append(",");
		colList.append(PortalDBEnum.TABLE_NAMES.installJobs);
		colList.append(".");
		colList.append(PortalDBEnum.INSTALL_JOBS.message.name());
		colList.append(",");
		colList.append(PortalDBEnum.TABLE_NAMES.installJobs);
		colList.append(".");
		colList.append(PortalDBEnum.INSTALL_JOBS.detail.name());
		colList.append(",");
		colList.append(PortalDBEnum.TABLE_NAMES.installJobs);
		colList.append(".");
		colList.append(PortalDBEnum.INSTALL_JOBS.lastModified.name());


		colList.append(",");
		colList.append(PortalDBEnum.TABLE_NAMES.appSecret);
		colList.append(".");
		colList.append(APP_SECRET.appSecretId.name());
		colList.append(",");
		colList.append(PortalDBEnum.TABLE_NAMES.appSecret);
		colList.append(".");		
		colList.append( APP_SECRET.appId.name() );
		colList.append(",");
		colList.append(PortalDBEnum.TABLE_NAMES.appSecret);
		colList.append(".");
		colList.append( APP_SECRET.secretKey.name());
		colList.append(",");
		colList.append(PortalDBEnum.TABLE_NAMES.appSecretVersion);
		colList.append(".");
		colList.append( APP_SECRET_VERSION.type.name());
		colList.append(",");
		colList.append(PortalDBEnum.TABLE_NAMES.appSecretVersion);
		colList.append(".");
		colList.append( APP_SECRET_VERSION.appSecretVersionId.name()); 
		colList.append(",");
		colList.append(PortalDBEnum.TABLE_NAMES.appSecretVersion);
		colList.append(".");
		colList.append( APP_SECRET_VERSION.displayName.name()); 
		colList.append(",");
		colList.append(PortalDBEnum.TABLE_NAMES.appSecretVersion);
		colList.append(".");
		colList.append( APP_SECRET_VERSION.secretValue.name()); 
		colList.append(",");
		colList.append(PortalDBEnum.TABLE_NAMES.appSecretVersion);
		colList.append(".");
		colList.append( APP_SECRET_VERSION.appUserId.name()); 
		colList.append(",");
		colList.append(PortalDBEnum.TABLE_NAMES.appSecretVersion);
		colList.append(".");
		colList.append( APP_SECRET_VERSION.createdDate.name());
		colList.append(",");
		colList.append(PortalDBEnum.TABLE_NAMES.appSecretVersion);
		colList.append(".");
		colList.append(APP_SECRET_VERSION.modifiedDate.name());
		colList.append(",");
		colList.append(PortalDBEnum.TABLE_NAMES.jobSecret);
		colList.append(".");
		colList.append(JOB_SECRET.serviceName.name()); 


		//join app secret and job secret
		//list app secrets
		//select * from appSecret left join jobSecrets on appsecret.appsecretId = jobSecret.appSecretId where appSecret.appId= appId and jobSecrets.edgeCoreId= devcieId

		StringBuilder query = new StringBuilder();
		query.append("SELECT ");
		query.append(colList);
		query.append(" FROM ");
		query.append( PortalDBEnum.TABLE_NAMES.installJobs );
		query.append(" LEFT JOIN ");
		query.append( PortalDBEnum.TABLE_NAMES.jobSecret );
		query.append(" ON (");
		query.append( PortalDBEnum.TABLE_NAMES.installJobs );
		query.append(".");
		query.append(PortalDBEnum.INSTALL_JOBS.objectId.name());
		query.append(" = ");
		query.append( PortalDBEnum.TABLE_NAMES.jobSecret );
		query.append(".");
		query.append(PortalDBEnum.JOB_SECRET.edgeCoreId.name());
		query.append(" AND ");
		query.append( PortalDBEnum.TABLE_NAMES.installJobs );
		query.append(".");
		query.append(PortalDBEnum.INSTALL_JOBS.uId.name());
		query.append(" = ");
		query.append( PortalDBEnum.TABLE_NAMES.jobSecret );
		query.append(".");
		query.append( PortalDBEnum.JOB_SECRET.jobId.name());
		query.append( ")");
		query.append(" LEFT JOIN ");
		query.append(PortalDBEnum.TABLE_NAMES.appSecret);
		query.append(" ON (");

		query.append( PortalDBEnum.TABLE_NAMES.appSecret );
		query.append(".");
		query.append( PortalDBEnum.APP_SECRET.appId.name());
		query.append(" = ");
		query.append( PortalDBEnum.TABLE_NAMES.installJobs );
		query.append(".");
		query.append(PortalDBEnum.INSTALL_JOBS.appId.name());
		query.append( ")");
		query.append(" LEFT JOIN ");
		query.append(PortalDBEnum.TABLE_NAMES.appSecretVersion);
		query.append(" ON (");
		query.append( PortalDBEnum.TABLE_NAMES.appSecretVersion );
		query.append(".");
		query.append(PortalDBEnum.APP_SECRET_VERSION.appSecretId.name());
		query.append(" = ");
		query.append( PortalDBEnum.TABLE_NAMES.appSecret );
		query.append(".");
		query.append( PortalDBEnum.APP_SECRET.appSecretId.name() );
		query.append(" AND ");
		query.append( PortalDBEnum.TABLE_NAMES.appSecretVersion );
		query.append(".");
		query.append( PortalDBEnum.APP_SECRET_VERSION.appSecretVersionId.name());
		query.append(" = ");
		query.append( PortalDBEnum.TABLE_NAMES.jobSecret );
		query.append(".");
		query.append(PortalDBEnum.JOB_SECRET.appSecretVersionId.name());
		query.append( ")");


		query.append(" Where ");
		query.append( PortalDBEnum.TABLE_NAMES.installJobs );
		query.append(".");
		query.append(PortalDBEnum.INSTALL_JOBS.status.name());
		query.append(" = ");
		query.append(InstallJobStatusEnum.PENDING.getValue());
		query.append(" AND ");
		query.append( PortalDBEnum.TABLE_NAMES.installJobs );
		query.append(".");
		query.append(PortalDBEnum.INSTALL_JOBS.objectId.name());
		query.append(" = " );
		query.append("?");
		
		if(addUserIdCondition)
		{
			query.append(" AND ");
			query.append( PortalDBEnum.TABLE_NAMES.installJobs );
			query.append(".");
			query.append(PortalDBEnum.INSTALL_JOBS.userId.name());
			query.append(" = ");
			query.append("?");
		}
		
		query.append("  ORDER BY ");
		query.append( PortalDBEnum.TABLE_NAMES.installJobs );
		query.append(".");
		query.append(PortalDBEnum.INSTALL_JOBS.timeStamp.name());
		query.append(" ASC");


		return query.toString();
	}

	/**
	 * Update status of a job  
	 * @param jobId
	 * @param status
	 * @return
	 */
	public String mUpdateStatus(InstallJobStatusEnum status)
	{
		StringBuilder sb =  new StringBuilder();
		sb.append("UPDATE ");
		sb.append(PortalDBEnum.TABLE_NAMES.installJobs);
		sb.append(" SET ");	

		sb.append(PortalDBEnum.INSTALL_JOBS.lastModified.name());
		sb.append(" = ");
		sb.append(System.currentTimeMillis());
		sb.append(",");

		sb.append(PortalDBEnum.INSTALL_JOBS.status.name());
		sb.append(" = ");
		sb.append(status.getValue());
		sb.append(" WHERE ");

		sb.append(PortalDBEnum.INSTALL_JOBS.uId.name());
		sb.append(" = ");
		sb.append("?");
		//		sb.append(dbCon.formatString(jobId));		
		return sb.toString();
	}


	/**
	 * Get job 
	 * @return
	 */
	public String getJobOperations(List<String> jobIdsSize) 
	{		
		SqlQueryBuilder queryBuilder = new SqlQueryBuilder();
		queryBuilder.appendQuery("SELECT * FROM ");
		queryBuilder.appendQuery(PortalDBEnum.TABLE_NAMES.installJobs);
		queryBuilder.appendQuery(" WHERE ");
		queryBuilder.appendQuery(PortalDBEnum.INSTALL_JOBS.uId.name());
		//		queryBuilder.appendQuery(" IN (");
		//		queryBuilder.appendQuery("?");	
		//		queryBuilder.appendQuery(")");
		queryBuilder.appendQueryIN(jobIdsSize);

		return queryBuilder.getQuery().toString();
	}
}
