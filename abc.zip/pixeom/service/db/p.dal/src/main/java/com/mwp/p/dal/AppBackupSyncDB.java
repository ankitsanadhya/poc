/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal;

import com.mwp.common.enums.AppBackupTaskStatus;
import com.mwp.p.common.enums.PortalDBEnum;

/**
 * Database Queries for AppBackupSync Table
 * @author root
 *
 */
public class AppBackupSyncDB {

	String table = "";
	StringBuilder colList;

	public AppBackupSyncDB() {
		table = PortalDBEnum.TABLE_NAMES.appBackupSync.name();

		colList = new StringBuilder(PortalDBEnum.APP_BACKUP_SYNC.clusterId.name()).append(", ")
				.append(PortalDBEnum.APP_BACKUP_SYNC.userId.name()).append(", ")
				.append(PortalDBEnum.APP_BACKUP_SYNC.status.name()).append(", ")
				.append(PortalDBEnum.APP_BACKUP_SYNC.requestedTime.name());	
	}

	/**
	 * Get all sync tasks
	 * @return
	 */
	public String get() {
		return mGet();
	}

	/**
	 * Get sync Tasks for cluster id with status 
	 * @param clusterId
	 * @param appBackupTaskStatus
	 * @return
	 */
	public String getWithClusterIdAndStatus() {
		return mGetWithClusterIdAndStatus();
	}

	/**
	 * Add sync task for cluster and user
	 * @param clusterId
	 * @param userId
	 * @return
	 */
	public String insert() {
		return mInsert();
	}

	/**
	 * update the AppBackupTaskStatus for clusterID 
	 * @param clusterId
	 * @param appBackupTaskStatus
	 * @return
	 */
	public String update() {
		return mUpdate();
	}

	/**
	 * Delete Sync task for cluster with status check ()  
	 * @param clusterId
	 * @param appBackupTaskStatus
	 * @return
	 */
	public String delete() {
		return mDelete();
	}

	public String mGet() {
		StringBuilder sb = new StringBuilder("SELECT ")
				.append(colList)
				.append(" FROM ")
				.append(table)
				.append(" ORDER BY ")
				.append(PortalDBEnum.APP_BACKUP_SYNC.requestedTime.name());

		return sb.toString();
	}

	public String mGetWithClusterIdAndStatus() {
		StringBuilder sb = new StringBuilder("SELECT ")
				.append(colList)
				.append(" FROM ")
				.append(table)
				.append(" WHERE ")
				.append(PortalDBEnum.APP_BACKUP_SYNC.clusterId.name())
				.append(" = ")
				.append("?")
				.append(" AND ")
				.append(PortalDBEnum.APP_BACKUP_SYNC.status.name())
				.append(" = ")
				.append("?")
				.append(" ORDER BY ")
				.append(PortalDBEnum.APP_BACKUP_SYNC.requestedTime.name());

		return sb.toString();
	}

	public String mInsert() {
		StringBuilder sb = new StringBuilder("INSERT INTO ")
				.append(table)
				.append(" (")
				.append(colList) 
				.append(") VALUES (")
				.append("?").append(",")
				.append("?").append(",")
				.append(AppBackupTaskStatus.ACTIVE.getStatusValue()).append(",")
				.append("?")
				.append(") ");

		return sb.toString();
	}

	public String mUpdate() {
		StringBuilder sb = new StringBuilder("UPDATE ")
				.append(table)
				.append(" SET ")
				.append(PortalDBEnum.APP_BACKUP_SYNC.status.name())
				.append(" = ")
				.append("?")
				.append(" WHERE ")
				.append(PortalDBEnum.APP_BACKUP_SYNC.clusterId.name())
				.append(" = ")
				.append("?");

		return sb.toString();
	}

	public String mDelete() {
		StringBuilder sb = new StringBuilder("DELETE FROM ")
				.append(table)
				.append(" WHERE ")
				.append(PortalDBEnum.APP_BACKUP_SYNC.clusterId.name())
				.append(" = ")
				.append("?")
				.append(" AND ")
				.append(PortalDBEnum.APP_BACKUP_SYNC.status.name())
				.append(" = ")
				.append("?");

		return sb.toString();
	}
}