/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal.engine;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.common.vo.ApplicationPlatformVO;
import com.mwp.common.vo.PlatformVO;
import com.mwp.common.vo.QueryVO;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.dal.ApplicationPlatformDB;

/**
 * This class executes queries related to applicationplatform table and create VO objects ApplicationPlatformVO and  PlatformVO.
 */
public class ApplicationPlatformEngine {

	/**
	 * Get all platform ecists in database.
	 * @return
	 * @throws SQLException
	 */
	public List<PlatformVO> getAllPlatForm() throws SQLException {
		return mGetAllPlatForm();
	}

	/**
	 * Get platform object for given platform actual name. 
	 * @param actualName
	 * @return
	 */
	public PlatformVO getPlatForm(String actualName) throws SQLException {
		return mGetPlatForm(actualName);
	}

	/**
	 * Get application platform for given application id and deviceId. 
	 * @param appId application Id
	 * @param deviceId device Id
	 * @return
	 */
	public ApplicationPlatformVO getDeviceApplicationPlatForm(String appId, String deviceId) throws SQLException {
		return mGetDeviceApplicationPlatForm(appId, deviceId);
	}

	private ApplicationPlatformVO mGetDeviceApplicationPlatForm(String appId, String deviceId) throws SQLException {
		ApplicationPlatformVO appPlatform = null;

		String sql = new ApplicationPlatformDB().getDeviceApplicationPlatForm();

		List<String> parameters = new ArrayList<>();

		parameters.add(deviceId);
		parameters.add(appId);

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameters(parameters).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				appPlatform = setApplicationPlatformObject(rs);
			}
		}
		return appPlatform;
	}

	private PlatformVO mGetPlatForm(String actualName) throws SQLException {
		PlatformVO platform = null;
		String sql = new ApplicationPlatformDB().getPlatForm();
		
		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(sql).addParameterForLike(true, actualName, true).build();

		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)){
			while (rs.next()){
				platform = setPlatformObject(rs);
			}
		}
		return platform;
	}

	private List<PlatformVO> mGetAllPlatForm() throws SQLException {
		List<PlatformVO> platforms = new ArrayList<>();
		String sql = new ApplicationPlatformDB().getAllPlatForm();

		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(sql).build();

		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)){
			while (rs.next()){
				platforms.add(setPlatformObject(rs));
			}
		}
		return platforms;
	}

	private PlatformVO setPlatformObject(ResultSet rs) throws SQLException
	{
		PlatformVO platform = new PlatformVO();
		platform.setPlatformId(rs.getString(PortalDBEnum.PLATFORM.platformId.name()));
		platform.setPlatformName(rs.getString(PortalDBEnum.PLATFORM.platformName.name()));
		platform.setPlatformActualName(rs.getString(PortalDBEnum.PLATFORM.platformActualName.name()));
		platform.setModifiedDate(rs.getTimestamp(PortalDBEnum.PLATFORM.modifiedDate.name()).getTime());
		return platform;
	}

	private ApplicationPlatformVO setApplicationPlatformObject(ResultSet rs) throws SQLException{
		ApplicationPlatformVO appPlatform = new ApplicationPlatformVO();
		appPlatform.setPlatformId(rs.getString(PortalDBEnum.APPLICATION_PLATFORM.platformId.name()));
		appPlatform.setAppPlatformId(rs.getString(PortalDBEnum.APPLICATION_PLATFORM.appPlatformId.name()));
		appPlatform.setAppId(rs.getString(PortalDBEnum.APPLICATION_PLATFORM.appId.name()));
		appPlatform.setRepositoryName(rs.getString(PortalDBEnum.APPLICATION_PLATFORM.repositoryName.name()));
		appPlatform.setModifiedDate(rs.getTimestamp(PortalDBEnum.APPLICATION_PLATFORM.modifiedDate.name()).getTime());
		return appPlatform;
	}

}
