/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal;



import com.mwp.db.Interface.IConnection;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.common.enums.PortalDBEnum.SUPPORT_RELAY_SERVERS;
import com.mwp.p.dal.engine.PortalDatabaseEngine;

/**
 * This class provides queries related to table  {@link SUPPORT_RELAY_SERVERS}
 *
 */
public class SupportRelayServersDB {
	
	/**
	 * create query to select relay server by id 
	 * @param relayServerId
	 * @return
	 */
	public String getSupportRelayServersFromRelayId()
	{
		StringBuilder sb = new StringBuilder();
		sb.append("Select * ");
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.supportrelayservers);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.SUPPORT_RELAY_SERVERS.sRelayServerID);
		sb.append(" = ");
		sb.append("?");
		//sb.append(dbCon.formatString(relayServerId));
		return sb.toString();
	}

	/**
	 * create query to get distinct relayservers and count.This query returns result order by device count 
	 * @return
	 */
	public String getSupportRelayServers() {
		return "select distinct "
				+ "supportrelayservers.sRelayServerID, "
				+ "supportrelayservers.sRelayServerAddress, "
				+ "supportrelayservers.sRelayName, "
				+ "supportrelayservers.nPortRangeStart, "
				+ "supportrelayservers.nPortRangeEnd,"
				+ "supportrelayservers.sDeviceLimit, "
				+ "(select count(*) from supportassignedrelayports where supportassignedrelayports.sRelayServerID = supportrelayservers.sRelayServerID) as Devices "
				+ "from supportrelayservers left join supportassignedrelayports on supportrelayservers.sRelayServerID = supportassignedrelayports.sRelayServerID "
				+ " where supportrelayservers.sPriority= 1 "
				+ "order by Devices asc";
	}
	
	/**
	 * Create query to return all relay servers
	 * @return
	 */
	public String getAllSupportedRelayServers() {
		return "SELECT * FROM supportrelayservers where sPriority  = 1";
	}
	
	/**
	 * Create queries to select relay server if its priority is 1. 
	 * @param relayServerId
	 * @return
	 */
	public String isOnePriority() 
	{
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT * FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.supportrelayservers.name());
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.SUPPORT_RELAY_SERVERS.sRelayServerID.name());
		sb.append(" = ");
		sb.append("?");
//		sb.append(dbCon.formatString(relayServerId));
		sb.append(" AND ");
		sb.append(PortalDBEnum.SUPPORT_RELAY_SERVERS.sPriority.name());
		sb.append(" = ");
		sb.append("?");
		return sb.toString();
	}
	
	
	
	
	
	public String listAllSupportRelayServer() 
	{
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT ");
		sb.append(PortalDBEnum.TABLE_NAMES.supportrelayservers.name());
		sb.append(".");
		sb.append("*");
		sb.append(",");
		sb.append(
				"(select count(*) from supportassignedrelayports where supportassignedrelayports.sRelayServerID = supportrelayservers.sRelayServerID and supportassignedrelayports.nStatus=1) as deviceCount");
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.supportrelayservers.name());

		sb.append(" ORDER BY ");
		sb.append(PortalDBEnum.TABLE_NAMES.supportrelayservers.name());
		sb.append(".");
		sb.append(PortalDBEnum.SUPPORT_RELAY_SERVERS.dModified.name());
		sb.append(" DESC ");
		return sb.toString();
	}
	
//	sRelayServerID,
//	sRelayServerAddress,
//	sRelayName,
//	nPortRangeStart,
//	nPortRangeEnd,
//	sDeviceLimit,
//	nStatus,
//	sRUserName,
//	sRPassword,
//	nRPort, 
//	sPriority,
//	dModified,
	public String insertSupportRelayServer() 
	{
		StringBuilder sb = new StringBuilder();
		sb.append("INSERT INTO ");
		sb.append(PortalDBEnum.TABLE_NAMES.supportrelayservers);
		sb.append(" ( ");
		sb.append(PortalDBEnum.SUPPORT_RELAY_SERVERS.sRelayServerID.name());
		sb.append(", ");
		sb.append(PortalDBEnum.SUPPORT_RELAY_SERVERS.sRelayServerAddress.name());
		sb.append(", ");
		sb.append(PortalDBEnum.SUPPORT_RELAY_SERVERS.sRelayName.name());
		sb.append(", ");
		sb.append(PortalDBEnum.SUPPORT_RELAY_SERVERS.nPortRangeStart.name());
		sb.append(", ");
		sb.append(PortalDBEnum.SUPPORT_RELAY_SERVERS.nPortRangeEnd.name());
		sb.append(", ");
		sb.append(PortalDBEnum.SUPPORT_RELAY_SERVERS.sDeviceLimit.name());
		sb.append(", ");
		sb.append(PortalDBEnum.SUPPORT_RELAY_SERVERS.nStatus.name());
		sb.append(", ");
		sb.append(PortalDBEnum.SUPPORT_RELAY_SERVERS.sRUserName.name());
		sb.append(", ");
		sb.append(PortalDBEnum.SUPPORT_RELAY_SERVERS.sRPassword.name());
		sb.append(", ");
		sb.append(PortalDBEnum.SUPPORT_RELAY_SERVERS.sHostKey.name());
		sb.append(", ");
		sb.append(PortalDBEnum.SUPPORT_RELAY_SERVERS.nRPort.name());
		sb.append(", ");
		sb.append(PortalDBEnum.SUPPORT_RELAY_SERVERS.sPriority.name());
		sb.append(", ");
		sb.append(PortalDBEnum.SUPPORT_RELAY_SERVERS.dModified.name());
		sb.append(" ) VALUES ( ");
		sb.append("?");
//		sb.append(dbCon.formatString(sRelayServerID));
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(sRelayServerAddress));
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(sRelayName));
		sb.append(", ");
		sb.append("?");
//		sb.append(nPortRangeStart);
		sb.append(", ");
		sb.append("?");
//		sb.append(nPortRangeEnd);
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(sDeviceLimit));
		sb.append(", ");
		sb.append("?");
//		sb.append(nStatus);
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(sRUserName));
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(sRPassword));
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(sHostKey));
		sb.append(", ");
		sb.append("?");
//		sb.append(nRPort);
		sb.append(", ");
		sb.append("?");
//		sb.append(sPriority);
		sb.append(", NOW()");
		sb.append(" ) ");
		return sb.toString();
	}
	
	public String updateSupportRelayServer() {
		StringBuilder sb = new StringBuilder();
		sb.append("UPDATE  ");
		sb.append(PortalDBEnum.TABLE_NAMES.supportrelayservers);
		sb.append(" set  ");
		sb.append(PortalDBEnum.SUPPORT_RELAY_SERVERS.sRelayServerAddress.name());
		sb.append(" = ");
		sb.append("?");
		// sb.append(dbCon.formatString(sRelayServerAddress));
		sb.append(", ");
		sb.append(PortalDBEnum.SUPPORT_RELAY_SERVERS.sRelayName.name());
		sb.append(" = ");
		sb.append("?");
		// sb.append(dbCon.formatString(sRelayName));
		sb.append(", ");
		sb.append(PortalDBEnum.SUPPORT_RELAY_SERVERS.nStatus.name());
		sb.append(" = ");
		sb.append("?");
		// sb.append(nStatus);
		sb.append(", ");
		sb.append(PortalDBEnum.SUPPORT_RELAY_SERVERS.sRUserName.name());
		sb.append(" = ");
		sb.append("?");
		// sb.append(dbCon.formatString(sRUserName));
		sb.append(", ");
		sb.append(PortalDBEnum.SUPPORT_RELAY_SERVERS.sRPassword.name());
		sb.append(" = ");
		sb.append("?");
		// sb.append(dbCon.formatString(sRPassword));
		sb.append(", ");
		sb.append(PortalDBEnum.SUPPORT_RELAY_SERVERS.sHostKey.name());
		sb.append(" = ");
		sb.append("?");
		// sb.append(dbCon.formatString(sHostkey));
		sb.append(", ");
		sb.append(PortalDBEnum.SUPPORT_RELAY_SERVERS.nRPort.name());
		sb.append(" = ");
		sb.append("?");
		// sb.append(nRPort);
		sb.append(", ");
		sb.append(PortalDBEnum.SUPPORT_RELAY_SERVERS.sPriority.name());
		sb.append(" = ");
		sb.append("?");
		// sb.append(sPriority);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.SUPPORT_RELAY_SERVERS.sRelayServerID.name());
		sb.append(" = ");
		sb.append("?");
		// sb.append(dbCon.formatString(sRelayServerID));
		return sb.toString();
	}
	
	public String isExists() 
	{
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT ");
		sb.append(PortalDBEnum.SUPPORT_RELAY_SERVERS.sRelayServerID.name());
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.supportrelayservers.name());
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.SUPPORT_RELAY_SERVERS.sRelayServerID.name());
		sb.append(" = ");
		sb.append("?");
		//sb.append(dbCon.formatString(relayServerId));
		return sb.toString();
	}
	
	public String delete() 
	{
		StringBuilder sb = new StringBuilder();
		sb.append("DELETE ");
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.supportrelayservers.name());
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.SUPPORT_RELAY_SERVERS.sRelayServerID.name());
		sb.append(" = ");
		sb.append("?");
		return sb.toString();
	}
}
