/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal;

import com.mwp.db.Interface.IConnection;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.common.enums.PortalDBEnum.LOCK_RELAY_PORTS;
import com.mwp.p.dal.engine.PortalDatabaseEngine;

/**
 * This class create query related to {@link LOCK_RELAY_PORTS
 */
public class LockRelayPortsDB {
	private IConnection dbCon= null;
	public LockRelayPortsDB() {
		dbCon = PortalDatabaseEngine.getInstance().getConnection();
	}

	/**
	 * Add lock for relay ports
	 * @param deviceId
	 * @param relayServerID
	 * @param portSegmentStart
	 * @return
	 */
	public String addLockRelayPorts() {

		StringBuilder sb = new StringBuilder();
		sb.append("INSERT INTO ");
		sb.append(PortalDBEnum.TABLE_NAMES.lockrelayports.name());
		sb.append(" ( ");
		sb.append(PortalDBEnum.LOCK_RELAY_PORTS.sDeviceID.name());
		sb.append(", ");
		sb.append(PortalDBEnum.LOCK_RELAY_PORTS.sRelayServerID.name());
		sb.append(", ");
		sb.append(PortalDBEnum.LOCK_RELAY_PORTS.nPortSegmentStart.name());
		sb.append(", ");
		sb.append(PortalDBEnum.LOCK_RELAY_PORTS.dModified.name());
		sb.append(" ) VALUES (");
		sb.append("?");
		//sb.append(dbCon.formatString(deviceId));
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(relayServerID));
		sb.append(", ");
		sb.append("?");
//		sb.append(portSegmentStart);
		sb.append(", NOW() )");
		return sb.toString();
	}


	/**
	 * Get list of locks relay server ports
	 * @param relayServerID
	 * @param portSegmentStart
	 * @return
	 */
	public String getLockRelayPorts() {
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT * FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.lockrelayports.name());
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.LOCK_RELAY_PORTS.sRelayServerID.name());
		sb.append(" = ");
		sb.append("?");
		//sb.append(dbCon.formatString(relayServerID));
		sb.append(" AND ");
		sb.append(PortalDBEnum.LOCK_RELAY_PORTS.nPortSegmentStart.name());
		sb.append(" = ");
		sb.append("?");
		//sb.append(portSegmentStart);
		sb.append(" ORDER BY ");
		sb.append(PortalDBEnum.LOCK_RELAY_PORTS.dModified.name());
		return sb.toString();
	}

	/**
	 * Delete lock for relay server that has time older then 5 minutes.
	 * @return
	 */
	public String deleteExpiredLocks() {
		StringBuilder sb = new StringBuilder();
		sb.append("DELETE FROM ");sb.append(PortalDBEnum.TABLE_NAMES.lockrelayports.name());
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.LOCK_RELAY_PORTS.dModified.name());sb.append(" < (NOW() - INTERVAL 5 MINUTE) ");
		return sb.toString();
	}

	/**
	 *  delete lock on relay ports for device id
	 * @param deviceId
	 * @return
	 */
	public String deleteLockRelayPorts() {
		StringBuilder sb = new StringBuilder();
		sb.append("DELETE FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.lockrelayports.name());
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.LOCK_RELAY_PORTS.sDeviceID.name());
		sb.append(" = ");
		sb.append("?");
		return sb.toString();
	}
}
