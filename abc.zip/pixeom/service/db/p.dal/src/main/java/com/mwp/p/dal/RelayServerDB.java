/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal;


import java.util.ArrayList;
import java.util.List;

import com.mwp.db.Interface.IConnection;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.dal.engine.PortalDatabaseEngine;

public class RelayServerDB {

	private IConnection dbCon= null;
	public RelayServerDB() {
		dbCon = PortalDatabaseEngine.getInstance().getConnection();
	}
	
	/**
	 * create query to get relayserver address.
	 * @param relayServerId
	 * @return
	 */
	public String getRelayServerAddress() {
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT sRelayServerAddress FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.relayservers.name());
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.RELAY_SERVERS.sRelayServerID.name());
		sb.append(" = ");
		sb.append("?");
//		sb.append(dbCon.formatString(relayServerId));
		return sb.toString();
	}

	/**
	 * create query to get distinct relay server information and device count from assignedrelayports.
	 * query order by result by deviceCount in ascending order
	 * @return
	 */
	public String getDistinctRelayServers() {
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT distinct ");
		sb.append(PortalDBEnum.TABLE_NAMES.relayservers.name());sb.append(".");sb.append(PortalDBEnum.RELAY_SERVERS.sRelayServerID.name());
		sb.append(",");
		sb.append(PortalDBEnum.TABLE_NAMES.relayservers.name());sb.append(".");sb.append(PortalDBEnum.RELAY_SERVERS.sRelayServerAddress.name());
		sb.append(",");
		sb.append(PortalDBEnum.TABLE_NAMES.relayservers.name());sb.append(".");sb.append(PortalDBEnum.RELAY_SERVERS.sRelayName.name());
		sb.append(",");
		sb.append(PortalDBEnum.TABLE_NAMES.relayservers.name());sb.append(".");sb.append(PortalDBEnum.RELAY_SERVERS.nPortRangeStart.name());
		sb.append(",");
		sb.append(PortalDBEnum.TABLE_NAMES.relayservers.name());sb.append(".");sb.append(PortalDBEnum.RELAY_SERVERS.nPortRangeEnd.name());
		sb.append(",");
		sb.append(PortalDBEnum.TABLE_NAMES.relayservers.name());sb.append(".");sb.append(PortalDBEnum.RELAY_SERVERS.sDeviceLimit.name());
		sb.append(",");
		sb.append("(select count(*) from assignedrelayports where assignedrelayports.sRelayServerID = relayservers.sRelayServerID) as deviceCount");
		sb.append(" FROM ");sb.append(PortalDBEnum.TABLE_NAMES.relayservers.name());
		sb.append(" LEFT JOIN ");
		sb.append(PortalDBEnum.TABLE_NAMES.assignedrelayports.name());sb.append(" ON ");
		sb.append(PortalDBEnum.TABLE_NAMES.relayservers.name());sb.append(".");sb.append(PortalDBEnum.RELAY_SERVERS.sRelayServerID.name());
		sb.append(" = ");
		sb.append(PortalDBEnum.TABLE_NAMES.assignedrelayports.name());sb.append(".");sb.append(PortalDBEnum.ASSIGNED_RELAY_PORTS.sRelayServerID.name());
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.TABLE_NAMES.relayservers.name());
		sb.append(".");
		sb.append(PortalDBEnum.RELAY_SERVERS.sPriority.name());
		sb.append(" = ");
		sb.append(1);
		sb.append(" ORDER BY deviceCount ASC ");
		return sb.toString();
	}

	/** Get all relay server information with priority 1
	 * @return
	 */
	public String getListRelayServer() {
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT * FROM ");sb.append(PortalDBEnum.TABLE_NAMES.relayservers.name());
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.RELAY_SERVERS.sPriority.name());
		sb.append(" = ");
		sb.append(1);
		return sb.toString();
	}
	
	/**
	 * Check if priority is 1 for relay server.
	 * @param relayServerId
	 * @return
	 */
	public String isOnePriority() 
	{
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT * FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.relayservers.name());
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.RELAY_SERVERS.sRelayServerID.name());
		sb.append(" = ");
		sb.append("?");
		//sb.append(dbCon.formatString(relayServerId));
		sb.append(" AND ");
		sb.append(PortalDBEnum.RELAY_SERVERS.sPriority.name());
		sb.append(" = ");
		sb.append("?");
//		sb.append(1);
		return sb.toString();
	}

	public String ListAllRelayServer() 
	{
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT ");
		sb.append(PortalDBEnum.TABLE_NAMES.relayservers.name());sb.append(".");sb.append("*");
		sb.append(",");
		sb.append("(select count(*) from assignedrelayports where assignedrelayports.sRelayServerID = relayservers.sRelayServerID and assignedrelayports.nStatus=1) as deviceCount");
		sb.append(" FROM ");sb.append(PortalDBEnum.TABLE_NAMES.relayservers.name());
		sb.append(" ORDER BY ");
		sb.append(PortalDBEnum.TABLE_NAMES.relayservers.name());sb.append(".");sb.append(PortalDBEnum.RELAY_SERVERS.dModified.name());
		sb.append(" DESC ");
		return sb.toString();
	}
	
//	sRelayServerID,
//	sRelayServerAddress,
//	sRelayName,
//	nPortRangeStart,
//	nPortRangeEnd,
//	sDeviceLimit,
//	nStatus,
//	sRUserName,
//	sRPassword,
//	nRPort, 
//	sPriority,
//	dModified,
	public String insertRelayServer() 
	{
		StringBuilder sb = new StringBuilder();
		sb.append("INSERT INTO ");
		sb.append(PortalDBEnum.TABLE_NAMES.relayservers);
		sb.append(" ( ");
		sb.append(PortalDBEnum.RELAY_SERVERS.sRelayServerID.name());
		sb.append(", ");
		sb.append(PortalDBEnum.RELAY_SERVERS.sRelayServerAddress.name());
		sb.append(", ");
		sb.append(PortalDBEnum.RELAY_SERVERS.sRelayName.name());
		sb.append(", ");
		sb.append(PortalDBEnum.RELAY_SERVERS.nPortRangeStart.name());
		sb.append(", ");
		sb.append(PortalDBEnum.RELAY_SERVERS.nPortRangeEnd.name());
		sb.append(", ");
		sb.append(PortalDBEnum.RELAY_SERVERS.sDeviceLimit.name());
		sb.append(", ");
		sb.append(PortalDBEnum.RELAY_SERVERS.nStatus.name());
		sb.append(", ");
		sb.append(PortalDBEnum.RELAY_SERVERS.sRUserName.name());
		sb.append(", ");
		sb.append(PortalDBEnum.RELAY_SERVERS.sRPassword.name());
		sb.append(", ");
		sb.append(PortalDBEnum.RELAY_SERVERS.sHostKey.name());
		sb.append(", ");
		sb.append(PortalDBEnum.RELAY_SERVERS.nRPort.name());
		sb.append(", ");
		sb.append(PortalDBEnum.RELAY_SERVERS.sPriority.name());
		sb.append(", ");
		sb.append(PortalDBEnum.RELAY_SERVERS.dModified.name());
		sb.append(" ) VALUES ( ");
		sb.append("?");
		//sb.append(dbCon.formatString(sRelayServerID));
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(sRelayServerAddress));
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(sRelayName));
		sb.append(", ");
		sb.append("?");
//		sb.append(nPortRangeStart);
		sb.append(", ");
		sb.append("?");
//		sb.append(nPortRangeEnd);
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(sDeviceLimit));
		sb.append(", ");
		sb.append("?");
//		sb.append(nStatus);
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(sRUserName));
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(sRPassword));
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(sHostKey));
		sb.append(", ");
		sb.append("?");
//		sb.append(nRPort);
		sb.append(", ");
		sb.append("?");
//		sb.append(sPriority);
		sb.append(", NOW()");
		sb.append(" ) ");
		
		return sb.toString();
	}
	
	public String updateRelayServer() {
		StringBuilder sb = new StringBuilder();
		sb.append("UPDATE  ");
		sb.append(PortalDBEnum.TABLE_NAMES.relayservers);
		sb.append(" set  ");
		sb.append(PortalDBEnum.RELAY_SERVERS.sRelayServerAddress.name());
		sb.append(" = ");
		sb.append("?");
		// sb.append(dbCon.formatString(sRelayServerAddress));
		sb.append(", ");
		sb.append(PortalDBEnum.RELAY_SERVERS.sRelayName.name());
		sb.append(" = ");
		sb.append("?");
		// sb.append(dbCon.formatString(sRelayName));
		sb.append(", ");
		sb.append(PortalDBEnum.RELAY_SERVERS.nStatus.name());
		sb.append(" = ");
		sb.append("?");
		// sb.append(nStatus);
		sb.append(", ");
		sb.append(PortalDBEnum.RELAY_SERVERS.sRUserName.name());
		sb.append(" = ");
		sb.append("?");
		// sb.append(dbCon.formatString(sRUserName));
		sb.append(", ");
		sb.append(PortalDBEnum.RELAY_SERVERS.sRPassword.name());
		sb.append(" = ");
		sb.append("?");
		// sb.append(dbCon.formatString(sRPassword));
		sb.append(", ");
		sb.append(PortalDBEnum.RELAY_SERVERS.sHostKey.name());
		sb.append(" = ");
		sb.append("?");
		// sb.append(dbCon.formatString(sHostKey));
		sb.append(", ");
		sb.append(PortalDBEnum.RELAY_SERVERS.nRPort.name());
		sb.append(" = ");
		sb.append("?");
		// sb.append(nRPort);
		sb.append(", ");
		sb.append(PortalDBEnum.RELAY_SERVERS.sPriority.name());
		sb.append(" = ");
		sb.append("?");
		// sb.append(sPriority);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.RELAY_SERVERS.sRelayServerID.name());
		sb.append(" = ");
		sb.append("?");
		// sb.append(dbCon.formatString(sRelayServerID));
		return sb.toString();
	}
	
	public String getRelayServer() 
	{
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT * FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.relayservers.name());
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.RELAY_SERVERS.sRelayServerID.name());
		sb.append(" = ");
		sb.append("?");
//		sb.append(dbCon.formatString(relayServerId));
		return sb.toString();
	}
	
	public String isExists() 
	{
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT ");
		sb.append(PortalDBEnum.RELAY_SERVERS.sRelayServerID.name());
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.relayservers.name());
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.RELAY_SERVERS.sRelayServerID.name());
		sb.append(" = ");
		sb.append("?");
//		sb.append(dbCon.formatString(relayServerId));
		return sb.toString();
	}
	
	public List<String> delete() 
	{
		List<String> queries = new ArrayList<>();
		StringBuilder sb = new StringBuilder();
		sb.append("DELETE ");
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.relayservers.name());
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.RELAY_SERVERS.sRelayServerID.name());
		sb.append(" = ");
		sb.append("?");
		//sb.append(dbCon.formatString(relayServerId));
		queries.add(sb.toString());

		sb = new StringBuilder();
		sb.append("DELETE ");
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.assignedrelayports.name());
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.ASSIGNED_RELAY_PORTS.sRelayServerID.name());
		sb.append(" = ");
		sb.append("?");
//		sb.append(dbCon.formatString(relayServerId));
		queries.add(sb.toString());

		sb = new StringBuilder();
		sb.append("DELETE ");
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.lockrelayports.name());
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.LOCK_RELAY_PORTS.sRelayServerID.name());
		sb.append(" = ");
		sb.append("?");
//		sb.append(dbCon.formatString(relayServerId));
		queries.add(sb.toString());

		return queries;
	}
}
