/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.common.enums.Operator;
import com.mwp.common.vo.AppBackupTaskVOPortal;
import com.mwp.common.vo.FilterObject;
import com.mwp.p.common.enums.PortalDBEnum;

/**
 * 
 * Returns queries for AppBackupTask 
 * 
 * AppBackupTasks are sync with minio files into this DB
 *
 */
public class AppBackupTaskDB {

	String table = "";
	StringBuilder colList;

	public AppBackupTaskDB() {
		table = PortalDBEnum.TABLE_NAMES.appBackupTask.name();

		colList = new StringBuilder(PortalDBEnum.APP_BACKUP_TASK.backupTaskId.name()).append(", ")
				.append( PortalDBEnum.APP_BACKUP_TASK.arkBackupName.name()).append(", ")
				.append( PortalDBEnum.APP_BACKUP_TASK.platformName.name()).append(", ")
				.append( PortalDBEnum.APP_BACKUP_TASK.clusterId.name()).append(", ")
				.append( PortalDBEnum.APP_BACKUP_TASK.clusterName.name()).append(", ")
				.append( PortalDBEnum.APP_BACKUP_TASK.applicationId.name()).append(", ")
				.append( PortalDBEnum.APP_BACKUP_TASK.appName.name()).append(", ")
				.append( PortalDBEnum.APP_BACKUP_TASK.appVersionId.name()).append(", ")
				.append( PortalDBEnum.APP_BACKUP_TASK.appVersion.name()).append(", ")
				.append( PortalDBEnum.APP_BACKUP_TASK.status.name()).append(", ")
				.append( PortalDBEnum.APP_BACKUP_TASK.startedTime.name() ).append(", ")
				.append( PortalDBEnum.APP_BACKUP_TASK.completedTime.name() );	
	}

	/**
	 * Insert new or if already exists update completedTime, status and arkBackupName
	 * @param appBackupTaskVOPortal
	 * @return
	 */
	public String upsert(AppBackupTaskVOPortal appBackupTaskVOPortal) {
		return mUpsert(appBackupTaskVOPortal);
	}

	/**
	 * List all app backup tasks for cluster
	 * @param clusterId
	 * @return
	 */
	public String listByClusterId() {
		return mListByClusterId();
	}

	/**
	 * List all app backup tasks for cluster with page limits
	 * @param pageNo
	 * @param pageSize
	 * @return
	 */
//	public Map<String, String> list(long pageNo, long pageSize) {
//		return mList(null, null, 0, pageNo, pageSize);
//	}

	/**
	 * List all app backup tasks for cluster with filters provided and page limits
	 * @param clusterIds - For which cluster you  needed for user it's own all cluster ids
	 * @param filters - Filter (AppId, Cluster) and Sort objects
	 * @param sizePerApp - 1 = List latest available backup, else list all backups
	 * @param pageNo - Which page
	 * @param pageSize - data in one page
	 * @return
	 */
	public Map<String, String> list(List<FilterObject> filters, int sizePerApp, List<String> clusterIds) {
		return mList(filters, sizePerApp, clusterIds);
	}

	/**
	 * Delete app Backup task with it's backup name
	 * @param arkBackupName
	 * @return
	 */
	public String delete() {
		return mDelete();
	}

	private String mUpsert(AppBackupTaskVOPortal appBackupTaskVOPortal) {

		StringBuilder sb = new StringBuilder("INSERT INTO ")
				.append(table)
				.append(" (")
				.append(colList) 
				.append(") VALUES (")
				.append("?").append(",")//.append(connection.formatString(appBackupTaskVOPortal.getAppBackupTaskVO().getBackupTaskId())).append(",")
				.append("?").append(",")//.append(connection.formatString(appBackupTaskVOPortal.getAppBackupTaskVO().getArkBackupName())).append(",")
				.append("?").append(",")//.append(connection.formatString(appBackupTaskVOPortal.getAppBackupTaskVO().getPlatformName())).append(",")
				.append("?").append(",")//.append(connection.formatString(appBackupTaskVOPortal.getClusterId())).append(",")
				.append("?").append(",")//.append(connection.formatString(appBackupTaskVOPortal.getClusterName())).append(",")
				.append("?").append(",")//.append(connection.formatString(appBackupTaskVOPortal.getAppBackupTaskVO().getApplicationId())).append(",")
				.append("?").append(",")//.append(connection.formatString(appBackupTaskVOPortal.getAppBackupTaskVO().getAppName())).append(",")
				.append("?").append(",")//.append(connection.formatString(appBackupTaskVOPortal.getAppBackupTaskVO().getAppVersionId())).append(",")
				.append("?").append(",")//.append(connection.formatString(appBackupTaskVOPortal.getAppBackupTaskVO().getAppVersion())).append(",")
				.append("?").append(",")//.append(appBackupTaskVOPortal.getAppBackupTaskVO().getStatus().getStatusValue()).append(",")
				.append("?").append(",")//.append(connection.formatString(new Timestamp(appBackupTaskVOPortal.getAppBackupTaskVO().getStartedTime()).toString())).append(",")
				.append("?")//.append(connection.formatString(new Timestamp(appBackupTaskVOPortal.getAppBackupTaskVO().getCompletedTime()).toString()))
				.append(") ")
				.append(" ON DUPLICATE KEY UPDATE ")
				.append(PortalDBEnum.APP_BACKUP_TASK.completedTime.name()) 
				.append(" = ")
				.append("?")
				.append(", ")
				.append(PortalDBEnum.APP_BACKUP_TASK.status.name()) 
				.append(" = ")
				.append("?")
				.append(", ")
				.append(PortalDBEnum.APP_BACKUP_TASK.arkBackupName.name()) 
				.append(" = ")
				.append("?");

		return sb.toString();
	}

//	private String mUpsert(AppBackupTaskVOPortal appBackupTaskVOPortal) {
//
//		if(StringUtils.isEmpty(appBackupTaskVOPortal.getAppBackupTaskVO().getBackupTaskId())) {
//			appBackupTaskVOPortal.getAppBackupTaskVO().setBackupTaskId(Common.getRandomId());
//		}
//		if(appBackupTaskVOPortal.getAppBackupTaskVO().getStartedTime() == 0) {
//			appBackupTaskVOPortal.getAppBackupTaskVO().setStartedTime(1);
//		}
//		if(appBackupTaskVOPortal.getAppBackupTaskVO().getCompletedTime() == 0) {
//			appBackupTaskVOPortal.getAppBackupTaskVO().setCompletedTime(1);
//		}
//
//		StringBuilder sb = new StringBuilder("INSERT INTO ")
//				.append(table)
//				.append(" (")
//				.append(colList) 
//				.append(") VALUES (")
//				.append(connection.formatString(appBackupTaskVOPortal.getAppBackupTaskVO().getBackupTaskId())).append(",")
//				.append(connection.formatString(appBackupTaskVOPortal.getAppBackupTaskVO().getArkBackupName())).append(",")
//				.append(connection.formatString(appBackupTaskVOPortal.getAppBackupTaskVO().getPlatformName())).append(",")
//				.append(connection.formatString(appBackupTaskVOPortal.getClusterId())).append(",")
//				.append(connection.formatString(appBackupTaskVOPortal.getClusterName())).append(",")
//				.append(connection.formatString(appBackupTaskVOPortal.getAppBackupTaskVO().getApplicationId())).append(",")
//				.append(connection.formatString(appBackupTaskVOPortal.getAppBackupTaskVO().getAppName())).append(",")
//				.append(connection.formatString(appBackupTaskVOPortal.getAppBackupTaskVO().getAppVersionId())).append(",")
//				.append(connection.formatString(appBackupTaskVOPortal.getAppBackupTaskVO().getAppVersion())).append(",")
//				.append(appBackupTaskVOPortal.getAppBackupTaskVO().getStatus().getStatusValue()).append(",")
//				.append(connection.formatString(new Timestamp(appBackupTaskVOPortal.getAppBackupTaskVO().getStartedTime()).toString())).append(",")
//				.append(connection.formatString(new Timestamp(appBackupTaskVOPortal.getAppBackupTaskVO().getCompletedTime()).toString()))
//				.append(") ")
//				.append(" ON DUPLICATE KEY UPDATE ")
//				.append(PortalDBEnum.APP_BACKUP_TASK.completedTime.name()) 
//				.append(" = ")
//				.append(connection.formatString(new Timestamp(appBackupTaskVOPortal.getAppBackupTaskVO().getCompletedTime()).toString()))
//				.append(", ")
//				.append(PortalDBEnum.APP_BACKUP_TASK.status.name()) 
//				.append(" = ")
//				.append(appBackupTaskVOPortal.getAppBackupTaskVO().getStatus().getStatusValue())
//				.append(", ")
//				.append(PortalDBEnum.APP_BACKUP_TASK.arkBackupName.name()) 
//				.append(" = ")
//				.append(connection.formatString(appBackupTaskVOPortal.getAppBackupTaskVO().getArkBackupName()));
//
//		return sb.toString();
//	}
	private String mListByClusterId() {
		StringBuilder sb = new StringBuilder("SELECT ").append(colList)
				.append(" FROM ")
				.append(table)
				.append(" WHERE ")
				.append(PortalDBEnum.APP_BACKUP_TASK.clusterId.name()).append(" = ?");

		return sb.toString();
	}

	private Map<String, String> mList(List<FilterObject> filters, int sizePerApp, List<String> clusterIds) {

		//select abt1.* from appBackupTask AS abt1 LEFT JOIN appBackupTask AS abt2 ON (abt1.applicationId = abt2.applicationId AND  abt1.completedTime > abt2.completedTime) GROUP BY applicationId

		/**
		 * sizePerApp == 0 ~ all backups
		 * Any other value ~ Latest backup only
		 */
		StringBuilder sbCount = new StringBuilder("SELECT ");
		StringBuilder sb = new StringBuilder("SELECT ");
		StringBuilder sbGroup = null;
		StringBuilder whereLatest = null;
		StringBuilder where = null;
		String joinPrefix = "";
		if (sizePerApp == 0) {
			sb.append(colList).append(" FROM ").append(table);

			sbCount.append(" COUNT(").append(PortalDBEnum.APP_BACKUP_TASK.backupTaskId.name()).append(") AS totalRows ")
					.append(" FROM ").append(table);

		} else {
			//SELECT  *  FROM appBackupTask WHERE completedTime IN ( SELECT MAX(completedTime) FROM appBackupTask GROUP BY applicationId )
			sb.append(" * FROM ")
			.append(PortalDBEnum.TABLE_NAMES.appBackupTask);

			whereLatest = getWhereClause(whereLatest)
					.append(PortalDBEnum.APP_BACKUP_TASK.completedTime.name())
					.append(" IN ")
					.append("( SELECT MAX(")
					.append(PortalDBEnum.APP_BACKUP_TASK.completedTime.name())
					.append(") FROM ")
					.append(PortalDBEnum.TABLE_NAMES.appBackupTask);
			sbGroup = new StringBuilder(" GROUP BY ").append(PortalDBEnum.APP_BACKUP_TASK.applicationId)
					.append(" ) ");

			sbCount.append(" COUNT(DISTINCT(").append(joinPrefix).append(PortalDBEnum.APP_BACKUP_TASK.applicationId.name()).append(")) AS totalRows FROM ")
			.append(PortalDBEnum.TABLE_NAMES.appBackupTask).append(" AS ").append(" abt1 ");
		}

		StringBuilder sortOrder = null;
		boolean clusterFilterApplied = false;
		SqlQueryBuilder builder = null;
		if(filters != null) {

			for (FilterObject filterObject : filters) {
				switch (filterObject.getFilterType()) {
				case FILTER:
					switch (filterObject.getFilterkey()) {
					case App:
						switch (filterObject.getValueType()) {
						case Single:
							where = getWhereClause(where).append(joinPrefix)
									.append(PortalDBEnum.APP_BACKUP_TASK.applicationId.name()).append(" = ")
									.append("?");
							break;
						case List:
							where = getWhereClause(where).append(joinPrefix)
									.append(PortalDBEnum.APP_BACKUP_TASK.applicationId.name());
							builder = new SqlQueryBuilder();
							builder.appendQueryIN(filterObject.getValues());
							where.append(builder.getQuery().toString());
							break;
						default:
							break;
						}
						break;
					case Cluster:
						switch (filterObject.getValueType()) {
						case Single:
							clusterFilterApplied = true;
							if (StringUtils.isEmpty(filterObject.getStartValue()) || "global".equalsIgnoreCase(filterObject.getStartValue())) {
								// No filter - list from all clusters
								where = getWhereClause(where).append(joinPrefix)
										.append(PortalDBEnum.APP_BACKUP_TASK.clusterId.name());
								builder = new SqlQueryBuilder();
								builder.appendQueryIN(clusterIds);
								where.append(builder.getQuery().toString());
							} else {
								where = getWhereClause(where).append(joinPrefix)
										.append(PortalDBEnum.APP_BACKUP_TASK.clusterId.name()).append(" = ")
										.append("?");
							}
							break;
						case List:
							clusterFilterApplied = true;
							where = getWhereClause(where).append(joinPrefix)
									.append(PortalDBEnum.APP_BACKUP_TASK.clusterId.name());
							builder = new SqlQueryBuilder();
							builder.appendQueryIN(filterObject.getValues());
							where.append(builder.getQuery().toString());
							break;
						default:
							break;
						}
						break;
					case Status:
						switch (filterObject.getValueType()) {
						case Single:
							where = getWhereClause(where).append(joinPrefix)
									.append(PortalDBEnum.APP_BACKUP_TASK.status.name()).append(" = ")
									.append("?");
							break;
						case List:
							where = getWhereClause(where).append(joinPrefix)
									.append(PortalDBEnum.APP_BACKUP_TASK.status.name());
							builder = new SqlQueryBuilder();
							builder.appendQueryIN(filterObject.getValues());
							where.append(builder.getQuery().toString());
							break;
						default:
							break;
						}
						break;
					default:
						break;
					}
					break;
				case SORT:
					switch (filterObject.getSortKey()) {
					case App:
						sortOrder = getSortClause(sortOrder).append(joinPrefix)
								.append(PortalDBEnum.APP_BACKUP_TASK.appName);
						break;
					case Cluster:
						sortOrder = getSortClause(sortOrder).append(joinPrefix)
								.append(PortalDBEnum.APP_BACKUP_TASK.clusterName);
						break;
					case CreationTime:
						sortOrder = getSortClause(sortOrder).append(joinPrefix)
								.append(PortalDBEnum.APP_BACKUP_TASK.completedTime);
						break;
					default:
						break;
					}
					if (sortOrder != null && filterObject.getOperator().ordinal() == Operator.DESC.ordinal()) {
						sortOrder.append(" DESC ");
					}
					break;
				default:
					break;
				}
			}
		}

		if(!clusterFilterApplied) {
			where = getWhereClause(where)
					.append(joinPrefix).append(PortalDBEnum.APP_BACKUP_TASK.clusterId.name());
			builder = new SqlQueryBuilder();
			builder.appendQueryIN(clusterIds);
			where.append(builder.getQuery().toString());
//					.append(" IN (")
//					.append("?").append(")");
		}

		if(whereLatest != null) {			
			sb.append(" WHERE ").append(whereLatest);

			if(where != null) {
				sb.append(" WHERE ").append(where);
			}

			sb.append(sbGroup);
		}

		if(where != null) {

			if(whereLatest != null) {
				sb.append(" AND ");	
			} else {
				sb.append(" WHERE ");
			}

			sb.append(where);


			sbCount.append(" WHERE ").append(where);
		}

		//Default sort order 
		if(sortOrder == null) {
			sortOrder = getSortClause(sortOrder)
					//.append(joinPrefix).append(PortalDBEnum.APP_BACKUP_TASK.appName)
					//.append(", ")
					.append(joinPrefix).append(PortalDBEnum.APP_BACKUP_TASK.completedTime.name()).append(" DESC");
		}

		sb.append(sortOrder).append(" limit ").append("?").append(" offset ").append("?");

		Map<String, String> sqlMap = new HashMap<>();
		sqlMap.put("data", sb.toString());
		sqlMap.put("count", sbCount.toString());

		return sqlMap;
	}

	private String mDelete() {
		StringBuilder sb = new StringBuilder("DELETE FROM ")
				.append(table)
				.append(" WHERE ")
				.append(PortalDBEnum.APP_BACKUP_TASK.arkBackupName.name()).append(" = ?");

		return sb.toString();
	}

	private StringBuilder getWhereClause(StringBuilder whereClause){
		if(whereClause == null){
			whereClause = new StringBuilder();
			whereClause.append(" ");						
		} else{
			whereClause.append(" AND ");
		}
		return whereClause;			
	}

	private StringBuilder getSortClause(StringBuilder sortOrder){
		if(sortOrder == null){
			sortOrder = new StringBuilder();
			sortOrder.append(" ORDER BY ");						
		} else{
			sortOrder.append(", ");
		}
		return sortOrder;			
	}
}
