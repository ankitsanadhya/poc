/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.mwp.p.dal;

import java.util.ArrayList;
import java.util.List;

import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.common.enums.NotificationType;
import com.mwp.common.enums.Operator;
import com.mwp.common.vo.FilterObject;
import com.mwp.p.common.enums.PortalDBEnum;

public class AlertsDB
{
	String table = "";
	StringBuilder colList;

	public AlertsDB() 
	{
		table = PortalDBEnum.TABLE_NAMES.alerts.name();

		colList=new StringBuilder(PortalDBEnum.ALERTS.alertId.name());
		colList.append(", ");
		colList.append( PortalDBEnum.ALERTS.alertType.name() );
		colList.append(", ");
		colList.append( PortalDBEnum.ALERTS.messageType.name() );
		colList.append(", ");
		colList.append( PortalDBEnum.ALERTS.info.name() );
		colList.append(", ");
		colList.append( PortalDBEnum.ALERTS.commandMessage.name() );
		colList.append(", ");
		colList.append( PortalDBEnum.ALERTS.createdDate.name());
	}


	/**
	 * This method return insert alert query. 
	 * @param clusterId
	 * @param nodeId
	 * @param alertType {@link NotificationType}
	 * @param notification
	 * @return insert alert query string.
	 */
	public String insert()
	{
		StringBuilder qry= new StringBuilder();
		qry.append("INSERT INTO ");
		qry.append( table); 
		qry.append( "(");
		qry.append( colList); 
		qry.append( ") VALUES (");
		qry.append("?");
		qry.append( ",");
		qry.append("?");
		qry.append( ",");
		qry.append("?");
		qry.append( ",");
		qry.append("?");
		qry.append( ",");
		qry.append("?");
		qry.append( ",");
		qry.append("NOW()");
		qry.append( ")");

		return qry.toString();
	}

	/**
	 * This method return list of alerts.
	 * @return select query of alerts.
	 */
	public String list() {
		StringBuilder qry= new StringBuilder("SELECT ");
		qry.append(colList);
		qry.append(" FROM ");
		qry.append(table);

		return qry.toString();
	}

	
	

	private StringBuilder getWhereClause(StringBuilder whereClause){
		if(whereClause == null){
			whereClause = new StringBuilder();
			whereClause.append(" WHERE ");						
		} else{
			whereClause.append(" AND ");
		}
		return whereClause;			
	}

	/**
	 * This method return select alert query and row count query,
	 * @param pageNo
	 * @param pageSize
	 * @param filters
	 * @return
	 */
	public List<String> listAlertsFilter(List<FilterObject> filters) {
		List<String> queries = new ArrayList<>();
		
		StringBuilder whereClause = null;
		
		SqlQueryBuilder queryBuilder = new SqlQueryBuilder();
		
		StringBuilder qry= new StringBuilder();

		qry.append("SELECT SQL_CALC_FOUND_ROWS ");
		qry.append(colList);
		qry.append(" FROM ");
		qry.append(table);


		if(filters!=null)
		{
			for (FilterObject filterObject : filters)
			{
				switch (filterObject.getFilterType()) 
				{
				case FILTER:
					switch (filterObject.getFilterkey())
					{
					case MessageType:
						queryBuilder.appendQuery(PortalDBEnum.ALERTS.messageType.name());
						whereClause = getWhereClause(whereClause);
						whereClause.append(PortalDBEnum.ALERTS.messageType.name());

						List<Integer> lstMsgType = new ArrayList<>();
						for (String msgType : filterObject.getValues()) {
							lstMsgType.add(Integer.valueOf(msgType));
						}
						queryBuilder.appendQueryIN(lstMsgType);
//						whereClause.append(" IN ( ");
//						whereClause.append("?");
//						//whereClause.append(connection.formatIntForIn(lstMsgType));
//						whereClause.append(")");

						break;
					case AlertType:

						whereClause = getWhereClause(whereClause);
						whereClause.append(PortalDBEnum.ALERTS.alertType.name());

						List<Integer> lstAlertType = new ArrayList<>();
						for (String alertType : filterObject.getValues()) {
							lstAlertType.add(Integer.valueOf(alertType));
						}
						
						whereClause .append(" IN ( ");
						whereClause.append("?");
						//whereClause.append(connection.formatIntForIn(lstAlertType));
						whereClause.append(")");

						break;
					default:
						break;
					}
					break;
				case SEARCHTEXT:
					whereClause = getWhereClause(whereClause);
					whereClause.append(PortalDBEnum.ALERTS.commandMessage.name());

					if(filterObject.getOperator().ordinal()== Operator.LIKE.ordinal())
					{
						//device name contains search text
						whereClause.append(" LIKE ");
						whereClause.append("?");
						//whereClause.append(connection.formatStringForLike(true,filterObject.getStartValue() , true));							
					}
					else if(filterObject.getOperator().ordinal()== Operator.EQUAL.ordinal()) 
					{
						whereClause.append(" = ");
						whereClause.append("?");
						//whereClause.append(PortalDatabaseEngine.getInstance().getConnection().formatString(filterObject.getStartValue()));
					}
					break;
				default:
					break;
				}
			}
		}
		if(whereClause!=null)
			qry.append(whereClause);

		qry.append(" ORDER BY ");
		qry.append(PortalDBEnum.ALERTS.createdDate);
		qry.append(" DESC ");
		qry.append(" limit ");
//		qry.append(pageSize);
		qry.append("?");
		qry.append(" offset ");
//		qry.append(offset);
		qry.append("?");

		queries.add(qry.toString());
		queries.add("SELECT FOUND_ROWS() as rowCount");

		return queries;
	}

}
