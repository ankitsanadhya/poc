/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.mwp.p.dal;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.mwp.common.StringFunctions;
import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.db.Interface.IConnection;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.common.enums.PortalDBEnum.DOWNLOADS;
import com.mwp.p.dal.engine.PortalDatabaseEngine;


public class DownloadDB
{

	//add, edit,delete,list
	private IConnection connection= null;
	String table;
	StringBuilder colList;
	
	public DownloadDB() {
		connection = PortalDatabaseEngine.getInstance().getConnection();
		table = PortalDBEnum.TABLE_NAMES.downloads.name();
		colList = new StringBuilder(DOWNLOADS.resourceId.name());
		colList.append(",");
		colList.append(DOWNLOADS.resourceType.name());
		colList.append(",");
		colList.append(DOWNLOADS.details.name());
		colList.append(",");
		colList.append(DOWNLOADS.sortOrder.name());
	}
	
	//insert into downloads(resourceId, resourceType , details ,sortOrder) select 'ds12333fsdfsf','0','{"des":"dsfs"}', max(sortOrder)+1 from downloads;


	public String insert() 
	{
		StringBuilder qry= new StringBuilder();
		qry.append("INSERT INTO ");
		qry.append( table); 
		qry.append( "(");
		qry.append( colList); 
		qry.append( ") SELECT ");
		qry.append( "?");
//		qry.append( connection.formatString(resourceId));
		qry.append( ",");
		qry.append( "?");
//		qry.append( resourceType.ordinal());
		qry.append( ",");
		qry.append( "?");
//		qry.append(connection.formatString( details));
		qry.append( ", IFNULL(MAX(");
		qry.append(DOWNLOADS.sortOrder.name());
		qry.append( "),0) +1 ");
		qry.append( "FROM ");
		qry.append( table); 
		qry.append(" WHERE ");
		qry.append( DOWNLOADS.resourceType.name());
		qry.append( " = ");
		qry.append( "?");
		//qry.append(resourceType.ordinal());

		return qry.toString();

	}


	
	public String edit()
	{
		StringBuilder qry= new StringBuilder();
		qry.append("UPDATE ");
		qry.append(table);
		qry.append(" SET ");
		qry.append( DOWNLOADS.details.name());
		qry.append( " = ");
		qry.append( "?");
//		qry.append(connection.formatString(details));
		qry.append(" WHERE ");
		qry.append( DOWNLOADS.resourceId.name());
		qry.append( " = ");
		qry.append( "?");
//		qry.append( connection.formatString(resourceId));
		return qry.toString();
	}

	/**
	 * return query string for listing all resourses 
	 * @return
	 */
	public String list(String resourceType)
	{
		StringBuilder qry= new StringBuilder();
		qry.append("SELECT ");
		qry.append(colList);
		qry.append(" FROM ");
		qry.append(table);
		if(!StringFunctions.isNullOrWhitespace(resourceType))
		{
			qry.append(" WHERE ");
			qry.append( DOWNLOADS.resourceType.name());
			qry.append( " = ");
			qry.append("?");
//			qry.append(ResourceType.valueOf(resourceType).ordinal());
		}
		qry.append(" ORDER BY ");
		qry.append( DOWNLOADS.sortOrder.name());
		

		return qry.toString();
	}
	
	public String listInvitedResources(List<String> groupIds, String resourceType)
	{
		// StringBuilder sb = new StringBuilder();

		SqlQueryBuilder queryBuilder = new SqlQueryBuilder();

		queryBuilder.appendQuery("Select ");
		queryBuilder.appendQuery(PortalDBEnum.TABLE_NAMES.downloads);
		queryBuilder.appendQuery(".* FROM ");
		queryBuilder.appendQuery(PortalDBEnum.TABLE_NAMES.groupResources);
		queryBuilder.appendQuery(" AS groupRes ");
		queryBuilder.appendQuery(" INNER JOIN ");
		queryBuilder.appendQuery(PortalDBEnum.TABLE_NAMES.downloads);
		queryBuilder.appendQuery(" AS downloads ON downloads.");
		queryBuilder.appendQuery(PortalDBEnum.DOWNLOADS.resourceId);
		queryBuilder.appendQuery(" = groupRes.");
		queryBuilder.appendQuery(PortalDBEnum.GROUP_RESOURCES.resourceId);
		queryBuilder.appendQuery(" WHERE ");
		queryBuilder.appendQuery(" groupRes.");
		queryBuilder.appendQuery(PortalDBEnum.GROUP_RESOURCES.groupId);

		queryBuilder.appendQueryIN(groupIds);
		
		// sb.append(" IN (");
		// sb.append(connection.formatStringForIn(groupIds));
		// sb.append(") ");

		if (!StringFunctions.isNullOrWhitespace(resourceType)) {
			queryBuilder.appendQuery(" AND ");
			queryBuilder.appendQuery(" groupRes.");
			queryBuilder.appendQuery(PortalDBEnum.GROUP_RESOURCES.resourceType);
			queryBuilder.appendQuery(" = ");
			queryBuilder.appendQuery("?");
//			queryBuilder.appendQuery(ResourceType.valueOf(resourceType).ordinal())
		}

		queryBuilder.appendQuery(" GROUP BY ");
		queryBuilder.appendQuery(" downloads.");
		queryBuilder.appendQuery(PortalDBEnum.DOWNLOADS.resourceId);
		queryBuilder.appendQuery(" ORDER BY ");
		queryBuilder.appendQuery(" downloads.");
		queryBuilder.appendQuery(PortalDBEnum.DOWNLOADS.sortOrder);
		return queryBuilder.getQuery().toString();
	}
	/**
	 * generate query string to get resourseInfo for given id
	 * @param resourseId
	 * @return
	 */
	public String get()
	{
		StringBuilder qry= new StringBuilder();
		qry.append("SELECT ");
		qry.append(colList);
		qry.append(" FROM ");
		qry.append(table);
		qry.append(" WHERE ");
		qry.append(DOWNLOADS.resourceId.name());
		qry.append(" = ");
		qry.append("?");
		//qry.append(connection.formatString(resourceId));

		return qry.toString();
	}

	/**
	 *  generate query string to delete resourse from resourse table
	 * @param resourseId
	 * @return
	 */
	public String delete()
	{
		StringBuilder qry= new StringBuilder("DELETE FROM " );
		qry.append(table );
		qry.append(" WHERE ");
		qry.append(DOWNLOADS.resourceId.name());
		qry.append(" = ");
		qry.append("?");
//		qry.append(connection.formatString(resourseId));
		return qry.toString();

	}
	/**
	 * this method assign given sort order to given resources
	 * @param resourceIdOrderMap
	 * @return
	 */
	public String updateSortOrder(Map<String,Integer> resourceIdOrderMap)
	{
		SqlQueryBuilder queryBuilder = new SqlQueryBuilder();
		StringBuilder qry = new StringBuilder();
		queryBuilder.appendQuery("UPDATE ");
		queryBuilder.appendQuery(table);
		queryBuilder.appendQuery(" SET ");
		queryBuilder.appendQuery(PortalDBEnum.DOWNLOADS.sortOrder);
		queryBuilder.appendQuery(" = (case ");
		//for (Map.Entry<String, Integer> mapEntry : resourceIdOrderMap.entrySet()) {
			queryBuilder.appendQuery(" when ");
			queryBuilder.appendQuery(PortalDBEnum.DOWNLOADS.resourceId);
			queryBuilder.appendQuery(" = ");
			queryBuilder.appendQuery("?");
			// qry.append(connection.formatString(mapEntry.getKey()));
			queryBuilder.appendQuery(" THEN ");
			queryBuilder.appendQuery("?");
			//queryBuilder.appendQuery(mapEntry.getValue());
		//}
		queryBuilder.appendQuery(" END) ");

		queryBuilder.appendQuery(" WHERE ");
		queryBuilder.appendQuery(DOWNLOADS.resourceId.name());

		queryBuilder.appendQueryIN(new ArrayList<>(resourceIdOrderMap.keySet()));
		// queryBuilder.appendQuery(" IN( ");
		// queryBuilder.appendQuery(connection.formatStringForIn(new
		// ArrayList<>(resourceIdOrderMap.keySet())));
		// queryBuilder.appendQuery(") ");

		return qry.toString();
	}
	
	
//	UPDATE table_users
//    SET cod_user = (case when user_role = 'student' then '622057'
//                         when user_role = 'assistant' then '2913659'
//                         when user_role = 'admin' then '6160230'
//                    end),
//        date = '12082014'
//    WHERE user_role in ('student', 'assistant', 'admin') AND
//          cod_office = '17389551';
}
