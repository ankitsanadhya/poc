/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.mwp.p.dal.engine;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import com.mwp.common.Common;
import com.mwp.common.StringFunctions;
import com.mwp.common.Utils;
import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.common.constant.ErrorMessage;
import com.mwp.common.enums.NetworkTypeEnum;
import com.mwp.common.enums.Operator;
import com.mwp.common.vo.FilterObject;
import com.mwp.common.vo.NetworkVO;
import com.mwp.common.vo.QueryVO;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.dal.NetworkDB;

public class NetworkEngine 
{

	public NetworkVO createNetwork(String networkName, String userId, NetworkTypeEnum networkType)throws SQLException
	{
		 return mCreateNetwork( networkName, userId, networkType);
	}
	
	public Map<String, Object>  listNetworkFilter(List<FilterObject> filterObjects,long pageNo, int pageSize,String userId) throws SQLException
	{
		return mListNetworkFilter(filterObjects, pageNo, pageSize, userId);
	}
	
	public void delete(String networkId) throws SQLException
	{
		 mDelete(networkId);
	}
	
	public void update(String networkId,String networkName)throws SQLException
	{
		mUpdate(networkId, networkName);
	}

	private NetworkVO mCreateNetwork(String networkName, String userId, NetworkTypeEnum networkType)
			throws SQLException {
		String networkId = Common.getRandomId();
		NetworkDB netDB = new NetworkDB();

		String sql = netDB.getNetworkByname();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(networkName).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			if (rs.next())
				throw new SQLException(ErrorMessage.NETWORK_EXIST);
			else {
				String insertQry = netDB.insert();
				QueryVO insertQueryVO = new SqlQueryBuilder(
						PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
								.appendQuery(insertQry).addParameter(networkId).addParameter(networkName)
								.addParameter(userId).addParameter(networkType).build();

				PortalDatabaseEngine.getInstance().getConnection().executeUpdate(insertQueryVO);
				return getNetwork(networkId);
			}
		}
	}
	
	private void mDelete(String networkId) throws SQLException {
		NetworkDB netDB = new NetworkDB();
		String qry = netDB.deleteNetwork();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(qry)
						.addParameter(networkId).build();

		PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
	}
	
	private void mUpdate(String networkId,String networkName)throws SQLException
	{
		NetworkDB netDB = new NetworkDB();
		String sql = netDB.getNetworkByname();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(networkName).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			if (rs.next()) {
				if (!rs.getString(PortalDBEnum.NETWORK.networkId.name()).equals(networkId))
					throw new SQLException(ErrorMessage.NETWORK_EXIST);
			} else {
				String updateQry = netDB.updateNetwork();
				
				QueryVO updateQueryVO = new SqlQueryBuilder(
						PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(updateQry)
								.addParameter(networkName).addParameter(networkId).build();
				
				PortalDatabaseEngine.getInstance().getConnection().executeUpdate(updateQueryVO);
			}
		}
	}
	
	private Map<String, Object> mListNetworkFilter(List<FilterObject> filterObjects, long pageNo, int pageSize,
			String userId) throws SQLException {
		HashMap<String, Object> hashOutput = new HashMap<>();
		ArrayList<NetworkVO> listNetwork = new ArrayList<>();
		NetworkDB netDB = new NetworkDB();

		List<String> queries = netDB.listNetworkFilter(filterObjects);
		long offset = (pageNo - 1) * pageSize;

		int totalNetworkCount = 0;
		List<Object> parameters = createFilterParameters(filterObjects, userId);
		parameters.add(pageSize);
		parameters.add(offset);

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
						.appendQuery(queries.get(0)).addParameters(parameters).build();

		QueryVO queryVOCount = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
						.appendQuery(queries.get(1)).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO);
				ResultSet rsCount = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVOCount)) {
			while (rsCount.next()) {
				totalNetworkCount = rsCount.getInt("rowCount");
			}

			while (rs.next()) {
				listNetwork.add(setNetworkObject(rs));
			}
		}

		int totalPages = totalNetworkCount / pageSize;
		if ((totalNetworkCount % pageSize) > 0) {
			totalPages += 1;
		}

		hashOutput.put("data", listNetwork);
		hashOutput.put("totalPages", totalPages);
		hashOutput.put("pageNo", pageNo);
		hashOutput.put("pageSize", pageSize);
		hashOutput.put("totalNetworkCount", totalNetworkCount);

		return hashOutput;
	}
	
	private List<Object> createFilterParameters(List<FilterObject> filters, String userId) {

		List<Object> parameters = new LinkedList<>();
		String searchString = null;
		boolean isNetWorkFilterAdded = false;
		if (filters != null) {
			for (FilterObject filterObject : filters) {
				switch (filterObject.getFilterType()) {
				case FILTER:
					switch (filterObject.getFilterkey()) {
					case NetworkType:
						NetworkTypeEnum networkType = NetworkTypeEnum.valueOf(filterObject.getStartValue());
						switch (networkType) {
						case publicNetwork:
							isNetWorkFilterAdded = true;
							parameters.add(NetworkTypeEnum.publicNetwork.ordinal());
							break;
						case privateNetwork:
							isNetWorkFilterAdded = true;
							parameters.add(userId);
							parameters.add(NetworkTypeEnum.privateNetwork.ordinal());

							break;
						case publicPrivateNetwork:
							isNetWorkFilterAdded = true;
							parameters.add(userId);
							parameters.add(NetworkTypeEnum.publicNetwork.ordinal());
							break;

						default:
							break;
						}
						break;
					default:
						break;
					}
					break;
				case SEARCHTEXT:
					if (filterObject.getOperator().ordinal() == Operator.LIKE.ordinal()) {
						searchString = filterObject.getStartValue();
						parameters.add(Utils.getFormatStringForLike(true, searchString, true));
					} else if (filterObject.getOperator().ordinal() == Operator.EQUAL.ordinal()) {
						parameters.add(filterObject.getStartValue());
					}
					break;
				case SORT:
					switch (filterObject.getSortKey()) {
					case Name:
						if (!StringFunctions.isNullOrEmpty(searchString)) {

							parameters.add(searchString);

							parameters.add(Utils.getFormatStringForLike(false, searchString, true));

							parameters.add(Utils.getFormatStringForLike(false, searchString, false));
						}
						break;
					case CreationTime:
						break;
					default:
						break;
					}

					break;
				default:
					break;
				}
			}
		}
		if (!isNetWorkFilterAdded) {
			parameters.add(NetworkTypeEnum.publicNetwork.ordinal());
		}
		
		return parameters;
	}
	
	private NetworkVO getNetwork(String networkId) throws SQLException {
		NetworkDB netDB = new NetworkDB();
		NetworkVO netVo = new NetworkVO();
		String query = netDB.getNetwork();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(query)
						.addParameter(networkId).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				netVo = setNetworkObject(rs);
			}
		}

		return netVo;
	}
	
	private NetworkVO setNetworkObject(ResultSet rs) throws SQLException
	{
		NetworkVO network = new NetworkVO();
		network.setNetworkId(rs.getString(PortalDBEnum.NETWORK.networkId.name()));
		network.setNetworkName(rs.getString(PortalDBEnum.NETWORK.networkName.name()));
		network.setUserId(rs.getString(PortalDBEnum.NETWORK.userId.name()));
		network.setNetworkType(NetworkTypeEnum.GetEnum(rs.getInt(PortalDBEnum.NETWORK.networkType.name())));
		network.setCreatedDate(rs.getTimestamp(PortalDBEnum.NETWORK.createdDate.name()).getTime());
		return network;
	}

}
