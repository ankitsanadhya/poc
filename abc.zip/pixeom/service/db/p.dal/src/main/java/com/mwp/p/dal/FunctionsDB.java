/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal;

import java.sql.SQLException;
import java.util.List;

import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.p.common.enums.PortalDBEnum;

public class FunctionsDB {

	public String addFunction() {
		return mAddFunction();
	}

	public String getFunctionByUserId() {
		return mGetFunctionByUserId();
	}

	/**
	 * create query to get function for given function id.
	 * @param functionId
	 * @return
	 */
	public String getFunction() {
		return mGetFunction();
	}

	/**
	 * create query to check if function with name already exists for user . 
	 * @param functionName name of function to check
	 * @param userId user id.
	 * @return 
	 */
	public String isFunctionExists() {
		return mIsFunctionExists();
	}

	/**
	 * create query to list all functions of user with user id.
	 * @param userId 
	 * @return
	 * @throws SQLException 
	 */
	public String listAllFunctions() {
		return mListAllFunctions();
	}


	/**
	 *  create query to get function with given function id and  version id
	 * @param functionId
	 * @param versionId
	 * @return
	 * @throws Exception
	 */
	public String getFunctionVersion() {
		return mGetFunctionVersion();
	}

	
	/**
	 * create query to get all versions of function for given version ids. 
	 * @param versionIds list of version ids.
	 * @return
	 * @throws Exception
	 */
	public String getFunctionVersions(List<String> versionIds) {
		return mGetFunctionVersions(versionIds);
	}

	/**
	 * create query to delete a function with function Id.
	 * @param functionId 
	 * @return deleted function funcationId
	 * @throws Exception 
	 */
	public String deleteFunction() {
		return mDeleteFunction();
	}

	private String mGetFunction() {
		StringBuilder sb = new StringBuilder();
		sb.append("Select * FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.functions);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.FUNCTIONS.functionId);
		sb.append(" = ");
		sb.append("?");
//		sb.append(dbCon.formatString(functionId));
		return sb.toString();
	}

	private String mIsFunctionExists() {
		StringBuilder sb = new StringBuilder();
		sb.append("Select ");
		sb.append(PortalDBEnum.FUNCTIONS.functionId);
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.functions);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.FUNCTIONS.name);
		sb.append(" = ");
		sb.append("?");
		//sb.append(dbCon.formatString(functionName));
		sb.append(" AND ");
		sb.append(PortalDBEnum.FUNCTIONS.userId);
		sb.append(" = ");
		sb.append("?");
//		sb.append(dbCon.formatString(userId));
		return sb.toString();
	}

	private String mGetFunctionByUserId() {
		StringBuilder sb = new StringBuilder();
		sb.append("Select * FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.functions);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.FUNCTIONS.name);
		sb.append(" = ");
		sb.append("?");
//		sb.append(dbCon.formatString(functionName));
		sb.append(" AND ");
		sb.append(PortalDBEnum.FUNCTIONS.userId);
		sb.append(" = ");
		sb.append("?");
//		sb.append(dbCon.formatString(userId));
		return sb.toString();
	}

	private String mAddFunction() {
		StringBuilder sb = new StringBuilder();
		sb.append("INSERT INTO ");
		sb.append(PortalDBEnum.TABLE_NAMES.functions);
		sb.append(" ( ");
		sb.append(PortalDBEnum.FUNCTIONS.functionId.name());
		sb.append(", ");
		sb.append(PortalDBEnum.FUNCTIONS.userId.name());
		sb.append(", ");
		sb.append(PortalDBEnum.FUNCTIONS.name.name());
		sb.append(", ");
		sb.append(PortalDBEnum.FUNCTIONS.modifiedDate.name());
		sb.append(" ) VALUES ( ");
//		sb.append(dbCon.formatString(functionVO.getFunctionId()));
		sb.append("?");
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(functionVO.getUserId()));
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(functionVO.getName()));
		sb.append(", NOW()");
		sb.append(" ) ");
		return sb.toString();
	}

	private String mListAllFunctions() {
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT ");
		sb.append(" f.* ");
		sb.append(", ");
		sb.append(PortalDBEnum.TABLE_NAMES.functionversions);
		sb.append(".");
		sb.append(PortalDBEnum.FUNCTION_VERSIONS.functionVersionId.name());
		sb.append(", ");
		sb.append(PortalDBEnum.TABLE_NAMES.functionversions);
		sb.append(".");
		sb.append(PortalDBEnum.FUNCTION_VERSIONS.version.name());
		sb.append(", ");
		sb.append(PortalDBEnum.TABLE_NAMES.functionversions);
		sb.append(".");
		sb.append(PortalDBEnum.FUNCTION_VERSIONS.body.name());
		sb.append(", ");
		sb.append(PortalDBEnum.TABLE_NAMES.functionversions);
		sb.append(".");
		sb.append(PortalDBEnum.FUNCTION_VERSIONS.toExecute.name());
		sb.append(", ");
		sb.append(PortalDBEnum.TABLE_NAMES.functionversions);
		sb.append(".");
		sb.append(PortalDBEnum.FUNCTION_VERSIONS.modifiedDate.name());
		sb.append(" as versionModifiedDate ");
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.functions);
		sb.append(" as f ");
		sb.append(" LEFT JOIN ");
		sb.append(PortalDBEnum.TABLE_NAMES.functionversions);
		sb.append(" ON f.functionId = functionversions.functionId ");
		sb.append(" WHERE ");
		sb.append(" f.userId = ");
		sb.append("?");
		//sb.append(PortalDatabaseEngine.getInstance().getConnection().formatString(userId));
		sb.append(" ORDER BY ");
		sb.append(" f.");
		sb.append(PortalDBEnum.FUNCTIONS.name);
		sb.append(" ASC ");

		return sb.toString();
	}

	
	private String mGetFunctionVersion() {
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT ");
		sb.append(" f.* ");
		sb.append(", ");
		sb.append(PortalDBEnum.TABLE_NAMES.functionversions);
		sb.append(".");
		sb.append(PortalDBEnum.FUNCTION_VERSIONS.functionVersionId.name());
		sb.append(", ");
		sb.append(PortalDBEnum.TABLE_NAMES.functionversions);
		sb.append(".");
		sb.append(PortalDBEnum.FUNCTION_VERSIONS.version.name());
		sb.append(", ");
		sb.append(PortalDBEnum.TABLE_NAMES.functionversions);
		sb.append(".");
		sb.append(PortalDBEnum.FUNCTION_VERSIONS.body.name());
		sb.append(", ");
		sb.append(PortalDBEnum.TABLE_NAMES.functionversions);
		sb.append(".");
		sb.append(PortalDBEnum.FUNCTION_VERSIONS.toExecute.name());
		sb.append(", ");
		sb.append(PortalDBEnum.TABLE_NAMES.functionversions);
		sb.append(".");
		sb.append(PortalDBEnum.FUNCTION_VERSIONS.modifiedDate.name());
		sb.append(" as versionModifiedDate ");
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.functions);
		sb.append(" as f ");
		sb.append(" JOIN ");
		sb.append(PortalDBEnum.TABLE_NAMES.functionversions);
		sb.append(" ON f.functionId = functionversions.functionId ");
		sb.append(" WHERE ");
		sb.append(" f.functionId = ");
		sb.append("?");
		//sb.append(dbCon.formatString(functionId));
		sb.append(" AND ");
		sb.append(PortalDBEnum.TABLE_NAMES.functionversions);
		sb.append(".");
		sb.append(PortalDBEnum.FUNCTION_VERSIONS.functionVersionId);
		sb.append(" = ");
		sb.append("?");
//		sb.append(dbCon.formatString(versionId));
		sb.append(" AND ");
		sb.append(" f.userId = ");
		sb.append("?");
//		sb.append(PortalDatabaseEngine.getInstance().getConnection().formatString(userId));
		return sb.toString();
	}

	private String mGetFunctionVersions(List<String> versionIds) {

//		for (String versionId : versionIds) {
//			if (sbVersionIds.length() > 0) {
//				sbVersionIds.append(",");
//			}
//			sbVersionIds.append(dbCon.formatString(versionId));
//		}
		SqlQueryBuilder builder = new SqlQueryBuilder();
		builder.appendQuery("SELECT ");
		builder.appendQuery(PortalDBEnum.TABLE_NAMES.functionversions);
		builder.appendQuery(".");
		builder.appendQuery(PortalDBEnum.FUNCTION_VERSIONS.functionId.name());
		builder.appendQuery(", ");
		builder.appendQuery(PortalDBEnum.TABLE_NAMES.functionversions);
		builder.appendQuery(".");
		builder.appendQuery(PortalDBEnum.FUNCTION_VERSIONS.functionVersionId.name());
		builder.appendQuery(", ");
		builder.appendQuery(PortalDBEnum.TABLE_NAMES.functionversions);
		builder.appendQuery(".");
		builder.appendQuery(PortalDBEnum.FUNCTION_VERSIONS.version.name());
		builder.appendQuery(", ");
		builder.appendQuery(PortalDBEnum.TABLE_NAMES.functionversions);
		builder.appendQuery(".");
		builder.appendQuery(PortalDBEnum.FUNCTION_VERSIONS.body.name());
		builder.appendQuery(", ");
		builder.appendQuery(PortalDBEnum.TABLE_NAMES.functionversions);
		builder.appendQuery(".");
		builder.appendQuery(PortalDBEnum.FUNCTION_VERSIONS.toExecute.name());
		builder.appendQuery(", ");
		builder.appendQuery(PortalDBEnum.TABLE_NAMES.functionversions);
		builder.appendQuery(".");
		builder.appendQuery(PortalDBEnum.FUNCTION_VERSIONS.modifiedDate.name());
		builder.appendQuery(" as versionModifiedDate ");
		builder.appendQuery(", f.");
		builder.appendQuery(PortalDBEnum.FUNCTIONS.name.name());
		builder.appendQuery(" FROM ");
		builder.appendQuery(PortalDBEnum.TABLE_NAMES.functionversions);
		builder.appendQuery(" JOIN ");
		builder.appendQuery(PortalDBEnum.TABLE_NAMES.functions);
		builder.appendQuery(" as f ");
		builder.appendQuery(" ON f.");
		builder.appendQuery(PortalDBEnum.FUNCTIONS.functionId.name());
		builder.appendQuery(" = ");
		builder.appendQuery(PortalDBEnum.TABLE_NAMES.functionversions);
		builder.appendQuery(".");
		builder.appendQuery(PortalDBEnum.FUNCTION_VERSIONS.functionId.name());
		builder.appendQuery(" WHERE ");
		builder.appendQuery(PortalDBEnum.TABLE_NAMES.functionversions);
		builder.appendQuery(".");
		builder.appendQuery(PortalDBEnum.FUNCTION_VERSIONS.functionVersionId);
		
		builder.appendQueryIN(versionIds);
//		builder.appendQuery(" IN(");
//		builder.appendQuery(sbVersionIds);
//		builder.appendQuery(")");
		
		return builder.getQuery().toString();
	}

	private String mDeleteFunction() {
		StringBuilder sb=new StringBuilder();
		sb.append("DELETE FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.functions);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.FUNCTIONS.functionId);
		sb.append(" = ");
		sb.append("?");
//		sb.append(dbCon.formatString(functionId));
		return sb.toString();
	}
}
