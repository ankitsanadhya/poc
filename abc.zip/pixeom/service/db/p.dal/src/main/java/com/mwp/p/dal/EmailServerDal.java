/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal;

import com.mwp.db.Interface.IConnection;
import com.mwp.p.common.enums.PortalDBEnum;

/**
 * This class contains query to get email server from emailServers table
 * @author root
 *
 */
public class EmailServerDal 
{
	IConnection dbCon;
	String table;
	StringBuilder colList;
	
	/**
	 * Email server Data access layer object
	 * @param conn
	 */
	public EmailServerDal(IConnection conn)
	{
		dbCon=conn;
		table= PortalDBEnum.TABLE_NAMES.emailServers.name();
		
		colList= new StringBuilder(PortalDBEnum.EMAIL_SERVERS.serverId.name());
		colList.append(", "	);		
		colList.append(PortalDBEnum.EMAIL_SERVERS.serverAddress.name()); 
		colList.append( ", ");
		colList.append( PortalDBEnum.EMAIL_SERVERS.serverName.name());
		colList.append( " ,");
		colList.append(PortalDBEnum.EMAIL_SERVERS.status.name()); 
		colList.append( ", ");	
		colList.append( PortalDBEnum.EMAIL_SERVERS.username.name()); 
		colList.append( ", ");	
		colList.append(PortalDBEnum.EMAIL_SERVERS.password.name());
		colList.append( ", ");
		colList.append( PortalDBEnum.EMAIL_SERVERS.port.name()); 
		colList.append( ", ");	
		colList.append(PortalDBEnum.EMAIL_SERVERS.priority.name());
		colList.append( ", ");
		colList.append(PortalDBEnum.EMAIL_SERVERS.modifiedDate.name()); 

	}
	
	/**
	 * Method to get email server
	 * @param serverName
	 * @return
	 */
	public String get()
	{
		StringBuilder qry= new StringBuilder("SELECT ");
		qry.append(colList);
		qry.append(" FROM ");
		qry.append(table);
		qry.append(" WHERE ");
		qry.append(PortalDBEnum.EMAIL_SERVERS.serverName.name()); 
		qry.append(" = ");
		qry.append("?");
		//qry.append( dbCon.formatString(serverName));
		return qry.toString();
	}
	
	public String listAll() 
	{
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT * FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.emailServers.name());
		sb.append(" ORDER BY ");		
		sb.append(PortalDBEnum.TABLE_NAMES.emailServers.name());sb.append(".");sb.append(PortalDBEnum.EMAIL_SERVERS.modifiedDate.name());
		
		sb.append(" DESC ");
		return sb.toString();
	}

	public String listsAllOrderByPriority() 
	{
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT * FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.emailServers.name());
		sb.append(" ORDER BY ");
		sb.append(PortalDBEnum.TABLE_NAMES.emailServers.name());sb.append(".");sb.append(PortalDBEnum.EMAIL_SERVERS.priority.name());
		sb.append(" ASC ");		
		return sb.toString();
	}

	public String insert() {
		StringBuilder sb = new StringBuilder();
		sb.append("INSERT INTO ");
		sb.append(PortalDBEnum.TABLE_NAMES.emailServers);
		sb.append(" ( ");
		sb.append(PortalDBEnum.EMAIL_SERVERS.serverId.name());
		sb.append(", ");
		sb.append(PortalDBEnum.EMAIL_SERVERS.serverAddress.name());
		sb.append(", ");
		sb.append(PortalDBEnum.EMAIL_SERVERS.serverName.name());
		sb.append(", ");
		sb.append(PortalDBEnum.EMAIL_SERVERS.status.name());
		sb.append(", ");
		sb.append(PortalDBEnum.EMAIL_SERVERS.username.name());
		sb.append(", ");
		sb.append(PortalDBEnum.EMAIL_SERVERS.password.name());
		sb.append(", ");
		sb.append(PortalDBEnum.EMAIL_SERVERS.port.name());
		sb.append(", ");
		sb.append(PortalDBEnum.EMAIL_SERVERS.priority.name());
		sb.append(", ");
		sb.append(PortalDBEnum.EMAIL_SERVERS.istls.name());
		sb.append(", ");
		sb.append(PortalDBEnum.EMAIL_SERVERS.modifiedDate.name());
		sb.append(" ) VALUES ( ");
		sb.append("?");
		//sb.append(dbCon.formatString(serverId));
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(serverAddress));
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(serverName));
		sb.append(", ");
		sb.append("?");
//		sb.append(status);
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(username));
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(password));
		sb.append(", ");
		sb.append("?");
//		sb.append(port);
		sb.append(" ,");
		sb.append("?");
//		sb.append(priority);
		sb.append(" ,");
		sb.append("?");
//		sb.append(isTLS);
		sb.append(", NOW()");
		sb.append(" ) ");

		sb.append("ON DUPLICATE KEY UPDATE ");
		sb.append(PortalDBEnum.EMAIL_SERVERS.serverAddress.name());
		sb.append(" = ");
		sb.append("?");
		//sb.append(dbCon.formatString(serverAddress));
		sb.append(", ");
		sb.append(PortalDBEnum.EMAIL_SERVERS.serverName.name());
		sb.append(" = ");
		sb.append("?");
//		sb.append(dbCon.formatString(serverName));
		sb.append(", ");
		sb.append(PortalDBEnum.EMAIL_SERVERS.status.name());
		sb.append(" = ");
		sb.append("?");
//		sb.append(status);
		sb.append(", ");
		sb.append(PortalDBEnum.EMAIL_SERVERS.username.name());
		sb.append(" = ");
		sb.append("?");
//		sb.append(dbCon.formatString(username));
		sb.append(", ");
		sb.append(PortalDBEnum.EMAIL_SERVERS.password.name());
		sb.append(" = ");
		sb.append("?");
//		sb.append(dbCon.formatString(password));
		sb.append(", ");
		sb.append(PortalDBEnum.EMAIL_SERVERS.port.name());
		sb.append(" = ");
		sb.append("?");
//		sb.append(port);
		sb.append(", ");
		sb.append(PortalDBEnum.EMAIL_SERVERS.priority.name());
		sb.append(" = ");
		sb.append("?");
//		sb.append(priority);
		sb.append(", ");
		sb.append(PortalDBEnum.EMAIL_SERVERS.istls.name());
		sb.append(" = ");
		sb.append("?");
//		sb.append(isTLS);
		return sb.toString();
	}

	public String Update() {
		StringBuilder sb = new StringBuilder();
		sb.append("UPDATE  ");
		sb.append(PortalDBEnum.TABLE_NAMES.emailServers);
		sb.append(" set  ");
		sb.append(PortalDBEnum.EMAIL_SERVERS.serverAddress.name());
		sb.append(" = ");
		sb.append("?");
		//sb.append(dbCon.formatString(serverAddress));
		sb.append(", ");
		sb.append(PortalDBEnum.EMAIL_SERVERS.serverName.name());
		sb.append(" = ");
		sb.append("?");
		//sb.append(dbCon.formatString(serverName));
		sb.append(", ");
		sb.append(PortalDBEnum.EMAIL_SERVERS.status.name());
		sb.append(" = ");
		sb.append("?");
//		sb.append(status);
		sb.append(", ");
		sb.append(PortalDBEnum.EMAIL_SERVERS.username.name());
		sb.append(" = ");
		sb.append("?");
//		sb.append(dbCon.formatString(username));
		sb.append(", ");
		sb.append(PortalDBEnum.EMAIL_SERVERS.password.name());
		sb.append(" = ");
		sb.append("?");
//		sb.append(dbCon.formatString(password));
		sb.append(", ");
		sb.append(PortalDBEnum.EMAIL_SERVERS.port.name());
		sb.append(" = ");
		sb.append("?");
//		sb.append(port);
		sb.append(", ");
		sb.append(PortalDBEnum.EMAIL_SERVERS.istls.name());
		sb.append(" = ");
		sb.append("?");
//		sb.append(istls);
		sb.append(", ");
		sb.append(PortalDBEnum.EMAIL_SERVERS.priority.name());
		sb.append(" = ");
		sb.append("?");
//		sb.append(priority);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.EMAIL_SERVERS.serverId.name());
		sb.append(" = ");
		sb.append("?");
//		sb.append(dbCon.formatString(serverId));
		return sb.toString();
	}
	
	public String getEmailServer() 
	{
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT * FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.emailServers.name());
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.EMAIL_SERVERS.serverId.name());
		sb.append(" = ");
		sb.append("?");
		// sb.append(dbCon.formatString(serverId));
		return sb.toString();
	}
	
	public String isExists() 
	{
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT ");
		sb.append(PortalDBEnum.EMAIL_SERVERS.serverId.name());
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.emailServers.name());
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.EMAIL_SERVERS.serverId.name());sb.append(" = ");
		sb.append("?");
		//sb.append(dbCon.formatString(serverId));
		return sb.toString();
	}
	
	public String delete() 
	{
		StringBuilder sb = new StringBuilder();
		sb.append("DELETE ");
		sb.append(" FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.emailServers.name());
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.EMAIL_SERVERS.serverId.name());
		sb.append(" = ");
		sb.append("?");
//		sb.append(dbCon.formatString(serverId));
		return sb.toString();
	}
}
