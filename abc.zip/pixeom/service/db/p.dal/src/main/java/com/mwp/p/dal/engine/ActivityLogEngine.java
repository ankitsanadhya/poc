/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal.engine;

import java.math.BigInteger;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.mwp.common.StringFunctions;
import com.mwp.common.Utils;
import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.common.constant.Constant;
import com.mwp.common.enums.Operator;
import com.mwp.common.vo.FilterObject;
import com.mwp.common.vo.QueryVO;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.common.vo.ActivityLogVo;
import com.mwp.p.dal.ActivityLogDB;

/**
 * This class execute queries related to table {@link ACTIVITY_LOG_LOG} 
 *
 */
public class ActivityLogEngine
{

	/**
	 * add new activity event log
	 * @param logId
	 * @param userId
	 * @param action
	 * @param paramJson
	 * @throws SQLException
	 */
	public void insert(String logId, String userId, String action, String paramJson) throws SQLException
	{
		mInsert(logId, userId, action, paramJson);
	}

	/**
	 * list activity according to filter along with pagging
	 * @param pageNo
	 * @param pageSize
	 * @param filters
	 * @return
	 * @throws SQLException
	 */
	public HashMap<String, Object> listByFilter(int pageNo, int pageSize, List<FilterObject> filters) throws SQLException
	{
		return mListByFilter(pageNo, pageSize, filters);
	}

	/**
	 * List all logs for an application
	 * @param appId
	 * @return
	 * @throws SQLException
	 */
	public List<ActivityLogVo> list()throws SQLException
	{
		return mListEvent();
	}

	/**
	 * List acticity event for last number of days 
	 * @param numberofdays
	 * @return  List<acticityEventVO> 
	 * @throws SQLException
	 */
	public List<ActivityLogVo> listByTime(int numberofdays) throws SQLException
	{
		return mListByTime(numberofdays);
	}
	/**
	 * delete all activity older than given number of days
	 * @param noOfDays
	 * @return
	 * @throws SQLException 
	 */
	public void purgeActivity(long noOfDays) throws SQLException
	{
		mPurgeActivity(noOfDays);
	}
	/**
	 * List acticity event wih paging 
	 * @param pageNum
	 * @param appId
	 * @param pageSize
	 * @return HashMap<String, Object> 
	 * @throws SQLException
	 */
	public  Map<String, Object> listByPage(int pageNum, int pageSize)throws SQLException
	{
		return mListByPage(pageNum, pageSize);
	}

	private void mInsert(String logId, String userId, String action, String paramJson) throws SQLException 
	{
		ActivityLogDB dbObj = new ActivityLogDB();
		String insertQry = dbObj.insert();

		List<String> parameters = new ArrayList<>();

		parameters.add(logId);
		parameters.add(userId);
		parameters.add(action);
		parameters.add(paramJson);
		
		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(insertQry).addParameters(parameters).build();

		PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
	}

	private List<ActivityLogVo> mListEvent() throws SQLException 
	{
		List<ActivityLogVo> lst = new ArrayList<>();
		ActivityLogDB dbObj = new ActivityLogDB();
		String lstQry =  dbObj.list();
		
		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(lstQry).build();
		
		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				lst.add(parseEventResult(rs));
			} 
		}
		return lst;
	}
	
	private HashMap<String, Object> mListByFilter(int pageNo, int pageSize, List<FilterObject> filters)
			throws SQLException {

		List<ActivityLogVo> lst = new ArrayList<>();
		int totalAppCount = 0;

		List<String> lstQry = new ActivityLogDB().listFilter(filters);

		int offset = (pageNo - 1) * pageSize;

		List<Object> parameters = createFilterParameters(filters);
		parameters.add(pageSize);
		parameters.add(offset);

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
						.appendQuery(lstQry.get(0)).addParameters(parameters).build();

		QueryVO queryVOCount = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
						.appendQuery(lstQry.get(1)).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO);
				ResultSet rsCount = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVOCount)) {
			while (rsCount.next()) {
				totalAppCount = rsCount.getInt("rowCount");
			}
			
			while (rs.next()) {
				lst.add(parseEventResult(rs));

			}
		}
		
		int totalPages = totalAppCount / pageSize;
		if ((totalAppCount % pageSize) > 0) {
			totalPages += 1;
		}

		HashMap<String, Object> hashOutput = new HashMap<>();

		hashOutput.put(Constant.DATA, lst);
		hashOutput.put("totalPages", totalPages);
		hashOutput.put("pageNo", pageNo);
		hashOutput.put("pageSize", pageSize);
		hashOutput.put("totalAppCount", totalAppCount);
		return hashOutput;
	}
	
	private List<Object> createFilterParameters(List<FilterObject> filters) {
		List<Object> parameters = new LinkedList<>();
		String searchString = null;
		if (filters != null) {
			for (FilterObject filterObject : filters) {
				switch (filterObject.getFilterType()) {
				case FILTER:
					switch (filterObject.getFilterkey()) {
					case User:
						parameters.add(filterObject.getStartValue());
						break;
					case Time:
						parameters.add(filterObject.getStartValue());
						break;
					default:
						break;

					}
					break;
				case SEARCHTEXT:
					if (filterObject.getOperator().ordinal() == Operator.LIKE.ordinal()) {
						searchString = filterObject.getStartValue();
						parameters.add(Utils.getFormatStringForLike(true, searchString, true));
					} else if (filterObject.getOperator().ordinal() == Operator.EQUAL.ordinal()) {
						parameters.add(filterObject.getStartValue());
					}
					break;
				case SORT:
					switch (filterObject.getSortKey()) {
					case Operation:
						if (!StringFunctions.isNullOrEmpty(searchString)) {
							parameters.add(searchString);

							parameters.add(Utils.getFormatStringForLike(false, searchString, true));

							parameters.add(Utils.getFormatStringForLike(true, searchString, false));
						}
						break;
					case CreationTime:
						break;
					default:
						break;
					}

					break;
				default:
					break;
				}
			}
		}
		return parameters;
	}

	private ActivityLogVo parseEventResult(ResultSet rs) throws SQLException
	{
		ActivityLogVo eventVo = new ActivityLogVo();
		eventVo.setId(BigInteger.valueOf(rs.getInt(PortalDBEnum.ACTIVITY_LOG.id.name())));
		eventVo.setUserId(rs.getString(PortalDBEnum.ACTIVITY_LOG.userId.name()));
		eventVo.setAction(rs.getString(PortalDBEnum.ACTIVITY_LOG.action.name()));
		eventVo.setTimeStampTicks(rs.getTimestamp(PortalDBEnum.ACTIVITY_LOG.timeStamp.name()).getTime());

		String param = rs.getString(PortalDBEnum.ACTIVITY_LOG.param.name());
		eventVo.setParam(new Gson().fromJson(param, new TypeToken<HashMap<String, Object>>(){}.getType()));

		return eventVo;
	}
	
	private List<ActivityLogVo> mListByTime(int numberofdays) throws SQLException 
	{
		List<ActivityLogVo> lst = new ArrayList<>();
		ActivityLogDB dbObj = new ActivityLogDB();
		String lstQry =  dbObj.listByTime();
		
		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(lstQry).addParameter(numberofdays).build();
		
		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				lst.add(parseEventResult(rs));
			} 
		}
		return lst;
	}
	
	private void mPurgeActivity(long noOfDays) throws SQLException {
		ActivityLogDB dbObj = new ActivityLogDB();
		String delQry = dbObj.purgeActivity();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(delQry)
						.addParameter(noOfDays).build();

		PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
	}
	
	private HashMap<String, Object> mListByPage(int pageNum, int queryLimit)  throws SQLException 
	{
		List<ActivityLogVo> lst = new ArrayList<>();
		HashMap<String, Object> hashOutput = new HashMap<>();
		ActivityLogDB dbObj = new ActivityLogDB();
		int totalAppEvents = 0;

		int offset = (pageNum - 1) * queryLimit;

		List<String> lstQry = dbObj.listWithEventCount();

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
						.appendQuery(lstQry.get(0)).addParameter(queryLimit).addParameter(offset).build();

		QueryVO queryVOCount = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
						.appendQuery(lstQry.get(1)).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO);
				ResultSet rsCount = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVOCount)) {
			while (rsCount.next()) {
				if (totalAppEvents <= 0) {
					/*
					 * getting total no of rows without page limit.
					 */
					totalAppEvents = rsCount.getInt("eventCount");
				}
			}
			while (rs.next()) {
				lst.add(parseEventResult(rs));
			}
		}
		
		int totalPages = totalAppEvents / queryLimit;
		if ((totalAppEvents % queryLimit) > 0) {
			totalPages += 1;
		}
		hashOutput.put(Constant.DATA, lst);
		hashOutput.put("totalPages", totalPages);
		hashOutput.put("pageNo", pageNum);
		hashOutput.put("pageSize", queryLimit);
		return hashOutput;
	}
}
