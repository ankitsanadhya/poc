/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal;


import java.util.ArrayList;
import java.util.List;

import com.mwp.db.Interface.IConnection;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.common.enums.PortalDBEnum.DOCKER_EVENT_LOG;
import com.mwp.p.dal.engine.PortalDatabaseEngine;

/**
 * This class create queries to log docket eventsn database related to table {@link DOCKER_EVENT_LOG}
 *
 */
public class DockerEventLogDB 
{
	private IConnection dbCon = PortalDatabaseEngine.getInstance().getConnection();

	/**
	 * Add new log info in table
	 * @param appId
	 * @param versionId
	 * @param deviceId
	 * @param event
	 * @param systemStatus
	 * @param createdDate
	 * @return
	 */
	public String insert() 
	{
		return mInsert();
	}

	/**
	 * List all events for an application 
	 * @param appId
	 * @return
	 */
	public String list()
	{
		return mList();
	}
	
	/**
	 * query to list log from last given number of days
	 * @param noOfDays
	 * @return
	 */
	public String listByTime()
	{
		return mListByTime();
	}

	/**
	 * List logs with paging
	 * @param pageNum
	 * @param appId
	 * @param queryLimit
	 * @return 
	 */
	public List<String> listByPaging()
	{
		return mListPaging();
	}

	private String mInsert() 
	{
		StringBuilder sb = new StringBuilder();
		sb.append("INSERT INTO ");
		sb.append(PortalDBEnum.TABLE_NAMES.dockerEventLog);
		sb.append(" ( ");
		sb.append(PortalDBEnum.DOCKER_EVENT_LOG.id.name());
		sb.append(", ");
		sb.append(PortalDBEnum.DOCKER_EVENT_LOG.applicationId.name());
		sb.append(", ");
		sb.append(PortalDBEnum.DOCKER_EVENT_LOG.versionId.name());
		sb.append(", ");
		sb.append(PortalDBEnum.DOCKER_EVENT_LOG.deviceId.name());
		sb.append(", ");
		sb.append(PortalDBEnum.DOCKER_EVENT_LOG.event.name());
		sb.append(", ");
		sb.append(PortalDBEnum.DOCKER_EVENT_LOG.systemStatus.name());
		sb.append(", ");
		sb.append(PortalDBEnum.DOCKER_EVENT_LOG.createdDate.name());
		sb.append(" ) VALUES ( ");
		sb.append("?");
//		sb.append(dbCon.formatString(Common.getRandomId()));
		sb.append(", ");
		sb.append("?");
		//sb.append(dbCon.formatString(appId));
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(versionId));
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(deviceId));
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(event));
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(systemStatus));
		sb.append(", ");
		sb.append( "from_unixtime(");
		sb.append("?");
//		sb.append(createdDate);
		sb.append( "))");
		return sb.toString();
	}
	
	private String mList() 
	{
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT SQL_CALC_FOUND_ROWS * FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.dockerEventLog);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.DOCKER_EVENT_LOG.applicationId.name());
		sb.append(" = ");
		sb.append("?");
		//sb.append(dbCon.formatString(appId));
		return sb.toString();	
	}
	/**
	 * this will list log from last given number of days
	 * @param noOfDays
	 * @return
	 */
	private String mListByTime() 
	{
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT * FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.dockerEventLog);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.DOCKER_EVENT_LOG.createdDate.name());
		sb.append(" > ");
		sb.append("NOW() - INTERVAL ");
		sb.append("?");
		//sb.append(noOfDays);
		sb.append(" DAY" );
		return sb.toString();		
	}
	private List<String> mListPaging()
	{
		List<String> eventSql = new ArrayList<>(); 
		
		StringBuilder sb = new StringBuilder();
		sb.append(mList());
		sb.append(" limit ");
		sb.append("?");
		//sb.append(queryLimit);
		sb.append(" offset ");
		sb.append("?");
//		sb.append(offset);

		eventSql.add(sb.toString());
		eventSql.add("SELECT FOUND_ROWS() as eventCount");
		return eventSql;

	}
}
