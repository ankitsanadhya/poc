/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal.engine;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.mwp.common.Common;
import com.mwp.common.StringFunctions;
import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.common.constant.Constant;
import com.mwp.common.enums.CommandEnum;
import com.mwp.common.enums.InstallJobStatusEnum;
import com.mwp.common.enums.SecretTypeEnum;
import com.mwp.common.enums.TypeEnum;
import com.mwp.common.vo.AuthorizationsVO;
import com.mwp.common.vo.InstallJobVO;
import com.mwp.common.vo.QueryVO;
import com.mwp.common.yamlparser.SecretVersionVO;
import com.mwp.common.yamlparser.SecretVo;
import com.mwp.logger.PALogger;
import com.mwp.p.common.Constants;
import com.mwp.p.common.PortalCommon;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.common.enums.PortalDBEnum.APP_SECRET;
import com.mwp.p.common.enums.PortalDBEnum.APP_SECRET_VERSION;
import com.mwp.p.common.enums.PortalDBEnum.JOB_SECRET;
import com.mwp.p.dal.InstallJobDB;
import com.mwp.p.dal.JobSecretDB;

/**
 * This class manages and execute queries to list update delete jobs of a user to install/uninstall/update apps on device etc.
 *
 */
public class InstallJobEngine {

	/**
	 * Add new job to database 
	 * @param installJobVO
	 * @return InstallJobVO object
	 * @throws Exception
	 */
	public InstallJobVO addJob(InstallJobVO installJobVO) throws SQLException
	{
		return mAddJob(installJobVO,null);
	}

	public InstallJobVO addJob(InstallJobVO installJobVO, List<SecretVo> lstSecretVo) throws SQLException
	{
		return mAddJob(installJobVO,lstSecretVo);
	}
	private InstallJobVO mAddJob(InstallJobVO installJobVO,List<SecretVo> lstSecretVo) throws SQLException
	{
		QueryVO insertJobQueryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
						.appendQuery(new InstallJobDB().insertJob()).addParameter(installJobVO.getInstalledJobId())
						.addParameter(installJobVO.getobjectId()).addParameter(installJobVO.getType().getValue())
						.addParameter(installJobVO.getTimeStamp()).addParameter(installJobVO.getStatus().getValue())
						.addParameter(installJobVO.getUserId()).addParameter(installJobVO.getAppId())
						.addParameter(installJobVO.getOperation()).addParameter(installJobVO.getAppVersion())
						.addParameter(installJobVO.getMessage()).addParameter(installJobVO.getDetail()).build();

		List<QueryVO> queries = new ArrayList<>();
		queries.add(insertJobQueryVO);
		/*
		 * Add updateAppSecret CommandEnum in job.
		 */
		if (lstSecretVo != null && !lstSecretVo.isEmpty()
				&& (CommandEnum.valueOf(installJobVO.getOperation()) == CommandEnum.installApplication
						|| CommandEnum.valueOf(installJobVO.getOperation()) == CommandEnum.updateApplication
						|| CommandEnum.valueOf(installJobVO.getOperation()) == CommandEnum.updateAppSecret)) {
			// insert in job Secrets

			for (SecretVo secretVo : lstSecretVo) {
				QueryVO queryVO = new SqlQueryBuilder().appendQuery(new JobSecretDB().insertMulti())
						.addParameter(Common.getRandomId())
						.addParameter(secretVo.getListSecretVersion().get(0).getAppSecretVersionId())
						.addParameter(installJobVO.getobjectId()).addParameter(installJobVO.getInstalledJobId())
						.addParameter(secretVo.getServiceName()).build();

				queries.add(queryVO);
			}
		}

		PortalDatabaseEngine.getInstance().getConnection().executeUpdatesInTransaction(queries);
		return installJobVO;
	}



	/**
	 * Update status of job in database
	 * @param jobId
	 * @param status status of job
	 * @return
	 * @throws Exception
	 */
	public boolean updateJobStatus(String jobId, InstallJobStatusEnum status) throws SQLException
	{
		return mUpdateJobStatus(jobId, status);
	}

	private boolean mUpdateJobStatus(String jobId, InstallJobStatusEnum status) throws SQLException
	{
		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new InstallJobDB().updateJobStatus())
				.addParameter(status.getValue())
				.addParameter(jobId).build();

		int insertCount = PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
		if(insertCount == 0)
		{
			PALogger.INFO("Updating job status===================SQL=  "+ queryVO.toString());
			throw new SQLException("update job failed.");
		}
		return true;
	}

	/**
	 * Get all jobs which have status as PENDING
	 * @return
	 * @throws SQLException
	 */
	public List<InstallJobVO> getAllPendingJobs() throws SQLException
	{
		return mGetAllPendingJobs();
	}

	/**
	 * Get all jobs of a device which have status as PENDING.
	 * @param userId
	 * @param objectId 
	 * @return
	 * @throws Exception
	 */
	public List<InstallJobVO> getAllPendingJobs(String userId,String objectId) throws SQLException
	{
		return mGetAllPendingJobs(userId, objectId);
	}
	
	public List<InstallJobVO> getAllPendingJobs(String objectId) throws SQLException
	{
		return mGetAllPendingJobs(objectId);
	}

	private List<InstallJobVO> mGetAllPendingJobs() throws SQLException
	{
		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new InstallJobDB().getAllPendingJobs()).build();

		List<InstallJobVO> jobs= new ArrayList<>();
		
		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)){
			while (rs.next()){
				jobs.add(this.setJobObject(rs));				
			}
		}
		return jobs;
	}

	
	private ArrayList<InstallJobVO> mGetAllPendingJobs(String objectId) throws SQLException
	{		
		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new InstallJobDB().getAllPendingJobsByDeviceId())
				.addParameter(objectId).build();
		
		ArrayList<InstallJobVO> jobs= new ArrayList<>();
		
		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO))
		{
			jobs = setJobObjectWithSecrets(rs);
		}
		return jobs;
	}
	
	
	private ArrayList<InstallJobVO> mGetAllPendingJobs(String userId, String objectId) throws SQLException
	{		
		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new InstallJobDB().getAllPendingJobsByUserNDeviceId())
				.addParameter(objectId)
				.addParameter(userId).build();
		
		ArrayList<InstallJobVO> jobs= new ArrayList<>();
		
		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO))
		{
			jobs = setJobObjectWithSecrets(rs);
		}
		return jobs;
	}

	/**
	 * Get all the jobs of a user
	 * @param authVo
	 * @return
	 * @throws SQLException
	 */
	public List<InstallJobVO> getAllJobs(AuthorizationsVO authVo) throws SQLException
	{
		return mGetAllJobs(authVo);
	}

	/**
	 * Update schedule time stamp of list of jobs.
	 * @param ticks ticks to update
	 * @param jobIds job ids list
	 * @return
	 * @throws SQLException if no jobs found in database from list of jobIds. 
	 */
	public boolean updateJobTimeStamp( long ticks, List<String> jobIds) throws SQLException
	{
		return mUpdateJobTimeStamp( ticks, jobIds);
	}

	private boolean mUpdateJobTimeStamp(long ticks, List<String> jobIds) throws SQLException
	{
		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
						.appendQuery(new InstallJobDB().updateJobTimeStamp(jobIds.size())).addParameter(ticks)
						.addParameters(jobIds).build();

		int insertCount = PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
		if (insertCount == 0) {
			throw new SQLException("update job failed.");
		}
		return true;
	}


	private List<InstallJobVO> mGetAllJobs(AuthorizationsVO authVo) throws SQLException
	{
		HashMap<String,InstallJobVO> jobsList= new HashMap<>();


		List<String> groupIds = null;
		if(authVo.getGroupPermissions()!=null)
			groupIds = new ArrayList<>(authVo.getGroupPermissions().keySet());
		
		List<Object> parameters = new ArrayList<>();
		parameters.add(authVo.getUserId());
		
		if(groupIds!= null && !groupIds.isEmpty())
		{
			parameters.addAll(groupIds);
		}
		
		String sql  = new InstallJobDB().getAllJobs(groupIds);
		InstallJobVO ijobvo= null;
		
		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(sql).addParameters(parameters).build();

		String jobID = "";
		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)){
			String appName = "";
			while (rs.next())
			{
				jobID= rs.getString(PortalDBEnum.INSTALL_JOBS.uId.name());
				if(!jobsList.containsKey(jobID))
				{
					ijobvo = this.setJobObject(rs);
					appName = rs.getString(PortalDBEnum.APPLICATION.title.name());

					if(StringFunctions.isNullOrWhitespace(appName)){
						appName = Constant.EDGECORE_SYSTEM_UPDATE_APPNAME;			
					}
					ijobvo.setIcon(rs.getString(PortalDBEnum.APPLICATION.icon.name()));
					if(!StringFunctions.isNullOrWhitespace(ijobvo.getIcon())){
						ijobvo.setIcon(PortalCommon.getInstance().createPublicUrl(ijobvo.getIcon(), Constants.UI_FOLDER_NAME));
					}
					ijobvo.setApplicationName(appName);

					jobsList.put(jobID, ijobvo);
				}
			}
		}
		return new ArrayList<>(jobsList.values());
	}

	/**
	 * Get install job object for device and application id
	 * @param userid
	 * @param appid
	 * @param objectid
	 * @return
	 * @throws SQLException
	 */
	public InstallJobVO getJob(String userid, String appid, String objectid ) throws SQLException
	{
		return mGetJobsWithData(userid, appid, objectid);
	}

	private InstallJobVO mGetJobsWithData(String userid, String appid, String objectid) throws SQLException
	{
		InstallJobVO ijobvo= null;
		
		QueryVO queryVO = new SqlQueryBuilder(PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
				.appendQuery(new InstallJobDB().getJobs(userid, appid, objectid))
				.addParameter(objectid)
				.addParameter(userid)
				.addParameter(appid)
				.build();
		
		try(ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)){
			while (rs.next())
			{
				ijobvo = this.setJobObject(rs);
			}

		}
		return ijobvo;
	}

	/**
	 * Delete existing jobs.
	 * @param jobIds list of job ids to delete
	 * @return
	 * @throws SQLException
	 */
	public boolean deleteJob(List<String> jobIds) throws SQLException
	{
		return mDeleteJob( jobIds);
	}

	private boolean mDeleteJob(List<String> jobIds) throws SQLException
	{
		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
						.appendQuery(new InstallJobDB().deleteJob(jobIds.size())).addParameters(jobIds).build();

		int insertCount = PortalDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
		if (insertCount == 0) {
			throw new SQLException("delete job failed.");
		}
		return true;
	}
	
	public Map<String, List<String>> getJobOperations(List<String> jobIds) throws SQLException {
		return mGetJobOperations(jobIds);
	}

	private HashMap<String, List<String>> mGetJobOperations(List<String> jobIds) throws SQLException {
		// hash map of devcies with list of operation for given jobs
		HashMap<String, List<String>> deviceOperations = new HashMap<>();

		List<String> operations = new ArrayList<>();
		String deviceId = "";

		// SqlArrayParam sqlArrayParam = new SqlArrayParam(jobIds.toArray(),
		// "VARCHAR");

		QueryVO queryVO = new SqlQueryBuilder(
				PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
						.appendQuery(new InstallJobDB().getJobOperations(jobIds)).addParameters(jobIds).build();

		try (ResultSet rs = PortalDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				deviceId = rs.getString(PortalDBEnum.INSTALL_JOBS.objectId.name());
				if (!deviceOperations.containsKey(deviceId)) {
					operations = new ArrayList<>();
					operations.add(rs.getString(PortalDBEnum.INSTALL_JOBS.operation.name()));
					deviceOperations.put(deviceId, operations);
				} else {
					String operation = rs.getString(PortalDBEnum.INSTALL_JOBS.operation.name());
					if (!deviceOperations.get(deviceId).contains(operation))
						deviceOperations.get(deviceId).add(operation);
				}

			}

		}
		return deviceOperations;

	}
	
	public static void main(String[] args) 
	{
		InstallJobEngine engg= new InstallJobEngine();
		List<String> jobIds = new  ArrayList<>();
		jobIds.add("002615c58a664c2fbae19a454837cf40");
		jobIds.add("013a0ddda74e4cd89eab860cc7ffc925");
		jobIds.add("0184df21601d48099bc53fee2d02dc35");
		jobIds.add("01860a93d41b42f4977bd0a31c1bab41");
		jobIds.add("01b6c226088c43bfb16c1b6e40de0108");
		jobIds.add("03e579e4c38a49e6b49c33fef2bade47");
		jobIds.add("6fd4f3760fa84588af00f000a166069e");
		jobIds.add("7591bacc5bf14d3a8ac2c1f7516d5490");
		Map<String, List<String>> deviceOperations;
		try
		{
			deviceOperations = engg.getJobOperations(jobIds);
			List<String> devcies= new ArrayList<>(deviceOperations.keySet());
			PALogger.INFO(devcies.size()+"");
		} catch (SQLException e) {

			PALogger.ERROR(e);
		}

	}

	private ArrayList<InstallJobVO> setJobObjectWithSecrets(ResultSet rs) throws SQLException
	{
		Map<String, InstallJobVO> mapObj = new HashMap<>();
		List<SecretVo> lstSecrets;
		String jobId;
		InstallJobVO jobVO;
		while (rs.next())
		{
			jobId= rs.getString(PortalDBEnum.TABLE_NAMES.installJobs + "."+ PortalDBEnum.INSTALL_JOBS.uId.name());
			if(mapObj.containsKey(jobId))
			{
				jobVO = mapObj.get(jobId);
				SecretVo secretObj = setAppsecret(rs);
				if(secretObj != null){
					jobVO.getSecretList().add(secretObj);
				}
			}
			else
			{
				lstSecrets = new ArrayList<>();
				jobVO = new InstallJobVO();
				jobVO.setInstalledJobId(jobId);
				jobVO.setobjectId(rs.getString(PortalDBEnum.TABLE_NAMES.installJobs + "."+PortalDBEnum.INSTALL_JOBS.objectId.name()));
				jobVO.setType(TypeEnum.GetEnum(rs.getInt(PortalDBEnum.TABLE_NAMES.installJobs + "."+PortalDBEnum.INSTALL_JOBS.type.name())));
				jobVO.setTimeStamp(rs.getLong(PortalDBEnum.TABLE_NAMES.installJobs + "."+PortalDBEnum.INSTALL_JOBS.timeStamp.name()));
				jobVO.setStatus(InstallJobStatusEnum.GetEnum(rs.getInt(PortalDBEnum.TABLE_NAMES.installJobs + "."+PortalDBEnum.INSTALL_JOBS.status.name())));
				jobVO.setUserId(rs.getString(PortalDBEnum.TABLE_NAMES.installJobs + "."+PortalDBEnum.INSTALL_JOBS.userId.name()));
				jobVO.setAppId(rs.getString(PortalDBEnum.TABLE_NAMES.installJobs + "."+PortalDBEnum.INSTALL_JOBS.appId.name()));
				jobVO.setOperation(rs.getString(PortalDBEnum.TABLE_NAMES.installJobs + "."+PortalDBEnum.INSTALL_JOBS.operation.name()));
				jobVO.setAppVersion(rs.getString(PortalDBEnum.TABLE_NAMES.installJobs + "."+PortalDBEnum.INSTALL_JOBS.appVersion.name()));
				jobVO.setMessage(rs.getString(PortalDBEnum.TABLE_NAMES.installJobs + "."+PortalDBEnum.INSTALL_JOBS.message.name()));
				jobVO.setDetail(rs.getString(PortalDBEnum.TABLE_NAMES.installJobs + "."+PortalDBEnum.INSTALL_JOBS.detail.name()));
				jobVO.setLastModified(rs.getTimestamp(PortalDBEnum.TABLE_NAMES.installJobs + "."+PortalDBEnum.INSTALL_JOBS.lastModified.name()).getTime());
				//read app Secret
				SecretVo secretObj = setAppsecret(rs);
				if(secretObj!=null)
					lstSecrets.add(secretObj);
				jobVO.setSecretList(lstSecrets);
				mapObj.put(jobId, jobVO);
			}				
		}
		return new ArrayList<>(mapObj.values());
	}
	private SecretVo setAppsecret(ResultSet rs) throws SQLException
	{
		String appSecretId=rs.getString(PortalDBEnum.TABLE_NAMES.appSecret + "."+APP_SECRET.appSecretId.name());
		if(StringFunctions.isNullOrWhitespace(appSecretId))
			return null;
		String appSecretVersionId = rs.getString(PortalDBEnum.TABLE_NAMES.appSecretVersion + "."+ APP_SECRET_VERSION.appSecretVersionId.name());
		if(StringFunctions.isNullOrWhitespace(appSecretVersionId))
			return null;

		SecretVo secretObj = new SecretVo();

		secretObj.setAppSecretId(appSecretId);
		secretObj.setAppId(rs.getString(PortalDBEnum.TABLE_NAMES.appSecret + "."+APP_SECRET.appId.name()));
		secretObj.setServiceName(rs.getString(PortalDBEnum.TABLE_NAMES.jobSecret + "."+JOB_SECRET.serviceName.name()));
		secretObj.setKey(rs.getString(PortalDBEnum.TABLE_NAMES.appSecret + "."+APP_SECRET.secretKey.name()));

		//	secretObj.setType(SecretTypeEnum.values()[rs.getInt(PortalDBEnum.TABLE_NAMES.appSecret + "."+ APP_SECRET.type.name())]);

		SecretVersionVO svo = new SecretVersionVO();

		svo.setAppSecretVersionId(appSecretVersionId);
		svo.setType(SecretTypeEnum.values()[rs.getInt(PortalDBEnum.TABLE_NAMES.appSecretVersion + "."+ APP_SECRET_VERSION.type.name())]);
		if(svo.getType().name().equals(SecretTypeEnum.file.name()))
		{
			String path = rs.getString(PortalDBEnum.TABLE_NAMES.appSecretVersion + "."+ APP_SECRET_VERSION.secretValue.name());
			svo.setPath(path);
			svo.setFileName(path.substring(path.lastIndexOf("/")+ 1));
		}
		else
			svo.setValue(rs.getString(PortalDBEnum.TABLE_NAMES.appSecretVersion + "."+ APP_SECRET_VERSION.secretValue.name()));

		svo.setDisplayName(rs.getString(PortalDBEnum.TABLE_NAMES.appSecretVersion + "."+ APP_SECRET_VERSION.displayName.name()));
		svo.setAppUserId(rs.getString(PortalDBEnum.TABLE_NAMES.appSecretVersion + "."+ APP_SECRET_VERSION.appUserId.name()));
		svo.setAppSecretId(secretObj.getAppSecretId());
		secretObj.getListSecretVersion().add(svo);

		return secretObj;
	}
	private InstallJobVO setJobObject(ResultSet rs) throws SQLException
	{
		InstallJobVO jobVO = new InstallJobVO();
		jobVO.setInstalledJobId(rs.getString(PortalDBEnum.INSTALL_JOBS.uId.name()));
		jobVO.setobjectId(rs.getString(PortalDBEnum.INSTALL_JOBS.objectId.name()));
		jobVO.setType(TypeEnum.GetEnum(rs.getInt(PortalDBEnum.INSTALL_JOBS.type.name())));
		jobVO.setTimeStamp(rs.getLong(PortalDBEnum.INSTALL_JOBS.timeStamp.name()));
		jobVO.setStatus(InstallJobStatusEnum.GetEnum(rs.getInt(PortalDBEnum.INSTALL_JOBS.status.name())));
		jobVO.setUserId(rs.getString(PortalDBEnum.INSTALL_JOBS.userId.name()));
		jobVO.setAppId(rs.getString(PortalDBEnum.INSTALL_JOBS.appId.name()));
		jobVO.setOperation(rs.getString(PortalDBEnum.INSTALL_JOBS.operation.name()));
		jobVO.setAppVersion(rs.getString(PortalDBEnum.INSTALL_JOBS.appVersion.name()));
		jobVO.setMessage(rs.getString(PortalDBEnum.INSTALL_JOBS.message.name()));
		jobVO.setDetail(rs.getString(PortalDBEnum.INSTALL_JOBS.detail.name()));
		jobVO.setLastModified(rs.getTimestamp(PortalDBEnum.INSTALL_JOBS.lastModified.name()).getTime());

		return jobVO;
	}



}

