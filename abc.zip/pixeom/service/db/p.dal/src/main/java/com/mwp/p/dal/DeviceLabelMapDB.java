/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.dal;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.common.enums.Status;
import com.mwp.db.Interface.IConnection;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.common.enums.PortalDBEnum.DEVICE_LABEL_MAP;
import com.mwp.p.dal.engine.PortalDatabaseEngine;

/**
 * This class create queries related to device label relation table {@link DEVICE_LABEL_MAP} 
 *
 */
public class DeviceLabelMapDB 
{
	private IConnection dbCon= null;

	public DeviceLabelMapDB(){
		dbCon = PortalDatabaseEngine.getInstance().getConnection();
	}

	/**
	 * Add new label device mapping entry.
	 * @param labelId
	 * @param deviceId
	 * @return
	 */
	public String addDeviceLabel(){
		return mAddDeviceLabel();
	}

	/**
	 * Get all device ids related to a label id.
	 * @param labelId
	 * @param userId
	 * @return
	 */
//	public String getDeviceIdsOfLabel(String labelId, String userId){
//		return mGetDeviceIdsOfLabel(labelId, userId);
//	}

	/**
	 * Update existing label id  of device and set other.
	 * @param labelId
	 * @param deviceId
	 * @return
	 */
	public String updateDeviceLabel()
	{
		return this.mUpdateDeviceLabel();
	}

	/**
	 * Delete device label mapping entry
	 * @param labelId
	 * @param deviceId
	 * @return
	 */
	public String deleteDeviceByLabelId(){
		return mDeleteDeviceLabel();
	}

	/**
	 * Set all devices label id to root label id to make relation of device to root label
	 * @param labelId
	 * @return
	 */
//	public String updateChildDevicesOfLabelToRoot(String labelId){
//		return mShiftChildDevicesOfLabelToRoot(labelId);
//	}

	/**
	 * Update label id of list of device id.
	 * @param labelId
	 * @param deviceId
	 * @return
	 */
	public String updateDeviceLabel(List<String> deviceId){
		return this.mUpdateDeviceLabel(deviceId);
	}

	/**
	 * Get all devices all information related to a label id.
	 * @param labelId
	 * @param userId
	 * @return	 
	 */
	public String getDevicesofLabel(){
		return this.mGetDevicesofLabel();
	}

	/**
	 * Select labels related to a device 
	 * @param deviceId
	 * @return
	 */
	public String getDeviceLabelByDeviceId() {
		StringBuilder sb = new StringBuilder();
		sb.append("Select * FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.devicelabelmap);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.DEVICE_LABEL_MAP.deviceId.name());
		sb.append(" = ");
		sb.append("?");
//		sb.append(dbCon.formatString(deviceId));

		return sb.toString();
	}

	/**
	 * Get perticular entry of device label for device id and label id
	 * @param deviceId
	 * @param labelId
	 * @return
	 */
	public String getDeviceLabel() {
		StringBuilder sb = new StringBuilder();
		sb.append("Select * FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.devicelabelmap);
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.DEVICE_LABEL_MAP.deviceId.name());
		sb.append(" = ");
		sb.append("?");
		sb.append(" AND ");
		sb.append(PortalDBEnum.DEVICE_LABEL_MAP.labelId.name());
		sb.append(" = ");
		sb.append("?");
		return sb.toString();
	}

	private String mUpdateDeviceLabel(){
		StringBuilder sb = new StringBuilder();
		sb.append("UPDATE ");
		sb.append(PortalDBEnum.TABLE_NAMES.devicelabelmap);
		sb.append(" SET ");  
		sb.append(PortalDBEnum.DEVICE_LABEL_MAP.labelId.name());
		sb.append(" = "); 
		sb.append("?"); 
//		sb.append(dbCon.formatString(labelId));
		sb.append(" WHERE ");
		sb.append(PortalDBEnum.DEVICE_LABEL_MAP.deviceId.name());
		sb.append(" = ");
		sb.append("?");
//		sb.append(dbCon.formatString(deviceId));  
		return sb.toString();
	}

	private String mUpdateDeviceLabel(List<String> deviceId){
		SqlQueryBuilder queryBuilder = new SqlQueryBuilder();
		queryBuilder.appendQuery("UPDATE ");
		queryBuilder.appendQuery(PortalDBEnum.TABLE_NAMES.devicelabelmap);
		queryBuilder.appendQuery(" SET ");  
		queryBuilder.appendQuery(PortalDBEnum.DEVICE_LABEL_MAP.labelId.name());
		queryBuilder.appendQuery(" = "); 
		queryBuilder.appendQuery("?"); 
//		queryBuilder.appendQuery(dbCon.formatString(labelId));
		queryBuilder.appendQuery(" WHERE ");
		queryBuilder.appendQuery(PortalDBEnum.DEVICE_LABEL_MAP.deviceId.name());
		
		queryBuilder.appendQueryIN(deviceId);
		
//		queryBuilder.appendQuery(" In ( ");
//		queryBuilder.appendQuery(dbCon.formatStringForIn(deviceId));
//		queryBuilder.appendQuery(")");
		
		return queryBuilder.getQuery().toString();
	}

	private String mGetDevicesofLabel() {

		StringBuilder sb = new StringBuilder();
		sb.append("Select ");
		sb.append(PortalDBEnum.VIEW_NAMES.devicesnodes_view);
		sb.append(".*");
		sb.append(", ");
		sb.append(PortalDBEnum.TABLE_NAMES.devicelabelmap);
		sb.append(".");
		sb.append(DEVICE_LABEL_MAP.labelId);
		sb.append(" FROM ");
		sb.append(PortalDBEnum.VIEW_NAMES.devicesnodes_view);

		sb.append(" INNER JOIN ");
		sb.append(PortalDBEnum.TABLE_NAMES.devicelabelmap);
		sb.append(" ON ");
		sb.append(PortalDBEnum.TABLE_NAMES.devicelabelmap);
		sb.append(".");
		sb.append(PortalDBEnum.DEVICE_LABEL_MAP.deviceId.name());
		sb.append(" = ");
		sb.append(PortalDBEnum.VIEW_NAMES.devicesnodes_view);
		sb.append(".");
		sb.append(PortalDBEnum.DEVICES_NODES_VIEW.devices_deviceId.name());

		sb.append(" WHERE ");
		sb.append(PortalDBEnum.DEVICE_LABEL_MAP.labelId.name());
		sb.append(" = ");
		sb.append("?");
		//sb.append(dbCon.formatString(labelId));
		sb.append(" AND ");
		sb.append(PortalDBEnum.DEVICES_NODES_VIEW.devices_userId.name());
		sb.append(" = ");
		sb.append("?");
//		sb.append(dbCon.formatString(userId));
		sb.append(" AND ");
		sb.append(PortalDBEnum.DEVICES_NODES_VIEW.devices_deviceStatus);
		sb.append(" != ");
		sb.append(Status.DELETED.ordinal());

		sb.append(" ORDER BY ");
		sb.append(PortalDBEnum.VIEW_NAMES.devicesnodes_view);
		sb.append(".");
		sb.append(PortalDBEnum.DEVICES_NODES_VIEW.devices_deviceName);
		sb.append(" ASC ");
		return sb.toString();
	}

//	private String mShiftChildDevicesOfLabelToRoot(String labelId){
//		StringBuilder sb = new StringBuilder();
//		sb.append("UPDATE ");
//		sb.append(PortalDBEnum.TABLE_NAMES.devicelabelmap);
//		sb.append(" SET ");  
//		sb.append(PortalDBEnum.DEVICE_LABEL_MAP.labelId.name());
//		sb.append(" = "); 
//		sb.append(dbCon.formatString(Constant.ROOT_LABEL_ID));
//		sb.append(" WHERE ");
//		sb.append(PortalDBEnum.DEVICE_LABEL_MAP.labelId.name());
//		sb.append(" = ");
//		sb.append(dbCon.formatString(labelId));
//
//		return sb.toString();
//	}

//	private String mGetDeviceIdsOfLabel(String labelId, String userId){
//		StringBuilder sb = new StringBuilder();
//		sb.append("Select devices.deviceId FROM ");
//		sb.append(PortalDBEnum.TABLE_NAMES.devicelabelmap);
//		sb.append(" JOIN ");
//		sb.append(PortalDBEnum.TABLE_NAMES.devices);sb.append(" ON devices.deviceId = devicelabelmap.deviceId ");
//		sb.append(" WHERE ");  
//		sb.append(PortalDBEnum.DEVICE_LABEL_MAP.labelId.name());sb.append(" = "); sb.append(dbCon.formatString(labelId));
//		sb.append(" AND ");
//		sb.append(PortalDBEnum.DEVICES.userId.name());sb.append(" = "); sb.append(dbCon.formatString(userId));
//		sb.append(" AND ");
//		sb.append(PortalDBEnum.DEVICES.deviceStatus);sb.append(" != ");sb.append(Status.DELETED.ordinal());	
//
//		return sb.toString();
//	}

	private String mAddDeviceLabel(){
		StringBuilder sb = new StringBuilder();
		sb.append("INSERT INTO ");
		sb.append(PortalDBEnum.TABLE_NAMES.devicelabelmap);
		sb.append(" ( ");
		sb.append(PortalDBEnum.DEVICE_LABEL_MAP.labelId.name());
		sb.append(", ");
		sb.append(PortalDBEnum.DEVICE_LABEL_MAP.deviceId.name());		
		sb.append(" ) VALUES ( ");
		sb.append("?");
		sb.append(", ");
		sb.append("?");
		sb.append(" )");
		return sb.toString();
	}

	private String mDeleteDeviceLabel(){
		StringBuilder sb = new StringBuilder();
		sb.append("DELETE FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.devicelabelmap);
		sb.append(" WHERE ");  
		sb.append(PortalDBEnum.DEVICE_LABEL_MAP.labelId.name());
		sb.append(" = ");
		sb.append("?");
		//sb.append(dbCon.formatString(labelId));
		sb.append(" AND ");
		sb.append(PortalDBEnum.DEVICE_LABEL_MAP.deviceId.name());
		sb.append(" = ");
		sb.append("?");
//		sb.append(dbCon.formatString(deviceId));
		return sb.toString();
	}

	public String deleteDeviceLabel(){
		StringBuilder sb = new StringBuilder();
		sb.append("DELETE FROM ");
		sb.append(PortalDBEnum.TABLE_NAMES.devicelabelmap);
		sb.append(" WHERE ");  
		sb.append(PortalDBEnum.DEVICE_LABEL_MAP.deviceId.name());
		sb.append(" = ");
		sb.append("?");
//		sb.append(dbCon.formatString(deviceId));
		return sb.toString();
	}

	/**
	 * Add a device to multiple labels
	 * @param labelIds
	 * @param deviceId
	 * @return
	 * @throws SQLException
	 */
	public List<String> addDeviceToLabels() 
	{
		return mAddDeviceToLabels();
	}

	private List<String> mAddDeviceToLabels()
	{	
		List<String> queries = new ArrayList<>();

		StringBuilder deleteQuery = new StringBuilder();
		deleteQuery.append("DELETE FROM ");
		deleteQuery.append(PortalDBEnum.TABLE_NAMES.devicelabelmap);
		deleteQuery.append(" WHERE ");
		deleteQuery.append(PortalDBEnum.DEVICE_LABEL_MAP.deviceId.name());
		deleteQuery.append(" = ");
		deleteQuery.append("?");
//		deleteQuery.append(dbCon.formatString(deviceId));

		queries.add(deleteQuery.toString());

		StringBuilder sbInsertInitial = new StringBuilder();
		sbInsertInitial.append("INSERT INTO ");
		sbInsertInitial.append(PortalDBEnum.TABLE_NAMES.devicelabelmap);
		sbInsertInitial.append(" ( ");
		sbInsertInitial.append(PortalDBEnum.DEVICE_LABEL_MAP.labelId.name());
		sbInsertInitial.append(", ");
		sbInsertInitial.append(PortalDBEnum.DEVICE_LABEL_MAP.deviceId.name());		
		sbInsertInitial.append(" ) VALUES ");

//		if(labelIds.isEmpty()){
//			labelIds.add(Constant.ROOT_LABEL_ID);
//		}
		

		StringBuilder labelValues = new StringBuilder();
//		for (String labelId : labelIds)
//		{

			labelValues.append(" ( ");
			labelValues.append("?");
//			labelValues.append(dbCon.formatString(labelId));
			labelValues.append(", ");
			labelValues.append("?");
//			labelValues.append(dbCon.formatString(deviceId));
			labelValues.append(" ) ");
//			labelValues.append(", ");


//		}
		
//		if(labelValues.length() != 0)
//		{
//			String labelValuesStr = labelValues.toString().substring(0, labelValues.lastIndexOf(", "));
			queries.add(sbInsertInitial.toString() + labelValues.toString());
//		}
		
		return	queries;
	}
}
