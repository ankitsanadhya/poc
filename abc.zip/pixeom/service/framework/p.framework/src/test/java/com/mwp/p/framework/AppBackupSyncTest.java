package com.mwp.p.framework;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.mockStatic;

import java.sql.ResultSet;
import java.sql.Timestamp;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.classloader.annotations.SuppressStaticInitializationFor;
import org.powermock.modules.junit4.PowerMockRunner;

import com.mwp.common.CredProvider;
import com.mwp.common.constant.Constant;
import com.mwp.common.enums.RoleEnum;
import com.mwp.common.vo.AuthorizationsVO;
import com.mwp.common.vo.QueryVO;
import com.mwp.db.Interface.IConnection;
import com.mwp.p.dal.engine.PortalDatabaseEngine;
import com.pa.crypto.StringEncryptionDecryption;

@RunWith(PowerMockRunner.class)
@SuppressStaticInitializationFor({"com.mwp.b.common.Constants","com.mwp.p.dal.engine.PortalDatabaseEngine"})
@PrepareForTest({Constant.class, StringEncryptionDecryption.class, PortalDatabaseEngine.class})
public class AppBackupSyncTest {
	
	@Mock
	private PortalDatabaseEngine portalDatabaseEngine;
	
	@Mock 
	IConnection connection;

	@Mock
	private ResultSet resultSet;
	
	@Mock
	private CredProvider credProvider;
	
	private AppBackupSync appBackupSync;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		mockStatic(PortalDatabaseEngine.class);
		mockStatic(StringEncryptionDecryption.class);
		mockStatic(Constant.class);
		appBackupSync = spy(new AppBackupSync());

		when(PortalDatabaseEngine.getInstance()).thenReturn(portalDatabaseEngine);
		when(portalDatabaseEngine.getConnection()).thenReturn(connection);
		
		when(connection.executeQuery(any(QueryVO.class))).thenReturn(resultSet);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));
		
		when(StringEncryptionDecryption.decrypt(any(),any())).thenReturn("test");
		when(StringEncryptionDecryption.encrypt(any(),any())).thenReturn("test");
		
		when(StringEncryptionDecryption.decrypt(any())).thenReturn("test");
		when(StringEncryptionDecryption.encrypt(any())).thenReturn("test");
		
		PowerMockito.whenNew(CredProvider.class).withNoArguments().thenReturn(credProvider);
	}

	@After
	public void tearDown() {
		appBackupSync = null;
		connection = null;
		resultSet = null;
		portalDatabaseEngine = null;
	}
	
	@Test
	public void testAddSync() throws Exception {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("deviceId");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));
		
		
		AuthorizationsVO authVo = new AuthorizationsVO();
		authVo.setApplicationId("permission");
		authVo.setRole(RoleEnum.User);		
		
		appBackupSync.addSync(authVo, "clusterId");
		
		verify(portalDatabaseEngine, times(9)).getConnection();
		verify(connection, times(1)).executeUpdate(any(QueryVO.class));
		verify(connection, times(3)).executeQuery(any(QueryVO.class));
	}	
	
	@Test(expected = Exception.class)
	public void testAddSyncWhenClusterIsEmpty() throws Exception {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		when(resultSet.next()).thenReturn(false);		
	
		AuthorizationsVO authVo = new AuthorizationsVO();
		authVo.setApplicationId("permission");
		authVo.setRole(RoleEnum.User);		
		
		appBackupSync.addSync(authVo, "clusterId");		
	}	
}
