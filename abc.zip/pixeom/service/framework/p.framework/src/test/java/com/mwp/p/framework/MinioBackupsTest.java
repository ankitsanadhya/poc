package com.mwp.p.framework;

import static org.junit.Assert.*;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.mockStatic;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.Reader;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.json.simple.parser.JSONParser;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.classloader.annotations.SuppressStaticInitializationFor;
import org.powermock.modules.junit4.PowerMockRunner;

import com.mwp.common.CredProvider;
import com.mwp.common.constant.Constant;
import com.mwp.common.enums.RoleEnum;
import com.mwp.common.vo.AppBackupTaskVOPortal;
import com.mwp.common.vo.AuthorizationsVO;
import com.mwp.common.vo.MinioVO;
import com.mwp.common.vo.QueryVO;
import com.mwp.db.Interface.IConnection;
import com.mwp.p.common.ClusterCmd;
import com.mwp.p.dal.engine.DiscoveryDetailsEngine;
import com.mwp.p.dal.engine.PortalDatabaseEngine;
import com.pa.crypto.StringEncryptionDecryption;

import io.minio.MinioClient;
import io.minio.Result;
import io.minio.errors.MinioException;
import io.minio.messages.Item;

@RunWith(PowerMockRunner.class)
@SuppressStaticInitializationFor({ "com.mwp.b.common.Constants", "com.mwp.p.dal.engine.PortalDatabaseEngine" })
@PrepareForTest({ Constant.class, StringEncryptionDecryption.class, PortalDatabaseEngine.class, ClusterCmd.class, DiscoveryDetailsEngine.class })
public class MinioBackupsTest {

	@Mock
	private PortalDatabaseEngine portalDatabaseEngine;

	@Mock
	IConnection connection;

	@Mock
	private ResultSet resultSet;

	@Mock
	private CredProvider credProvider;

	@Mock
	private ClusterCmd clusterCmd;

	@Mock
	private MinioClient minioClient;

	@Mock
	private JSONParser jsonParser;

	@Mock
	private BufferedReader bufferReader;

	@Mock
	private InputStreamReader inputStreamReader;

	private MinioBackups minioBackups;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		mockStatic(PortalDatabaseEngine.class);
		mockStatic(StringEncryptionDecryption.class);
		mockStatic(Constant.class);
		mockStatic(ClusterCmd.class);
		minioBackups = spy(new MinioBackups());

		when(PortalDatabaseEngine.getInstance()).thenReturn(portalDatabaseEngine);
		when(portalDatabaseEngine.getConnection()).thenReturn(connection);

		when(connection.executeQuery(any(QueryVO.class))).thenReturn(resultSet);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		when(StringEncryptionDecryption.decrypt(any(), any())).thenReturn("test");
		when(StringEncryptionDecryption.encrypt(any(), any())).thenReturn("test");

		when(StringEncryptionDecryption.decrypt(any())).thenReturn("test");
		when(StringEncryptionDecryption.encrypt(any())).thenReturn("test");

		when(ClusterCmd.getInstance()).thenReturn(clusterCmd);

		PowerMockito.whenNew(CredProvider.class).withNoArguments().thenReturn(credProvider);
	}

	@After
	public void tearDown() {
		minioBackups = null;
		connection = null;
		resultSet = null;
		portalDatabaseEngine = null;
	}

	@Test
	public void testCreateMinioUserHappyPath() throws Exception {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		when(clusterCmd.executeCommand(any())).thenReturn("successfully");
		MinioVO minioVO = new MinioVO();
		when(Constant.getMinio()).thenReturn(minioVO);
		minioBackups.CreateMinioUser("userId", "userPassword");
	}
	
	@Test
	public void testCreateMinioBucket() throws Exception {
		PowerMockito.doReturn(minioClient).when(minioBackups).GetMinioClient();
		when(minioClient.bucketExists(any())).thenReturn(true);
		boolean isBucketExist = minioBackups.CreateMinioBucket("clusterId");
		assertFalse(isBucketExist);
	}
	
	@Test
	public void testCreateMinioBucketWhenBucketNotExist() throws Exception {
		PowerMockito.doReturn(minioClient).when(minioBackups).GetMinioClient();
		when(minioClient.bucketExists(any())).thenReturn(false);
		PowerMockito.doNothing().when(minioClient).makeBucket(any());
		boolean isBucketExist = minioBackups.CreateMinioBucket("clusterId");
		assertTrue(isBucketExist);
	}

	@Test(expected = MinioException.class)
	public void testCreateMinioUser() throws Exception {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		when(clusterCmd.executeCommand(any())).thenReturn("Create alias failed");
		MinioVO minioVO = new MinioVO();
		when(Constant.getMinio()).thenReturn(minioVO);
		minioBackups.CreateMinioUser("userId", "userPassword");
	}

	@Test(expected = MinioException.class)
	public void testCreateMinioUserWhenAddAliasSuccessfull() throws Exception {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		when(clusterCmd.executeCommand(any())).thenReturn("successfully").thenReturn("Create alias failed");
		MinioVO minioVO = new MinioVO();
		when(Constant.getMinio()).thenReturn(minioVO);
		minioBackups.CreateMinioUser("userId", "userPassword");
	}

	@Test(expected = Exception.class)
	public void testListAllBackupsWhenPlatformNotFound() throws Exception {
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("clusterId");

		AuthorizationsVO authVO = new AuthorizationsVO();
		authVO.setApplicationId("appId");
		authVO.setRole(RoleEnum.User);
		authVO.setUserId("userId");

		PowerMockito.doReturn(minioClient).when(minioBackups).GetMinioClient();
		when(minioClient.bucketExists(any())).thenReturn(true);
		List<Result<Item>> list = new ArrayList<>();
		Item item = new Item();
		item.set("test", "test");
		Result<Item> result = new Result<Item>(item, null);
		list.add(result);

		String backupString = "{'metadata':{'name':'test-123456','namespace':'velero','labels':{'appVersion':'1.0',"
				+ "'appVersionId':'12345678','platformName':'x86_64'}},'status':{'phase':'Completed'}}";

		PowerMockito.doReturn(jsonParser).when(minioBackups).buildJsonParser();
		PowerMockito.doReturn(bufferReader).when(minioBackups).buildBufferReader(any());
		PowerMockito.doReturn(inputStreamReader).when(minioBackups).buildInputStreamReader(any());
		when(jsonParser.parse(any(Reader.class))).thenReturn(backupString);
		Iterable<Result<Item>> objectList = new ArrayList<>(list);
		when(minioClient.listObjects(any(String.class), any(String.class), any(Boolean.class))).thenReturn(objectList);
		minioBackups.ListAllBackups(authVO);
	}

	@Test(expected = Exception.class)
	public void testListAllBackupsWhenAppNameIsEmpty() throws Exception {
		when(resultSet.next()).thenReturn(true).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false)
				.thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("clusterId");

		AuthorizationsVO authVO = new AuthorizationsVO();
		authVO.setApplicationId("appId");
		authVO.setRole(RoleEnum.User);
		authVO.setUserId("userId");

		PowerMockito.doReturn(minioClient).when(minioBackups).GetMinioClient();
		when(minioClient.bucketExists(any())).thenReturn(true);
		List<Result<Item>> list = new ArrayList<>();
		Item item = new Item();
		item.set("test", "test");
		Result<Item> result = new Result<Item>(item, null);
		list.add(result);

		String backupString = "{'metadata':{'name':'test-123456','namespace':'velero','labels':{'appVersion':'1.0',"
				+ "'appVersionId':'12345678','platformName':'x86_64'}},'status':{'phase':'Completed'}}";

		PowerMockito.doReturn(jsonParser).when(minioBackups).buildJsonParser();
		PowerMockito.doReturn(bufferReader).when(minioBackups).buildBufferReader(any());
		PowerMockito.doReturn(inputStreamReader).when(minioBackups).buildInputStreamReader(any());
		when(jsonParser.parse(any(Reader.class))).thenReturn(backupString);
		Iterable<Result<Item>> objectList = new ArrayList<>(list);
		when(minioClient.listObjects(any(String.class), any(String.class), any(Boolean.class))).thenReturn(objectList);
		minioBackups.ListAllBackups(authVO);
	}

	@Test(expected = Exception.class)
	public void testListAllBackupsWhenVersionNotFound() throws Exception {
		when(resultSet.next()).thenReturn(true).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false)
				.thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("clusterId");

		AuthorizationsVO authVO = new AuthorizationsVO();
		authVO.setApplicationId("appId");
		authVO.setRole(RoleEnum.User);
		authVO.setUserId("userId");

		PowerMockito.doReturn(minioClient).when(minioBackups).GetMinioClient();
		when(minioClient.bucketExists(any())).thenReturn(true);
		List<Result<Item>> list = new ArrayList<>();
		Item item = new Item();
		item.set("test", "test");
		Result<Item> result = new Result<Item>(item, null);
		list.add(result);

		String backupString = "{'metadata':{'name':'test-123456','namespace':'velero','labels':{'appVersion':'1.0',"
				+ "'appVersionId':'12345678','platformName':'x86_64'}},'status':{'phase':'Completed'}}";

		PowerMockito.doReturn(jsonParser).when(minioBackups).buildJsonParser();
		PowerMockito.doReturn(bufferReader).when(minioBackups).buildBufferReader(any());
		PowerMockito.doReturn(inputStreamReader).when(minioBackups).buildInputStreamReader(any());
		when(jsonParser.parse(any(Reader.class))).thenReturn(backupString);
		Iterable<Result<Item>> objectList = new ArrayList<>(list);
		when(minioClient.listObjects(any(String.class), any(String.class), any(Boolean.class))).thenReturn(objectList);
		minioBackups.ListAllBackups(authVO);
	}
	
	@Test
	public void testListAllBackups() throws Exception {
		when(resultSet.next()).thenReturn(true).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false)
				.thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(true).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("1.0");

		AuthorizationsVO authVO = new AuthorizationsVO();
		authVO.setApplicationId("appId");
		authVO.setRole(RoleEnum.User);
		authVO.setUserId("userId");

		PowerMockito.doReturn(minioClient).when(minioBackups).GetMinioClient();
		when(minioClient.bucketExists(any())).thenReturn(true);
		List<Result<Item>> list = new ArrayList<>();
		Item item = new Item();
		item.set("test", "test");
		Result<Item> result = new Result<Item>(item, null);
		list.add(result);

		String backupString = "{'metadata':{'name':'test-123456','namespace':'velero','labels':{'appVersion':'1.0',"
				+ "'appVersionId':'12345678','platformName':'x86_64'}},'status':{'phase':'Completed'}}";

		PowerMockito.doReturn(jsonParser).when(minioBackups).buildJsonParser();
		PowerMockito.doReturn(bufferReader).when(minioBackups).buildBufferReader(any());
		PowerMockito.doReturn(inputStreamReader).when(minioBackups).buildInputStreamReader(any());
		when(jsonParser.parse(any(Reader.class))).thenReturn(backupString);
		Iterable<Result<Item>> objectList = new ArrayList<>(list);
		when(minioClient.listObjects(any(String.class), any(String.class), any(Boolean.class))).thenReturn(objectList);
		List<AppBackupTaskVOPortal> appBackupTaskVOPortals = minioBackups.ListAllBackups(authVO);
		assertNotNull(appBackupTaskVOPortals);
		assertEquals(1,appBackupTaskVOPortals.size());
	}
	
	@Test
	public void testListAllBackupsOfApplicationForCluster() throws Exception {
		when(resultSet.next()).thenReturn(true).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false)
				.thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(true).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("1.0");

		AuthorizationsVO authVO = new AuthorizationsVO();
		authVO.setApplicationId("appId");
		authVO.setRole(RoleEnum.User);
		authVO.setUserId("userId");

		PowerMockito.doReturn(minioClient).when(minioBackups).GetMinioClient();
		when(minioClient.bucketExists(any())).thenReturn(true);
		List<Result<Item>> list = new ArrayList<>();
		Item item = new Item();
		item.set("test", "test");
		Result<Item> result = new Result<Item>(item, null);
		list.add(result);

		String backupString = "{'metadata':{'name':'test-123456','namespace':'velero','labels':{'appVersion':'1.0',"
				+ "'appVersionId':'12345678','platformName':'x86_64'}},'status':{'phase':'Completed'}}";

		PowerMockito.doReturn(jsonParser).when(minioBackups).buildJsonParser();
		PowerMockito.doReturn(bufferReader).when(minioBackups).buildBufferReader(any());
		PowerMockito.doReturn(inputStreamReader).when(minioBackups).buildInputStreamReader(any());
		when(jsonParser.parse(any(Reader.class))).thenReturn(backupString);
		Iterable<Result<Item>> objectList = new ArrayList<>(list);
		when(minioClient.listObjects(any(String.class), any(String.class), any(Boolean.class))).thenReturn(objectList);
		List<AppBackupTaskVOPortal> appBackupTaskVOPortals = minioBackups.ListAllBackupsOfApplicationForCluster(authVO,"clusterId","userId");
		assertNotNull(appBackupTaskVOPortals);
		assertEquals(1,appBackupTaskVOPortals.size());
	}
	
	@Test
	public void testListAllBackupsOfACluster() throws Exception {
		when(resultSet.next()).thenReturn(true).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false)
				.thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(true).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("1.0");

		AuthorizationsVO authVO = new AuthorizationsVO();
		authVO.setApplicationId("appId");
		authVO.setRole(RoleEnum.User);
		authVO.setUserId("userId");

		PowerMockito.doReturn(minioClient).when(minioBackups).GetMinioClient();
		when(minioClient.bucketExists(any())).thenReturn(true);
		List<Result<Item>> list = new ArrayList<>();
		Item item = new Item();
		item.set("test", "test");
		Result<Item> result = new Result<Item>(item, null);
		list.add(result);

		String backupString = "{'metadata':{'name':'test-123456','namespace':'velero','labels':{'appVersion':'1.0',"
				+ "'appVersionId':'12345678','platformName':'x86_64'}},'status':{'phase':'Completed'}}";

		PowerMockito.doReturn(jsonParser).when(minioBackups).buildJsonParser();
		PowerMockito.doReturn(bufferReader).when(minioBackups).buildBufferReader(any());
		PowerMockito.doReturn(inputStreamReader).when(minioBackups).buildInputStreamReader(any());
		when(jsonParser.parse(any(Reader.class))).thenReturn(backupString);
		Iterable<Result<Item>> objectList = new ArrayList<>(list);
		when(minioClient.listObjects(any(String.class), any(String.class), any(Boolean.class))).thenReturn(objectList);
		List<AppBackupTaskVOPortal> appBackupTaskVOPortals = minioBackups.ListAllBackupsOfACluster(authVO,"clusterId");
		assertNotNull(appBackupTaskVOPortals);
		assertEquals(1,appBackupTaskVOPortals.size());
	}
	
	@Test
	public void testListAllBackupsOfAnApp() throws Exception {
		when(resultSet.next()).thenReturn(true).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false)
				.thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(true).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("1.0");

		AuthorizationsVO authVO = new AuthorizationsVO();
		authVO.setApplicationId("appId");
		authVO.setRole(RoleEnum.User);
		authVO.setUserId("userId");

		PowerMockito.doReturn(minioClient).when(minioBackups).GetMinioClient();
		when(minioClient.bucketExists(any())).thenReturn(true);
		List<Result<Item>> list = new ArrayList<>();
		Item item = new Item();
		item.set("test", "test");
		Result<Item> result = new Result<Item>(item, null);
		list.add(result);

		String backupString = "{'metadata':{'name':'test-123456','namespace':'velero','labels':{'appVersion':'1.0',"
				+ "'appVersionId':'12345678','platformName':'x86_64'}},'status':{'phase':'Completed'}}";

		PowerMockito.doReturn(jsonParser).when(minioBackups).buildJsonParser();
		PowerMockito.doReturn(bufferReader).when(minioBackups).buildBufferReader(any());
		PowerMockito.doReturn(inputStreamReader).when(minioBackups).buildInputStreamReader(any());
		when(jsonParser.parse(any(Reader.class))).thenReturn(backupString);
		Iterable<Result<Item>> objectList = new ArrayList<>(list);
		when(minioClient.listObjects(any(String.class), any(String.class), any(Boolean.class))).thenReturn(objectList);
		List<AppBackupTaskVOPortal> appBackupTaskVOPortals = minioBackups.ListAllBackupsOfAnApp(authVO,"appId");
		assertNotNull(appBackupTaskVOPortals);
		assertEquals(1,appBackupTaskVOPortals.size());
	}
	
	@Test
	public void testListAllBackupsWhenPhaseIsInProgress() throws Exception {
		when(resultSet.next()).thenReturn(true).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false)
				.thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(true).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("1.0");

		AuthorizationsVO authVO = new AuthorizationsVO();
		authVO.setApplicationId("appId");
		authVO.setRole(RoleEnum.User);
		authVO.setUserId("userId");

		PowerMockito.doReturn(minioClient).when(minioBackups).GetMinioClient();
		when(minioClient.bucketExists(any())).thenReturn(true);
		List<Result<Item>> list = new ArrayList<>();
		Item item = new Item();
		item.set("test", "test");
		Result<Item> result = new Result<Item>(item, null);
		list.add(result);

		String backupString = "{'metadata':{'name':'test-123456','namespace':'velero','labels':{'appVersion':'1.0',"
				+ "'appVersionId':'12345678','platformName':'x86_64'}},'status':{'phase':'IN PROGRESS'}}";

		PowerMockito.doReturn(jsonParser).when(minioBackups).buildJsonParser();
		PowerMockito.doReturn(bufferReader).when(minioBackups).buildBufferReader(any());
		PowerMockito.doReturn(inputStreamReader).when(minioBackups).buildInputStreamReader(any());
		when(jsonParser.parse(any(Reader.class))).thenReturn(backupString);
		Iterable<Result<Item>> objectList = new ArrayList<>(list);
		when(minioClient.listObjects(any(String.class), any(String.class), any(Boolean.class))).thenReturn(objectList);
		List<AppBackupTaskVOPortal> appBackupTaskVOPortals = minioBackups.ListAllBackups(authVO);
		assertEquals(0, appBackupTaskVOPortals.size());
	}
	
	@Test
	public void testListAllBackupsArkObjectIsNull() throws Exception {
		when(resultSet.next()).thenReturn(true).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false)
				.thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(true).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("1.0");

		AuthorizationsVO authVO = new AuthorizationsVO();
		authVO.setApplicationId("appId");
		authVO.setRole(RoleEnum.User);
		authVO.setUserId("userId");

		PowerMockito.doReturn(minioClient).when(minioBackups).GetMinioClient();
		when(minioClient.bucketExists(any())).thenReturn(true);
		List<Result<Item>> list = new ArrayList<>();
		Item item = new Item();
		item.set("test", "test");
		Result<Item> result = new Result<Item>(item, null);
		list.add(result);

		PowerMockito.doReturn(jsonParser).when(minioBackups).buildJsonParser();
		PowerMockito.doReturn(bufferReader).when(minioBackups).buildBufferReader(any());
		PowerMockito.doReturn(inputStreamReader).when(minioBackups).buildInputStreamReader(any());
		when(jsonParser.parse(any(Reader.class))).thenReturn("");
		Iterable<Result<Item>> objectList = new ArrayList<>(list);
		when(minioClient.listObjects(any(String.class), any(String.class), any(Boolean.class))).thenReturn(objectList);
		List<AppBackupTaskVOPortal> appBackupTaskVOPortals = minioBackups.ListAllBackups(authVO);
		assertEquals(0, appBackupTaskVOPortals.size());
	}

}
