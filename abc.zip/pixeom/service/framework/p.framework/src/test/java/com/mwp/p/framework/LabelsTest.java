package com.mwp.p.framework;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.mockStatic;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.BDDMockito;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.classloader.annotations.SuppressStaticInitializationFor;
import org.powermock.modules.junit4.PowerMockRunner;

import com.mwp.common.CredProvider;
import com.mwp.common.constant.Constant;
import com.mwp.common.vo.LabelVO;
import com.mwp.common.vo.QueryVO;
import com.mwp.db.Interface.IConnection;
import com.mwp.p.dal.engine.PortalDatabaseEngine;
import com.pa.crypto.StringEncryptionDecryption;

@RunWith(PowerMockRunner.class)
@SuppressStaticInitializationFor({ "com.mwp.b.common.Constants", "com.mwp.p.dal.engine.PortalDatabaseEngine" })
@PrepareForTest({ Constant.class, StringEncryptionDecryption.class, PortalDatabaseEngine.class })
public class LabelsTest {

	@Mock
	private PortalDatabaseEngine portalDatabaseEngine;

	@Mock
	IConnection connection;

	@Mock
	private ResultSet resultSet;

	@Mock
	private CredProvider credProvider;

	private Labels labels;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		mockStatic(PortalDatabaseEngine.class);
		mockStatic(StringEncryptionDecryption.class);
		mockStatic(Constant.class);
		labels = spy(new Labels());

		when(PortalDatabaseEngine.getInstance()).thenReturn(portalDatabaseEngine);
		when(portalDatabaseEngine.getConnection()).thenReturn(connection);

		when(connection.executeQuery(any(QueryVO.class))).thenReturn(resultSet);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		BDDMockito.given(StringEncryptionDecryption.decrypt(any(), any())).willReturn("test");
		BDDMockito.given(StringEncryptionDecryption.encrypt(any(), any())).willReturn("test");

		BDDMockito.given(StringEncryptionDecryption.decrypt(any())).willReturn("test");
		BDDMockito.given(StringEncryptionDecryption.encrypt(any())).willReturn("test");

		BDDMockito.given(StringEncryptionDecryption.decrypt(any())).willReturn("test");
		PowerMockito.whenNew(CredProvider.class).withNoArguments().thenReturn(credProvider);
	}

	@After
	public void tearDown() {
		labels = null;
	}

	@Test
	public void testListLabels() throws SQLException {
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("0").thenReturn("labelName").thenReturn("-1")
				.thenReturn("tenantId");
		List<LabelVO> labelVos =  labels.listLabels("tenantId");
		assertNotNull(labelVos);
		assertEquals(1, labelVos.size());
		assertEquals("labelName", labelVos.get(0).getLabelName());
		verify(portalDatabaseEngine, times(3)).getConnection();
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(2)).next();
		verify(resultSet, times(4)).getString(any(String.class));
	}
	
	@Test
	public void testListLabelsWithEmptyList() throws SQLException {
		when(resultSet.next()).thenReturn(false).thenReturn(true);
		when(resultSet.getString(any(String.class))).thenReturn("0").thenReturn("labelName").thenReturn("-1")
				.thenReturn("tenantId");
		labels.listLabels("tenantId");
		verify(portalDatabaseEngine, times(3)).getConnection();
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(1)).next();
	}

	@Test
	public void testAddLabel() throws SQLException {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		LabelVO labelVO = new LabelVO();
		labels.addLabel(labelVO);
		verify(portalDatabaseEngine, times(3)).getConnection();
		verify(connection, times(1)).executeUpdate(any(QueryVO.class));
	}

	@Test
	public void testEditLabel() throws SQLException {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		LabelVO labelVO = new LabelVO();
		labels.editLabel(labelVO);
		verify(portalDatabaseEngine, times(3)).getConnection();
		verify(connection, times(1)).executeUpdate(any(QueryVO.class));
	}

	@Test
	public void testDeleteLabel() throws SQLException {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		labels.deleteLabel("labelId", "tenantId");
		verify(portalDatabaseEngine, times(7)).getConnection();
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(1)).next();
	}

	@Test
	public void testUpdateDeviceLabel() throws SQLException {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("0").thenReturn("labelName").thenReturn("-1")
				.thenReturn("tenantId");
		labels.updateDeviceLabel("labelId", "tenantId");
		verify(portalDatabaseEngine, times(5)).getConnection();
		verify(connection, times(1)).executeUpdate(any(QueryVO.class));
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(2)).next();
		verify(resultSet, times(4)).getInt(any(String.class));
		verify(resultSet, times(19)).getString(any(String.class));
	}

	@Test(expected = Exception.class)
	public void testAddDeviceLabelWhenDeviceAlreadyExist() throws Exception {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("0").thenReturn("labelName").thenReturn("-1")
				.thenReturn("tenantId");
		// String labelId, List<String> deviceIds, String action
		List<String> deviceIds = new ArrayList<>();
		deviceIds.add("deviceId");
		labels.addDeviceLabel("labelId", deviceIds, "move");
		verify(portalDatabaseEngine, times(19)).getConnection();
		verify(connection, times(2)).executeUpdate(any(QueryVO.class));
		verify(connection, times(5)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(9)).next();
		verify(resultSet, times(11)).getInt(any(String.class));
		verify(resultSet, times(63)).getString(any(String.class));
	}

	@Test
	public void testAddDeviceLabel() throws Exception {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		when(resultSet.next()).thenReturn(false).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("0").thenReturn("labelName").thenReturn("-1")
				.thenReturn("tenantId");
		when(connection.executeUpdatesInTransaction(any())).thenReturn(true);
		List<String> deviceIds = new ArrayList<>();
		deviceIds.add("deviceId");
		labels.addDeviceLabel("labelId", deviceIds, "move");
		verify(portalDatabaseEngine, times(7)).getConnection();
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(1)).next();
	}
	
	@Test
	public void testAddDeviceLabelActionIsNotMove() throws Exception {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		when(resultSet.next()).thenReturn(false).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("0").thenReturn("labelName").thenReturn("-1")
				.thenReturn("tenantId");
		when(connection.executeUpdatesInTransaction(any())).thenReturn(true);
		List<String> deviceIds = new ArrayList<>();
		deviceIds.add("deviceId");
		labels.addDeviceLabel("labelId", deviceIds, "dmove");
		verify(portalDatabaseEngine, times(6)).getConnection();
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(1)).next();
	}

	@Test
	public void testDeleteDeviceFromLabel() throws SQLException {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		labels.deleteDeviceFromLabel("deviceId", "labelId");
		verify(portalDatabaseEngine, times(6)).getConnection();
		verify(connection, times(1)).executeUpdate(any(QueryVO.class));
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(1)).next();
	}

	@Test
	public void testDeleteDeviceLabel() throws SQLException {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		labels.deleteDeviceLabel("deviceId", "labelId");
		verify(portalDatabaseEngine, times(3)).getConnection();
		verify(connection, times(1)).executeUpdate(any(QueryVO.class));
	}
	
	@Test
	public void testGetDevicesofLabel() throws SQLException {
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("deviceId").thenReturn("deviceId")
			.thenReturn("deviceId").thenReturn("deviceId").thenReturn("deviceId").thenReturn("deviceId")
			.thenReturn("deviceId").thenReturn("deviceId").thenReturn("deviceId").thenReturn("labelName").thenReturn("-1")
				.thenReturn("tenantId");
		labels.getDevicesofLabel("labelId", "tenantId");
		verify(portalDatabaseEngine, times(3)).getConnection();
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(2)).next();
		verify(resultSet, times(4)).getInt(any(String.class));
		verify(resultSet, times(21)).getString(any(String.class));
	}
	
}
