package com.mwp.p.framework;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.mockStatic;

import java.io.File;
import java.io.FileOutputStream;
import java.sql.ResultSet;
import java.sql.Timestamp;

import org.apache.commons.io.FileUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.BDDMockito;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.classloader.annotations.SuppressStaticInitializationFor;
import org.powermock.modules.junit4.PowerMockRunner;

import com.mwp.common.CredProvider;
import com.mwp.common.constant.Constant;
import com.mwp.common.vo.QueryVO;
import com.mwp.db.Interface.IConnection;
import com.mwp.p.common.Constants;
import com.mwp.p.dal.engine.PortalDatabaseEngine;
import com.pa.crypto.FileEncryptionDecryption;
import com.pa.crypto.StringEncryptionDecryption;

@RunWith(PowerMockRunner.class)
@SuppressStaticInitializationFor({ "com.mwp.p.common.Constants", "com.mwp.p.dal.engine.PortalDatabaseEngine" })
@PrepareForTest({ Constant.class, StringEncryptionDecryption.class, PortalDatabaseEngine.class, FileUtils.class,
		FileEncryptionDecryption.class, Constants.class })
public class PlatformTest {

	@Mock
	private PortalDatabaseEngine portalDatabaseEngine;

	@Mock
	IConnection connection;

	@Mock
	private ResultSet resultSet;

	@Mock
	private CredProvider credProvider;

	@Mock
	private File file;

	@Mock
	private FileOutputStream fileOutputStream;

	private Platform platform;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		mockStatic(PortalDatabaseEngine.class);
		mockStatic(StringEncryptionDecryption.class);
		mockStatic(Constant.class);
		mockStatic(Constants.class);
		mockStatic(FileUtils.class);
		mockStatic(FileEncryptionDecryption.class);
		platform = spy(new Platform());

		when(PortalDatabaseEngine.getInstance()).thenReturn(portalDatabaseEngine);
		when(portalDatabaseEngine.getConnection()).thenReturn(connection);

		when(connection.executeQuery(any(QueryVO.class))).thenReturn(resultSet);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		BDDMockito.given(StringEncryptionDecryption.decrypt(any(), any())).willReturn("test");
		BDDMockito.given(StringEncryptionDecryption.encrypt(any(), any())).willReturn("test");

		PowerMockito.whenNew(CredProvider.class).withNoArguments().thenReturn(credProvider);
	}

	@After
	public void tearDown() {
		platform = null;
	}

	@Test
	public void testGetAllPlatForm() throws Exception {
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("platformId").thenReturn("platformName")
				.thenReturn("platformActualName");

		platform.getAllPlatForm();

		verify(portalDatabaseEngine, times(3)).getConnection();
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(2)).next();
		verify(resultSet, times(1)).getTimestamp(any(String.class));
		verify(resultSet, times(3)).getString(any(String.class));
	}

	@Test
	public void testGetPlatForm() throws Exception {
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("platformName");

		platform.getPlatForm("platformName");
	}
	
	@Test
	public void testGetDeviceApplicationPlatForm() throws Exception {
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("platformId").thenReturn("platformName")
				.thenReturn("platformActualName");

		platform.getDeviceApplicationPlatForm("appId", "deviceId");
	}

}
