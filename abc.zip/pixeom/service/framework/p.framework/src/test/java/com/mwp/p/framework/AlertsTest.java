package com.mwp.p.framework;

import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.mockStatic;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.classloader.annotations.SuppressStaticInitializationFor;
import org.powermock.modules.junit4.PowerMockRunner;

import com.mwp.common.CredProvider;
import com.mwp.common.constant.Constant;
import com.mwp.common.enums.FilterType;
import com.mwp.common.enums.MessageType;
import com.mwp.common.enums.NotificationType;
import com.mwp.common.vo.AlertsVO;
import com.mwp.common.vo.FilterObject;
import com.mwp.common.vo.QueryVO;
import com.mwp.db.Interface.IConnection;
import com.mwp.p.dal.engine.PortalDatabaseEngine;
import com.pa.crypto.StringEncryptionDecryption;

@RunWith(PowerMockRunner.class)
@SuppressStaticInitializationFor({"com.mwp.b.common.Constants","com.mwp.p.dal.engine.PortalDatabaseEngine"})
@PrepareForTest({Constant.class, StringEncryptionDecryption.class, PortalDatabaseEngine.class})
public class AlertsTest {
	
	@Mock
	private PortalDatabaseEngine portalDatabaseEngine;
	
	@Mock 
	IConnection connection;

	@Mock
	private ResultSet resultSet;
	
	@Mock
	private CredProvider credProvider;
	
	private Alerts alerts;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		mockStatic(PortalDatabaseEngine.class);
		mockStatic(StringEncryptionDecryption.class);
		mockStatic(Constant.class);
		alerts = spy(new Alerts());

		when(PortalDatabaseEngine.getInstance()).thenReturn(portalDatabaseEngine);
		when(portalDatabaseEngine.getConnection()).thenReturn(connection);
		
		when(connection.executeQuery(any(QueryVO.class))).thenReturn(resultSet);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));
		
		when(StringEncryptionDecryption.decrypt(any(),any())).thenReturn("test");
		when(StringEncryptionDecryption.encrypt(any(),any())).thenReturn("test");
		
		when(StringEncryptionDecryption.decrypt(any())).thenReturn("test");
		when(StringEncryptionDecryption.encrypt(any())).thenReturn("test");
		
		PowerMockito.whenNew(CredProvider.class).withNoArguments().thenReturn(credProvider);
	}

	@After
	public void tearDown() {
		alerts = null;
		connection = null;
		resultSet = null;
		portalDatabaseEngine = null;
	}
	
	@Test
	public void testInsert() throws SQLException {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		alerts.add(NotificationType.Info,"{\"data\": \"test\"}",MessageType.Memory,"command message");
		
		verify(portalDatabaseEngine, times(2)).getConnection();
		verify(connection, times(1)).executeUpdate(any(QueryVO.class));		
	}
	
	@Test
	public void testListFilterAlerts() throws SQLException{
		Map<String, Object> expectedMap = new HashMap<>();
		expectedMap.put("totalAlertCount", 1);
		expectedMap.put("pageNo", 1);
		expectedMap.put("totalPages", 1);
		expectedMap.put("pageSize", 3);
		ArrayList<AlertsVO> listAlerts = new ArrayList<>();
		expectedMap.put("data", listAlerts);
		
		List<FilterObject> filterObjectList = new ArrayList<>();
		FilterObject filterObject = new FilterObject();
		filterObject.setFilterType(FilterType.CATEGORY);
		filterObjectList.add(filterObject);
		
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("deviceId");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));
		
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		when(Constant.toLogActivity()).thenReturn(true);
		Map<String, Object> actualFilterAlertsList = alerts.listFilterAlerts(filterObjectList,1L,3);

		assertTrue(expectedMap.get("data").equals(actualFilterAlertsList.get("data")));
		assertTrue(expectedMap.get("totalAlertCount").equals(actualFilterAlertsList.get("totalAlertCount")));
		
		verify(portalDatabaseEngine, times(4)).getConnection();
		verify(connection, times(2)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(3)).next();
		verify(resultSet, times(1)).getInt(any(String.class));		
	}
}
