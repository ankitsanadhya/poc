package com.mwp.p.framework;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.mockStatic;

import java.io.File;
import java.io.FileReader;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.json.simple.parser.JSONParser;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.BDDMockito;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.classloader.annotations.SuppressStaticInitializationFor;
import org.powermock.modules.junit4.PowerMockRunner;

import com.mwp.common.CredProvider;
import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.common.constant.Constant;
import com.mwp.common.enums.Status;
import com.mwp.common.enums.StatusEnum.VERSION_STATUS;
import com.mwp.common.vo.ApplicationDetailsVO;
import com.mwp.common.vo.ApplicationPlatformVO;
import com.mwp.common.vo.AuthorizationsVO;
import com.mwp.common.vo.QueryVO;
import com.mwp.db.Interface.IConnection;
import com.mwp.p.dal.engine.ApplicationsEngine;
import com.mwp.p.dal.engine.DeveloperApplicationsEngine;
import com.mwp.p.dal.engine.PortalDatabaseEngine;
import com.pa.crypto.FileEncryptionDecryption;
import com.pa.crypto.StringEncryptionDecryption;

@RunWith(PowerMockRunner.class)
@SuppressStaticInitializationFor({"com.mwp.p.common.Constants","com.mwp.p.dal.engine.PortalDatabaseEngine"})
@PrepareForTest({Constant.class, StringEncryptionDecryption.class, PortalDatabaseEngine.class, 
	ApplicationsEngine.class,FileEncryptionDecryption.class, SqlQueryBuilder.class, DeveloperApplicationsEngine.class})
public class DeveloperApplicationsTest {

	@Mock
	private PortalDatabaseEngine portalDatabaseEngine;
	
	@Mock 
	IConnection connection;

	@Mock
	private ResultSet resultSet;
	
	@Mock
	private CredProvider credProvider;	

	@Mock
	private File file;
	
	@Mock
	private FileReader fileReader;
	
	@Mock
	private JSONParser jsonParser;
	
	private DeveloperApplications developerApplications; 
	
	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		mockStatic(PortalDatabaseEngine.class);
		mockStatic(StringEncryptionDecryption.class);	
		mockStatic(Constant.class);
		mockStatic(FileEncryptionDecryption.class);
		developerApplications = spy(new DeveloperApplications());

		when(PortalDatabaseEngine.getInstance()).thenReturn(portalDatabaseEngine);
		when(portalDatabaseEngine.getConnection()).thenReturn(connection);
		
		when(connection.executeQuery(any(QueryVO.class))).thenReturn(resultSet);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));
		
		BDDMockito.given(StringEncryptionDecryption.decrypt(any(),any())).willReturn("test");
		BDDMockito.given(StringEncryptionDecryption.encrypt(any(),any())).willReturn("test");
		
		BDDMockito.given(StringEncryptionDecryption.decrypt(any())).willReturn("test");
		BDDMockito.given(StringEncryptionDecryption.encrypt(any())).willReturn("test");
		
		PowerMockito.whenNew(CredProvider.class).withNoArguments().thenReturn(credProvider);
	}

	@After
	public void tearDown() {
		developerApplications = null;
	}
	
	@Test
	public void testListInvitedApps() throws SQLException{		
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("deviceId");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));
		
		List<String> groupIds = new ArrayList<>();
		groupIds.add("groupId");
		developerApplications.listInvitedApps(groupIds);
		
		verify(portalDatabaseEngine, times(2)).getConnection();
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(2)).next();
		verify(resultSet, times(1)).getInt(any(String.class));
	}
	
	@Test
	public void testCreateApplication() throws Exception{		
		when(connection.executeUpdatesInTransaction(any())).thenReturn(true);		
		
		ApplicationDetailsVO applicationDetailsVO = new ApplicationDetailsVO();
		applicationDetailsVO.setApplicationId("appId");
		applicationDetailsVO.setAppStatus(Status.ACTIVE);
		developerApplications.createApplication(applicationDetailsVO);
		
		verify(portalDatabaseEngine, times(2)).getConnection();		
		verify(connection, times(1)).executeUpdatesInTransaction(any());
	}
	
	@Test(expected = Exception.class)
	public void testCreateApplicationWhenAppDetailVoIsNull() throws Exception{				
		ApplicationDetailsVO applicationDetailsVO = new ApplicationDetailsVO();
		applicationDetailsVO.setUsePxAuth(true);		
		developerApplications.createApplication(applicationDetailsVO);
	}
	
	@Test
	public void testUpdateApplication() throws SQLException{		
		when(connection.executeUpdatesInTransaction(any())).thenReturn(true);	
				
		ApplicationDetailsVO applicationDetailsVO = new ApplicationDetailsVO();
		applicationDetailsVO.setApplicationId("appId");
		applicationDetailsVO.setAppStatus(Status.ACTIVE);
		developerApplications.updateApplication(applicationDetailsVO);
		
		verify(portalDatabaseEngine, times(3)).getConnection();		
		verify(connection, times(1)).executeUpdatesInTransaction(any());
	}
	
	@Test
	public void testUpdateApplicationLogo() throws SQLException{		
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);				
		
		developerApplications.updateApplicationLogo("appId", "logoPath");
		
		verify(portalDatabaseEngine, times(2)).getConnection();		
		verify(connection, times(1)).executeUpdate(any(QueryVO.class));
	}
	
	@Test
	public void testDeleteApplication() throws SQLException{		
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		
		developerApplications.deleteApplication("appId", "userId");
		
		verify(portalDatabaseEngine, times(2)).getConnection();		
		verify(connection, times(1)).executeUpdate(any(QueryVO.class));
	}
	
	@Test
	public void testGetVersionDetails() throws SQLException{		
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("appId");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));		
		
		developerApplications.getVersionDetails("appId", "versionId");
		verify(portalDatabaseEngine, times(2)).getConnection();
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(2)).next();
		verify(resultSet, times(2)).getInt(any(String.class));
	}
	
	@Test
	public void testListApplicationOfUser() throws SQLException{				
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("app");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));		
		
		developerApplications.listApplicationOfUser("userId");
		
		verify(portalDatabaseEngine, times(2)).getConnection();
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(2)).next();
		verify(resultSet, times(13)).getString(any(String.class));
	}
	
	@Test
	public void testGetDevAppDetails() throws SQLException{				
		when(resultSet.next()).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("userId");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));
				
		AuthorizationsVO authVo = new AuthorizationsVO();
		authVo.setApplicationId("appId");
		authVo.setUserId("userId");

		List<VERSION_STATUS> filterVersionStstus = new ArrayList<>();
		developerApplications.getDevAppDetails("appId", authVo, filterVersionStstus);
		
		verify(portalDatabaseEngine, times(4)).getConnection();
		verify(connection, times(2)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(4)).next();
		verify(resultSet, times(35)).getString(any(String.class));
	}
	
	@Test
	public void testAddApplicationImage() throws SQLException{		
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		developerApplications.addApplicationImage("appId", "imagePath", 1);
		
		verify(portalDatabaseEngine, times(2)).getConnection();		
		verify(connection, times(1)).executeUpdate(any(QueryVO.class));
	}	
	
	@Test
	public void testGetAppVersionCommand() throws SQLException{		
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
	
		when(resultSet.next()).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("test");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));
		List<String> grpIds = new ArrayList<>();
		developerApplications.getAppVersionCommand("userId", "applicationId", "appVersionId",grpIds);
		
		verify(portalDatabaseEngine, times(5)).getConnection();
		verify(connection, times(2)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(4)).next();
		verify(resultSet, times(4)).getString(any(String.class));
	}
	
	@Test
	public void testGetVersionsOfApplication() throws SQLException{						
		when(resultSet.next()).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn(null);
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));
		
		List<VERSION_STATUS> filterVersionStstus = new ArrayList<>();
		developerApplications.getVersionsOfApplication("appId", "userId", "appVersionId", "appPlatformId",filterVersionStstus);
		
		verify(portalDatabaseEngine, times(3)).getConnection();
		verify(connection, times(2)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(4)).next();
		verify(resultSet, times(12)).getString(any(String.class));
	}

	@Test
	public void testGetInvitedVersionsOfGroup() throws SQLException{				
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn(null);
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));
		
		List<VERSION_STATUS> filterVersionStstus = new ArrayList<>();
		developerApplications.getInvitedVersionsOfGroup("appId", "groupId", filterVersionStstus);
		
		verify(portalDatabaseEngine, times(4)).getConnection();
		verify(connection, times(2)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(2)).next();		
	}
	
	@Test
	public void testIsAllVersionsInvited() throws SQLException {				
		when(resultSet.next()).thenReturn(true);
		boolean isVersionInvited = developerApplications.isAllVersionsInvited("appId", "groupId");
		
		assertFalse(isVersionInvited);
		verify(portalDatabaseEngine, times(2)).getConnection();
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(1)).next();	
	}	
	
	@Test(expected = Exception.class)
	public void testIsApplicationExits() throws Exception {				
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		developerApplications.isApplicationExits("title");
	}
	
	@Test
	public void testIsApplicationNotExits() throws Exception {				
		when(resultSet.next()).thenReturn(false);
		developerApplications.isApplicationExits("title");
		
		verify(portalDatabaseEngine, times(2)).getConnection();
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(1)).next();	
	}
	
	@Test
	public void testAddAppRepo() throws SQLException {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		ApplicationPlatformVO appRepoVO = new ApplicationPlatformVO();
		appRepoVO.setAppId("appId");
		appRepoVO.setAppPlatformId("appPlatformId");
		developerApplications.addAppRepo(appRepoVO);
		
		verify(portalDatabaseEngine, times(2)).getConnection();		
		verify(connection, times(1)).executeUpdate(any(QueryVO.class));
	}
	
	@Test(expected = SQLException.class)
	public void testAddAppRepoUnsuccessfull() throws SQLException {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(0);
		ApplicationPlatformVO appRepoVO = new ApplicationPlatformVO();
		appRepoVO.setAppId("appId");		
		developerApplications.addAppRepo(appRepoVO);
	}
	
	@Test(expected = Exception.class)
	public void testIsAppNameAlreadyExist() throws Exception {
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		developerApplications.isAppNameAlreadyExist("appName","appId");
	}
	
	@Test
	public void testIsAppNameNotExist() throws Exception {
		when(resultSet.next()).thenReturn(false);
		developerApplications.isAppNameAlreadyExist("appName","appId");
		
		verify(portalDatabaseEngine, times(2)).getConnection();
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(1)).next();	
	}
	
	@Test
	public void testGetVersionComposeYMLPath() throws SQLException {
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn(null);
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));
		developerApplications.getVersionComposeYMLPath("appId", "versionId");
		
		verify(portalDatabaseEngine, times(2)).getConnection();
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(2)).next();	
	}
	
	@Test
	public void testGetComposeVersion() throws SQLException {
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn(null);
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));
		developerApplications.getComposeVersion("appId", "versionId");
		
		verify(portalDatabaseEngine, times(2)).getConnection();
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(2)).next();	
	}
	
	
	@Test
	public void testGetInstalledApplicationComposeVersion() throws SQLException {
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn(null);
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));
		developerApplications.getInstalledApplicationComposeVersion("appId", "versionId");
		
		verify(portalDatabaseEngine, times(2)).getConnection();
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(2)).next();
	}
	
	@Test
	public void testGetAllAppType() throws SQLException {
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn(null);
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));
		developerApplications.getAllAppType();
		
		verify(portalDatabaseEngine, times(2)).getConnection();
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(2)).next();
	}
	
	@Test
	public void testIsRepoNameAvailable() throws SQLException {
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn(null);
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));
		
		List<String> listOfRepo = new ArrayList<>();
		developerApplications.isRepoNameAvailable(listOfRepo, "appId");
		
		verify(portalDatabaseEngine, times(2)).getConnection();
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(2)).next();
	}
	
	@Test
	public void testDeleteAppImage() throws SQLException {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);		
		String actualMessage = developerApplications.deleteAppImage("appId","imageId");
		
		assertTrue("imageId".equals(actualMessage));
		verify(portalDatabaseEngine, times(2)).getConnection();		
		verify(connection, times(1)).executeUpdate(any(QueryVO.class));
	}
}
