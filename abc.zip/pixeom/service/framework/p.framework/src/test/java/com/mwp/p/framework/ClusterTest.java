package com.mwp.p.framework;

import static org.mockito.Matchers.any;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.mockStatic;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.BDDMockito;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.classloader.annotations.SuppressStaticInitializationFor;
import org.powermock.modules.junit4.PowerMockRunner;

import com.mwp.common.CredProvider;
import com.mwp.common.constant.Constant;
import com.mwp.common.enums.NodeType;
import com.mwp.common.enums.StateEnum;
import com.mwp.common.vo.DeviceNodeMasterVO;
import com.mwp.common.vo.DeviceVO;
import com.mwp.common.vo.QueryVO;
import com.mwp.db.Interface.IConnection;
import com.mwp.p.dal.engine.PortalDatabaseEngine;
import com.pa.crypto.StringEncryptionDecryption;

@RunWith(PowerMockRunner.class)
@SuppressStaticInitializationFor({ "com.mwp.b.common.Constants", "com.mwp.p.dal.engine.PortalDatabaseEngine" })
@PrepareForTest({ Constant.class, StringEncryptionDecryption.class, PortalDatabaseEngine.class })
public class ClusterTest {

	@Mock
	private PortalDatabaseEngine portalDatabaseEngine;

	@Mock
	IConnection connection;

	@Mock
	private ResultSet resultSet;

	@Mock
	private CredProvider credProvider;

	private Cluster cluster;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		mockStatic(PortalDatabaseEngine.class);
		mockStatic(StringEncryptionDecryption.class);
		mockStatic(Constant.class);
		cluster = spy(new Cluster());

		when(PortalDatabaseEngine.getInstance()).thenReturn(portalDatabaseEngine);
		when(portalDatabaseEngine.getConnection()).thenReturn(connection);

		when(connection.executeQuery(any(QueryVO.class))).thenReturn(resultSet);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		BDDMockito.given(StringEncryptionDecryption.decrypt(any(), any())).willReturn("test");
		BDDMockito.given(StringEncryptionDecryption.encrypt(any(), any())).willReturn("test");

		BDDMockito.given(StringEncryptionDecryption.decrypt(any())).willReturn("test");
		BDDMockito.given(StringEncryptionDecryption.encrypt(any())).willReturn("test");

		PowerMockito.whenNew(CredProvider.class).withNoArguments().thenReturn(credProvider);
	}

	@After
	public void tearDown() {
		cluster = null;
		connection = null;
		resultSet = null;
		portalDatabaseEngine = null;
	}

	@Test(expected = Exception.class)
	public void testCreateCluster() throws Exception {
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("deviceId");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		List<DeviceNodeMasterVO> listProductId = new ArrayList<>();
		DeviceNodeMasterVO deviceNodeMasterVO = new DeviceNodeMasterVO("macAdd", NodeType.MASTER, StateEnum.Active);
		listProductId.add(deviceNodeMasterVO);
		cluster.createCluster("clusterName", "userId", "clusterId", "platformActualName",  listProductId);

		verify(portalDatabaseEngine, times(5)).getConnection();
		verify(connection, times(2)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(3)).next();
		verify(resultSet, times(1)).getInt(any(String.class));
	}
	
	@Test(expected = Exception.class)
	public void testCreateClusterWhenPlatFormIsEmpty() throws Exception {
		when(resultSet.next()).thenReturn(false).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("deviceId");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		List<DeviceNodeMasterVO> listProductId = new ArrayList<>();
		DeviceNodeMasterVO deviceNodeMasterVO = new DeviceNodeMasterVO("macAdd", NodeType.MASTER, StateEnum.Active);
		listProductId.add(deviceNodeMasterVO);
		cluster.createCluster("clusterName", "userId", "clusterId", "platformActualName",  listProductId);

		verify(portalDatabaseEngine, times(5)).getConnection();
		verify(connection, times(2)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(3)).next();
		verify(resultSet, times(1)).getInt(any(String.class));
	}
	
	@Test
	public void testCreateClusterWhenMacAddressIsEmpty() throws Exception {
		when(connection.executeUpdatesInTransaction(any())).thenReturn(true);
		when(resultSet.next()).thenReturn(false).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false)
		.thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false);
		
		when(resultSet.getString(any(String.class))).thenReturn("deviceId");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		List<DeviceNodeMasterVO> listProductId = new ArrayList<>();
		DeviceNodeMasterVO deviceNodeMasterVO = new DeviceNodeMasterVO("macAdd", NodeType.MASTER, StateEnum.Active);
		listProductId.add(deviceNodeMasterVO);
		DeviceVO deviceVo = cluster.createCluster("clusterName", "userId", "clusterId", "platformActualName",  listProductId);
		
		assertNotNull(deviceVo);
		verify(portalDatabaseEngine, times(22)).getConnection();
		verify(connection, times(5)).executeQuery(any(QueryVO.class));
		verify(connection, times(1)).executeUpdatesInTransaction(any());
		verify(resultSet, times(9)).next();
		verify(resultSet, times(6)).getString(any(String.class));
	}
	
	@Test
	public void testAddDevicesToCluster() throws SQLException {
		when(connection.executeUpdatesInTransaction(any())).thenReturn(true);
		when(resultSet.next()).thenReturn(false).thenReturn(true).thenReturn(false);
		
		when(resultSet.getString(any(String.class))).thenReturn("deviceId");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		List<DeviceNodeMasterVO> listProductId = new ArrayList<>();
		DeviceNodeMasterVO deviceNodeMasterVO = new DeviceNodeMasterVO("macAdd", NodeType.MASTER, StateEnum.Active);
		listProductId.add(deviceNodeMasterVO);
		cluster.addDevicesToCluster("clusterName", listProductId);
		
		verify(portalDatabaseEngine, times(9)).getConnection();
		verify(connection, times(2)).executeQuery(any(QueryVO.class));
		verify(connection, times(1)).executeUpdatesInTransaction(any());
		verify(resultSet, times(3)).next();
		verify(resultSet, times(1)).getString(any(String.class));
	}
	
	@Test
	public void testUpdateClusterName() throws SQLException {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		boolean isUpdated = cluster.updateClusterName("clusterDeviceId", "clusterName");
		assertTrue(isUpdated);
		verify(portalDatabaseEngine, times(2)).getConnection();		
		verify(connection, times(1)).executeUpdate(any(QueryVO.class));
	}	
}
