package com.mwp.p.framework;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.mockStatic;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.classloader.annotations.SuppressStaticInitializationFor;
import org.powermock.modules.junit4.PowerMockRunner;

import com.mwp.common.CredProvider;
import com.mwp.common.constant.Constant;
import com.mwp.common.vo.QueryVO;
import com.mwp.db.Interface.IConnection;
import com.mwp.p.common.enums.PortalDBEnum.AD_TYPE;
import com.mwp.p.common.vo.AdZoneVO;
import com.mwp.p.dal.engine.PortalDatabaseEngine;
import com.pa.crypto.StringEncryptionDecryption;

@RunWith(PowerMockRunner.class)
@SuppressStaticInitializationFor({ "com.mwp.p.common.Constants", "com.mwp.p.dal.engine.PortalDatabaseEngine" })
@PrepareForTest({ Constant.class, StringEncryptionDecryption.class, PortalDatabaseEngine.class })
public class AdZoneTest {

	@Mock
	private PortalDatabaseEngine portalDatabaseEngine;

	@Mock
	IConnection connection;

	@Mock
	private ResultSet resultSet;

	@Mock
	private CredProvider credProvider;

	private AdZone adZone;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		mockStatic(PortalDatabaseEngine.class);
		mockStatic(StringEncryptionDecryption.class);
		mockStatic(Constant.class);
		adZone = spy(new AdZone());

		when(PortalDatabaseEngine.getInstance()).thenReturn(portalDatabaseEngine);
		when(portalDatabaseEngine.getConnection()).thenReturn(connection);

		when(connection.executeQuery(any(QueryVO.class))).thenReturn(resultSet);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		when(StringEncryptionDecryption.decrypt(any(), any())).thenReturn("test");
		when(StringEncryptionDecryption.encrypt(any(), any())).thenReturn("test");

		when(StringEncryptionDecryption.decrypt(any())).thenReturn("test");
		when(StringEncryptionDecryption.encrypt(any())).thenReturn("test");

		PowerMockito.whenNew(CredProvider.class).withNoArguments().thenReturn(credProvider);
	}

	@After
	public void tearDown() {
		adZone = null;
		connection = null;
		resultSet = null;
		portalDatabaseEngine = null;
	}

	@Test
	public void testAdd() throws SQLException {
		AdZoneVO expectedAddZone = populateAdZoneVo();		
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getString(any(String.class))).thenReturn("zoneId");
		
		AdZoneVO actualAddZone = adZone.add(expectedAddZone);
		assertTrue(expectedAddZone.getZoneId().equals(actualAddZone.getZoneId()));
		
		verify(portalDatabaseEngine, times(6)).getConnection();
		verify(connection, times(1)).executeUpdate(any(QueryVO.class));
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(2)).next();
		verify(resultSet, times(2)).getInt(any(String.class));
		verify(resultSet, times(4)).getString(any(String.class));
	}
	
	@Test
	public void testEditSortOrder() throws SQLException {				
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);	
		boolean actualEditSortOrderValue = adZone.editSortOrder(1, "addId");
		assertTrue(actualEditSortOrderValue);
		
		verify(portalDatabaseEngine, times(3)).getConnection();
		verify(connection, times(1)).executeUpdate(any(QueryVO.class));
	}
	
	@Test
	public void testDelete() throws SQLException {				
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);	
		boolean actualEditSortOrderValue = adZone.delete("addId");
		assertTrue(actualEditSortOrderValue);
		
		verify(portalDatabaseEngine, times(3)).getConnection();
		verify(connection, times(1)).executeUpdate(any(QueryVO.class));
	}
	
	@Test
	public void testDeleteOnUpdateFailed() throws SQLException {				
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(0);	
		boolean actualEditSortOrderValue = adZone.delete("addId");
		assertFalse(actualEditSortOrderValue);
		
		verify(portalDatabaseEngine, times(3)).getConnection();
		verify(connection, times(1)).executeUpdate(any(QueryVO.class));
	}
	
	@Test
	public void testGet() throws SQLException {
		AdZoneVO expectedAddZone = populateAdZoneVo();		
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getString(any(String.class))).thenReturn("zoneId");
		
		AdZoneVO actualAddZone = adZone.get("addId","zoneId");
		assertTrue(expectedAddZone.getZoneId().equals(actualAddZone.getZoneId()));
		
		verify(portalDatabaseEngine, times(3)).getConnection();
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(2)).next();
		verify(resultSet, times(2)).getInt(any(String.class));
		verify(resultSet, times(4)).getString(any(String.class));
	}
	
	@Test
	public void testList() throws SQLException {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		when(resultSet.next()).thenReturn(true).thenReturn(true).thenReturn(false);
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getString(any(String.class))).thenReturn("zoneId");
		
		List<AdZoneVO> actualAddZones = adZone.list();
		assertEquals(2, actualAddZones.size());
		
		verify(portalDatabaseEngine, times(3)).getConnection();
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(3)).next();
		verify(resultSet, times(4)).getInt(any(String.class));
		verify(resultSet, times(8)).getString(any(String.class));
	}
	
	@Test
	public void testListByType() throws SQLException {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		when(resultSet.next()).thenReturn(true).thenReturn(true).thenReturn(false);
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getString(any(String.class))).thenReturn("zoneId");
		
		List<AdZoneVO> actualAddZones = adZone.listByType(AD_TYPE.appBanner);
		assertEquals(2, actualAddZones.size());
		
		verify(portalDatabaseEngine, times(3)).getConnection();
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(3)).next();
		verify(resultSet, times(4)).getInt(any(String.class));
		verify(resultSet, times(8)).getString(any(String.class));
	}
	
	@Test
	public void testListByCategory() throws SQLException {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		when(resultSet.next()).thenReturn(true).thenReturn(true).thenReturn(false);
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getString(any(String.class))).thenReturn("zoneId");
		
		List<AdZoneVO> actualAddZones = adZone.listByCategory("category");
		assertEquals(2, actualAddZones.size());
		
		verify(portalDatabaseEngine, times(3)).getConnection();
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(3)).next();
		verify(resultSet, times(4)).getInt(any(String.class));
		verify(resultSet, times(8)).getString(any(String.class));
	}

	private AdZoneVO populateAdZoneVo() {
		AdZoneVO adZoneObj = new AdZoneVO();
		adZoneObj.setAppId("appId");
		adZoneObj.setCategoryId("categoryId");
		adZoneObj.setSortOrder(1);
		adZoneObj.setZoneId("zoneId");
		adZoneObj.setType(AD_TYPE.appBanner);
		return adZoneObj;
	}

	
}
