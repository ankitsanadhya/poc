package com.mwp.p.framework;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.mockStatic;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.BDDMockito;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.classloader.annotations.SuppressStaticInitializationFor;
import org.powermock.modules.junit4.PowerMockRunner;

import com.mwp.common.CredProvider;
import com.mwp.common.constant.Constant;
import com.mwp.common.vo.QueryVO;
import com.mwp.db.Interface.IConnection;
import com.mwp.p.dal.engine.PortalDatabaseEngine;
import com.pa.crypto.StringEncryptionDecryption;

@RunWith(PowerMockRunner.class)
@SuppressStaticInitializationFor({"com.mwp.b.common.Constants","com.mwp.p.dal.engine.PortalDatabaseEngine"})
@PrepareForTest({Constant.class, StringEncryptionDecryption.class, PortalDatabaseEngine.class})
public class BoxStaticsTest {
	
	@Mock
	private PortalDatabaseEngine portalDatabaseEngine;
	
	@Mock 
	IConnection connection;

	@Mock
	private ResultSet resultSet;
	
	@Mock
	private CredProvider credProvider;
	
	private BoxStatics boxStatics;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		mockStatic(PortalDatabaseEngine.class);
		mockStatic(StringEncryptionDecryption.class);
		mockStatic(Constant.class);
		boxStatics = spy(new BoxStatics());

		when(PortalDatabaseEngine.getInstance()).thenReturn(portalDatabaseEngine);
		when(portalDatabaseEngine.getConnection()).thenReturn(connection);
		
		when(connection.executeQuery(any(QueryVO.class))).thenReturn(resultSet);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));
		
		when(StringEncryptionDecryption.decrypt(any(),any())).thenReturn("test");
		when(StringEncryptionDecryption.encrypt(any(),any())).thenReturn("test");
		
		when(StringEncryptionDecryption.decrypt(any())).thenReturn("test");
		when(StringEncryptionDecryption.encrypt(any())).thenReturn("test");
		
		PowerMockito.whenNew(CredProvider.class).withNoArguments().thenReturn(credProvider);
	}

	@After
	public void tearDown() {
		boxStatics = null;
		connection = null;
		resultSet = null;
		portalDatabaseEngine = null;
	}
	
	@Test
	public void testInsert() throws SQLException {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);	
		boxStatics.insert("deviceId", "statics");
		
		verify(portalDatabaseEngine, times(2)).getConnection();
		verify(connection, times(1)).executeUpdate(any(QueryVO.class));		
	}	
	
	
	@Test
	public void testList() throws SQLException {
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("deviceId");
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));
				
		boxStatics.list("deviceId");
		
		verify(portalDatabaseEngine, times(2)).getConnection();
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(2)).next();
		verify(resultSet, times(1)).getString(any(String.class));
		verify(resultSet, times(1)).getTimestamp(any(String.class));
	}
}
