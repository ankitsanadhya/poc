package com.mwp.p.framework;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.mockStatic;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.BDDMockito;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.classloader.annotations.SuppressStaticInitializationFor;
import org.powermock.modules.junit4.PowerMockRunner;

import com.mwp.common.CredProvider;
import com.mwp.common.constant.Constant;
import com.mwp.common.vo.QueryVO;
import com.mwp.db.Interface.IConnection;
import com.mwp.p.dal.engine.PortalDatabaseEngine;
import com.pa.crypto.StringEncryptionDecryption;

@RunWith(PowerMockRunner.class)
@SuppressStaticInitializationFor({ "com.mwp.b.common.Constants", "com.mwp.p.dal.engine.PortalDatabaseEngine" })
@PrepareForTest({ Constant.class, StringEncryptionDecryption.class, PortalDatabaseEngine.class })
public class ValidationInfoTest {

	@Mock
	private PortalDatabaseEngine portalDatabaseEngine;

	@Mock
	IConnection connection;

	@Mock
	private ResultSet resultSet;

	@Mock
	private CredProvider credProvider;

	private ValidationInfo validationInfo;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		mockStatic(PortalDatabaseEngine.class);
		mockStatic(StringEncryptionDecryption.class);
		mockStatic(Constant.class);
		validationInfo = spy(new ValidationInfo());

		when(PortalDatabaseEngine.getInstance()).thenReturn(portalDatabaseEngine);
		when(portalDatabaseEngine.getConnection()).thenReturn(connection);

		when(connection.executeQuery(any(QueryVO.class))).thenReturn(resultSet);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		BDDMockito.given(StringEncryptionDecryption.decrypt(any(), any())).willReturn("test");
		BDDMockito.given(StringEncryptionDecryption.encrypt(any(), any())).willReturn("test");

		BDDMockito.given(StringEncryptionDecryption.decrypt(any())).willReturn("test");
		BDDMockito.given(StringEncryptionDecryption.encrypt(any())).willReturn("test");

		PowerMockito.whenNew(CredProvider.class).withNoArguments().thenReturn(credProvider);
	}

	@After
	public void tearDown() {

	}

	@Test
	public void testCheckValidationInfo() throws SQLException {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("macAddress");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getLong(any(String.class))).thenReturn(100L);

		validationInfo.checkValidationInfo("macAddress", 0, "macAddress", 100, "email", "hostName", "swLicenseTest",
				"hwConfig");
	}
	
//	validInfoVO.setsMACAddress(rs.getString(PortalDBEnum.VALIDATION_INFO.sMACAddress.name()));
//	validInfoVO.setsGUID(rs.getString(PortalDBEnum.VALIDATION_INFO.sGUID.name()));
//	validInfoVO.setnStatus(rs.getInt(PortalDBEnum.VALIDATION_INFO.nStatus.name()));
//	validInfoVO.setnTimestamp(rs.getLong(PortalDBEnum.VALIDATION_INFO.nTimestamp.name()));
//	validInfoVO.setsInternetAddress(rs.getString(PortalDBEnum.VALIDATION_INFO.sInternetAddress.name()));
//	validInfoVO.setsCode(rs.getString(PortalDBEnum.VALIDATION_INFO.sCode.name()));
//	validInfoVO.setnPreviousTS(rs.getLong(PortalDBEnum.VALIDATION_INFO.nPreviousTS.name()));

	@Test
	public void testCheckValidationInfoWhenGuidIsDifferent() throws SQLException {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("macAddress").thenReturn("guid");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getLong(any(String.class))).thenReturn(100L);
		validationInfo.checkValidationInfo("macAddress", 0, "guid", 100, "email", "hostName", "swLicenseTest",
				"hwConfig");
	}

	
	@Test
	public void testCheckValidationInfoFail() throws SQLException {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("macAddress").thenReturn("guid");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getLong(any(String.class))).thenReturn(100L);
		validationInfo.checkValidationInfo("macAddress", 0, "guid", 0, "email", "hostName", "swLicenseTest",
				"hwConfig");
	}
	
	@Test
	public void testIsProductIDUnique() throws SQLException {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("macAddress");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getLong(any(String.class))).thenReturn(100L);
		validationInfo.isProductIDUnique("productId");
	}

	@Test
	public void testIsProductIDUniqueWhenDuplicateMacAddress() throws SQLException {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		when(resultSet.next()).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("macAddress");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getLong(any(String.class))).thenReturn(100L);
		validationInfo.isProductIDUnique("productId");
	}
}
