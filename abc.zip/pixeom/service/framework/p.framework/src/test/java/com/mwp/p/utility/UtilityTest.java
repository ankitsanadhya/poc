package com.mwp.p.utility;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.mockStatic;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.powermock.core.classloader.annotations.SuppressStaticInitializationFor;
import org.powermock.modules.junit4.PowerMockRunner;

import com.mwp.common.enums.RoleEnum;
import com.mwp.common.vo.AuthorizationsVO;
import com.mwp.common.vo.QueryVO;
import com.mwp.db.Interface.IConnection;
import com.mwp.p.dal.engine.PortalDatabaseEngine;

@RunWith(PowerMockRunner.class)
@SuppressStaticInitializationFor({"com.mwp.b.common.Constants","com.mwp.p.dal.engine.PortalDatabaseEngine"})
public class UtilityTest {
	@Mock
	private PortalDatabaseEngine portalDatabaseEngine;
	
	@Mock 
	IConnection connection;

	@Mock
	private ResultSet resultSet;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		mockStatic(PortalDatabaseEngine.class);
		
		when(PortalDatabaseEngine.getInstance()).thenReturn(portalDatabaseEngine);
		when(portalDatabaseEngine.getConnection()).thenReturn(connection);
		
		when(connection.executeQuery(any(QueryVO.class))).thenReturn(resultSet);
	}

	@After
	public void tearDown() {
		portalDatabaseEngine = null;
		connection = null;
		resultSet= null;
	}
	
	@Test
	public void testCheckPermission() throws Exception{		
		when(resultSet.next()).thenReturn(true).thenReturn(true).thenReturn(false).thenReturn(false).thenReturn(true).thenReturn(false);		
		when(resultSet.getString(any(String.class))).thenReturn("permission");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));
		
		Map<String, List<String>>  hashPermission = new HashMap<>();
		List<String> listOfPermissions = new LinkedList<>();
		listOfPermissions.add("permission");
		hashPermission.put("key", listOfPermissions);
		
		Utility.checkPermission(hashPermission, "permission", "permission");
	}
	
	@Test
	public void testCheckPermissionForWhat() throws Exception{		
		when(resultSet.next()).thenReturn(true).thenReturn(true).thenReturn(false).thenReturn(false).thenReturn(true).thenReturn(false);		
		when(resultSet.getString(any(String.class))).thenReturn("permission");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));
		
		Map<String, List<String>>  hashPermission = new HashMap<>();
		List<String> listOfPermissions = new LinkedList<>();
		listOfPermissions.add("permission");
		hashPermission.put("key", listOfPermissions);
		
		Utility.checkPermission(hashPermission, listOfPermissions, "permission", true);
	}

	
	@Test
	public void testCheckEdgecorePermission() throws Exception{		
		when(resultSet.next()).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false);		
		when(resultSet.getString(any(String.class))).thenReturn("permission");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));
		
		Map<String, List<String>>  hashPermission = new HashMap<>();
		List<String> listOfPermissions = new LinkedList<>();
		listOfPermissions.add("permission");
		hashPermission.put("permission", listOfPermissions);
		
		AuthorizationsVO authVo = new AuthorizationsVO();
		authVo.setApplicationId("permission");
		authVo.setRole(RoleEnum.User);
		authVo.setGroupPermissions(hashPermission);
		Utility.checkEdgecorePermission(authVo, listOfPermissions, "deviceId", false);
	}
	
	@Test
	public void testCheckEdgecorePermissionForDevices() throws Exception{		
		when(resultSet.next()).thenReturn(true).thenReturn(true).thenReturn(false).thenReturn(false).thenReturn(true).thenReturn(false);		
		when(resultSet.getString(any(String.class))).thenReturn("permission");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));
		
		Map<String, List<String>>  hashPermission = new HashMap<>();
		List<String> listOfPermissions = new LinkedList<>();
		listOfPermissions.add("permission");
		hashPermission.put("permission", listOfPermissions);
		
		AuthorizationsVO authVo = new AuthorizationsVO();
		authVo.setApplicationId("permission");
		authVo.setRole(RoleEnum.User);
		authVo.setGroupPermissions(hashPermission);
		
		List<String> deviceIds = new LinkedList<>();
		deviceIds.add("permission");
		Utility.checkEdgecorePermissionForDevices(authVo, listOfPermissions, deviceIds, false);
	}	
	
	@Test(expected = Exception.class)
	public void testCheckPermissionWhenAppNotFound() throws Exception{		
		when(resultSet.next()).thenReturn(true).thenReturn(false);		
		when(resultSet.getString(any(String.class))).thenReturn("deviceId");
		when(resultSet.getInt(any(String.class))).thenReturn(0).thenReturn(3).thenReturn(0);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));
		
		Map<String, List<String>>  hashPermission = new HashMap<>();
		List<String> listOfPermissions = new LinkedList<>();
		listOfPermissions.add("test");
		hashPermission.put("key", listOfPermissions);
		
		Utility.checkPermission(hashPermission, "permission", "applicationId");
	}
	
	@Test(expected = Exception.class)
	public void testCheckEdgecorePermissionForJobsWhenGroupIDNull() throws Exception{		
		when(resultSet.next()).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false);		
		when(resultSet.getString(any(String.class))).thenReturn("permission");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));
		
		List<String> listOfPermissions = new LinkedList<>();
		listOfPermissions.add("permission");
		
		AuthorizationsVO authVo = new AuthorizationsVO();
		authVo.setApplicationId("permission");
		authVo.setRole(RoleEnum.User);
		Utility.checkEdgecorePermissionForJobs(authVo, listOfPermissions);
	}
	
	@Test
	public void testCheckEdgecorePermissionForInstallApp() throws Exception{		
		checkEdgeCorePermissions("installApplication","appliances.apps.install");
	}
	
	@Test
	public void testCheckEdgecorePermissionForUpdateInstallApp() throws Exception{		
		checkEdgeCorePermissions("updateApplication","appliances.apps.install");
	}
	
	@Test
	public void testCheckEdgecorePermissionForUnInstallApp() throws Exception{		
		checkEdgeCorePermissions("uninstallApplication","appliances.apps.uninstall");
	}
	
	@Test
	public void testCheckEdgecorePermissionForSystemUpdate() throws Exception{		
		checkEdgeCorePermissions("systemUpdate","appliances.system.update");
	}
	
	@Test
	public void testCheckEdgecorePermissionForStartApplication() throws Exception{		
		checkEdgeCorePermissions("startApplication","appliances.apps.start");
	}
	
	@Test
	public void testCheckEdgecorePermissionForStopApplication() throws Exception{		
		checkEdgeCorePermissions("stopApplication","appliances.apps.stop");
	}
	
	@Test
	public void testCheckEdgecorePermissionForRestartApplication() throws Exception{		
		checkEdgeCorePermissions("restartApplication","appliances.apps.restart");
	}
	
	@Test
	public void testCheckEdgecorePermissionForSystemReboot() throws Exception{		
		checkEdgeCorePermissions("systemReboot","appliances.system.reboot");
	}
	
	@Test
	public void testCheckEdgecorePermissionForSystemShutdown() throws Exception{		
		checkEdgeCorePermissions("systemShutdown","appliances.system.shutdown");
	}
	
	@Test
	public void testCheckEdgecorePermissionForSystemFactoryReset() throws Exception{		
		checkEdgeCorePermissions("systemFactoryReset","appliances.system.factoryreset");
	}
	
	@Test
	public void testCheckEdgecorePermissionForSystemReset() throws Exception{		
		checkEdgeCorePermissions("systemReset","appliances.system.reset");
	}
	
	private void checkEdgeCorePermissions(String operation,String permission) throws SQLException, Exception {
		when(resultSet.next()).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false);		
		when(resultSet.getString(any(String.class))).thenReturn(operation);
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));
		
		Map<String, List<String>>  hashPermission = new HashMap<>();
		List<String> listOfPermissions = new LinkedList<>();
		listOfPermissions.add(permission);
		hashPermission.put(operation, listOfPermissions);
		
		AuthorizationsVO authVo = new AuthorizationsVO();
		authVo.setApplicationId("installApplication");
		authVo.setRole(RoleEnum.User);
		authVo.setGroupPermissions(hashPermission);
		Utility.checkEdgecorePermissionForJobs(authVo, listOfPermissions);
	}
}
