package com.mwp.p.framework;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.mockStatic;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.BDDMockito;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.classloader.annotations.SuppressStaticInitializationFor;
import org.powermock.modules.junit4.PowerMockRunner;

import com.mwp.common.CredProvider;
import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.common.constant.Constant;
import com.mwp.common.vo.QueryVO;
import com.mwp.db.Interface.IConnection;
import com.mwp.p.common.PortalCommon;
import com.mwp.p.common.vo.CompanyInfoVO;
import com.mwp.p.dal.CompanyDB;
import com.mwp.p.dal.engine.CompanyEngine;
import com.mwp.p.dal.engine.PortalDatabaseEngine;
import com.pa.crypto.StringEncryptionDecryption;

@RunWith(PowerMockRunner.class)
@SuppressStaticInitializationFor({ "com.mwp.b.common.Constants", "com.mwp.p.dal.engine.PortalDatabaseEngine" })
@PrepareForTest({ Constant.class, StringEncryptionDecryption.class, PortalDatabaseEngine.class, SqlQueryBuilder.class, CompanyEngine.class, CompanyDB.class })
public class CompanyTest {

	@Mock
	private PortalDatabaseEngine portalDatabaseEngine;

	@Mock
	IConnection connection;

	@Mock
	private ResultSet resultSet;

	@Mock
	private CredProvider credProvider;

	@Mock
	private PortalCommon portalCommon;

	private Company company;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		mockStatic(PortalDatabaseEngine.class);
		mockStatic(StringEncryptionDecryption.class);
		mockStatic(Constant.class);
		company = spy(new Company());

		when(PortalDatabaseEngine.getInstance()).thenReturn(portalDatabaseEngine);
		when(portalDatabaseEngine.getConnection()).thenReturn(connection);

		when(connection.executeQuery(any(QueryVO.class))).thenReturn(resultSet);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		BDDMockito.given(StringEncryptionDecryption.decrypt(any(), any())).willReturn("test");
		BDDMockito.given(StringEncryptionDecryption.encrypt(any(), any())).willReturn("test");

		BDDMockito.given(StringEncryptionDecryption.decrypt(any())).willReturn("test");
		BDDMockito.given(StringEncryptionDecryption.encrypt(any())).willReturn("test");

		BDDMockito.given(StringEncryptionDecryption.decrypt(any())).willReturn("test");
		PowerMockito.whenNew(CredProvider.class).withNoArguments().thenReturn(credProvider);
	}

	@After
	public void tearDown() {
		company = null;
	}

	@Test
	public void testList() throws SQLException {

		when(resultSet.next()).thenReturn(true).thenReturn(false);
		company.list("userId");
		
		verify(portalDatabaseEngine, times(2)).getConnection();
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(2)).next();
	}

	@Test
	public void testGet() throws SQLException {
		when(resultSet.next()).thenReturn(true).thenReturn(false);

		company.get("companyId", "userId");
		
		verify(portalDatabaseEngine, times(2)).getConnection();
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(2)).next();
	}

	@Test
	public void testIsCompanyExits() throws SQLException {
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("jobs");

		company.isCompanyExits("companyName", "userId");
		
		verify(portalDatabaseEngine, times(2)).getConnection();
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(2)).next();
	}

	@Test
	public void testAdd() throws Exception {
		when(resultSet.next()).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("jobs");
		
		CompanyInfoVO companyInfoVO = new CompanyInfoVO();
		companyInfoVO.setCompanyId("companyId");
		company.add(companyInfoVO);
		
		verify(portalDatabaseEngine, times(4)).getConnection();
		verify(connection, times(1)).executeUpdate(any(QueryVO.class));
		verify(resultSet, times(1)).next();
	}
	
	@Test(expected = Exception.class)
	public void testAddWhenCompanyAlreadyExist() throws Exception {
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("company");
		
		CompanyInfoVO companyInfoVO = new CompanyInfoVO();
		companyInfoVO.setCompanyId("companyId");
		company.add(companyInfoVO);
	}
	
	@Test
	public void testUpdate() throws Exception {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("jobs");
		
		CompanyInfoVO companyInfoVO = new CompanyInfoVO();
		companyInfoVO.setCompanyId("companyId");
		company.update(companyInfoVO,"userId");
		
		verify(portalDatabaseEngine, times(4)).getConnection();
		verify(connection, times(1)).executeUpdate(any(QueryVO.class));
		verify(resultSet, times(2)).next();
	}
	
	@Test(expected = Exception.class)
	public void testUpdateWhenCompanyIdIsEmpty() throws Exception {
		CompanyInfoVO companyInfoVO = new CompanyInfoVO();
		company.update(companyInfoVO,"userId");
	}
	
	@Test(expected = Exception.class)
	public void testUpdateWhenInfoNotAvailable() throws Exception {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		when(resultSet.next()).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("jobs");
		
		CompanyInfoVO companyInfoVO = new CompanyInfoVO();
		companyInfoVO.setCompanyId("companyId");
		company.update(companyInfoVO,"userId");
	}
	
	@Test
	public void testDelete() throws Exception {
		when(resultSet.next()).thenReturn(false);
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		company.delete("companyId", "userId");
		
		verify(portalDatabaseEngine, times(6)).getConnection();
		verify(connection, times(1)).executeUpdate(any(QueryVO.class));
	}
	
	@Test(expected = Exception.class)
	public void testDeleteWhenProjectExist() throws Exception {
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		company.delete("companyId", "userId");
	}
}
