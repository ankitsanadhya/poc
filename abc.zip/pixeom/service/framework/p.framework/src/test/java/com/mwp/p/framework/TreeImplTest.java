package com.mwp.p.framework;

import static org.mockito.Mockito.spy;

import java.sql.SQLException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.powermock.modules.junit4.PowerMockRunner;

import com.mwp.common.vo.LabelVO;

@RunWith(PowerMockRunner.class)
public class TreeImplTest {

	private TreeImpl treeimpl;
	
	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		treeimpl = spy(new TreeImpl("rootId"));
	}
	
	@After
	public void tearDown() {
		treeimpl = null;
	}
	
	@Test
	public void testPut() throws SQLException{
		LabelVO labelVO = new LabelVO();
		labelVO.setParentLabelId("rootId");
		
		treeimpl.put(labelVO);
	}
	
	@Test
	public void testPutContains() throws SQLException{
		
		LabelVO labelVO = new LabelVO();
		labelVO.setParentLabelId("rootId");
		treeimpl.put("rootId", labelVO);
		treeimpl.put(labelVO);
	}
	
	@Test
	public void testPutContainsChildrenNull() throws SQLException{
		LabelVO labelVO = new LabelVO();
		labelVO.setParentLabelId("rootId");
		labelVO.setChildLabels(null);
		treeimpl.put("rootId", labelVO);
		treeimpl.put(labelVO);
	}
	
	@Test
	public void testPutNoSuchParent() throws SQLException{
		LabelVO labelVO = new LabelVO();
		labelVO.setParentLabelId("rootId1");
		treeimpl.put(labelVO);
	}
}
