package com.mwp.p.framework;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.mockStatic;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.BDDMockito;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.classloader.annotations.SuppressStaticInitializationFor;
import org.powermock.modules.junit4.PowerMockRunner;

import com.mwp.common.CredProvider;
import com.mwp.common.constant.Constant;
import com.mwp.common.enums.InstallJobStatusEnum;
import com.mwp.common.vo.AuthorizationsVO;
import com.mwp.common.vo.InstallJobVO;
import com.mwp.common.vo.QueryVO;
import com.mwp.common.yamlparser.YamlParser;
import com.mwp.db.Interface.IConnection;
import com.mwp.p.common.PortalCommon;
import com.mwp.p.dal.engine.PortalDatabaseEngine;
import com.pa.crypto.StringEncryptionDecryption;

import static org.junit.Assert.*;

@RunWith(PowerMockRunner.class)
@SuppressStaticInitializationFor({ "com.mwp.b.common.Constants", "com.mwp.p.dal.engine.PortalDatabaseEngine" })
@PrepareForTest({ Constant.class, StringEncryptionDecryption.class, PortalDatabaseEngine.class, YamlParser.class,
		PortalCommon.class })
public class InstallJobsTest {

	@Mock
	private PortalDatabaseEngine portalDatabaseEngine;

	@Mock
	IConnection connection;

	@Mock
	private ResultSet resultSet;

	@Mock
	private CredProvider credProvider;

	@Mock
	private PortalCommon portalCommon;

	private InstallJobs installJobs;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		mockStatic(PortalDatabaseEngine.class);
		mockStatic(StringEncryptionDecryption.class);
		mockStatic(Constant.class);
		mockStatic(YamlParser.class);
		mockStatic(PortalCommon.class);
		installJobs = spy(new InstallJobs());

		when(PortalDatabaseEngine.getInstance()).thenReturn(portalDatabaseEngine);
		when(portalDatabaseEngine.getConnection()).thenReturn(connection);

		when(PortalCommon.getInstance()).thenReturn(portalCommon);
		when(portalCommon.executeCommnad(any())).thenReturn("valid");

		when(connection.executeQuery(any(QueryVO.class))).thenReturn(resultSet);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		BDDMockito.given(StringEncryptionDecryption.decrypt(any(), any())).willReturn("test");
		BDDMockito.given(StringEncryptionDecryption.encrypt(any(), any())).willReturn("test");

		BDDMockito.given(StringEncryptionDecryption.decrypt(any())).willReturn("test");
		BDDMockito.given(StringEncryptionDecryption.encrypt(any())).willReturn("test");

		BDDMockito.given(StringEncryptionDecryption.decrypt(any())).willReturn("test");
		PowerMockito.whenNew(CredProvider.class).withNoArguments().thenReturn(credProvider);
	}

	@After
	public void tearDown() {
		installJobs = null;
		portalCommon = null;
		resultSet = null;
		credProvider = null;
	}

	@Test
	public void testGetAllJobs() throws SQLException {
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("jobs");

		AuthorizationsVO authVo = new AuthorizationsVO();
		authVo.setApplicationId("applicationId");
		List<InstallJobVO> listOfInstallJob = installJobs.getAllJobs(authVo);
		assertEquals(1, listOfInstallJob.size());
		verify(portalDatabaseEngine, times(2)).getConnection();
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
	}

	@Test
	public void testUpdateJobTimeStamp() throws SQLException {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);

		AuthorizationsVO authVo = new AuthorizationsVO("userID", "applicationId");
		authVo.setApplicationId("applicationId");

		List<String> jobIds = new ArrayList<>();
		installJobs.updateJobTimeStamp(1L, jobIds);

		verify(portalDatabaseEngine, times(2)).getConnection();
		verify(connection, times(1)).executeUpdate(any(QueryVO.class));
	}

	@Test
	public void testDeleteJob() throws SQLException {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);

		AuthorizationsVO authVo = new AuthorizationsVO();
		authVo.setApplicationId("applicationId");

		List<String> jobIds = new ArrayList<>();
		boolean isDeleted = installJobs.deleteJob(jobIds);
		assertTrue(isDeleted);
		verify(portalDatabaseEngine, times(2)).getConnection();
		verify(connection, times(1)).executeUpdate(any(QueryVO.class));
	}

	@Test
	public void testUpdateJobStatus() throws SQLException {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		AuthorizationsVO authVo = new AuthorizationsVO();
		authVo.setApplicationId("applicationId");

		InstallJobVO installJobVO = new InstallJobVO();
		installJobVO.setStatus(InstallJobStatusEnum.EXECUTING);
		installJobVO.setDetail("detail");
		boolean isUpdated = installJobs.updateJobStatus(installJobVO);
		assertTrue(isUpdated);
		verify(portalDatabaseEngine, times(2)).getConnection();
		verify(connection, times(1)).executeUpdate(any(QueryVO.class));

	}

	@Test
	public void testGetAllPendingJobs() throws SQLException {
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("jobs");

		List<InstallJobVO> listOfInstallJobsVO = installJobs.getAllPendingJobs("userId", "deviceId");
		assertNotNull(listOfInstallJobsVO);
		assertEquals(1, listOfInstallJobsVO.size());
		verify(portalDatabaseEngine, times(2)).getConnection();
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(2)).next();
	}

	@Test
	public void testGetJobOperations() throws SQLException {
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("jobs");

		List<String> jobIds = new ArrayList<>();
		installJobs.getJobOperations(jobIds);

		verify(portalDatabaseEngine, times(2)).getConnection();
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(2)).next();
	}
}
