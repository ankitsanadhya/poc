package com.mwp.p.framework;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.mockStatic;

import java.io.FileReader;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.List;
import java.util.Map;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.BDDMockito;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.classloader.annotations.SuppressStaticInitializationFor;
import org.powermock.modules.junit4.PowerMockRunner;

import com.mwp.common.CredProvider;
import com.mwp.common.Mailer;
import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.common.constant.Constant;
import com.mwp.common.vo.QueryVO;
import com.mwp.db.Interface.IConnection;
import com.mwp.p.common.vo.RelayServerVO;
import com.mwp.p.dal.TokenDB;
import com.mwp.p.dal.engine.DiscoveryDetailsEngine;
import com.mwp.p.dal.engine.DiscoveryJarDetailsEngine;
import com.mwp.p.dal.engine.EmailServerEngine;
import com.mwp.p.dal.engine.PortalDatabaseEngine;
import com.mwp.p.dal.engine.SupportRelayServerEngine;
import com.mwp.p.dal.engine.TokenEngine;
import com.pa.crypto.StringEncryptionDecryption;

@RunWith(PowerMockRunner.class)
@SuppressStaticInitializationFor({ "com.mwp.p.common.Constants", "com.mwp.p.dal.engine.PortalDatabaseEngine","com.mwp.common.Mailer" })
@PrepareForTest({ Constant.class, DiscoveryDetailsEngine.class, DiscoveryJarDetailsEngine.class,
	StringEncryptionDecryption.class, PortalDatabaseEngine.class, URL.class, HttpURLConnection.class, 
	TokenEngine.class, SupportRelayServerEngine.class, TokenDB.class, EmailServerEngine.class, SqlQueryBuilder.class})
public class SupportRelayServerTest {

	@Mock
	private PortalDatabaseEngine portalDatabaseEngine;

	@Mock
	IConnection connection;

	@Mock
	private ResultSet resultSet;

	@Mock
	private CredProvider credProvider;
	
	@Mock
	private RelayServers relayServers;
	
	@Mock
	private FileReader fileReader;
	
	@Mock
	private JSONParser jsonParser;
	
	@Mock
	private Mailer mailer;
	
	private SupportRelayServer supportRelayServer;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		mockStatic(PortalDatabaseEngine.class);
		mockStatic(StringEncryptionDecryption.class);
		mockStatic(Constant.class);
		supportRelayServer = spy(new SupportRelayServer());

		when(PortalDatabaseEngine.getInstance()).thenReturn(portalDatabaseEngine);
		when(portalDatabaseEngine.getConnection()).thenReturn(connection);

		when(connection.executeQuery(any(QueryVO.class))).thenReturn(resultSet);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));
		PowerMockito.whenNew(CredProvider.class).withNoArguments().thenReturn(credProvider);
		BDDMockito.given(StringEncryptionDecryption.decrypt(any(), any())).willReturn("test");
		BDDMockito.given(StringEncryptionDecryption.encrypt(any(), any())).willReturn("test");

		BDDMockito.given(StringEncryptionDecryption.decrypt(any())).willReturn("test");
		BDDMockito.given(StringEncryptionDecryption.encrypt(any())).willReturn("test");
		BDDMockito.given(Constant.getProduct()).willReturn("productName");
		
		
	}

	@After
	public void tearDown() {
		supportRelayServer = null;
		fileReader = null;
		relayServers = null;
		mailer = null;
		credProvider = null;
		resultSet = null;
		jsonParser = null;
		connection = null;
		portalDatabaseEngine = null;
	}

	@Test
	public void testSetupSupportRelay() throws SQLException, IOException, ParseException {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		when(resultSet.next()).thenReturn(true).thenReturn(false).thenReturn(false)
		.thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(true).thenReturn(true).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("hostname");
		when(resultSet.getInt(any(String.class))).thenReturn(0);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));
		
		PowerMockito.doReturn(relayServers).when(supportRelayServer).buildRelayServers();
		when(relayServers.checkIfRelayServerIsAlive(Matchers.anyString(), Matchers.anyBoolean(), Matchers.anyBoolean())).thenReturn(200);
		
		Map<String, Object> mapOfSupportrelayServer = supportRelayServer.setupSupportRelay("hostname", "email", "token", true);
		
		assertEquals("Success", mapOfSupportrelayServer.get("Status"));
		assertEquals("", mapOfSupportrelayServer.get("ErrorMessage"));
		
		verify(portalDatabaseEngine, times(24)).getConnection();
		verify(connection, times(5)).executeUpdate(any(QueryVO.class));
		verify(connection, times(7)).executeQuery(any(QueryVO.class));
	}
	
	@Test
	public void testSetupSupportRelayWhenCallByAdminFalse() throws SQLException, IOException, ParseException {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		when(resultSet.next()).thenReturn(true).thenReturn(false).thenReturn(false)
		.thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(true).thenReturn(true).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("hostname");
		when(resultSet.getInt(any(String.class))).thenReturn(0);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));
		
		PowerMockito.doReturn(credProvider).when(supportRelayServer).buildCredProvider();
		when(credProvider.getEcnKey()).thenReturn("testEncKey");
		PowerMockito.doReturn(relayServers).when(supportRelayServer).buildRelayServers();
		when(relayServers.checkIfRelayServerIsAlive(Matchers.anyString(), Matchers.anyBoolean(), Matchers.anyBoolean())).thenReturn(200);
		
		Map<String, Object> mapOfSupportrelayServer = supportRelayServer.setupSupportRelay("hostname", "email", "token", false);
		assertEquals("Success", mapOfSupportrelayServer.get("Status"));
		assertEquals("", mapOfSupportrelayServer.get("ErrorMessage"));
		
		verify(portalDatabaseEngine, times(24)).getConnection();
		verify(connection, times(5)).executeUpdate(any(QueryVO.class));
		verify(connection, times(7)).executeQuery(any(QueryVO.class));
	}
	
	@Test
	public void testSetupSupportRelayWhenRelayServerreturns500() throws SQLException, IOException, ParseException {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		when(resultSet.next()).thenReturn(true).thenReturn(false).thenReturn(true)
		.thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(true).thenReturn(true).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("hostname");
		when(resultSet.getInt(any(String.class))).thenReturn(0);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));
		
		PowerMockito.doReturn(credProvider).when(supportRelayServer).buildCredProvider();
		when(credProvider.getEcnKey()).thenReturn("testEncKey");
		PowerMockito.doReturn(relayServers).when(supportRelayServer).buildRelayServers();
		when(relayServers.checkIfRelayServerIsAlive(Matchers.anyString(), Matchers.anyBoolean(), Matchers.anyBoolean())).thenReturn(500);
		
		Map<String, Object> mapOfSupportrelayServer = supportRelayServer.setupSupportRelay("hostname", "email", "token", true);
		assertEquals("Failure", mapOfSupportrelayServer.get("Status"));
		assertEquals("No relay server available.", mapOfSupportrelayServer.get("ErrorMessage"));
		
		verify(portalDatabaseEngine, times(6)).getConnection();
		verify(connection, times(3)).executeQuery(any(QueryVO.class));
	}
	
	@Test
	public void testSetupSupportRelayWhenAssignedPortNull() throws SQLException, IOException, ParseException {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		when(resultSet.next()).thenReturn(true).thenReturn(false).thenReturn(false)
		.thenReturn(true).thenReturn(false).thenReturn(false).thenReturn(true).thenReturn(true).thenReturn(true)
		.thenReturn(false).thenReturn(true).thenReturn(true).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("hostname");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));
		
		PowerMockito.doReturn(relayServers).when(supportRelayServer).buildRelayServers();
		when(relayServers.checkIfRelayServerIsAlive(Matchers.anyString(), Matchers.anyBoolean(), Matchers.anyBoolean())).thenReturn(200);
		
		Map<String, Object> mapOfSupportrelayServer = supportRelayServer.setupSupportRelay("hostname", "email", "token", true);
		assertEquals("Success", mapOfSupportrelayServer.get("Status"));
		assertEquals("", mapOfSupportrelayServer.get("ErrorMessage"));
		
		verify(portalDatabaseEngine, times(30)).getConnection();
		verify(connection, times(6)).executeUpdate(any(QueryVO.class));
		verify(connection, times(9)).executeQuery(any(QueryVO.class));
	}
	
	@Test
	public void testSetupSupportRelayWhenAssignedRelayPortNull() throws SQLException, IOException, ParseException {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		when(resultSet.next()).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(true).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("deviceId");
		when(resultSet.getInt(any(String.class))).thenReturn(0);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));
		
		PowerMockito.doReturn(relayServers).when(supportRelayServer).buildRelayServers();
		when(relayServers.checkIfRelayServerIsAlive(Matchers.anyString(), Matchers.anyBoolean(), Matchers.anyBoolean())).thenReturn(200);
		
		Map<String, Object> mapOfSupportrelayServer = supportRelayServer.setupSupportRelay("hostname", "email", "token", true);
		assertEquals("Success", mapOfSupportrelayServer.get("Status"));
		assertEquals(null, mapOfSupportrelayServer.get("ErrorMessage"));
		
		verify(portalDatabaseEngine, times(10)).getConnection();
		verify(connection, times(1)).executeUpdate(any(QueryVO.class));
		verify(connection, times(4)).executeQuery(any(QueryVO.class));
	}
	
	@Test
	public void testSetupSupportRelayCallByAdminFalse() throws SQLException, IOException, ParseException {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		when(resultSet.next()).thenReturn(true).thenReturn(false).thenReturn(true)
		.thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(true).thenReturn(true).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("deviceId");
		when(resultSet.getInt(any(String.class))).thenReturn(0);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));
		
		PowerMockito.doReturn(relayServers).when(supportRelayServer).buildRelayServers();		
		when(relayServers.checkIfRelayServerIsAlive(Matchers.anyString(), Matchers.anyBoolean(), Matchers.anyBoolean())).thenReturn(200);
		
		PowerMockito.doReturn(credProvider).when(supportRelayServer).buildCredProvider();
		when(credProvider.getEcnKey()).thenReturn("test") ;
		
		Map<String, Object> mapOfSupportrelayServer = supportRelayServer.setupSupportRelay("hostname", "email", "token", false);
		assertEquals("Success", mapOfSupportrelayServer.get("Status"));
		assertEquals(null, mapOfSupportrelayServer.get("ErrorMessage"));
		
		verify(portalDatabaseEngine, times(10)).getConnection();
		verify(connection, times(1)).executeUpdate(any(QueryVO.class));
		verify(connection, times(4)).executeQuery(any(QueryVO.class));
	}
	
	@Test
	public void testSetupDeleteSupportRelay() throws SQLException, IOException, ParseException {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		when(resultSet.next()).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(true).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("deviceId");
		when(resultSet.getInt(any(String.class))).thenReturn(0);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));
		
		
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("portalUrl", "http://portal.pixeom.com");		
				
		PowerMockito.doReturn(fileReader).when(supportRelayServer).buildFileReader();
		PowerMockito.doReturn(jsonParser).when(supportRelayServer).buildJSONParser();
		when(jsonParser.parse(fileReader)).thenReturn(jsonObject);
		
		PowerMockito.doReturn(relayServers).when(supportRelayServer).buildRelayServers();
		
		PowerMockito.doReturn(mailer).when(supportRelayServer).buildMailer(Matchers.anyList());
		
		PowerMockito.doNothing().when(mailer).sendDeleteSupportTokenEmail(Matchers.anyString(), Matchers.anyString(), Matchers.anyString());
		when(relayServers.checkIfRelayServerIsAlive(Matchers.anyString(), Matchers.anyBoolean(), Matchers.anyBoolean())).thenReturn(200);
		
		Map<String, Object> mapOfSupportrelayServer = supportRelayServer.setupDeleteSupportRelay("hostname", "email", "token");
		assertEquals("Success", mapOfSupportrelayServer.get("Status"));
		assertEquals("Token device mark as deleted.", mapOfSupportrelayServer.get("ErrorMessage"));
		
		verify(portalDatabaseEngine, times(7)).getConnection();
		verify(connection, times(1)).executeUpdate(any(QueryVO.class));
		verify(connection, times(2)).executeQuery(any(QueryVO.class));
	}
	
	@Test
	public void testSetupDeleteSupportRelayWhenTokenVoisNull() throws SQLException, IOException, ParseException {
		when(resultSet.next()).thenReturn(false);
		Map<String, Object> mapOfSupportrelayServer = supportRelayServer.setupDeleteSupportRelay("hostname", "email", "token");
		
		assertEquals("Failure", mapOfSupportrelayServer.get("Status"));
		assertEquals("Unable to update devicedetails, please try again.", mapOfSupportrelayServer.get("ErrorMessage"));
		
		verify(portalDatabaseEngine, times(4)).getConnection();
		verify(connection, times(1)).executeUpdate(any(QueryVO.class));
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
	}
	
	@Test
	public void testUpdateSupportTokenFailed() throws SQLException, IOException, ParseException {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(0);
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		Map<String, Object> mapOfSupportrelayServer = supportRelayServer.setupDeleteSupportRelay("hostname", "email", "token");
		
		assertEquals("Failure", mapOfSupportrelayServer.get("Status"));
		assertEquals("Unable to update devicedetails, please try again.", mapOfSupportrelayServer.get("ErrorMessage"));
		
		verify(portalDatabaseEngine, times(4)).getConnection();
		verify(connection, times(1)).executeUpdate(any(QueryVO.class));
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
	}
	
	@Test
	public void testSetupSupportRelayWhenTokenVoisNull() throws SQLException  {
		when(resultSet.next()).thenReturn(false);
		Map<String, Object> mapOfSupportrelayServer = supportRelayServer.setupSupportRelay("hostname", "email", "token", true);
		assertEquals("Failure", mapOfSupportrelayServer.get("Status"));
		assertEquals("Invalid suport token.", mapOfSupportrelayServer.get("ErrorMessage"));
		
		verify(portalDatabaseEngine, times(2)).getConnection();
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
	}
	
	@Test
	public void testListsAllSupportRelayServer() throws SQLException {
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		
		when(resultSet.getString(any(String.class))).thenReturn("deviceId");
		when(resultSet.getInt(any(String.class))).thenReturn(0);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));
		
		List<RelayServerVO> listOfRelayServer = supportRelayServer.listsAllSupportRelayServer(true);
		assertEquals(1, listOfRelayServer.size());
		
		verify(portalDatabaseEngine, times(2)).getConnection();		
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
		
	}
	
	@Test
	public void testInsertSupportRelayServer() throws Exception {
		when(resultSet.next()).thenReturn(false).thenReturn(true).thenReturn(false);
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		when(resultSet.getString(any(String.class))).thenReturn("relayName");
		RelayServerVO relayServerVo = new RelayServerVO();
		relayServerVo.setsRelayName("relayName");
		relayServerVo.setDeviceCount(12);
		
		RelayServerVO relayServerVOActual = supportRelayServer.insertSupportRelayServer(relayServerVo, true);
		assertEquals(relayServerVo.getsRelayName(), relayServerVOActual.getsRelayName());
		
		verify(portalDatabaseEngine, times(6)).getConnection();
		verify(connection, times(1)).executeUpdate(any(QueryVO.class));
		verify(connection, times(2)).executeQuery(any(QueryVO.class));
	}
	
	@Test
	public void testUpdateSupportRelayServer() throws SQLException {
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		when(resultSet.getString(any(String.class))).thenReturn("relayName1");
		RelayServerVO relayServerVo = new RelayServerVO();
		relayServerVo.setsRelayName("relayName1");
		relayServerVo.setDeviceCount(12);
		
		RelayServerVO relayServerVOActual = supportRelayServer.updateSupportRelayServer(relayServerVo, true);
		assertEquals(relayServerVo.getsRelayName(), relayServerVOActual.getsRelayName());
		
		verify(portalDatabaseEngine, times(4)).getConnection();
		verify(connection, times(1)).executeUpdate(any(QueryVO.class));
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
	}
	
	@Test
	public void testDeleteSupportRelayServer() throws SQLException {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);		
		supportRelayServer.deleteSupportRelayServer("relayServerId");
		
		verify(portalDatabaseEngine, times(2)).getConnection();
		verify(connection, times(1)).executeUpdate(any(QueryVO.class));
	}
	
	@Test
	public void testSupportRelayServerDetails() throws IOException, Exception {
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		Map<String, String> mapOfSupportrelayServer = supportRelayServer.supportRelayServerDetails("relayServerId");

		assertEquals("0", mapOfSupportrelayServer.get("nPortSegmentStart"));
		verify(portalDatabaseEngine, times(2)).getConnection();
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
	}
	
	@Test
	public void testGetSupportTokenDetails() throws IOException, Exception {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		
		when(resultSet.getString(any(String.class))).thenReturn("deviceId");
		when(resultSet.getInt(any(String.class))).thenReturn(0);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));
		
		supportRelayServer.GetSupportTokenDetails("relayServerId");
	}
	
	
	
	@Test
	public void testGenerateSupportToken() throws IOException, Exception {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		
		when(resultSet.getString(any(String.class))).thenReturn("deviceId");
		when(resultSet.getInt(any(String.class))).thenReturn(0);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));
	
		when(resultSet.next()).thenReturn(false);
		supportRelayServer.generateSupportToken("email","hostName","userId",1L,"nodeId");
	}
	
	@Test
	public void testSendTokenOnEmail() throws IOException, Exception {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		when(resultSet.next()).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false).thenReturn(false);
		
		when(resultSet.getString(any(String.class))).thenReturn("deviceId");
		when(resultSet.getInt(any(String.class))).thenReturn(0);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));
		
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("portalUrl", "http://portal.pixeom.com");		
				
		PowerMockito.doReturn(fileReader).when(supportRelayServer).buildFileReader();
		PowerMockito.doReturn(jsonParser).when(supportRelayServer).buildJSONParser();
		when(jsonParser.parse(fileReader)).thenReturn(jsonObject);
		
		
		PowerMockito.doReturn(mailer).when(supportRelayServer).buildMailer(Matchers.anyList());
		PowerMockito.doNothing().when(mailer).sendSupportTokenEmail(Matchers.anyString(), Matchers.anyString(), Matchers.anyString(), Matchers.anyString());
		
		supportRelayServer.sendTokenOnEmail("email","token","deviceId");
	}
	
	@Test
	public void testSendTokenOnEmailWhenDeviceVoIsEmpty() throws IOException, Exception {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		
		when(resultSet.getString(any(String.class))).thenReturn("deviceId");
		when(resultSet.getInt(any(String.class))).thenReturn(0);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));
		
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("portalUrl", "http://portal.pixeom.com");		
				
		PowerMockito.doReturn(fileReader).when(supportRelayServer).buildFileReader();
		PowerMockito.doReturn(jsonParser).when(supportRelayServer).buildJSONParser();
		when(jsonParser.parse(fileReader)).thenReturn(jsonObject);
		supportRelayServer.sendTokenOnEmail("email","token","deviceId");
	}
	
	@Test
	public void testListBids() throws IOException, Exception {		
		supportRelayServer.listBids("relayServerId",1);
	}
	
	@Test
	public void testDeleteExpiredLocks() throws IOException, Exception {		
		supportRelayServer.deleteExpiredLocks();
	}
}
