package com.mwp.p.framework;

import static org.junit.Assert.*;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.mockStatic;

import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.BDDMockito;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.classloader.annotations.SuppressStaticInitializationFor;
import org.powermock.modules.junit4.PowerMockRunner;

import com.mwp.common.Client;
import com.mwp.common.CredProvider;
import com.mwp.common.constant.Constant;
import com.mwp.common.enums.RelayEnum.NetworkTypeEnum;
import com.mwp.common.vo.DiscoveryDetailsVO;
import com.mwp.common.vo.DiscoveryJarDetailsVO;
import com.mwp.common.vo.QueryVO;
import com.mwp.common.vo.ValidationInfoVO;
import com.mwp.db.Interface.IConnection;
import com.mwp.p.common.Constants;
import com.mwp.p.common.enums.DNS_SERVERS;
import com.mwp.p.dal.engine.DiscoveryDetailsEngine;
import com.mwp.p.dal.engine.DiscoveryJarDetailsEngine;
import com.mwp.p.dal.engine.PortalDatabaseEngine;
import com.pa.crypto.StringEncryptionDecryption;

@RunWith(PowerMockRunner.class)
@SuppressStaticInitializationFor({ "com.mwp.p.common.Constants", "com.mwp.p.dal.engine.PortalDatabaseEngine" })
@PrepareForTest({ Constant.class, StringEncryptionDecryption.class, DiscoveryDetailsEngine.class,
		DiscoveryJarDetailsEngine.class, RelayServers.class, ManageDomainName.class, ManageDomainNameGoogle.class,
		ManageDomainNameJD.class, URL.class, HttpURLConnection.class, Client.class, HttpServletRequest.class, Constants.class})
public class DiscoveryDetailsTest {

	@Mock
	private PortalDatabaseEngine portalDatabaseEngine;

	@Mock
	IConnection connection;

	@Mock
	private ResultSet resultSet;

	@Mock
	private CredProvider credProvider;

	private DiscoveryDetails discoveryDetails;
	
	private static final String SUCCESS = "Success";

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		mockStatic(PortalDatabaseEngine.class);
		mockStatic(StringEncryptionDecryption.class);
		mockStatic(Constant.class);
		mockStatic(ManageDomainName.class);
		mockStatic(ManageDomainNameGoogle.class);
		mockStatic(ManageDomainNameJD.class);
		mockStatic(URL.class);
		mockStatic(HttpURLConnection.class);
		mockStatic(HttpServletRequest.class);		
		mockStatic(Client.class);
		mockStatic(Constants.class);

		discoveryDetails = spy(new DiscoveryDetails());

		when(PortalDatabaseEngine.getInstance()).thenReturn(portalDatabaseEngine);
		when(portalDatabaseEngine.getConnection()).thenReturn(connection);
		when(connection.executeQuery(any(QueryVO.class))).thenReturn(resultSet);
		PowerMockito.whenNew(CredProvider.class).withNoArguments().thenReturn(credProvider);
		when(connection.executeUpdatesInTransaction(any())).thenReturn(true);
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		BDDMockito.given(StringEncryptionDecryption.decrypt(any(), any())).willReturn("test");
		BDDMockito.given(StringEncryptionDecryption.encrypt(any(), any())).willReturn("test");
	}

	@After
	public void tearDown() throws Exception {
		discoveryDetails = null;
		connection = null;
		resultSet = null;
		credProvider = null;
		portalDatabaseEngine = null;
	}

	@Test
	public void testSetDiscoveryDetails() throws Exception {
		
		DiscoveryDetailsVO discoveryDetailsVO = populateDiscoveryDetails();

		when(PortalDatabaseEngine.getInstance()).thenReturn(portalDatabaseEngine);
		when(portalDatabaseEngine.getConnection()).thenReturn(connection);

		when(connection.executeQuery(any(QueryVO.class))).thenReturn(resultSet);

		when(resultSet.getString(any(String.class))).thenReturn("10.225.63.56");
		when(resultSet.getInt(any(String.class))).thenReturn(0).thenReturn(3).thenReturn(5).thenReturn(0);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		PowerMockito.whenNew(CredProvider.class).withNoArguments().thenReturn(credProvider);

		BDDMockito.given(StringEncryptionDecryption.decrypt(any(), any())).willReturn("test");
		BDDMockito.given(StringEncryptionDecryption.encrypt(any(), any())).willReturn("test");

		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		when(resultSet.next()).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(true).thenReturn(true)
				.thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false);

		String actualValue = discoveryDetails.setDiscoveryDetails(discoveryDetailsVO.getsDeviceID(), discoveryDetailsVO.getsIPAddress(),
				discoveryDetailsVO.getsLocalIPAddress(), discoveryDetailsVO.getsChatInputChannel(),
				discoveryDetailsVO.getsChatOutputChannel(), discoveryDetailsVO.getsChatSubscriptionChannel(),
				discoveryDetailsVO.getsNodeCommunicationPort(), discoveryDetailsVO.getsOpenStackPort(),
				discoveryDetailsVO.getsTomcatPort(), discoveryDetailsVO.getsPort1(), discoveryDetailsVO.getsPort2(),
				discoveryDetailsVO.getsPort3(), discoveryDetailsVO.getsPort4(), discoveryDetailsVO.getsPort5(),
				discoveryDetailsVO.getsRURLTomcatPort(), discoveryDetailsVO.getsRAddress(),
				discoveryDetailsVO.getnStatus(), discoveryDetailsVO.getsRelayServerID(),
				discoveryDetailsVO.getsNetworkType());
		assertEquals(SUCCESS, actualValue);
		
		verify(portalDatabaseEngine, times(14)).getConnection();
		verify(connection, times(3)).executeQuery(any(QueryVO.class));
		verify(connection, times(2)).executeUpdate(any(QueryVO.class));
	}

	@Test
	public void testSetDiscoveryDetailsForWanAmz() throws Exception {		
		BDDMockito.given(Constants.getDNS_SERVER()).willReturn(DNS_SERVERS.AMZ);
		
		PowerMockito.doNothing().when(ManageDomainName.class, "runCommand", any(), any(), any());
		String value = setDiscoveryDetailsForWan();
		assertEquals(SUCCESS, value);
		
		verify(portalDatabaseEngine, times(14)).getConnection();
		verify(connection, times(3)).executeQuery(any(QueryVO.class));
		verify(connection, times(2)).executeUpdate(any(QueryVO.class));
	}

	@Test
	public void testSetDiscoveryDetailsForWanGOO() throws Exception {
		BDDMockito.given(Constants.getDNS_SERVER()).willReturn(DNS_SERVERS.GOO);
		PowerMockito.doNothing().when(ManageDomainNameGoogle.class, "runCommand", any(), any(), any(), any());
		String value = setDiscoveryDetailsForWan();
		assertEquals(SUCCESS, value);
		
		verify(portalDatabaseEngine, times(14)).getConnection();
		verify(connection, times(3)).executeQuery(any(QueryVO.class));
		verify(connection, times(2)).executeUpdate(any(QueryVO.class));
	}

	@Test
	public void testSetDiscoveryDetailsForWanAZR() throws Exception {
		BDDMockito.given(Constants.getDNS_SERVER()).willReturn(DNS_SERVERS.AZR);
		String value = setDiscoveryDetailsForWan();
		assertEquals(SUCCESS, value);
		
		verify(portalDatabaseEngine, times(14)).getConnection();
		verify(connection, times(3)).executeQuery(any(QueryVO.class));
		verify(connection, times(2)).executeUpdate(any(QueryVO.class));
	}

	@Test
	public void testSetDiscoveryDetailsForWanJD() throws Exception {
		BDDMockito.given(Constants.getDNS_SERVER()).willReturn(DNS_SERVERS.JD);
		PowerMockito.doNothing().when(ManageDomainNameJD.class, "runCommand", any(), any(), any(), any());
		String value = setDiscoveryDetailsForWan();
		assertEquals(SUCCESS, value);
		
		verify(portalDatabaseEngine, times(14)).getConnection();
		verify(connection, times(3)).executeQuery(any(QueryVO.class));
		verify(connection, times(2)).executeUpdate(any(QueryVO.class));
	}

	@Test
	public void testSetDiscoveryDetailsForAMZ() throws Exception {
		BDDMockito.given(Constants.getDNS_SERVER()).willReturn(DNS_SERVERS.AMZ);
		PowerMockito.doNothing().when(ManageDomainName.class, "runCommand", any(), any(), any());
		String value = mockSetDiscoveryDetails();
		assertEquals(SUCCESS, value);
		
		verify(portalDatabaseEngine, times(14)).getConnection();
		verify(connection, times(3)).executeQuery(any(QueryVO.class));
		verify(connection, times(2)).executeUpdate(any(QueryVO.class));
	}

	@Test
	public void testSetDiscoveryDetailsForGOO() throws Exception {
		BDDMockito.given(Constants.getDNS_SERVER()).willReturn(DNS_SERVERS.GOO);
		PowerMockito.doNothing().when(ManageDomainNameGoogle.class, "runCommand", any(), any(), any(), any());
		String value = mockSetDiscoveryDetails();
		assertEquals(SUCCESS, value);
		
		
		verify(portalDatabaseEngine, times(14)).getConnection();
		verify(connection, times(3)).executeQuery(any(QueryVO.class));
		verify(connection, times(2)).executeUpdate(any(QueryVO.class));
	}

	@Test
	public void testSetDiscoveryDetailsForAZR() throws Exception {
		BDDMockito.given(Constants.getDNS_SERVER()).willReturn(DNS_SERVERS.AZR);
		String value = mockSetDiscoveryDetails();
		assertEquals(SUCCESS, value);
		
		
		verify(portalDatabaseEngine, times(14)).getConnection();
		verify(connection, times(3)).executeQuery(any(QueryVO.class));
		verify(connection, times(2)).executeUpdate(any(QueryVO.class));
	}

	@Test
	public void testSetDiscoveryDetailsForJD() throws Exception {
		BDDMockito.given(Constants.getDNS_SERVER()).willReturn(DNS_SERVERS.JD);
		PowerMockito.doNothing().when(ManageDomainNameJD.class, "runCommand", any(), any(), any(), any());
		String value = mockSetDiscoveryDetails();
		assertEquals(SUCCESS, value);
		
		
		verify(portalDatabaseEngine, times(14)).getConnection();
		verify(connection, times(3)).executeQuery(any(QueryVO.class));
		verify(connection, times(2)).executeUpdate(any(QueryVO.class));
	}

	@Test
	public void testSetDiscoveryDetailsWhenUnableToAddDiscoveryDetails() throws Exception {
		BDDMockito.given(Constants.getDNS_SERVER()).willReturn(DNS_SERVERS.AZR);
		DiscoveryDetailsVO discoveryDetailsVO = populateDiscoveryDetails();

		when(resultSet.next()).thenReturn(true).thenReturn(false);

		when(resultSet.getString(any(String.class))).thenReturn("deviceId");
		when(resultSet.getInt(any(String.class))).thenReturn(0).thenReturn(3).thenReturn(0);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		String value = discoveryDetails.setDiscoveryDetails(discoveryDetailsVO.getsDeviceID(), discoveryDetailsVO.getsIPAddress(),
				discoveryDetailsVO.getsLocalIPAddress(), discoveryDetailsVO.getsChatInputChannel(),
				discoveryDetailsVO.getsChatOutputChannel(), discoveryDetailsVO.getsChatSubscriptionChannel(),
				discoveryDetailsVO.getsNodeCommunicationPort(), discoveryDetailsVO.getsOpenStackPort(),
				discoveryDetailsVO.getsTomcatPort(), discoveryDetailsVO.getsPort1(), discoveryDetailsVO.getsPort2(),
				discoveryDetailsVO.getsPort3(), discoveryDetailsVO.getsPort4(), discoveryDetailsVO.getsPort5(),
				discoveryDetailsVO.getsRURLTomcatPort(), discoveryDetailsVO.getsRAddress(),
				discoveryDetailsVO.getnStatus(), discoveryDetailsVO.getsRelayServerID(),
				discoveryDetailsVO.getsNetworkType());		
		assertEquals(SUCCESS, value);
		
		
		verify(portalDatabaseEngine, times(14)).getConnection();
		verify(connection, times(3)).executeQuery(any(QueryVO.class));
		verify(connection, times(2)).executeUpdate(any(QueryVO.class));
	}

	@Test
	public void testReceiveDiscoveryDetails() throws Exception {
		BDDMockito.given(Constants.getDNS_SERVER()).willReturn(DNS_SERVERS.AZR);
		DiscoveryJarDetailsVO discoveryJarDetailsVO = populateDiscoveryJarDetails();
		ValidationInfoVO validationInfoVO = populateValidationInfoVO();

		when(PortalDatabaseEngine.getInstance()).thenReturn(portalDatabaseEngine);
		when(portalDatabaseEngine.getConnection()).thenReturn(connection);

		when(connection.executeQuery(any(QueryVO.class))).thenReturn(resultSet);
		when(resultSet.next()).thenReturn(true).thenReturn(false);

		when(resultSet.getString(any(String.class))).thenReturn("deviceId");
		when(resultSet.getInt(any(String.class))).thenReturn(0).thenReturn(3).thenReturn(0);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);

		Map<String, Object> discoveryDetailsActual = discoveryDetails.receiveDiscoveryDetails(discoveryJarDetailsVO, validationInfoVO);
		assertNotNull(discoveryDetailsActual);
		
		verify(portalDatabaseEngine, times(19)).getConnection();
		verify(connection, times(5)).executeQuery(any(QueryVO.class));
		verify(connection, times(2)).executeUpdate(any(QueryVO.class));
	}

	@Test(expected = Exception.class)
	public void testReceiveDiscoveryDetailsWhenDeviceIdIsNull() throws Exception {
		DiscoveryJarDetailsVO discoveryJarDetailsVO = new DiscoveryJarDetailsVO();
		discoveryJarDetailsVO.setsDeviceId(null);
		ValidationInfoVO validationInfoVO = new ValidationInfoVO();
		discoveryDetails.receiveDiscoveryDetails(discoveryJarDetailsVO, validationInfoVO);
	}

	@Test
	public void testReceiveJARRelayDiscoveryDetails() throws Exception {
		BDDMockito.given(Constants.getDNS_SERVER()).willReturn(DNS_SERVERS.AZR);
		DiscoveryJarDetailsVO discoveryJarDetailsVO = populateDiscoveryJarDetails();
		ValidationInfoVO validationInfoVO = populateValidationInfoVO();

		when(PortalDatabaseEngine.getInstance()).thenReturn(portalDatabaseEngine);
		when(portalDatabaseEngine.getConnection()).thenReturn(connection);

		when(connection.executeQuery(any(QueryVO.class))).thenReturn(resultSet);
		when(resultSet.next()).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false);

		when(resultSet.getString(any(String.class))).thenReturn("deviceId");
		when(resultSet.getInt(any(String.class))).thenReturn(0).thenReturn(3).thenReturn(0);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);

		PowerMockito.whenNew(CredProvider.class).withNoArguments().thenReturn(credProvider);

		BDDMockito.given(StringEncryptionDecryption.decrypt(any(), any())).willReturn("test");
		BDDMockito.given(StringEncryptionDecryption.encrypt(any(), any())).willReturn("test");

		Map<String, Object> discoveryDetailsActual = discoveryDetails.receiveJARRelayDiscoveryDetails(discoveryJarDetailsVO, validationInfoVO);
		assertNotNull(discoveryDetailsActual);
		
		verify(portalDatabaseEngine, times(26)).getConnection();
		verify(connection, times(7)).executeQuery(any(QueryVO.class));
		verify(connection, times(2)).executeUpdate(any(QueryVO.class));
	}

	@Test(expected = Exception.class)
	public void testReceiveJARRelayDiscoveryDetailsWhenMacAddressIsNull() throws Exception {
		DiscoveryJarDetailsVO discoveryJarDetailsVO = new DiscoveryJarDetailsVO();
		ValidationInfoVO validationInfoVO = new ValidationInfoVO();
		discoveryDetails.receiveJARRelayDiscoveryDetails(discoveryJarDetailsVO, validationInfoVO);
	}

	@Test
	public void testReceiveRelayDiscoveryDetails() throws Exception {
		BDDMockito.given(Constants.getDNS_SERVER()).willReturn(DNS_SERVERS.AZR);
		DiscoveryJarDetailsVO discoveryJarDetailsVO = populateDiscoveryJarDetails();
		ValidationInfoVO validationInfoVO = populateValidationInfoVO();
		when(resultSet.next()).thenReturn(true).thenReturn(false);

		when(resultSet.getString(any(String.class))).thenReturn("10.225.63.56");
		when(resultSet.getInt(any(String.class))).thenReturn(0).thenReturn(1).thenReturn(5).thenReturn(0).thenReturn(1)
				.thenReturn(2);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));
		Map<String, Object> discoveryDetailsActual = discoveryDetails.receiveRelayDiscoveryDetails(discoveryJarDetailsVO, validationInfoVO);
		assertNotNull(discoveryDetailsActual);
		verify(portalDatabaseEngine, times(30)).getConnection();
		verify(connection, times(9)).executeQuery(any(QueryVO.class));
		verify(connection, times(2)).executeUpdate(any(QueryVO.class));
	}

	@Test
	public void testReceiveRelayDiscoveryDetailsWhenTimeStampSame() throws Exception {
		BDDMockito.given(Constants.getDNS_SERVER()).willReturn(DNS_SERVERS.AZR);
		DiscoveryJarDetailsVO discoveryJarDetailsVO = populateDiscoveryJarDetails();
		ValidationInfoVO validationInfoVO = populateValidationInfoVO();
		when(resultSet.next()).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false).thenReturn(true)
				.thenReturn(false);

		URL u = PowerMockito.mock(URL.class);
		PowerMockito.whenNew(URL.class).withArguments(any()).thenReturn(u);
		HttpURLConnection huc = PowerMockito.mock(HttpURLConnection.class);
		PowerMockito.when(u.openConnection()).thenReturn(huc);
		PowerMockito.when(huc.getResponseCode()).thenReturn(200);

		when(resultSet.getString(any(String.class))).thenReturn("10.225.63.56");
		when(resultSet.getInt(any(String.class))).thenReturn(0).thenReturn(1).thenReturn(5).thenReturn(4).thenReturn(1)
				.thenReturn(2);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));
		when(resultSet.getLong(any(String.class))).thenReturn(2121627163136136136L);
		Map<String, Object> discoveryDetailsActual = discoveryDetails.receiveRelayDiscoveryDetails(discoveryJarDetailsVO, validationInfoVO);
		assertNotNull(discoveryDetailsActual);
		
		verify(portalDatabaseEngine, times(27)).getConnection();
		verify(connection, times(7)).executeQuery(any(QueryVO.class));
		verify(connection, times(3)).executeUpdate(any(QueryVO.class));
	}

	@Test
	public void testReceiveRelayDiscoveryDetailsWhenValidInfoVoIsNull() throws Exception {
		DiscoveryJarDetailsVO discoveryJarDetailsVO = populateDiscoveryJarDetails();
		ValidationInfoVO validationInfoVO = populateValidationInfoVO();
		when(resultSet.next()).thenReturn(false);

		when(resultSet.getString(any(String.class))).thenReturn("10.225.63.56");
		when(resultSet.getInt(any(String.class))).thenReturn(0).thenReturn(1).thenReturn(5).thenReturn(0).thenReturn(1)
				.thenReturn(2);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));
		Map<String, Object> discoveryDetailsActual = discoveryDetails.receiveRelayDiscoveryDetails(discoveryJarDetailsVO, validationInfoVO);
		assertNotNull(discoveryDetailsActual);
		
		verify(portalDatabaseEngine, times(2)).getConnection();
		verify(connection, times(1)).executeQuery(any(QueryVO.class));		
	}

	@Test(expected = Exception.class)
	public void testReceiveRelayDiscoveryDetailsWhenDeviceIsNull() throws Exception {
		DiscoveryJarDetailsVO discoveryJarDetailsVO = new DiscoveryJarDetailsVO();
		ValidationInfoVO validationInfoVO = new ValidationInfoVO();
		discoveryDetails.receiveRelayDiscoveryDetails(discoveryJarDetailsVO, validationInfoVO);
	}	

	@Test
	public void testCanConnectNewWhenDeviceNameUnavailableForWANDiffDeviceId() throws Exception {

		when(connection.executeQuery(any(QueryVO.class))).thenReturn(resultSet);
		when(resultSet.next()).thenReturn(true).thenReturn(false);

		when(resultSet.getString(any(String.class))).thenReturn("deviceId1");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		BDDMockito.given(Client.callServer(any(), any(), any(), any(), any(), any(), any(), any()))
				.willReturn("deviceId1").willReturn("deviceId");
		discoveryDetails.canConnectNew("ipAddress", "port", "deviceId", "", "port5", "backCallerRestPath");
		
		verify(portalDatabaseEngine, times(6)).getConnection();
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
	}

	@Test
	public void testCanConnectNewWhenDeviceNameUnavailableAndRestPathEmptyForWANDiffDeviceId() throws Exception {

		when(connection.executeQuery(any(QueryVO.class))).thenReturn(resultSet);
		when(resultSet.next()).thenReturn(true).thenReturn(false);

		when(resultSet.getString(any(String.class))).thenReturn("deviceId1");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		BDDMockito
				.given(Client.callServer(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
						Mockito.anyString(), Mockito.anyString(), Mockito.anyMap(), Mockito.anyObject(),
						Mockito.anyString(), Mockito.anyInt(), Mockito.anyInt(), Mockito.anyInt()))
				.willReturn("deviceId1").willReturn("deviceId");
		discoveryDetails.canConnectNew("ipAddress", "port", "deviceId", "", "port5", "");
		
		verify(portalDatabaseEngine, times(6)).getConnection();
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
	}

	@Test
	public void testCanConnectNewWhenDeviceNameUnavailableForWANDiffResponse() throws Exception {

		when(connection.executeQuery(any(QueryVO.class))).thenReturn(resultSet);
		when(resultSet.next()).thenReturn(true).thenReturn(false);

		when(resultSet.getString(any(String.class))).thenReturn("deviceId");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		BDDMockito.given(Client.callServer(any(), any(), any(), any(), any(), any(), any(), any()))
				.willReturn("deviceId1");
		discoveryDetails.canConnectNew("ipAddress", "port", "deviceId", "", "port5", "backCallerRestPath");
		
		verify(portalDatabaseEngine, times(3)).getConnection();
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
	}

	@Test
	public void testCanConnectNewWhenDeviceNameUnavailableForWAN() throws Exception {

		when(connection.executeQuery(any(QueryVO.class))).thenReturn(resultSet);
		when(resultSet.next()).thenReturn(true).thenReturn(false);

		when(resultSet.getString(any(String.class))).thenReturn("deviceId");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		BDDMockito.given(Client.callServer(any(), any(), any(), any(), any(), any(), any(), any()))
				.willReturn("deviceId");
		discoveryDetails.canConnectNew("ipAddress", "port", "deviceId", "", "port5", "backCallerRestPath");
		
		verify(portalDatabaseEngine, times(6)).getConnection();
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
	}

	@Test
	public void testCanConnectNewWhenDeviceNameUnavailableAndRestPathEmptyForWAN() throws Exception {

		when(connection.executeQuery(any(QueryVO.class))).thenReturn(resultSet);
		when(resultSet.next()).thenReturn(true).thenReturn(false);

		when(resultSet.getString(any(String.class))).thenReturn("deviceId");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		BDDMockito
				.given(Client.callServer(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
						Mockito.anyString(), Mockito.anyString(), Mockito.anyMap(), Mockito.anyObject(),
						Mockito.anyString(), Mockito.anyInt(), Mockito.anyInt(), Mockito.anyInt()))
				.willReturn("deviceId");
		discoveryDetails.canConnectNew("ipAddress", "port", "deviceId", "", "port5", "");
		
		verify(portalDatabaseEngine, times(6)).getConnection();
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
	}

	@Test
	public void testCanConnectNewWhenDeviceNameUnavailableDiffResponse() throws Exception {

		when(connection.executeQuery(any(QueryVO.class))).thenReturn(resultSet);
		when(resultSet.next()).thenReturn(true).thenReturn(false);

		when(resultSet.getString(any(String.class))).thenReturn("deviceId");
		when(resultSet.getInt(any(String.class))).thenReturn(4);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		BDDMockito.given(Client.callServer(any(), any(), any(), any(), any(), any(), any(), any()))
				.willReturn("deviceId1").willReturn("deviceId");
		discoveryDetails.canConnectNew("ipAddress", "port", "deviceId", "", "port5", "backCallerRestPath");
		
		verify(portalDatabaseEngine, times(9)).getConnection();
		verify(connection, times(2)).executeQuery(any(QueryVO.class));
	}

	@Test
	public void testCanConnectNewWhenDeviceNameUnavailableAndRestPathEmptyDiffResponse() throws Exception {

		when(connection.executeQuery(any(QueryVO.class))).thenReturn(resultSet);
		when(resultSet.next()).thenReturn(true).thenReturn(false);

		when(resultSet.getString(any(String.class))).thenReturn("deviceId");
		when(resultSet.getInt(any(String.class))).thenReturn(4);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		BDDMockito
				.given(Client.callServer(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
						Mockito.anyString(), Mockito.anyString(), Mockito.anyMap(), Mockito.anyObject(),
						Mockito.anyString(), Mockito.anyInt(), Mockito.anyInt(), Mockito.anyInt()))
				.willReturn("deviceId1").willReturn("deviceId");
		discoveryDetails.canConnectNew("ipAddress", "port", "deviceId", "", "port5", "");
		
		verify(portalDatabaseEngine, times(9)).getConnection();
		verify(connection, times(2)).executeQuery(any(QueryVO.class));
	}

	@Test
	public void testCanConnectNewWhenDeviceNameUnavailable() throws Exception {

		when(connection.executeQuery(any(QueryVO.class))).thenReturn(resultSet);
		when(resultSet.next()).thenReturn(true).thenReturn(false);

		when(resultSet.getString(any(String.class))).thenReturn("deviceId");
		when(resultSet.getInt(any(String.class))).thenReturn(4);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		BDDMockito.given(Client.callServer(any(), any(), any(), any(), any(), any(), any(), any()))
				.willReturn("deviceId");
		discoveryDetails.canConnectNew("ipAddress", "port", "deviceId", "", "port5", "backCallerRestPath");
		
		verify(portalDatabaseEngine, times(6)).getConnection();
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
	}

	@Test
	public void testCanConnectNewWhenDeviceNameUnavailableAndRestPathEmpty() throws Exception {

		when(connection.executeQuery(any(QueryVO.class))).thenReturn(resultSet);
		when(resultSet.next()).thenReturn(true).thenReturn(false);

		when(resultSet.getString(any(String.class))).thenReturn("deviceId");
		when(resultSet.getInt(any(String.class))).thenReturn(4);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		BDDMockito
				.given(Client.callServer(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
						Mockito.anyString(), Mockito.anyString(), Mockito.anyMap(), Mockito.anyObject(),
						Mockito.anyString(), Mockito.anyInt(), Mockito.anyInt(), Mockito.anyInt()))
				.willReturn("deviceId");
		discoveryDetails.canConnectNew("ipAddress", "port", "deviceId", "", "port5", "");
		
		
		verify(portalDatabaseEngine, times(6)).getConnection();
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
	}

	@Test
	public void testCanConnectNew() throws Exception {
		BDDMockito.given(Client.callServer(any(), any(), any(), any(), any(), any(), any(), any()))
				.willReturn("deviceId");
		discoveryDetails.canConnectNew("ipAddress", "port", "deviceId1", "deviceName", "port5", "backCallerRestPath");
	}
	
	@Test
	public void testCanConnectNewbackCallerRestPathEmpty() throws Exception {
		BDDMockito.given(Client.callServer(any(), any(), any(), any(), any(), any(), any(), any()))
				.willReturn("deviceId");
		discoveryDetails.canConnectNew("ipAddress", "port", "deviceId1", "deviceName", "port5", "null");
	}

	@Test
	public void testCanConnectNewWhenBackCallerRestPathIsNull() throws Exception {
		BDDMockito
				.given(Client.callServer(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
						Mockito.anyString(), Mockito.anyString(), Mockito.anyMap(), Mockito.anyObject(),
						Mockito.anyString(), Mockito.anyInt(), Mockito.anyInt(), Mockito.anyInt()))
				.willReturn("deviceId");
		discoveryDetails.canConnectNew("ipAddress", "port", "deviceId", "deviceName", "port5", "");		
	}

	@Test
	public void testSetRURLDetails() throws Exception {
		BDDMockito.given(Client.callServer(any(), any(), any(), any(), any(), any(), any(), any()))
				.willReturn("deviceId");
		discoveryDetails.setRURLDetails("deviceId", "port", "deviceId", "true", "backCallerRestPath");
		
		verify(portalDatabaseEngine, times(3)).getConnection();
		verify(connection, times(1)).executeUpdate(any(QueryVO.class));
	}

	@Test
	public void testSetRURLDetailsIsCheckFalse() throws Exception {
		discoveryDetails.setRURLDetails("deviceId", "port", "deviceId", "false", "backCallerRestPath");
		
		verify(portalDatabaseEngine, times(3)).getConnection();
		verify(connection, times(1)).executeUpdate(any(QueryVO.class));
	}

	@Test
	public void testSetRURLDetailsToTriggerLoop() throws Exception {
		Map<String, Object> expectedMap = new HashMap<>();
		expectedMap.put("Status", "Failure");
		expectedMap.put("ErrorMessage", "Can't Connect");
		BDDMockito.given(Client.callServer(any(), any(), any(), any(), any(), any(), any(), any()))
				.willReturn("deviceId1");
		Map<String, Object> actualMap = discoveryDetails.setRURLDetails("deviceId", "port", "deviceId", "true", "backCallerRestPath");
		assertTrue(expectedMap.equals(actualMap));
	}

	@Test
	public void testSetRURLDetailsBackCallerRestPathIsNull() throws Exception {
		Map<String, Object> expectedMap = new HashMap<>();
		expectedMap.put("Status", SUCCESS);
		expectedMap.put("ConnectionIP", "https://deviceId:port/pb/");
		
		BDDMockito
				.given(Client.callServer(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
						Mockito.anyString(), Mockito.anyString(), Mockito.anyMap(), Mockito.anyObject(),
						Mockito.anyString(), Mockito.anyInt(), Mockito.anyInt(), Mockito.anyInt()))
				.willReturn("deviceId");
		Map<String, Object> actualMap = discoveryDetails.setRURLDetails("deviceId", "port", "deviceId", "true", "");
		assertTrue(expectedMap.equals(actualMap));
	}

	@Test
	public void testCheckRestConnectNew() throws Exception {
		Map<String, Object> expectedMap = new HashMap<>();
		expectedMap.put("Status", SUCCESS);
		
		BDDMockito.given(Client.callServer(any(), any(), any(), any(), any(), any(), any(), any()))
				.willReturn("deviceId");
		Map<String, Object> actualMap = discoveryDetails.checkRestConnectNew("ipAddress", "port", "deviceId", "backCallerRestPath");
		assertTrue(expectedMap.equals(actualMap));
	}

	@Test
	public void testCheckRestConnectNewBackCallerRestPathIsNull() throws Exception {
		Map<String, Object> expectedMap = new HashMap<>();
		expectedMap.put("Status", SUCCESS);
		BDDMockito
				.given(Client.callServer(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
						Mockito.anyString(), Mockito.anyString(), Mockito.anyMap(), Mockito.anyObject(),
						Mockito.anyString(), Mockito.anyInt(), Mockito.anyInt(), Mockito.anyInt()))
				.willReturn("deviceId");
		Map<String, Object> actualMap = discoveryDetails.checkRestConnectNew("ipAddress", "port", "deviceId", "");
		assertTrue(expectedMap.equals(actualMap));
	}

	@Test
	public void testCheckRestConnectNewToTriggerLoop() throws Exception {
		Map<String, Object> expectedMap = new HashMap<>();
		expectedMap.put("Status", "Failure");
		BDDMockito.given(Client.callServer(any(), any(), any(), any(), any(), any(), any(), any()))
				.willReturn("deviceId1");
		Map<String, Object> actualMap = discoveryDetails.checkRestConnectNew("ipAddress", "port", "deviceId", "backCallerRestPath");		
		assertTrue(expectedMap.equals(actualMap));
	}

	@Test
	public void testGetDiscoveryDetailsByName() throws Exception {
		when(resultSet.next()).thenReturn(true).thenReturn(false);

		when(resultSet.getString(any(String.class))).thenReturn("deviceId");
		when(resultSet.getInt(any(String.class))).thenReturn(4);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));
		DiscoveryDetailsVO discoveryDetailsVO = discoveryDetails.getDiscoveryDetailsByName("deviceName");
		
	}
	
	@Test(expected = Exception.class)
	public void testGetDiscoveryDetailsByNameWhenDeviceVoIsNull() throws Exception {
		discoveryDetails.getDiscoveryDetailsByName("deviceName");
	}
	
	@Test
	public void testGetClientIP() throws Exception {
		HttpServletRequest httpRequest = PowerMockito.mock(HttpServletRequest.class);
		when(httpRequest.getHeader(any(String.class))).thenReturn("test");
		when(httpRequest.getContextPath()).thenReturn("test");
		discoveryDetails.getClientIP(httpRequest);
	}
	
	@Test
	public void testSetConnectURLRelay() throws Exception {
		DiscoveryDetailsVO discoveryDetailsVO = populateDiscoveryDetails();
		
		discoveryDetails.setConnectURLRelay(discoveryDetailsVO.getsDeviceID(), NetworkTypeEnum.DMZ,
				discoveryDetailsVO.getsLocalIPAddress(), discoveryDetailsVO.getsChatInputChannel(),
				discoveryDetailsVO.getsChatOutputChannel(), discoveryDetailsVO.getsChatSubscriptionChannel(),
				discoveryDetailsVO.getsNodeCommunicationPort(), discoveryDetailsVO.getsOpenStackPort(),
				discoveryDetailsVO.getsTomcatPort(), discoveryDetailsVO.getsPort1(), discoveryDetailsVO.getsPort2(),
				discoveryDetailsVO.getsPort3(), discoveryDetailsVO.getsPort4(), discoveryDetailsVO.getsPort5(),
				discoveryDetailsVO.getsRURLTomcatPort(), discoveryDetailsVO.getsRAddress(),
				discoveryDetailsVO.getsRelayServerID());
	}

	private ValidationInfoVO populateValidationInfoVO() {
		ValidationInfoVO validationInfoVO = new ValidationInfoVO();
		validationInfoVO.setsMACAddress("10.225.63.56");
		validationInfoVO.setnStatus(1);
		validationInfoVO.setsInternetAddress("10.225.63.56,10.225.63.56,10.225.63.56");
		validationInfoVO.setsGUID("10.225.63.56");
		validationInfoVO.setnTimestamp(2121627163136136136L);
		validationInfoVO.setEmail("test@email.com");
		validationInfoVO.setHostName("hostName");
		validationInfoVO.setSwLicense("swLicence");
		validationInfoVO.setHwConfig("HWConfig");
		return validationInfoVO;
	}

	private DiscoveryDetailsVO populateDiscoveryDetails() {
		DiscoveryDetailsVO discoveryDetailsVO = new DiscoveryDetailsVO();
		discoveryDetailsVO.setsDeviceID("deviceId");
		discoveryDetailsVO.setsIPAddress("10.225.63.56,10.225.63.56,10.225.63.56");
		discoveryDetailsVO.setsLocalIPAddress("10.225.63.56");
		discoveryDetailsVO.setsChatInputChannel("chatInputChannel");
		discoveryDetailsVO.setsChatOutputChannel("chatOutputChannel");
		discoveryDetailsVO.setsChatSubscriptionChannel("chatSubscriptionChannel");
		discoveryDetailsVO.setsNodeCommunicationPort("nodeCommunicationPort");
		discoveryDetailsVO.setsOpenStackPort("openStackPort");
		discoveryDetailsVO.setsTomcatPort("tomcatPort");
		discoveryDetailsVO.setsPort1("port1");
		discoveryDetailsVO.setsPort2("port2");
		discoveryDetailsVO.setsPort3("port3");
		discoveryDetailsVO.setsPort4("port4");
		discoveryDetailsVO.setsPort5("port5");
		discoveryDetailsVO.setsRURLTomcatPort("rURLTomcatPort");
		discoveryDetailsVO.setsRAddress("rAddress");
		discoveryDetailsVO.setnStatus(1);
		discoveryDetailsVO.setsRelayServerID("relayServerID");

		discoveryDetailsVO.setsNetworkType(NetworkTypeEnum.RelayNR);
		return discoveryDetailsVO;
	}

	private DiscoveryJarDetailsVO populateDiscoveryJarDetails() {
		DiscoveryJarDetailsVO discoveryJarDetailsVO = new DiscoveryJarDetailsVO();
		discoveryJarDetailsVO.setsMACAddress("10.225.63.56,10.225.63.56,10.225.63.56");
		discoveryJarDetailsVO.setsDeviceId("deviceID");
		discoveryJarDetailsVO.setsIPAddress("10.225.63.56,10.225.63.56,10.225.63.56");
		discoveryJarDetailsVO.setsLocalIPAddress("10.225.63.56");
		discoveryJarDetailsVO.setsChatInputChannel("chatInputChannel");
		discoveryJarDetailsVO.setsChatOutputChannel("chatOutputChannel");
		discoveryJarDetailsVO.setsChatSubscriptionChannel("chatSubscriptionChannel");
		discoveryJarDetailsVO.setsNodeCommunicationPort("nodeCommunicationPort");
		discoveryJarDetailsVO.setsOpenStackPort("openStackPort");
		discoveryJarDetailsVO.setsTomcatPort("tomcatPort");
		discoveryJarDetailsVO.setsPort1("port1");
		discoveryJarDetailsVO.setsPort2("port2");
		discoveryJarDetailsVO.setsPort3("port3");
		discoveryJarDetailsVO.setsPort4("port4");
		discoveryJarDetailsVO.setsPort5("port5");
		discoveryJarDetailsVO.setsRURLTomcatPort("rURLTomcatPort");
		discoveryJarDetailsVO.setsRAddress("rAddress");
		discoveryJarDetailsVO.setnStatus(1);
		discoveryJarDetailsVO.setsRelayServerID("relayServerID");

		discoveryJarDetailsVO.setsNetworkType(NetworkTypeEnum.RelayNR);
		return discoveryJarDetailsVO;
	}

	private String mockSetDiscoveryDetails() throws SQLException, Exception {
		DiscoveryDetailsVO discoveryDetailsVO = populateDiscoveryDetails();
		when(resultSet.next()).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(true).thenReturn(true)
				.thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("deviceId");
		when(resultSet.getInt(any(String.class))).thenReturn(0).thenReturn(3).thenReturn(0);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));
		String value = discoveryDetails.setDiscoveryDetails(discoveryDetailsVO.getsDeviceID(), discoveryDetailsVO.getsIPAddress(),
				discoveryDetailsVO.getsLocalIPAddress(), discoveryDetailsVO.getsChatInputChannel(),
				discoveryDetailsVO.getsChatOutputChannel(), discoveryDetailsVO.getsChatSubscriptionChannel(),
				discoveryDetailsVO.getsNodeCommunicationPort(), discoveryDetailsVO.getsOpenStackPort(),
				discoveryDetailsVO.getsTomcatPort(), discoveryDetailsVO.getsPort1(), discoveryDetailsVO.getsPort2(),
				discoveryDetailsVO.getsPort3(), discoveryDetailsVO.getsPort4(), discoveryDetailsVO.getsPort5(),
				discoveryDetailsVO.getsRURLTomcatPort(), discoveryDetailsVO.getsRAddress(),
				discoveryDetailsVO.getnStatus(), discoveryDetailsVO.getsRelayServerID(),
				discoveryDetailsVO.getsNetworkType());
		return value;
	}

	private String setDiscoveryDetailsForWan() throws SQLException, Exception {
		DiscoveryDetailsVO discoveryDetailsVO = populateDiscoveryDetails();
		when(resultSet.next()).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(true).thenReturn(true)
				.thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("10.225.63.57,10.225.63.57");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));
		String value = discoveryDetails.setDiscoveryDetails(discoveryDetailsVO.getsDeviceID(), discoveryDetailsVO.getsIPAddress(),
				discoveryDetailsVO.getsLocalIPAddress(), discoveryDetailsVO.getsChatInputChannel(),
				discoveryDetailsVO.getsChatOutputChannel(), discoveryDetailsVO.getsChatSubscriptionChannel(),
				discoveryDetailsVO.getsNodeCommunicationPort(), discoveryDetailsVO.getsOpenStackPort(),
				discoveryDetailsVO.getsTomcatPort(), discoveryDetailsVO.getsPort1(), discoveryDetailsVO.getsPort2(),
				discoveryDetailsVO.getsPort3(), discoveryDetailsVO.getsPort4(), discoveryDetailsVO.getsPort5(),
				discoveryDetailsVO.getsRURLTomcatPort(), discoveryDetailsVO.getsRAddress(), 0,
				discoveryDetailsVO.getsRelayServerID(), NetworkTypeEnum.WAN);
		return value;
	}

	/*private void updateDeviceNameRecords() throws SQLException {
		DeviceVO deviceVO = new DeviceVO();
		deviceVO.setDeviceId("deviceid");
		deviceVO.setClusterId("clusterId");
		deviceVO.setDeviceName("deviceName");
		ArrayList<DeviceNodeVO> listOfDeviceNodes = new ArrayList<>();
		DeviceNodeVO deviceNodeVo = new DeviceNodeVO();
		deviceNodeVo.setHostName("hostname");
		deviceNodeVo.setMacAddress("macaddress");
		deviceNodeVo.setDeviceRole(NodeType.MASTER);
		deviceNodeVo.setDeviceState(StateEnum.Active);

		DiscoveryDetailsVO discoveryDetailsVO = populateDiscoveryDetails();
		deviceNodeVo.setDiscoveryDetailsVO(discoveryDetailsVO);
		listOfDeviceNodes.add(deviceNodeVo);
		deviceVO.setNodes(listOfDeviceNodes);
		deviceVO.setNodeHostName("hostname");

		//discoveryDetails.updateDeviceNameRecords(deviceVO, "updatedDeviceName");
	}*/

}
