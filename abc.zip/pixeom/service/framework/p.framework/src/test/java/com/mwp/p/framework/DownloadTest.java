package com.mwp.p.framework;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.mockStatic;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.BDDMockito;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.classloader.annotations.SuppressStaticInitializationFor;
import org.powermock.modules.junit4.PowerMockRunner;

import com.mwp.common.CredProvider;
import com.mwp.common.GCSSignUrl;
import com.mwp.common.constant.Constant;
import com.mwp.common.vo.QueryVO;
import com.mwp.db.Interface.IConnection;
import com.mwp.p.common.Constants;
import com.mwp.p.common.enums.ResourceType;
import com.mwp.p.common.vo.DownloadResourceVO;
import com.mwp.p.common.vo.DownloadVO;
import com.mwp.p.dal.engine.PortalDatabaseEngine;
import com.pa.crypto.FileEncryptionDecryption;
import com.pa.crypto.StringEncryptionDecryption;

import org.junit.Assert;

@RunWith(PowerMockRunner.class)
@SuppressStaticInitializationFor({ "com.mwp.p.common.Constants", "com.mwp.p.dal.engine.PortalDatabaseEngine" })
@PrepareForTest({ Constant.class, Constants.class, StringEncryptionDecryption.class, PortalDatabaseEngine.class,
	FileEncryptionDecryption.class, GCSSignUrl.class, URL.class})
public class DownloadTest {

	@Mock
	private PortalDatabaseEngine portalDatabaseEngine;

	@Mock
	IConnection connection;

	@Mock
	private ResultSet resultSet;

	@Mock
	private CredProvider credProvider;

	@Mock
	private File file;

	@Mock
	private GCSSignUrl gcsSignUrl;

	@Mock
	private FileInputStream fileInputStream;

	@Mock
	private FileOutputStream fileOutputStream;

	private Download download;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		mockStatic(PortalDatabaseEngine.class);
		mockStatic(StringEncryptionDecryption.class);
		mockStatic(Constant.class);
		mockStatic(Constants.class);
		mockStatic(FileEncryptionDecryption.class);
		mockStatic(GCSSignUrl.class);
		mockStatic(URL.class);
		download = spy(new Download());

		when(PortalDatabaseEngine.getInstance()).thenReturn(portalDatabaseEngine);
		when(portalDatabaseEngine.getConnection()).thenReturn(connection);

		when(connection.executeQuery(any(QueryVO.class))).thenReturn(resultSet);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		BDDMockito.given(StringEncryptionDecryption.decrypt(any(), any())).willReturn("test");
		BDDMockito.given(StringEncryptionDecryption.encrypt(any(), any())).willReturn("test");

		BDDMockito.given(StringEncryptionDecryption.decrypt(any())).willReturn("test");
		BDDMockito.given(StringEncryptionDecryption.encrypt(any())).willReturn("test");

		PowerMockito.whenNew(CredProvider.class).withNoArguments().thenReturn(credProvider);
	}

	@After
	public void tearDown() {
		download = null;
	}

	@Test
	public void testGetUrl() throws Exception {
		//when(connection.executeUpdate(any(String.class))).thenReturn(1);
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("{\"isExternalDownload\": true\"\"}");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));
		PowerMockito.doReturn(file).when(download).buildFile(any());
		when(file.exists()).thenReturn(true);
		String path = download.getUrl("resourceId", "password");
		verify(portalDatabaseEngine, times(3)).getConnection();
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(2)).next();
		verify(resultSet, times(2)).getInt(any(String.class));
		verify(resultSet, times(2)).getString(any(String.class));
		Assert.assertNotNull(path);
	}

	@Test
	public void testGetUrlWithoutPassword() throws Exception {
//		when(connection.executeUpdate(any(String.class))).thenReturn(1);
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("{\"isExternalDownload\": true\"\"}");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));
		PowerMockito.doReturn(file).when(download).buildFile(any());
		when(file.exists()).thenReturn(true);
		download.getUrl("resourceId");
		verify(portalDatabaseEngine, times(3)).getConnection();
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(2)).next();
		verify(resultSet, times(2)).getInt(any(String.class));
		verify(resultSet, times(2)).getString(any(String.class));
	}

	@Test(expected = Exception.class)
	public void testGetUrlPwdRequired() throws Exception {
//		when(connection.executeUpdate(any(String.class))).thenReturn(1);
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("{\"pwdRequired\": \"true\"}");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));
		PowerMockito.doReturn(file).when(download).buildFile(any());
		PowerMockito.doReturn(credProvider).when(download).buildCredProvider();
		when(credProvider.getEcnKey()).thenReturn("test");
		when(file.exists()).thenReturn(true);
		download.getUrl("resourceId", "password");
	}

	@Test(expected = Exception.class)
	public void testGetUrlExternalDownloadNotFound() throws Exception {
//		when(connection.executeUpdate(any(String.class))).thenReturn(1);
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("{\"pwdRequired\": \"false\"}");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));
		PowerMockito.doReturn(file).when(download).buildFile(any());
		when(file.exists()).thenReturn(false);
		download.getUrl("resourceId", "password");
	}

	@Test
	public void testGetUrlExternalDownloadTrue() throws Exception {
//		when(connection.executeUpdate(any(String.class))).thenReturn(1);
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("{\"isExternalDownload\": \"true\"}");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));
		PowerMockito.doReturn(file).when(download).buildFile(any());
		PowerMockito.doReturn(gcsSignUrl).when(download).buildGCSSignUrl();
		URL url = PowerMockito.mock(URL.class);
		when(gcsSignUrl.getGCSSignUrl(any(String.class), any(String.class), any(String.class))).thenReturn(url);

		when(file.exists()).thenReturn(true);
		download.getUrl("resourceId", "password");
		verify(portalDatabaseEngine, times(3)).getConnection();
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(2)).next();
		verify(resultSet, times(2)).getInt(any(String.class));
		verify(resultSet, times(2)).getString(any(String.class));
	}

	@Test
	public void testGetFunctionUrl() throws Exception {
//		when(connection.executeUpdate(any(String.class))).thenReturn(1);
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("{\"isExternalDownload\": true\"\"}");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		PowerMockito.doReturn(credProvider).when(download).buildCredProvider();
		when(credProvider.getEcnKey()).thenReturn("test");
		PowerMockito.doNothing().when(FileEncryptionDecryption.class, "Decrypt_File", Mockito.any(String.class),
				Mockito.any(String.class), Mockito.any(String.class));

		PowerMockito.doReturn(file).when(download).buildFile(any());
		when(file.exists()).thenReturn(true);
		download.getFunctionUrl("functionId", "functionVersionId");
	}

	@Test(expected = Exception.class)
	public void testGetFunctionUrlNotFound() throws Exception {
//		when(connection.executeUpdate(any(String.class))).thenReturn(1);
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("{\"isExternalDownload\": true\"\"}");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		PowerMockito.doReturn(credProvider).when(download).buildCredProvider();
		when(credProvider.getEcnKey()).thenReturn("test");
		PowerMockito.doNothing().when(FileEncryptionDecryption.class, "Decrypt_File", Mockito.any(String.class),
				Mockito.any(String.class), Mockito.any(String.class));

		PowerMockito.doReturn(file).when(download).buildFile(any());
		when(file.exists()).thenReturn(false);
		download.getFunctionUrl("functionId", "functionVersionId");
	}

	@Test
	public void testdownloadFile() throws Exception {
		DownloadVO downloadVO = new DownloadVO("secureToken", System.currentTimeMillis() + 10000);
		HashMap<String, DownloadVO> hashMap = new HashMap<>();
		hashMap.put("secureToken", downloadVO);
		BDDMockito.given(Constants.getDownloadTokens()).willReturn(hashMap);

		download.downloadFile("secureToken");
	}

	@Test(expected = Exception.class)
	public void testdownloadFileUNAUTHORIZED() throws Exception {
		DownloadVO downloadVO = new DownloadVO("secureToken", System.currentTimeMillis() - 10000);
		HashMap<String, DownloadVO> hashMap = new HashMap<>();
		hashMap.put("secureToken", downloadVO);
		BDDMockito.given(Constants.getDownloadTokens()).willReturn(hashMap);
		download.downloadFile("secureToken");
	}

	@Test
	public void testCleanUpTokens() throws Exception {
		DownloadVO downloadVO = new DownloadVO("secureToken", System.currentTimeMillis() - 10000);
		HashMap<String, DownloadVO> hashMap = new HashMap<>();
		hashMap.put("secureToken", downloadVO);
		BDDMockito.given(Constants.getDownloadTokens()).willReturn(hashMap);

		PowerMockito.doReturn(file).when(download).buildFile(any());
		when(file.exists()).thenReturn(false);
		when(file.getParentFile()).thenReturn(file);
		download.cleanUpTokens();
	}

	@Test
	public void testAdd() throws Exception {
//		when(connection.executeUpdate(any(String.class))).thenReturn(1);
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("{\"isExternalDownload\": true\"\"}");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		PowerMockito.doReturn(credProvider).when(download).buildCredProvider();
		when(credProvider.getEcnKey()).thenReturn("test");
		PowerMockito.doNothing().when(FileEncryptionDecryption.class, "Decrypt_File", Mockito.any(String.class),
				Mockito.any(String.class), Mockito.any(String.class));

		PowerMockito.doReturn(file).when(download).buildFile(any());
		when(file.exists()).thenReturn(true);

		DownloadResourceVO resourceVO = new DownloadResourceVO();
		resourceVO.setResourceType(ResourceType.document);
		DownloadResourceVO drVO = download.add(resourceVO);
		verify(portalDatabaseEngine, times(6)).getConnection();
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
		verify(connection, times(1)).executeUpdate(any(QueryVO.class));
		verify(resultSet, times(2)).next();
		verify(resultSet, times(2)).getInt(any(String.class));
		verify(resultSet, times(2)).getString(any(String.class));
		Assert.assertEquals(1, drVO.getSortOrder());
	}

	@Test
	public void testEdit() throws Exception {
		when(connection.executeUpdate(any(String.class))).thenReturn(1);
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("{\"isExternalDownload\": true\"\"}");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		PowerMockito.doReturn(credProvider).when(download).buildCredProvider();
		when(credProvider.getEcnKey()).thenReturn("test");
		PowerMockito.doNothing().when(FileEncryptionDecryption.class, "Decrypt_File", Mockito.any(String.class),
				Mockito.any(String.class), Mockito.any(String.class));

		PowerMockito.doReturn(file).when(download).buildFile(any());
		when(file.exists()).thenReturn(true);

		DownloadResourceVO resourceVO = new DownloadResourceVO();
		resourceVO.setResourceType(ResourceType.document);
		DownloadResourceVO drVO = download.edit(resourceVO);
		verify(portalDatabaseEngine, times(6)).getConnection();
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
		verify(connection, times(1)).executeUpdate(any(QueryVO.class));
		verify(resultSet, times(2)).next();
		verify(resultSet, times(2)).getInt(any(String.class));
		verify(resultSet, times(2)).getString(any(String.class));
		Assert.assertEquals(1, drVO.getSortOrder());
	}

	@Test
	public void testUpdateSortOrder() throws Exception {
		when(connection.executeUpdate(any(String.class))).thenReturn(1);
		when(resultSet.next()).thenReturn(true).thenReturn(false);

		Map<String, Integer> idOrderMap = new HashMap<>();
		idOrderMap.put("abcd", 2);
		idOrderMap.put("1234", 1);
		download.updateSortOrder(idOrderMap);
		verify(portalDatabaseEngine, times(2)).getConnection();
		verify(connection, times(1)).executeUpdate(any(QueryVO.class));
	}

	@Test
	public void testDelete() throws Exception {
//		when(connection.executeUpdate(any(String.class))).thenReturn(1);
		when(resultSet.next()).thenReturn(true).thenReturn(false);

		download.delete("resourceId");
		verify(portalDatabaseEngine, times(3)).getConnection();
		verify(connection, times(1)).executeUpdate(any(QueryVO.class));
	}

	@Test
	public void testListResouces() throws Exception {
//		when(connection.executeUpdate(any(String.class))).thenReturn(1);
		when(resultSet.next()).thenReturn(true).thenReturn(false);

		List<DownloadResourceVO> listResouces = download.listResouces(ResourceType.document.name());
		verify(portalDatabaseEngine, times(3)).getConnection();
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(2)).next();
		verify(resultSet, times(2)).getInt(any(String.class));
		verify(resultSet, times(2)).getString(any(String.class));
		Assert.assertEquals(1, listResouces.size());
	}

	@Test
	public void testListResoucesInGroups() throws Exception {
//		when(connection.executeUpdate(any(String.class))).thenReturn(1);
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		List<String> groupIds = new ArrayList<>();
		groupIds.add("abcd");
		List<DownloadResourceVO> listResouces = download.listResoucesInGroups(groupIds, ResourceType.document.name());
		Assert.assertEquals(1, listResouces.size());
	}

	@Test
	public void testWriteFile() throws Exception {
//		when(connection.executeUpdate(any(String.class))).thenReturn(1);
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("{\"isExternalDownload\": true\"\"}");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		PowerMockito.doReturn(credProvider).when(download).buildCredProvider();
		when(credProvider.getEcnKey()).thenReturn("test");
		PowerMockito.doNothing().when(FileEncryptionDecryption.class, "Decrypt_File", Mockito.any(String.class),
				Mockito.any(String.class), Mockito.any(String.class));

		PowerMockito.doReturn(file).when(download).buildFile(any());
		when(file.exists()).thenReturn(true);

		Path temp = Files.createTempFile("resource-", ".ext");
		// Files.copy("resource.ext", temp,
		// StandardCopyOption.REPLACE_EXISTING);
		FileInputStream fi = new FileInputStream(temp.toFile());

		// FileInputStream fi = new FileInputStream("abc.txt");
		PowerMockito.doReturn(fi).when(download).buildFileInputStream(any());

		DownloadResourceVO resourceVO = new DownloadResourceVO();
		resourceVO.setResourceType(ResourceType.document);
		HttpServletResponse response = Mockito.mock(HttpServletResponse.class);
		ServletOutputStream servletOutputStreamMock = Mockito.mock(ServletOutputStream.class);
		when(response.getOutputStream()).thenReturn(servletOutputStreamMock);
		PowerMockito.doNothing().when(servletOutputStreamMock).write(any());
		download.writeFile("abcd", response);
	}

	@Test(expected = Exception.class)
	public void testWriteFileNotFound() throws Exception {

		PowerMockito.doReturn(file).when(download).buildFile(any());
		when(file.exists()).thenReturn(false);

		Path temp = Files.createTempFile("resource-", ".ext");
		// Files.copy("resource.ext", temp,
		// StandardCopyOption.REPLACE_EXISTING);
		FileInputStream fi = new FileInputStream(temp.toFile());

		// FileInputStream fi = new FileInputStream("abc.txt");
		PowerMockito.doReturn(fi).when(download).buildFileInputStream(any());

		DownloadResourceVO resourceVO = new DownloadResourceVO();
		resourceVO.setResourceType(ResourceType.document);
		HttpServletResponse response = Mockito.mock(HttpServletResponse.class);
		ServletOutputStream servletOutputStreamMock = Mockito.mock(ServletOutputStream.class);
		when(response.getOutputStream()).thenReturn(servletOutputStreamMock);
		PowerMockito.doNothing().when(servletOutputStreamMock).write(any());
		download.writeFile("abcd", response);
	}

	@Test
	public void testBuildFileInputStream() throws Exception {
		Path temp = Files.createTempFile("resource-", ".ext");
		download.buildFileInputStream(temp.toFile());
	}

	@Test
	public void testBuildFile() throws Exception {
		download.buildFile("abc");
	}
}
