package com.mwp.p.framework;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.mockStatic;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.BDDMockito;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.classloader.annotations.SuppressStaticInitializationFor;
import org.powermock.modules.junit4.PowerMockRunner;

import com.mwp.common.CredProvider;
import com.mwp.common.ImageThumbCreater;
import com.mwp.common.constant.Constant;
import com.mwp.common.vo.AppResourceVO;
import com.mwp.common.yamlparser.YamlParser;
import com.mwp.p.common.PortalCommon;
import com.pa.crypto.FileEncryptionDecryption;
import com.pa.crypto.StringEncryptionDecryption;

@RunWith(PowerMockRunner.class)
@SuppressStaticInitializationFor({ "com.mwp.p.common.Constants", "com.mwp.p.dal.engine.PortalDatabaseEngine" })
@PrepareForTest({ Constant.class, StringEncryptionDecryption.class, YamlParser.class, PortalCommon.class, Files.class, ImageThumbCreater.class,
		FileUtils.class, FileEncryptionDecryption.class})
public class PortalFileUploadTest {

	@Mock
	private CredProvider credProvider;

	@Mock
	private PortalCommon portalCommon;

	@Mock
	private File file;
	
	@Mock
	private ImageThumbCreater imageThumbCreater;

	@Mock
	private FileInputStream fileInputStream;
	
	private PortalFileUpload portalFileUpload;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		mockStatic(StringEncryptionDecryption.class);
		mockStatic(Constant.class);
		mockStatic(PortalCommon.class);
		mockStatic(Files.class);
		mockStatic(FileEncryptionDecryption.class);
		mockStatic(FileUtils.class);
		mockStatic(ImageThumbCreater.class);
		portalFileUpload = spy(new PortalFileUpload());

		when(PortalCommon.getInstance()).thenReturn(portalCommon);
		BDDMockito.given(StringEncryptionDecryption.decrypt(any(), any())).willReturn("test");
		BDDMockito.given(StringEncryptionDecryption.encrypt(any(), any())).willReturn("test");

		BDDMockito.given(StringEncryptionDecryption.decrypt(any())).willReturn("test");
		BDDMockito.given(StringEncryptionDecryption.encrypt(any())).willReturn("test");

		BDDMockito.given(StringEncryptionDecryption.decrypt(any())).willReturn("test");
		PowerMockito.whenNew(CredProvider.class).withNoArguments().thenReturn(credProvider);
		
		PowerMockito.doReturn(credProvider).when(portalFileUpload).buildCredProvider();
		when(credProvider.getEcnKey()).thenReturn("test");		
	}

	@After
	public void tearDown() {
		portalFileUpload = null;
	}

	@Test
	public void testGetBasePath() throws SQLException {
		portalFileUpload.getBasePath("foldername", "uniqueid");
	}

	@Test
	public void testInputStreamToFile() throws Exception {
		PowerMockito.doReturn(file).when(portalFileUpload).buildFile(any());

		when(file.exists()).thenReturn(true);

		PowerMockito.doNothing().when(FileUtils.class, "writeByteArrayToFile", any(), any());

		InputStream inuptStream = new ByteArrayInputStream("exampleString".getBytes(StandardCharsets.UTF_8));
		portalFileUpload.inputStreamToFile(inuptStream, "tempPath");
	}

	@Test
	public void testUploadAppResources() throws Exception {
		PowerMockito.doReturn(file).when(portalFileUpload).buildFile(any());
		PowerMockito.doReturn(fileInputStream).when(portalFileUpload).buildFileInputStream(any());
		PowerMockito.doReturn(1l).when(portalFileUpload).buildFilesCopy(any(), any());
		when(file.exists()).thenReturn(true);
		when(file.getParentFile()).thenReturn(file);
		List<AppResourceVO> resourceVOs = new ArrayList<>();
		AppResourceVO appResource = new AppResourceVO();
		appResource.setFieldName("fieldName");
		resourceVOs.add(appResource);
		Map<String, String> inputstreamHash = new HashMap();
		inputstreamHash.put("fieldName", "fieldName");
		portalFileUpload.uploadAppResources(resourceVOs, inputstreamHash);
	}

	@Test
	public void testUploadAttachmentInline() throws Exception {
		PowerMockito.doReturn(file).when(portalFileUpload).buildFile(any());
		PowerMockito.doReturn(fileInputStream).when(portalFileUpload).buildFileInputStream(any());
		
		when(file.exists()).thenReturn(true);
		when(file.getParentFile()).thenReturn(file);

		List<AppResourceVO> resourceVOs = new ArrayList<>();
		AppResourceVO appResource = new AppResourceVO();
		appResource.setFieldName("fieldName");
		resourceVOs.add(appResource);
		Map<String, String> inputstreamHash = new HashMap();
		inputstreamHash.put("fieldName", "fieldName");
		portalFileUpload.uploadAttachmentInline(inputstreamHash, "tempPath", false, false);
	}
	
	@Test
	public void testUploadAttachmentInlineIsThumbReq() throws Exception {
		PowerMockito.doReturn(file).when(portalFileUpload).buildFile(any());
		PowerMockito.doReturn(fileInputStream).when(portalFileUpload).buildFileInputStream(any());
		PowerMockito.doReturn("test".getBytes()).when(portalFileUpload).buildIOUtilsToByteArray(any());
		PowerMockito.doReturn(1l).when(portalFileUpload).buildFilesCopy(any(), any());
		when(file.exists()).thenReturn(true);
		when(file.getParentFile()).thenReturn(file);
		when(ImageThumbCreater.createThumbnail(any(), any())).thenReturn("test");
		List<AppResourceVO> resourceVOs = new ArrayList<>();
		AppResourceVO appResource = new AppResourceVO();
		appResource.setFieldName("fieldName");
		resourceVOs.add(appResource);
		Map<String, String> inputstreamHash = new HashMap();
		inputstreamHash.put("fieldName", "fieldName");
		portalFileUpload.uploadAttachmentInline(inputstreamHash, "tempPath", false, true);
	}
	
	@Test
	public void testUploadAttachmentInlineDoEncrypt() throws Exception {
		PowerMockito.doReturn(file).when(portalFileUpload).buildFile(any());
		PowerMockito.doReturn(fileInputStream).when(portalFileUpload).buildFileInputStream(any());
		PowerMockito.doNothing().when(FileEncryptionDecryption.class, "Encrypt_File", Mockito.any(String.class),
				Mockito.any(String.class), Mockito.any(String.class));
		when(file.exists()).thenReturn(true);
		when(file.getParentFile()).thenReturn(file);

		List<AppResourceVO> resourceVOs = new ArrayList<>();
		AppResourceVO appResource = new AppResourceVO();
		appResource.setFieldName("fieldName");
		resourceVOs.add(appResource);
		Map<String, String> inputstreamHash = new HashMap();
		inputstreamHash.put("fieldName", "fieldName");
		portalFileUpload.uploadAttachmentInline(inputstreamHash, "tempPath", true, false);
	}
	
	@Test
	public void testCopyFile() throws Exception {
		java.nio.file.Path destination = Paths.get("test" + "file");
		PowerMockito.doReturn(destination).when(portalFileUpload).buildFilesCopyPath(any(), any());
		portalFileUpload.copyFile(new File("test"), new File("test1"));
	}
}
