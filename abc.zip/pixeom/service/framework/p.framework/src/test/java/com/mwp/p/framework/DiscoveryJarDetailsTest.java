package com.mwp.p.framework;

import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.mockStatic;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.BDDMockito;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.classloader.annotations.SuppressStaticInitializationFor;
import org.powermock.modules.junit4.PowerMockRunner;

import com.mwp.common.CredProvider;
import com.mwp.common.constant.Constant;
import com.mwp.common.enums.RelayEnum.NetworkTypeEnum;
import com.mwp.common.vo.DiscoveryJarDetailsVO;
import com.mwp.common.vo.QueryVO;
import com.mwp.db.Interface.IConnection;
import com.mwp.p.common.Constants;
import com.mwp.p.common.enums.DNS_SERVERS;
import com.mwp.p.dal.engine.DiscoveryDetailsEngine;
import com.mwp.p.dal.engine.DiscoveryJarDetailsEngine;
import com.mwp.p.dal.engine.PortalDatabaseEngine;
import com.pa.crypto.StringEncryptionDecryption;

@RunWith(PowerMockRunner.class)
@SuppressStaticInitializationFor({ "com.mwp.p.common.Constants", "com.mwp.p.dal.engine.PortalDatabaseEngine" })
@PrepareForTest({ Constant.class, StringEncryptionDecryption.class, DiscoveryDetailsEngine.class,
		DiscoveryJarDetailsEngine.class, RelayServers.class, ManageDomainName.class, ManageDomainNameGoogle.class,
		ManageDomainNameJD.class, Constants.class })
public class DiscoveryJarDetailsTest {

	@Mock
	private PortalDatabaseEngine portalDatabaseEngine;

	@Mock
	IConnection connection;

	@Mock
	private ResultSet resultSet;

	@Mock
	private CredProvider credProvider;

	@Mock
	private RelayServers relayServers;

	private DiscoveryJarDetails discoveryJarDetails;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		mockStatic(PortalDatabaseEngine.class);
		mockStatic(StringEncryptionDecryption.class);
		mockStatic(Constant.class);
		mockStatic(Constants.class);
		mockStatic(ManageDomainName.class);
		mockStatic(ManageDomainNameGoogle.class);
		mockStatic(ManageDomainNameJD.class);

		discoveryJarDetails = spy(new DiscoveryJarDetails());

		when(PortalDatabaseEngine.getInstance()).thenReturn(portalDatabaseEngine);
		when(portalDatabaseEngine.getConnection()).thenReturn(connection);
		when(connection.executeQuery(any(QueryVO.class))).thenReturn(resultSet);
		PowerMockito.whenNew(CredProvider.class).withNoArguments().thenReturn(credProvider);

		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		BDDMockito.given(StringEncryptionDecryption.decrypt(any(), any())).willReturn("test");
		BDDMockito.given(StringEncryptionDecryption.encrypt(any(), any())).willReturn("test");
	}

	@After
	public void tearDown() throws Exception {
		discoveryJarDetails = null;
		connection = null;
		resultSet = null;
	}

	@Test
	public void testSetDiscoveryDetailsForAzr() throws SQLException {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		when(resultSet.getString(any(String.class))).thenReturn("10.225.63.56");
		when(resultSet.getInt(any(String.class))).thenReturn(4);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		BDDMockito.given(Constants.getDNS_SERVER()).willReturn(DNS_SERVERS.AZR);

		when(resultSet.next()).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false);

		Map<String, Object> actualdiscoveryJarDEtails = discoveryJarDetails.setJARDiscoveryDetails("macAddress",
				"hostName", "iPAddress", "localIPAddress", "chatInputChannel", "chatOutputChannel",
				"chatSubscriptionChannel", "nodeCommunicationPort", "openStackPort", "tomcatPort", "port1", "port2",
				"port3", "port4", "port5", "rURLTomcatPort", "rAddress", 0, "relayServerID", NetworkTypeEnum.RelayPF);

		String actualStatus = actualdiscoveryJarDEtails.get("Status").toString();

		assertTrue(expectedStatus().equals(actualStatus));

		verify(portalDatabaseEngine, times(12)).getConnection();
		verify(connection, times(2)).executeUpdate(any(QueryVO.class));
		verify(connection, times(2)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(4)).next();
		verify(resultSet, times(2)).getInt(any(String.class));
		verify(resultSet, times(15)).getString(any(String.class));

	}

	@Test
	public void testSetDiscoveryDetailsForGOO() throws SQLException {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		when(resultSet.getString(any(String.class))).thenReturn("10.225.63.56");
		when(resultSet.getInt(any(String.class))).thenReturn(4);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		BDDMockito.given(Constants.getDNS_SERVER()).willReturn(DNS_SERVERS.GOO);

		when(resultSet.next()).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false);

		Map<String, Object> actualdiscoveryJarDEtails = discoveryJarDetails.setJARDiscoveryDetails("macAddress",
				"hostName", "iPAddress", "localIPAddress", "chatInputChannel", "chatOutputChannel",
				"chatSubscriptionChannel", "nodeCommunicationPort", "openStackPort", "tomcatPort", "port1", "port2",
				"port3", "port4", "port5", "rURLTomcatPort", "rAddress", 0, "relayServerID", NetworkTypeEnum.RelayPF);

		String actualStatus = actualdiscoveryJarDEtails.get("Status").toString();

		assertTrue(expectedStatus().equals(actualStatus));

		verify(portalDatabaseEngine, times(12)).getConnection();
		verify(connection, times(2)).executeUpdate(any(QueryVO.class));
		verify(connection, times(2)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(4)).next();
		verify(resultSet, times(2)).getInt(any(String.class));
		verify(resultSet, times(15)).getString(any(String.class));

	}

	private String expectedStatus() {
		return Constant.SUCCESS;
	}

	private String expectedFailedStatus() {
		return Constant.FAILURE;
	}

	@Test
	public void testSetDiscoveryDetailsForAMZ() throws Exception {
		PowerMockito.doNothing().when(ManageDomainName.class, "runCommand", any(), any(), any());
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		when(resultSet.getString(any(String.class))).thenReturn("10.225.63.56");
		when(resultSet.getInt(any(String.class))).thenReturn(4);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		BDDMockito.given(Constants.getDNS_SERVER()).willReturn(DNS_SERVERS.AZR);

		when(resultSet.next()).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false);

		Map<String, Object> actualdiscoveryJarDEtails = discoveryJarDetails.setJARDiscoveryDetails("macAddress",
				"hostName", "iPAddress", "localIPAddress", "chatInputChannel", "chatOutputChannel",
				"chatSubscriptionChannel", "nodeCommunicationPort", "openStackPort", "tomcatPort", "port1", "port2",
				"port3", "port4", "port5", "rURLTomcatPort", "rAddress", 1, "relayServerID", NetworkTypeEnum.RelayPF);
		String actualStatus = actualdiscoveryJarDEtails.get("Status").toString();

		assertTrue(expectedStatus().equals(actualStatus));

		verify(portalDatabaseEngine, times(12)).getConnection();
		verify(connection, times(2)).executeUpdate(any(QueryVO.class));
		verify(connection, times(2)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(4)).next();
		verify(resultSet, times(2)).getInt(any(String.class));
		verify(resultSet, times(15)).getString(any(String.class));
	}

	@Test
	public void testSetDiscoveryDetailsForGoogle() throws Exception {
		PowerMockito.doNothing().when(ManageDomainNameGoogle.class, "runCommand", any(), any(), any(), any());
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		when(resultSet.getString(any(String.class))).thenReturn("10.225.63.56");
		when(resultSet.getInt(any(String.class))).thenReturn(4);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		BDDMockito.given(Constants.getDNS_SERVER()).willReturn(DNS_SERVERS.GOO);

		when(resultSet.next()).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false);

		Map<String, Object> actualdiscoveryJarDEtails = discoveryJarDetails.setJARDiscoveryDetails("macAddress",
				"hostName", "iPAddress", "localIPAddress", "chatInputChannel", "chatOutputChannel",
				"chatSubscriptionChannel", "nodeCommunicationPort", "openStackPort", "tomcatPort", "port1", "port2",
				"port3", "port4", "port5", "rURLTomcatPort", "rAddress", 1, "relayServerID", NetworkTypeEnum.RelayPF);

		String actualStatus = actualdiscoveryJarDEtails.get("Status").toString();

		assertTrue(expectedStatus().equals(actualStatus));

		verify(portalDatabaseEngine, times(12)).getConnection();
		verify(connection, times(2)).executeUpdate(any(QueryVO.class));
		verify(connection, times(2)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(4)).next();
		verify(resultSet, times(2)).getInt(any(String.class));
		verify(resultSet, times(15)).getString(any(String.class));
	}

	@Test
	public void testSetDiscoveryDetailsForJD() throws Exception {
		// Constants.DNS_SERVER = DNS_SERVERS.JD;
		PowerMockito.doNothing().when(ManageDomainNameJD.class, "runCommand", any(), any(), any(), any());
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		when(resultSet.getString(any(String.class))).thenReturn("10.225.63.56");
		when(resultSet.getInt(any(String.class))).thenReturn(4);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		BDDMockito.given(Constants.getDNS_SERVER()).willReturn(DNS_SERVERS.JD);
		// BDDMockito.given(Constant.ISDNSRequired()).willReturn(false);

		when(resultSet.next()).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false);

		Map<String, Object> actualdiscoveryJarDEtails = discoveryJarDetails.setJARDiscoveryDetails("macAddress",
				"hostName", "iPAddress", "localIPAddress", "chatInputChannel", "chatOutputChannel",
				"chatSubscriptionChannel",

				"nodeCommunicationPort", "openStackPort", "tomcatPort", "port1", "port2", "port3", "port4", "port5",
				"rURLTomcatPort", "rAddress", 0, "relayServerID", NetworkTypeEnum.RelayPF);

		String actualStatus = actualdiscoveryJarDEtails.get("Status").toString();
		assertTrue(expectedStatus().equals(actualStatus));

		verify(portalDatabaseEngine, times(12)).getConnection();
		verify(connection, times(2)).executeUpdate(any(QueryVO.class));
		verify(connection, times(2)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(4)).next();
		verify(resultSet, times(2)).getInt(any(String.class));
		verify(resultSet, times(15)).getString(any(String.class));
	}

	@Test
	public void testDeleteDiscoveryJarDetails() throws SQLException {
		HashMap<String, Object> expectedResult = new HashMap<>();
		expectedResult.put("Status", "Success");
		expectedResult.put("Details", "macAddress");

		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		Map<String, Object> actualResult = discoveryJarDetails.deleteDiscoveryJarDetails("macAddress");

		String actualStatus = actualResult.get("Status").toString();
		assertTrue(expectedStatus().equals(actualStatus));
		assertTrue(expectedResult.equals(actualResult));
		verify(portalDatabaseEngine, times(3)).getConnection();
		verify(connection, times(1)).executeUpdate(any(QueryVO.class));
	}

	@Test
	public void testSetupRelayJARDiscoveryDetails() throws Exception {
		when(resultSet.next()).thenReturn(false).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("deviceID");
		when(resultSet.getInt(any(String.class))).thenReturn(4);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		BDDMockito.given(Constants.getDNS_SERVER()).willReturn(DNS_SERVERS.AZR);

		PowerMockito.doReturn(relayServers).when(discoveryJarDetails).buildRelayServers();
		when(relayServers.checkIfRelayServerIsAlive(Matchers.anyString(), Matchers.anyBoolean(), Matchers.anyBoolean()))
				.thenReturn(200);

		when(relayServers.setRelayServer(Matchers.anyString(), Matchers.anyString(), Matchers.anyString(),
				Matchers.anyString(), Matchers.anyString(), Matchers.anyString(), Matchers.anyString(),
				Matchers.anyString(), Matchers.anyString(), Matchers.anyString(), Matchers.anyString(),
				Matchers.anyString(), Matchers.anyString(), Matchers.anyString(), Matchers.anyString(),
				Matchers.anyString(), Matchers.anyString(), Matchers.anyString(), Matchers.anyString(),
				Matchers.anyInt(), Matchers.anyBoolean())).thenReturn("");

		Map<String, Object> actualResult = discoveryJarDetails.setupRelayJARDiscoveryDetails("macAddress", 1, "guid",
				100L, "test@email.com", "hostName", "swLicense", "hwConfig", "iPAddress", "localIPAddress",
				"chatInputChannel", "chatOutputChannel", "chatSubscriptionChannel", "nodeCommunicationPort",
				"openStackPort", "tomcatPort", "port1", "port2", "port3", "port4", "port5", "rURLTomcatPort",
				"rAddress", "true", 0);

		String actualStatus = actualResult.get("Status").toString();
		assertTrue(expectedStatus().equals(actualStatus));

	}

	@Test
	public void testSetupRelayJARDiscoveryDetailsFail() throws Exception {
		when(resultSet.next()).thenReturn(true).thenReturn(false).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("deviceID");
		when(resultSet.getInt(any(String.class))).thenReturn(4);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		BDDMockito.given(Constants.getDNS_SERVER()).willReturn(DNS_SERVERS.AZR);

		PowerMockito.doReturn(relayServers).when(discoveryJarDetails).buildRelayServers();
		when(relayServers.checkIfRelayServerIsAlive(Matchers.anyString(), Matchers.anyBoolean(), Matchers.anyBoolean()))
				.thenReturn(500);

		when(relayServers.setRelayServer(Matchers.anyString(), Matchers.anyString(), Matchers.anyString(),
				Matchers.anyString(), Matchers.anyString(), Matchers.anyString(), Matchers.anyString(),
				Matchers.anyString(), Matchers.anyString(), Matchers.anyString(), Matchers.anyString(),
				Matchers.anyString(), Matchers.anyString(), Matchers.anyString(), Matchers.anyString(),
				Matchers.anyString(), Matchers.anyString(), Matchers.anyString(), Matchers.anyString(),
				Matchers.anyInt(), Matchers.anyBoolean())).thenReturn("");

		Map<String, Object> actualResult = discoveryJarDetails.setupRelayJARDiscoveryDetails("macAddress", 1, "guid",
				100L, "test@email.com", "hostName", "swLicense", "hwConfig", "iPAddress", "localIPAddress",
				"chatInputChannel", "chatOutputChannel", "chatSubscriptionChannel", "nodeCommunicationPort",
				"openStackPort", "tomcatPort", "port1", "port2", "port3", "port4", "port5", "rURLTomcatPort",
				"rAddress", "true", 0);

		String actualStatus = actualResult.get("Status").toString();
		assertTrue(expectedStatus().equals(actualStatus));

		verify(portalDatabaseEngine, times(8)).getConnection();
		verify(connection, times(3)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(4)).next();
		verify(resultSet, times(1)).getInt(any(String.class));
		verify(resultSet, times(4)).getString(any(String.class));
	}

	@Test
	public void testSetupRelayJARDiscoveryDetailsWhenErrorIsNotEmpty() throws Exception {
		when(resultSet.next()).thenReturn(false).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("deviceID");
		when(resultSet.getInt(any(String.class))).thenReturn(4);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		PowerMockito.doReturn(relayServers).when(discoveryJarDetails).buildRelayServers();
		when(relayServers.checkIfRelayServerIsAlive(Matchers.anyString(), Matchers.anyBoolean(), Matchers.anyBoolean()))
				.thenReturn(500);

		when(relayServers.setRelayServer(Matchers.anyString(), Matchers.anyString(), Matchers.anyString(),
				Matchers.anyString(), Matchers.anyString(), Matchers.anyString(), Matchers.anyString(),
				Matchers.anyString(), Matchers.anyString(), Matchers.anyString(), Matchers.anyString(),
				Matchers.anyString(), Matchers.anyString(), Matchers.anyString(), Matchers.anyString(),
				Matchers.anyString(), Matchers.anyString(), Matchers.anyString(), Matchers.anyString(),
				Matchers.anyInt(), Matchers.anyBoolean())).thenReturn("test");

		Map<String, Object> actualResult = discoveryJarDetails.setupRelayJARDiscoveryDetails("macAddress", 1, "guid",
				100L, "test@email.com", "hostName", "swLicense", "hwConfig", "iPAddress", "localIPAddress",
				"chatInputChannel", "chatOutputChannel", "chatSubscriptionChannel", "nodeCommunicationPort",
				"openStackPort", "tomcatPort", "port1", "port2", "port3", "port4", "port5", "rURLTomcatPort",
				"rAddress", "true", 0);

		String actualStatus = actualResult.get("Status").toString();
		assertTrue(expectedFailedStatus().equals(actualStatus));

		verify(portalDatabaseEngine, times(8)).getConnection();
		verify(connection, times(3)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(4)).next();
		verify(resultSet, times(3)).getInt(any(String.class));
		verify(resultSet, times(18)).getString(any(String.class));
	}

	@Test
	public void testSetupRelayJARDiscoveryDetailsWhenErrorIsEmpty() throws Exception {
		when(resultSet.next()).thenReturn(false).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("deviceID");
		when(resultSet.getInt(any(String.class))).thenReturn(4);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		PowerMockito.doReturn(relayServers).when(discoveryJarDetails).buildRelayServers();
		when(relayServers.checkIfRelayServerIsAlive(Matchers.anyString(), Matchers.anyBoolean(), Matchers.anyBoolean()))
				.thenReturn(500);

		when(relayServers.setRelayServer(Matchers.anyString(), Matchers.anyString(), Matchers.anyString(),
				Matchers.anyString(), Matchers.anyString(), Matchers.anyString(), Matchers.anyString(),
				Matchers.anyString(), Matchers.anyString(), Matchers.anyString(), Matchers.anyString(),
				Matchers.anyString(), Matchers.anyString(), Matchers.anyString(), Matchers.anyString(),
				Matchers.anyString(), Matchers.anyString(), Matchers.anyString(), Matchers.anyString(),
				Matchers.anyInt(), Matchers.anyBoolean())).thenReturn("");

		Map<String, Object> actualResult = discoveryJarDetails.setupRelayJARDiscoveryDetails("macAddress", 1, "guid",
				100L, "test@email.com", "hostName", "swLicense", "hwConfig", "iPAddress", "localIPAddress",
				"chatInputChannel", "chatOutputChannel", "chatSubscriptionChannel", "nodeCommunicationPort",
				"openStackPort", "tomcatPort", "port1", "port2", "port3", "port4", "port5", "rURLTomcatPort",
				"rAddress", "true", 0);

		String actualStatus = actualResult.get("Status").toString();
		assertTrue(expectedStatus().equals(actualStatus));

		verify(portalDatabaseEngine, times(8)).getConnection();
		verify(connection, times(3)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(4)).next();
		verify(resultSet, times(3)).getInt(any(String.class));
		verify(resultSet, times(18)).getString(any(String.class));

	}

	@Test
	public void testGetNonActivatedDevices() throws SQLException {
		when(resultSet.next()).thenReturn(true).thenReturn(false);

		when(resultSet.getString(any(String.class))).thenReturn("10.225.63.56");
		when(resultSet.getInt(any(String.class))).thenReturn(4);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));
		List<DiscoveryJarDetailsVO> detailsVOs = discoveryJarDetails.getNonActivatedDevices("externalIP");

		assertTrue(1 == detailsVOs.size());
		assertTrue(detailsVOs.get(0).getsIPAddress().equals("10.225.63.56"));

	}

	@Test
	public void testGetDiscoveryJarDetailsUsingHostName() throws Exception {
		when(resultSet.next()).thenReturn(true).thenReturn(false);

		when(resultSet.getString(any(String.class))).thenReturn("10.225.63.56");
		when(resultSet.getInt(any(String.class))).thenReturn(4);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));
		DiscoveryJarDetailsVO detailsVOs = discoveryJarDetails.getDiscoveryJarDetailsUsingHostName("hostName");

		assertTrue(detailsVOs.getsIPAddress().equals("10.225.63.56"));
	}

	@Test(expected = Exception.class)
	public void testGetDiscoveryJarDetailsUsingHostNameNotFound() throws Exception {
		when(resultSet.next()).thenReturn(false);
		discoveryJarDetails.getDiscoveryJarDetailsUsingHostName("hostName");
	}

	@Test
	public void testUpdateInactiveDeviceHeartbeat() throws SQLException {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		discoveryJarDetails.updateInactiveDeviceHeartbeat("productId");
	}

	@Test(expected = SQLException.class)
	public void testUpdateInactiveDeviceHeartbeatWhenUpdateFailed() throws SQLException {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(0);
		discoveryJarDetails.updateInactiveDeviceHeartbeat("productId");
	}
}
