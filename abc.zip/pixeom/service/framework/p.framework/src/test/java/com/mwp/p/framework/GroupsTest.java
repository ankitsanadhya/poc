package com.mwp.p.framework;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.mockStatic;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.BDDMockito;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.classloader.annotations.SuppressStaticInitializationFor;
import org.powermock.modules.junit4.PowerMockRunner;

import com.mwp.common.CredProvider;
import com.mwp.common.constant.Constant;
import com.mwp.common.vo.QueryVO;
import com.mwp.db.Interface.IConnection;
import com.mwp.p.common.enums.ResourceType;
import com.mwp.p.dal.engine.PortalDatabaseEngine;
import com.pa.crypto.StringEncryptionDecryption;

@RunWith(PowerMockRunner.class)
@SuppressStaticInitializationFor({ "com.mwp.b.common.Constants", "com.mwp.p.dal.engine.PortalDatabaseEngine" })
@PrepareForTest({ Constant.class, StringEncryptionDecryption.class, PortalDatabaseEngine.class })
public class GroupsTest {

	@Mock
	private PortalDatabaseEngine portalDatabaseEngine;

	@Mock
	IConnection connection;

	@Mock
	private ResultSet resultSet;

	@Mock
	private CredProvider credProvider;

	private Groups groups;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		mockStatic(PortalDatabaseEngine.class);
		mockStatic(StringEncryptionDecryption.class);
		mockStatic(Constant.class);
		groups = spy(new Groups());

		when(PortalDatabaseEngine.getInstance()).thenReturn(portalDatabaseEngine);
		when(portalDatabaseEngine.getConnection()).thenReturn(connection);

		when(connection.executeQuery(any(QueryVO.class))).thenReturn(resultSet);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		BDDMockito.given(StringEncryptionDecryption.decrypt(any(), any())).willReturn("test");
		BDDMockito.given(StringEncryptionDecryption.encrypt(any(), any())).willReturn("test");

		BDDMockito.given(StringEncryptionDecryption.decrypt(any())).willReturn("test");
		BDDMockito.given(StringEncryptionDecryption.encrypt(any())).willReturn("test");

		PowerMockito.whenNew(CredProvider.class).withNoArguments().thenReturn(credProvider);
	}

	@After
	public void tearDown() {

	}

	@Test(expected = Exception.class)
	public void testAddAppToGroup() throws SQLException {

		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("deviceId");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		List<String> versionIds = new ArrayList<>();
		versionIds.add("versionId");
		groups.addAppToGroup("appId", "groupId", versionIds);
	}

	@Test
	public void testListGroupApp() throws SQLException {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		when(resultSet.next()).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("deviceId");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		groups.listGroupApp("groupId");
	}
	
	@Test
	public void testAddAppToGroupWhenVersionNotPresent() throws SQLException {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		when(resultSet.next()).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("deviceId");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		List<String> versionIds = new ArrayList<>();
		groups.addAppToGroup("appId", "groupId", versionIds);
	}

	@Test(expected = SQLException.class)
	public void testAddAppToGroupWhenUpdateFailed() throws SQLException {
		when(connection.executeUpdate(any(String.class))).thenReturn(0);
		when(resultSet.next()).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("deviceId");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		List<String> versionIds = new ArrayList<>();
		groups.addAppToGroup("appId", "groupId", versionIds);
	}

	@Test
	public void testRemoveAppToGroup() throws Exception {
		when(connection.executeUpdatesInTransaction(any(List.class))).thenReturn(true);
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("deviceId");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		groups.removeAppToGroup("appId", "groupId");
	}

	@Test
	public void testUpdateGroupVersion() throws Exception {
		when(resultSet.next()).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("deviceId");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));
		Map<String, Boolean> versionIdsWithOperation = new HashMap<>();
		versionIdsWithOperation.put("key", true);
		groups.updateGroupVersion("appId", "groupId", versionIdsWithOperation);
	}

	@Test
	public void testListGroupEdgeCore() throws SQLException {

		when(resultSet.next()).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("deviceId");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));
		groups.listGroupEdgeCore("groupId");
	}

	@Test(expected = SQLException.class)
	public void testAddEdgeCoreToGroupWhenDeviceAlreadyExist() throws SQLException {

		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("deviceId");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));
		groups.addEdgeCoreToGroup("deviceId", "groupId");
	}

	@Test
	public void testAddEdgeCoreToGroup() throws SQLException {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		when(resultSet.next()).thenReturn(false).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("deviceId");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));
		groups.addEdgeCoreToGroup("deviceId", "groupId");
	}

	@Test
	public void testAddResourceToGroup() throws SQLException {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		when(resultSet.next()).thenReturn(false).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("deviceId");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		groups.addResourceToGroup("deviceId", "groupId", ResourceType.document);
	}

	@Test
	public void testRemoveResourceFromGroup() throws SQLException {
		when(connection.executeUpdate(any(String.class))).thenReturn(1);
		groups.removeResourceFromGroup("resourceId", "groupId");
	}

	@Test
	public void testRemoveResourceFromGroupForMultipleReources() throws SQLException {
		when(connection.executeUpdate(any(String.class))).thenReturn(1);
		List<String> resourceIds = new ArrayList<>();
		resourceIds.add("reoureId");
		groups.removeResourceFromGroup(resourceIds, "groupId");
	}

	@Test
	public void testRemoveEdgeCoreFromGroup() throws SQLException {
		when(connection.executeUpdate(any(String.class))).thenReturn(1);
		groups.removeEdgeCoreFromGroup("deviceId", "groupId");
	}

	@Test
	public void testDeleteGroupResources() throws SQLException {
		when(connection.executeUpdate(any(String.class))).thenReturn(1);
		groups.deleteGroupResources("deviceId", "groupId");
	}
}
