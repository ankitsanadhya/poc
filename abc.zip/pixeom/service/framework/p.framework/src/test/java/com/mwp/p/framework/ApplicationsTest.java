package com.mwp.p.framework;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.mockStatic;

import java.io.File;
import java.io.FileReader;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.classloader.annotations.SuppressStaticInitializationFor;
import org.powermock.modules.junit4.PowerMockRunner;

import com.mwp.common.CredProvider;
import com.mwp.common.constant.Constant;
import com.mwp.common.enums.CommandEnum;
import com.mwp.common.enums.FilterKeysEnum;
import com.mwp.common.enums.FilterType;
import com.mwp.common.enums.Operator;
import com.mwp.common.vo.AppInstallDetailsVO;
import com.mwp.common.vo.ApplicationDetailsVO;
import com.mwp.common.vo.ApplicationVO;
import com.mwp.common.vo.FilterObject;
import com.mwp.common.vo.QueryVO;
import com.mwp.common.vo.VersionVO;
import com.mwp.common.yamlparser.ComposeVO;
import com.mwp.common.yamlparser.SecretVersionVO;
import com.mwp.common.yamlparser.SecretVo;
import com.mwp.common.yamlparser.SectionVO;
import com.mwp.common.yamlparser.YamlParser;
import com.mwp.db.Interface.IConnection;
import com.mwp.p.common.vo.AppCommandVO;
import com.mwp.p.common.vo.DeviceApplicationVO;
import com.mwp.p.dal.engine.ApplicationsEngine;
import com.mwp.p.dal.engine.PortalDatabaseEngine;
import com.pa.crypto.FileEncryptionDecryption;
import com.pa.crypto.StringEncryptionDecryption;

@RunWith(PowerMockRunner.class)
@SuppressStaticInitializationFor({ "com.mwp.p.common.Constants", "com.mwp.p.dal.engine.PortalDatabaseEngine" })
@PrepareForTest({ Constant.class, StringEncryptionDecryption.class, PortalDatabaseEngine.class,
		ApplicationsEngine.class, FileEncryptionDecryption.class, YamlParser.class })
public class ApplicationsTest {

	@Mock
	private PortalDatabaseEngine portalDatabaseEngine;

	@Mock
	IConnection connection;

	@Mock
	private ResultSet resultSet;

	@Mock
	private CredProvider credProvider;

	@Mock
	private File file;

	@Mock
	private FileReader fileReader;

	@Mock
	private JSONParser jsonParser;

	private Applications applications;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		mockStatic(PortalDatabaseEngine.class);
		mockStatic(StringEncryptionDecryption.class);
		mockStatic(Constant.class);
		mockStatic(FileEncryptionDecryption.class);
		mockStatic(YamlParser.class);
		applications = spy(new Applications());

		when(PortalDatabaseEngine.getInstance()).thenReturn(portalDatabaseEngine);
		when(portalDatabaseEngine.getConnection()).thenReturn(connection);

		when(connection.executeQuery(any(QueryVO.class))).thenReturn(resultSet);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));
		PowerMockito.whenNew(CredProvider.class).withNoArguments().thenReturn(credProvider);
	}

	@After
	public void tearDown() {
		applications = null;
		portalDatabaseEngine = null;
		connection = null;
		resultSet = null;
		jsonParser = null;
		file = null;
		fileReader = null;
	}

	@Test
	public void testListGroupsOfApp() throws SQLException {
		List<String> expectedList = new ArrayList<>();
		expectedList.add("deviceId");
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("deviceId");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		List<String> groupIds = new ArrayList<>();
		groupIds.add("groupId");
		List<String> actualList = applications.listGroupsOfApp("appId", groupIds);

		assertTrue(expectedList.equals(actualList));
		verify(portalDatabaseEngine, times(2)).getConnection();
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(2)).next();
		verify(resultSet, times(1)).getString(any(String.class));
	}

	@Test
	public void testSearchApps() throws SQLException {
		Map<String, Object> expectedMap = new HashMap<>();
		expectedMap.put("totalAppCount", 1);
		expectedMap.put("pageNo", 1);
		expectedMap.put("totalPages", 1);
		expectedMap.put("pageSize", 5);
		ArrayList<ApplicationVO> listAlerts = new ArrayList<>();
		expectedMap.put("data", listAlerts);

		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("deviceId");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		List<FilterObject> filters = new ArrayList<>();
		FilterObject fo = new FilterObject();
		fo.setFilterkey(FilterKeysEnum.MessageType);
		fo.setFilterType(FilterType.SORT);
		fo.setOperator(Operator.EQUAL);
		fo.setStartValue("Test");
		filters.add(fo);

		Map<String, Object> actualFilteredMAp = applications.searchApps(1, 5, filters, true);
		assertTrue(expectedMap.equals(actualFilteredMAp));
		verify(portalDatabaseEngine, times(4)).getConnection();
		verify(connection, times(2)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(3)).next();
		verify(resultSet, times(1)).getInt(any(String.class));
	}

	@Test
	public void testListApps() throws SQLException {
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("appId");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		List<ApplicationVO> listApplicationVo = applications.listApps("searchText");

		assertEquals("appId", listApplicationVo.get(0).getApplicationId());
		verify(portalDatabaseEngine, times(2)).getConnection();
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(2)).next();
		verify(resultSet, times(1)).getInt(any(String.class));
		verify(resultSet, times(8)).getString(any(String.class));
		verify(resultSet, times(2)).getTimestamp(any(String.class));
	}
	
	@Test
	public void testGetAppVersionAndUserIdOfApp() throws SQLException {
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("appId");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		List<String> listApplicationVo = applications.getAppVersionAndUserIdOfApp("appVersionId");

		assertEquals(3, listApplicationVo.size());
		verify(portalDatabaseEngine, times(2)).getConnection();
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(2)).next();		
	}
	
	

	@Test
	public void testCheckUpdate() throws SQLException {
		when(resultSet.next()).thenReturn(true);
		boolean actualUpdatedValue = applications.checkUpdate("appVersionID");
		assertTrue(actualUpdatedValue);
		verify(portalDatabaseEngine, times(2)).getConnection();
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(1)).next();
	}

	@Test
	public void testGetUserIdOfApp() throws SQLException {
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("appId");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		String actualValue = applications.getUserIdOfApp("appID");
		assertEquals("appId", actualValue);
		verify(portalDatabaseEngine, times(2)).getConnection();
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(2)).next();
		verify(resultSet, times(1)).getString(any(String.class));
	}

	@Test
	public void testGetUpdateAvailableForInstalledApp() throws SQLException {
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getBoolean(any(String.class))).thenReturn(true);

		boolean actualValue = applications.getUpdateAvailableForInstalledApp("appID", "appVersionId", "platformId");
		assertTrue(actualValue);
		verify(portalDatabaseEngine, times(2)).getConnection();
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(2)).next();
		verify(resultSet, times(1)).getBoolean(any(String.class));
	}

	@Test
	public void testListAllLatestVersion() throws SQLException {
		Map<String, Object> expectedMap = new HashMap<>();
		expectedMap.put("pageNo", 1);
		expectedMap.put("totalPages", 1);
		expectedMap.put("pageSize", 5);
		ArrayList<ApplicationVO> listAlerts = new ArrayList<>();
		expectedMap.put("data", listAlerts);

		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("appId");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		Map<String, Object> actualFilteredMAp = applications.listAllLatestVersion(1, 5);

		assertTrue(expectedMap.equals(actualFilteredMAp));
		verify(portalDatabaseEngine, times(4)).getConnection();
		verify(connection, times(2)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(3)).next();
		verify(resultSet, times(1)).getInt(any(String.class));
	}

	@Test
	public void testGetAppInstallDetail() throws SQLException {
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("appId").thenReturn("appVersionId").thenReturn("2020");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));
		when(StringEncryptionDecryption.decrypt(any(), any())).thenReturn("2020");
		AppInstallDetailsVO appInstallDetailsVO = applications.getAppInstallDetail("appid", "versionId",
				"appPlatFormId");

		assertEquals("appId", appInstallDetailsVO.getApplicationId());
		verify(portalDatabaseEngine, times(2)).getConnection();
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(2)).next();
		verify(resultSet, times(4)).getInt(any(String.class));
		verify(resultSet, times(31)).getString(any(String.class));
	}

	@Test
	public void testScheduleOperation() throws Exception {
		when(resultSet.next()).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false).thenReturn(true)
				.thenReturn(false).thenReturn(true).thenReturn(false).thenReturn(false).thenReturn(true)
				.thenReturn(false).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false);
		String jsonString = "{'dockercompose':'Bob','resources':{'limits':'4','memory':'10000'},'SystemInfo':{'CpuCores':'4','MemoryTotal':'10000'}}";
		when(resultSet.getString(any(String.class))).thenReturn(jsonString);
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		List<SecretVo> lstSecretVo = listOfSecretVo();

		List<String> resourcesIds = new ArrayList<>();
		resourcesIds.add("deviceId");

		PowerMockito.doReturn(credProvider).when(applications).buildCredProvider();
		when(credProvider.getEcnKey()).thenReturn("test");
		PowerMockito.doNothing().when(FileEncryptionDecryption.class, "Decrypt_File", Mockito.any(String.class),
				Mockito.any(String.class), Mockito.any(String.class));

		ComposeVO composeVO = new ComposeVO();
		Hashtable<String, SectionVO> composeServices = new Hashtable<>();
		SectionVO sectionVO = new SectionVO();
		sectionVO.setContainerName("containerName");
		sectionVO.setImage("image");
		sectionVO.setCpuset("4-5");
		sectionVO.setMem_limit("1000");

		HashMap<String, Object> policyMap = new HashMap<>();
		sectionVO.setDeploy(policyMap);

		ArrayList<String> parsedVolumeList = new ArrayList<>();
		parsedVolumeList.add("parsedVolume1");
		sectionVO.setParsedVolumes(parsedVolumeList);

		composeServices.put("key", sectionVO);
		composeVO.setServices(composeServices);
		composeVO.setVersion("3");

		when(YamlParser.parse(any())).thenReturn(composeVO);

		applications.scheduleOperation("userId", "appid", "deviceIds", CommandEnum.installApplication.name(),
				"versionId", 1L, lstSecretVo, true, resourcesIds);

		verify(portalDatabaseEngine, times(19)).getConnection();
		verify(connection, times(8)).executeQuery(any(QueryVO.class));
		verify(connection, times(1)).executeUpdatesInTransaction(any(List.class));
		verify(resultSet, times(15)).next();
		verify(resultSet, times(29)).getString(any(String.class));
		verify(resultSet, times(4)).getInt(any(String.class));
		verify(resultSet, times(6)).getTimestamp(any(String.class));
	}

	@Test
	public void testScheduleOperationForV2() throws Exception {
		when(resultSet.next()).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false).thenReturn(true)
				.thenReturn(false).thenReturn(true).thenReturn(false).thenReturn(false).thenReturn(true)
				.thenReturn(false).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false);
		String jsonString = "{'dockercompose':'Bob','resources':{'limits':'4','memory':'10000'},'SystemInfo':{'CpuCores':'4','MemoryTotal':'10000'}}";
		when(resultSet.getString(any(String.class))).thenReturn(jsonString);
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		List<SecretVo> lstSecretVo = listOfSecretVo();

		List<String> resourcesIds = new ArrayList<>();
		resourcesIds.add("deviceId");

		PowerMockito.doReturn(credProvider).when(applications).buildCredProvider();
		when(credProvider.getEcnKey()).thenReturn("test");
		PowerMockito.doNothing().when(FileEncryptionDecryption.class, "Decrypt_File", Mockito.any(String.class),
				Mockito.any(String.class), Mockito.any(String.class));

		ComposeVO composeVO = new ComposeVO();
		Hashtable<String, SectionVO> composeServices = new Hashtable<>();
		SectionVO sectionVO = new SectionVO();
		sectionVO.setContainerName("containerName");
		sectionVO.setImage("image");
		sectionVO.setCpuset("4-5");
		sectionVO.setMem_limit("1000");

		HashMap<String, Object> policyMap = new HashMap<>();
		sectionVO.setDeploy(policyMap);

		ArrayList<String> parsedVolumeList = new ArrayList<>();
		parsedVolumeList.add("parsedVolume1");
		sectionVO.setParsedVolumes(parsedVolumeList);

		composeServices.put("key", sectionVO);
		composeVO.setServices(composeServices);
		composeVO.setVersion("2");

		when(YamlParser.parse(any())).thenReturn(composeVO);

		applications.scheduleOperation("userId", "appid", "deviceIds", CommandEnum.installApplication.name(),
				"versionId", 1L, lstSecretVo, true, resourcesIds);

		verify(portalDatabaseEngine, times(19)).getConnection();
		verify(connection, times(8)).executeQuery(any(QueryVO.class));
		verify(connection, times(1)).executeUpdatesInTransaction(any(List.class));
		verify(resultSet, times(15)).next();
		verify(resultSet, times(29)).getString(any(String.class));
		verify(resultSet, times(4)).getInt(any(String.class));
		verify(resultSet, times(6)).getTimestamp(any(String.class));
	}

	@Test(expected = IndexOutOfBoundsException.class)
	public void testScheduleOperationWhenBoxStatsEmpty() throws Exception {
		when(resultSet.next()).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false).thenReturn(true)
				.thenReturn(false).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("dockercompose");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		List<String> appConfigIds = new ArrayList<>();
		appConfigIds.add("deviceId");

		List<SecretVo> lstSecretVo = new ArrayList<>();
		SecretVo svo = new SecretVo();
		svo.setAppId("appId");
		lstSecretVo.add(svo);
		applications.scheduleOperation("userId", "appid", "deviceIds", CommandEnum.installApplication.name(),
				"versionId", 1L, lstSecretVo, true, appConfigIds);
	}

	@Test
	public void testScheduleOperationWhenApplicationNotFound() throws Exception {
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn(null);
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		List<String> appConfigIds = new ArrayList<>();
		appConfigIds.add("deviceId");

		List<SecretVo> lstSecretVo = new ArrayList<>();
		SecretVo svo = new SecretVo();
		svo.setAppId("appId");
		lstSecretVo.add(svo);
		applications.scheduleOperation("userId", "appid", "deviceIds", "uninstallApplication", "versionId", 1L,
				lstSecretVo, true, appConfigIds);
	}

	@Test
	public void testScheduleOperationAll() throws Exception {
		when(resultSet.next()).thenReturn(false).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false)
				.thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false).thenReturn(true)
				.thenReturn(false).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false);
		String jsonString = "{'dockercompose':'Bob','resources':{'limits':'4','memory':'10000'},'SystemInfo':{'CpuCores':'4','MemoryTotal':'10000'}}";
		when(resultSet.getString(any(String.class))).thenReturn("deviceid").thenReturn("deviceid")
				.thenReturn("deviceid").thenReturn("deviceid").thenReturn("deviceid").thenReturn("deviceid")
				.thenReturn("deviceid").thenReturn("deviceid").thenReturn("deviceid").thenReturn("deviceid")
				.thenReturn("deviceid").thenReturn("deviceid").thenReturn("deviceid").thenReturn("deviceid")
				.thenReturn("deviceid").thenReturn("deviceid").thenReturn("deviceid").thenReturn("deviceid")
				.thenReturn("deviceid").thenReturn("deviceid").thenReturn("deviceid").thenReturn("deviceid")
				.thenReturn("deviceid").thenReturn("deviceid").thenReturn("deviceid").thenReturn(null)
				.thenReturn("dockercompose");

		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		List<String> deviceIds = new ArrayList<>();
		deviceIds.add("deviceId");
		deviceIds.add("deviceId2");

		List<String> appConfigIds = new ArrayList<>();
		appConfigIds.add("deviceId");

		List<SecretVo> lstSecretVo = listOfSecretVo();

		JSONObject jsonObject = new JSONObject();
		jsonObject.put("serverCount", 1);
		jsonObject.put("batchSize", 5);
		jsonObject.put("interval", 4L);
		jsonObject.put("sizeFactor", 0L);

		PowerMockito.doReturn(file).when(applications).buildFile(any());
		when(file.exists()).thenReturn(true);
		PowerMockito.doReturn(fileReader).when(applications).buildFileReader();
		PowerMockito.doReturn(jsonParser).when(applications).buildJSONParser();
		when(jsonParser.parse(fileReader)).thenReturn(jsonObject);
		when(StringEncryptionDecryption.decrypt(any(), any())).thenReturn("3");

		Map<String, String> deviceOwnerIds = new HashMap<>();
		deviceOwnerIds.put("deviceOwnerKey1", "deviceOwnerValue1");

		applications.scheduleOperationAll(deviceOwnerIds, "appid", deviceIds, "updateApplication", "versionId",
				lstSecretVo, true, appConfigIds);

		verify(portalDatabaseEngine, times(27)).getConnection();
		verify(connection, times(11)).executeQuery(any(QueryVO.class));
		verify(connection, times(1)).executeUpdatesInTransaction(any(List.class));
		verify(resultSet, times(18)).next();
		verify(resultSet, times(60)).getString(any(String.class));
		verify(resultSet, times(7)).getInt(any(String.class));
		verify(resultSet, times(4)).getTimestamp(any(String.class));
	}
	
	@Test
	public void testScheduleAppRestoreOperationAll() throws Exception {
		when(resultSet.next()).thenReturn(false).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false)
				.thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false).thenReturn(true)
				.thenReturn(false).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false);
		String jsonString = "{'dockercompose':'Bob','resources':{'limits':'4','memory':'10000'},'SystemInfo':{'CpuCores':'4','MemoryTotal':'10000'}}";
		when(resultSet.getString(any(String.class))).thenReturn("deviceid").thenReturn("deviceid")
				.thenReturn("deviceid").thenReturn("deviceid").thenReturn("deviceid").thenReturn("deviceid")
				.thenReturn("deviceid").thenReturn("deviceid").thenReturn("deviceid").thenReturn("deviceid")
				.thenReturn("deviceid").thenReturn("deviceid").thenReturn("deviceid").thenReturn("deviceid")
				.thenReturn("deviceid").thenReturn("deviceid").thenReturn("deviceid").thenReturn("deviceid")
				.thenReturn("deviceid").thenReturn("deviceid").thenReturn("deviceid").thenReturn("deviceid")
				.thenReturn("deviceid").thenReturn("deviceid").thenReturn("deviceid").thenReturn(null)
				.thenReturn("dockercompose");

		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		List<String> deviceIds = new ArrayList<>();
		deviceIds.add("deviceId");
		deviceIds.add("deviceId2");

		List<String> appConfigIds = new ArrayList<>();
		appConfigIds.add("deviceId");

		List<SecretVo> lstSecretVo = listOfSecretVo();

		JSONObject jsonObject = new JSONObject();
		jsonObject.put("serverCount", 1);
		jsonObject.put("batchSize", 5);
		jsonObject.put("interval", 4L);
		jsonObject.put("sizeFactor", 0L);

		PowerMockito.doReturn(file).when(applications).buildFile(any());
		when(file.exists()).thenReturn(true);
		PowerMockito.doReturn(fileReader).when(applications).buildFileReader();
		PowerMockito.doReturn(jsonParser).when(applications).buildJSONParser();
		when(jsonParser.parse(fileReader)).thenReturn(jsonObject);
		when(StringEncryptionDecryption.decrypt(any(), any())).thenReturn("3");

		Map<String, String> deviceOwnerIds = new HashMap<>();
		deviceOwnerIds.put("deviceOwnerKey1", "deviceOwnerValue1");
	
		applications.scheduleAppRestoreOperationAll(deviceOwnerIds, "appid", deviceIds, "updateApplication", "versionId",
				lstSecretVo, true, "detailObject",appConfigIds);

		verify(portalDatabaseEngine, times(27)).getConnection();
		verify(connection, times(11)).executeQuery(any(QueryVO.class));
		verify(connection, times(1)).executeUpdatesInTransaction(any(List.class));
		verify(resultSet, times(18)).next();
		verify(resultSet, times(60)).getString(any(String.class));
		verify(resultSet, times(7)).getInt(any(String.class));
		verify(resultSet, times(4)).getTimestamp(any(String.class));
	}
	
	

	@Test
	public void testGetAppDetail() throws SQLException {
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("deviceId");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		ApplicationDetailsVO actualApplicationDetailsVo = applications.getAppDetail("appId", "userId");
		assertEquals("deviceId", actualApplicationDetailsVo.getApplicationId());
		verify(portalDatabaseEngine, times(4)).getConnection();
		verify(connection, times(2)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(3)).next();
		verify(resultSet, times(35)).getString(any(String.class));
	}

	@Test
	public void testGetAppCommandsForUser() throws SQLException {
		when(resultSet.next()).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("deviceId");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		List<String> grpIds = new ArrayList<>();
		grpIds.add("groupId");
		List<AppCommandVO> appCommandVoList = applications.getAppCommandsForUser("appId", "userId", grpIds);
		assertEquals("deviceId", appCommandVoList.get(0).getDeviceId());
		verify(portalDatabaseEngine, times(5)).getConnection();
		verify(connection, times(2)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(4)).next();
		verify(resultSet, times(4)).getString(any(String.class));
	}

	@Test
	public void testListVersionOfApplication() throws SQLException {
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("appId");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		List<VersionVO> versionVoList = applications.listVersionOfApplication("appId", "userId");

		assertEquals("appId", versionVoList.get(0).getAppId());
		verify(portalDatabaseEngine, times(2)).getConnection();
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(2)).next();
		verify(resultSet, times(11)).getString(any(String.class));
	}

	@Test
	public void testGetSecretKey() throws SQLException {
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("appId");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));
		when(StringEncryptionDecryption.decrypt(any(), any())).thenReturn("test");

		String actualSecretKey = applications.getSecretKey("appId", "userId");

		assertEquals("test", actualSecretKey);
		verify(portalDatabaseEngine, times(2)).getConnection();
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(2)).next();
		verify(resultSet, times(1)).getString(any(String.class));
	}

	@Test
	public void testGetInstalledDeviceAppDetail() throws SQLException {
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("appId");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		DeviceApplicationVO actualDeviceApplicationVo = applications.getInstalledDeviceAppDetail("appId", "deviceId");

		assertEquals("appId", actualDeviceApplicationVo.getApplicationId());
		verify(portalDatabaseEngine, times(2)).getConnection();
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(2)).next();
		verify(resultSet, times(39)).getString(any(String.class));
	}
	
	@Test
	public void testGetInstalledDeviceAppDetailWithFilterHappyPath() throws SQLException {
		when(resultSet.next()).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("appId");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		Map<String, Object> map = applications.getInstalledDeviceAppDetail("appId", 1, 3);
		assertNotNull(map.get("data"));
		assertEquals(3, map.get("pageSize"));
		verify(portalDatabaseEngine, times(4)).getConnection();
		verify(connection, times(2)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(4)).next();
	}

	@Test(expected = SQLException.class)
	public void testGetInstalledDeviceAppDetailWithFilter() throws SQLException {
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("appId");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		Map<String, Object> map = applications.getInstalledDeviceAppDetail("appId", 1, 3);
	}

	@Test
	public void testExecuteOperation() throws SQLException {
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("appId");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		applications.executeOperation("appId", "deviceId", CommandEnum.uninstallApplication.name(), "versionId",
				"jobId");

		verify(portalDatabaseEngine, times(2)).getConnection();
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(2)).next();
		verify(resultSet, times(39)).getString(any(String.class));
		verify(resultSet, times(5)).getInt(any(String.class));
		verify(resultSet, times(5)).getTimestamp(any(String.class));
	}

	@Test
	public void testScheduleAppRestoreOperation() throws Exception {
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("appId");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));
		List<SecretVo> lstSecretVo = listOfSecretVo();

		List<String> resourcesIds = new ArrayList<>();
		resourcesIds.add("deviceId");

		applications.scheduleAppRestoreOperation("userId", "appId", "deviceId", CommandEnum.uninstallApplication.name(),
				"versionId", 1L, lstSecretVo, true, "", resourcesIds);

		verify(portalDatabaseEngine, times(6)).getConnection();
		verify(connection, times(2)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(3)).next();
		verify(resultSet, times(8)).getString(any(String.class));
		verify(resultSet, times(2)).getInt(any(String.class));
		verify(resultSet, times(1)).getTimestamp(any(String.class));
	}

	@Test
	public void testGetFilePaths() throws Exception {
		PowerMockito.doReturn(file).when(applications).buildFile(any());
		File[] fileArray = new File[] { new File("pathName.yaml"), new File("pathName.yml") };
		when(file.listFiles()).thenReturn(fileArray);
		List<String> filePathList = applications.getFilePaths("pathName.yaml");
		assertEquals(2, filePathList.size());
	}

	@Test
	public void testGetCount() throws SQLException {
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("appId");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		applications.getCount();
	}

	public List<SecretVo> listOfSecretVo() {
		List<SecretVo> lstSecretVo = new ArrayList<>();
		SecretVo svo = new SecretVo();
		svo.setAppId("appId");
		ArrayList<SecretVersionVO> secretVersionVOs = new ArrayList<>();
		SecretVersionVO secretVersionVO = new SecretVersionVO();
		secretVersionVO.setAppSecretVersionId("3.0");
		secretVersionVOs.add(secretVersionVO);
		svo.setListSecretVersion(secretVersionVOs);
		lstSecretVo.add(svo);
		return lstSecretVo;
	}

}
