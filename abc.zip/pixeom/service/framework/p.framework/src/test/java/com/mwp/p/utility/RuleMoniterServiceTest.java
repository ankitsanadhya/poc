package com.mwp.p.utility;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.mockStatic;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.classloader.annotations.SuppressStaticInitializationFor;
import org.powermock.modules.junit4.PowerMockRunner;

import com.mwp.common.CommandExecutor;
import com.mwp.common.constant.Constant;
import com.mwp.common.vo.QueryVO;
import com.mwp.db.Interface.IConnection;
import com.mwp.p.dal.engine.PortalDatabaseEngine;

@RunWith(PowerMockRunner.class)
@SuppressStaticInitializationFor({"com.mwp.p.common.Constants","com.mwp.p.dal.engine.PortalDatabaseEngine"})
@PrepareForTest({ Constant.class, StorageMonitorService.class, PortalDatabaseEngine.class })
public class RuleMoniterServiceTest {
	
	@Mock
	private PortalDatabaseEngine portalDatabaseEngine;
	
	@Mock 
	IConnection connection;

	@Mock
	private ResultSet resultSet;
	
	@Mock
	private CommandExecutor commandExecutor;
	
	private RuleMoniterService ruleMonitorService;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		mockStatic(PortalDatabaseEngine.class);
		ruleMonitorService = spy(new RuleMoniterService());
		
		PowerMockito.whenNew(CommandExecutor.class).withNoArguments().thenReturn(commandExecutor);
		when(commandExecutor.Execute(any())).thenReturn("test\ntest");
	}

	@After
	public void tearDown() throws Exception {
		ruleMonitorService = null;
		commandExecutor = null;
		connection = null;
		resultSet = null;
		portalDatabaseEngine = null;
	}
	
	@Test
	public void testMonitorRuleForRelay() throws SQLException{
		when(PortalDatabaseEngine.getInstance()).thenReturn(portalDatabaseEngine);
		when(portalDatabaseEngine.getConnection()).thenReturn(connection);
		
		when(connection.executeQuery(any(QueryVO.class))).thenReturn(resultSet);
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getInt(any(String.class))).thenReturn(0);
		when(resultSet.getString(any(String.class))).thenReturn("ruleId").thenReturn("{\"ruleValue\":\"0\", \"maxRelay\": \"1\"}");
		
		ruleMonitorService.moniterRule();
	}
	
	@Test
	public void testMonitorRuleForStorage() throws SQLException {
		when(PortalDatabaseEngine.getInstance()).thenReturn(portalDatabaseEngine);
		when(portalDatabaseEngine.getConnection()).thenReturn(connection);
		
		when(connection.executeQuery(any(QueryVO.class))).thenReturn(resultSet);
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getString(any(String.class))).thenReturn("ruleId").thenReturn("{\"ruleValue\":\"0\", \"diskIncreaseSize\": \"1\", \"maxDiskSize\": \"1\"}");
		
		
		ruleMonitorService.moniterRule();
	}
}
