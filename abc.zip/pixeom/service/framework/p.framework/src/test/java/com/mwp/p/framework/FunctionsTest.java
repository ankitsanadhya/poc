package com.mwp.p.framework;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.mockStatic;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;

import javax.management.InstanceAlreadyExistsException;

import org.apache.commons.io.FileUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.BDDMockito;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.classloader.annotations.SuppressStaticInitializationFor;
import org.powermock.modules.junit4.PowerMockRunner;

import com.mwp.common.CredProvider;
import com.mwp.common.constant.Constant;
import com.mwp.common.vo.FunctionVO;
import com.mwp.common.vo.FunctionVersionVO;
import com.mwp.common.vo.QueryVO;
import com.mwp.db.Interface.IConnection;
import com.mwp.p.common.Constants;
import com.mwp.p.dal.engine.PortalDatabaseEngine;
import com.pa.crypto.FileEncryptionDecryption;
import com.pa.crypto.StringEncryptionDecryption;

@RunWith(PowerMockRunner.class)
@SuppressStaticInitializationFor({ "com.mwp.p.common.Constants", "com.mwp.p.dal.engine.PortalDatabaseEngine" })
@PrepareForTest({ Constant.class, StringEncryptionDecryption.class, PortalDatabaseEngine.class, FileUtils.class,
		FileEncryptionDecryption.class, Constants.class })
public class FunctionsTest {

	@Mock
	private PortalDatabaseEngine portalDatabaseEngine;

	@Mock
	IConnection connection;

	@Mock
	private ResultSet resultSet;

	@Mock
	private CredProvider credProvider;

	@Mock
	private File file;

	@Mock
	private FileOutputStream fileOutputStream;

	private Functions functions;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		mockStatic(PortalDatabaseEngine.class);
		mockStatic(StringEncryptionDecryption.class);
		mockStatic(Constant.class);
		mockStatic(Constants.class);
		mockStatic(FileUtils.class);
		mockStatic(FileEncryptionDecryption.class);
		functions = spy(new Functions());

		when(PortalDatabaseEngine.getInstance()).thenReturn(portalDatabaseEngine);
		when(portalDatabaseEngine.getConnection()).thenReturn(connection);

		when(connection.executeQuery(any(QueryVO.class))).thenReturn(resultSet);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		BDDMockito.given(StringEncryptionDecryption.decrypt(any(), any())).willReturn("test");
		BDDMockito.given(StringEncryptionDecryption.encrypt(any(), any())).willReturn("test");

		BDDMockito.given(StringEncryptionDecryption.decrypt(any())).willReturn("test");
		BDDMockito.given(StringEncryptionDecryption.encrypt(any())).willReturn("test");

		BDDMockito.given(StringEncryptionDecryption.decrypt(any())).willReturn("test");
		PowerMockito.whenNew(CredProvider.class).withNoArguments().thenReturn(credProvider);
	}

	@After
	public void tearDown() {
		functions = null;
	}

	@Test
	public void testAddFunction() throws Exception {
		when(connection.executeUpdate(any(String.class))).thenReturn(1);
		when(resultSet.next()).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("infoLogs");

		FunctionVO functionVO = new FunctionVO();
		functionVO.setFunctionId("functionId");
		ArrayList<FunctionVersionVO> functionVersionVOs = new ArrayList<>();
		FunctionVersionVO functionVersionVO = new FunctionVersionVO();
		functionVersionVO.setVersion(1);
		functionVersionVOs.add(functionVersionVO);
		functionVO.setVersions(functionVersionVOs);
		InputStream fileStream = PowerMockito.mock(InputStream.class);

		PowerMockito.doReturn(file).when(functions).buildFile(any(String.class));
		when(file.exists()).thenReturn(false);
		when(file.mkdirs()).thenReturn(true);

		BDDMockito.given(FileUtils.deleteQuietly(any())).willReturn(true);
		PowerMockito.doNothing().when(FileUtils.class, "touch", any());

		PowerMockito.doReturn(fileOutputStream).when(functions).buildFileOutputStream(any());
		
		PowerMockito.doReturn(credProvider).when(functions).buildCredProvider();
		when(credProvider.getEcnKey()).thenReturn("test");
		PowerMockito.doNothing().when(FileEncryptionDecryption.class, "Encrypt_File", Mockito.any(String.class),
				Mockito.any(String.class), Mockito.any(String.class));

		functions.addFunction(functionVO, fileStream, "fileName");
	}

	/*@Test
	public void testAddFunctionWhenFileAlreadyExist() throws Exception {
		when(connection.executeUpdate(any(String.class))).thenReturn(1);
		when(resultSet.next()).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("infoLogs");

		FunctionVO functionVO = new FunctionVO();
		functionVO.setFunctionId("functionId");
		ArrayList<FunctionVersionVO> functionVersionVOs = new ArrayList<>();
		FunctionVersionVO functionVersionVO = new FunctionVersionVO();
		functionVersionVO.setVersion(1);
		functionVersionVOs.add(functionVersionVO);
		functionVO.setVersions(functionVersionVOs);
		InputStream fileStream = PowerMockito.mock(InputStream.class);

		PowerMockito.doReturn(file).when(functions).buildFile(any(String.class));
		when(file.exists()).thenReturn(true);

		PowerMockito.doReturn(fileOutputStream).when(functions).buildFileOutputStream(any());

		BDDMockito.given(FileUtils.deleteQuietly(any())).willReturn(true);
		PowerMockito.doNothing().when(FileUtils.class, "touch", any());

		PowerMockito.doReturn(credProvider).when(functions).buildCredProvider();
		when(credProvider.getEcnKey()).thenReturn("test");
		PowerMockito.doNothing().when(FileEncryptionDecryption.class, "Encrypt_File", Mockito.any(String.class),
				Mockito.any(String.class), Mockito.any(String.class));
		functions.addFunction(functionVO, fileStream, "fileName");
	}*/
	
	@Test(expected = InstanceAlreadyExistsException.class)
	public void testAddFunctionWhenInstanceAlreadyExist() throws SQLException, InstanceAlreadyExistsException, IOException {
		when(resultSet.next()).thenReturn(true).thenReturn(false);

		FunctionVO functionVO = new FunctionVO();
		functionVO.setFunctionId("functionId");
		ArrayList<FunctionVersionVO> functionVersionVOs = new ArrayList<>();
		FunctionVersionVO functionVersionVO = new FunctionVersionVO();
		functionVersionVO.setVersion(1);
		functionVersionVOs.add(functionVersionVO);
		functionVO.setVersions(functionVersionVOs);
		InputStream fileStream = PowerMockito.mock(InputStream.class);	
		functions.addFunction(functionVO, fileStream, "fileName");
	}
	
	@Test
	public void testListAllFunctions() throws SQLException {
		when(resultSet.next()).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("function");


		functions.listAllFunctions("userId");
	}
	
	@Test(expected = SQLException.class)
	public void testAddFunctionVersion() throws Exception {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(0);
		when(resultSet.next()).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("infoLogs");

		FunctionVersionVO functionVersionVO = new FunctionVersionVO();
		functionVersionVO.setVersion(1);		
		InputStream fileStream = PowerMockito.mock(InputStream.class);

		PowerMockito.doReturn(file).when(functions).buildFile(any(String.class));
		when(file.exists()).thenReturn(true);

		PowerMockito.doReturn(fileOutputStream).when(functions).buildFileOutputStream(any());

		BDDMockito.given(FileUtils.deleteQuietly(any())).willReturn(true);
		PowerMockito.doNothing().when(FileUtils.class, "touch", any());

		PowerMockito.doReturn(credProvider).when(functions).buildCredProvider();
		when(credProvider.getEcnKey()).thenReturn("test");
		PowerMockito.doNothing().when(FileEncryptionDecryption.class, "Encrypt_File", Mockito.any(String.class),
				Mockito.any(String.class), Mockito.any(String.class));
		functions.addFunctionVersion(functionVersionVO, fileStream, "fileName");
	}
	
	@Test
	public void testAddFunctionVersionHappyScenario() throws Exception {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		when(resultSet.next()).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("infoLogs");

		FunctionVersionVO functionVersionVO = new FunctionVersionVO();
		functionVersionVO.setVersion(1);		
		InputStream fileStream = PowerMockito.mock(InputStream.class);

		PowerMockito.doReturn(file).when(functions).buildFile(any(String.class));
		when(file.exists()).thenReturn(true);

		PowerMockito.doReturn(fileOutputStream).when(functions).buildFileOutputStream(any());

		BDDMockito.given(FileUtils.deleteQuietly(any())).willReturn(true);
		PowerMockito.doNothing().when(FileUtils.class, "touch", any());

		PowerMockito.doReturn(credProvider).when(functions).buildCredProvider();
		when(credProvider.getEcnKey()).thenReturn("test");
		PowerMockito.doNothing().when(FileEncryptionDecryption.class, "Encrypt_File", Mockito.any(String.class),
				Mockito.any(String.class), Mockito.any(String.class));
		functions.addFunctionVersion(functionVersionVO, fileStream, "fileName");
	}
	
	@Test
	public void testListAllVersion() throws SQLException {
		when(resultSet.next()).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("function");


		functions.listAllVersion("userId");
	}
	
	@Test
	public void testGetFunction() throws SQLException {
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("function");


		functions.getFunction("functionId", "versionId", "userId");
	}
	
	@Test
	public void testGetFunctionVersions() throws SQLException {
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("function");


		functions.getFunctionVersions("versionId");
	}
	
	@Test
	public void testGetFunctionByFunctionId() throws SQLException {
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("function");


		functions.getFunction("functionId");
	}
	
	@Test
	public void testDeleteFunction() throws SQLException {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		functions.deleteFunction("functionId");
	}
	
	@Test
	public void testDeleteFunctionVersion() throws SQLException {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		functions.deleteFunctionVersion("functionId","versionId");
	}
}
