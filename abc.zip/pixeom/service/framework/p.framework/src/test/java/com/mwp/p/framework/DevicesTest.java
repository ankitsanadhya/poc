package com.mwp.p.framework;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.mockStatic;

import java.io.File;
import java.io.FileReader;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.BDDMockito;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.classloader.annotations.SuppressStaticInitializationFor;
import org.powermock.modules.junit4.PowerMockRunner;

import com.mwp.common.CredProvider;
import com.mwp.common.constant.Constant;
import com.mwp.common.enums.CommandEnum;
import com.mwp.common.enums.DeviceTypeEnum;
import com.mwp.common.enums.FilterKeysEnum;
import com.mwp.common.enums.FilterType;
import com.mwp.common.enums.NodeType;
import com.mwp.common.enums.Operator;
import com.mwp.common.enums.OwnershipEnum;
import com.mwp.common.enums.RoleEnum;
import com.mwp.common.enums.StateEnum;
import com.mwp.common.enums.Status;
import com.mwp.common.vo.ApplicationUserVO;
import com.mwp.common.vo.AuthorizationsVO;
import com.mwp.common.vo.DeviceNodeVO;
import com.mwp.common.vo.DeviceVO;
import com.mwp.common.vo.FilterObject;
import com.mwp.common.vo.GroupReleaseVO;
import com.mwp.common.vo.QueryVO;
import com.mwp.db.Interface.IConnection;
import com.mwp.p.common.Constants;
import com.mwp.p.common.enums.DNS_SERVERS;
import com.mwp.p.common.vo.DeviceApplicationVO;
import com.mwp.p.dal.engine.DiscoveryDetailsEngine;
import com.mwp.p.dal.engine.PortalDatabaseEngine;
import com.pa.crypto.StringEncryptionDecryption;

@RunWith(PowerMockRunner.class)
@SuppressStaticInitializationFor({ "com.mwp.p.common.Constants", "com.mwp.p.dal.engine.PortalDatabaseEngine" })
@PrepareForTest({ Constant.class, StringEncryptionDecryption.class, PortalDatabaseEngine.class, FileUtils.class,
		DiscoveryDetailsEngine.class, ManageDomainName.class, ManageDomainNameGoogle.class, ManageDomainNameJD.class,
		Constants.class })
public class DevicesTest {

	@Mock
	private PortalDatabaseEngine portalDatabaseEngine;

	@Mock
	IConnection connection;

	@Mock
	private ResultSet resultSet;

	@Mock
	private CredProvider credProvider;

	@Mock
	private JSONParser jsonParser;

	@Mock
	private File file;

	@Mock
	private FileReader fileReader;

	private Devices devices;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		mockStatic(PortalDatabaseEngine.class);
		mockStatic(StringEncryptionDecryption.class);
		mockStatic(ManageDomainName.class);
		mockStatic(ManageDomainNameGoogle.class);
		mockStatic(ManageDomainNameJD.class);
		mockStatic(FileUtils.class);
		mockStatic(Constant.class);
		mockStatic(Constants.class);
		devices = spy(new Devices());

		when(PortalDatabaseEngine.getInstance()).thenReturn(portalDatabaseEngine);
		when(portalDatabaseEngine.getConnection()).thenReturn(connection);

		when(connection.executeQuery(any(QueryVO.class))).thenReturn(resultSet);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		BDDMockito.given(StringEncryptionDecryption.decrypt(any(), any())).willReturn("test");
		BDDMockito.given(StringEncryptionDecryption.encrypt(any(), any())).willReturn("test");

		BDDMockito.given(StringEncryptionDecryption.decrypt(any())).willReturn("test");
		BDDMockito.given(StringEncryptionDecryption.encrypt(any())).willReturn("test");

		PowerMockito.whenNew(CredProvider.class).withNoArguments().thenReturn(credProvider);
	}

	@After
	public void tearDown() {
		devices = null;
		portalDatabaseEngine = null;
		resultSet = null;
		devices = null;
		credProvider = null;
		fileReader = null;
		jsonParser = null;

	}

	@Test
	public void testListDeviceApplication() throws SQLException {
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("deviceId");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));
		Map<String, Object> listDeviceApplicationMap = devices.listDeviceApplication(1, 3, "userId", "deviceId");

		Map<String, Object> expectedMap = new HashMap<>();
		expectedMap.put("pageNo", 1);
		expectedMap.put("totalPages", 1);
		expectedMap.put("pageSize", 3);
		ArrayList<DeviceApplicationVO> deviceApplicationVos = new ArrayList<>();
		expectedMap.put("data", deviceApplicationVos);

		assertTrue(expectedMap.equals(listDeviceApplicationMap));

		verify(portalDatabaseEngine, times(4)).getConnection();
		verify(connection, times(2)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(3)).next();
		verify(resultSet, times(1)).getInt(any(String.class));
	}
	
	@Test
	public void testListDevice() throws SQLException {
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("deviceId");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));
		List<DeviceVO> deviceVos = devices.listDevice("userId", "deviceId", true);

		assertEquals(1, deviceVos.size());

		verify(portalDatabaseEngine, times(5)).getConnection();
		verify(connection, times(2)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(3)).next();		
	}
	
	@Test
	public void testListKubenetesClusterForUser() throws SQLException {
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("deviceId");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));
		List<DeviceVO> deviceVos = devices.listKubenetesClusterForUser("userId");

		assertEquals(1, deviceVos.size());

		verify(portalDatabaseEngine, times(5)).getConnection();
		verify(connection, times(2)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(3)).next();		
	}
	
	@Test
	public void testListKubenetesClusterForUserAndCluster() throws SQLException {
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("deviceId");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));
		List<DeviceVO> deviceVos = devices.listKubenetesClusterForUser("userId","clusterId");

		assertEquals(1, deviceVos.size());

		verify(portalDatabaseEngine, times(5)).getConnection();
		verify(connection, times(2)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(3)).next();		
	}	
	

	@Test
	public void testListAllAppsOfDevice() throws SQLException {
		when(resultSet.next()).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false).thenReturn(true)
				.thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("test");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		AuthorizationsVO authVo = new AuthorizationsVO();
		authVo.setApplicationId("appId");
		authVo.setRole(RoleEnum.Admin);
		List<DeviceApplicationVO> listDeviceApplicationVo = devices.listAllAppsOfDevice(authVo, "deviceId");
		assertNotNull(listDeviceApplicationVo);
		assertEquals(1, listDeviceApplicationVo.size());
		verify(portalDatabaseEngine, times(7)).getConnection();
		verify(connection, times(3)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(6)).next();
	}
	
	@Test
	public void testListAppsOfDevice() throws SQLException {
		when(resultSet.next()).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false).thenReturn(true)
				.thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("test");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		AuthorizationsVO authVo = new AuthorizationsVO();
		authVo.setApplicationId("appId");
		authVo.setRole(RoleEnum.Admin);
		List<FilterObject> filterObjectList = new ArrayList<>();
		FilterObject filterObject = new FilterObject();
		filterObject.setFilterType(FilterType.CATEGORY);
		filterObjectList.add(filterObject);
		
		Map<String, Object> mapDeviceApplicationVo = devices.listAppsOfDevice("userId", "deviceId", filterObjectList, 1, 5);
		assertNotNull(mapDeviceApplicationVo);
		verify(portalDatabaseEngine, times(6)).getConnection();
		verify(connection, times(3)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(6)).next();
	}
	

	@Test
	public void testAddDeviceApplication() throws SQLException {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);

		DeviceApplicationVO deviceApplication = new DeviceApplicationVO();
		deviceApplication.setApplicationId("appId");
		deviceApplication.setDeviceId("deviceId");
		deviceApplication.setCurrency("USD");
		deviceApplication.setStatus(Status.ACTIVE);
		DeviceApplicationVO deviceApplicationVO = devices.addDeviceApplication(deviceApplication);

		assertNotNull(deviceApplicationVO);
		assertEquals("appId", deviceApplicationVO.getApplicationId());
		verify(portalDatabaseEngine, times(4)).getConnection();
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
		verify(connection, times(1)).executeUpdate(any(QueryVO.class));
		verify(resultSet, times(1)).next();
	}

	@Test(expected = SQLException.class)
	public void testAddDeviceApplicationWhenUpdateFailed() throws SQLException {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(0);

		DeviceApplicationVO deviceApplication = new DeviceApplicationVO();
		deviceApplication.setApplicationId("appId");
		deviceApplication.setDeviceId("deviceId");
		deviceApplication.setCurrency("USD");
		deviceApplication.setStatus(Status.ACTIVE);
		devices.addDeviceApplication(deviceApplication);
	}

	@Test
	public void testAddDeviceApplicationWithExecuteSelect() throws SQLException {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);

		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("test");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		DeviceApplicationVO deviceApplication = new DeviceApplicationVO();
		deviceApplication.setApplicationId("appId");
		deviceApplication.setDeviceId("deviceId");
		deviceApplication.setCurrency("USD");
		deviceApplication.setStatus(Status.ACTIVE);

		DeviceApplicationVO deviceApplicationVO = devices.addDeviceApplication(deviceApplication);
		assertNotNull(deviceApplicationVO);
		assertEquals("appId", deviceApplicationVO.getApplicationId());
		verify(portalDatabaseEngine, times(4)).getConnection();
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
		verify(connection, times(1)).executeUpdate(any(QueryVO.class));
		verify(resultSet, times(1)).next();
	}

	@Test
	public void testAddUpdateDeviceApplication() throws SQLException {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		List<DeviceApplicationVO> listOfDeviceApplicationVo = new ArrayList<>();
		DeviceApplicationVO deviceApplication = new DeviceApplicationVO();
		deviceApplication.setApplicationId("appId");
		deviceApplication.setDeviceId("deviceId");
		deviceApplication.setCurrency("USD");
		deviceApplication.setStatus(Status.ACTIVE);
		listOfDeviceApplicationVo.add(deviceApplication);

		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn(null);
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		List<String> listOfDevices = devices.addUpdateDeviceApplication(listOfDeviceApplicationVo);

		assertNotNull(listOfDevices);
		assertEquals(1, listOfDevices.size());
		verify(portalDatabaseEngine, times(4)).getConnection();
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
		verify(connection, times(1)).executeUpdate(any(QueryVO.class));
		verify(resultSet, times(1)).next();
	}

	@Test
	public void testUpdateActivationStatus() throws SQLException {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		devices.updateActivationStatus("deviceId");

		verify(portalDatabaseEngine, times(2)).getConnection();
		verify(connection, times(1)).executeUpdate(any(QueryVO.class));
	}

	@Test(expected = SQLException.class)
	public void testUpdateActivationStatusWhenUpdateFailed() throws SQLException {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(0);
		devices.updateActivationStatus("deviceId");
	}

	@Test
	public void testActivateDevice() throws Exception {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		when(resultSet.next()).thenReturn(false).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false)
				.thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false).thenReturn(true)
				.thenReturn(false).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("macaddress");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		when(connection.executeUpdatesInTransaction(any(List.class))).thenReturn(true);
		PowerMockito.doReturn(file).when(devices).buildFile(any(String.class));

		when(file.exists()).thenReturn(false);
		when(file.getParentFile()).thenReturn(file);
		when(file.mkdirs()).thenReturn(true);

		PowerMockito.doNothing().when(FileUtils.class, "writeStringToFile", any(), any());

		DeviceVO deviceVO = new DeviceVO();
		deviceVO.setDeviceId("deviceid");
		deviceVO.setClusterId("clusterId");
		deviceVO.setDeviceName("deviceName");
		ArrayList<DeviceNodeVO> listOfDeviceNodes = new ArrayList<>();
		DeviceNodeVO deviceNodeVo = new DeviceNodeVO();
		deviceNodeVo.setHostName("hostname");
		deviceNodeVo.setMacAddress("macaddress");
		deviceNodeVo.setDeviceRole(NodeType.MASTER);
		deviceNodeVo.setDeviceState(StateEnum.Active);
		listOfDeviceNodes.add(deviceNodeVo);
		deviceVO.setNodes(listOfDeviceNodes);
		deviceVO.setNodeHostName("hostname");
		Map<String, Object> actaulActivateDeviceMap = devices.activateDevice(deviceVO, "licenseKey", "networkJson",
				"jwtPublicKey");
		assertNotNull(actaulActivateDeviceMap);

		verify(portalDatabaseEngine, times(28)).getConnection();
		verify(connection, times(6)).executeQuery(any(QueryVO.class));
		verify(connection, times(4)).executeUpdate(any(QueryVO.class));
		verify(connection, times(1)).executeUpdatesInTransaction(any(List.class));
		verify(resultSet, times(11)).next();
	}

	@Test(expected = Exception.class)
	public void testActivateDeviceWhenPLatFormVoIsNull() throws Exception {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);

		when(resultSet.next()).thenReturn(false).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("macaddress");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		DeviceVO deviceVO = new DeviceVO();
		deviceVO.setDeviceId("deviceid");
		deviceVO.setClusterId("clusterId");
		deviceVO.setDeviceName("deviceName");
		ArrayList<DeviceNodeVO> listOfDeviceNodes = new ArrayList<>();
		DeviceNodeVO deviceNodeVo = new DeviceNodeVO();
		deviceNodeVo.setHostName("hostname");
		deviceNodeVo.setMacAddress("macaddress");
		listOfDeviceNodes.add(deviceNodeVo);
		deviceVO.setNodes(listOfDeviceNodes);
		deviceVO.setNodeHostName("hostname");

		devices.activateDevice(deviceVO, "licenseKey", "networkJson", "jwtPublicKey");

	}

	@Test(expected = Exception.class)
	public void testActivateDeviceWhenMacAddressIsNull() throws Exception {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);

		when(resultSet.next()).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn(null);
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		DeviceVO deviceVO = new DeviceVO();
		deviceVO.setDeviceId("deviceid");
		deviceVO.setClusterId("clusterId");
		deviceVO.setDeviceName("deviceName");
		ArrayList<DeviceNodeVO> listOfDeviceNodes = new ArrayList<>();
		DeviceNodeVO deviceNodeVo = new DeviceNodeVO();
		deviceNodeVo.setHostName("hostname");
		deviceNodeVo.setMacAddress("macaddress");
		listOfDeviceNodes.add(deviceNodeVo);
		deviceVO.setNodes(listOfDeviceNodes);
		deviceVO.setNodeHostName("hostname");
		devices.activateDevice(deviceVO, "licenseKey", "networkJson", "jwtPublicKey");
	}

	@Test(expected = Exception.class)
	public void testActivateDeviceWhenDeviceIdIsNull() throws Exception {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		DeviceVO deviceVO = new DeviceVO();
		deviceVO.setClusterId("clusterId");
		devices.activateDevice(deviceVO, "licenseKey", "networkJson", "jwtPublicKey");
	}

	@Test(expected = Exception.class)
	public void testActivateDeviceWhenDeviceAlreadyExist() throws Exception {
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn(null);
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		DeviceVO deviceVO = new DeviceVO();
		deviceVO.setClusterId("clusterId");
		devices.activateDevice(deviceVO, "licenseKey", "networkJson", "jwtPublicKey");
	}

	@Test
	public void testIsDeviceNameAvailable() throws SQLException {
		when(resultSet.next()).thenReturn(false).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("macaddress");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		boolean isAvailable = devices.isDeviceNameAvailable("deviceName", "macaddress");
		assertTrue(isAvailable);
		verify(portalDatabaseEngine, times(2)).getConnection();	
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
	}

	@Test
	public void testDeleteDeviceApplicationForAMZ() throws Exception {

		BDDMockito.given(Constants.getDNS_SERVER()).willReturn(DNS_SERVERS.AMZ);

		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		PowerMockito.doNothing().when(ManageDomainName.class, "runCommand", any(), any(), any());
		when(resultSet.next()).thenReturn(true).thenReturn(true).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("macaddress");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		DeviceVO deviceVO = devices.deleteDeviceApplication("deviceName", "macaddress");
		assertNotNull(deviceVO);
		verify(portalDatabaseEngine, times(19)).getConnection();	
		verify(connection, times(3)).executeQuery(any(QueryVO.class));		
	}

	@Test
	public void testDeleteDeviceApplicationForGOO() throws Exception {
		BDDMockito.given(Constants.getDNS_SERVER()).willReturn(DNS_SERVERS.GOO);
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		PowerMockito.doNothing().when(ManageDomainNameGoogle.class, "runCommand", any(), any(), any(), any());
		when(resultSet.next()).thenReturn(true).thenReturn(true).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("macaddress");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		DeviceVO deviceVO = devices.deleteDeviceApplication("deviceName", "macaddress");
		assertNotNull(deviceVO);
		verify(portalDatabaseEngine, times(19)).getConnection();	
		verify(connection, times(3)).executeQuery(any(QueryVO.class));	
	}

	@Test
	public void testDeleteDeviceApplicationForAZR() throws Exception {
		BDDMockito.given(Constants.getDNS_SERVER()).willReturn(DNS_SERVERS.AZR);
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		when(resultSet.next()).thenReturn(true).thenReturn(true).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("macaddress");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		DeviceVO deviceVO = devices.deleteDeviceApplication("deviceName", "macaddress");
		assertNotNull(deviceVO);
		verify(portalDatabaseEngine, times(19)).getConnection();	
		verify(connection, times(3)).executeQuery(any(QueryVO.class));	
	}

	@Test
	public void testDeleteDeviceApplicationForJD() throws Exception {
		BDDMockito.given(Constants.getDNS_SERVER()).willReturn(DNS_SERVERS.JD);
		PowerMockito.doNothing().when(ManageDomainNameJD.class, "runCommand", any(), any(), any(), any());
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		when(resultSet.next()).thenReturn(true).thenReturn(true).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("macaddress");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		DeviceVO deviceVO = devices.deleteDeviceApplication("deviceName", "macaddress");
		assertNotNull(deviceVO);
		verify(portalDatabaseEngine, times(19)).getConnection();	
		verify(connection, times(3)).executeQuery(any(QueryVO.class));	
	}

	@Test
	public void testDeleteDeviceApplicationWhenDiscoveryDetailsNull() throws SQLException {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);

		when(resultSet.next()).thenReturn(true).thenReturn(true).thenReturn(false).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("macaddress");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		DeviceVO deviceVO = devices.deleteDeviceApplication("deviceName", "macaddress");
		assertNotNull(deviceVO);
		verify(portalDatabaseEngine, times(19)).getConnection();	
		verify(connection, times(3)).executeQuery(any(QueryVO.class));	
	}

	@Test
	public void testDeleteClusterNodeForAMZ() throws Exception {
		BDDMockito.given(Constants.getDNS_SERVER()).willReturn(DNS_SERVERS.AMZ);
		PowerMockito.doNothing().when(ManageDomainName.class, "runCommand", any(), any(), any());
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		when(resultSet.next()).thenReturn(true).thenReturn(true).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("macaddress");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		boolean isClusterNodeDeleted = devices.deleteClusterNode("nodeId", "deviceId", true);
		assertTrue(isClusterNodeDeleted);
	}

	@Test
	public void testDeleteClusterNodeForAZR() throws Exception {
		BDDMockito.given(Constants.getDNS_SERVER()).willReturn(DNS_SERVERS.AZR);
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		when(resultSet.next()).thenReturn(true).thenReturn(true).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("macaddress");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		boolean isClusterNodeDeleted = devices.deleteClusterNode("nodeId", "deviceId", true);
		assertTrue(isClusterNodeDeleted);
	}

	@Test
	public void testDeleteClusterNodeForGOO() throws Exception {
		BDDMockito.given(Constants.getDNS_SERVER()).willReturn(DNS_SERVERS.GOO);
		PowerMockito.doNothing().when(ManageDomainNameGoogle.class, "runCommand", any(), any(), any(), any());
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		when(resultSet.next()).thenReturn(true).thenReturn(true).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("macaddress");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		boolean isClusterNodeDeleted = devices.deleteClusterNode("nodeId", "deviceId", true);
		assertTrue(isClusterNodeDeleted);
	}

	@Test
	public void testDeleteClusterNodeForJD() throws Exception {
		BDDMockito.given(Constants.getDNS_SERVER()).willReturn(DNS_SERVERS.JD);
		PowerMockito.doNothing().when(ManageDomainNameJD.class, "runCommand", any(), any(), any(), any());
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		when(resultSet.next()).thenReturn(true).thenReturn(true).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("macaddress");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		boolean isClusterNodeDeleted = devices.deleteClusterNode("nodeId", "deviceId", true);
		assertTrue(isClusterNodeDeleted);
	}

	@Test
	public void testSearchDevices() throws Exception {
		when(resultSet.next()).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("macaddress");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		Map<String, Object> filters = new HashMap<>();
		Map<String, Object> searchMap = devices.searchDevices(1, 5, filters);
		assertEquals(5, searchMap.get("pageSize"));
		verify(portalDatabaseEngine, times(4)).getConnection();	
		verify(connection, times(2)).executeQuery(any(QueryVO.class));	
	}


	@Test
	public void testIsProductIDUnique() throws Exception {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		when(resultSet.next()).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("macaddress");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		Map<String, Object> isProductIdUniqueActual = devices.isProductIDUnique("productId", "hostName");
		Map<String, Object> expectedMap = new HashMap<>();
		expectedMap.put("Status", false);
		expectedMap.put("DuplicateHostName", false);
		expectedMap.put("ErrorMessage", "Duplicate productId/hostName.");
		expectedMap.put("DuplicateProductID", true);
		assertTrue(expectedMap.equals(isProductIdUniqueActual));
	}

	@Test
	public void testIsProductIDUniqueWhenIDExist() throws Exception {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		when(resultSet.next()).thenReturn(true).thenReturn(true).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("macaddress");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		Map<String, Object> isProductIdUniqueActual = devices.isProductIDUnique("productId", "hostName");
		Map<String, Object> expectedMap = new HashMap<>();
		expectedMap.put("Status", false);
		expectedMap.put("DuplicateHostName", true);
		expectedMap.put("ErrorMessage", "Duplicate productId/hostName.");
		expectedMap.put("DuplicateProductID", true);
		assertTrue(expectedMap.equals(isProductIdUniqueActual));
	}

	@Test
	public void testIsProductIDUniqueWhenHostNameNotExist() throws Exception {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		when(resultSet.next()).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("macaddress");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		Map<String, Object> isProductIdUniqueActual = devices.isProductIDUnique("productId", "hostName");
		Map<String, Object> expectedMap = new HashMap<>();
		expectedMap.put("Status", true);
		assertTrue(expectedMap.equals(isProductIdUniqueActual));
	}

	@Test
	public void testGetPlatformId() throws SQLException {
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("platformId");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		String platformId = devices.getPlatformId("deviceId");
		assertTrue("platformId".equals(platformId));
		
	}

	@Test
	public void testGetDeviceType() throws SQLException {
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("deviceId");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		DeviceTypeEnum deviceType = devices.getDeviceType("deviceId");
		assertEquals("KubernetesDevice", deviceType.name());
	}

	
	@Test
	public void testIsDeviceIdExists() throws SQLException {
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("deviceId");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		boolean isDeviceExist = devices.isDeviceExist("deviceId","userid");
		assertTrue(isDeviceExist);
	}

	@Test
	public void testIsUpdateAvilable() throws SQLException {
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("deviceId");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getBoolean(any(String.class))).thenReturn(true);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		List<String> installedAppIds = new ArrayList<>();
		installedAppIds.add("test");
		devices.isUpdateAvilable("deviceId", installedAppIds, "platformId");
	}

	// scheduleOperation

	@Test
	public void testScheduleOperation() throws Exception {
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("serverCount", 1);
		jsonObject.put("batchSize", 5);
		jsonObject.put("interval", 4L);

		PowerMockito.doReturn(file).when(devices).buildFile(any(String.class));
		when(file.exists()).thenReturn(true);
		PowerMockito.doReturn(fileReader).when(devices).buildFileReader();
		PowerMockito.doReturn(jsonParser).when(devices).buildJsonParser();
		when(jsonParser.parse(fileReader)).thenReturn(jsonObject);

		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("deviceId");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		Map<String, GroupReleaseVO> devicesMap = new HashMap<>();
		GroupReleaseVO groupReleaseVO = new GroupReleaseVO();
		groupReleaseVO.setGroupId("groupId");
		groupReleaseVO.setGrpReleaseId("groupReleaseId");
		devicesMap.put("key", groupReleaseVO);
		ApplicationUserVO appUserVO = new ApplicationUserVO();
		appUserVO.setAppId("appID");

		devices.scheduleOperation("userId", "deviceId", CommandEnum.installApplication.name(), 1l);
	}

	@Test
	public void testScheduleOperationTimerFileIsMissing() throws Exception {
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("serverCount", 1);
		jsonObject.put("batchSize", 1);
		jsonObject.put("interval", 4L);

		PowerMockito.doReturn(file).when(devices).buildFile(any(String.class));
		when(file.exists()).thenReturn(true);
		PowerMockito.doReturn(fileReader).when(devices).buildFileReader();
		PowerMockito.doReturn(jsonParser).when(devices).buildJsonParser();
		when(jsonParser.parse(fileReader)).thenReturn(jsonObject);

		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("deviceId");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		Map<String, GroupReleaseVO> devicesMap = new HashMap<>();
		GroupReleaseVO groupReleaseVO = new GroupReleaseVO();
		groupReleaseVO.setGroupId("groupId");
		groupReleaseVO.setGrpReleaseId("groupReleaseId");
		devicesMap.put("key", groupReleaseVO);
		ApplicationUserVO appUserVO = new ApplicationUserVO();
		appUserVO.setAppId("appID");

		devices.scheduleOperation("userId", "deviceId", CommandEnum.installApplication.name(), 1l);
	}

	@Test
	public void testScheduleOperationWithDeviceId() throws Exception {
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("serverCount", 1);
		jsonObject.put("batchSize", 5);
		jsonObject.put("interval", 4L);

		PowerMockito.doReturn(file).when(devices).buildFile(any(String.class));
		when(file.exists()).thenReturn(true);
		PowerMockito.doReturn(fileReader).when(devices).buildFileReader();
		PowerMockito.doReturn(jsonParser).when(devices).buildJsonParser();
		when(jsonParser.parse(fileReader)).thenReturn(jsonObject);

		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("deviceId");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		GroupReleaseVO groupReleaseVO = new GroupReleaseVO();
		groupReleaseVO.setGroupId("groupId");
		groupReleaseVO.setGrpReleaseId("groupReleaseId");

		ApplicationUserVO appUserVO = new ApplicationUserVO();
		appUserVO.setAppId("appID");

		devices.scheduleOperation("userId", "deviceId", CommandEnum.installApplication.name(), 1l);
	}

	@Test
	public void testScheduleOperationWithDeviceIdList() throws Exception {
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("serverCount", 1);
		jsonObject.put("batchSize", 1);
		jsonObject.put("interval", 4L);

		PowerMockito.doReturn(file).when(devices).buildFile(any(String.class));
		when(file.exists()).thenReturn(true);
		PowerMockito.doReturn(fileReader).when(devices).buildFileReader();
		PowerMockito.doReturn(jsonParser).when(devices).buildJsonParser();
		when(jsonParser.parse(fileReader)).thenReturn(jsonObject);

		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("deviceId");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		List<String> deviceIds = new ArrayList<>();
		deviceIds.add("deviceId");
		ApplicationUserVO appUserVO = new ApplicationUserVO();
		appUserVO.setAppId("appID");

		Map<String, String> deviceOwnerIds = new HashMap<>();
		deviceOwnerIds.put("deviceOwnerKey1", "deviceOwnerValue1");
		devices.scheduleOperation(deviceOwnerIds, deviceIds, CommandEnum.installApplication.name());
	}

	@Test
	public void testGetDeviceByHostName() throws Exception {
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("macaddress");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		DeviceVO deviceVo = devices.getDeviceByHostName("hostName");
		assertNotNull(deviceVo);
	}

	@Test
	public void testListDeviceFilter() throws Exception {
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("KubernetesCluster");
		when(resultSet.getInt(any(String.class))).thenReturn(2);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		List<FilterObject> filters = new ArrayList<>();
		FilterObject fo = new FilterObject();
		fo.setFilterkey(FilterKeysEnum.MessageType);
		fo.setFilterType(FilterType.SEARCHTEXT);
		fo.setOperator(Operator.LIKE);
		filters.add(fo);

		AuthorizationsVO authVo = new AuthorizationsVO();
		authVo.setApplicationId("appId");
		authVo.setRole(RoleEnum.Admin);
		devices.listDeviceFilter("userId", 1, 5, filters, true, OwnershipEnum.Owner, authVo);
	}

	
	@Test
	public void testRemoveNodeFromCluster() throws Exception {
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("KubernetesCluster");
		when(resultSet.getInt(any(String.class))).thenReturn(2);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		devices.removeNodeFromCluster("nodeId", "deviceId", "userId");
	}

	@Test
	public void testAddDeviceToLabels() throws Exception {
		when(connection.executeUpdatesInTransaction(any())).thenReturn(true);
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("KubernetesCluster");
		when(resultSet.getInt(any(String.class))).thenReturn(2);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		List<String> labelIds = new ArrayList<>();
		labelIds.add("testLabel");

		boolean isAdded = devices.addDeviceToLabels(labelIds, "deviceId");
		assertTrue(isAdded);
	}

	@Test
	public void testGetCount() throws Exception {
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("KubernetesCluster");
		when(resultSet.getInt(any(String.class))).thenReturn(2);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		devices.getCount();
	}

	@Test
	public void testUpdateClusterActiveMaster() throws Exception {
		when(connection.executeUpdatesInTransaction(any())).thenReturn(true);
		boolean isUpdateClusterActiveMaster = devices.updateClusterActiveMaster("nodeId");
		assertTrue(isUpdateClusterActiveMaster);
	}

	@Test
	public void testListGroupsOfDevice() throws Exception {
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("KubernetesCluster");
		when(resultSet.getInt(any(String.class))).thenReturn(2);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		List<String> groupIds = new ArrayList<>();
		groupIds.add("groupId");
		List<String> listOfGroups = devices.listGroupsOfDevice("deviceId", groupIds);
		assertEquals(1, listOfGroups.size());
	}

	@Test
	public void testListGroupsOfDevices() throws SQLException {
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("KubernetesCluster");
		when(resultSet.getInt(any(String.class))).thenReturn(2);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		List<String> groupIds = new ArrayList<>();
		groupIds.add("groupId");
		devices.listGroupsOfDevices(groupIds);
	}

	@Test(expected = Exception.class)
	public void testCheckClusterNodeExsitanceWhenDeviceNotFound() throws Exception {
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("KubernetesCluster");
		when(resultSet.getInt(any(String.class))).thenReturn(2);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		devices.checkClusterNodeExsitance("clusterId", "nodeId");
	}

	@Test
	public void testCheckClusterNodeExsitance() throws Exception {
		when(resultSet.next()).thenReturn(true).thenReturn(true).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("KubernetesCluster");
		when(resultSet.getInt(any(String.class))).thenReturn(2);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		devices.checkClusterNodeExsitance("clusterId", "nodeId");
	}
	
	@Test
	public void testListDevicesUtilities() throws SQLException {
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("KubernetesCluster");
		when(resultSet.getInt(any(String.class))).thenReturn(2);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		List<String> groupIds = new ArrayList<>();
		groupIds.add("groupId");
		Map<String, Object> deviceUtilityList = devices.listDevicesUtilities(1,5,"userId");
		assertNotNull(deviceUtilityList.get("data"));
		assertEquals(4, deviceUtilityList.size());
	}
	
	@Test
	public void testSearchDevicesUtilities() throws SQLException {
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("KubernetesCluster");
		when(resultSet.getInt(any(String.class))).thenReturn(2);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		List<String> groupIds = new ArrayList<>();
		groupIds.add("groupId");
		Map<String, String> filters = new HashMap<>();
		Map<String, Object> deviceUtilityList = devices.searchDevicesUtilities(1,5,"userId", filters);
		assertNotNull(deviceUtilityList.get("data"));
		assertEquals(4, deviceUtilityList.size());
	}
	
	
	@Test
	public void testGetUserId() throws SQLException {
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("platformId");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		String platformId = devices.getUserId("deviceId");
		assertTrue("platformId".equals(platformId));		
	}
	
	@Test
	public void testGetDevicesOwner() throws SQLException {
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("platformId");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));
		List<String> deviceIds = new ArrayList<>();
		deviceIds.add("deviceId");
		Map<String, String> deviceMap = devices.getDevicesOwner(deviceIds);
		Map<String, String> expectedMap = new HashMap<>();
		expectedMap.put("platformId", "platformId");
		assertTrue(expectedMap.equals(deviceMap));				
	}
	
	@Test
	public void testCheckDeviceExist() throws Exception {
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("platformId");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));
		List<String> deviceIds = new ArrayList<>();
		deviceIds.add("deviceId");
		devices.checkDeviceExist(deviceIds);
	}	
	
	@Test
	public void testIsSameOwnerDevice() throws SQLException {
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("platformId");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		List<String> deviceIds = new ArrayList<>();
		
		boolean isSameOwnerDevice = devices.isSameOwnerDevice(deviceIds, "userId");
		
		assertTrue(!isSameOwnerDevice);		
	}
	
	@Test
	public void testIsSameOwnerDeviceWhenDeviceIdCountSame() throws SQLException {
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("platformId");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		List<String> deviceIds = new ArrayList<>();
		deviceIds.add("deviceId");
		boolean isSameOwnerDevice = devices.isSameOwnerDevice(deviceIds, "userId");
		
		assertTrue(isSameOwnerDevice);		
	}
}
