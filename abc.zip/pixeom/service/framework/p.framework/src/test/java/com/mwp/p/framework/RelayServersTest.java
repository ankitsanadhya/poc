package com.mwp.p.framework;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.mockStatic;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.BDDMockito;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.classloader.annotations.SuppressStaticInitializationFor;
import org.powermock.modules.junit4.PowerMockRunner;

import com.mwp.common.CredProvider;
import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.common.constant.Constant;
import com.mwp.common.enums.RelayEnum.NetworkTypeEnum;
import com.mwp.common.vo.DiscoveryJarDetailsVO;
import com.mwp.common.vo.QueryVO;
import com.mwp.common.vo.ValidationInfoVO;
import com.mwp.db.Interface.IConnection;
import com.mwp.p.common.Constants;
import com.mwp.p.common.enums.DNS_SERVERS;
import com.mwp.p.common.vo.RelayServerVO;
import com.mwp.p.dal.engine.DiscoveryDetailsEngine;
import com.mwp.p.dal.engine.DiscoveryJarDetailsEngine;
import com.mwp.p.dal.engine.PortalDatabaseEngine;
import com.pa.crypto.StringEncryptionDecryption;

@RunWith(PowerMockRunner.class)
@SuppressStaticInitializationFor({ "com.mwp.p.common.Constants", "com.mwp.p.dal.engine.PortalDatabaseEngine" })
@PrepareForTest({ Constant.class, DiscoveryDetailsEngine.class, DiscoveryJarDetailsEngine.class,
	StringEncryptionDecryption.class, PortalDatabaseEngine.class, URL.class, HttpURLConnection.class, Constants.class, SqlQueryBuilder.class})
public class RelayServersTest {

	@Mock
	private PortalDatabaseEngine portalDatabaseEngine;

	@Mock
	IConnection connection;

	@Mock
	private ResultSet resultSet;

	@Mock
	private CredProvider credProvider;
	
	private RelayServers relayServers;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		mockStatic(PortalDatabaseEngine.class);
		mockStatic(StringEncryptionDecryption.class);
		mockStatic(Constant.class);
		mockStatic(Constants.class);
		relayServers = spy(new RelayServers());

		when(PortalDatabaseEngine.getInstance()).thenReturn(portalDatabaseEngine);
		when(portalDatabaseEngine.getConnection()).thenReturn(connection);

		when(connection.executeQuery(any(QueryVO.class))).thenReturn(resultSet);
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		BDDMockito.given(StringEncryptionDecryption.decrypt(any(), any())).willReturn("test");
		BDDMockito.given(StringEncryptionDecryption.encrypt(any(), any())).willReturn("test");

		BDDMockito.given(StringEncryptionDecryption.decrypt(any())).willReturn("test");
		BDDMockito.given(StringEncryptionDecryption.encrypt(any())).willReturn("test");

		PowerMockito.whenNew(CredProvider.class).withNoArguments().thenReturn(credProvider);
	}

	@After
	public void tearDown() {
		relayServers= null;
		credProvider = null;
		resultSet = null;
		connection = null;
		portalDatabaseEngine = null;
	}

	@Test
	public void testCheckIfRelayServerIsAlive() throws IOException, Exception {
		int expectedResponse = 500;

		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("deviceId");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		mockHttpConnection();

		int actualResponse = relayServers.checkIfRelayServerIsAlive("relayServerID", true, true);
		//assertThat(actualResponse, equalTo(expectedResponse));
		verify(portalDatabaseEngine, times(2)).getConnection();
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(1)).next();
	}

	@Test
	public void testCheckIfRelayServerIsAliveWhenCheckInPriorityIsFalse() throws IOException, Exception {
		int expectedResponse = 500;

		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("deviceId");
		when(resultSet.getInt(any(String.class))).thenReturn(1);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));

		mockHttpConnection();

		int actualResponse = relayServers.checkIfRelayServerIsAlive("relayServerID", true, false);
		//assertThat(actualResponse, equalTo(expectedResponse));
		verify(portalDatabaseEngine, times(3)).getConnection();
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(1)).next();
	}

	@Test
	public void testCheckIfRelayServerIsNotAlive() throws SQLException {
		int expectedResponse = 500;
		int actualResponse = relayServers.checkIfRelayServerIsAlive("relayServerID", true, true);
		//assertThat(actualResponse, equalTo(expectedResponse));
		verify(portalDatabaseEngine, times(2)).getConnection();
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(1)).next();
	}

	@Test
	public void testSetupRelayDiscoveryDetails() throws Exception {
		//Constants.DNS_SERVER = DNS_SERVERS.AZR;
		BDDMockito.given(Constants.getDNS_SERVER()).willReturn(DNS_SERVERS.AZR);
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		DiscoveryJarDetailsVO detailsVO = populateDiscoveryJarDetails();
		ValidationInfoVO infoVO = populateValidationInfoVO();
		Mockito.doReturn(200).when(relayServers).checkIfRelayServerIsAlive(Matchers.anyString(), Matchers.anyBoolean(), Matchers.anyBoolean());

		when(resultSet.next()).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false)
			.thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(true).thenReturn(false)
			.thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false)
			.thenReturn(true).thenReturn(false);
		when(connection.executeUpdate(any(String.class))).thenReturn(1);
		when(resultSet.getString(any(String.class))).thenReturn("deviceID");
		when(resultSet.getInt(any(String.class))).thenReturn(1).thenReturn(1).thenReturn(1).thenReturn(4).thenReturn(2);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));
		relayServers.setupRelayDiscoveryDetails(infoVO.getsMACAddress(), infoVO.getnStatus(), infoVO.getsGUID(),
				infoVO.getnTimestamp(), infoVO.getEmail(), infoVO.getHostName(), infoVO.getSwLicense(),
				infoVO.getHwConfig(), detailsVO.getsDeviceId(), detailsVO.getsIPAddress(),
				detailsVO.getsLocalIPAddress(), detailsVO.getsChatInputChannel(), detailsVO.getsChatOutputChannel(),
				detailsVO.getsChatSubscriptionChannel(), detailsVO.getsNodeCommunicationPort(),
				detailsVO.getsOpenStackPort(), detailsVO.getsTomcatPort(), detailsVO.getsPort1(), detailsVO.getsPort2(),
				detailsVO.getsPort3(), detailsVO.getsPort4(), detailsVO.getsPort5(), detailsVO.getsRURLTomcatPort(),
				detailsVO.getsRAddress(), detailsVO.getIsSetRURL(), detailsVO.getnStatus());
		verify(portalDatabaseEngine, times(19)).getConnection();
		verify(connection, times(2)).executeUpdate(any(QueryVO.class));
		verify(connection, times(5)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(9)).next();
		verify(resultSet, times(11)).getInt(any(String.class));
		verify(resultSet, times(63)).getString(any(String.class));
	}
	
	@Test
	public void testSetupRelayDiscoveryDetailsValidationInfoNotFound() throws Exception {
		//Constants.DNS_SERVER = DNS_SERVERS.AZR;
		BDDMockito.given(Constants.getDNS_SERVER()).willReturn(DNS_SERVERS.AZR);
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		DiscoveryJarDetailsVO detailsVO = populateDiscoveryJarDetails();
		ValidationInfoVO infoVO = populateValidationInfoVO();
		Mockito.doReturn(200).when(relayServers).checkIfRelayServerIsAlive(Matchers.anyString(), Matchers.anyBoolean(), Matchers.anyBoolean());

		when(resultSet.next()).thenReturn(false).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false)
			.thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(true).thenReturn(false)
			.thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false)
			.thenReturn(true).thenReturn(false);
		when(connection.executeUpdate(any(String.class))).thenReturn(1);
		when(resultSet.getString(any(String.class))).thenReturn("deviceID");
		when(resultSet.getInt(any(String.class))).thenReturn(1).thenReturn(1).thenReturn(1).thenReturn(4).thenReturn(2);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));
		relayServers.setupRelayDiscoveryDetails(infoVO.getsMACAddress(), infoVO.getnStatus(), infoVO.getsGUID(),
				infoVO.getnTimestamp(), infoVO.getEmail(), infoVO.getHostName(), infoVO.getSwLicense(),
				infoVO.getHwConfig(), detailsVO.getsDeviceId(), detailsVO.getsIPAddress(),
				detailsVO.getsLocalIPAddress(), detailsVO.getsChatInputChannel(), detailsVO.getsChatOutputChannel(),
				detailsVO.getsChatSubscriptionChannel(), detailsVO.getsNodeCommunicationPort(),
				detailsVO.getsOpenStackPort(), detailsVO.getsTomcatPort(), detailsVO.getsPort1(), detailsVO.getsPort2(),
				detailsVO.getsPort3(), detailsVO.getsPort4(), detailsVO.getsPort5(), detailsVO.getsRURLTomcatPort(),
				detailsVO.getsRAddress(), detailsVO.getIsSetRURL(), detailsVO.getnStatus());
		verify(portalDatabaseEngine, times(2)).getConnection();
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(1)).next();
	}
	
	@Test
	public void testSetupRelayDiscoveryDetailsWhenDeviceDetailsNotAvailable() throws Exception {
		BDDMockito.given(Constants.getDNS_SERVER()).willReturn(DNS_SERVERS.AZR);
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		DiscoveryJarDetailsVO detailsVO = populateDiscoveryJarDetails();
		ValidationInfoVO infoVO = populateValidationInfoVO();
		when(resultSet.next()).thenReturn(true).thenReturn(false).thenReturn(false).thenReturn(true).thenReturn(false)
		.thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false)
		.thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false)
		.thenReturn(true).thenReturn(false);
		
		Mockito.doReturn(200).when(relayServers).checkIfRelayServerIsAlive(Matchers.anyString(), Matchers.anyBoolean(), Matchers.anyBoolean());
		
		//when(resultSet.getString(any(String.class))).thenReturn("10.225.63.56");
		when(resultSet.getString(any(String.class))).thenReturn("deviceID");
		when(resultSet.getInt(any(String.class))).thenReturn(1).thenReturn(1).thenReturn(1).thenReturn(4).thenReturn(2);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(100));
		relayServers.setupRelayDiscoveryDetails(infoVO.getsMACAddress(), 0, "0",
				100, infoVO.getEmail(), infoVO.getHostName(), infoVO.getSwLicense(),
				infoVO.getHwConfig(), detailsVO.getsDeviceId(), detailsVO.getsIPAddress(),
				detailsVO.getsLocalIPAddress(), detailsVO.getsChatInputChannel(), detailsVO.getsChatOutputChannel(),
				detailsVO.getsChatSubscriptionChannel(), detailsVO.getsNodeCommunicationPort(),
				detailsVO.getsOpenStackPort(), detailsVO.getsTomcatPort(), detailsVO.getsPort1(), detailsVO.getsPort2(),
				detailsVO.getsPort3(), detailsVO.getsPort4(), detailsVO.getsPort5(), detailsVO.getsRURLTomcatPort(),
				detailsVO.getsRAddress(), "false", detailsVO.getnStatus());
		verify(portalDatabaseEngine, times(24)).getConnection();
		verify(connection, times(2)).executeUpdate(any(QueryVO.class));
		verify(connection, times(7)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(11)).next();		
	}
	
	@Test
	public void testSetupRelayDiscoveryDetailsWhenRelayServiceReturns500() throws Exception {
		BDDMockito.given(Constants.getDNS_SERVER()).willReturn(DNS_SERVERS.AZR);
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		DiscoveryJarDetailsVO detailsVO = populateDiscoveryJarDetails();
		ValidationInfoVO infoVO = populateValidationInfoVO();
		when(resultSet.next()).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false)
		.thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false)
		.thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false)
		.thenReturn(true).thenReturn(false);
		
		Mockito.doReturn(500).when(relayServers).checkIfRelayServerIsAlive(Matchers.anyString(), Matchers.anyBoolean(), Matchers.anyBoolean());
		
		//when(resultSet.getString(any(String.class))).thenReturn("10.225.63.56");
		when(resultSet.getString(any(String.class))).thenReturn("deviceID");
		when(resultSet.getInt(any(String.class))).thenReturn(1).thenReturn(1).thenReturn(1).thenReturn(4).thenReturn(2);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(100));
		relayServers.setupRelayDiscoveryDetails(infoVO.getsMACAddress(), 0, "0",
				100, infoVO.getEmail(), infoVO.getHostName(), infoVO.getSwLicense(),
				infoVO.getHwConfig(), detailsVO.getsDeviceId(), detailsVO.getsIPAddress(),
				detailsVO.getsLocalIPAddress(), detailsVO.getsChatInputChannel(), detailsVO.getsChatOutputChannel(),
				detailsVO.getsChatSubscriptionChannel(), detailsVO.getsNodeCommunicationPort(),
				detailsVO.getsOpenStackPort(), detailsVO.getsTomcatPort(), detailsVO.getsPort1(), detailsVO.getsPort2(),
				detailsVO.getsPort3(), detailsVO.getsPort4(), detailsVO.getsPort5(), detailsVO.getsRURLTomcatPort(),
				detailsVO.getsRAddress(), "false", detailsVO.getnStatus());
		verify(portalDatabaseEngine, times(22)).getConnection();
		verify(connection, times(2)).executeUpdate(any(QueryVO.class));
		verify(connection, times(6)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(10)).next();
		verify(resultSet, times(14)).getInt(any(String.class));
		verify(resultSet, times(66)).getString(any(String.class));
	}
	
	@Test
	public void testSetupRelayDiscoveryDetailsWhenAssignedRelayNotAvailable() throws Exception {
		BDDMockito.given(Constants.getDNS_SERVER()).willReturn(DNS_SERVERS.AZR);
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		DiscoveryJarDetailsVO detailsVO = populateDiscoveryJarDetails();
		ValidationInfoVO infoVO = populateValidationInfoVO();
		when(resultSet.next()).thenReturn(true).thenReturn(false).thenReturn(false).thenReturn(false)
		.thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false)
		.thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false)
		.thenReturn(true).thenReturn(false);
		
		Mockito.doReturn(200).when(relayServers).checkIfRelayServerIsAlive(Matchers.anyString(), Matchers.anyBoolean(), Matchers.anyBoolean());
		
		//when(resultSet.getString(any(String.class))).thenReturn("10.225.63.56");
		when(resultSet.getString(any(String.class))).thenReturn("deviceID");
		when(resultSet.getInt(any(String.class))).thenReturn(1).thenReturn(1).thenReturn(1).thenReturn(4).thenReturn(2);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(100));
		relayServers.setupRelayDiscoveryDetails(infoVO.getsMACAddress(), 0, "0",
				100, infoVO.getEmail(), infoVO.getHostName(), infoVO.getSwLicense(),
				infoVO.getHwConfig(), detailsVO.getsDeviceId(), detailsVO.getsIPAddress(),
				detailsVO.getsLocalIPAddress(), detailsVO.getsChatInputChannel(), detailsVO.getsChatOutputChannel(),
				detailsVO.getsChatSubscriptionChannel(), detailsVO.getsNodeCommunicationPort(),
				detailsVO.getsOpenStackPort(), detailsVO.getsTomcatPort(), detailsVO.getsPort1(), detailsVO.getsPort2(),
				detailsVO.getsPort3(), detailsVO.getsPort4(), detailsVO.getsPort5(), detailsVO.getsRURLTomcatPort(),
				detailsVO.getsRAddress(), detailsVO.getIsSetRURL(), detailsVO.getnStatus());
		verify(portalDatabaseEngine, times(43)).getConnection();
		verify(connection, times(6)).executeUpdate(any(QueryVO.class));
		verify(connection, times(10)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(16)).next();
		verify(resultSet, times(17)).getInt(any(String.class));
		verify(resultSet, times(70)).getString(any(String.class));
	}
	
	@Test
	public void testSetupRelayDiscoveryDetailsPortSegmentO() throws Exception {
		BDDMockito.given(Constants.getDNS_SERVER()).willReturn(DNS_SERVERS.AZR);
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		DiscoveryJarDetailsVO detailsVO = populateDiscoveryJarDetails();
		ValidationInfoVO infoVO = populateValidationInfoVO();
		when(resultSet.next()).thenReturn(true).thenReturn(false).thenReturn(false).thenReturn(false)
		.thenReturn(true).thenReturn(false).thenReturn(false).thenReturn(false)
		.thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false)
		.thenReturn(true).thenReturn(false);
		
		Mockito.doReturn(200).when(relayServers).checkIfRelayServerIsAlive(Matchers.anyString(), Matchers.anyBoolean(), Matchers.anyBoolean());
		
		//when(resultSet.getString(any(String.class))).thenReturn("10.225.63.56");
		when(resultSet.getString(any(String.class))).thenReturn("deviceID");
		when(resultSet.getInt(any(String.class))).thenReturn(1).thenReturn(1).thenReturn(1).thenReturn(4).thenReturn(2);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(100));
		relayServers.setupRelayDiscoveryDetails(infoVO.getsMACAddress(), 0, "0",
				100, infoVO.getEmail(), infoVO.getHostName(), infoVO.getSwLicense(),
				infoVO.getHwConfig(), detailsVO.getsDeviceId(), detailsVO.getsIPAddress(),
				detailsVO.getsLocalIPAddress(), detailsVO.getsChatInputChannel(), detailsVO.getsChatOutputChannel(),
				detailsVO.getsChatSubscriptionChannel(), detailsVO.getsNodeCommunicationPort(),
				detailsVO.getsOpenStackPort(), detailsVO.getsTomcatPort(), detailsVO.getsPort1(), detailsVO.getsPort2(),
				detailsVO.getsPort3(), detailsVO.getsPort4(), detailsVO.getsPort5(), detailsVO.getsRURLTomcatPort(),
				detailsVO.getsRAddress(), detailsVO.getIsSetRURL(), detailsVO.getnStatus());
		verify(portalDatabaseEngine, times(45)).getConnection();
		verify(connection, times(6)).executeUpdate(any(QueryVO.class));
		verify(connection, times(11)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(16)).next();
		verify(resultSet, times(15)).getInt(any(String.class));
		verify(resultSet, times(68)).getString(any(String.class));
	}
	
	@Test
	public void testSetupRelayDiscoveryDetailsWhenRelayServerIsDown() throws Exception {
		BDDMockito.given(Constants.getDNS_SERVER()).willReturn(DNS_SERVERS.AZR);
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		DiscoveryJarDetailsVO detailsVO = populateDiscoveryJarDetails();
		ValidationInfoVO infoVO = populateValidationInfoVO();
		when(resultSet.next()).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false)
		.thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false)
		.thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false)
		.thenReturn(true).thenReturn(false);

		Mockito.doReturn(500).doReturn(200).when(relayServers).checkIfRelayServerIsAlive(Matchers.anyString(), Matchers.anyBoolean(), Matchers.anyBoolean());

		//when(resultSet.getString(any(String.class))).thenReturn("10.225.63.56");
		when(resultSet.getString(any(String.class))).thenReturn("deviceID");
		when(resultSet.getInt(any(String.class))).thenReturn(1).thenReturn(1).thenReturn(1).thenReturn(4).thenReturn(2);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));
		relayServers.setupRelayDiscoveryDetails(infoVO.getsMACAddress(), infoVO.getnStatus(), infoVO.getsGUID(),
				infoVO.getnTimestamp(), infoVO.getEmail(), infoVO.getHostName(), infoVO.getSwLicense(),
				infoVO.getHwConfig(), detailsVO.getsDeviceId(), detailsVO.getsIPAddress(),
				detailsVO.getsLocalIPAddress(), detailsVO.getsChatInputChannel(), detailsVO.getsChatOutputChannel(),
				detailsVO.getsChatSubscriptionChannel(), detailsVO.getsNodeCommunicationPort(),
				detailsVO.getsOpenStackPort(), detailsVO.getsTomcatPort(), detailsVO.getsPort1(), detailsVO.getsPort2(),
				detailsVO.getsPort3(), detailsVO.getsPort4(), detailsVO.getsPort5(), detailsVO.getsRURLTomcatPort(),
				detailsVO.getsRAddress(), detailsVO.getIsSetRURL(), detailsVO.getnStatus());
		
		verify(connection, times(6)).executeUpdate(any(QueryVO.class));
		verify(connection, times(9)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(16)).next();
		verify(resultSet, times(21)).getInt(any(String.class));
		verify(resultSet, times(94)).getString(any(String.class));
	}
	
	@Test
	public void testSetRelayServer() throws Exception {
		BDDMockito.given(Constants.getDNS_SERVER()).willReturn(DNS_SERVERS.AZR);
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		DiscoveryJarDetailsVO detailsVO = populateDiscoveryJarDetails();
		ValidationInfoVO infoVO = populateValidationInfoVO();
		when(resultSet.next()).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false)
		.thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false)
		.thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false)
		.thenReturn(true).thenReturn(false);

		Mockito.doReturn(200).when(relayServers).checkIfRelayServerIsAlive(Matchers.anyString(), Matchers.anyBoolean(), Matchers.anyBoolean());

		when(resultSet.getString(any(String.class))).thenReturn("deviceID");
		when(resultSet.getInt(any(String.class))).thenReturn(1).thenReturn(1).thenReturn(1).thenReturn(4).thenReturn(2);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));


		relayServers.setRelayServer(infoVO.getsMACAddress(), detailsVO.getsDeviceId(), infoVO.getHostName(), detailsVO.getsIPAddress(), 
				detailsVO.getsLocalIPAddress(), detailsVO.getsChatInputChannel(), detailsVO.getsChatOutputChannel(),
				detailsVO.getsChatSubscriptionChannel(), detailsVO.getsNodeCommunicationPort(),
				detailsVO.getsOpenStackPort(), detailsVO.getsTomcatPort(), detailsVO.getsPort1(), detailsVO.getsPort2(),
				detailsVO.getsPort3(), detailsVO.getsPort4(), detailsVO.getsPort5(), detailsVO.getsRURLTomcatPort(),
				detailsVO.getsRAddress(), "false", detailsVO.getnStatus(), true);
		verify(connection, times(6)).executeUpdate(any(QueryVO.class));
		verify(connection, times(6)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(10)).next();
		verify(resultSet, times(12)).getInt(any(String.class));
		verify(resultSet, times(42)).getString(any(String.class));
	}
	
	@Test
	public void testSetRelayServerWhenEmpty() throws Exception {
		BDDMockito.given(Constants.getDNS_SERVER()).willReturn(DNS_SERVERS.AZR);
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		DiscoveryJarDetailsVO detailsVO = populateDiscoveryJarDetails();
		ValidationInfoVO infoVO = populateValidationInfoVO();
		when(resultSet.next()).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false)
		.thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false)
		.thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false)
		.thenReturn(true).thenReturn(false);
		
		Mockito.doReturn(200).when(relayServers).checkIfRelayServerIsAlive(Matchers.anyString(), Matchers.anyBoolean(), Matchers.anyBoolean());
		
		when(resultSet.getString(any(String.class))).thenReturn("deviceID");
		when(resultSet.getInt(any(String.class))).thenReturn(1).thenReturn(1).thenReturn(1).thenReturn(4).thenReturn(2);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));
		
		
		relayServers.setRelayServer(infoVO.getsMACAddress(), detailsVO.getsDeviceId(), infoVO.getHostName(), detailsVO.getsIPAddress(), 
				detailsVO.getsLocalIPAddress(), detailsVO.getsChatInputChannel(), detailsVO.getsChatOutputChannel(),
				detailsVO.getsChatSubscriptionChannel(), detailsVO.getsNodeCommunicationPort(),
				detailsVO.getsOpenStackPort(), detailsVO.getsTomcatPort(), detailsVO.getsPort1(), detailsVO.getsPort2(),
				detailsVO.getsPort3(), detailsVO.getsPort4(), detailsVO.getsPort5(), detailsVO.getsRURLTomcatPort(),
				detailsVO.getsRAddress(), "false", detailsVO.getnStatus(), false);
				verify(connection, times(6)).executeUpdate(any(QueryVO.class));
		verify(connection, times(5)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(10)).next();
		verify(resultSet, times(8)).getInt(any(String.class));
		verify(resultSet, times(23)).getString(any(String.class));
	}
	
	@Test
	public void testSetRelayServerWhenIsActivatedFalse() throws Exception {
		BDDMockito.given(Constants.getDNS_SERVER()).willReturn(DNS_SERVERS.AZR);
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		DiscoveryJarDetailsVO detailsVO = populateDiscoveryJarDetails();
		ValidationInfoVO infoVO = populateValidationInfoVO();
		when(resultSet.next()).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false)
		.thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false)
		.thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false)
		.thenReturn(true).thenReturn(false);
		
		Mockito.doReturn(200).when(relayServers).checkIfRelayServerIsAlive(Matchers.anyString(), Matchers.anyBoolean(), Matchers.anyBoolean());
		
		when(resultSet.getString(any(String.class))).thenReturn("deviceID");
		when(resultSet.getInt(any(String.class))).thenReturn(1).thenReturn(1).thenReturn(1).thenReturn(4).thenReturn(2);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));
		
		
		relayServers.setRelayServer(infoVO.getsMACAddress(), detailsVO.getsDeviceId(), infoVO.getHostName(), detailsVO.getsIPAddress(), 
				detailsVO.getsLocalIPAddress(), detailsVO.getsChatInputChannel(), detailsVO.getsChatOutputChannel(),
				detailsVO.getsChatSubscriptionChannel(), detailsVO.getsNodeCommunicationPort(),
				detailsVO.getsOpenStackPort(), detailsVO.getsTomcatPort(), detailsVO.getsPort1(), detailsVO.getsPort2(),
				detailsVO.getsPort3(), detailsVO.getsPort4(), detailsVO.getsPort5(), detailsVO.getsRURLTomcatPort(),
				detailsVO.getsRAddress(), "false", detailsVO.getnStatus(), false);
		verify(connection, times(6)).executeUpdate(any(QueryVO.class));
		verify(connection, times(5)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(10)).next();
		verify(resultSet, times(8)).getInt(any(String.class));
		verify(resultSet, times(23)).getString(any(String.class));
	}
	
	@Test
	public void testSetRelayServerWhenPortNotAvailable() throws Exception {
		BDDMockito.given(Constants.getDNS_SERVER()).willReturn(DNS_SERVERS.AZR);
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		DiscoveryJarDetailsVO detailsVO = populateDiscoveryJarDetails();
		ValidationInfoVO infoVO = populateValidationInfoVO();
		when(resultSet.next()).thenReturn(true).thenReturn(false).thenReturn(false).thenReturn(true).thenReturn(false)
		.thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false)
		.thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false)
		.thenReturn(true).thenReturn(false);

		Mockito.doReturn(200).when(relayServers).checkIfRelayServerIsAlive(Matchers.anyString(), Matchers.anyBoolean(), Matchers.anyBoolean());

		//when(resultSet.getString(any(String.class))).thenReturn("10.225.63.56");
		when(resultSet.getString(any(String.class))).thenReturn("deviceID");
		when(resultSet.getInt(any(String.class))).thenReturn(1).thenReturn(1).thenReturn(1).thenReturn(4).thenReturn(2);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));


		relayServers.setRelayServer(infoVO.getsMACAddress(), detailsVO.getsDeviceId(), infoVO.getHostName(), detailsVO.getsIPAddress(), 
				detailsVO.getsLocalIPAddress(), detailsVO.getsChatInputChannel(), detailsVO.getsChatOutputChannel(),
				detailsVO.getsChatSubscriptionChannel(), detailsVO.getsNodeCommunicationPort(),
				detailsVO.getsOpenStackPort(), detailsVO.getsTomcatPort(), detailsVO.getsPort1(), detailsVO.getsPort2(),
				detailsVO.getsPort3(), detailsVO.getsPort4(), detailsVO.getsPort5(), detailsVO.getsRURLTomcatPort(),
				detailsVO.getsRAddress(), detailsVO.getIsSetRURL(), detailsVO.getnStatus(), true);
		verify(connection, times(6)).executeUpdate(any(QueryVO.class));
		verify(connection, times(9)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(13)).next();
		verify(resultSet, times(13)).getInt(any(String.class));
		verify(resultSet, times(42)).getString(any(String.class));
	}
	
	@Test
	public void testSetupRelayJARDiscoveryDetails() throws Exception {
		BDDMockito.given(Constants.getDNS_SERVER()).willReturn(DNS_SERVERS.AZR);
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		DiscoveryJarDetailsVO detailsVO = populateDiscoveryJarDetails();
		ValidationInfoVO infoVO = populateValidationInfoVO();
		when(resultSet.next()).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false)
		.thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false)
		.thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false)
		.thenReturn(true).thenReturn(false);

		Mockito.doReturn(200).when(relayServers).checkIfRelayServerIsAlive(Matchers.anyString(), Matchers.anyBoolean(), Matchers.anyBoolean());

		when(resultSet.getString(any(String.class))).thenReturn("deviceID");
		when(resultSet.getInt(any(String.class))).thenReturn(1).thenReturn(1).thenReturn(1).thenReturn(4).thenReturn(2);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));		

		relayServers.setupRelayJARDiscoveryDetails(infoVO.getsMACAddress(), 1, infoVO.getsGUID(),
				infoVO.getnTimestamp(), infoVO.getEmail(), infoVO.getHostName(), infoVO.getSwLicense(),
				infoVO.getHwConfig(), detailsVO.getsIPAddress(),
				detailsVO.getsLocalIPAddress(), detailsVO.getsChatInputChannel(), detailsVO.getsChatOutputChannel(),
				detailsVO.getsChatSubscriptionChannel(), detailsVO.getsNodeCommunicationPort(),
				detailsVO.getsOpenStackPort(), detailsVO.getsTomcatPort(), detailsVO.getsPort1(), detailsVO.getsPort2(),
				detailsVO.getsPort3(), detailsVO.getsPort4(), detailsVO.getsPort5(), detailsVO.getsRURLTomcatPort(),
				detailsVO.getsRAddress(), detailsVO.getIsSetRURL(), detailsVO.getnStatus());
		verify(connection, times(2)).executeUpdate(any(QueryVO.class));
		verify(connection, times(5)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(10)).next();
		verify(resultSet, times(9)).getInt(any(String.class));
		verify(resultSet, times(55)).getString(any(String.class));
	}
	
	@Test
	public void testSetupRelayJARDiscoveryDetailsWhenDeviceDetailsNotAvailable() throws Exception {
		BDDMockito.given(Constants.getDNS_SERVER()).willReturn(DNS_SERVERS.AZR);
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		DiscoveryJarDetailsVO detailsVO = populateDiscoveryJarDetails();
		ValidationInfoVO infoVO = populateValidationInfoVO();
		when(resultSet.next()).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false)
		.thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false)
		.thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false)
		.thenReturn(true).thenReturn(false);
		
		Mockito.doReturn(200).when(relayServers).checkIfRelayServerIsAlive(Matchers.anyString(), Matchers.anyBoolean(), Matchers.anyBoolean());
		
		when(resultSet.getString(any(String.class))).thenReturn("deviceID");
		when(resultSet.getInt(any(String.class))).thenReturn(1).thenReturn(1).thenReturn(1).thenReturn(4).thenReturn(2);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));		
		
		relayServers.setupRelayJARDiscoveryDetails(infoVO.getsMACAddress(), 1, infoVO.getsGUID(),
				infoVO.getnTimestamp(), infoVO.getEmail(), infoVO.getHostName(), infoVO.getSwLicense(),
				infoVO.getHwConfig(), detailsVO.getsIPAddress(),
				detailsVO.getsLocalIPAddress(), detailsVO.getsChatInputChannel(), detailsVO.getsChatOutputChannel(),
				detailsVO.getsChatSubscriptionChannel(), detailsVO.getsNodeCommunicationPort(),
				detailsVO.getsOpenStackPort(), detailsVO.getsTomcatPort(), detailsVO.getsPort1(), detailsVO.getsPort2(),
				detailsVO.getsPort3(), detailsVO.getsPort4(), detailsVO.getsPort5(), detailsVO.getsRURLTomcatPort(),
				detailsVO.getsRAddress(), detailsVO.getIsSetRURL(), detailsVO.getnStatus());
				verify(connection, times(2)).executeUpdate(any(QueryVO.class));
		verify(connection, times(5)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(10)).next();
		verify(resultSet, times(9)).getInt(any(String.class));
		verify(resultSet, times(55)).getString(any(String.class));
	}
	
	@Test
	public void testSetupRelayJARDiscoveryDetailsWhenErrorMessageIsEmpty() throws Exception {
		BDDMockito.given(Constants.getDNS_SERVER()).willReturn(DNS_SERVERS.AZR);
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		DiscoveryJarDetailsVO detailsVO = populateDiscoveryJarDetails();
		ValidationInfoVO infoVO = populateValidationInfoVO();
		when(resultSet.next()).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false)
		.thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false)
		.thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false)
		.thenReturn(true).thenReturn(false);
		
		Mockito.doReturn(200).when(relayServers).checkIfRelayServerIsAlive(Matchers.anyString(), Matchers.anyBoolean(), Matchers.anyBoolean());
		
		
//		String macAddress, String deviceId, String hostName, String iPAddress, String localIPAddress, 
//		String chatInputChannel, String chatOutputChannel, String chatSubscriptionChannel, String nodeCommunicationPort, 
//		String openStackPort, String tomcatPort, String port1, String port2, String port3, String port4, String port5,
//		String rURLTomcatPort,  String rAddress, String isSetRURL, int status, boolean isActivated
//		
		
		Mockito.doReturn("").when(relayServers).setRelayServer(Matchers.anyString(), Matchers.anyString(),Matchers.anyString(),Matchers.anyString(),Matchers.anyString() ,
				Matchers.anyString(),Matchers.anyString(),Matchers.anyString(),Matchers.anyString(), 
				Matchers.anyString(),Matchers.anyString(),Matchers.anyString(),Matchers.anyString(),Matchers.anyString(),Matchers.anyString(),Matchers.anyString(),
				Matchers.anyString(), Matchers.anyString(),Matchers.anyString(), Matchers.anyInt(), Matchers.anyBoolean());
		
		when(resultSet.getString(any(String.class))).thenReturn("deviceID");
		when(resultSet.getInt(any(String.class))).thenReturn(1).thenReturn(1).thenReturn(1).thenReturn(4).thenReturn(2);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));		
		
		relayServers.setupRelayJARDiscoveryDetails(infoVO.getsMACAddress(), 1, infoVO.getsGUID(),
				infoVO.getnTimestamp(), infoVO.getEmail(), infoVO.getHostName(), infoVO.getSwLicense(),
				infoVO.getHwConfig(), detailsVO.getsIPAddress(),
				detailsVO.getsLocalIPAddress(), detailsVO.getsChatInputChannel(), detailsVO.getsChatOutputChannel(),
				detailsVO.getsChatSubscriptionChannel(), detailsVO.getsNodeCommunicationPort(),
				detailsVO.getsOpenStackPort(), detailsVO.getsTomcatPort(), detailsVO.getsPort1(), detailsVO.getsPort2(),
				detailsVO.getsPort3(), detailsVO.getsPort4(), detailsVO.getsPort5(), detailsVO.getsRURLTomcatPort(),
				detailsVO.getsRAddress(), detailsVO.getIsSetRURL(), detailsVO.getnStatus());
				verify(connection, times(2)).executeUpdate(any(QueryVO.class));
		verify(connection, times(5)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(10)).next();
		verify(resultSet, times(9)).getInt(any(String.class));
		verify(resultSet, times(55)).getString(any(String.class));
	}
	
	@Test
	public void testListsAllRelayServer() throws Exception {
		BDDMockito.given(Constants.getDNS_SERVER()).willReturn(DNS_SERVERS.AZR);
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		when(resultSet.next()).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false)
		.thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false)
		.thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false)
		.thenReturn(true).thenReturn(false);
		
		Mockito.doReturn(200).when(relayServers).checkIfRelayServerIsAlive(Matchers.anyString(), Matchers.anyBoolean(), Matchers.anyBoolean());
		
		when(resultSet.getString(any(String.class))).thenReturn("deviceID");
		when(resultSet.getInt(any(String.class))).thenReturn(1).thenReturn(1).thenReturn(1).thenReturn(4).thenReturn(2);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));		
		
		relayServers.listsAllRelayServer(false);
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(2)).next();
		verify(resultSet, times(6)).getInt(any(String.class));
		verify(resultSet, times(7)).getString(any(String.class));
	}
	
	@Test
	public void testInsertRelayServer() throws Exception {
		BDDMockito.given(Constants.getDNS_SERVER()).willReturn(DNS_SERVERS.AZR);
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		when(resultSet.next()).thenReturn(false).thenReturn(true).thenReturn(false)
		.thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false)
		.thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false)
		.thenReturn(true).thenReturn(false);
		RelayServerVO relayServerVo = populateRelayServerVO();
		Mockito.doReturn(200).when(relayServers).checkIfRelayServerIsAlive(Matchers.anyString(), Matchers.anyBoolean(), Matchers.anyBoolean());
		
		when(resultSet.getString(any(String.class))).thenReturn("deviceID");
		when(resultSet.getInt(any(String.class))).thenReturn(1).thenReturn(1).thenReturn(1).thenReturn(4).thenReturn(2);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));		
		
		relayServers.insertRelayServer(relayServerVo, false);
		verify(connection, times(1)).executeUpdate(any(QueryVO.class));
		verify(connection, times(2)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(3)).next();
		verify(resultSet, times(5)).getInt(any(String.class));
		verify(resultSet, times(7)).getString(any(String.class));
	}
	
	@Test
	public void testUpdateRelayServer() throws Exception {
		BDDMockito.given(Constants.getDNS_SERVER()).willReturn(DNS_SERVERS.AZR);
		when(connection.executeUpdate(any(QueryVO.class))).thenReturn(1);
		when(resultSet.next()).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false)
		.thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false)
		.thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false)
		.thenReturn(true).thenReturn(false);
		RelayServerVO relayServerVo = populateRelayServerVO();
		Mockito.doReturn(200).when(relayServers).checkIfRelayServerIsAlive(Matchers.anyString(), Matchers.anyBoolean(), Matchers.anyBoolean());
		
		when(resultSet.getString(any(String.class))).thenReturn("deviceID");
		when(resultSet.getInt(any(String.class))).thenReturn(1).thenReturn(1).thenReturn(1).thenReturn(4).thenReturn(2);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));		
		
		relayServers.updateRelayServer(relayServerVo, false);
		verify(connection, times(1)).executeUpdate(any(QueryVO.class));
		verify(connection, times(1)).executeQuery(any(QueryVO.class));
		verify(resultSet, times(2)).next();
		verify(resultSet, times(5)).getInt(any(String.class));
		verify(resultSet, times(7)).getString(any(String.class));
	}
	
	@Test
	public void testDeleteRelayServer() throws Exception {
		BDDMockito.given(Constants.getDNS_SERVER()).willReturn(DNS_SERVERS.AZR);
		when(connection.executeUpdatesInTransaction(any(List.class))).thenReturn(true);
		when(resultSet.next()).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false)
		.thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false)
		.thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false)
		.thenReturn(true).thenReturn(false);
		RelayServerVO relayServerVo = populateRelayServerVO();
		Mockito.doReturn(200).when(relayServers).checkIfRelayServerIsAlive(Matchers.anyString(), Matchers.anyBoolean(), Matchers.anyBoolean());
		
		when(resultSet.getString(any(String.class))).thenReturn("deviceID");
		when(resultSet.getInt(any(String.class))).thenReturn(1).thenReturn(1).thenReturn(1).thenReturn(4).thenReturn(2);
		when(resultSet.getTimestamp(any(String.class))).thenReturn(new Timestamp(2121627163136136136L));		
		
		relayServers.deleteRelayServer(relayServerVo.getsRelayServerID());
	}
	
	
	private ValidationInfoVO populateValidationInfoVO() {
		ValidationInfoVO validationInfoVO = new ValidationInfoVO();
		validationInfoVO.setsMACAddress("10.225.63.56");
		validationInfoVO.setnStatus(1);
		validationInfoVO.setsInternetAddress("10.225.63.56,10.225.63.56,10.225.63.56");
		validationInfoVO.setsGUID("10.225.63.56");
		validationInfoVO.setnTimestamp(2121627163136136136L);
		validationInfoVO.setEmail("test@email.com");
		validationInfoVO.setHostName("hostName");
		validationInfoVO.setSwLicense("swLicence");
		validationInfoVO.setHwConfig("HWConfig");
		return validationInfoVO;
	}
	
	private RelayServerVO populateRelayServerVO() {
		
		RelayServerVO relayServerVo = new RelayServerVO();
		
		relayServerVo.setsRelayServerID("relayServerID");
		relayServerVo.setsRelayServerAddress("rAddress");
		relayServerVo.setsRelayName("sRelayName");
		relayServerVo.setnPortRangeStart(1000);
		relayServerVo.setnPortRangeEnd(5000);
		relayServerVo.setsDeviceLimit("5000");
		relayServerVo.setnStatus(1);
		
		relayServerVo.setsRUserName("user");
		relayServerVo.setsRPassword("password");
		relayServerVo.setsHostKey("sHostKey");
		relayServerVo.setnRPort(1001);
		relayServerVo.setsPriority(1);

		return relayServerVo;
	}

	private DiscoveryJarDetailsVO populateDiscoveryJarDetails() {
		DiscoveryJarDetailsVO discoveryJarDetailsVO = new DiscoveryJarDetailsVO();
		discoveryJarDetailsVO.setsMACAddress("10.225.63.56,10.225.63.56,10.225.63.56");
		discoveryJarDetailsVO.setsDeviceId("deviceID");
		discoveryJarDetailsVO.setsIPAddress("10.225.63.56,10.225.63.56,10.225.63.56");
		discoveryJarDetailsVO.setsLocalIPAddress("10.225.63.56");
		discoveryJarDetailsVO.setsChatInputChannel("chatInputChannel");
		discoveryJarDetailsVO.setsChatOutputChannel("chatOutputChannel");
		discoveryJarDetailsVO.setsChatSubscriptionChannel("chatSubscriptionChannel");
		discoveryJarDetailsVO.setsNodeCommunicationPort("nodeCommunicationPort");
		discoveryJarDetailsVO.setsOpenStackPort("openStackPort");
		discoveryJarDetailsVO.setsTomcatPort("tomcatPort");
		discoveryJarDetailsVO.setsPort1("port1");
		discoveryJarDetailsVO.setsPort2("port2");
		discoveryJarDetailsVO.setsPort3("port3");
		discoveryJarDetailsVO.setsPort4("port4");
		discoveryJarDetailsVO.setsPort5("port5");
		discoveryJarDetailsVO.setsRURLTomcatPort("rURLTomcatPort");
		discoveryJarDetailsVO.setsRAddress("rAddress");
		discoveryJarDetailsVO.setnStatus(1);
		discoveryJarDetailsVO.setIsSetRURL("false");
		discoveryJarDetailsVO.setsRelayServerID("relayServerID");

		discoveryJarDetailsVO.setsNetworkType(NetworkTypeEnum.RelayNR);
		return discoveryJarDetailsVO;
	}

	private void mockHttpConnection() throws IOException, Exception {
		URL u = PowerMockito.mock(URL.class);
		PowerMockito.whenNew(URL.class).withArguments("www.google.com").thenReturn(u);
		HttpURLConnection huc = PowerMockito.mock(HttpURLConnection.class);
		PowerMockito.when(u.openConnection()).thenReturn(huc);
		PowerMockito.when(huc.getResponseCode()).thenReturn(200);
	}
}
