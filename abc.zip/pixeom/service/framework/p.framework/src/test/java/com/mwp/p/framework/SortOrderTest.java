package com.mwp.p.framework;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.mockStatic;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.classloader.annotations.SuppressStaticInitializationFor;
import org.powermock.modules.junit4.PowerMockRunner;

import com.mwp.common.CredProvider;
import com.mwp.common.constant.Constant;
import com.mwp.common.vo.QueryVO;
import com.mwp.db.Interface.IConnection;
import com.mwp.p.common.vo.SortOrderVO;
import com.mwp.p.dal.engine.PortalDatabaseEngine;


@RunWith(PowerMockRunner.class)
@SuppressStaticInitializationFor({"com.mwp.p.common.Constants","com.mwp.p.dal.engine.PortalDatabaseEngine"})
@PrepareForTest({Constant.class, PortalDatabaseEngine.class})
public class SortOrderTest {
	
	@Mock
	private PortalDatabaseEngine portalDatabaseEngine;
	
	@Mock 
	IConnection connection;

	@Mock
	private ResultSet resultSet;
	
	@Mock
	private CredProvider credProvider;	
	
	private SortOrder sortOrder;

	@Before
	public void setUp() throws SQLException {
		MockitoAnnotations.initMocks(this);
		mockStatic(PortalDatabaseEngine.class);
		mockStatic(Constant.class);
		sortOrder = spy(new SortOrder());
		when(PortalDatabaseEngine.getInstance()).thenReturn(portalDatabaseEngine);
		when(portalDatabaseEngine.getConnection()).thenReturn(connection);
		when(connection.executeQuery(any(QueryVO.class))).thenReturn(resultSet);
	}

	@After
	public void tearDown() {
		sortOrder = null;
		connection = null;
		resultSet = null;
		portalDatabaseEngine = null;
	}
	
	@Test
	public void testGetAllSortOrder() throws SQLException {
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		when(resultSet.getString(any(String.class))).thenReturn("filter");
		
		List<SortOrderVO> filterVos = sortOrder.getAllSortOrder();
		assertEquals(1, filterVos.size());
	}
}
