/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.framework;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mwp.common.constant.Constant;
import com.mwp.common.vo.DeviceVO;
import com.mwp.common.vo.LabelVO;
import com.mwp.p.dal.engine.DeviceLabelEngine;
import com.mwp.p.dal.engine.LabelEngine;

/**
 * This class manages labels.funcationality to List , delete, update labels.  
 *
 */
public class Labels {

	/**
	 * List all labels hierarchy of user.
	 * @param userId
	 * @param parentLabelId
	 * @return List<LabelVO> 
	 * @throws Exception
	 */
	public  List<LabelVO>  listLabels(String userId) throws SQLException {
		return mListLabels(userId);
	}

	private List<LabelVO> mListLabels(String userId) throws SQLException {
		LabelEngine labelEngine=new LabelEngine();
		List<LabelVO> lstLabels =  labelEngine.listLabels(userId);
		if(!lstLabels.isEmpty()){
			LabelVO root = lstLabels.stream().filter(x -> Constant.ROOT_LABEL_ID.equals(x.getLabelId())).findAny().orElse(null);
			if(root != null){
				root.setPath("");
				TreeImpl t = new TreeImpl(Constant.ROOT_PARENT_LABEL_ID);
				t.put(root);
				boolean isInserted = false;
				while(!lstLabels.isEmpty()){
					for (int i = lstLabels.size()-1; i >-1 ; i--) {
						LabelVO labelVO = lstLabels.get(i); 
						isInserted = t.put(labelVO);
						if(isInserted){
							lstLabels.remove(i);
						}
					}
				}
				parseTree(t,root);
				lstLabels = new ArrayList<>();
				lstLabels.add(root);
			}
			return lstLabels;
		}	
		else{
			return lstLabels;
		}
	}

	private void parseTree(TreeImpl t, LabelVO location) {
		LabelVO cat = (LabelVO) t.get(location.getLabelId());
		if (null != cat) {
			cat.getChildLabels().sort((LabelVO l1, LabelVO l2) -> l1.getLabelName().compareTo(l2.getLabelName()));
			List<LabelVO> l = cat.getChildLabels();
			if (null != l) {
				int length = l.size();
				for (int i = 0; i < length; i++) {
					LabelVO temp = l.get(i); 
					if(!cat.getPath().equals(""))
						temp.setPath(cat.getPath() + "/" + temp.getLabelName());
					else
						temp.setPath(temp.getLabelName());
					parseTree(t, temp);
				}
			}
		}
	}


	/**
	 * Add new label
	 * @param labelVO
	 * @return
	 * @throws Exception
	 */
	public LabelVO addLabel(LabelVO labelVO) throws SQLException {
		return mAddLabel(labelVO);
	}

	private LabelVO mAddLabel(LabelVO labelVO) throws SQLException {
		LabelEngine labelEngine=new LabelEngine();
		return labelEngine.addLabel(labelVO);
	}

	/**
	 * Edit label name of existing label
	 * @param deviceVO
	 * @return
	 * @throws Exception  if label with id not exists.
	 */
	public LabelVO editLabel(LabelVO labelVO) throws SQLException {
		return mEditLabel(labelVO);
	}

	private LabelVO mEditLabel(LabelVO labelVO) throws SQLException {
		LabelEngine labelEngine=new LabelEngine();
		return labelEngine.editLabel(labelVO);
	}


	/**
	 * Delete label along with all child labels recursive.
	 * @param labelId label id
	 * @param userId user id
	 * @return true on success, false otherwise
	 * @throws Exception
	 */
	public Boolean deleteLabel(String labelId, String userId) throws SQLException {
		return mDeleteLabel(labelId, userId);
	}

	private Boolean mDeleteLabel(String labelId, String userId) throws SQLException {
		LabelEngine labelEngine=new LabelEngine();
		labelEngine.deleteLabelRecursive(labelId, userId);
		return true;
	}

	/**
	 * Update device label. change device label id.
	 * @param labelId
	 * @param deviceId
	 * @return
	 * @throws Exception
	 */
	public DeviceVO updateDeviceLabel(String labelId,  String deviceId) throws SQLException {
		return mUpdateDeviceLabel(labelId,  deviceId);
	}

	private DeviceVO mUpdateDeviceLabel(String labelId,  String deviceId) throws SQLException {
		return new DeviceLabelEngine().updateDeviceLabel(labelId,  deviceId);
	}

	/**
	 * Add devices in label with label id.If action is move then firstly delete devices from all existing labels then add into new label with label id.
	 * @param labelId label id
	 * @param deviceIds list of devices.
	 * @param action can be move or add
	 * @throws Exception
	 */
	public void addDeviceLabel(String labelId,  List<String> deviceIds, String action) throws Exception {
		if(action.equals("move")){
			mUpdateDeviceLabel(labelId,  deviceIds);
		}else{
			new DeviceLabelEngine().addDeviceLabel(labelId, deviceIds);
		}
	}

	private void mUpdateDeviceLabel(String labelId,   List<String> deviceIds) throws Exception {
		new DeviceLabelEngine().updateDeviceLabel(labelId, deviceIds);
	}

	/**
	 * List all devices associated with labels.
	 * @param labelId 
	 * @param deviceId 
	 * @return
	 * @throws Exception
	 */
	public List<DeviceVO> getDevicesofLabel(String labelId, String userId) throws SQLException {
		return mGetDevicesofLabel(labelId, userId);
	}

	private List<DeviceVO> mGetDevicesofLabel(String labelId, String userId) throws SQLException {
		return new DeviceLabelEngine().getDeviceFromLabel(labelId, userId);
	}

	/**
	 * Delete label from device.if device has single label then shift this device to root.otherwise delete label.
	 * @param labelId
	 * @param deviceId
	 * @return
	 * @throws Exception
	 */
	public boolean deleteDeviceFromLabel(String deviceId, String labelId) throws SQLException {
		return mDeleteDeviceFromLabel(deviceId, labelId);
	}

	private boolean mDeleteDeviceFromLabel(String deviceId, String labelId) throws SQLException {
		return new DeviceLabelEngine().deleteDeviceFromLabel(deviceId, labelId);
	}

	/**
	 * Delete label from device.
	 * @param labelId
	 * @param deviceId
	 * @throws Exception
	 */
	public void deleteDeviceLabel(String labelId, String deviceId) throws SQLException{
		new DeviceLabelEngine().deleteDeviceLabel(labelId, deviceId);  
	}
}
