/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.framework;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import com.mwp.common.vo.AuthorizationsVO;
import com.mwp.common.vo.InstallJobVO;
import com.mwp.p.dal.engine.InstallJobEngine;

/**
 * This class gives functionality to list update delete jobs of a user to install/uninstall/update apps on device etc. 
 */
public class InstallJobs {

	
	/**
	 * Get all jobs added for a particular user.
	 * @param authVo
	 * @return  List<InstallJobVO>
	 * @throws SQLException 
	 */
	public  List<InstallJobVO>  getAllJobs(AuthorizationsVO authVo) throws SQLException {
		return mGetAllJobs(authVo);
	}

	private List<InstallJobVO> mGetAllJobs(AuthorizationsVO authVo) throws SQLException {
		InstallJobEngine installJobEngine=new InstallJobEngine();
		return installJobEngine.getAllJobs(authVo);
	}
	
	
	
	public boolean updateJobTimeStamp(long ticks, List<String> jobIds) throws SQLException
	{
		InstallJobEngine installJobEngine=new InstallJobEngine();
		return installJobEngine.updateJobTimeStamp( ticks, jobIds);
	}
	
	/**
	 * Delete all jobs with job id.
	 * @param jobIds list of  jobIds to be deleted  
	 * @return true if successfully deleted  false otherwise. 
	 * @throws SQLException  "no jobs found" if all jobs not exists from job list in database.  
	 */
	public boolean deleteJob(List<String> jobIds) throws SQLException//user id not required as permission already checked for user on given job ids
	{
		InstallJobEngine installJobEngine=new InstallJobEngine();
		return installJobEngine.deleteJob( jobIds);
	}
	
	/**
	 * Update status of existing job.
	 * @param jobVo jobVO 
	 * @return true if update job is successful false otherwise. 
	 * @throws SQLException 
	 */
	public boolean updateJobStatus(InstallJobVO jobVo) throws SQLException
	{
		InstallJobEngine installJobEngine=new InstallJobEngine();
		return installJobEngine.updateJobStatus(jobVo.getInstalledJobId(), jobVo.getStatus());
	}
	/**
	 * Get all jobs with PENDING from database.
	 * @param userId
	 * @param deviceId
	 * @return
	 * @throws SQLException
	 */
	public  List<InstallJobVO>  getAllPendingJobs(String userId, String deviceId) throws SQLException {
		return mGetAllPendingJobs(userId, deviceId);
	}
	
	private List<InstallJobVO> mGetAllPendingJobs(String userId, String deviceId) throws SQLException {
		InstallJobEngine installJobEngine=new InstallJobEngine();
		return installJobEngine.getAllPendingJobs(userId, deviceId);
	}
	
	public  List<InstallJobVO>  getAllPendingJobs(String deviceId) throws SQLException {
		return mGetAllPendingJobs(deviceId);
	}

	private List<InstallJobVO> mGetAllPendingJobs(String deviceId) throws SQLException {
		InstallJobEngine installJobEngine=new InstallJobEngine();
		return installJobEngine.getAllPendingJobs(deviceId);
	}
	public Map<String, List<String>> getJobOperations(List<String> jobIds) throws SQLException
	{
		InstallJobEngine installJobEngine=new InstallJobEngine();
		return installJobEngine.getJobOperations(jobIds);
	}

}
