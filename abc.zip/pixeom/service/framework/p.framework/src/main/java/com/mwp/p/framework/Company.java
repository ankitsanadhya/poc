/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.framework;

import java.sql.SQLException;
import java.util.List;

import com.mwp.common.StringFunctions;
import com.mwp.p.common.vo.CompanyInfoVO;
import com.mwp.p.dal.engine.CompanyEngine;
import com.mwp.p.dal.engine.ProjectsEngine;

/*
 * This class manages the company table information.Provides facility for list company info , get single company info, add , update etc.   
 */
public class Company {

	/**
	 * List all companies exists for single user for given user id.
	 * @param userId
	 * @return List of CompanyInfoVO objects.
	 * @throws Exception
	 */
	public List<CompanyInfoVO> list(String userId) throws SQLException {
		return mList(userId);
	}

	/**
	 * Get company info object for given comanpy id. 
	 * @param userId user id.
	 * @return List of CompanyInfoVO objects.
	 * @throws Exception
	 */
	public CompanyInfoVO get(String companyId, String userId) throws SQLException {
		return mGet(companyId, userId);
	}

	/**
	 * Check if company for given company name already exists for user. 
	 * @param companyName
	 * @param userId
	 * @return
	 * @throws Exception
	 */
	public boolean isCompanyExits(String companyName, String userId) throws SQLException {
		return mIsCompanyExits(companyName, userId);
	}
	
	/**
	 * Add new company info.
	 * @param companyInfoVO
	 * @return CompanyInfoVO object.
	 * @throws Exception
	 */
	public CompanyInfoVO add(CompanyInfoVO companyInfoVO) throws Exception {
		return mAdd(companyInfoVO);
	}

	/**
	 * update information of existing company information.
	 * @param companyInfoVO
	 * @param userId user id.
	 * @return
	 * @throws Exception "no company found" if company with given id not exists. 
	 */
	public CompanyInfoVO update(CompanyInfoVO companyInfoVO, String userId) throws Exception {
		return mUpdate(companyInfoVO, userId);
	}

	/**
	 * delete a company info with given company id.
	 * @param companyId
	 * @param userId
	 * @return
	 * @throws Exception
	 */
	public CompanyInfoVO delete(String companyId, String userId) throws Exception {
		return mDelete(companyId, userId);
	}

	private List<CompanyInfoVO> mList(String userId) throws SQLException {
		CompanyEngine companyEngine = new CompanyEngine();

		return companyEngine.list(userId);
	}

	private CompanyInfoVO mGet(String companyId, String userId) throws SQLException {
		CompanyEngine companyEngine = new CompanyEngine();

		return companyEngine.get(companyId, userId);
	}

	private boolean mIsCompanyExits(String companyName, String userId) throws SQLException {
		CompanyEngine companyEngine = new CompanyEngine();

		return companyEngine.isCompanyExits(companyName, userId);
	}

	private CompanyInfoVO mAdd(CompanyInfoVO companyInfoVO) throws Exception {
		CompanyEngine companyEngine = new CompanyEngine();
		boolean isCompanyExits = companyEngine.isCompanyExits(companyInfoVO.getName(), companyInfoVO.getUserId());
		if(isCompanyExits){
			throw new Exception("Company with same name already exists.");
		} else {
			return companyEngine.add(companyInfoVO);
		}
	}

	private CompanyInfoVO mUpdate(CompanyInfoVO companyInfoVO, String userId) throws Exception {
		CompanyEngine companyEngine = new CompanyEngine();

		if(StringFunctions.isNullOrWhitespace(companyInfoVO.getCompanyId())){
			throw new Exception("No company found.");
		} else if(companyEngine.get(companyInfoVO.getCompanyId(), userId) == null) {
			throw new Exception("No company found.");
		} else {
			return companyEngine.update(companyInfoVO);
		}
	}

	private CompanyInfoVO mDelete(String companyId, String userId) throws Exception {
		CompanyEngine companyEngine = new CompanyEngine();
		ProjectsEngine projectsEngine = new ProjectsEngine();
		if(projectsEngine.projectExits(companyId)){
			throw new Exception("Company can not be deleted.");
		} else {
			return companyEngine.delete(companyId, userId);
		}
	}

	
}
