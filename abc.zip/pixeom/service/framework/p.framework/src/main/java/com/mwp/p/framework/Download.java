/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.framework;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.MediaType;

import org.apache.commons.io.FileUtils;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.mwp.common.Common;
import com.mwp.common.CredProvider;
import com.mwp.common.GCSSignUrl;
import com.mwp.common.StringFunctions;
import com.mwp.common.TempFiles;
import com.mwp.common.constant.Constant;
import com.mwp.logger.PALogger;
import com.mwp.p.common.Constants;
import com.mwp.p.common.vo.DownloadResourceVO;
import com.mwp.p.common.vo.DownloadVO;
import com.mwp.p.common.vo.SoftwareUpdatesVO;
import com.mwp.p.dal.engine.DownloadsEngine;
import com.pa.crypto.FileEncryptionDecryption;
import com.pa.crypto.StringEncryptionDecryption;

/**
 * This class provides facility to download the file from given path and get url of download path.
 *
 */
public class Download 
{	
	/**
	 * Push file for download and execute command to dosnload file to link folder.
	 * @param path the file path to be downlaoded 
	 * @return link of the file to access the downloaded file. 
	 * @throws Exception
	 */
	public String getUrl(String resourceId,String password) throws Exception {
		return mGetUrl(resourceId,password);
	}


	/**
	 * Push file for download and execute command to dosnload file to link folder.
	 * @param path the file path to be downlaoded 
	 * @return link of the file to access the downloaded file. 
	 * @throws Exception
	 */
	public String getUrl(String resourceId) throws Exception {
		return mGetUrl(resourceId, "");
	}
	
	
	public String getFunctionUrl(String functionId,String  functionVersionId) throws IOException, InterruptedException  {
		return mGetFunctionUrl(functionId,functionVersionId);
	}



	public String downloadFile(String secureToken) throws Exception {
		return mDownloadFile(secureToken);
	}

	/*public String getSoftWareUpdates() throws Exception {
		return mgetSoftWareUpdates();
	}*/

	/**
	 * delete all entries from tokens which have been timed out.
	 */
	public void cleanUpTokens() {
		mCleanUpTokens();
	}
	
	
	public void writeFile(String filePath,HttpServletResponse response  ) throws IOException {
		
		File file = buildFile(filePath);

		if(!file.exists()) {
			throw new IOException(Constant.NOTFOUND);
		}

		response.setContentType(MediaType.APPLICATION_OCTET_STREAM);
		response.setStatus(HttpServletResponse.SC_OK);
		response.setHeader("content-disposition", "attachment; filename=" + file.getName());
		response.addHeader("Content-Length", Long.toString(file.length()));

		FileInputStream input = buildFileInputStream(file);
		byte[] buffer = new byte[32000];
		int read = 0;
		try {
			while ((read = input.read(buffer)) != -1) {
				response.getOutputStream().write(buffer,0,read);
				response.getOutputStream().flush();
			}
		} finally {
			input.close();
		}

		response.getOutputStream().flush();
		response.getOutputStream().close();
	}


	public FileInputStream buildFileInputStream(File file) throws FileNotFoundException {
		return new FileInputStream(file);
	}

	public DownloadResourceVO  add(DownloadResourceVO resourceVO)  throws SQLException 
	{
		return mAdd(resourceVO);
	}
	
	public DownloadResourceVO  edit(DownloadResourceVO resourceVO)  throws SQLException 
	{
		return mEdit(resourceVO);
	}
	
	public void  updateSortOrder(Map<String, Integer> idOrderMap) throws SQLException 
	{
		mUpdateSortOrder(idOrderMap);
	}
	
	public void  delete(String resourceId)  throws SQLException 
	{
		mDelete(resourceId);
	}
	
	public List<DownloadResourceVO> listResouces(String resourceType)throws SQLException 
	{
		return mListresources(resourceType);
	}
	
	public List<DownloadResourceVO> listResoucesInGroups(List<String> groupIds, String resourceType)throws SQLException 
	{
		return  mListInvitedResouces(groupIds, resourceType);
	}


	private String mGetFunctionUrl(String functionId,String  functionVersionId) throws IOException, InterruptedException {
		

		String filePath = Constants.PORTAL_FILES_PATH + Constants.PORTAL_FUNCTION_FOLDER_NAME + Constant.localFileSeparator +functionId + Constant.localFileSeparator+ functionVersionId+".zip";

		String tempDecPath =TempFiles.getTempFolderPath() + functionVersionId+".zip";
		FileEncryptionDecryption.Decrypt_File(filePath, tempDecPath, buildCredProvider().getEcnKey());

		
		File file = buildFile(tempDecPath);

		if(!file.exists()) {
			throw new IOException(Constant.NOTFOUND);
		}


		String secureToken = Common.getRandomId();

		String filePathDownload = Constants.PORTAL_CACHE_PATH  + Constants.DOWNLOAD_ASSETS_FOLDER_NAME  + "/links" + Constant.localFileSeparator + secureToken + Constant.localFileSeparator;
		File fPath = buildFile(filePathDownload);
		fPath.mkdir();

		filePathDownload += file.getName(); 

		List<String> command = new ArrayList<>();
		command.add("ln");
		command.add("-sf");
		command.add(tempDecPath);
		command.add(filePathDownload);
		Common.executeCommnad(command);

		long timeout = System.currentTimeMillis() + 60000;

		DownloadVO downloadVO = new DownloadVO(filePathDownload, timeout);

		Constants.getDownloadTokens().put(secureToken, downloadVO);

		return Constants.AUTH_SERVER_IP_PORT + Constants.UI_FOLDER_NAME + "/" + Constants.PORTAL_DATA_FOLDER_NAME  + "/" + Constants.DOWNLOAD_ASSETS_FOLDER_NAME  + "/links/" + secureToken + "/" + file.getName();

	}

	private String mGetUrl(String resourceId, String password) throws Exception {
		
		String basePath = "";
		
		DownloadResourceVO resource = new DownloadsEngine().getResource(resourceId);		
		GsonBuilder builder = new GsonBuilder();  
		builder.excludeFieldsWithoutExposeAnnotation();  
		Gson gson = builder.create();

		SoftwareUpdatesVO  updates = gson.fromJson(resource.getDetails(), SoftwareUpdatesVO.class);
		if(updates.isPwdRequired())	{
			String passwordStr = Common.toSHA256Hash(password);
			if(StringFunctions.isNullOrWhitespace(password) || !StringEncryptionDecryption.decrypt(updates.getPassword(),buildCredProvider().getEcnKey()).equals(passwordStr))			{
				throw new Exception(Constant.INCORRECTLOGIN);			
			}
		}
		
		if(!updates.isExternalDownload())
		{
			basePath = Constants.PORTAL_FILES_PATH + Constants.DOWNLOAD_ASSETS_FOLDER_NAME + Constant.localFileSeparator;

			String filePath =  basePath + updates.getKey();
			File file = buildFile(filePath);

			if(!file.exists()) {
				throw new IOException(Constant.NOTFOUND);
			}

			String secureToken = Common.getRandomId();

			String filePathDownload = Constants.PORTAL_CACHE_PATH  + Constants.DOWNLOAD_ASSETS_FOLDER_NAME  + "/links" + Constant.localFileSeparator + secureToken + Constant.localFileSeparator;
			File fPath = buildFile(filePathDownload);
			fPath.mkdir();

			filePathDownload += file.getName(); 

			List<String> command = new ArrayList<>();
			command.add("ln");
			command.add("-sf");
			command.add(filePath);
			command.add(filePathDownload);
			Common.executeCommnad(command);

			long timeout = System.currentTimeMillis() + 60000;

			DownloadVO downloadVO = new DownloadVO(filePathDownload, timeout);

			Constants.getDownloadTokens().put(secureToken, downloadVO);

			return Constants.AUTH_SERVER_IP_PORT + Constants.UI_FOLDER_NAME + "/" + Constants.PORTAL_DATA_FOLDER_NAME  + "/" + Constants.DOWNLOAD_ASSETS_FOLDER_NAME  + "/links/" + secureToken + "/" + file.getName();
		}
		else
		{
			String filePath =  basePath + updates.getCloudPath();

			URL url = buildGCSSignUrl().getGCSSignUrl(filePath, updates.getAccessKey(), updates.getSecretKey());
			String filePathDownload  = url.toString();

			long timeout = System.currentTimeMillis() + 60000;
			DownloadVO downloadVO = new DownloadVO(filePathDownload, timeout);

			String secureToken = Common.getRandomId();

			Constants.getDownloadTokens().put(secureToken, downloadVO);
			return filePathDownload; 
		}
	}

	private String mDownloadFile(String secureToken) throws Exception {

		DownloadVO downloadVO = Constants.getDownloadTokens().get(secureToken);

		if(downloadVO != null && downloadVO.getTimeout() > System.currentTimeMillis()) {
			return Constants.PORTAL_FILES_PATH + Constants.DOWNLOAD_ASSETS_FOLDER_NAME + Constant.localFileSeparator + downloadVO.getPath();
		}

		throw new Exception(Constant.UNAUTHORIZED);
	}

	private void mCleanUpTokens() {
		@SuppressWarnings("unchecked")
		Map<String, DownloadVO> downloadAuthClone = (Map<String, DownloadVO>) Constants.getDownloadTokens().clone();

		for (Entry<String, DownloadVO> entry : downloadAuthClone.entrySet()) {
			DownloadVO downloadVO = entry.getValue();

			if(downloadVO.getTimeout() < System.currentTimeMillis()) {
				File toDelete = buildFile(downloadVO.getPath());
				if(toDelete.exists()) {
					FileUtils.deleteQuietly(toDelete);
					try {
						FileUtils.deleteDirectory(toDelete.getParentFile());
					} catch (IOException e) {
						PALogger.ERROR(e);	
					}
				}

				Constants.getDownloadTokens().remove(entry.getKey());
			}
		}
	}
	
	private DownloadResourceVO  mAdd(DownloadResourceVO resourceVO)  throws SQLException 
	{
		DownloadsEngine engg= new DownloadsEngine();
		return engg.add(resourceVO);
	}
	
	private DownloadResourceVO  mEdit(DownloadResourceVO resourceVO)  throws SQLException 
	{
		DownloadsEngine engg= new DownloadsEngine();
		return engg.edit(resourceVO);
	}
	
	private void  mUpdateSortOrder(Map<String, Integer> idOrderMap) throws SQLException 
	{
		DownloadsEngine engg= new DownloadsEngine();
		 engg.updateSortOrder(idOrderMap);
	}
	
	private void  mDelete(String resourceId)  throws SQLException 
	{
		DownloadsEngine engg= new DownloadsEngine();
		engg.delete(resourceId);
	}
	
	private List<DownloadResourceVO> mListresources(String resourceType)throws SQLException 
	{
		DownloadsEngine engg= new DownloadsEngine();
		return engg.listResouces(resourceType);
	}
	
	private List<DownloadResourceVO> mListInvitedResouces(List<String> groupIds, String resourceType)throws SQLException 
	{
		DownloadsEngine engg= new DownloadsEngine();
		return engg.listInvitedResouces(groupIds, resourceType);
	}
	
	public GCSSignUrl buildGCSSignUrl() {
		return new GCSSignUrl();
	}


	public File buildFile(String filePath) {
		return new File(filePath);
	}
	
	public CredProvider buildCredProvider() {
		return new CredProvider();
	}
}