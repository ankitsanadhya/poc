/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.framework;

import java.sql.SQLException;
import java.util.List;

import com.mwp.common.vo.ApplicationVO;
import com.mwp.p.common.vo.ProjectVO;
import com.mwp.p.dal.engine.ProjectsEngine;

/**
 * This class manages projects. 
 */
public class Projects {

	/**
	 * Return a {@link ProjectVO} object
	 * <p>
	 * This method add project info.
	 * <p>
	 * @param projectVO
	 * @return
	 * @throws Exception 
	 */
	public ProjectVO addProject(ProjectVO projectVO) throws SQLException {
		return mAddProject(projectVO);
	}

	/**
	 * list all projects for as user
	 * @return  List<ProjectVO> 
	 * @throws Exception 
	 */
	public List<ProjectVO> listProject(String userId) throws SQLException {
		return mListProject(userId);
	}



	/**
	 * update existing project in database 
	 * @param projectVO
	 * @return
	 * @throws Exception 
	 */
	public ProjectVO updateProject(ProjectVO projectVO) throws SQLException {
		return mUpdateProject(projectVO);

	}

	/**
	 * Delete project with project id. 
	 * @param projectId
	 * @param userId user id of user which came for delete request
	 * @throws Exception 
	 */
	public void deleteProject(String projectId,String userId) throws SQLException {
		mDeleteProject(projectId,userId);
	}

	/**
	 * List of applications of a project
	 * @param projectId
	 * @return List<ApplicationVO>
	 * @throws Exception 
	 */
	public List<ApplicationVO> listProjectApps(String projectId,String userId) throws SQLException {
		return mListProjectApps(projectId,userId);
	}

	/**
	 * Get detail of project
	 * @param projectId
	 * @return ProjectVO object
	 * @throws Exception 
	 */
	public ProjectVO getProjectDetail(String projectId) throws SQLException {	
		return mGetProjectDetail(projectId);

	}

	/**
	 * Get number of projects of particular user.
	 * @param userId
	 * @throws Exception
	 */
	public int projectCount(String userId) throws SQLException {
		return mProjectCount(userId);
	}


	private ProjectVO mGetProjectDetail(String projectId) throws SQLException {
		ProjectsEngine projectsEngine =new ProjectsEngine();
		return projectsEngine.getProjectDetail(projectId);
	}

	private ProjectVO mAddProject(ProjectVO projectVO) throws SQLException {
		ProjectsEngine projectsEngine =new ProjectsEngine();
		return projectsEngine.addProject(projectVO);
	}

	private List<ProjectVO> mListProject(String userId) throws SQLException {
		ProjectsEngine projectsEngine =new ProjectsEngine();
		return projectsEngine.listProject(userId);
	}



	private ProjectVO mUpdateProject(ProjectVO projectVO) throws SQLException {
		ProjectsEngine projectsEngine =new ProjectsEngine();
		return projectsEngine.updateProject(projectVO);
	}

	private void mDeleteProject(String projectId,String userId) throws SQLException {
		ProjectsEngine projectsEngine =new ProjectsEngine();
		projectsEngine.deleteProject(projectId,userId);
	}

	private List<ApplicationVO> mListProjectApps(String projectId,String userId) throws SQLException {
		ProjectsEngine projectsEngine =new ProjectsEngine();
		return projectsEngine.listProjectApps(projectId,userId);
	}

	private int mProjectCount(String userId) throws SQLException {
		ProjectsEngine projectsEngine =new ProjectsEngine();
		return projectsEngine.projectCount(userId);
	}

}
