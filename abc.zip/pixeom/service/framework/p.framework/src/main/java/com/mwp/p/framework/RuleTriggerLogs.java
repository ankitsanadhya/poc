/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.framework;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import com.mwp.common.enums.RuleStatus;
import com.mwp.common.enums.RuleType;
import com.mwp.common.vo.RuleTriggerLogVO;
import com.mwp.p.dal.engine.RuleTriggerLogEngine;

/**
 * Manages rule Trigger logs in insert/ List  etc.   
 *
 */
public class RuleTriggerLogs
{
	/**
	 * add rule Trigger logs 
	 * @param logs
	 * @return
	 * @throws SQLException
	 */
	public String insert( String ruleId,  RuleStatus status,String data) throws SQLException
	{
		return mInsert( ruleId,  status,data);
	}



	/**
	 * List all Activity Log
	 * @return
	 * @throws SQLException
	 */
	public List<RuleTriggerLogVO> listEvent()throws SQLException
	{
		return mListEvent();
	}

	/**
	 *  List Activity Log of last <numberofdays>
	 * @param numberofdays
	 * @return
	 * @throws SQLException
	 */
	public List<RuleTriggerLogVO> listByTime(int numberofdays) throws SQLException
	{
		return mListByTime(numberofdays);
	}

	/**
	 * List Activity Logs using paging
	 * @param pageNo page number
	 * @param pageSize number of events in a page result
	 * @return  HashMap<String, Object> with keys totalPages, pageSize, pageNumber, data . data is List<RuleTriggerLogVO> 
	 * @throws SQLException
	 */
	public Map<String, Object> listByPage(int pageNo,int pageSize) throws SQLException
	{
		return mListByPage(pageNo,pageSize);
	}
	
	public RuleTriggerLogVO update(String id,RuleStatus status, int stage , String info) throws SQLException 
	{
		return mUpdate(id,  status, stage, info);
	}
	
	public RuleTriggerLogVO get(String id) throws SQLException 
	{
		return mGet(id);
	}
	public RuleTriggerLogVO getLatestrecord(String ruleId) throws SQLException 
	{
		return mgetLatestrec(ruleId);
	}
	public List<RuleTriggerLogVO> list(RuleType type)  throws SQLException 
	{
		return mList(type);
	}
	
	public List<RuleTriggerLogVO> list()  throws SQLException 
	{
		return mListlog();
	}
	
	private List<RuleTriggerLogVO> mList(RuleType type) throws SQLException
	{
		RuleTriggerLogEngine engg = new RuleTriggerLogEngine();
		return engg.list(type);
	}
	
	private List<RuleTriggerLogVO> mListlog() throws SQLException
	{
		RuleTriggerLogEngine engg = new RuleTriggerLogEngine();
		return engg.listlog();
	}
	
	private RuleTriggerLogVO mgetLatestrec(String ruleId) throws SQLException {
		RuleTriggerLogEngine engg = new RuleTriggerLogEngine();
		return engg.getLatestrec(ruleId);
	}


	private String mInsert(String ruleId, RuleStatus status,String data) throws SQLException 
	{
			RuleTriggerLogEngine engg = new RuleTriggerLogEngine();
			return  engg.insert(ruleId, status,data);
	}

	private List<RuleTriggerLogVO> mListEvent() throws SQLException
	{
		RuleTriggerLogEngine engg = new RuleTriggerLogEngine();
		return engg.list();
	}
	private List<RuleTriggerLogVO> mListByTime(int numberofdays) throws SQLException
	{
		RuleTriggerLogEngine engg = new RuleTriggerLogEngine();
		return engg.listByTime(numberofdays);
	}

	private Map<String, Object> mListByPage(int pageNo, int pageSize) throws SQLException
	{
		RuleTriggerLogEngine engg = new RuleTriggerLogEngine();
		return engg.listByPage(pageNo,pageSize);
	}
	
	private RuleTriggerLogVO mUpdate(String id, RuleStatus status, int stage , String info) throws SQLException 
	{
		RuleTriggerLogEngine engg = new RuleTriggerLogEngine();
		return engg.update(id, status, stage, info);
	}
	private RuleTriggerLogVO mGet(String id) throws SQLException 
	{
		RuleTriggerLogEngine engg = new RuleTriggerLogEngine();
		return engg.getlog(id);
	}
}
