/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.framework;


import java.io.IOException;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import org.threeten.bp.Duration;

import com.google.api.gax.retrying.RetrySettings;
import com.google.cloud.dns.ChangeRequestInfo;
import com.google.cloud.dns.Dns;
import com.google.cloud.dns.DnsOptions;
import com.google.cloud.dns.RecordSet;
import com.google.cloud.dns.Zone;
import com.mwp.common.StringFunctions;
import com.mwp.logger.PALogger;
import com.mwp.p.common.Constants;

public class ManageDomainNameGoogle
{

	public enum DomainOperation 
	{
		Add,
		Delete,
		Edit;
	}

	public static void main(String[] args) {
		runCommand(DomainOperation.Add, "p-rs56", "35.197.92.79", "");
	}

	static ThreadPoolExecutor parallelExecutor;
	 
	static
	{
		parallelExecutor = new ThreadPoolExecutor(5, 5, 
		    60L, TimeUnit.SECONDS,
		    new LinkedBlockingQueue<Runnable>());
		
		parallelExecutor.allowCoreThreadTimeOut(true);
	}
	
	/**
	 * 
	 * @param command
	 * @param deviceName
	 * @param ipAddress
	 * @param ipAddressOld only required in edit operation
	 */
	public static void runCommand(final DomainOperation command, final String deviceName, final String ipAddress, final String ipAddressOld)                                     
	{		
		parallelExecutor.execute(new Runnable() {
			public void run() 
			{
				mRunCommand(command, deviceName, ipAddress, ipAddressOld);
			}			
		});
	}

	private static Zone login() throws IOException
	{
		String serviceAccountFile = "/opt/app_engine/sc.json";
		com.google.cloud.dns.DnsOptions.Builder b =  DnsOptions.newBuilder();
		b.setCredentials(new PxGCredProvider(serviceAccountFile).getCredentials());
		
		b.setProjectId(Constants.getProjectName());
		RetrySettings retrySettings = RetrySettings.newBuilder()
				.setMaxAttempts(6)
				.setInitialRetryDelay(Duration.ofMillis(1000L))
				.setMaxRetryDelay(Duration.ofMillis(32000L))
				.setRetryDelayMultiplier(2.0)
				.setTotalTimeout(Duration.ofMillis(50000L))
				.setInitialRpcTimeout(Duration.ofMillis(50000L))
				.setRpcTimeoutMultiplier(1.0)
				.setMaxRpcTimeout(Duration.ofMillis(50000L)).build();
		b.setRetrySettings(retrySettings);
		Dns dns = b.build().getService();
		return dns.getZone(Constants.getDNSZone());
	}



	private static void mRunCommand(DomainOperation command, String deviceName, String ipAddress,String ipAddressOld){
		int retryCount = 3;
		int retry = 0;
		PALogger.INFO("Command: "+command);
		PALogger.INFO("deviceName: "+deviceName);
		PALogger.INFO("ipAddress: "+ipAddress);
		PALogger.INFO("ipAddressOld: "+ipAddressOld);
		while(retry < retryCount)
		{
			try
			{
				retry++;
				Zone zone = login();
				RecordSet toCreate = null;
				RecordSet toDelete =null;
				//add recordset
				switch (command) 
				{
				case Add:
					toCreate = RecordSet.newBuilder(deviceName + "." + zone.getDnsName(), RecordSet.Type.A)
					.setTtl(300, TimeUnit.SECONDS)
					.addRecord(ipAddress)
					.build();
					break;
				case Delete:
					toDelete = RecordSet.newBuilder(deviceName + "." + zone.getDnsName(), RecordSet.Type.A)
					.setTtl(300, TimeUnit.SECONDS)
					.addRecord(ipAddress)
					.build();
					break;
				case Edit:
					if(!StringFunctions.isNullOrWhitespace(ipAddressOld) && !ipAddressOld.equals(ipAddress) ){
						toDelete = RecordSet.newBuilder(deviceName + "." + zone.getDnsName(), RecordSet.Type.A)
								.setTtl(300, TimeUnit.SECONDS)
								.addRecord(ipAddressOld)
								.build();
					}
					toCreate = RecordSet.newBuilder(deviceName + "." + zone.getDnsName(), RecordSet.Type.A)
							.setTtl(300, TimeUnit.SECONDS)
							.addRecord(ipAddress)
							.build();
					break;
				default:
					break;
				}
				//make change request
				ChangeRequestInfo.Builder changeBuilder = ChangeRequestInfo.newBuilder();
				if(toDelete!= null)
					changeBuilder.delete(toDelete);  
				if(toCreate!= null)
					changeBuilder.add(toCreate);

				// Build and apply the change request to our zone
				ChangeRequestInfo changeRequest = changeBuilder.build();
				zone.applyChangeRequest(changeRequest);
				break;

			}
			catch (Exception exe)
			{	
				PALogger.ERROR(exe);	
				if(exe.getMessage()!= null && exe.getMessage().contains("already exists"))
					break;
			
				try
				{
					if(retry == retryCount)
						break;
					Thread.sleep(5000);
				}
				catch (InterruptedException e) 
				{
					PALogger.ERROR(e);
					//Thread.currentThread().interrupt();			
				}
			}
		}
	}
}
