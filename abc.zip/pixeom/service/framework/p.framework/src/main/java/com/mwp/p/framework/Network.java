/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.mwp.p.framework;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.mwp.common.enums.FilterType;
import com.mwp.common.enums.NetworkTypeEnum;
import com.mwp.common.enums.Operator;
import com.mwp.common.enums.SortKeysEnum;
import com.mwp.common.vo.FilterObject;
import com.mwp.common.vo.NetworkVO;
import com.mwp.p.dal.engine.ApplicationNetworkEngine;
import com.mwp.p.dal.engine.NetworkEngine;

public class Network 
{

	public NetworkVO createNetwork(String networkName, String userId, NetworkTypeEnum networkType)throws SQLException
	{
		return mCreateNetwork( networkName, userId, networkType);
	}
	public Map<String, Object>  listNetworkFilter(List<FilterObject> filterObjects,long pageNo, int pageSize,String userId) throws SQLException
	{
		return mListNetworkFilter(filterObjects, pageNo, pageSize, userId);
	}
	public void delete(String networkId) throws SQLException
	{
		 mDelete(networkId);
	}
	public void update(String networkId,String networkName)throws SQLException
	{
		mUpdate(networkId, networkName);
	}

	public void linkApp(String appId,String networkId)throws SQLException
	{
		mLinkApp(appId,networkId);
	}
	
	
	private NetworkVO mCreateNetwork(String networkName, String userId, NetworkTypeEnum networkType)throws SQLException
	{
		NetworkEngine engg= new NetworkEngine();
		return engg.createNetwork(networkName, userId, networkType);
		
	}
	private Map<String, Object> mListNetworkFilter(List<FilterObject> filterObjects, long pageNo, int pageSize,
			String userId) throws SQLException
	{
		NetworkEngine engg= new NetworkEngine();
		return engg.listNetworkFilter(filterObjects, pageNo, pageSize, userId);
	}
	private void mDelete(String networkId) throws SQLException
	{
		NetworkEngine engg= new NetworkEngine();
		engg.delete(networkId);
		
	}
	private void mUpdate(String networkId, String networkName)throws SQLException {
		NetworkEngine engg= new NetworkEngine();
		engg.update(networkId, networkName);
		
	}
	private void mLinkApp(String appId,String networkId)throws SQLException
	{
		ApplicationNetworkEngine engg= new ApplicationNetworkEngine();
		engg.linkApp(appId,networkId);
	}
}
