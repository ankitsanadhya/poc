/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.framework;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import com.mwp.common.vo.ApplicationVO;
import com.mwp.common.vo.DeviceVO;
import com.mwp.p.common.enums.ResourceType;
import com.mwp.p.dal.engine.GroupsEngine;

/**
 * This class manage Group-Application relation and their versions,
 * List group of application, add/delete/update group-application relation, add application versions,
 * @author root
 *
 */
public class Groups {

	/**
	 * List group of application according to given groupId.
	 * @param groupId
	 * @return
	 * @throws Exception 
	 */
	public List<ApplicationVO> listGroupApp(String groupId) throws SQLException {
		return mlistGroupApp(groupId);

	}

	/**
	 * Add an application to group.
	 * before add we check relation of group-application already exist in db or not,
	 * if exist then we throw exception on UI. 
	 * @param appId application id.
	 * @param groupId group id
	 * @param versionIds if version id is null or empty then application will be added in group otherwise app versions also will be added to group.
	 * @throws Exception application already exists in group then throw exception.
	 */
	public void addAppToGroup(String appId, String groupId, List<String> versionIds) throws SQLException {
		maddAppToGroup(appId, groupId,versionIds);
	}

	/**
	 * Remove an application from a given group.also removes all the version entries of application added to group.
	 * @param appId
	 * @param groupId
	 * @param versions
	 * @throws Exception 
	 */
	public void removeAppToGroup(String appId, String groupId
			) throws SQLException {
		mremoveAppToGroup(appId, groupId);

	}

	/**
	 * update application-version relation add/delete applicationversion entry according to versionIds HashMap of (String-boolean),
	 * which have versionId in key and true/false means (ADD/DELETE) boolean in value.
	 * @param appId
	 * @param groupId
	 * @param versionIdsWithOperation
	 * @throws Exception
	 */
	public void updateGroupVersion(String appId, String groupId, Map<String,Boolean> versionIdsWithOperation) throws SQLException {
		mUpdateGroupVersion(appId,groupId,versionIdsWithOperation);
	}

	
	
	
	/**
	 * List group of devcie according to given groupId.
	 * @param groupId
	 * @return
	 * @throws Exception 
	 */
	public List<DeviceVO> listGroupEdgeCore(String groupId) throws SQLException {
		return mListGroupEdgeCore(groupId);

	}

	/**
	 * Add device to group.
	 * before add we check relation of group-edgecore already exist in db or not,
	 * if exist then we throw exception on UI. 
	 * @param deviceId 
	 * @param groupId group id
	* @throws Exception device already exists in group then throw exception.
	 */
	public void addEdgeCoreToGroup(String deviceId, String groupId) throws SQLException {
		mAddEdgeCoreToGroup(deviceId, groupId);
	}

	/**
	 * Remove device from a given group.
	 * @param deviceId
	 * @param groupId
	 * @throws Exception 
	 */
	public void removeEdgeCoreFromGroup(String deviceId, String groupId) throws SQLException {
		mRemoveEdgeCoreFromGroup(deviceId, groupId);

	}
	public void deleteGroupResources(String groupId, String filter)throws SQLException
	{
		mDeleteGroupResources(groupId, filter);
	}
	
	
	public void addResourceToGroup(String resourceId, String groupId,ResourceType resourceType) throws SQLException {
		mAddResourceToGroup(resourceId, groupId, resourceType);
	}

	
	public void removeResourceFromGroup(String resourceId, String groupId) throws SQLException {
		mRemoveResourceFromGroup(resourceId, groupId);

	}
	public void removeResourceFromGroup(List<String> resourceIds, String groupId) throws SQLException {
		mRemoveResourceFromGroup(resourceIds, groupId);

	}
	
	

	private void mUpdateGroupVersion(String appId, String groupId,
			Map<String, Boolean> versionIdsWithOperation) throws SQLException {
		new GroupsEngine().updateGroupVersion(appId, groupId, versionIdsWithOperation);

	}

	private List<ApplicationVO> mlistGroupApp(String groupId) throws SQLException {
		GroupsEngine groupsEngine=new GroupsEngine();
		return groupsEngine.listGroupApp(groupId);
	}

	private void maddAppToGroup(String appId, String groupId, List<String> versionIds
			) throws SQLException {
		GroupsEngine groupsEngine=new GroupsEngine();
		if(versionIds!=null && !versionIds.isEmpty())
			groupsEngine.addAppToGroup(appId, groupId,versionIds);
		else
			groupsEngine.addAppToGroup(appId, groupId);
	}

	private void mremoveAppToGroup(String appId, String groupId
			) throws SQLException {
		GroupsEngine groupsEngine=new GroupsEngine();
		groupsEngine.removeAppFromGroup(appId, groupId);
	}
	
	
	private List<DeviceVO> mListGroupEdgeCore(String groupId) throws SQLException {
		GroupsEngine groupsEngine=new GroupsEngine();
		return groupsEngine.listGroupEdgeCore(groupId);
	}

	private void mAddEdgeCoreToGroup(String deviceId, String groupId) throws SQLException {
		GroupsEngine groupsEngine=new GroupsEngine();
			groupsEngine.addEdgeCoreToGroup(deviceId, groupId);
	}

	private void mRemoveEdgeCoreFromGroup(String deviceId, String groupId
			) throws SQLException  {
		GroupsEngine groupsEngine=new GroupsEngine();
		groupsEngine.removeEdgeCoreFromGroup(deviceId, groupId);
	}
	
	private void mDeleteGroupResources(String groupId,String filter)throws SQLException
	{
		GroupsEngine groupsEngine=new GroupsEngine();
		groupsEngine.deleteGroupResources(groupId, filter);
	}
	private void mAddResourceToGroup(String resourceId, String groupId, ResourceType resourceType) throws SQLException {
		GroupsEngine groupsEngine=new GroupsEngine();
			groupsEngine.addResourceToGroup(resourceId, groupId, resourceType);
	}

	private void mRemoveResourceFromGroup(String resourceId, String groupId
			) throws SQLException  {
		GroupsEngine groupsEngine=new GroupsEngine();
		groupsEngine.removeResourceFromGroup(resourceId, groupId);
	}
	
	private void mRemoveResourceFromGroup(List<String> resourceIds, String groupId
			) throws SQLException  {
		GroupsEngine groupsEngine=new GroupsEngine();
		groupsEngine.removeResourceFromGroup(resourceIds, groupId);
	}
}
