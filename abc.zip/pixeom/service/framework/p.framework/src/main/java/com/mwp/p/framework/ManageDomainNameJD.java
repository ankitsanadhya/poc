/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.mwp.p.framework;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import com.google.gson.Gson;
import com.jdcloud.sdk.auth.CredentialsProvider;
import com.jdcloud.sdk.auth.StaticCredentialsProvider;
import com.jdcloud.sdk.service.clouddnsservice.client.ClouddnsserviceClient;
import com.jdcloud.sdk.service.clouddnsservice.model.AddRR;
import com.jdcloud.sdk.service.clouddnsservice.model.AddRRRequest;
import com.jdcloud.sdk.service.clouddnsservice.model.AddRRResponse;
import com.jdcloud.sdk.service.clouddnsservice.model.OperateRRRequest;
import com.jdcloud.sdk.service.clouddnsservice.model.OperateRRResponse;
import com.jdcloud.sdk.service.clouddnsservice.model.RR;
import com.jdcloud.sdk.service.clouddnsservice.model.SearchRRRequest;
import com.jdcloud.sdk.service.clouddnsservice.model.SearchRRResponse;
import com.jdcloud.sdk.service.clouddnsservice.model.SearchRRResult;
import com.jdcloud.sdk.service.clouddnsservice.model.UpdateRR;
import com.jdcloud.sdk.service.clouddnsservice.model.UpdateRRRequest;
import com.jdcloud.sdk.service.clouddnsservice.model.UpdateRRResponse;
import com.mwp.common.StringFunctions;
import com.mwp.common.constant.Constant;
import com.mwp.logger.PALogger;
import com.mwp.p.framework.ManageDomainNameGoogle.DomainOperation;

public class ManageDomainNameJD {

	static ThreadPoolExecutor parallelExecutor;	

	static {
		parallelExecutor = new ThreadPoolExecutor(5, 5, 
				60L, TimeUnit.SECONDS,
				new LinkedBlockingQueue<Runnable>());

		parallelExecutor.allowCoreThreadTimeOut(true);
	}

	public static void runCommand(final DomainOperation command, final String deviceName, final String ipAddress, final String ipAddressOld)                                     
	{		
		parallelExecutor.execute(new Runnable() {
			public void run() 
			{
				new ManageDomainNameJD().mRunCommand(command, deviceName, ipAddress, ipAddressOld);
			}			
		});
	}

	public static void main(String[] args) {

	}

	private void mRunCommand(DomainOperation command, String deviceName, String ipAddress,String ipAddressOld){
		PALogger.INFO("Command: "+command);
		PALogger.INFO("deviceName: "+deviceName);
		PALogger.INFO("ipAddress: "+ipAddress);
		PALogger.INFO("ipAddressOld: "+ipAddressOld);


		/*
		 * 		<dependency>
			<groupId>com.jdcloud.sdk</groupId>
			<artifactId>core</artifactId>
			<version>1.0.0</version>
		</dependency>

		<dependency>
			<groupId>com.jdcloud.sdk</groupId>
			<artifactId>clouddnsservice</artifactId>
			<version>1.0.0</version>
		</dependency>
		 * 
		 * */
		switch (command){
		case Add:
			AddRR req = new AddRR();
			req.hostRecord(deviceName).hostValue(ipAddress).type("A").ttl(600).jcloudRes(false).mxPriority(1).weight(1).viewValue(-1).port(443);

			AddRRRequest request = new AddRRRequest();		
			request.req(req).domainId(Constant.getDNSDomainID()).setRegionId(Constant.getDNSRegion());

			AddRRResponse response =  mExecuteAddRR(request, 3);

			PALogger.INFO(new Gson().toJson(response));			
			break;		
		case Edit:
			if(!StringFunctions.isNullOrWhitespace(ipAddressOld) && !ipAddressOld.equals(ipAddress) ){
				RR rrToUpdate = mSearchRR(deviceName);
				if(rrToUpdate != null){
					UpdateRR updaterR = new UpdateRR();
					updaterR.id(rrToUpdate.getId()).hostRecord(deviceName).hostValue(ipAddress).type("A").ttl(600).jcloudRes(false).mxPriority(1).weight(1).viewValue(-1);
					UpdateRRRequest updateRrRequest = new UpdateRRRequest();			
					updateRrRequest.domainId(Constant.getDNSDomainID()).regionId(Constant.getDNSRegion()).req(updaterR);

					UpdateRRResponse updateResponse =  mExecuteUpdateRR(updateRrRequest, 3);
					PALogger.INFO(new Gson().toJson(updateResponse));
				}
			}
			else{
				AddRR addReq = new AddRR();
				addReq.hostRecord(deviceName).hostValue(ipAddress).type("A").ttl(600).jcloudRes(false).mxPriority(1).weight(1).viewValue(-1).port(443);

				AddRRRequest addRequest = new AddRRRequest();		
				addRequest.req(addReq).domainId(Constant.getDNSDomainID()).setRegionId(Constant.getDNSRegion());

				AddRRResponse addResponse =  mExecuteAddRR(addRequest, 3);

				PALogger.INFO(new Gson().toJson(addResponse));	
			}
			break;
		case Delete:
			RR rrToDelete = mSearchRR(deviceName);
			if(rrToDelete != null){
				OperateRRRequest operateRr = new OperateRRRequest();
				List<Integer> ids = new ArrayList<>();
				ids.add(rrToDelete.getId());
				operateRr.action("del").domainId(Constant.getDNSDomainID()).ids(ids).regionId(Constant.getDNSRegion());

				OperateRRResponse operateResponse =  mExecuteOperateRR(operateRr, 3);
				PALogger.INFO(new Gson().toJson(operateResponse));
			}
			break;
		default:
			break;
		}	
	}


	private RR mSearchRR(String deviceName){
		SearchRRRequest srr = new SearchRRRequest();
		int pageNumber = 0;
		int pageSize = 40;
		int totalCount = 0;
		int recordsFound = 0;
		RR rrToFind = null;		
		do{
			pageNumber++;
			srr.pageNumber(pageNumber).pageSize(pageSize).domainId(Constant.getDNSDomainID()).regionId(Constant.getDNSRegion());
			SearchRRResult result =  null;
			SearchRRResponse searchResponse =  mExecuteSearchRR(srr, 3);
			if(searchResponse != null){
				System.out.println(new Gson().toJson(searchResponse));			
				result = searchResponse.getResult();
				totalCount = result.getTotalCount();
				recordsFound += result.getCurrentCount();			
				rrToFind = result.getDataList().stream().filter(rr-> rr.getHostRecord().equals(deviceName.toLowerCase())).findAny().orElse(null);
				if(rrToFind != null)
					break;
			}
		}while(totalCount != recordsFound);
		return rrToFind;
	}

	private AddRRResponse mExecuteAddRR( AddRRRequest request, int retryCount){
		int retry = 0;	
		while(retry < retryCount){
			try {
				retry++;
				return getDnsClient().addRR(request);			
			}
			catch (Exception exe) {	
				PALogger.ERROR(exe);
				//TODO: Ignore already exists error.
				if(exe.getMessage()!= null && exe.getMessage().contains("already exists"))
					break;

				try {
					if(retry < retryCount)
						Thread.sleep(5000);
				}
				catch (InterruptedException e){
					PALogger.ERROR(e);
					//Thread.currentThread().interrupt();
				}
			}
		}
		return null;
	}

	private UpdateRRResponse mExecuteUpdateRR(UpdateRRRequest request, int retryCount){
		int retry = 0;	
		while(retry < retryCount){
			try {
				retry++;
				return getDnsClient().updateRR(request);				
			}
			catch (Exception exe) {	
				PALogger.ERROR(exe);
				//TODO: Ignore already exists error.
				if(exe.getMessage()!= null && exe.getMessage().contains("already exists"))
					break;
				try {
					if(retry < retryCount)
						Thread.sleep(5000);
				}
				catch (InterruptedException e){
					PALogger.ERROR(e);
					//Thread.currentThread().interrupt();
				}
			}
		}
		return null;
	}

	private OperateRRResponse mExecuteOperateRR(OperateRRRequest request, int retryCount){
		int retry = 0;	
		while(retry < retryCount){
			try {
				retry++;
				return getDnsClient().operateRR(request);				
			}
			catch (Exception exe) {	
				PALogger.ERROR(exe);
				//TODO: Ignore already exists error.
				if(exe.getMessage()!= null && exe.getMessage().contains("already exists"))
					break;
				try {
					if(retry < retryCount)
						Thread.sleep(5000);
				}
				catch (InterruptedException e){
					PALogger.ERROR(e);
					//Thread.currentThread().interrupt();
				}
			}
		}
		return null;
	}

	private SearchRRResponse mExecuteSearchRR(SearchRRRequest request, int retryCount){
		int retry = 0;	
		while(retry < retryCount){
			try {
				retry++;
				return getDnsClient().searchRR(request);				
			}
			catch (Exception exe) {	
				PALogger.ERROR(exe);
				//TODO: Ignore already exists error.
				if(exe.getMessage()!= null && exe.getMessage().contains("already exists"))
					break;
				try {
					if(retry < retryCount)
						Thread.sleep(5000);
				}
				catch (InterruptedException e){					
					PALogger.ERROR(e);
					//Thread.currentThread().interrupt();
				}
			}
		}
		return null;
	}

	private ClouddnsserviceClient getDnsClient(){
		String accessKeyId = "F7AD2F2FF33916EBACABFBF8C427ECD2";
		String secretAccessKey = "B57F33E9E9762E4FD83EC59D182813EA";
		CredentialsProvider credentialsProvider = new StaticCredentialsProvider(Constant.getDNSAccessKey(), Constant.getDNSSecretKey());
		return ClouddnsserviceClient.builder().credentialsProvider(credentialsProvider).build();
	}

}
