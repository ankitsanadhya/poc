/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.framework.docker;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;

import com.mwp.common.Client;
import com.mwp.p.common.Constants;

public class ClairClient {
	
	private String serverPath;

	/**
	 * @param clairServerUrl Path of registry server
	 * @param authorizationHeader Value of authorization key
	 */
	public ClairClient() {
		this.serverPath = "http://"+ Constants.getClairAddress() +":6060";
	}

	/**
	 * This method to analyze Layer
	 * @throws IOException 
	 * @throws KeyStoreException 
	 * @throws NoSuchAlgorithmException 
	 * @throws KeyManagementException 
	 * @throws Exception 
	 */
	public String analyzeLayer(String layerName) throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException, IOException {
		
		/*
		 * http://portaldev.pixeom.net:6060/v1/layers/8b8aed2431b17dd1623ef2f8bf989b3451b44f3b79dea5e2f4791c037a8e766d?features&vulnerabilities 
		 */
		return Client.callServer(serverPath, "v1", "layers", "GET", layerName + "?features&vulnerabilities", null, null, "");
	}
	
	
	/**
	 * This method to analyze Layer
	 * @throws IOException 
	 * @throws KeyStoreException 
	 * @throws NoSuchAlgorithmException 
	 * @throws KeyManagementException 
	 * @throws Exception 
	 */
	public String pushLayer(String args) throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException, IOException  {
		//http://portaldev.pixeom.net:6060/v1/layers
		return Client.callServer(serverPath, "v1", "layers", "POST", "", null, args, "");
	}
	
}
