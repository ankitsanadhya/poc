/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.mwp.p.utility;

import java.io.FileReader;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.google.gson.Gson;
import com.google.gson.internal.LinkedTreeMap;
import com.mwp.common.CommandExecutor;
import com.mwp.common.enums.MessageType;
import com.mwp.common.enums.NotificationType;
import com.mwp.common.enums.RuleServerType;
import com.mwp.common.enums.RuleStatus;
import com.mwp.common.vo.RuleTriggerLogVO;
import com.mwp.common.vo.RuleVO;
import com.mwp.logger.PALogger;
import com.mwp.p.common.vo.RelayServerVO;
import com.mwp.p.dal.engine.AlertsEngine;
import com.mwp.p.framework.RelayServers;
import com.mwp.p.framework.Rule;
import com.mwp.p.framework.RuleTriggerLogs;
import com.mwp.p.framework.SupportRelayServer;

public class MoniterRelayServer {

	public void moniterRelay(int rulePortValue,int maxrelay,RuleServerType ruleservertype,String ruleId, boolean callByAdmin){
		try {
			int relayserverIndex =	0;
			String relayprefix;
			RuleTriggerLogVO rtvo = new RuleTriggerLogs().getLatestrecord(ruleId);

			if(rtvo!=null && rtvo.getStatus().equals(RuleStatus.failure))
			{
				LinkedTreeMap<String, Object> info = new LinkedTreeMap<>();
				Gson json = new Gson();
				info=json.fromJson(rtvo.getInfo(), info.getClass());

				relayserverIndex = Integer.parseInt(info.get("relayserverIndex").toString());
				relayprefix = info.get("relayprefix").toString();

				HashMap<String, Object> result=addGCloudRelayServer(relayserverIndex,relayprefix, ruleservertype, rtvo.getStage(), callByAdmin);
				RuleStatus success =RuleStatus.success;
				if(!Boolean.parseBoolean(result.get("success").toString()))
					success = RuleStatus.failure;
				result.put("trigger", info.get("trigger"));
				updateRuleLog(rtvo.getId(),success, Integer.parseInt(result.get("stage").toString()), result);
				return;
			}

			List<RelayServerVO> relayServerList;

			if(ruleservertype== RuleServerType.relay)
			{
				relayServerList =new RelayServers().listsAllRelayServer(callByAdmin);
				relayprefix="p";
			}
			else
			{
				relayServerList =new SupportRelayServer().listsAllSupportRelayServer(callByAdmin);
				relayprefix="s";
			}

			if(relayServerList.isEmpty() || relayServerList.size() >= maxrelay )
				return ;
			int totalCount =0;
			int freeCout =	0;
			int totalFreePorts=0;
			
			for (int i = 0; i < relayServerList.size(); i++) {
				String[] arr= relayServerList.get(i).getsRelayName().split("-");
				

				int count = getCount(arr);
				if(relayserverIndex<count)
					relayserverIndex=count;
				totalCount +=	(relayServerList.get(i).getnPortRangeEnd() -relayServerList.get(i).getnPortRangeStart() ) +1 ;
				freeCout +=relayServerList.get(i).getFreePort();

			}
			if(totalCount > 0)
				totalFreePorts= (freeCout*100)/totalCount;

			//If rule value is greater than equal to total available ports then add relay server
			if(rulePortValue >= totalFreePorts)
			{

				relayserverIndex++;
				Map<String, Object> result=new HashMap<>();
				Map<String,Object> triggerht = new HashMap<>();
				triggerht.put("triggerCondition", rulePortValue);
				triggerht.put("maxRelayServers", maxrelay);
				triggerht.put("relayServerType", ruleservertype.name());
				result.put("trigger", triggerht);
				String logId =addRuleLog(ruleId,RuleStatus.running,result);
				result=addGCloudRelayServer(relayserverIndex,relayprefix, ruleservertype, 1, callByAdmin);
				RuleStatus success =RuleStatus.success;
				if(!Boolean.parseBoolean(result.get("success").toString()))
					success = RuleStatus.failure;

				result.put("trigger", triggerht);
				updateRuleLog(logId,success, Integer.parseInt(result.get("stage").toString()), result);

			}

		} catch (SQLException e) {
			PALogger.ERROR(e);
		}
	}
	
	private int getCount(String[] arr)
	{
		int count =1;
		try
		{
			count= Integer.parseInt(arr[arr.length-1]);
		}
		catch (Exception e)
		{
			PALogger.ERROR(e);
		}
		return count;
	}
	public Map<String, Object> addRelayOnDemand(RuleServerType ruleservertype, boolean callByAdmin) throws SQLException{
		List<RelayServerVO> relayServerList;
		String relayprefix;
		if(ruleservertype== RuleServerType.relay)
		{
			relayServerList =new RelayServers().listsAllRelayServer(callByAdmin);
			relayprefix="p";
		}
		else
		{
			relayServerList =new SupportRelayServer().listsAllSupportRelayServer(callByAdmin);
			relayprefix="s";
		}
		int relayserverIndex =	1;
		for (int i = 0; i < relayServerList.size(); i++) {
			String[] arr= relayServerList.get(i).getsRelayName().split("-");
			
			int count = getCount(arr);
			if(relayserverIndex<count)
				relayserverIndex=count;


		}
		relayserverIndex++;

		return addGCloudRelayServer(relayserverIndex,relayprefix, ruleservertype, 1, callByAdmin);
	}
	private HashMap<String, Object> addGCloudRelayServer(int relayserverIndex, String relayprefix, RuleServerType ruleservertype, int stage, boolean callByAdmin){
		String relayIPAdress="";
		HashMap<String, Object> result  = new HashMap<>();
		JSONParser parser = new JSONParser();
		JSONObject obj = null;
		try {
			obj = (JSONObject) parser.parse(new FileReader("/opt/app_engine/ListingServer"));
		} catch (IOException | ParseException e1) {
			result.put("success", false);
			result.put("stage", 1);
			result.put("error", e1.getMessage());
			result.put("relayserverIndex",String.valueOf(relayserverIndex));
			result.put("relayprefix",relayprefix);

			
			return result;
		}

		String domainNamePrefix = obj.get("ProjectName").toString();
		String relayServerName = domainNamePrefix+"-relay-"+relayserverIndex;
		String snapShotName =obj.get("RelayServerDisk").toString();
		String fireWallName = relayServerName+"-firewall";
		String dnsName =relayprefix+"-rs"+relayserverIndex+"."+obj.get("domainName").toString();
		String output;
		ArrayList<String> commands= new ArrayList<>();




		RelayServerVO rsvo = new RelayServerVO();
		rsvo.setnStatus(1);
		rsvo.setsDeviceLimit("");// diff end -start as string
		rsvo.setsPriority(1);
		rsvo.setsRelayName(relayServerName);
		rsvo.setsRelayServerID(dnsName);
		rsvo.setnRPort(Integer.parseInt(obj.get("rPort").toString()));
		rsvo.setsRPassword(obj.get("rPassword").toString());
		rsvo.setsRUserName(obj.get("rUsername").toString());
		rsvo.setnPortRangeEnd(Integer.parseInt(obj.get("rPortEndRange").toString()));
		rsvo.setnPortRangeStart(Integer.parseInt(obj.get("rPortStartRange").toString()));

		result.put("RelayServerVO",rsvo);


		switch (stage) {
		case 1:
			//1-------------------------------------------- First create a disk that will be based on the snapshot.

			commands.add("gcloud");
			commands.add("compute");
			commands.add("disks");
			commands.add("create");
			commands.add(relayServerName);
			commands.add("--source-snapshot");
			commands.add(snapShotName);
			try {
				output=executeCommand(commands);
				if(output.contains("ERROR")){
					throw new Exception(output);
				}
			} catch (Exception e) {

				result.put("success", false);
				result.put("stage", 1);
				result.put("error", e.getMessage());
				result.put("relayserverIndex",String.valueOf(relayserverIndex));
				result.put("relayprefix",relayprefix);
				PALogger.ERROR(e);
				return result;
			}
			commands.clear();

		case 2:
			//2-------------------------------------------- Now Create an instance that will use the above created disk.

			commands.add("gcloud");
			commands.add("compute");
			commands.add("instances");
			commands.add("create");
			commands.add(relayServerName);
			commands.add("--image-family");
			commands.add("centos-7");
			commands.add("--image-project");
			commands.add("centos-cloud");
			commands.add("--disk");
			commands.add("name="+relayServerName+",boot=yes");

			try {
				output=executeCommand(commands);
				if(output.contains("ERROR")){
					throw new Exception(output);
				}
			} catch (Exception e) {

				result.put("success", false);
				result.put("stage", 2);
				result.put("error", e.getMessage());
				result.put("relayserverIndex",String.valueOf(relayserverIndex));
				result.put("relayprefix",relayprefix);

				PALogger.ERROR(e);
				return result;
			}
			commands.clear();

		case 3:
			//3-------------------------------------------- Allow specific Ports to the instances.
			commands.add("gcloud");
			commands.add("compute");
			commands.add("firewall-rules");
			commands.add("create");
			commands.add(fireWallName);
			commands.add("--allow");
			commands.add("tcp:55000-60000");
			commands.add("--source-tags="+relayServerName);
			commands.add("--source-ranges=0.0.0.0/0");
			commands.add("--description=\""+relayServerName+" firewall\"");


			try {
				output=executeCommand(commands);
				if(output.contains("ERROR")){
					throw new Exception(output);
				}
			} catch (Exception e) {
				result.put("success", false);
				result.put("stage", 3);
				result.put("error", e.getMessage());
				result.put("relayserverIndex",String.valueOf(relayserverIndex));
				result.put("relayprefix",relayprefix);

				PALogger.ERROR(e);
				return result;
			}
			commands.clear();

		case 4:
			//4-------------------------------------------- Find IP Address for added server.
			commands.add("gcloud");
			commands.add("compute");
			commands.add("instances");
			commands.add("list");
			commands.add("--format");
			commands.add("json");

			try {
				output=executeCommand(commands);
				if(output.contains("ERROR")){
					throw new Exception(output);
				}
				ArrayList<LinkedTreeMap<String, Object>> n = new ArrayList<>();
				Gson g = new Gson();
				n =g.fromJson(output, n.getClass());
				for (LinkedTreeMap<String, Object> string : n) {
					if(string.get("name").toString().equals(relayServerName))
					{

						List<Object> arr  =  (ArrayList<Object>) string.get("networkInterfaces"); 
						arr =  (ArrayList<Object>)((LinkedTreeMap<String, Object>) arr.get(0)).get("accessConfigs"); 
						relayIPAdress=  ((LinkedTreeMap<String, Object>) arr.get(0)).get("natIP").toString();
						
					}

				}
			} catch (Exception e) {
				result.put("success", false);
				result.put("stage", 4);
				result.put("error", e.getMessage());
				result.put("relayserverIndex",String.valueOf(relayserverIndex));
				result.put("relayprefix",relayprefix);

				PALogger.ERROR(e);
				return result;
			}
			commands.clear();


			//5.1-------------------------------------------- Add DNS.
			commands.add("gcloud");
			commands.add("dns");
			commands.add("record-sets");
			commands.add("transaction");
			commands.add("start");
			commands.add("--zone="+domainNamePrefix);

			try {
				output=executeCommand(commands);
				if(output.contains("ERROR") && !output.contains("transaction already exists")){
					throw new Exception(output);
				}
			} catch (Exception e) {
				result.put("success", false);
				result.put("stage", 4);
				result.put("error", e.getMessage());
				result.put("relayserverIndex",String.valueOf(relayserverIndex));
				result.put("relayprefix",relayprefix);

				PALogger.ERROR(e);
				return result;
			}
			commands.clear();

			//5.2-------------------------------------------- Add DNS.		
			commands.add("gcloud");
			commands.add("dns");
			commands.add("record-sets");
			commands.add("transaction");
			commands.add("add");
			commands.add("--zone="+domainNamePrefix);
			commands.add("--name="+dnsName+".");
			commands.add("--type=A");
			commands.add("--ttl=300");
			commands.add(relayIPAdress);
			try {
				output=executeCommand(commands);
				if(output.contains("ERROR")){
					throw new Exception(output);
				}
			} catch (Exception e) {
				result.put("success", false);
				result.put("stage", 4);
				result.put("error", e.getMessage());
				result.put("relayserverIndex",String.valueOf(relayserverIndex));
				result.put("relayprefix",relayprefix);

				PALogger.ERROR(e);
				return result;
			}
			commands.clear();


			commands.add("gcloud");
			commands.add("dns");
			commands.add("record-sets");
			commands.add("transaction");
			commands.add("execute");
			commands.add("--zone="+domainNamePrefix);
			try {
				output=executeCommand(commands);
				if(output.contains("ERROR")){
					throw new Exception(output);
				}
			} catch (Exception e) {
				result.put("success", false);
				result.put("stage", 4);
				result.put("error", e.getMessage());
				result.put("relayserverIndex",String.valueOf(relayserverIndex));
				result.put("relayprefix",relayprefix);

				PALogger.ERROR(e);
				return result;
			}
			commands.clear();



		case 5:

			//6 -------------------------------------------- Add relay to DB.





			rsvo.setsRelayServerAddress(relayIPAdress);
			result.put("RelayServerVO",rsvo);
			try {
				if(ruleservertype== RuleServerType.relay)
					new RelayServers().insertRelayServer(rsvo, callByAdmin);
				else 
					new SupportRelayServer().insertSupportRelayServer(rsvo, callByAdmin);
			} catch (Exception e) {
				result.put("success", false);
				result.put("stage", 5);
				result.put("error", e.getMessage());
				result.put("relayserverIndex",String.valueOf(relayserverIndex));
				result.put("relayprefix",relayprefix);

				PALogger.ERROR(e);
				return result;
			}

			// -------------------------------------------- Done
			result.put("success", true);
			result.put("stage", 5);



			return result;
			
		}
		return null;
	}
	private String executeCommand(List<String> commands) throws Exception{

		CommandExecutor commandExecutor = new CommandExecutor();

		return commandExecutor.Execute (commands);


	}
	private String addRuleLog(String ruleId, RuleStatus status,Map<String, Object> data){

		try {

			return new RuleTriggerLogs().insert(ruleId,  status,new Gson().toJson(data));

		} catch (SQLException e) {
			PALogger.ERROR(e);
		}
		return null;
	}
	private void updateRuleLog(String id, RuleStatus status, int stage, Map<String, Object> data){
		try {

			RuleTriggerLogVO rultVO = new RuleTriggerLogs().update(id,  status, stage, new Gson().toJson(data));

			RuleVO rulevo = new Rule().get(rultVO.getRuleId());
			Map<String, Object> list = new Gson().fromJson(rulevo.getRuleValue(), Map.class);

			String msg = "New server created available ports are below " + list.get("ruleValue") + " and maximum servers to create are " + list.get("maxRelay") + ".";
			NotificationType notificatiotype = NotificationType.Info;
			if(rultVO.getStatus() == RuleStatus.failure)
			{
				notificatiotype = NotificationType.Error;
				msg =  "Create new server failed available ports are below " + list.get("ruleValue") + " and maximum servers to create are " + list.get("maxRelay") + ".";
			}

			AlertsEngine eng= new AlertsEngine();
			eng.add(notificatiotype,rultVO ,MessageType.RuleLog,msg);


		} catch (SQLException e) {
			PALogger.ERROR(e);
		}
	}

}
