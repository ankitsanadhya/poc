/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.framework;

import java.sql.SQLException;
import java.util.List;

import com.mwp.common.Common;
import com.mwp.common.enums.RuleType;
import com.mwp.common.vo.RuleVO;
import com.mwp.p.dal.engine.RuleEngine;

/**
 * this class access data from Rule table
 * @author root
 *
 */
public class Rule 
{

	/**
	 * list all email servers 
	 * @return
	 * @throws SQLException
	 */
	public List<RuleVO> listRuleofType(RuleType ruletype) throws SQLException
	{
		return mListRuleofType(ruletype);
	}
	
	/**
	 * list all email servers 
	 * @return
	 * @throws SQLException
	 */
	public List<RuleVO> listsAll() throws SQLException
	{
		return mListsAll();
	}

	/**
	 * insert in email server
	 * @param relayServerVo
	 * @return
	 * @throws SQLException
	 */
	public  RuleVO insert(RuleVO ruleVo) throws SQLException 
	{
		return mInsert(ruleVo);
	}
	
	/**
	 * update in email server
	 * @param relayServerVo
	 * @return
	 * @throws SQLException
	 */
	public  RuleVO update(String ruleId, String ruleValue) throws SQLException 
	{
		return mUpdate(ruleId, ruleValue);
	}

	/**
	 * delete email server
	 * @param sRelayServerId
	 * @throws SQLException
	 */
	public void delete(String ruleId) throws SQLException 
	{
		mDelete(ruleId);
	}
	
	public RuleVO get(String ruleID) throws SQLException
	{
		return mGet(ruleID);
	}
	
	private RuleVO mGet(String ruleID) throws SQLException
	{
		RuleEngine engg = new RuleEngine();
		return engg.get(ruleID);
	}
	private List<RuleVO> mListsAll() throws SQLException
	{
		RuleEngine engg = new RuleEngine();
		return engg.listsAll();
	}
	private List<RuleVO> mListRuleofType(RuleType ruletype) throws SQLException
	{
		RuleEngine engg = new RuleEngine();
		return engg.getRuleByTypes(ruletype);
	}

	/**
	 * insert in email server
	 * @param relayServerVo
	 * @return
	 * @throws SQLException
	 */
	private RuleVO mInsert(RuleVO rulevo) throws SQLException 
	{
		rulevo.setRuleId(Common.getRandomId());
		RuleEngine engg = new RuleEngine();
		return engg.insert(rulevo);
	}
	
	/**
	 * update in email server
	 * @param relayServerVo
	 * @return
	 * @throws SQLException
	 */
	private  RuleVO mUpdate(String ruleId, String ruleValue) throws SQLException 
	{
		RuleEngine engg = new RuleEngine();
		return engg.update(ruleId, ruleValue);
	}
	
	private  void mDelete(String ruleId) throws SQLException 
	{
		RuleEngine engg = new RuleEngine();
		 engg.delete(ruleId);
	}
	
}
