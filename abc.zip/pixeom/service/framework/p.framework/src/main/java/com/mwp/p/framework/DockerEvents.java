/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.framework;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import com.mwp.common.vo.DockerEventVO;
import com.mwp.p.dal.engine.DockerEventLogEngine;

/**
 * Manages docker events logs in insert/ update/ delete etc   
 *
 */
public class DockerEvents
{
	/**
	 * add docker event 
	 * @param events
	 * @return
	 * @throws SQLException
	 */
	public List<String> insert(List<DockerEventVO>events) throws SQLException
	{
		return mInsert(events);
	}
	
	/**
	 * List all docker events 
	 * @param appId
	 * @return
	 * @throws SQLException
	 */
	public List<DockerEventVO> listEvent(String appId)throws SQLException
	{
		return mListEvent(appId);
	}
	
	/**
	 *  List events of last <numberofdays>
	 * @param numberofdays
	 * @return
	 * @throws SQLException
	 */
	public List<DockerEventVO> listByTime(int numberofdays) throws SQLException
	{
		return mListByTime(numberofdays);
	}
	
	/**
	 * List events using paging
	 * @param pageNo page number
	 * @param appId application id.
	 * @param pageSize number of events in a page result
	 * @return  HashMap<String, Object> with keys totalPages, pageSize, pageNumber, data . data is List<DockerEventVO> 
	 * @throws SQLException
	 */
	public  Map<String, Object> listByPage(int pageNo, String appId,int pageSize) throws SQLException
	{
		return mListByPage(pageNo, appId,pageSize);
	}

	private List<String> mInsert(List<DockerEventVO> events) throws SQLException
	{
		DockerEventLogEngine engg = new DockerEventLogEngine();
		return engg.insert(events);
	}
	private List<DockerEventVO> mListEvent(String appId) throws SQLException
	{
		DockerEventLogEngine engg = new DockerEventLogEngine();
		return engg.listEvent(appId);
	}
	private List<DockerEventVO> mListByTime(int numberofdays) throws SQLException
	{
		DockerEventLogEngine engg = new DockerEventLogEngine();
		return engg.listByTime(numberofdays);
	}

	private  Map<String, Object> mListByPage(int pageNo, String appId, int pageSize) throws SQLException
	{
		DockerEventLogEngine engg = new DockerEventLogEngine();
		return engg.listByPage(pageNo,appId,pageSize);
	}
}
