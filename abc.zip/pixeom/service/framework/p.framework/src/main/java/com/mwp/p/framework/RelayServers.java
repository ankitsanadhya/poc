/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.framework;

import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.google.gson.Gson;
import com.jcabi.ssh.Shell;
import com.jcabi.ssh.SshByPassword;
import com.mwp.common.Client;
import com.mwp.common.StringFunctions;
import com.mwp.common.enums.RelayEnum.NetworkTypeEnum;
import com.mwp.common.vo.DiscoveryDetailsVO;
import com.mwp.common.vo.DiscoveryJarDetailsVO;
import com.mwp.logger.PALogger;
import com.mwp.p.common.PortalCommon;
import com.mwp.p.common.vo.AssignedRelayPortsVO;
import com.mwp.p.common.vo.LockRelayPortsVO;
import com.mwp.p.common.vo.RelayServerVO;
import com.mwp.p.dal.engine.AssignedRelayPortsEngine;
import com.mwp.p.dal.engine.LockRelayPortsEngine;
import com.mwp.p.dal.engine.RelayServersEngine;
import com.mwp.p.dal.engine.SupportRelayServerEngine;

public class RelayServers {

	private int portSegmentSize = 1;


	/**
	 * this method check if given relayserver is with 1 priority and is available
	 * @param relayServerID
	 * @param toChkPriority = to check if given relayserverid is with priority 1
	 * @param toChkInSupport = to check  priority in relayserver or in supportrelayserver table; used only if toChkPriority is true
	 * @return
	 * @throws SQLException 
	 */
	public int checkIfRelayServerIsAlive(String relayServerID,boolean toChkPriority,boolean toChkInSupport) throws SQLException 
	{
		boolean checkDomain = true;
		if(toChkPriority)
		{
			if(toChkInSupport)
			{
				if(!new SupportRelayServerEngine().isOnePriority(relayServerID))
					checkDomain =false;
			}
			else
			{
				if(!new RelayServersEngine().isOnePriority(relayServerID))
					checkDomain =false;
			}
		}
		if(checkDomain)
		{
			if(isDomainAvailible(relayServerID))
				return 200;
			else
				return 500;
		}
		return 500;
	}

	/**
	 * list all relay servers with used and available count
	 * @return
	 * @throws SQLException
	 */
	public List<RelayServerVO> listsAllRelayServer(boolean callByAdmin) throws SQLException
	{
		return mListsAllRelayServer(callByAdmin);
	}

	/**
	 * insert in relay server
	 * @param relayServerVo
	 * @return
	 * @throws Exception 
	 */
	public  RelayServerVO insertRelayServer(RelayServerVO relayServerVo, boolean callByAdmin) throws Exception 
	{
		return mInsertRelayServer(relayServerVo,callByAdmin);
	}

	/**
	 * update in relay server
	 * @param relayServerVo
	 * @return
	 * @throws SQLException
	 */
	public  RelayServerVO updateRelayServer(RelayServerVO relayServerVo, boolean callByAdmin) throws SQLException 
	{
		return mUpdateRelayServer(relayServerVo, callByAdmin);
	}

	/**
	 * delete relay server
	 * @param sRelayServerId
	 * @throws SQLException
	 */
	public  void deleteRelayServer(String sRelayServerId) throws SQLException 
	{
		mDeleteRelayServer(sRelayServerId);
	}
	/**
	 * returns true, if domain is availible, false if not
	 * @param domain
	 * @return
	 */
	private boolean isDomainAvailible(String domain)
	{
		int retryCount = 0;
		while(retryCount<3)
		{
			try
			{
				String protocol = "https://";

				Client.callHeadURI(protocol + domain + "/", 0, 0, 0 , true);
				return true;
				//DB - Resolved the issue with Memory Leak which result in OutOfMemoryException
				//				URL url = new URL(protocol + domain + "/");
				//				HttpURLConnection conn= (HttpURLConnection) url.openConnection();
				//				conn.setRequestMethod("HEAD");
				//				conn.connect();
				//				int code = conn.getResponseCode();
				//				if(code ==200)
				//					return true;
				//				else
				//					retryCount++;
			}
			catch (Exception e)
			{
				retryCount++;
			}
			try {
				Thread.sleep(10000);
			} catch (InterruptedException e) {
				PALogger.ERROR(e);
				//Thread.currentThread().interrupt();	
			}
		}
		return false;




	}


	public Map<String, Object> setupRelayDiscoveryDetails(String macAddress, int deviceStatus, String guid, long timestamp,
			String email, String hostName, String swLicense, String hwConfig, String deviceId, String iPAddress, String localIPAddress, 
			String chatInputChannel, String chatOutputChannel, String chatSubscriptionChannel, String nodeCommunicationPort, String openStackPort, 
			String tomcatPort, String port1, String port2, String port3, String port4, String port5, String rURLTomcatPort, 
			String rAddress, String isSetRURL, int status) throws Exception
	{
		Map<String, Object>  hashResult = new HashMap<>();
		// uncomment code for use in android-ntl
		Map<String, Object> validationResult = new ValidationInfo().checkValidationInfo(macAddress, deviceStatus, guid, timestamp, 
				email, hostName, swLicense, hwConfig);
		String statusTemp = "";
		String errorMessage = "";
		if(validationResult.size() > 0) { 
			/*
			 *  Not require validationResult - ntl, va // Use in validationInfo - ntl, va, hu
			 */
			statusTemp = validationResult.get("Status").toString();
			errorMessage = validationResult.get("ErrorMessage").toString();
			if("Failure".equals(statusTemp) && "Duplicate MAC Address.".equals(errorMessage)) {
				hashResult.put("Status", "Failure");
				hashResult.put("validationResult", validationResult);
				return hashResult;
			}
			else if("Failure".equals(statusTemp) && "ValidationInfo not found.".equals(errorMessage)){
				return validationResult;
			}
		}

		DiscoveryDetailsVO detailsVO = new DiscoveryDetails().getDiscoveryDetails(deviceId);

		if(detailsVO != null) {
			PALogger.INFO("===== DiscoveryDetails found for first time ===="+ detailsVO.getsDeviceID() +"============");
			PALogger.INFO("===== DiscoveryDetails found ===="+ new Gson().toJson(detailsVO) +"============");
			NetworkTypeEnum networkType = detailsVO.getsNetworkType();
			String relayServerID = detailsVO.getsRelayServerID();
			if(PortalCommon.getInstance().isRelay(networkType)) {// equals(2)
				int relayServerIsAlive = checkIfRelayServerIsAlive(relayServerID,true,false);
				PALogger.INFO("=====Check if already assigned relay isalive ===="+ relayServerID +"============");
				if(relayServerIsAlive == 200) {
					chatInputChannel = detailsVO.getsChatInputChannel();
					chatOutputChannel = detailsVO.getsChatOutputChannel();
					chatSubscriptionChannel = detailsVO.getsChatSubscriptionChannel();
					nodeCommunicationPort = detailsVO.getsNodeCommunicationPort();
					openStackPort = detailsVO.getsOpenStackPort();
					tomcatPort = detailsVO.getsTomcatPort();
					port1 = detailsVO.getsPort1();
					rURLTomcatPort = detailsVO.getsRURLTomcatPort();
					rAddress = detailsVO.getsRAddress();						

					new DiscoveryDetails().setDiscoveryDetails(deviceId, iPAddress, localIPAddress, 
							chatInputChannel, chatOutputChannel, 
							chatSubscriptionChannel, nodeCommunicationPort, openStackPort, 
							tomcatPort, port1, port2, port3, port4, port5, 
							rURLTomcatPort, rAddress, status, relayServerID, networkType);

				} else {
					PALogger.INFO("=====relay is not alive reasigned relay ports====" + relayServerID + "============");
					errorMessage = setRelayServer(macAddress,deviceId, "", iPAddress, localIPAddress, chatInputChannel, chatOutputChannel, 
							chatSubscriptionChannel, nodeCommunicationPort, openStackPort,  tomcatPort, 
							port1, port2, port3, port4, port5, port5,  rAddress,isSetRURL, status, true);
				}
				if("".equals(errorMessage)) {
					detailsVO =  new DiscoveryDetails().getDiscoveryDetails(deviceId);
					hashResult.put("Status", "Success");
					hashResult.put("Details", detailsVO);
					hashResult.put("validationResult", validationResult);
				} else {
					hashResult.put("Status", "Failure");
					hashResult.put("ErrorMessage", errorMessage);
					hashResult.put("Details", detailsVO);
					hashResult.put("validationResult", validationResult);
					return hashResult;
				}
				return hashResult;
			}
		}
		PALogger.INFO("===== DiscoveryDetails not found for first time ===="+ deviceId +"============");


		AssignedRelayPortsVO isresult = new RelayServers().isassignrelay(deviceId);

		if(isresult == null) {
			errorMessage = setRelayServer(macAddress, deviceId, "",iPAddress, localIPAddress, chatInputChannel, 
					chatOutputChannel, chatSubscriptionChannel, nodeCommunicationPort, openStackPort,  tomcatPort, 
					port1, port2, port3, port4, port5, rURLTomcatPort,  rAddress,isSetRURL, status, true);
		} else {
			/*
			 * Already assigned ports
			 */
			PALogger.INFO("===== relay ports are already assigned for ===="+ deviceId +"============");
			String relayServerID = isresult.getsRelayServerID();
			int portSegmentStart = isresult.getnPortSegmentStart();

			int relayServerIsAlive = checkIfRelayServerIsAlive(relayServerID,true,false);
			PALogger.INFO("=====Check if already assigned relay isalive===="+ relayServerID +"============");
			if(relayServerIsAlive == 200) {
				NetworkTypeEnum nt = NetworkTypeEnum.None;
				if(isSetRURL.equals("false")){
					nt = NetworkTypeEnum.RelayNR;
				}
				PALogger.INFO("=====UpdateDiscoveryDetails==== isSetRURL =="+ isSetRURL +"======NetworkTypeEnum======"+nt.name());
				updateDiscoveryDetails(deviceId, iPAddress, localIPAddress, chatInputChannel, 
						chatOutputChannel, chatSubscriptionChannel, nodeCommunicationPort, 
						openStackPort,  tomcatPort, port1, port2, port3, port4, 
						port5, rURLTomcatPort,  rAddress, isSetRURL, status, 
						nt, relayServerID, portSegmentStart);

			} else {
				PALogger.INFO("=====relay server assigned but not alive again ports and relayserver assigned===="+ relayServerID +"============");
				errorMessage = setRelayServer(macAddress, deviceId,"", iPAddress, localIPAddress, chatInputChannel, chatOutputChannel, 
						chatSubscriptionChannel, nodeCommunicationPort, openStackPort,  tomcatPort, 
						port1, port2, port3, port4, port5, rURLTomcatPort, rAddress, isSetRURL, status, true);
			}
		}

		detailsVO = new DiscoveryDetails().getDiscoveryDetails(deviceId);

		if("".equals(errorMessage)) {
			/*
			 *  uncomment code for use in android-ntl
			 */
			hashResult.put("Status", "Success");
			hashResult.put("Details", detailsVO);
			hashResult.put("validationResult", validationResult);
			return hashResult;
		} else {
			hashResult.put("Status", "Failure");
			hashResult.put("ErrorMessage", errorMessage);
			hashResult.put("Details", detailsVO);
			hashResult.put("validationResult", validationResult);
			return hashResult;
		}
	}

	public Map<String, Object> setupRelayJARDiscoveryDetails(String macAddress, int deviceStatus, String guid, long timestamp, 
			String email, String hostName, String swLicense, String hwConfig, String iPAddress, String localIPAddress, 
			String chatInputChannel, String chatOutputChannel, String chatSubscriptionChannel, String nodeCommunicationPort, String openStackPort, 
			String tomcatPort, String port1, String port2, String port3, String port4, String port5, String rURLTomcatPort, 
			String rAddress, String isSetRURL, int status) throws Exception{

		Map<String, Object> validationResult = new ValidationInfo().checkValidationInfo(macAddress, deviceStatus, guid, timestamp, 
				email, hostName, swLicense, hwConfig);
		HashMap<String, Object> result = new HashMap<>();
		String statusTemp = "";
		String errorMessage = "";
		DiscoveryJarDetailsVO detailsVO = null;
		// uncomment code for use in android-ntl
		if(validationResult.size() > 0) {  // Not require validationResult - ntl, va // Use in validationInfo - ntl, va, hu
			statusTemp = validationResult.get("Status").toString();
			errorMessage = validationResult.get("ErrorMessage").toString();
			if("Failure".equals(statusTemp) && "Duplicate MAC Address.".equals(errorMessage)) {
				result.put("Status", "Failure");
				result.put("validationResult", validationResult);
				return result;
			}
		}

		detailsVO = new DiscoveryJarDetails().getDiscoveryJARDetails(macAddress);			

		if(detailsVO != null && !StringFunctions.isNullOrWhitespace(detailsVO.getsRelayServerID())) {

			int relayServerIsAlive = checkIfRelayServerIsAlive(detailsVO.getsRelayServerID(),true,false);
			PALogger.INFO("=====Check if already assigned relay isalive ===="+ detailsVO.getsRelayServerID() +"============");
			if(relayServerIsAlive == 200) {
				new DiscoveryJarDetails().setJARDiscoveryDetails(macAddress, hostName, iPAddress, localIPAddress, detailsVO.getsChatInputChannel(), 
						detailsVO.getsChatOutputChannel(), detailsVO.getsChatSubscriptionChannel(), detailsVO.getsNodeCommunicationPort(), 
						detailsVO.getsOpenStackPort(), detailsVO.getsTomcatPort(), 
						detailsVO.getsPort1(), port2, port3, port4, port5, detailsVO.getsRURLTomcatPort(),  
						detailsVO.getsRAddress(), status, detailsVO.getsRelayServerID(), detailsVO.getsNetworkType());

				detailsVO = new DiscoveryJarDetails().getDiscoveryJARDetails(macAddress);
				result.put("Status", "Success");
				result.put("Details", detailsVO);
				result.put("validationResult", validationResult);
				return result;
			}
		}

		errorMessage = setRelayServer(macAddress, macAddress, hostName, iPAddress, localIPAddress, chatInputChannel, chatOutputChannel, 
				chatSubscriptionChannel, nodeCommunicationPort, openStackPort,  tomcatPort, port1, port2, port3, port4, port5, 
				rURLTomcatPort,  rAddress, isSetRURL, status, false);



		if("".equals(errorMessage)){
			detailsVO = new DiscoveryJarDetails().getDiscoveryJARDetails(macAddress);				
			result.put("Status", "Success");
			result.put("Details", detailsVO);
			result.put("validationResult", validationResult);
			return result;
		} 
		else {
			result.put("Status", "Failure");
			result.put("ErrorMessage", errorMessage);
			result.put("validationResult", validationResult);
			return result;
		}	
	}

	public String setRelayServer(String macAddress, String deviceId, String hostName, String iPAddress, String localIPAddress, 
			String chatInputChannel, String chatOutputChannel, String chatSubscriptionChannel, String nodeCommunicationPort, 
			String openStackPort, String tomcatPort, String port1, String port2, String port3, String port4, String port5,
			String rURLTomcatPort,  String rAddress, String isSetRURL, int status, boolean isActivated) throws Exception {

		List<RelayServerVO> allrelayserver = getRelayServers();
		boolean isRelayServerAssigned = false;
		boolean isLockGranted = false;

		String errorMessage="";
		if(!allrelayserver.isEmpty()) {
			for (Iterator iterator = allrelayserver.iterator(); iterator.hasNext();) {
				RelayServerVO relayServerVO = (RelayServerVO) iterator.next();

				int retryCount = 0;
				int relayServerIsAlive = checkIfRelayServerIsAlive(relayServerVO.getsRelayServerID(),false,false);
				PALogger.INFO("=====RelayServerIsAlive====" + relayServerIsAlive + "============");
				if(relayServerIsAlive == 200) {					
					while(retryCount < 3)
					{
						errorMessage="";
						PALogger.INFO("=====get relay server id and port range===="+ relayServerVO.getsRelayServerID() +"======"+ relayServerVO.getnPortRangeEnd() +"======");
						int portSegmentStart = getAvailablePortRange(deviceId, relayServerVO.getsRelayServerID(), relayServerVO.getnPortRangeEnd());
						PALogger.INFO("=====PortSegmentStart====" + portSegmentStart + "============");
						if(portSegmentStart == 0) 									
						{
							portSegmentStart = relayServerVO.getnPortRangeStart();
							PALogger.INFO("=====PortSegmentStart====" + portSegmentStart + "============");
						}
						if(portSegmentStart != -1) {

							String relayServerID = relayServerVO.getsRelayServerID();				

							isLockGranted  = lockPortSegment(deviceId, relayServerID, portSegmentStart);
							PALogger.INFO("=====IsLockGranted====" + isLockGranted + "============");
							if(isLockGranted){

								NetworkTypeEnum nt = NetworkTypeEnum.None;
								if(isSetRURL.equals("false")) {									
									nt = NetworkTypeEnum.RelayNR;
								}


								if(isActivated){
									updateDiscoveryDetails(deviceId, iPAddress, localIPAddress, 
											chatInputChannel, chatOutputChannel, chatSubscriptionChannel, 
											nodeCommunicationPort, openStackPort,  tomcatPort, 
											port1, port2, port3, port4, port5, rURLTomcatPort, 
											rAddress, isSetRURL, status, nt, 
											relayServerID, portSegmentStart);
								}
								else{
									updateJARDiscoveryDetails(deviceId, hostName, iPAddress, localIPAddress, chatInputChannel, 
											chatOutputChannel, chatSubscriptionChannel, 
											nodeCommunicationPort, openStackPort,  tomcatPort, port1, port2, port3, port4, port5, 
											rURLTomcatPort,  rAddress, status, nt, relayServerID, portSegmentStart);
								}
								isRelayServerAssigned = true;
								break;
							} else {
								errorMessage="No relay ports available.";
							}
						}
						retryCount++;

					}
					if(isRelayServerAssigned){
						break;
					}       				
				}
			}
		}

		if(!isRelayServerAssigned){
			errorMessage="No relay server available.";
			if(isActivated){
				//LAN

				updateDiscoveryDetails(deviceId, iPAddress, localIPAddress, chatInputChannel, 
						chatOutputChannel, chatSubscriptionChannel, nodeCommunicationPort, 
						openStackPort,  tomcatPort, port1, port2, port3, port4, 
						port5, rURLTomcatPort,  rAddress, isSetRURL, status, 
						NetworkTypeEnum.RelayPF, "", 0);
			}
			else{

				//LAN

				updateJARDiscoveryDetails(macAddress, hostName, iPAddress, localIPAddress, 
						chatInputChannel, chatOutputChannel, chatSubscriptionChannel, 
						nodeCommunicationPort, openStackPort,  tomcatPort, 
						port1, port2, port3, port4, port5, rURLTomcatPort,  
						rAddress, status, NetworkTypeEnum.RelayPF, "", 0);
			}
		}
		return errorMessage;
	}

	public AssignedRelayPortsVO isassignrelay(String deviceId) throws SQLException {
		return new AssignedRelayPortsEngine().getAssignedRelayPortsVO(deviceId);
	}

	private List<RelayServerVO> getRelayServers() throws SQLException {

		List<RelayServerVO>  lsitRelayServer = new RelayServersEngine().getDistinctRelayServers();
		if(lsitRelayServer.isEmpty()) {
			lsitRelayServer = new RelayServersEngine().getListRelayServer();
		}	    
		return  lsitRelayServer;
	}

	private int getAvailablePortRange(String deviceId, String relayServerID, int portRangeEnd) throws SQLException {
		AssignedRelayPortsVO assinedPorts = getAlreadyAssignedPorts(deviceId, relayServerID);
		if(assinedPorts != null) {
			PALogger.INFO("=====Already assigned ports===="+ assinedPorts.getnPortSegmentStart() +"============");
			if(!StringFunctions.isNullOrWhitespace(assinedPorts.getnPortSegmentStart())){
				return assinedPorts.getnPortSegmentStart();
			}
		}		
		int portsegment = getMaxRelayPort(relayServerID);
		PALogger.INFO("=====GetAvailablePortRange====" + portsegment + "============");
		if(portsegment +(portSegmentSize-1) > portRangeEnd) {
			List<AssignedRelayPortsVO> lstAvailablePorts = getAvailablePorts(relayServerID); // list all assigned ports on this relay server where status is AVAILABLE
			if(!lstAvailablePorts.isEmpty()) {
				PALogger.INFO("=====lstAvailablePorts====" + lstAvailablePorts + "============");
				deleteDeviceAssignedPorts(lstAvailablePorts.get(0).getsDeviceID());			
				return lstAvailablePorts.get(0).getnPortSegmentStart();
			}
			else{
				return -1;
			}
		} else {
			return portsegment;
		}
	}

	private int getMaxRelayPort(String relayServerId) throws SQLException {
		int availablePortSegment = new AssignedRelayPortsEngine().getMaxRelayPort(relayServerId);
		if(availablePortSegment == 0){
			return 0;
		}
		else{
			return availablePortSegment + portSegmentSize;	    	
		}
	}

	private List<AssignedRelayPortsVO> getAvailablePorts(String relayServerID) throws SQLException {
		return new AssignedRelayPortsEngine().getAvailablePorts(relayServerID);
	}

	private boolean deleteDeviceAssignedPorts(String deviceId) throws SQLException {
		new AssignedRelayPortsEngine().deleteDeviceAssignedPorts(deviceId);
		return true;
	}

	private boolean lockPortSegment(String deviceId, String relayServerID, int portSegmentStart) throws SQLException{
		placeBid(deviceId, relayServerID, portSegmentStart);
		if(isDeviceBidWon(deviceId, relayServerID, portSegmentStart)){
			//We need to create cron job to delete bids older than x Minuts
			addAssignedRelayPorts(deviceId, relayServerID, portSegmentStart);
			return true;
		}else{
			deleteDeviceBids(deviceId);
			return false;
		}
	}

	private boolean placeBid(String deviceId, String relayServerID, int portSegmentStart) throws SQLException{
		deleteDeviceBids(deviceId);
		return new LockRelayPortsEngine().addLockRelayPorts(deviceId, relayServerID, portSegmentStart);
	}

	private List<LockRelayPortsVO> listBids(String relayServerID, int portSegmentStart) throws SQLException{
		return new LockRelayPortsEngine().getListLockRelayPorts(relayServerID, portSegmentStart);
	}

	private boolean isDeviceBidWon(String deviceId, String relayServerID, int portSegmentStart) throws SQLException {
		deleteExpiredLocks();
		List<LockRelayPortsVO> bids = listBids(relayServerID, portSegmentStart);
		for (Iterator iterator = bids.iterator(); iterator.hasNext();) {
			LockRelayPortsVO lockRelayPortsVO = (LockRelayPortsVO) iterator.next();
			PALogger.INFO("=====bids========" + portSegmentStart + "===========" + lockRelayPortsVO.getsDeviceID()
					+ "======" + lockRelayPortsVO.getdModified() + "======");
		}
		if (!bids.isEmpty() && bids.get(0).getsDeviceID().equals(deviceId)) {
			return true;
		} else {
			return false;
		}
	}

	private boolean deleteExpiredLocks() throws SQLException {
		return new LockRelayPortsEngine().deleteExpiredLocks();
	}

	private boolean addAssignedRelayPorts(String deviceId, String relayServerID, int portSegmentStart){
		try{ 
			new AssignedRelayPortsEngine().addAssignedRelayPorts(deviceId, relayServerID, portSegmentStart);
			return true;
		}catch(SQLException ex){
			return false;
		}
	}

	private boolean deleteDeviceBids(String deviceId) throws SQLException{
		return new LockRelayPortsEngine().deleteLockRelayPorts(deviceId);
	}

	private void updateDiscoveryDetails(String deviceId, String iPAddress, String localIPAddress, String chatInputChannel, String chatOutputChannel, 
			String chatSubscriptionChannel, String nodeCommunicationPort, String openStackPort,  String tomcatPort, 
			String port1, String port2, String port3, String port4, String port5, String rURLTomcatPort,  
			String rAddress, String isSetRURL, int status, NetworkTypeEnum networkType, String relayServerID, int portSegmentStart) throws Exception{

		if("true".equals(isSetRURL)){
			if(portSegmentStart == 0){
				rURLTomcatPort = "";
			}else{
				rURLTomcatPort = String.valueOf(portSegmentStart);
			}
			rAddress = relayServerID;			
		}
		else{
			if(PortalCommon.getInstance().isRelay(networkType)){//equals(NetworkTypeRelay)
				if(portSegmentStart == 0){
					tomcatPort = "";
				}else{
					tomcatPort = String.valueOf(portSegmentStart);
				}
				openStackPort = "";
				nodeCommunicationPort = "";
				chatInputChannel = "";
				chatOutputChannel = "";
				chatSubscriptionChannel = "";

				rURLTomcatPort = tomcatPort;
				rAddress = relayServerID;
			}
		}

		new DiscoveryDetails().setDiscoveryDetails(deviceId, iPAddress, localIPAddress,
				chatInputChannel, chatOutputChannel, chatSubscriptionChannel, nodeCommunicationPort, openStackPort,
				tomcatPort, port1, port2, port3, port4, port5, rURLTomcatPort,  rAddress, 
				status, relayServerID, networkType); 
	}

	private void updateJARDiscoveryDetails(String macAddress, String hostName, String iPAddress, String localIPAddress, String chatInputChannel, 
			String chatOutputChannel, String chatSubscriptionChannel, String nodeCommunicationPort, String openStackPort, 
			String tomcatPort, String port1, String port2, String port3, String port4, String port5, String rURLTomcatPort, 
			String rAddress, int status, NetworkTypeEnum networkType, String relayServerID, int portSegmentStart) throws SQLException{

		if(portSegmentStart == 0){
			tomcatPort = rURLTomcatPort = "";
		}else{
			tomcatPort = rURLTomcatPort = String.valueOf(portSegmentStart);
		}
		rAddress = relayServerID;

		new DiscoveryJarDetails().setJARDiscoveryDetails(macAddress, hostName, iPAddress, localIPAddress, 
				chatInputChannel, chatOutputChannel, chatSubscriptionChannel, nodeCommunicationPort, 
				openStackPort,  tomcatPort, port1, port2, port3, port4, port5, 
				rURLTomcatPort,  rAddress, status, relayServerID, networkType); 
	}

	private AssignedRelayPortsVO getAlreadyAssignedPorts(String deviceId, String relayServerID) throws SQLException {
		return new AssignedRelayPortsEngine().getAssignedRelayPortsVO(deviceId, relayServerID);
	}

	private List<RelayServerVO> mListsAllRelayServer(boolean callByAdmin) throws SQLException
	{
		RelayServersEngine engg = new RelayServersEngine();
		return engg.listsAllRelayServer(callByAdmin);
	}

	/**
	 * insert in relay server
	 * @param relayServerVo
	 * @return
	 * @throws Exception 
	 */
	private  RelayServerVO mInsertRelayServer(RelayServerVO relayServerVo, boolean callByAdmin) throws Exception 
	{
		RelayServersEngine engg = new RelayServersEngine();
		return engg.insertRelayServer(relayServerVo.getsRelayServerID(), relayServerVo.getsRelayServerAddress(), relayServerVo.getsRelayName(), relayServerVo.getnPortRangeStart(), relayServerVo.getnPortRangeEnd(), relayServerVo.getsDeviceLimit(), relayServerVo.getnStatus(),relayServerVo.getsRUserName(), relayServerVo.getsRPassword(),relayServerVo.getsHostKey(), relayServerVo.getnRPort(), relayServerVo.getsPriority(), callByAdmin);
	}

	/**
	 * update in relay server
	 * @param relayServerVo
	 * @return
	 * @throws SQLException
	 */
	private  RelayServerVO mUpdateRelayServer(RelayServerVO relayServerVo, boolean callByAdmin) throws SQLException 
	{
		RelayServersEngine engg = new RelayServersEngine();
		return engg.updateRelayServer(relayServerVo.getsRelayServerID(), relayServerVo.getsRelayServerAddress(), relayServerVo.getsRelayName(),  relayServerVo.getnStatus(), relayServerVo.getsRUserName(), relayServerVo.getsRPassword(), relayServerVo.getsHostKey(), relayServerVo.getnRPort(), relayServerVo.getsPriority(), callByAdmin);
	}

	private  void mDeleteRelayServer(String sRelayServerId) throws SQLException 
	{
		RelayServersEngine engg = new RelayServersEngine();
		engg.delete(sRelayServerId);
	}
	
	public Map<String,String> getRelayServerPodDetails() throws IOException{
		return mGetRelayServerPodDetails();
	}
	
	private Map<String,String> mGetRelayServerPodDetails() throws IOException{


		/***
		 * 1. sshpass -p L@wnM0wer ssh root@portalrelay.localportal.svc.cluster.local -p 2020 "cat /root/userconfig"
User configurations - meghauser:038c7438-ba39-4423-a135-6cff053a2910

2. sshpass -p L@wnM0wer ssh root@portalrelay.localportal.svc.cluster.local -p 2020 "cat /etc/ssh/ssh_host_rsa_key.pub"
ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQC4qqeQvsTwqCeoYt3n2DVNxryM8kuELGPgVB5H+uOkFXAYuZ2ACHJf0mzqXL0ILmbmqHhgRnpmnC47pyb+kQiEcGRpLd0lagIxgwMaBCtsnOWByFB2sdxNk1sWWxQrXwROpaJB4TreFACiVdktg2an13csYEUo+jwLqpkonKUN69/Dc95w2YRb8HCFcJ6v8+HqcDL4iPbc16rM9a5S3CUlFpAjHsukFdT0n5ntROG3yCCGvkkypMaaWx+JeiC5Erg9J3KQvXdl3pfpEjvrQO837MQxb/gMBBvtxlVPkHS/JFWOsmbHUaCDdUvs5aNIn8bN06ceMd7BHKyIvqFm+BIx
		 */
		final String namespace = System.getenv("REPOSITORY_NAME");
		final String relayServerDomain = System.getenv("RELAY_SERVER_DOMAIN");
		final String hostName = "portalrelay." + namespace + ".svc.cluster.local";
		//"portaltwo-rs1.siemenspx.us";		

		PALogger.INFO("Repository Name: " + namespace + " , hostname: " + hostName + " ,domainName: " + relayServerDomain);		

		Map<String,String> details = new HashMap<>();
		Shell shell = new SshByPassword(hostName, 2020, "root", "L@wnM0wer");
		String stdout = new Shell.Plain(shell).exec("cat /root/userconfig");

		String[] cred = stdout.split(" - ")[1].trim().split(":");

		details.put("userName", cred[0]);
		details.put("key", cred[1]);

		stdout = new Shell.Plain(shell).exec("cat /etc/ssh/ssh_host_rsa_key.pub");
		details.put("sshHostKey", stdout.trim());
		details.put("name", "relay");
		details.put("address", relayServerDomain);
		details.put("adminport", "32500");
		details.put("portsRangeStart", "32502");
		details.put("portsRangeEnd", "32700");	
		return details;
	}
}
