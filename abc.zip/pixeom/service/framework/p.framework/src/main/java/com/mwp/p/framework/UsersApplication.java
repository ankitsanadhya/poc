/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.mwp.p.framework;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.mwp.common.vo.ApplicationVO;
import com.mwp.common.vo.DeviceVO;
import com.mwp.common.vo.VersionVO;
import com.mwp.p.common.vo.DeviceApplicationVO;
import com.mwp.p.common.vo.UserDeviceApplicationsVO;
import com.mwp.p.common.vo.UsersApplicationsVersionVO;
import com.mwp.p.dal.engine.UsersApplicationEngine;

public class UsersApplication {

	/**
	 * List device of user. 
	 * @param userIds
	 * @return
	 * @throws Exception
	 */
	public List<DeviceVO> listDevice(String appid) throws SQLException {
		return mListDevice(appid);
	}



	private List<DeviceVO> mListDevice(String appid) throws SQLException {

		UsersApplicationEngine userengin = new UsersApplicationEngine();
		return userengin.listDevice(appid);


	}



	/**
	 * List all application info, all application of users that exist on device
	 * @param pageNo
	 * @param pageSize
	 * @param userId
	 * @param deviceId
	 * @return
	 * @throws Exception
	 */
	public List<DeviceApplicationVO> listDeviceApplication(String deviceid) throws SQLException {
		return mListDeviceApplication(deviceid);
	}


	private List<DeviceApplicationVO> mListDeviceApplication(String deviceid) throws SQLException {
		UsersApplicationEngine userengin = new UsersApplicationEngine();
		return userengin.listDeviceApplication(deviceid);
		
	}
	
	
	/**
	 * return all devices of users and installed apps on the devices.
	 * HashMap<String,HashMap<String, UserDeviceApplicationsVO>> key: userid, value: HashMap<String, UserDeviceApplicationsVO>
	 * HashMap<String, UserDeviceApplicationsVO> key: device id, value: UserDeviceApplicationsVO object
	 * @param userid
	 * @return
	 * @throws Exception
	 */
	public Map<String,HashMap<String, UserDeviceApplicationsVO>>  listusersDeviceApplication(List<String> userid) throws SQLException {
		return mlistusersDeviceApplication(userid);
	}


	private Map<String,HashMap<String, UserDeviceApplicationsVO>> mlistusersDeviceApplication(List<String> userid) throws SQLException {
		UsersApplicationEngine userengin = new UsersApplicationEngine();
		return userengin.listUsersDeviceApplication(userid);

	}



	/**
	 * List application of Users.
	 * @param projectId
	 * @param userId user id of user whuch came for listing request
	 * @return
	 * @throws Exception
	 */
	public List<ApplicationVO> listUsersApps(List<String> userIds) throws SQLException{
		return mListUsersApps(userIds);
	}



	private List<ApplicationVO> mListUsersApps(List<String> userIds) throws SQLException {

		UsersApplicationEngine userengin = new UsersApplicationEngine();
		return userengin.listUsersApps(userIds);
	}



	
	/**
	 * list all versions and ports of an application.
	 * @param appid
	 * @return
	 * @throws SQLException
	 */
	public  List<VersionVO> listApplicationVersion( String appid) throws SQLException {
		return mlistApplicationVersion(appid);
	}


	private List<VersionVO> mlistApplicationVersion(String appid) throws SQLException {
		UsersApplicationEngine userengin = new UsersApplicationEngine();
		return userengin.listApplicationVersion(appid);
	}

	
	
	
	/**
	 * list all created applications of user with versions and ports
	 * @param userid
	 * @return Hashtable<String, Hashtable<String, UsersApplicationsVersionVO>> key: userid, value:  Hashtable<String, UsersApplicationsVersionVO>
	 *  Hashtable<String, UsersApplicationsVersionVO> key: applicationId, value: UsersApplicationsVersionVO
	 * @throws SQLException
	 */
	public  Map<String, HashMap<String, UsersApplicationsVersionVO>> listUsersApplicationVersion(List<String> userid) throws SQLException {
		return mlistUsersApplicationVersion(userid);
	}



	private Map<String, HashMap<String, UsersApplicationsVersionVO>> mlistUsersApplicationVersion(List<String> userid ) throws SQLException {
		UsersApplicationEngine userengin = new UsersApplicationEngine();
		return userengin.listUsersApplicationVersion(userid);
	}



}
