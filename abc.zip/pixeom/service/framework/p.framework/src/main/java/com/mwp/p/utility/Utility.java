/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.utility;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.mwp.common.CommandExecutor;
import com.mwp.common.NginxCommands;
import com.mwp.common.constant.Constant;
import com.mwp.common.constant.ErrorMessage;
import com.mwp.common.constant.PermissionResourceKeys;
import com.mwp.common.constant.PermissionResources;
import com.mwp.common.enums.ApplicationDefaultType;
import com.mwp.common.enums.CommandEnum;
import com.mwp.common.vo.AppResourceVO;
import com.mwp.common.vo.ApplicationVO;
import com.mwp.common.vo.AuthorizationsVO;
import com.mwp.p.framework.Devices;
import com.mwp.p.framework.Groups;
import com.mwp.p.framework.InstallJobs;
/**
 * This Class used for common method which are generally used for portal framework method.
 * @author root
 *
 */
public class Utility 
{
	/**
	 * This method used for check that user has permission for that operation or not.
	 * @param hashPermission
	 * @param permissionName
	 * @param applicationId
	 * @return
	 * @throws Exception
	 */
	public static void  checkPermission(Map<String, List<String>>  hashPermission, String permission,String applicationId) throws Exception
	{
		List<String> permissions=new ArrayList<>();
		permissions.add(permission);
		mcheckPermission(hashPermission,permissions,applicationId,false);
	}

	/**
	 * This method used for check that user has permission for that operation or not.
	 * @param hashPermission
	 * @param permissionsEnum ---List of Permission Enums
	 * @param applicationId
	 * @throws Exception
	 */
	
	public static void  checkPermission(Map<String, List<String>>  hashPermission, List<String> permissionsEnum,String applicationId,boolean checkAnd) throws Exception
	{
		mcheckPermission(hashPermission,permissionsEnum,applicationId,checkAnd);
	}
	
	public static void checkEdgecorePermission(AuthorizationsVO authorizationsVO, List<String> permissionsEnum,String deviceId,boolean checkForAnd) throws Exception
	{
		mcheckEdgecorePermission(authorizationsVO, permissionsEnum, deviceId, checkForAnd);
	}
	
	public static void checkEdgecorePermissionForDevices(AuthorizationsVO authorizationsVO, List<String> permissionsEnum,List<String> deviceIds,boolean checkForAnd) throws Exception
	{
		mcheckEdgecorePermissionForDevicesOrJobs(authorizationsVO, permissionsEnum, deviceIds, checkForAnd, false, null);
	}
	
	public static void checkEdgecorePermissionForJobs(AuthorizationsVO authorizationsVO,List<String> jobIds) throws Exception
	{
		mcheckEdgecorePermissionForDevicesOrJobs(authorizationsVO, null, null, true, true, jobIds);
	}
	
	/**
	 * This method used for check that user has permission for that operation or not.
	 * @param hashPermission
	 * @param permissionsEnum
	 * @param applicationId
	 * @param checkForAnd
	 * @throws Exception
	 */
	private static void mcheckPermission(Map<String, List<String>>  hashPermission, List<String> permissions,String applicationId,boolean checkForAnd) throws Exception
	{
		ArrayList<String> groupIds = new ArrayList<>();
		boolean appFound=false;
		// Get List of groups for the given permission. 
		boolean permissionFound=false;
		for (Object object : hashPermission.entrySet())
		{
			Map.Entry pair = (Map.Entry) object;
			List<String> lstpermission=new ArrayList<>(((List)pair.getValue()));
			for(String permission:permissions)
			{
				permissionFound=false;
				if(lstpermission.contains(permission))
				{
					permissionFound=true;
					if(!checkForAnd)   // boolean variable decides wheather check that permission lies within the list (Which came from authVo) or not. 
						break;
				}
				else if(checkForAnd)
					break;
			}
			if(permissionFound)
				groupIds.add(pair.getKey().toString());
		}
		Groups grp = new Groups();
		
		// Get List of Applicatios which lies within that group. 
		for (String groupId : groupIds) 
		{
			List<ApplicationVO> appVos = grp.listGroupApp(groupId);
			for (ApplicationVO applicationVO : appVos) {
				// Return true if given applicationId lies within that group.
				if(applicationVO.getApplicationId().equals(applicationId)) {
					appFound=true;
					break;
				}
			}
		}
		if(!appFound)
			throw new Exception(Constant.NOTPERMITTED);
	}

	
	private static void mcheckEdgecorePermission(AuthorizationsVO authorizationsVO, List<String> permissions,String deviceId,boolean checkForAnd) throws Exception
	{
		List<String> groupIds ;
		Devices deviceObj = new Devices();
		String ownerId = deviceObj.getUserId(deviceId);
		if(ownerId.equals(""))
			throw new Exception(ErrorMessage.DEVICE_NOT_FOUND);
		if(deviceObj.getUserId(deviceId).equals(authorizationsVO.getUserId()))
				return;
		if(authorizationsVO.getGroupPermissions()==null || authorizationsVO.getGroupPermissions().isEmpty())
			throw new Exception(Constant.NOTPERMITTED);
		groupIds = deviceObj.listGroupsOfDevice(deviceId,new ArrayList<String>(authorizationsVO.getGroupPermissions().keySet()));
		if(groupIds.isEmpty() )
			throw new Exception(Constant.NOTPERMITTED);
			
	
		// Get List of groups for the given permission. 
		boolean permissionFound=false;
		
		//list of pemission from those groups  which contains deviceId
		List<String> lstpermission=new ArrayList<>();
		for (Object object : authorizationsVO.getGroupPermissions().entrySet())
		{
			Map.Entry pair = (Map.Entry) object;
			if(groupIds.contains(pair.getKey().toString()))
			{
				lstpermission.addAll((List)pair.getValue());
			}
		}
			for(String permission:permissions)
			{
				permissionFound=false;
				if(lstpermission.contains(permission))
				{
					permissionFound=true;
					if(!checkForAnd)   // boolean variable decides wheather check that permission lies within the list (Which came from authVo) or not. 
						break;
				}
				else if(checkForAnd)
					break;
			}

		
		if(!permissionFound)
			throw new Exception(Constant.NOTPERMITTED);
		
	}
	
	private static void mcheckEdgecorePermissionForDevicesOrJobs(AuthorizationsVO authorizationsVO, List<String> permissions,List<String> deviceIds,boolean checkForAnd,boolean checkforJobIds,List<String> jobIds) throws Exception
	{
		List<String> groupIds = new ArrayList<>();
		Devices deviceObj = new Devices();
		Map<String, List<String>> devicesOperations = null;
		if(checkforJobIds)
		{
			InstallJobs jobs= new InstallJobs();
			devicesOperations = jobs.getJobOperations(jobIds);
			deviceIds =new ArrayList<>(devicesOperations.keySet());
		}
		
		Map<String, List<String>>  devicesGrps= deviceObj.listGroupsOfDevices(deviceIds);
		if(devicesGrps.size() == 0)
		{
			//it means these devices are not added in any group so permission for access to these devices is only constrained to their owner
			boolean isOwner = deviceObj.isSameOwnerDevice(deviceIds, authorizationsVO.getUserId());
			if(isOwner)
				return;
			else
				throw new Exception(Constant.NOTPERMITTED);
		}
			
		boolean permissionFound=false;	
	Set<String> deviceIdsFromDB = devicesGrps.keySet();
		for (String deviceId : deviceIds)
		{
			//check for is owner
			if(deviceObj.getUserId(deviceId).equals(authorizationsVO.getUserId()))
				continue;
			//neither owner nor invited in any group
			if(authorizationsVO.getGroupPermissions()==null || authorizationsVO.getGroupPermissions().isEmpty())
				throw new Exception(Constant.NOTPERMITTED);
			//not invited for this deviceId
			if(!deviceIdsFromDB.contains(deviceId))
				throw new Exception(Constant.NOTPERMITTED);
			
			groupIds = devicesGrps.get(deviceId);
			//list of pemission from those groups  which contains deviceId
			List<String> lstpermission=new ArrayList<>();
			for (Object object : authorizationsVO.getGroupPermissions().entrySet())
			{
				Map.Entry pair = (Map.Entry) object;
				if(groupIds.contains(pair.getKey().toString()))
				{
					lstpermission.addAll((List)pair.getValue());
				}
			}
			if(checkforJobIds)
			{
				List<String> operations = devicesOperations.get(deviceId);
				permissions = new ArrayList<>();
				for (String operation : operations)
				{
					if(CommandEnum.installApplication == CommandEnum.valueOf(operation) 
							||CommandEnum.updateApplication == CommandEnum.valueOf(operation))
						permissions.add(PermissionResources.getString(PermissionResourceKeys.APPLIANCES_APP_INSTALL));
					else if(CommandEnum.uninstallApplication == CommandEnum.valueOf(operation) )
						permissions.add(PermissionResources.getString(PermissionResourceKeys.APPLIANCES_APP_UNINSTALL));
					else if(CommandEnum.systemUpdate == CommandEnum.valueOf(operation) )
						permissions.add(PermissionResources.getString(PermissionResourceKeys.APPLIANCES_SYSTEM_UPDATE));

					else if(CommandEnum.updateApplication == CommandEnum.valueOf(operation) )
						permissions.add(PermissionResources.getString(PermissionResourceKeys.APPLIANCES_APP_INSTALL));
					else if(CommandEnum.startApplication == CommandEnum.valueOf(operation) )
						permissions.add(PermissionResources.getString(PermissionResourceKeys.APPLIANCES_APP_START));
					else if(CommandEnum.restartApplication == CommandEnum.valueOf(operation) )
						permissions.add(PermissionResources.getString(PermissionResourceKeys.APPLIANCES_APP_RESTART));
					else if(CommandEnum.stopApplication == CommandEnum.valueOf(operation) )
						permissions.add(PermissionResources.getString(PermissionResourceKeys.APPLIANCES_APP_STOP));
					else if(CommandEnum.systemReboot == CommandEnum.valueOf(operation) )
						permissions.add(PermissionResources.getString(PermissionResourceKeys.APPLIANCES_SYSTEM_REBOOT));
					else if(CommandEnum.systemShutdown == CommandEnum.valueOf(operation) )
						permissions.add(PermissionResources.getString(PermissionResourceKeys.APPLIANCES_SYSTEM_SHUTDOWN));
					else if(CommandEnum.systemFactoryReset == CommandEnum.valueOf(operation) )
						permissions.add(PermissionResources.getString(PermissionResourceKeys.APPLIANCES_SYSTEM_FACTORYRESET));
					else if(CommandEnum.systemReset == CommandEnum.valueOf(operation) )
						permissions.add(PermissionResources.getString(PermissionResourceKeys.APPLIANCES_SYSTEM_RESET));
					//					else if(CommandEnum.restoreApplicationBackup == CommandEnum.valueOf(operation) )
					//						permissions.add(PermissionResources.getString(PermissionResourceKeys.APPLIANCES_SYSTEM_UPDATE));


				}
			}
			for(String permisison:permissions)
			{
				permissionFound=false;
				if(lstpermission.contains(permisison))
				{
					permissionFound=true;
					if(!checkForAnd)   // boolean variable decides wheather check that permission lies within the list (Which came from authVo) or not. 
						break;
				}
				else if(checkForAnd)
					break;
			}
			
			if(!permissionFound)
				throw new Exception(Constant.NOTPERMITTED);
			
		}
		
	}

	/**
	 * Validate the resources submitted for the applications
	 * @param type - {@link ApplicationDefaultType}
	 * @param appResourceVO - {@link AppResourceVO} resource object submitted
	 * @return
	 * @throws Exception
	 */
	public static boolean validateResource(ApplicationDefaultType type, AppResourceVO appResourceVO) throws Exception {

		switch (appResourceVO.getKind()) {
		case nginxConfig:
			if(appResourceVO.getFilePath().endsWith(".conf")) {
				if(type == ApplicationDefaultType.kubernetes && 
						new NginxCommands().isNginxFileTypeServer(appResourceVO.getFilePath())) {
					return true;
				}
			}
			break;
		case nginxCertificate:
			if(appResourceVO.getFilePath().endsWith(".crt")) {
				ArrayList<String> command = new ArrayList<>();
				command.add("openssl");
				command.add("x509");
				command.add("-in");
				command.add(appResourceVO.getFilePath());
				command.add("-text");
				command.add("-noout");
				String result = new CommandExecutor().Execute(command);
				if(result.startsWith("Certificate:")) {
					return true;
				}
			}
			break;
		case nginxCertificateKey:
			if(appResourceVO.getFilePath().endsWith(".key")) {
				ArrayList<String> command = new ArrayList<>();
				command.add("openssl");
				command.add("rsa");
				command.add("-in");
				command.add(appResourceVO.getFilePath());
				command.add("-check");
				command.add("-noout");
				String result = new CommandExecutor().Execute(command);
				if(result.startsWith("RSA key ok")) {
					return true;
				}
			}
			break;
		case nginxDhParam:
			if(appResourceVO.getFilePath().endsWith(".pem")) {
				return true;
			}
			break;
		default:
			break;
		}

		return false;
	}

}
