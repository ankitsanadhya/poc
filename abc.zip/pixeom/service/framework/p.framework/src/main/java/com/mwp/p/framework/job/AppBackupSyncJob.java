/** 
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com) 
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL 
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC. 
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD 
 * IN STRICTEST CONFIDENCE. 
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */ 
package com.mwp.p.framework.job;

import java.util.HashMap;
import java.util.List;

import com.mwp.common.constant.ErrorMessage;
import com.mwp.common.enums.AppBackupTaskStatus;
import com.mwp.common.enums.RoleEnum;
import com.mwp.common.interfaces.IScheduledJob;
import com.mwp.common.vo.AppBackupTaskVOPortal;
import com.mwp.common.vo.AuthorizationsVO;
import com.mwp.logger.PALogger;
import com.mwp.p.common.vo.AppBackupSyncVO;
import com.mwp.p.dal.engine.AppBackupSyncEngine;
import com.mwp.p.dal.engine.AppBackupTaskEngine;
import com.mwp.p.framework.MinioBackups;

/**
 * Scheduler job look for sync the minio backups in DB
 *   
 * Look for AppBackupSync table for list of cluster id to which sync is needed
 *
 */
public class AppBackupSyncJob implements IScheduledJob {

	private static final int INTERVAL = 300; //Seconds for 5 Minute
	private static int sleepCounter = 0;

	@Override
	public void init() {
		while(true) {
			try {
				syncBackups();
			} catch(Exception e) {
				PALogger.ERROR(e);	
			} finally {
				sleepCounter = 0;
				while(sleepCounter < INTERVAL) {
					sleepCounter++;

					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						PALogger.ERROR(e);
						//Thread.currentThread().interrupt();
					}
				}
			}
		}
	}

	public static synchronized void tryInit() {
		if(sleepCounter != 0) {
			sleepCounter += INTERVAL;
		}
	}


	private void syncBackups() throws Exception {
		AppBackupSyncEngine appBackupSyncEngine = new AppBackupSyncEngine();
		AppBackupTaskEngine appBackupTaskEngine = new AppBackupTaskEngine();
		List<AppBackupSyncVO> appBackupSyncVOs = appBackupSyncEngine.get();

		MinioBackups minioBackups = new MinioBackups();

		for (AppBackupSyncVO appBackupSyncVO : appBackupSyncVOs) {
			appBackupSyncEngine.update(appBackupSyncVO.getClusterId(), AppBackupTaskStatus.EXECUTING);

			
			AuthorizationsVO authVO = new AuthorizationsVO();
			authVO.setRole(RoleEnum.Admin);
			authVO.setUserId(appBackupSyncVO.getUserId());
			authVO.setGroupPermissions(new HashMap<>());

			try {
				List<AppBackupTaskVOPortal> minioAppBackupTaskVOs = minioBackups.ListAllBackupsOfACluster(authVO, appBackupSyncVO.getClusterId());
				List<AppBackupTaskVOPortal> dbAppBackupTaskVOs =  appBackupTaskEngine.list(appBackupSyncVO.getClusterId());

				//Add the backups which are not previously added into database. 
				for (AppBackupTaskVOPortal minioAppBackupTaskVO : minioAppBackupTaskVOs) {
					AppBackupTaskVOPortal dbAppBackupTaskVO = dbAppBackupTaskVOs
							.stream()
							.filter(dbBackupTaskVO -> (
									dbBackupTaskVO.getAppBackupTaskVO().getArkBackupName().equals(minioAppBackupTaskVO.getAppBackupTaskVO().getArkBackupName()) 
									)).findFirst().orElse(null);

					if(dbAppBackupTaskVO == null) {
						appBackupTaskEngine.upsert(minioAppBackupTaskVO);
					} else {
						dbAppBackupTaskVOs.remove(dbAppBackupTaskVO);
					}

				}

				//Delete the backups which are nor listed in minio list.
				for (AppBackupTaskVOPortal dbAppBackupTaskVO : dbAppBackupTaskVOs) {
					/*AppBackupTaskVOPortal minioAppBackupTaskVO = minioAppBackupTaskVOs
							.stream()
							.filter(minioBackupTaskVO -> (
									minioBackupTaskVO.getAppBackupTaskVO().getArkBackupName().equals(dbAppBackupTaskVO.getAppBackupTaskVO().getArkBackupName()) 
									)).findFirst().orElse(null);

					if(minioAppBackupTaskVO == null) {
						appBackupTaskEngine.delete(dbAppBackupTaskVO.getAppBackupTaskVO().getArkBackupName());
					}*/
					appBackupTaskEngine.delete(dbAppBackupTaskVO.getAppBackupTaskVO().getArkBackupName());

				}

				appBackupSyncEngine.delete(appBackupSyncVO.getClusterId(), AppBackupTaskStatus.EXECUTING);
			} catch (Exception e) {
				PALogger.ERROR(e);
				if(e != null && (e.getMessage().equals(ErrorMessage.DEVICE_NOT_FOUND) ||
						e.getMessage().equals(minioBackups.PLATFORM_NOT_FOUND) ||
						e.getMessage().equals(minioBackups.APP_NOT_FOUND) ||
						e.getMessage().equals(minioBackups.APP_VERSION_NOT_FOUND))) {
					appBackupSyncEngine.delete(appBackupSyncVO.getClusterId(), AppBackupTaskStatus.EXECUTING);
					continue;
				}
			}
		}
	}
}
