/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.framework;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.io.FileUtils;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.google.gson.Gson;
import com.google.gson.internal.LinkedTreeMap;
import com.mwp.common.Common;
import com.mwp.common.CredProvider;
import com.mwp.common.TempFiles;
import com.mwp.common.Utils;
import com.mwp.common.constant.Constant;
import com.mwp.common.constant.ErrorMessage;
import com.mwp.common.enums.ApplicationDefaultType;
import com.mwp.common.enums.CommandEnum;
import com.mwp.common.enums.InstallJobStatusEnum;
import com.mwp.common.enums.TypeEnum;
import com.mwp.common.vo.AppInstallDetailsVO;
import com.mwp.common.vo.AppNotificationVo;
import com.mwp.common.vo.AppResourceVO;
import com.mwp.common.vo.ApplicationDetailsVO;
import com.mwp.common.vo.ApplicationPlatformVO;
import com.mwp.common.vo.ApplicationVO;
import com.mwp.common.vo.FilterObject;
import com.mwp.common.vo.InstallJobVO;
import com.mwp.common.vo.NotificationMessage;
import com.mwp.common.vo.VersionVO;
import com.mwp.common.yamlparser.ComposeVO;
import com.mwp.common.yamlparser.SecretVo;
import com.mwp.common.yamlparser.SectionVO;
import com.mwp.common.yamlparser.YamlParser;
import com.mwp.logger.PALogger;
import com.mwp.p.common.vo.AppCommandVO;
import com.mwp.p.common.vo.AppTypeVO;
import com.mwp.p.common.vo.DeviceApplicationVO;
import com.mwp.p.dal.engine.ApplicationResourceEngine;
import com.mwp.p.dal.engine.ApplicationsEngine;
import com.mwp.p.dal.engine.BoxStaticsEngine;
import com.mwp.p.dal.engine.DeveloperApplicationsEngine;
import com.mwp.p.dal.engine.InstallJobEngine;
import com.pa.crypto.FileEncryptionDecryption;

public class Applications {



	/**
	 * This method return list of related groups of app
	 * @param appId : application id of requested app
	 * @return : List of groups
	 * @throws SQLException 
	 */
	public List<String> listGroupsOfApp(String appId, List<String> groupIds) throws SQLException {
		return mListGroupsOfApp(appId, groupIds);
	}

	/**
	 * This method gives all applications using paging.
	 * @param pageNo 
	 * @param pageSize number of applications in one page.
	 * @param filters
	 * @return
	 * @throws Exception 
	 */
	public Map<String, Object> searchApps(int pageNo, int pageSize,
			List<FilterObject> filters,boolean toListAllApps) throws SQLException {
		return mSearchApps(pageNo, pageSize, filters, toListAllApps);
	}

	/**
	 * This method gives list of all {@link ApplicationVO} 
	 * according to requested search text.
	 * 
	 * @param searchText requested search text 
	 * @return list of {@link ApplicationVO} 
	 * @throws Exception
	 */
	public List<ApplicationVO> listApps(String searchText) throws SQLException {
		return mListApps(searchText);

	}

	/**
	 * This method gives application detail 
	 * according to given application Id.
	 *  
	 * @param appId Application Id which is unique for each application.
	 * @return object of {@link ApplicationDetailsVO}
	 * @throws Exception 
	 */
	public ApplicationDetailsVO getAppDetail(String appId,String userId) throws SQLException {
		return mGetAppDetail(appId,userId);
	}

	/**
	 * This method returns map of actions for an application according to device
	 * @param appId
	 * @param userId
	 * @param grpIds
	 * @return
	 * @throws Exception
	 */
	public List<AppCommandVO> getAppCommandsForUser(String appId,String userId, List<String> grpIds) throws SQLException {
		return mGetAppCommandsForUser(appId,userId, grpIds);
	}

	public AppInstallDetailsVO getAppInstallDetail(String appId, String versionId, String appPlatformId) throws SQLException {
		return mGetAppInstallDetail(appId, versionId, appPlatformId);
	}

	/**
	 * This method gives list version of application 
	 * according to given user Id.
	 *  
	 * @param appId Application Id which is unique for each application.
	 * @param userId is who created the application.
	 * @return
	 * @throws Exception 
	 */
	public List<VersionVO> listVersionOfApplication(String appId,String userId) throws SQLException {
		return mListVersionOfApplication(appId,userId);
	}

	/**
	 * This method publish kafka event to execute install/uninstall operation.
	 */
	public void executeOperation(String appId,String deviceId,String operation,String versionId,String  jobId) throws SQLException
	{
		mExecuteOperation(appId,deviceId,operation,versionId,jobId);
	}


	/**
	 * This method provides functionality to schedule the desired operation being sent to particular device Id.
	 * @param appId application Id.
	 * @param deviceId device Id
	 * @param operation Operation to be performed on device for application. 
	 * @param versionId application version.
	 * @param schedularTicks Time at which particular operation is to be triggered
	 * @throws Exception 
	 */
	public void scheduleOperation(String userId, String appId,String deviceId,String operation,String versionId, Long schedularTicks, List<SecretVo> lstSecretVo, boolean retainSecret, List<String> resourcesIds) throws Exception
	{
		mScheduleOperation(userId, appId, deviceId, operation, versionId, schedularTicks, lstSecretVo, retainSecret, null, resourcesIds);
	}

	/**
	 * This method provides functionality to schedule the desired operation being sent to particular device Id.
	 * @param appId application Id.
	 * @param deviceId device Id
	 * @param operation Operation to be performed on device for application. 
	 * @param versionId application version.
	 * @param schedularTicks Time at which particular operation is to be triggered
	 * @throws Exception 
	 */
	public void scheduleAppRestoreOperation(String userId, String appId,String deviceId,String operation,String versionId, Long schedularTicks, List<SecretVo> lstSecretVo, boolean retainSecret, Object detailObject, List<String> resourcesIds) throws Exception
	{
		mScheduleOperation(userId, appId, deviceId, operation, versionId, schedularTicks, lstSecretVo, retainSecret, detailObject, resourcesIds);
	}


	/**
	 * This method schedules operation in batches for all devices given in list.
	 * The batch size, interval, sizefactor and server count is used from Constant.TIMERS("/opt/timers") file, if file is not available then default values from constants is used.  
	 * @param deviceOwnerIds hashmap of device id and its owner id
	 * @param appId applicaiton id which to be install/uninstall/update
	 * @param deviceIds list of device ids.
	 * @param operation Operation to be performed on device for application. 
	 * @param versionId application version id. 
	 * @throws Exception
	 */
	public void scheduleOperationAll(Map<String, String> deviceOwnerIds, String appId,List<String> deviceIds,String operation,String versionId,List<SecretVo> lstSecretVo, boolean  retainSecret, List<String> resourcesIds) throws Exception
	{
		mScheduleOperationAll(deviceOwnerIds, appId,deviceIds,operation,versionId, lstSecretVo, retainSecret, null, resourcesIds);
	}

	/**
	 * This method schedules operation in batches for all devices given in list.
	 * The batch size, interval, sizefactor and server count is used from Constant.TIMERS("/opt/timers") file, if file is not available then default values from constants is used.  
	 * @param deviceOwnerIds hashmap of device id and its owner id
	 * @param appId applicaiton id which to be install/uninstall/update
	 * @param deviceIds list of device ids.
	 * @param operation Operation to be performed on device for application. 
	 * @param versionId application version id. 
	 * @throws Exception
	 */
	public void scheduleAppRestoreOperationAll(Map<String, String> deviceOwnerIds, String appId,List<String> deviceIds,String operation,String versionId,List<SecretVo> lstSecretVo, boolean retainSecret, Object detailObject, List<String> resourcesIds) throws Exception
	{
		mScheduleOperationAll(deviceOwnerIds, appId,deviceIds,operation,versionId, lstSecretVo, retainSecret, detailObject, resourcesIds);
	}

	/**
	 * This method gives secretKey of application using applicationId and userId.
	 * @param appId
	 * @param userId
	 * @return
	 * @throws SQLException 
	 */
	public String getSecretKey(String appId, String userId) throws SQLException {
		return mGetSecretKey(appId, userId);
	}

	/**
	 * Check update of requested application version.
	 * @param appVersionId version id of application.
	 * @return true if update is available otherwise false
	 * @throws SQLException
	 */
	public boolean checkUpdate(String appVersionId) throws SQLException {
		return mCheckUpdate(appVersionId);
	}

	/**
	 * Getting device application detail,
	 * (with isUpdateAvailable) which is installed on given device,
	 * @param appId
	 * @param deviceId
	 * @return
	 * @throws SQLException 
	 */
	public DeviceApplicationVO getInstalledDeviceAppDetail(String appId, String deviceId) throws SQLException {
		return mGetInstalledDeviceAppDetail(appId, deviceId);
	}


	/**
	 * Getting device application detail,
	 * (with isUpdateAvailable) which is installed on given device,
	 * @param appId
	 * @param deviceId
	 * @return
	 * @throws SQLException 
	 */
	public Map<String, Object> getInstalledDeviceAppDetail(String appId,int pageNo, int pageSize) throws SQLException {
		return mGetInstalledDeviceAppDetail(appId,pageNo,pageSize);
	}


	/**
	 * This method give userId of application which is saved in db when app created,
	 * it gives null if app status 'DELETED' and not found, other return userId.
	 * @param appId
	 * @return userId of application.
	 * @throws SQLException
	 */
	public String getUserIdOfApp(String appId) throws SQLException {
		return mGetUserIdOfApp(appId);
	}

	private String mGetUserIdOfApp(String appId) throws SQLException {
		return new ApplicationsEngine().getUserIdOfApp(appId);
	}

	/**
	 * This method give userId and version(0.0.0) of application version
	 * it gives empty list if app status 'DELETED' or not found, otherwise returns userid at index 0 and version at index 1.
	 * @param appVersionId
	 * @return userId,version of application.
	 * @throws SQLException
	 */
	public List<String> getAppVersionAndUserIdOfApp(String appVersionId) throws SQLException {
		return mGetAppVersionAndUserIdOfApp(appVersionId);
	}

	private List<String> mGetAppVersionAndUserIdOfApp(String appVersionId) throws SQLException {
		return new DeveloperApplicationsEngine().getAppVersionAndUserIdOfApp(appVersionId);
	}

	/**
	 * this method for getting new updated application version available or not,
	 * if getting true means new Update Available.
	 * @param appId - unique id of application.
	 * @param appVersionId - of application version installed on device.
	 * @return
	 * @throws SQLException 
	 */
	public boolean getUpdateAvailableForInstalledApp(String appId, String appVersionId, String appPlatformId) throws SQLException{
		return new ApplicationsEngine().getUpdateAvailableForInstalledApp(appId, appVersionId, appPlatformId);
	}

	/**
	 * This method gives basic application detail without any status check,
	 * according to appId param.
	 * @param appId
	 * @return ApplicationVO object.
	 * @throws SQLException 
	 */
	public ApplicationVO getApplicationBasicDetail(String appId) throws SQLException{
		return mGetApplicationBasicDetail(appId);
	}

	public Map<String, Object> listAllLatestVersion(int pageNo, int pageSize) throws SQLException {
		return mListAllLatestVersion(pageNo, pageSize);
	}
	/**
	 * This method gives basic application detail without any status check,
	 * according to appId param.
	 * @param appId
	 * @return ApplicationVO object.
	 * @throws SQLException 
	 */
	private ApplicationVO mGetApplicationBasicDetail(String appId) throws SQLException {
		return new ApplicationsEngine().getApplicationBasicDetail(appId);
	}

	private DeviceApplicationVO mGetInstalledDeviceAppDetail(String appId, String deviceId) throws SQLException {
		return new ApplicationsEngine().getInstalledDeviceAppDetail(appId, deviceId);
	}


	private Map<String, Object> mGetInstalledDeviceAppDetail(String appId,int pageNo, int pageSize) throws SQLException {
		return new ApplicationsEngine().getInstalledDeviceAppDetail(appId,pageNo,pageSize);
	}



	/**
	 * This method gives secretKey of application using applicationId and userId.
	 * @param appId
	 * @param userId
	 * @return
	 * @throws SQLException
	 */
	private String mGetSecretKey(String appId, String userId) throws SQLException {
		/**
		 * call getSecretKey() method for getting secretKey,
		 *  using appId and userId(who create this application).
		 */
		return new ApplicationsEngine().getSecretKey(appId, userId);
	}



	private Map<String, Object> mSearchApps(int pageNo, int pageSize,
			List<FilterObject> filters,boolean toListAllApps) throws SQLException {
		ApplicationsEngine applicationsEngine = new ApplicationsEngine();
		return applicationsEngine.searchApps(pageNo, pageSize, filters, toListAllApps);
	}

	private List<ApplicationVO> mListApps(String searchText) throws SQLException {
		ApplicationsEngine applicationsEngine = new ApplicationsEngine();
		return applicationsEngine.suggestedApps(searchText);
	}

	private ApplicationDetailsVO mGetAppDetail(String appId,String userId) throws SQLException {
		ApplicationsEngine applicationsEngine = new ApplicationsEngine();
		//#AKH_01_1
		return applicationsEngine.getAppDetail(appId,userId);
	}

	private List<AppCommandVO> mGetAppCommandsForUser(String appId,String userId,List<String> grpIds) throws SQLException {
		ApplicationsEngine applicationsEngine = new ApplicationsEngine();
		return applicationsEngine.getAppCommandsForUser(appId,userId, grpIds);
	}

	private AppInstallDetailsVO mGetAppInstallDetail(String appId, String versionId, String appPlatformId) throws SQLException {
		ApplicationsEngine applicationsEngine = new ApplicationsEngine();
		return applicationsEngine.getAppInstallDetail(appId, versionId, appPlatformId);
	}

	private List<VersionVO> mListVersionOfApplication(String appId,
			String userId) throws SQLException {
		ApplicationsEngine applicationsEngine = new ApplicationsEngine();
		return applicationsEngine.listVersionOfApplication(appId, userId);
	}

	private boolean mCheckUpdate(String appVersionId) throws SQLException {
		DeveloperApplicationsEngine developerApplicationsEngine = new DeveloperApplicationsEngine();
		return developerApplicationsEngine.checkUpdate(appVersionId);
	}
	private Map<String, Object> mListAllLatestVersion(int pageNo, int pageSize) throws SQLException {
		ApplicationsEngine applicationsEngine = new ApplicationsEngine();
		return applicationsEngine.listAllLatestVersion(pageNo, pageSize);
	}
	

	private void mScheduleOperationAll(Map<String, String> deviceOwnerIds, String appId, List<String> listDevices, String operation,String versionId,List<SecretVo> lstSecretVo, boolean retainSecret, Object detailObject, List<String> resourcesIds) throws Exception
	{
		long schedularTicks = 0;

		int batchSize = Constant.DEFAULT_BATCHSIZE;
		long interval = Constant.DEFAULT_INTERVAL;
		long sizeFactor = Constant.DEFALUT_SIZE_FACTOR;
		int serverCount = Constant.DEFALUT_SERVER_COUNT;
		if(buildFile(Constant.TIMERS).exists()){
			try{
				JSONParser parser = buildJSONParser();
				JSONObject obj = (JSONObject) parser.parse(buildFileReader());
				serverCount = Integer.parseInt(obj.get("serverCount").toString());

				batchSize = Integer.parseInt(obj.get("batchSize").toString()) * serverCount;
				interval = Long.parseLong(obj.get("interval").toString());
				sizeFactor = Long.parseLong(obj.get("sizeFactor").toString());
			}catch(Exception e){
				PALogger.ERROR(e);	
			}
		}else{
			batchSize = batchSize*serverCount;
		}


		int batchCount = 0;
		long intervalToAdd = 0;
		boolean isAppSizeSet = false; 
		long currentTimestamp = new Date().getTime();
		for (String deviceId : listDevices) 
		{
			batchCount++;
			/*
			 * use this check for updateAppSecret - CommandEnum also.
			 */
			if(CommandEnum.installApplication == CommandEnum.valueOf(operation) 
					|| CommandEnum.updateApplication == CommandEnum.valueOf(operation)){
				ApplicationPlatformVO appPlatformVO = new Platform().getDeviceApplicationPlatForm(appId, deviceId);
				if(appPlatformVO == null){
					PALogger.INFO("Application does not support Appliance's platform.");
					continue;
				}
				if(!isAppSizeSet){
					AppInstallDetailsVO applicationVO = new Applications().getAppInstallDetail(appId,versionId, appPlatformVO.getAppPlatformId());

					if(applicationVO != null){
						if(applicationVO.getSize() > sizeFactor){
							long appSize = applicationVO.getSize();
							interval =  (appSize/sizeFactor)*interval;
						}
						isAppSizeSet = true;						
						//#HDV_02_2
						if(applicationVO.getVersionId()==null){
							throw new Exception(Constant.VERSIONNOTAVAILABLE);
						}
					}
					//#HDV_02_2
					else{
						throw new Exception(Constant.APPISNOTAVAILABLE);
					}
				}
			}
			//			  schedule job for now()+ intervalToAdd
			schedularTicks = currentTimestamp + intervalToAdd;

			mScheduleOperation(deviceOwnerIds.get(deviceId), appId, deviceId, operation, versionId, schedularTicks, TypeEnum.Device,lstSecretVo,retainSecret, detailObject, resourcesIds);

			if(batchCount % batchSize == 0)
			{
				currentTimestamp = new Date().getTime();
				intervalToAdd += interval;
			}
		}	

	}

	private void mExecuteOperation(String appId,String deviceId,String operation,String versionId,String jobId) throws SQLException
	{
		// TODO Execute operation (Install and Update Application on that device).


		NotificationMessage notificationMessage=new NotificationMessage();
		notificationMessage.setNotificationId(UUID.randomUUID().toString());
		notificationMessage.setCommand(operation);
		notificationMessage.setApplicationId(appId);
		notificationMessage.setVersionId(versionId);
		notificationMessage.setJobId(jobId);
		/*
		 * set AppNotificationVo (application basic detail(version, size, title)),
		 * in notification message object.
		 */
		AppNotificationVo appNotifyVO = null;
		if(CommandEnum.uninstallApplication ==  CommandEnum.valueOf(operation)){
			DeviceApplicationVO deviceAppVo =  new ApplicationsEngine().getInstalledDeviceAppDetail(appId, deviceId);
			appNotifyVO = new AppNotificationVo();
			appNotifyVO.setAppId(deviceAppVo.getApplicationId());
			appNotifyVO.setVersionId(deviceAppVo.getAppVersionId());
			appNotifyVO.setVersion(deviceAppVo.getVersion());
			appNotifyVO.setTitle(deviceAppVo.getTitle());
			appNotifyVO.setSize(deviceAppVo.getSize());
		}else{
			appNotifyVO = new ApplicationsEngine().getAppDetailsForNotification(appId, versionId);
		}
		notificationMessage.setMessage(appNotifyVO);
		new Gson().toJson(notificationMessage);
	}



	private void mScheduleOperation(String userId, String appId,String deviceId,String operation, String versionId, Long schedularTicks, List<SecretVo> lstSecretVo, boolean retainSecret, Object detailObject, List<String> resourcesIds) throws Exception
	{
		mScheduleOperation(userId, appId, deviceId, operation, versionId, schedularTicks, TypeEnum.Device,lstSecretVo,retainSecret, detailObject, resourcesIds);
	}

	/**
	 * Function schedules and insert a schedule job in database
	 * @param appId
	 * @param labelDeviceId
	 * @param operation
	 * @param versionId
	 * @param schedularTicks
	 * @param labelDevice
	 * @throws Exception 
	 */
	private void mScheduleOperation(String userId, String appId, String labelDeviceId, String operation,String versionId, Long schedularTicks, TypeEnum labelDevice,List<SecretVo> lstSecretVo,boolean retainSecret, Object detailObject, List<String> resourcesIds) throws Exception {
		InstallJobEngine job = new InstallJobEngine();
		job.getJob(userId, appId, labelDeviceId);
		InstallJobVO jobVO = new InstallJobVO();
		jobVO.setAppId(appId);
		jobVO.setAppVersion(versionId);
		jobVO.setStatus(InstallJobStatusEnum.PENDING);
		jobVO.setLastModified(0);
		jobVO.setobjectId(labelDeviceId);
		jobVO.setTimeStamp(schedularTicks);						
		jobVO.setType(labelDevice);
		jobVO.setUserId(userId);
		jobVO.setInstalledJobId(Common.getRandomId());
		jobVO.setOperation(operation);




		boolean forceUninstall = false;
		/*
		 * use this check for updateAppSecret - CommandEnum also.
		 */
		if(CommandEnum.installApplication == CommandEnum.valueOf(operation)
				|| CommandEnum.updateApplication == CommandEnum.valueOf(operation)){
			/**
			 * Get old composeVersion from applicationversion table...
			 */
			PALogger.INFO("Getting Compose version for  appId " + appId + " version Id " + versionId);
			String newComposeVersion = new DeveloperApplications().getComposeVersion(appId, versionId);
			PALogger.INFO("new_ComposeVersion " + newComposeVersion );

			PALogger.INFO("Getting Compose version for installedApplication deviceId " + labelDeviceId + " app Id " + appId);

			String existingComposeVersion = new DeveloperApplications().getInstalledApplicationComposeVersion(labelDeviceId, appId);
			PALogger.INFO("existing_ComposeVersion " + existingComposeVersion );

			if(existingComposeVersion != null) //applcation's some version already installed on device 
			{
				if(existingComposeVersion.equals(""))
				{
					//Installed old version is 2
					existingComposeVersion = "2";
				}
				if(newComposeVersion.equals("")) //new 
				{
					newComposeVersion = "2";
				}
				/**
				 * if both compose versions are different then uninstall forcefully is true.
				 */
				if(!existingComposeVersion.equals(newComposeVersion))
				{
					PALogger.INFO("existing_ComposeVersion != new_ComposeVersion values are --> " + existingComposeVersion + " != " + newComposeVersion);
					PALogger.INFO("set forceUninstall true");
					forceUninstall = true;
				}
				else
				{
					PALogger.INFO("existing_ComposeVersion == new_ComposeVersion  values are --> " + existingComposeVersion + " = " + newComposeVersion);
					PALogger.INFO("set forceUninstall false");
				}
			}
			/**
			 * Added details to install forcefully
			 */


			if(!checkApplicationLimitation(appId, versionId, labelDeviceId))
			{
				jobVO.setStatus(InstallJobStatusEnum.FAILED);
				jobVO.setMessage(ErrorMessage.NOT_ENOUGH_RESOURCES_AVAILABLE);
			}
		}

		HashMap<String, Object> detailHash = new HashMap<>();
		detailHash.put("forceUninstall", forceUninstall);
		detailHash.put("purge", true);


		//Fill app resourceVos
		if(resourcesIds != null && !resourcesIds.isEmpty()) {
			List<AppResourceVO> appResourceVOs = new ApplicationResourceEngine().get(resourcesIds);


			for (AppResourceVO appResourceVO : appResourceVOs) {
				if(!detailHash.containsKey(appResourceVO.getKind().getInstallDetailKeyName())) {
					List<AppResourceVO> resourceVOs = new ArrayList<>();
					resourceVOs.add(appResourceVO);
					detailHash.put(appResourceVO.getKind().getInstallDetailKeyName(), resourceVOs);
				} else {
					((List<AppResourceVO>)detailHash.get(appResourceVO.getKind().getInstallDetailKeyName())).add(appResourceVO);
				}
			}
		}

		if(detailObject != null) {
			detailHash.put("detailObject", new Gson().toJson(detailObject));
		}
		detailHash.put("retainSecret", retainSecret);
		jobVO.setDetail(new Gson().toJson(detailHash));

		job.addJob(jobVO,lstSecretVo);

	}




	/**
	 * This method that if device have enough resources to install application. -PS
	 * check cpu cores and memory available on device.
	 * In case of kubernetes all nodes return true if any of node device have memory and cpu as required by application containers.    
	 * @param appId application id to install on device
	 * @param versionId version of application to be installed 
	 * @param deviceId device id in case of docker compose and cluster id in case of kubernetes.
	 * @return boolean to show whether we can add job or not for device to install application 
	 * @throws SQLException 
	 * @throws IOException 
	 * @throws Exception
	 */
	private boolean checkApplicationLimitation(String appId, String versionId, String deviceId) throws SQLException, IOException
	{	
		/**
		 * Get application basic details by appid  to check application type
		 */
		ApplicationVO appvo = getApplicationBasicDetail(appId);			
		List<AppTypeVO> types = new DeveloperApplications().getAllAppType();

		ApplicationDefaultType type = ApplicationDefaultType.dockercompose;
		for (AppTypeVO appTypeVO : types) 
		{
			if(appvo.getAppTypeId().equals(appTypeVO.getTypeId()))
			{
				type =  ApplicationDefaultType.valueOf(appTypeVO.getType());
				break;
			}
		}

		/**
		 * Get the composer file path for given application 
		 */		
		String composeYMLPath = new DeveloperApplications().getVersionComposeYMLPath(appId, versionId);		

		/**
		 * Get box Statistics for device 
		 */
		HashMap<String, String> bsHashMap =  (HashMap<String, String>)new BoxStaticsEngine().getBoxStatics(deviceId);

		/**
		 * If the device is docker compoe type
		 */
		if(type == ApplicationDefaultType.dockercompose)
		{	
			/**
			 * If box Statistics exists
			 */
			if(bsHashMap.size() > 0)
			{
				String firstKey = bsHashMap.keySet().toArray()[0].toString();
				String statics = bsHashMap.get(firstKey);		

				HashMap<String, Object> bsHash1 = new Gson().fromJson(statics, HashMap.class);

				LinkedTreeMap<String, String> s1 = (LinkedTreeMap<String, String>)bsHash1.get("SystemInfo");

				/** 
				 * Get properties cpuCores and memoryTotal of device from system info  
				 */
				int cpuCoresDevice = Integer.parseInt(s1.get("CpuCores"));
				long memoryTotalDevice = Utils.SizeReverseConverter((s1.get("MemoryTotal")));

				/**
				 * parse Yaml file content to get ComposeVO object
				 * 
				 */

				String decYmlPath = TempFiles.getTempFolderPath()+new File(composeYMLPath).getName();
				FileEncryptionDecryption.Decrypt_File(composeYMLPath, decYmlPath, buildCredProvider().getEcnKey());
				ComposeVO composeVO= YamlParser.parse(decYmlPath);

				FileUtils.deleteQuietly(new File(decYmlPath));

				//Resolved issue with yaml version check - PS 
				if(composeVO.getVersion().startsWith("2")){
					/**
					 * For each section in yaml loop to check thye limit given for application 
					 */
					for (String sectionName : composeVO.getServices().keySet()) 
					{			
						SectionVO section = composeVO.getServices().get(sectionName);


						if(section.getCpuset() != null)
						{
							String cpu = section.getCpuset();
							int cpuSetApplication =0;
							if(cpu.contains("-")) {
								cpu=cpu.split("-")[1];
								cpuSetApplication =Integer.parseInt(cpu)+1;
							} else {
								cpuSetApplication = Integer.parseInt(section.getCpuset());
							}

							/**
							 * if device not have memory or cores required by application then return false
							 */
							if(cpuSetApplication > cpuCoresDevice)
							{
								//Add job with error
								return false;
							}
						}

						if(section.getMem_limit() != null)
						{
							long memLimitApplication =  Utils.SizeReverseConverterForYaml(section.getMem_limit());

							/**
							 * if device not have memory or cores required by applicaiton then return false
							 */
							if(memLimitApplication > memoryTotalDevice)
							{
								//Add job with error
								return false;
							}
						}
					}	
				}
				else{ //docker compose version 3
					//cpu 

					//memory 

					for (String sectionName : composeVO.getServices().keySet()) 
					{

						SectionVO section = composeVO.getServices().get(sectionName);
			

						LinkedTreeMap<String, Object> hashtable =  (LinkedTreeMap<String, Object>) section.getDeploy().get("resources");

						if(hashtable != null){

							hashtable =  (LinkedTreeMap<String, Object>) hashtable.get("limits");

							if(hashtable != null && hashtable.get("memory") != null)
							{
								long mem_limitApplication =  Utils.SizeReverseConverterForYaml(hashtable.get("memory").toString());

								/**
								 * if device not have memory or cores required by applicaiton then return false
								 */
								if(mem_limitApplication > memoryTotalDevice)
								{
									//Add job with error
									return false;
								}
							}
						}

					}


				}
			}
			return true;
		}
		else{
			//		case of kubernetes implementation can found from git history - PS
			return true; 
		}
	}

	/**
	 * Get all the files exists in a folder 
	 * @param pathname
	 * @return
	 */
	public  List<String> getFilePaths(String pathname) 
	{
		List<String>  paths = new ArrayList<>();
		List<File> files=  Arrays.asList(buildFile(pathname).listFiles());
		for (File file : files) 
		{
			if(file.getAbsolutePath().endsWith(".yaml")||file.getAbsolutePath().endsWith(".yml"))
				paths.add(file.getAbsolutePath());
		}
		return paths;
	}


	private List<String> mListGroupsOfApp(String appId, List<String> groupIds) throws SQLException {

		return new ApplicationsEngine().listGroupsOfApp(appId, groupIds);
	}
	public List<Map<String, String>> getCount() throws SQLException
	{
		return mGetCount();
	}
	private List<Map<String, String>> mGetCount() throws SQLException
	{
		return new ApplicationsEngine().getCount();
	}
	
	public CredProvider buildCredProvider() {
		return new CredProvider();
	}
	
	public File buildFile(final String path) {
		return new File(path);
	}

	public FileReader buildFileReader() throws FileNotFoundException {
		return new FileReader(Constant.TIMERS);
	}

	public JSONParser buildJSONParser() {
		return new JSONParser();
	}
}
/**
 * History of check-in or issue resolved
 * 
 * 01 - 12-10-2016 
 * AKH_01_1
 * Remove isDeveloper from param, because in old method mashup with getDevAppDetail and getAppInstallDetail and use unnecessary query. 
 * 
 * 02 - 30-7-2018
 * HDV_02_2
 * Apply check for version id as if version is not available while installing an app. 
 * Bug Id :- 1380
 */
