/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.framework;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.amazonaws.services.route53.model.ChangeAction;
import com.google.gson.Gson;
import com.mwp.common.Client;
import com.mwp.common.StringFunctions;
import com.mwp.common.constant.Constant;
import com.mwp.common.enums.NodeType;
import com.mwp.common.enums.RelayEnum.NetworkTypeEnum;
import com.mwp.common.enums.StateEnum;
import com.mwp.common.vo.DeviceNodeVO;
import com.mwp.common.vo.DiscoveryDetailsVO;
import com.mwp.common.vo.DiscoveryJarDetailsVO;
import com.mwp.common.vo.ValidationInfoVO;
import com.mwp.logger.PALogger;
import com.mwp.p.common.Constants;
import com.mwp.p.common.PortalCommon;
import com.mwp.p.dal.engine.AssignedRelayPortsEngine;
import com.mwp.p.dal.engine.DevicesEngine;
import com.mwp.p.dal.engine.DiscoveryDetailsEngine;
import com.mwp.p.dal.engine.RelayServersEngine;
import com.mwp.p.framework.ManageDomainNameGoogle.DomainOperation;
import com.sun.research.ws.wadl.HTTPMethods;

public class DiscoveryDetails {

	private String HTTPS_PREFIX = "https://";
	
	/**
	 * This method set all properties to detailVO object and then insert discovery details into database.Also Edit localIPAddress, RelayServer address etc domain name on public portals.
	 * @param deviceId
	 * @param iPAddress
	 * @param localIPAddress
	 * @param chatInputChannel
	 * @param chatOutputChannel
	 * @param chatSubscriptionChannel
	 * @param nodeCommunicationPort
	 * @param openStackPort
	 * @param tomcatPort
	 * @param port1
	 * @param port2
	 * @param port3
	 * @param port4
	 * @param port5
	 * @param rURLTomcatPort
	 * @param rAddress
	 * @param status
	 * @param relayServerID
	 * @param networkType
	 * @return
	 * @throws SQLException 
	 * @throws Exception
	 */
	public String setDiscoveryDetails(String deviceId, String iPAddress, String localIPAddress, String chatInputChannel, 
			String chatOutputChannel, String chatSubscriptionChannel, String nodeCommunicationPort, String openStackPort,
			String tomcatPort, String port1, String port2, String port3, String port4, String port5, String rURLTomcatPort, 
			String rAddress, int status, String relayServerID, NetworkTypeEnum networkType) throws SQLException {

	
		PALogger.INFO("=====Set Discovery Details====" + networkType + "============");
		String connectURL = "";
		String makeUrl = "";
		String oldLocalIPAddress="";
		String oldRelayServerAddress="";
		String[] iPAddressArr = iPAddress.split(",");
		String domain = iPAddressArr[0].trim();
		iPAddress =iPAddressArr[1].trim();		
		iPAddress = domain + "," + iPAddress;

		if(status==0)
		{
			status = 4;	
		} else {
			status = 1;
		}
		PALogger.INFO("=====Set Discovery Details====" + deviceId + "======Status======"+status);

		
		DiscoveryDetailsVO row = isDiscoveryDetailsExists(deviceId);
		if(row == null){
			makeUrl = iPAddress;		
			connectURL = "";			
		}
		else{
			makeUrl = row.getsIPAddress();
			connectURL = row.getsConnectURL();
			oldLocalIPAddress = row.getsLocalIPAddress();
			oldRelayServerAddress = (StringFunctions.isNullOrWhitespace(row.getsRelayServerAddress()))?"":row.getsRelayServerAddress();
		}
		DiscoveryDetailsVO detailsVO = new DiscoveryDetailsVO();

		detailsVO.setnNodeStatus(0);
		detailsVO.setnStatus(status);
		detailsVO.setsChatInputChannel(chatInputChannel);
		detailsVO.setsChatOutputChannel(chatOutputChannel);
		detailsVO.setsChatSubscriptionChannel(chatSubscriptionChannel);
		detailsVO.setsDeviceID(deviceId);
		detailsVO.setsConnectURL(connectURL);
		detailsVO.setsIPAddress(iPAddress);
		detailsVO.setsLocalIPAddress(localIPAddress);
		detailsVO.setsMasterID(deviceId);
		detailsVO.setsNetworkType(networkType);
		detailsVO.setsNodeCommunicationPort(nodeCommunicationPort);
		detailsVO.setsOpenStackPort(openStackPort);
		detailsVO.setsPort1(port1);
		detailsVO.setsPort2(port2);
		detailsVO.setsPort3(port3);
		detailsVO.setsPort4(port4);
		detailsVO.setsPort5(port5);
		detailsVO.setsRAddress(rAddress);
		detailsVO.setsRelayServerID(relayServerID);
		detailsVO.setsRingID("");
		detailsVO.setsRURLTomcatPort(rURLTomcatPort);
		detailsVO.setsTomcatPort(tomcatPort);

		new DiscoveryDetailsEngine().addDiscoveryDetails(detailsVO);


		DeviceNodeVO deviceVO = new DevicesEngine().getNode(deviceId, false);
		String deviceName = "";
		String clusterName = null;
		if(deviceVO != null) {			
			deviceName = deviceVO.getDeviceName();
			//Added Check related to multimaster implementation.Resolve cluster name for active  master,-PS
			if(deviceVO.getDeviceRole() == NodeType.MASTER && deviceVO.getDeviceState() == StateEnum.Active)
			{
				clusterName = new DevicesEngine().getClusterName(deviceId);
			}
		}


		String connectionIP = "";
		PALogger.INFO("=====Discovery Details Added ====" + deviceName + "============");

		if(!PortalCommon.getInstance().isRelay(networkType))//Not Relay
		{
			PALogger.INFO("=====NetworkType is not relay setDiscovery Details====" + networkType + "============");
			String[] extIPAddresses = iPAddress.split(",");
			String[] makeUrls = makeUrl.split(",");
			PALogger.INFO("=====NetworkType is not relay setDiscovery Details====" + makeUrls + "======"+ extIPAddresses + "======");

			if(!makeUrls[1].equals(extIPAddresses[1])){

				switch (Constants.getDNS_SERVER()) {
				case AMZ:
					manageDomainName(ChangeAction.UPSERT, deviceId, deviceName, clusterName, extIPAddresses[1], makeUrls[1]);
					break;
				case AZR:
					break;
				case GOO:
					manageDomainNameGoogle(DomainOperation.Edit, deviceId, deviceName, clusterName, extIPAddresses[1],makeUrls[1]);
					break;
				case JD:
					manageDomainNameJD(DomainOperation.Edit, deviceId, deviceName, clusterName, extIPAddresses[1],makeUrls[1]);
					break;
				default:
					break;
				}

			}

			String localDeviceName = "l-" + deviceName.trim();
			String localClusterName = null;
			if(clusterName!= null)
				localClusterName = "l-" + clusterName.trim();

			if(!oldLocalIPAddress.equals(localIPAddress)){
			

				switch (Constants.getDNS_SERVER()) {
				case AMZ:
					ManageDomainName.runCommand(ChangeAction.UPSERT, localDeviceName, localIPAddress);
					PALogger.INFO("=====NetworkType RunCommand local setDiscovery Details====" + localDeviceName + "======" + localIPAddress + "======");				

					if(localClusterName != null)
					{
						ManageDomainName.runCommand(ChangeAction.UPSERT, localClusterName, localIPAddress);
						PALogger.INFO("=====NetworkType RunCommand local setDiscovery Details====" + localClusterName + "======" + localIPAddress + "======");				
					}
					break;
				case AZR:
					break;
				case GOO:
					ManageDomainNameGoogle.runCommand(DomainOperation.Edit, localDeviceName, localIPAddress,oldLocalIPAddress);
					PALogger.INFO("=====NetworkType RunCommand local setDiscovery Details====" + localDeviceName + "======" + localIPAddress + "======");				

					if(localClusterName != null)
					{
						ManageDomainNameGoogle.runCommand(DomainOperation.Edit, localClusterName, localIPAddress,oldLocalIPAddress);
						PALogger.INFO("=====NetworkType RunCommand local setDiscovery Details====" + localClusterName + "======" + localIPAddress + "======");				
					}
					break;
				case JD:
					ManageDomainNameJD.runCommand(DomainOperation.Edit, localDeviceName, localIPAddress,oldLocalIPAddress);
					PALogger.INFO("=====NetworkType RunCommand local setDiscovery Details====" + localDeviceName + "======" + localIPAddress + "======");				

					if(localClusterName != null)
					{
						ManageDomainNameJD.runCommand(DomainOperation.Edit, localClusterName, localIPAddress,oldLocalIPAddress);
						PALogger.INFO("=====NetworkType RunCommand local setDiscovery Details====" + localClusterName + "======" + localIPAddress + "======");				
					}
					break;
				default:
					break;
				}


				
			}

			connectionIP = HTTPS_PREFIX + extIPAddresses[1].trim() + ":" + tomcatPort + "/" + PortalCommon.getInstance().getUIPath() +"/";
			PALogger.INFO("=====Update Discovery Details ====" + connectionIP + "============");
			new DiscoveryDetailsEngine().updateDiscoveryDetails(connectionIP, "", "",  deviceId);

			String rAddressName = "r-"+deviceName.trim();
			String rClusterName = null;
			if(clusterName!= null)
				rClusterName = "r-"+ clusterName.trim();

			String relayServerAddress = new RelayServersEngine().getRelayServerAddress(relayServerID);
			if(!StringFunctions.isNullOrWhitespace(relayServerAddress)){
				PALogger.INFO("=====RelayServerAddress in setDiscovery Details====" + relayServerAddress + "============");
				if(!oldRelayServerAddress.equals(relayServerAddress)){

					switch (Constants.getDNS_SERVER()) {
					case AMZ:
						ManageDomainName.runCommand(ChangeAction.UPSERT, rAddressName, relayServerAddress);
						if(rClusterName != null)
							ManageDomainName.runCommand(ChangeAction.UPSERT, rClusterName, relayServerAddress);
						break;
					case AZR:
						break;
					case GOO:
						ManageDomainNameGoogle.runCommand(DomainOperation.Edit, rAddressName, relayServerAddress,oldRelayServerAddress);
						if(rClusterName != null)
							ManageDomainNameGoogle.runCommand(DomainOperation.Edit, rClusterName, relayServerAddress,oldRelayServerAddress);
						break;
					case JD:
						ManageDomainNameJD.runCommand(DomainOperation.Edit, rAddressName, relayServerAddress,oldRelayServerAddress);
						if(rClusterName != null)
							ManageDomainNameJD.runCommand(DomainOperation.Edit, rClusterName, relayServerAddress,oldRelayServerAddress);
						break;
					default:
						break;
					}


					

				}
			}
		}
		else 
		{
			PALogger.INFO("=====NetworkType in setDiscovery Details====" + networkType + "============");
			String relayServerAddress = new RelayServersEngine().getRelayServerAddress(relayServerID);
			if(!StringFunctions.isNullOrWhitespace(relayServerAddress)){
				PALogger.INFO("=====RelayServerAddress in setDiscovery Details====" + relayServerAddress + "============");

				PALogger.INFO("=====Set devicename on with domain in set discovery====" + deviceName + "======" + relayServerAddress + "======");
				if(!oldRelayServerAddress.equals(relayServerAddress) || !PortalCommon.getInstance().isRelay(row.getsNetworkType())){
					switch (Constants.getDNS_SERVER()) {
					case AMZ:
						manageDomainName(ChangeAction.UPSERT, deviceId, deviceName, clusterName, relayServerAddress, oldRelayServerAddress);
						break;
					case AZR:
						break;
					case GOO:
						manageDomainNameGoogle(DomainOperation.Edit, deviceId, deviceName, clusterName, relayServerAddress, oldRelayServerAddress);
						break;
					case JD:
						manageDomainNameJD(DomainOperation.Edit, deviceId, deviceName, clusterName, relayServerAddress, oldRelayServerAddress);
						break;
					default:
						break;
					}

					

				}
			}
			String localDeviceName = "l-" + deviceName.trim();

			String localClusterName = null;
			if(clusterName != null)
				localClusterName = "l-" + clusterName.trim();

			if(!oldLocalIPAddress.equals(localIPAddress)){
				switch (Constants.getDNS_SERVER()) {
				case AMZ:
					ManageDomainName.runCommand(ChangeAction.UPSERT, localDeviceName, localIPAddress);				
					PALogger.INFO("=====NetworkType RunCommand setDiscovery local Details====" + localDeviceName + "======" + localIPAddress + "======");

					if(localClusterName != null)				
					{	
						ManageDomainName.runCommand(ChangeAction.UPSERT, localClusterName, localIPAddress);
						PALogger.INFO("=====NetworkType RunCommand setDiscovery local Details====" + localClusterName + "======" + localIPAddress + "======");

					}
					break;
				case AZR:
					break;
				case GOO:
					ManageDomainNameGoogle.runCommand(DomainOperation.Edit, localDeviceName, localIPAddress,oldLocalIPAddress);				
					PALogger.INFO("=====NetworkType RunCommand setDiscovery local Details====" + localDeviceName + "======" + localIPAddress + "======");

					if(localClusterName != null)				
					{	
						ManageDomainNameGoogle.runCommand(DomainOperation.Edit, localClusterName, localIPAddress,oldLocalIPAddress);
						PALogger.INFO("=====NetworkType RunCommand setDiscovery local Details====" + localClusterName + "======" + localIPAddress + "======");

					}
					break;
				case JD:
					ManageDomainNameJD.runCommand(DomainOperation.Edit, localDeviceName, localIPAddress,oldLocalIPAddress);				
					PALogger.INFO("=====NetworkType RunCommand setDiscovery local Details====" + localDeviceName + "======" + localIPAddress + "======");

					if(localClusterName != null)				
					{	
						ManageDomainNameJD.runCommand(DomainOperation.Edit, localClusterName, localIPAddress,oldLocalIPAddress);
						PALogger.INFO("=====NetworkType RunCommand setDiscovery local Details====" + localClusterName + "======" + localIPAddress + "======");

					}
					break;
				default:
					break;
				}
				
				
				

			}

			connectionIP = HTTPS_PREFIX + relayServerID + ":" + tomcatPort + "/" + PortalCommon.getInstance().getUIPath() +"/";
			PALogger.INFO("=====Update Discovery Details ====" + connectionIP + "============");
			new DiscoveryDetailsEngine().updateDiscoveryDetails(connectionIP, "", "",  deviceId);

			String rAddressName = "r-" + deviceName.trim();
			String rClusterName = null;
			if(clusterName!= null)
				rClusterName = "r-"+ clusterName.trim();

			if(!oldRelayServerAddress.equals(relayServerAddress)){
				
				switch (Constants.getDNS_SERVER()) {
				case AMZ:
					ManageDomainName.runCommand(ChangeAction.UPSERT, rAddressName, relayServerAddress);				
					PALogger.INFO("=====NetworkType RunCommand setDiscovery RAddressName====" + rAddressName + "======" + relayServerAddress + "======");

					if(rClusterName != null)
					{
						ManageDomainName.runCommand(ChangeAction.UPSERT, rClusterName, relayServerAddress);
						PALogger.INFO("=====NetworkType RunCommand setDiscovery RClusterName====" + rClusterName + "======" + relayServerAddress + "======");
					}
					break;
				case AZR:
					break;
				case GOO:
					ManageDomainNameGoogle.runCommand(DomainOperation.Edit,  rAddressName, relayServerAddress,oldRelayServerAddress);				
					PALogger.INFO("=====NetworkType RunCommand setDiscovery RAddressName====" + rAddressName + "======" + relayServerAddress + "======");

					if(rClusterName != null)
					{
						ManageDomainNameGoogle.runCommand(DomainOperation.Edit, rClusterName, relayServerAddress,oldRelayServerAddress);
						PALogger.INFO("=====NetworkType RunCommand setDiscovery RClusterName====" + rClusterName + "======" + relayServerAddress + "======");
					}
					break;
				case JD:
					ManageDomainNameJD.runCommand(DomainOperation.Edit,  rAddressName, relayServerAddress,oldRelayServerAddress);				
					PALogger.INFO("=====NetworkType RunCommand setDiscovery RAddressName====" + rAddressName + "======" + relayServerAddress + "======");

					if(rClusterName != null)
					{
						ManageDomainNameJD.runCommand(DomainOperation.Edit, rClusterName, relayServerAddress,oldRelayServerAddress);
						PALogger.INFO("=====NetworkType RunCommand setDiscovery RClusterName====" + rClusterName + "======" + relayServerAddress + "======");
					}
					break;
				default:
					break;
				}
			}
		}
		PALogger.INFO("=====Set Discovery Details ==== deviceId- "+deviceId +" == deviceName- " + deviceName +" == connectUrl- " + connectionIP + "============");
		if(clusterName != null)
			PALogger.INFO("=====Set Discovery Details ==== deviceId- "+deviceId +" == clusterName- " + clusterName +" == connectUrl- " + connectionIP + "============");

		return "Success";
	}

	/**
	 * 
	 * @param detailsVO
	 * @param infoVO
	 * @return
	 * @throws Exception if device id is null or empty
	 */
	public Map<String, Object> receiveRelayDiscoveryDetails(DiscoveryJarDetailsVO detailsVO, ValidationInfoVO infoVO) throws Exception {

		if(StringFunctions.isNullOrWhitespace(detailsVO.getsDeviceId())){
			throw new Exception("deviceId must required.");
		}
		detailsVO.setnStatus(1);
		return new RelayServers().setupRelayDiscoveryDetails(infoVO.getsMACAddress(),
				infoVO.getnStatus(),
				infoVO.getsGUID(),																   
				infoVO.getnTimestamp(),
				infoVO.getEmail(),
				infoVO.getHostName(),
				infoVO.getSwLicense(),
				infoVO.getHwConfig(),
				detailsVO.getsDeviceId(),
				detailsVO.getsIPAddress(),
				detailsVO.getsLocalIPAddress(),
				detailsVO.getsChatInputChannel(),
				detailsVO.getsChatOutputChannel(),
				detailsVO.getsChatSubscriptionChannel(),
				detailsVO.getsNodeCommunicationPort(),
				detailsVO.getsOpenStackPort(),
				detailsVO.getsTomcatPort(),
				detailsVO.getsPort1(),
				detailsVO.getsPort2(),
				detailsVO.getsPort3(),
				detailsVO.getsPort4(),
				detailsVO.getsPort5(),
				detailsVO.getsRURLTomcatPort(),
				detailsVO.getsRAddress(),
				detailsVO.getIsSetRURL(),
				detailsVO.getnStatus());
	}


	public DiscoveryDetailsVO getDiscoveryDetails(String deviceId) throws SQLException {
		PALogger.INFO("=====Call getDiscoveryDetails method ===="+ deviceId +"============");
		return new DiscoveryDetailsEngine().getDiscoveryDetailsVO(deviceId, true);

	}

	public DiscoveryDetailsVO getDiscoveryDetailsByName(String deviceName) throws Exception {
		DiscoveryDetailsVO detailsVO = new DiscoveryDetailsEngine().getDiscoveryDetailsVOByName(deviceName, true);
		if(detailsVO == null) {
			throw new Exception(Constant.NOTFOUND);
		}
		return detailsVO;
	}

	public String getClientIP(HttpServletRequest request) {
		return mGetClientIP(request);
	}

	public void updateDeviceHeartbeat(String deviceId) throws SQLException {
		new DiscoveryDetailsEngine().updateDeviceHeartbeat(deviceId);
	}	

	/**
	 * 
	 * @param ipAddress
	 * @param port
	 * @param deviceId
	 * @param deviceName
	 * @param port5
	 * @param backCallerRestPath
	 * @return
	 * @throws IOException 
	 * @throws KeyStoreException 
	 * @throws NoSuchAlgorithmException 
	 * @throws KeyManagementException 
	 * @throws InterruptedException 
	 * @throws Exception 
	 */
	public Map<String, Object> canConnectNew(String ipAddress, String port, String deviceId, String deviceName, String port5, String backCallerRestPath) throws SQLException, KeyManagementException, NoSuchAlgorithmException, KeyStoreException, IOException, InterruptedException {
		String response = "";
		String connectURL = "";
		String connectionIP = "";
		Map<String, Object> hashResult = new HashMap<>();
		String uiPath = PortalCommon.getInstance().getUIPath();
		if(StringFunctions.isNullOrWhitespace(deviceName)) {
			hashResult = new DiscoveryDetailsEngine().getDiscoveryDetails(deviceId);
			/*
			 * Added count check for data exist or not - ntl
			 */
			if(hashResult.size() > 0) {

				int i = 0;
				while (i < 5) {
					i++;
					PALogger.INFO("===== IN CAN CONNECT ====Trying count   "+ i +"============");
					String[] externalIPArr = hashResult.get("ExternalIPAddress").toString().split(",");
					if (PortalCommon.getInstance().isRelay(NetworkTypeEnum.valueOf((hashResult.get("NetworkType")).toString()))) {
						//check devicename.mypixeom.com
						PALogger.INFO("===== IN CAN CONNECT ====NETWORK TYPE IS  "+ hashResult.get("NetworkType") +"============");
						connectURL = HTTPS_PREFIX + externalIPArr[0] + ":" + hashResult.get("Port");

						if(StringFunctions.isNullOrWhitespace(backCallerRestPath)){
							PALogger.INFO("===== IN CAN CONNECT ====TRYING ON   "+ connectURL + "/" + Constants.BOX_SERVICE_NAME + "/device/connectdevice" +"============");
							response = Client.callServer(connectURL , Constants.BOX_SERVICE_NAME, "device", HTTPMethods.GET.name(), "connectdevice", null, null, Constant.BEARER
									,10000,10000,10000);
							response = new Gson().fromJson(response, String.class);
							response = response.trim();
						} else {
							PALogger.INFO("===== IN CAN CONNECT ====TRYING ON   "+ connectURL + backCallerRestPath +"============");
							
							response = Client.callServer(connectURL, backCallerRestPath, "", HTTPMethods.GET.name(), "", null, null, Constant.BEARER);
						}
						PALogger.INFO("===== IN CAN CONNECT ====RESPONSE   "+ response +"============");

						if(response.equals(deviceId)) {
							connectionIP = HTTPS_PREFIX + externalIPArr[0].trim() + ":" + hashResult.get("Port") + "/" + uiPath +"/";
							PALogger.INFO("update discoverdetails connectionIP : "+connectionIP);
							try{
								new DiscoveryDetailsEngine().updateDiscoveryDetails(connectionIP, "", "",  deviceId);
							}catch(Exception ex){}
							hashResult.put("Status", "Success");
							hashResult.put("ExternalIPAddress", externalIPArr);
							hashResult.put("LANIPAddress", hashResult.get("LANIPAddress").toString().split(","));
							hashResult.put("ConnectionIP", connectionIP);
							return hashResult;
						}

						connectURL = HTTPS_PREFIX+hashResult.get("RelayServerID") + ":" + hashResult.get("Port");
						if(StringFunctions.isNullOrWhitespace(backCallerRestPath)){
							PALogger.INFO("===== IN CAN CONNECT ====TRYING ON   "+ connectURL + "/" + Constants.BOX_SERVICE_NAME + "/device/connectdevice" +"============");
							response = Client.callServer(connectURL, Constants.BOX_SERVICE_NAME, "device", HTTPMethods.GET.name(), "connectdevice", null, null, Constant.BEARER
									,10000,10000,10000);
							response = new Gson().fromJson(response, String.class);
							response = response.trim();
						} else {
							PALogger.INFO("===== IN CAN CONNECT ====TRYING ON   "+ connectURL + backCallerRestPath +"============");
							
							response = Client.callServer(connectURL, backCallerRestPath, "", HTTPMethods.GET.name(), "", null, null, Constant.BEARER);
						}
						PALogger.INFO("===== IN CAN CONNECT ====RESPONSE   "+ response +"============");

						if(response.equals(deviceId)) {
							String relayServerId = new RelayServersEngine().getRelayServerAddress(hashResult.get("RelayServerID").toString());
							if(!StringFunctions.isNullOrWhitespace(relayServerId)) {
								hashResult.put("RelayServerID", relayServerId);
								PALogger.INFO("===== IN CAN CONNECT ====RelayServerAddress"+ hashResult.get("RelayServerID"));
							}
							connectionIP = HTTPS_PREFIX + hashResult.get("RelayServerID").toString().trim() + ":" + hashResult.get("Port") + "/" + uiPath +"/";
							try{
								new DiscoveryDetailsEngine().updateDiscoveryDetails(connectionIP, "", "",  deviceId);
							}catch(Exception ex){}
							hashResult.put("Status", "Success");
							hashResult.put("ExternalIPAddress", externalIPArr);
							hashResult.put("LANIPAddress", hashResult.get("LANIPAddress").toString().split(","));
							hashResult.put("ConnectionIP", connectionIP);
							return hashResult;
						}
					} else {
						PALogger.INFO("===== IN CAN CONNECT ====NETWORK TYPE IS NOT RELAY ============");
						for (int j = 0; j < externalIPArr.length; j++) {
							String externalIP = externalIPArr[j];
							if(StringFunctions.isNullOrWhitespace(backCallerRestPath)){
								connectURL = HTTPS_PREFIX+ externalIP.trim() + ":" + hashResult.get("defaultPort");
								PALogger.INFO("===== IN CAN CONNECT ====TRYING ON   "+ connectURL + Constants.BOX_SERVICE_NAME + "/device/connectdevice" +"============");
								response = Client.callServer(connectURL, Constants.BOX_SERVICE_NAME, "device", HTTPMethods.GET.name(), "connectdevice", null, null, Constant.BEARER
										,10000,10000,10000);
								response = new Gson().fromJson(response, String.class);
								response = response.trim();
							} else {
								connectURL = HTTPS_PREFIX+ externalIP.trim() + ":" + hashResult.get("defaultPort");
								PALogger.INFO("===== IN CAN CONNECT ====TRYING ON   "+ connectURL + backCallerRestPath +"============");
								response = Client.callServer(connectURL, backCallerRestPath, "", HTTPMethods.GET.name(), "", null, null, Constant.BEARER);
							}
							PALogger.INFO("===== IN CAN CONNECT ====RESPONSE   "+ response +"============");
							if(response.equals(deviceId)) {
								connectionIP = HTTPS_PREFIX + externalIP.trim() + ":" + hashResult.get("defaultPort") + "/" + uiPath +"/";
								new DiscoveryDetailsEngine().updateDiscoveryDetails(connectionIP, "", "",  deviceId);
								hashResult.put("Status", "Success");
								hashResult.put("ExternalIPAddress", externalIPArr);
								hashResult.put("LANIPAddress", hashResult.get("LANIPAddress").toString().split(","));
								hashResult.put("ConnectionIP", connectionIP);
								return hashResult;
							} else if(!hashResult.get("Port").equals(hashResult.get("defaultPort"))) {
								if(StringFunctions.isNullOrWhitespace(backCallerRestPath)){
									connectURL = HTTPS_PREFIX+ externalIP.trim() +":"+ hashResult.get("Port");
									PALogger.INFO("===== IN CAN CONNECT ====TRYING ON   "+ connectURL + "/" + Constants.BOX_SERVICE_NAME + "/device/connectdevice" +"============");
									response = Client.callServer(connectURL, Constants.BOX_SERVICE_NAME, "device", HTTPMethods.GET.name(), "connectdevice", null, null, Constant.BEARER
											,10000,10000,10000);
									response = new Gson().fromJson(response, String.class);
									response = response.trim();
								} else {
									connectURL = HTTPS_PREFIX+ externalIP.trim() +":"+ hashResult.get("Port");
									PALogger.INFO("===== IN CAN CONNECT ====TRYING ON   "+ connectURL + backCallerRestPath +"============");
									response = Client.callServer(connectURL, backCallerRestPath, "", HTTPMethods.GET.name(), "", null, null, Constant.BEARER);
								}
								PALogger.INFO("===== IN CAN CONNECT ====RESPONSE   "+ response +"============");
								if(response.equals(deviceId)) {
									connectionIP = HTTPS_PREFIX + externalIP.trim() + ":" + hashResult.get("Port") + "/" + uiPath +"/";
									new DiscoveryDetailsEngine().updateDiscoveryDetails(connectionIP, "", "",  deviceId);
									hashResult.put("Status", "Success");
									hashResult.put("ExternalIPAddress", externalIPArr);
									hashResult.put("LANIPAddress", hashResult.get("LANIPAddress").toString().split(","));
									hashResult.put("ConnectionIP", connectionIP);
									return hashResult;
								}
							}
						}
					}
					Thread.sleep(5000);
				}
				if (!hashResult.get("NetworkType").equals("2")) {
					String[] lanIpArr = hashResult.get("LANIPAddress").toString().split(",");
					for (int j = 0; j < lanIpArr.length; j++) {
						String lanIP = lanIpArr[j];
						PALogger.INFO("===== IN CAN CONNECT ====SETTING TO LAN   "+ lanIP +"============");
						//TODO $this->updateAllDiscoverydetails(lanIP.trim(), $defaultPort, $DeviceID, $Port5);
					}
				}
				hashResult.put("Status", "Failure");
				hashResult.put("ErrorMessage", "Can't Connect");
				return hashResult;
			}
		} else {
			int i = 0;
			while (i < 5) {
				i++;
				if(StringFunctions.isNullOrWhitespace(backCallerRestPath)){
					connectURL = HTTPS_PREFIX+ deviceName.trim() + "."+ Constants.getSERVER_ADDRESS()+":" + port;
					PALogger.INFO("===== IN CAN CONNECT ====TRYING ON   "+ connectURL + "/" + Constants.BOX_SERVICE_NAME + "/device/connectdevice" +"============");
					response = Client.callServer(connectURL, Constants.BOX_SERVICE_NAME, "device", HTTPMethods.GET.name(), "connectdevice", null, null, Constant.BEARER
							,10000,10000,10000);
					response = new Gson().fromJson(response, String.class);
					response = response.trim();
				} else {
					connectURL = HTTPS_PREFIX+ deviceName.trim() + "."+ Constants.getSERVER_ADDRESS() +":"+ port;
					PALogger.INFO("===== IN CAN CONNECT ====TRYING ON   "+ connectURL + backCallerRestPath +"============");
					response = Client.callServer(connectURL, backCallerRestPath, "", HTTPMethods.GET.name(), "", null, null, Constant.BEARER);
				}
				PALogger.INFO("===== IN CAN CONNECT ====RESPONSE   "+ response +"============");

				if(response.equals(deviceId)) {
					connectionIP = connectURL + "/" + uiPath +"/";
					new DiscoveryDetailsEngine().updateDiscoveryDetails(connectionIP, "", "",  deviceId);
					hashResult.put("Status", "Success");
					hashResult.put("ExternalIPAddress", "");
					hashResult.put("LANIPAddress", "");
					hashResult.put("Port", port);
					hashResult.put("defaultPort", "443");
					hashResult.put("ConnectionIP", connectionIP);
					return hashResult;

				}
				Thread.sleep(5000);
			}

			connectURL = HTTPS_PREFIX + ipAddress.trim() + ":" + port;
			PALogger.INFO("===== IN CAN CONNECT NEW ====ConnectURL   "+ connectURL +"============");
			if(StringFunctions.isNullOrWhitespace(backCallerRestPath)){
				PALogger.INFO("===== IN CAN CONNECT ====TRYING ON   "+ connectURL + "/" + Constants.BOX_SERVICE_NAME + "/device/connectdevice" +"============");
				response = Client.callServer(connectURL, Constants.BOX_SERVICE_NAME, "device", HTTPMethods.GET.name(), "connectdevice", null, null, Constant.BEARER
						,10000,10000,10000);
				response = new Gson().fromJson(response, String.class);
				response = response.trim();
			} else {
				PALogger.INFO("===== IN CAN CONNECT ====TRYING ON   "+ connectURL + backCallerRestPath +"============");
				response = Client.callServer(connectURL, backCallerRestPath, "", HTTPMethods.GET.name(), "", null, null, Constant.BEARER);
			}
			PALogger.INFO("===== IN CAN CONNECT ====RESPONSE   "+ response +"============");

			if(response.equals(deviceId)) {
				connectionIP = connectURL + "/" + uiPath +"/";
				new DiscoveryDetailsEngine().updateDiscoveryDetails(connectionIP, "", "",  deviceId);
				hashResult.put("Status", "Success");
				hashResult.put("ExternalIPAddress", "");
				hashResult.put("LANIPAddress", "");
				hashResult.put("Port", port);
				hashResult.put("defaultPort", "443");
				hashResult.put("ConnectionIP", connectionIP);
				return hashResult;
			}
		}
		hashResult.put("Status", "Failure");
		hashResult.put("ErrorMessage", "Can't Connect");
		return hashResult;
	}

	public Map<String, Object> setRURLDetails(String deviceId, String rURLTomcatPort,  String rAddress, String isCheck, String backCallerRestPath) throws SQLException  {
		String response = "";
		HashMap<String, Object> hashResult = new HashMap<>();
		if (isCheck.equals("true")) {
			try{
				int i = 0;
				while (i < 2) {
					i++;
					String connectURL = HTTPS_PREFIX + rAddress.trim() + ":" + rURLTomcatPort;				
					PALogger.INFO("===== IN setRURLDetails ====ConnectURL   "+ connectURL +"===TRY COUNT==="+ i +"======");
					if(StringFunctions.isNullOrWhitespace(backCallerRestPath)){
						PALogger.INFO("===== IN CAN CONNECT ====TRYING ON   "+ connectURL + "/" + Constants.BOX_SERVICE_NAME + "/device/connectdevice" +"============");
						response = Client.callServer(connectURL, Constants.BOX_SERVICE_NAME, "device", HTTPMethods.GET.name(), "connectdevice", null, null, Constant.BEARER
								,10000,10000,10000);
						response = new Gson().fromJson(response, String.class);
						response = response.trim();
					} else {
						PALogger.INFO("===== IN CAN CONNECT ====TRYING ON   "+ connectURL + backCallerRestPath +"============");
						response = Client.callServer(connectURL, backCallerRestPath, "", HTTPMethods.GET.name(), "", null, null, Constant.BEARER);
					}
					PALogger.INFO("===== IN CAN CONNECT ====RESPONSE   " + response + "============");
					PALogger.INFO("===== IN CAN CONNECT ====DeviceId   " + deviceId + "============");
					if (response.equals(deviceId)) {
						try{
							new DiscoveryDetailsEngine().updateDiscoveryDetails("", rAddress, "",  deviceId);
						}catch(Exception ex){}
						hashResult.put("Status", "Success");
						hashResult.put("ConnectionIP", connectURL + "/" + PortalCommon.getInstance().getUIPath() + "/");
						return hashResult;
					}
					Thread.sleep(2000);
				}
			}catch(Exception ex){
				PALogger.ERROR(ex);	
			}
			hashResult.put("Status", "Failure");
			hashResult.put("ErrorMessage", "Can't Connect");
			return hashResult;
		} else {
			new DiscoveryDetailsEngine().updateDiscoveryDetails("", rAddress, rURLTomcatPort, deviceId);
			hashResult.put("Status", "Success");
			hashResult.put("Data", deviceId);
			return hashResult;
		}
	}



	public Map<String, Object> checkRestConnectNew(String ipAddress, String port, String deviceId, String backCallerRestPath) {
		String response = "";
		String connectURL = "";
		HashMap<String, Object>  hashResult = new HashMap<>();
		PALogger.INFO("===== IN CheckRestconnectnew REQUEST DEVICE ID==========" + deviceId + "============");
		try{
			int i = 0;
			while (i < 1) {
				i++;
				PALogger.INFO("===== IN CheckRestconnectnew ====Trying count   " + i + "============");
				if(StringFunctions.isNullOrWhitespace(backCallerRestPath)){
					connectURL = HTTPS_PREFIX + ipAddress.trim() + ":" + port;
					PALogger.INFO("===== IN CheckRestconnectnew ACTION ====TRYING ON   "+ connectURL + "/" + Constants.BOX_SERVICE_NAME + "/device/connectdevice" +"============");
					response = Client.callServer(connectURL , Constants.BOX_SERVICE_NAME, "device", HTTPMethods.GET.name(), "connectdevice", null, null, Constant.BEARER
							,10000,10000,10000);
					response = new Gson().fromJson(response, String.class);
					response = response.trim();
				} else {
					connectURL = HTTPS_PREFIX + ipAddress.trim() + ":" + port;
					PALogger.INFO("===== IN CheckRestconnectnew ACTION ====TRYING ON   "+ connectURL + backCallerRestPath +"============");
					response = Client.callServer(connectURL, backCallerRestPath, "", HTTPMethods.GET.name(), "", null, null, Constant.BEARER);
				}
				PALogger.INFO("===== IN CheckRestconnectnew RESPONSE==========" + response + "============");
				if (response.equals(deviceId)) {
					hashResult.put("Status", "Success");
					return hashResult;
				}
				else if(!response.equals("")){
					PALogger.INFO("===== IN CheckRestconnectnew ====Failure   SOME OTHER DEVICE RESPONDED============");
					hashResult.put("Status", "Failure");
					return hashResult;
				}
				Thread.sleep(5000);
			}}
		catch (Exception e) {
			PALogger.ERROR(e);	
		}
		hashResult.put("Status", "Failure");
		return hashResult;
	}

	public Map<String, Object> setConnectURLRelay(String iPAddress,NetworkTypeEnum networkType, String relayServerID, String chatInputChannel, String chatOutputChannel, 
			String chatSubscriptionChannel, String nodeCommunicationPort, String openStackPort, String tomcatPort, String port1, String port2, 
			String port3, String port4, String port5, String rURLTomcatPort, String rAddress, String deviceId) throws SQLException {
		HashMap<String, Object>  hashResult = new HashMap<>();
		String connectURL = HTTPS_PREFIX + iPAddress + ":" + tomcatPort + "/" + PortalCommon.getInstance().getUIPath() + "/";
		PALogger.INFO("===== IN SET CAN CONNECT ====   " +connectURL+ "============");

		new DiscoveryDetailsEngine().updateDiscoveryDetails(connectURL, chatInputChannel,networkType,relayServerID,chatOutputChannel,
				chatSubscriptionChannel,nodeCommunicationPort,openStackPort,tomcatPort,
				port1,port2,port3,port4,port5,
				rURLTomcatPort,rAddress, deviceId);
		new AssignedRelayPortsEngine().updateAssignedPortsStatus(deviceId);
		PALogger.INFO("===== IN SET CAN CONNECT Delete assigned relay ports for=======" + deviceId + "============");
		hashResult.put("Status", "Success");
		return hashResult;
	}

	public Map<String, Object> receiveDiscoveryDetails(DiscoveryJarDetailsVO detailsVO, ValidationInfoVO validInfo) throws Exception {


		if(StringFunctions.isNullOrWhitespace(detailsVO.getsDeviceId())){
			throw new Exception("deviceId must required.");
		}
		return	setDiscoveryDetailsMain(validInfo.getsMACAddress(), validInfo.getnStatus(), validInfo.getsGUID(), 
				validInfo.getnTimestamp(), validInfo.getsInternetAddress(), validInfo.getEmail(), validInfo.getHostName(), validInfo.getSwLicense(), validInfo.getHwConfig(), detailsVO.getsDeviceId(), 
				 detailsVO.getsLocalIPAddress(), detailsVO.getsChatInputChannel(), detailsVO.getsChatOutputChannel(), detailsVO.getsChatSubscriptionChannel(), 
				detailsVO.getsNodeCommunicationPort(), detailsVO.getsOpenStackPort(), detailsVO.getsTomcatPort(), 
				detailsVO.getsPort1(), detailsVO.getsPort2(), detailsVO.getsPort3(), detailsVO.getsPort4(), detailsVO.getsPort5(), detailsVO.getsRURLTomcatPort(),
				detailsVO.getsRAddress(), detailsVO.getnStatus(), detailsVO.getsRelayServerID(), detailsVO.getsNetworkType());
	}






	private String mGetClientIP(HttpServletRequest request) {
		String ipaddress  = request.getHeader("X-Real-IP");
		//Note : if required more info from request		
		String scheme  = request.getHeader("x-forwarded-protocol");
		String port  = request.getHeader("x-forwarded-port");
		String contextPath = request.getContextPath();
		StringBuilder sb = new StringBuilder();
		sb.append(scheme).append("://").append(ipaddress).append(":").append(port).append(contextPath);
		PALogger.INFO(sb.toString() + "/");
		return ipaddress;
	}

	public Map<String, Object> receiveJARRelayDiscoveryDetails(DiscoveryJarDetailsVO detailsVO, ValidationInfoVO infoVO) throws Exception {

		if(StringFunctions.isNullOrWhitespace(detailsVO.getsMACAddress())){
			throw new Exception("MACAddress must be required."); 
		}

		return new RelayServers().setupRelayJARDiscoveryDetails(infoVO.getsMACAddress(),
				infoVO.getnStatus(),
				infoVO.getsGUID(),																   
				infoVO.getnTimestamp(),
				infoVO.getEmail(),
				infoVO.getHostName(),
				infoVO.getSwLicense(),
				infoVO.getHwConfig(),
				detailsVO.getsIPAddress(),
				detailsVO.getsLocalIPAddress(),
				detailsVO.getsChatInputChannel(),
				detailsVO.getsChatOutputChannel(),
				detailsVO.getsChatSubscriptionChannel(),
				detailsVO.getsNodeCommunicationPort(),
				detailsVO.getsOpenStackPort(),
				detailsVO.getsTomcatPort(),
				detailsVO.getsPort1(),
				detailsVO.getsPort2(),
				detailsVO.getsPort3(),
				detailsVO.getsPort4(),
				detailsVO.getsPort5(),
				detailsVO.getsRURLTomcatPort(),
				detailsVO.getsRAddress(),
				detailsVO.getIsSetRURL(),
				detailsVO.getnStatus());
	}

	public Map<String, Object> setDiscoveryDetailsMain(String macAddress, int deviceStatus, String guid, 
			long timestamp, String internetAddress, String email, String hostName, String swLicense, String hwConfig, String deviceId, 
			String localIPAddress, String chatInputChannel, String chatOutputChannel, String chatSubscriptionChannel, 
			String nodeCommunicationPort, String openStackPort, String tomcatPort, 
			String port1, String port2, String port3, String port4, String port5, String rURLTomcatPort, 
			String rAddress, int status, String relayServerID, NetworkTypeEnum networkType) throws SQLException {
		HashMap<String, Object>  hashResult = new HashMap<>();
		PALogger.INFO("=====Call setDiscoveryDetailsMain method ===="+ deviceId +"============");
		Map<String, Object> validationResult = new ValidationInfo().checkValidationInfo(macAddress, deviceStatus, guid, timestamp, 
				 email, hostName, swLicense, hwConfig);

		setDiscoveryDetails(deviceId, internetAddress, localIPAddress, chatInputChannel, chatOutputChannel, chatSubscriptionChannel, nodeCommunicationPort, 
				openStackPort, tomcatPort, port1, port2, port3, port4, port5, rURLTomcatPort, rAddress, 
				status, relayServerID, networkType);
		DiscoveryDetailsVO detailsVO = new DiscoveryDetails().getDiscoveryDetails(deviceId);
		hashResult.put("Status", "Success");
		hashResult.put("Details", detailsVO);
		hashResult.put("validationResult", validationResult);
		return hashResult;	
	}	




	private DiscoveryDetailsVO isDiscoveryDetailsExists(String deviceId) throws SQLException {
		return new DiscoveryDetailsEngine().getDiscoveryDetailsVO(deviceId, false);
	}

	private void manageDomainNameGoogle(DomainOperation command,String deviceId,String deviceName,String clusterName, String ipAddress, String ipAddressOld) throws SQLException
	{
		//1 resolve ip with devcie name
		ManageDomainNameGoogle.runCommand(command, deviceName, ipAddress,ipAddressOld);	
		//2 resolve ip with all virtualurls for given device
		//VirtuakURL urlObj= new VirtuakURL();
		//List<String> listDomainNames = urlObj.listDomainNames(deviceId);
//		for (String domainName : listDomainNames) 
//		{
//			ManageDomainNameGoogle.runCommand(command,domainName,ipAddress,ipAddressOld);
//		}
		PALogger.INFO("=====NetworkType RunCommand setDiscovery Details====" + ipAddressOld + "======" +ipAddress + "======");
		//3 resolve ip with clustername
		if(clusterName != null)
		{
			ManageDomainNameGoogle.runCommand(command, clusterName, ipAddress,ipAddressOld);
		}
	}
	
	private void manageDomainNameJD(DomainOperation command,String deviceId,String deviceName,String clusterName, String ipAddress, String ipAddressOld) throws SQLException
	{
		//1 resolve ip with devcie name
		ManageDomainNameJD.runCommand(command, deviceName, ipAddress,ipAddressOld);	
		//2 resolve ip with all virtualurls for given device
		//VirtuakURL urlObj= new VirtuakURL();
		//List<String> listDomainNames = urlObj.listDomainNames(deviceId);
//		for (String domainName : listDomainNames) 
//		{
//			ManageDomainNameJD.runCommand(command,domainName,ipAddress,ipAddressOld);
//		}
		PALogger.INFO("=====NetworkType RunCommand setDiscovery Details====" + ipAddressOld + "======" +ipAddress + "======");
		//3 resolve ip with clustername
		if(clusterName != null)
		{
			ManageDomainNameJD.runCommand(command, clusterName, ipAddress,ipAddressOld);
		}
	}

	private void manageDomainName(ChangeAction command,String deviceId,String deviceName,String clusterName, String ipAddress, String ipAddressOld) throws SQLException
	{
		//1 resolve ip with devcie name
		ManageDomainName.runCommand(command, deviceName, ipAddress);	
		//2 resolve ip with all virtualurls for given device
//		VirtuakURL urlObj= new VirtuakURL();
//		List<String> listDomainNames = urlObj.listDomainNames(deviceId);
//		for (String domainName : listDomainNames) 
//		{
//			ManageDomainName.runCommand(command,domainName,ipAddress);
//		}
		PALogger.INFO("=====NetworkType RunCommand setDiscovery Details====" + ipAddressOld + "======" +ipAddress + "======");

		//3 resolve ip with clustername
		if(clusterName != null)
		{
			ManageDomainName.runCommand(command, clusterName, ipAddress);
		}
	}
}
