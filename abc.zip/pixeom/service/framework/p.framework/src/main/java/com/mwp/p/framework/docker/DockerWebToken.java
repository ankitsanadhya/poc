/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.framework.docker;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;

import com.mwp.common.AuthHelper;
import com.mwp.common.CredProvider;
import com.mwp.common.StringFunctions;
import com.mwp.common.constant.Constant;
import com.mwp.common.constant.PermissionResourceKeys;
import com.mwp.common.constant.PermissionResources;
import com.mwp.common.vo.ApplicationPlatformVO;
import com.mwp.common.vo.ApplicationVO;
import com.mwp.common.vo.AuthorizationsVO;
import com.mwp.logger.PALogger;
import com.mwp.p.common.Constants;
import com.mwp.p.common.PortalCommon;
import com.mwp.p.framework.Applications;
import com.mwp.p.framework.Groups;

public class DockerWebToken {
	public String generateDockerAuthToken(String scope, String service, String authToken, String appId, HttpServletResponse response) throws Exception {
		return mGenerateDockerAuthTokenPython(scope, service, authToken, appId, response);
	}

	private synchronized String mGenerateDockerAuthTokenPython(String scope, String service, String authToken, String appId, HttpServletResponse response) throws Exception {
		//send response as per NTK changes in TNCNT.
		printLog("scope -> " + scope);
		printLog("service -> " + service);
		printLog("appId -> " + appId);
		
		if(StringFunctions.isNullOrWhitespace(authToken)){
			throw new Exception(Constant.UNAUTHORIZED);
		}

		if(StringFunctions.isNullOrWhitespace(authToken)){
			throw new Exception(Constant.UNAUTHORIZED);
		}


		String[] scopeArr = scope.split(":");
		if(scopeArr.length != 3) {
			throw new Exception("Invalid Scope");
		}

		String type = scopeArr[0];
		String repoName = scopeArr[1];
		String actions = scopeArr[2];


		if(authToken.equals(Constants.PORTAL_USER_ID))
		{
			actions=PermissionResources.getString(PermissionResourceKeys.APP_VERSION_CREATE)+","+PermissionResources.getString(PermissionResourceKeys.APP_VERSION_INSTALL);
		}
		else
		{
			AuthHelper ah = new AuthHelper();
			AuthorizationsVO authvo;
			if(authToken.toLowerCase().startsWith(Constant.JWT_BEARER.toLowerCase())) {

				authvo =  ah.checkJwtToken(authToken, response);
			}else{
				authvo = ah.getAuthorizationsVO(authToken, Constants.AUTH_SERVER_IP_PORT);
			}
			actions = getFilteredActions(repoName, appId, authvo);

		}

		printLog("actions -> " + actions);


		printLog("Aquired lock creating der start -> appId:" + appId);

		CredProvider credProvider = new CredProvider();

		try {
			credProvider.getCerts();

			List<String> command = new ArrayList<>();

			command.add("python");
			command.add("/opt/python/tockenizer.py");
			command.add("-s");
			command.add(service);
			command.add("-t");
			command.add(type);
			command.add("-n");
			command.add(repoName);
			command.add("-a");
			command.add(actions);

			String der = PortalCommon.getInstance().executeCommnad(command).trim();

			printLog("der -> " + der);

			return der;
		} finally {
			credProvider.removeCerts();
			printLog("Aquired lock creating der completed -> appId:" + appId);
		}
	}

	private String getFilteredActions(String repoName, String resourceId, AuthorizationsVO authvo) throws SQLException   {

		String[] repoNameArr = repoName.split("/");

		List<String> actions = new ArrayList<>();

		Applications apps = new Applications();

		ApplicationVO appdetailVo = apps.getApplicationBasicDetail(resourceId);

		if(appdetailVo != null && appdetailVo.getApplicationId() != null) {
			actions.add("pull");
		} else {
			printLog("Invalid app");
		}

		boolean isRepoExist = false;

		for (ApplicationPlatformVO platformVO : appdetailVo.getPlatFormList()) {
			if(repoNameArr[0].equals(platformVO.getRepositoryName())) {
				isRepoExist = true;
				if(appdetailVo.getUserId().equals(authvo.getUserId())) {
					actions.add("push");
				} else {

					printLog("Not same userId Auth -> " + authvo.getUserId() + ", appDetails -> " + appdetailVo.getUserId());

					ArrayList<String> groupIdsFiltered = new ArrayList<>();

					authvo.getGroupPermissions().forEach((grpId, permissions) -> {

						if(permissions.contains(PermissionResources.getString(PermissionResourceKeys.APP_VERSION_CREATE))) {
							groupIdsFiltered.add(grpId);
						} else {
							printLog("grpId -> " + grpId + ", no push permission");
						}
					});

					Groups grp = new Groups();

					printLog("Group count with push permission -> " + groupIdsFiltered.size() + " , Checking is app in group.");

					for (String groupId : groupIdsFiltered) {
						printLog("Filtered GroupId -> " + groupId);

						List<ApplicationVO> appVos = grp.listGroupApp(groupId);

						printLog("Applications in group -> " + appVos.size());

						for (ApplicationVO applicationVO : appVos) {							
							if(applicationVO.getApplicationId().equals(resourceId)) {
								actions.add("push");
							} else {
								printLog("application not found in group.");
							}
						}
					}

				}
			} 
		}
		if(!isRepoExist) {
			StringBuilder repositoryName =new StringBuilder();
			for (ApplicationPlatformVO platform : appdetailVo.getPlatFormList()) {
				repositoryName.append( platform.getRepositoryName());
				repositoryName.append(" ");
			}
			printLog("Invalid Repo, requested -> " + repoNameArr[0] + " in DB -> " + repositoryName.toString());
		}
		return StringUtils.join(actions, ",");
	}

	private void printLog(String message) {
		PALogger.INFO("DockerWebToken: ------> " + message);
	}
}