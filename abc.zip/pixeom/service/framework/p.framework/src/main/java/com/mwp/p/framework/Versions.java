/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.framework;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mwp.common.enums.StatusEnum.VERSION_STATUS;
import com.mwp.common.vo.AppResourceVO;
import com.mwp.common.vo.PortVO;
import com.mwp.common.vo.VersionVO;
import com.mwp.common.yamlparser.ComposeVO;
import com.mwp.common.yamlparser.YamlParser;
import com.mwp.p.common.PortalCommon;
import com.mwp.p.dal.engine.ApplicationResourceEngine;
import com.mwp.p.dal.engine.VersionEngine;

/**
 * This class manage - add application version, application configuration YML file path.
 * @author root
 *
 */
public class Versions {

	/**
	 * add application version, configuration, service end points in db.
	 * @param projectId
	 * @param versionVO
	 * @return
	 * @throws SQLException
	 * @throws InterruptedException
	 * @throws IOException
	 */
	public VersionVO createAppVersion(String projectId, VersionVO versionVO, List<AppResourceVO> appResourceVOs, String yamlTempFilePath) throws SQLException, InterruptedException, IOException {
		return mCreateAppVersion(projectId, versionVO, appResourceVOs, yamlTempFilePath);
	}


	public VersionVO createK8sAppVersion(String projectId, VersionVO versionVO, List<AppResourceVO> appResourceVOs) throws SQLException,  IOException {
		return mCreateK8sAppVersion(projectId, versionVO, appResourceVOs);
	}

	/**
	 * Check if version already exists 
	 * @param appId
	 * @param appPlatformId
	 * @param versionNumber
	 * @return
	 * @throws SQLException if version already exists
	 */
	public boolean checkVersionExist(String appId, String appPlatformId, String versionNumber) throws SQLException  {
		List<String> versions = new VersionEngine().getAllVersionNumbers(appId, appPlatformId);
		return versions.contains(versionNumber);
	}

	//AKH_01
	private VersionVO mCreateAppVersion(String projectId, VersionVO versionVO, List<AppResourceVO> appResourceVOs, String yamlTempFilePath) throws SQLException, InterruptedException, IOException {

		VersionEngine versionEngine = new VersionEngine();


		if(checkVersionExist(versionVO.getAppId(), versionVO.getAppPlatformId(), versionVO.getVersionNumber())) {
			throw new IOException("Version already exists.");
		}

		//Parse YAML is a valid file or not
		@SuppressWarnings("unused")
		ComposeVO composevo = YamlParser.parse(yamlTempFilePath);

		//DO this to remove any impurity in uploaded YAML file i.e. no quotes around commands and entry point tags, filter not-supported docker tags

		//Command to check Yaml file validation via docker-compose library
		List<String> command = new ArrayList<>();
		command.add("/opt/utils/validate_compose_file");
		command.add(yamlTempFilePath);

		//Execute the command - Returns valid or invalid 
		String result = PortalCommon.getInstance().executeCommnad(command);

		if(result.toLowerCase().startsWith("valid")) {
			List<PortVO> ports = new ArrayList<>();
			/**
			 * PSH_01
			 */
			//			for (String serviceKey : composevo.getServices().keySet()) {
			//
			//				SectionVO sectionVO = composevo.getServices().get(serviceKey);
			//				for (String port : sectionVO.getParsedPorts()) {
			//					PortVO portVO = new PortVO();
			//					portVO.setImageId(serviceKey);
			//					String[] portArr = port.split(":");
			//					if(portArr.length == 1){
			//						portVO.setInternalPort(Integer.parseInt(portArr[0]));
			//					}else if(portArr.length == 2){
			//						portVO.setInternalPort(Integer.parseInt(portArr[1]));
			//						portVO.setPort(Integer.parseInt(portArr[0]));
			//					}
			//					ports.add(portVO);
			//				} 
			//			} 

			addAppResources(appResourceVOs, versionVO.getVersionId());

			return versionEngine.createAppVersion(projectId, ports, versionVO);
		} else {
			throw new IOException("Invalid composer file provided.");
		}		
	}


	private VersionVO mCreateK8sAppVersion(String projectId, VersionVO versionVO, List<AppResourceVO> appResourceVOs) throws SQLException,  IOException {

		VersionEngine versionEngine = new VersionEngine();

		if(checkVersionExist(versionVO.getAppId(), versionVO.getAppPlatformId(), versionVO.getVersionNumber())) {
			throw new IOException("Version already exists.");
		}

		addAppResources(appResourceVOs, versionVO.getVersionId());

		return versionEngine.createAppVersion(projectId,versionVO.getPortlist(), versionVO);

	}

	public void addAppResources(List<AppResourceVO> appResourceVOs, String versionId) throws SQLException {
		if(appResourceVOs != null) {
			//Add application resources
			List<AppResourceVO> appResourceVOsDb = new ApplicationResourceEngine().add(appResourceVOs);

			//Map application resources with app version
			//List<AppVersionResourceVO> appVersionResourceVOs = new ArrayList<>();
			//for (AppResourceVO appResourceVO : appResourceVOsDb) {
			//	AppVersionResourceVO appVersionResourceVO = new AppVersionResourceVO();
			//	appVersionResourceVO.setAppId(appResourceVO.getAppId());
			//	appVersionResourceVO.setAppResourceVO(appResourceVO);
			//	appVersionResourceVO.setResourceId(appResourceVO.getAppResourceId());
			//	appVersionResourceVO.setVersionId(versionId);
			//	appVersionResourceVOs.add(appVersionResourceVO);
			//}
			//new ApplicationVersionResourcesEngine().add(appVersionResourceVOs);

		}
	}

	/**
	 * change application version status according to given appversionId.
	 * @param appId
	 * @param appVersionId
	 * @param status
	 * @throws SQLException
	 */
	public void changeAppVersionStatus(String appId,String appVersionId, String status) throws SQLException {
		mChangeAppVersionStatus(appId,appVersionId, status);
	}

	private void mChangeAppVersionStatus(String appId, String appVersionId, String status) throws SQLException {
		new VersionEngine().changeAppVersionStatus(appId, appVersionId, VERSION_STATUS.valueOf(status));
	}

}
/**
 * History of check-in or issue resolved
 * 
 * 01 - 14-11-2016 AKH_01
 * change param field use versionVO because we need more property to set like restRedirectUrl, redirectUrl, redirectType and redirectSection in applicationVersion,
 * so we remove other param which exist in versionVO object.
 * 
 * 02 09-1-2019 PSH_01
 * Remove insert ports into database on create version as per discussion with VA, PKN.
 */