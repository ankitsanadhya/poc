/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.mwp.p.framework;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import com.mwp.common.enums.MessageType;
import com.mwp.common.enums.NotificationType;
import com.mwp.common.vo.FilterObject;
import com.mwp.p.dal.engine.AlertsEngine;

public class Alerts 
{
	/**
	 * Add alerts for system 
	 * @param clusterId
	 * @param nodeId
	 * @param ntype {@link NotificationType}
	 * @param notification
	 * @throws SQLException
	 */
	public void add(NotificationType ntype,Object notification, MessageType messageType,String commandMessage) throws SQLException
	{
		 mAdd(ntype, notification, messageType,commandMessage);
	}
	
	/**
	 * list of alerts according to filters
	 * @param filterObjects
	 * @param pageNo
	 * @param pageSize
	 * @return
	 * @throws SQLException
	 */
	public Map<String, Object>  listFilterAlerts(List<FilterObject> filterObjects,long pageNo, int pageSize) throws SQLException
	{
		return mListFilterAlerts(filterObjects, pageNo, pageSize);
	}
	
	private void mAdd( NotificationType ntype,Object notification, MessageType messageType,String commandMessage) throws SQLException
	{
		AlertsEngine eng= new AlertsEngine();
		eng.add(ntype, notification, messageType,commandMessage);
	}
	
	private Map<String, Object>  mListFilterAlerts(List<FilterObject> filterObjects,long pageNo, int pageSize) throws SQLException
	{
		AlertsEngine eng= new AlertsEngine();
		return eng.listFilterAlerts(filterObjects, pageNo, pageSize);
	}

}
