/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.framework;

import java.sql.SQLException;
import java.util.List;

import com.mwp.common.StringFunctions;
import com.mwp.common.enums.SignUpTypeEnum;
import com.mwp.common.enums.StatusEnum.VERSION_STATUS;
import com.mwp.common.vo.ApplicationDetailsVO;
import com.mwp.common.vo.ApplicationImagesVO;
import com.mwp.common.vo.ApplicationPlatformVO;
import com.mwp.common.vo.ApplicationVO;
import com.mwp.common.vo.AuthorizationsVO;
import com.mwp.common.vo.DevAppDetailsVO;
import com.mwp.common.vo.VersionVO;
import com.mwp.p.common.vo.AppCommandVO;
import com.mwp.p.common.vo.AppTypeVO;
import com.mwp.p.common.vo.DeveloperApplicationVO;
import com.mwp.p.dal.engine.AppRepositoryEngine;
import com.mwp.p.dal.engine.ApplicationTypeEngine;
import com.mwp.p.dal.engine.ApplicationsEngine;
import com.mwp.p.dal.engine.DeveloperApplicationsEngine;
import com.mwp.p.dal.engine.VersionEngine;

/**
 * This class manages developer applications.Provides functionality  to add, list, delete etc  
 *
 */
public class DeveloperApplications {

	/**
	 * List invited application which user are invited on multiple groups.
	 * @param groupIds
	 * @return
	 * @throws Exception 
	 */
	public List<DeveloperApplicationVO> listInvitedApps(
			List<String> groupIds) throws SQLException {
		return mListInvitedApps( groupIds);
	}

	/**
	 * Get all the type of application
	 * @return
	 * @throws SQLException
	 */
	public List<AppTypeVO> getAllAppType() throws SQLException
	{
		return mGetAllAppType();
	}
	
	/**
	 * 
	 * @param applicationDetailsVO
	 * @return
	 * @throws Exception 
	 */
	public ApplicationDetailsVO createApplication(ApplicationDetailsVO applicationDetailsVO) throws Exception {
		return mCreateApplication(applicationDetailsVO);

	}

	/**
	 * 
	 * @param applicationDetailsVO
	 * @return
	 * @throws Exception 
	 */
	public ApplicationDetailsVO updateApplication(
			ApplicationDetailsVO applicationDetailsVO) throws SQLException {
		return mUpdateApplication(applicationDetailsVO);
	}

	/**
	 * update application logo path.
	 * @param appId
	 * @param logoPath
	 * @return
	 * @throws Exception
	 */
	public void updateApplicationLogo(String appId, String logoPath) throws SQLException {
		mUpdateApplicationLogo(appId, logoPath);
	}


	/**
	 * 
	 * @param appId
	 * @param userId user id of user whuch came for delete request
	 * @throws Exception 
	 */
	public void deleteApplication(String appId,String userId) throws SQLException {
		mDeleteApplication(appId,userId);
	}

	/**
	 * 
	 * @param appId
	 * @param versionId
	 * @return
	 * @throws Exception 
	 */
	public VersionVO getVersionDetails(String appId, String versionId) throws SQLException {
		return mGetVersionDetails(appId, versionId);

	}

	/**
	 * This method  gives yml compose file path for application version
	 * @param appId
	 * @param versionId
	 * @return
	 * @throws Exception 
	 */
	public String getVersionComposeYMLPath(String appId, String versionId) throws SQLException {
		return mGetVersionComposeYMLPath(appId, versionId);

	}
	
	/**
	 * This method  gives composeversion of for application id and version id.
	 * @param appId
	 * @param versionId
	 * @return
	 * @throws Exception 
	 */
	public String getComposeVersion(String appId, String versionId) throws SQLException {
		return mGetComposeVersion(appId, versionId);

	}
	
	public String getInstalledApplicationComposeVersion(String deviceId, String appId) throws SQLException {
		return mGetInstalledApplicationComposeVersion(deviceId, appId);

	}
	
	private String mGetInstalledApplicationComposeVersion(String appId, String versionId) throws SQLException {
		DeveloperApplicationsEngine developerApplicationsEngine=new DeveloperApplicationsEngine();
		return developerApplicationsEngine.getInstalledApplicatonComposeVersion(appId, versionId);
	}
	
	
	/**
	 * This method gives list application of user 
	 * according to given user Id.
	 *  
	 * @param userId is who created the application.
	 * @return
	 * @throws Exception 
	 */
	public List<ApplicationVO> listApplicationOfUser(String userId) throws SQLException {
		return mListApplicationOfUser(userId);
	}

	/**
	 * getting installation details of application.
	 * @param appId
	 * @return
	 * @throws Exception
	 */
	public DevAppDetailsVO getDevAppDetails(String appId, AuthorizationsVO authVo, List<VERSION_STATUS> filterVersionStstus) throws SQLException{
		return mGetDevAppDetails(appId, authVo, filterVersionStstus);
	}

	/**
	 * add image of application.
	 * @param appId
	 * @return
	 * @throws Exception
	 */
	public ApplicationImagesVO addApplicationImage(String appId,String imagePath, int seqNo) throws SQLException{
		return mAddApplicationImage(appId, imagePath, seqNo);
	}

	/**
	 * This method gives application version command according to requested
	 * applicationId and appVersionId
	 * @param userId id of logged in user.
	 * @param applicationId Application Id which is unique for each application.
	 * @param appVersionId  Version Id of application which is unique for each version.
	 * @param grpIds
	 * @return list of AppCommandVO {@link AppCommandVO}
	 * @throws SQLException 
	 */
	public List<AppCommandVO> getAppVersionCommand(String userId, String applicationId,String appVersionId, List<String> grpIds) throws SQLException	{
		return mGetAppVersionCommand(userId, applicationId, appVersionId,  grpIds);
	}


	/**
	 * This method gives all available version of application
	 * @param appId Application Id which is unique for each application.
	 * @param userId id of logged in user.
	 * @param appVersionId versionId
	 * @return
	 * @throws SQLException
	 */
	public List<VersionVO> getVersionsOfApplication(String appId,String userId,String appVersionId, String appPlatformId,  List<VERSION_STATUS> filterVersionStatus) throws SQLException{
		return mGetVersionsOfApplication(appId,userId,appVersionId, appPlatformId, filterVersionStatus);
	}

	/**
	 * This method returns invited versions of app in requested group
	 * @param appId : application id of selected app
	 * @param groupId : group id where application was invited
	 * @return : list of versions
	 * @throws SQLException
	 */
	public List<VersionVO> getInvitedVersionsOfGroup(String appId, String groupId, List<VERSION_STATUS> filterVersionStstus) throws SQLException {
		return mGetInvitedVersionsOfGroup(appId, groupId, filterVersionStstus);
	}

	/**
	 * This method checking that all versions invited in group or not
	 * @param appId : application id of selected app
	 * @param groupId : group id where application was invited
	 * @return : return TRUE if all versions invited otherwise FALSE
	 * @throws SQLException
	 */
	public boolean isAllVersionsInvited(String appId, String groupId) throws SQLException {
		return mIsAllVersionsInvited(appId, groupId);
	}

	/**
	 * Delete application image according to appImageId and appId.
	 * @param appId
	 * @param appImageId
	 * @return id of appImage - appImageId
	 * @throws SQLException
	 */
	public String deleteAppImage(String appId, String appImageId) throws SQLException {
		return mDeleteAppImage(appId, appImageId);
	}
	
	/**
	 * Check if application already exists for title and repository name. 
	 * @param title
	 * @param repositoryName not used
	 * @return true if application already exists false otherwise.
	 * @throws SQLException Application already exists exception
	 */	
	public void isApplicationExits(String title) throws Exception {
		mIsApplicationExits(title);
	}
	
	/**
	 * 
	 * @param appRepoVO
	 * @return
	 * @throws Exception 
	 */
	public ApplicationPlatformVO addAppRepo(ApplicationPlatformVO appRepoVO) throws SQLException {
		return mAddAppRepo(appRepoVO);
	}

	/**
	 * Check if application name already exits, If exits then throw error
	 * @param appName
	 * @param appId
	 * @throws Exception  "Application name already exits"
	 */
	public void isAppNameAlreadyExist(String appName, String appId) throws Exception 
	{
		mIsAppNameAlreadyExist(appName, appId);
	}

	private String mDeleteAppImage(String appId, String appImageId) throws SQLException {
		return new DeveloperApplicationsEngine().deleteAppImage(appId, appImageId);
	}

	private boolean mIsAllVersionsInvited(String appId, String groupId) throws SQLException {
		return new VersionEngine().isAllVersionsInvited(appId, groupId);
	}

	private List<VersionVO> mGetInvitedVersionsOfGroup(String appId, String groupId, List<VERSION_STATUS> filterVersionStstus) throws SQLException {
		return new VersionEngine().getVersionsOfGroupAppWithoutPermission(appId, groupId, filterVersionStstus);
	}


	private ApplicationImagesVO mAddApplicationImage(String appId,String imagePath, int sequenceNo) throws SQLException {
		ApplicationImagesVO imagesVO = new ApplicationImagesVO();
		imagesVO.setAppId(appId);
		imagesVO.setImagePath(imagePath);
		imagesVO.setSequenceNo(sequenceNo);
		return new DeveloperApplicationsEngine().addApplicationImage(imagesVO);
	}

	private DevAppDetailsVO mGetDevAppDetails(String appId, AuthorizationsVO authVo, List<VERSION_STATUS> filterVersionStstus) throws SQLException {
		return new DeveloperApplicationsEngine().getDevAppDetails(appId, authVo, filterVersionStstus);
	}

	private List<DeveloperApplicationVO> mListInvitedApps(
			List<String> groupIds) throws SQLException {
		DeveloperApplicationsEngine developerApplicationsEngine=new DeveloperApplicationsEngine();
		return developerApplicationsEngine.listInvitedApps(groupIds);

	}

	private ApplicationDetailsVO mCreateApplication(ApplicationDetailsVO applicationDetailsVO) throws Exception {
		/*
		 * Check if 'usePxAuth' is "true", 
		 * then 'SignUpType' must be set with valid SignUpTypeEnum value.
		 */
		if(applicationDetailsVO.isUsePxAuth() == true 
				&& (StringFunctions.isNullOrWhitespace(applicationDetailsVO.getSignUpType()) 
						|| applicationDetailsVO.getSignUpType().ordinal() == SignUpTypeEnum.None.ordinal())){
			throw new Exception("SignUp type must be required.");
		}

		DeveloperApplicationsEngine developerApplicationsEngine=new DeveloperApplicationsEngine();
		return developerApplicationsEngine.createApplication(applicationDetailsVO);

	}

	private ApplicationDetailsVO mUpdateApplication(
			ApplicationDetailsVO applicationDetailsVO) throws SQLException {
		DeveloperApplicationsEngine developerApplicationsEngine=new DeveloperApplicationsEngine();
		return developerApplicationsEngine.updateApplication(applicationDetailsVO);

	}

	private void mUpdateApplicationLogo(String appId,String logoPath) throws SQLException {
		new DeveloperApplicationsEngine().updateApplicationLogo(appId, logoPath);
	}

	private void mDeleteApplication(String appId,String userId) throws SQLException {
		DeveloperApplicationsEngine developerApplicationsEngine=new DeveloperApplicationsEngine();
		developerApplicationsEngine.deleteApplication(appId,userId);

	}

	private VersionVO mGetVersionDetails(String appId, String versionId) throws SQLException {
		DeveloperApplicationsEngine developerApplicationsEngine=new DeveloperApplicationsEngine();
		return developerApplicationsEngine.getVersionDetails(appId, versionId);

	}	
	
	private String mGetVersionComposeYMLPath(String appId, String versionId) throws SQLException {
		DeveloperApplicationsEngine developerApplicationsEngine=new DeveloperApplicationsEngine();
		return developerApplicationsEngine.getVersionComposeYMLPath(appId, versionId);

	}
	private String mGetComposeVersion(String appId, String versionId) throws SQLException {
		DeveloperApplicationsEngine developerApplicationsEngine=new DeveloperApplicationsEngine();
		return developerApplicationsEngine.getComposeVersion(appId, versionId);

	}

	private List<ApplicationVO> mListApplicationOfUser(String userId) throws SQLException {
		return new ApplicationsEngine().listApplicationOfUser(userId); 
	}

	private List<AppCommandVO> mGetAppVersionCommand(String userId,String applicationId, String appVersionId, List<String> grpIds) throws SQLException {
		return new DeveloperApplicationsEngine().getAppVersionCommand(userId, applicationId, appVersionId, grpIds);
	}

	private List<VersionVO> mGetVersionsOfApplication(String appId,
			String userId, String appVersionId, String appPlatformId,  List<VERSION_STATUS> filterVersionStatus) throws SQLException {
		DeveloperApplicationsEngine developerApplicationsEngine = new DeveloperApplicationsEngine();
		return developerApplicationsEngine.listAppVersion(appId, userId, appVersionId, appPlatformId, filterVersionStatus);
	}
	
	private void mIsApplicationExits(String title) throws Exception {
		DeveloperApplicationsEngine developerApplicationsEngine = new DeveloperApplicationsEngine();
		boolean appExits = developerApplicationsEngine.isApplicationExits(title);
		if(appExits) {
			throw new Exception("Application already exists");
		}
	}
	private ApplicationPlatformVO mAddAppRepo(ApplicationPlatformVO appRepoVO) throws SQLException {
		AppRepositoryEngine repositoryEngine = new AppRepositoryEngine();
		appRepoVO = repositoryEngine.addAppRepo(appRepoVO);
		return appRepoVO;
	}
	private List<AppTypeVO> mGetAllAppType() throws SQLException
	{
		ApplicationTypeEngine eng = new ApplicationTypeEngine();
		return eng.getAllAppType();
	}
	
	private void mIsAppNameAlreadyExist(String appName, String appId) throws Exception 
	{
		DeveloperApplicationsEngine developerApplicationsEngine = new DeveloperApplicationsEngine();
		boolean appExits = developerApplicationsEngine.isAppNameAlreadyExist(appName, appId);
		if(appExits) {
			throw new Exception("Application name already exists");
		}
	}
	
	public List<String> isRepoNameAvailable(List<String> repoNames, String appId) throws SQLException {
		return mIsRepoNameAvailable(repoNames, appId);
	}
	
	private List<String> mIsRepoNameAvailable(List<String> repoNames, String appId) throws SQLException {
		return new AppRepositoryEngine().isRepoNameAvailable(repoNames, appId);		
	}
}
