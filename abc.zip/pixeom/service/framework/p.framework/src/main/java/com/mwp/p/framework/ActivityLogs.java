/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.framework;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.mwp.common.Common;
import com.mwp.common.constant.Constant;
import com.mwp.common.vo.FilterObject;
import com.mwp.p.common.vo.ActivityLogVo;
import com.mwp.p.dal.engine.ActivityLogEngine;

/**
 * Manages activity logs in insert/ List  etc.   
 *
 */
public class ActivityLogs
{
	/**
	 * add activity logs 
	 * @param logs
	 * @return
	 * @throws SQLException
	 */
	public void insert(String userId, String action, String paramJson) throws SQLException
	{
		mInsert(userId, action, paramJson);
	}

	/**
	 * list activity according to filter along with pagging
	 * @param pageNo
	 * @param pageSize
	 * @param filters
	 * @return
	 * @throws SQLException
	 */
	public HashMap<String, Object> listByFilter(int pageNo, int pageSize, List<FilterObject> filters) throws SQLException
	{
		return mListByFilter(pageNo, pageSize, filters);
	}
	/**
	 * List all Activity Log
	 * @return
	 * @throws SQLException
	 */
	public List<ActivityLogVo> listEvent()throws SQLException
	{
		return mListEvent();
	}

	/**
	 *  List Activity Log of last <numberofdays>
	 * @param numberofdays
	 * @return
	 * @throws SQLException
	 */
	public List<ActivityLogVo> listByTime(int numberofdays) throws SQLException
	{
		return mListByTime(numberofdays);
	}

	/**
	 * List Activity Logs using paging
	 * @param pageNo page number
	 * @param pageSize number of events in a page result
	 * @return  HashMap<String, Object> with keys totalPages, pageSize, pageNumber, data . data is List<ActivityLogVo> 
	 * @throws SQLException
	 */
	public  Map<String, Object> listByPage(int pageNo,int pageSize) throws SQLException
	{
		return mListByPage(pageNo,pageSize);
	}
	
	/**
	 * delete all activity older than given number of days
	 * @param noOfDays
	 * @return
	 * @throws SQLException 
	 */
	public void purgeActivity(long noOfDays) throws SQLException
	{
		 mPurgeActivity(noOfDays);
	}

	private void mInsert(String userId, String action, String paramJson) throws SQLException 
	{
		if(Constant.toLogActivity())
		{
			ActivityLogEngine engg = new ActivityLogEngine();
			engg.insert(Common.getRandomId(), userId, action, paramJson);
		}
	}

	private HashMap<String, Object> mListByFilter(int pageNo, int pageSize, List<FilterObject> filters) throws SQLException
	{
		ActivityLogEngine engg = new ActivityLogEngine();
		return engg.listByFilter(pageNo, pageSize, filters);
	}
	private List<ActivityLogVo> mListEvent() throws SQLException
	{
		ActivityLogEngine engg = new ActivityLogEngine();
		return engg.list();
	}
	private List<ActivityLogVo> mListByTime(int numberofdays) throws SQLException
	{
		ActivityLogEngine engg = new ActivityLogEngine();
		return engg.listByTime(numberofdays);
	}

	private  Map<String, Object> mListByPage(int pageNo, int pageSize) throws SQLException
	{
		ActivityLogEngine engg = new ActivityLogEngine();
		return engg.listByPage(pageNo,pageSize);
	}
	
	private void mPurgeActivity(long noOfDays) throws SQLException
	{
		ActivityLogEngine engg = new ActivityLogEngine();
		 engg.purgeActivity(noOfDays);
	}
}
