/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.mwp.p.vo;

import java.util.Map;

import com.mwp.common.ISkipObfuscation;

public class VeleroBackupMetadataVO implements ISkipObfuscation{
//	"metadata": {
	//	"generation": 1,
	//	"uid": "0f5ced23-3669-11e9-9a06-aaeef721c6c6",
	//	"resourceVersion": "308793",
	//	"name": "3ccd9272c07749728fa70d8f15c8da2c-0.0.2-1550816023000",
	//	"namespace": "heptio-ark",
	//	"creationTimestamp": "2019-02-22T06:14:06Z",
	//	"selfLink": "\/apis\/ark.heptio.com\/v1\/namespaces\/heptio-ark\/backups\/3ccd9272c07749728fa70d8f15c8da2c-0.0.2-1550816023000",
	//	"labels": {
	//		"ark.heptio.com\/storage-location": "default"
	//	}
	private Map<String, String> labels;
	private String name ; 

	

	public Map<String, String> getLabels() {
		return labels;
	}

	public void setLabels(Map<String, String> labels) {
		this.labels = labels;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public void guid() {
		// TODO Auto-generated method stub
		
	}
}
