/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.mwp.p.utility;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.google.gson.Gson;
import com.google.gson.internal.LinkedTreeMap;
import com.mwp.common.CommandExecutor;
import com.mwp.common.StringFunctions;
import com.mwp.common.enums.MessageType;
import com.mwp.common.enums.NotificationType;
import com.mwp.common.enums.RuleStatus;
import com.mwp.common.vo.RuleTriggerLogVO;
import com.mwp.common.vo.RuleVO;
import com.mwp.logger.PALogger;
import com.mwp.p.common.Constants;
import com.mwp.p.dal.engine.AlertsEngine;
import com.mwp.p.framework.Rule;
import com.mwp.p.framework.RuleTriggerLogs;

public class StorageMonitorService {

	public void monitorStorageService(int comarevalue,String ruleId,int increaseDiskSize,int maxDiskSize){

		HashMap<String, String> hashMap=new HashMap<>();
		List<String> clusterMonitoring = new ArrayList<>();		
		try{

			RuleTriggerLogVO rtvo = new RuleTriggerLogs().getLatestrecord(ruleId);
			if(rtvo!=null && rtvo.getStatus().equals(RuleStatus.failure))
			{
				LinkedTreeMap<String, Object> info = new LinkedTreeMap<>();
				Gson json = new Gson();
				info=json.fromJson(rtvo.getInfo(), info.getClass());
				increaseDiskSize = Integer.parseInt(info.get("increaseDiskSize").toString());
				Map<String, Object> result= addDisk(rtvo.getStage(),increaseDiskSize);
				RuleStatus success =RuleStatus.success;
				if(!Boolean.parseBoolean(result.get("success").toString()))
					success = RuleStatus.failure;
				result.put("trigger", info.get("trigger"));
				updateRuleLog(rtvo.getId(),success, Integer.parseInt(result.get("stage").toString()), result);
				return; 
			}

			String cmdToMonitor="kubectl exec -it $(kubectl get pods | grep -m 1 ^nfs-server | awk {'print $1'}) -- df --output=size,used,avail,pcent /dev/sdb";

			ArrayList<String> s=new ArrayList<>();
			s.add("/bin/bash");
			s.add("-c");
			s.add(cmdToMonitor);

			clusterMonitoring=clusterMonitoring(s);

			PALogger.INFO("static "+clusterMonitoring );

			List<String> keysList= new ArrayList<>( Arrays.asList(clusterMonitoring.get(0).split(" ")));		

			Iterator<String> keys=keysList.listIterator();	

			while (keys.hasNext()) {
				String ele=keys.next();
				if(StringFunctions.isNullOrWhitespace(ele))
					keys.remove();				
			}
			PALogger.INFO(" Keys list"+keysList);
			List<String> valuesList= new ArrayList<>(Arrays.asList(clusterMonitoring.get(1).split(" ")));
			Iterator<String> values=valuesList.listIterator();		
			while (values.hasNext()) {
				String ele=values.next();
				if(StringFunctions.isNullOrWhitespace(ele))
					values.remove();				
			}
			PALogger.INFO(" Values list"+valuesList);
			for (int i = 0; i < valuesList.size(); i++) {
				if(keysList.get(i).equals("1K-blocks")){
					keysList.remove(i);
					keysList.add(i, "totalSize");
				}
				hashMap.put(keysList.get(i),valuesList.get(i));

			}
			PALogger.INFO(""+hashMap);
			int usedpercentage= Integer.parseInt(hashMap.get("Use%").replace("%", " ").trim());
			int freespace=100-usedpercentage;//&& increaseDiskSize+comarevalue <= maxDiskSize 			
			if(freespace <= comarevalue)
			{
				String baseSizeCmd="gcloud --quiet compute disks list  --filter=\"name="+Constants.getClusterName()+"\" | sed -n '2p' | awk {'print $3'}";
				ArrayList<String> s2=new ArrayList<>();
				s2.add("/bin/bash");
				s2.add("-c");
				s2.add(baseSizeCmd);
				long  basesizedata = Long.parseLong(getBaseSize(s2));			
				if( basesizedata+increaseDiskSize <= maxDiskSize)
				{
					Map<String, Object> result= new HashMap<>();
					Map<String,Object> triggerht = new HashMap<>();
					triggerht.put("triggerCondition", comarevalue);
					triggerht.put("diskSize", increaseDiskSize);
					triggerht.put("maxDiskSize", maxDiskSize);
					result.put("trigger", triggerht);
					result.put("increaseDiskSize", String.valueOf(increaseDiskSize+basesizedata));
					String logId =addRuleLog(ruleId,RuleStatus.running,result);	
					result=addDisk(1,increaseDiskSize+basesizedata);
					RuleStatus success =RuleStatus.success;
					if(!Boolean.parseBoolean(result.get("success").toString()))
						success = RuleStatus.failure;

					result.put("trigger", triggerht);
					updateRuleLog(logId, success, Integer.parseInt(result.get("stage").toString()), result);
				}

			}

		} catch (Exception e) {
			PALogger.ERROR(""+e.getMessage());
		}

			
	}


	public Map<String, Object> addDisk(int stage,long increaseDiskSize) {
		String increasedOutputMessage="";	
		HashMap<String, Object> result  = new HashMap<>();
		switch (stage) {
		case 1:
			String gcloudMessage="";
			try {				
				gcloudMessage= doLinuxCommand("gcloud --quiet compute disks resize --size "+increaseDiskSize+"GB " +Constants.getDataDiskName());
				if(!gcloudMessage.contains("creationTimestamp")){
					throw new Exception(gcloudMessage);
				}
			}
			catch (Exception e) {
				result.put("success", false);
				result.put("stage", 1);
				result.put("increaseDiskSize", String.valueOf(increaseDiskSize));
				result.put("error", e.getMessage());

				PALogger.ERROR(e);
				return result;
			}	
			PALogger.INFO("gcloud Resized message "+gcloudMessage);
		case 2:
			String cmdToIncreaseSize="kubectl exec -it $(kubectl get pods | grep -m 1 ^nfs-server | awk {'print $1'}) -- resize2fs /dev/sdb";
			ArrayList<String> s2=new ArrayList<>();
			s2.add("/bin/bash");
			s2.add("-c");
			s2.add(cmdToIncreaseSize);

			try {
				increasedOutputMessage=executeCommand(s2);
				if(!increasedOutputMessage.contains("The filesystem on /dev/sdb is now")){
					throw new Exception(increasedOutputMessage);
				}
			} catch (Exception e) {
				result.put("success", false);
				result.put("stage", 2);
				result.put("increaseDiskSize", String.valueOf(increaseDiskSize));
				result.put("error", e.getMessage());

				PALogger.ERROR(e);
				return result;
			}	
			PALogger.INFO("kube Resized Message :-"+increasedOutputMessage);
			break;
		default:
			break;
		}
		result.put("success", true);
		result.put("increaseDiskSize", String.valueOf(increaseDiskSize));
		result.put("stage", 2);

		return result;
	}

	public List<String> clusterMonitoring(List<String> command) throws Exception {
		List<String> arrayobj=new ArrayList<>();
		String output= executeCommand(command);
		String[] lines = output.split("\\r?\\n");
		if(lines[0].contains("Unable to use a TTY - input is not a terminal or the right kind of file"))
		{
			arrayobj.add(lines[1]);
			arrayobj.add(lines[2]);
		}else{
			arrayobj.add(lines[0]);
			arrayobj.add(lines[1]);
		}

		return arrayobj;
	}

	public String getBaseSize(List<String> command) throws Exception {
		String output= executeCommand(command);	
		return output.trim();
	}

	/**
	 * its run the linux command
	 * @param Command
	 * @return
	 * @throws Exception
	 */
	public String  executeCommand(List<String>  command) throws Exception
	{		
		PALogger.INFO("doLinuxCommand - "+ command);	
		CommandExecutor commandExecutor = new CommandExecutor();
		return commandExecutor.Execute(command);		
	}


	/**
	 * its run the linux command
	 * @param command
	 * @return
	 * @throws IOException 
	 * @throws InterruptedException 
	 */
	public String doLinuxCommand(String command) throws  IOException, InterruptedException 
	{
		PALogger.INFO("doLinuxCommand - "+ command);
		StringBuilder result = new StringBuilder();	
		Runtime r = Runtime.getRuntime();
		Process p = r.exec(command);
		BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
		String str = "";
		while ((str = br.readLine()) != null)
		{
			result.append(str);
			PALogger.INFO(str);
		}
		br.close();
		p.waitFor();
		p.destroy();

		return result.toString();
	}


	private String addRuleLog(String ruleId, RuleStatus status,Map<String, Object> data){

		try {

			return new RuleTriggerLogs().insert(ruleId, status,new Gson().toJson(data));

		} catch (SQLException e) {
			PALogger.ERROR(e);
		}
		return null;
	}

	private void updateRuleLog(String id,  RuleStatus status, int stage, Map<String, Object> data){
		try {
			RuleTriggerLogVO  rultVO = new RuleTriggerLogs().update(id,  status, stage, new Gson().toJson(data));
		
			
			RuleVO rulevo = new Rule().get(rultVO.getRuleId());
			Map<String, Object> list = new Gson().fromJson(rulevo.getRuleValue(), HashMap.class);

			NotificationType notificatiotype = NotificationType.None;
			String msg = "Disk size increased by " + list.get("diskIncreaseSize") + "GB free disk space is below " + list.get("ruleValue")  + " and maximum disk size is " + list.get("maxDiskSize") + ".";
			
			if(rultVO.getStatus() == RuleStatus.failure)
			{
				notificatiotype = NotificationType.Error;
				msg = "Increased disk size failed by " + list.get("diskIncreaseSize") + "GB free disk space is below " + list.get("ruleValue")  + " and maximum disk size is " + list.get("maxDiskSize") + ".";
			}

			AlertsEngine eng= new AlertsEngine();
			eng.add(notificatiotype,rultVO ,MessageType.RuleLog,msg);
		} catch (SQLException e) {
			PALogger.ERROR(e);
		}
	}


}
