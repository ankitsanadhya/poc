/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.framework;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.management.InstanceAlreadyExistsException;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;

import com.mwp.common.Common;
import com.mwp.common.CredProvider;
import com.mwp.common.StringFunctions;
import com.mwp.common.TempFiles;
import com.mwp.common.constant.Constant;
import com.mwp.common.vo.FunctionVO;
import com.mwp.common.vo.FunctionVersionVO;
import com.mwp.logger.PALogger;
import com.mwp.p.common.Constants;
import com.mwp.p.common.PortalCommon;
import com.mwp.p.dal.engine.FunctionsEngine;
import com.pa.crypto.FileEncryptionDecryption;

/**
 * This class provides functionality to add, delete update functions and its versions.Also save input stream of version to a file
 *
 */
public class Functions {

	/**
	 * Save file input stream into file path "/data/PortalChache/functions/<functionId>/<versionId>.<ext>" and add function in database
	 * @param functionVO
	 * @param fileStream file input Stream
	 * @param fileName  
	 * @return FunctionVO object set function file path public uri in FunctionBody property.
	 * @throws IOException 
	 * @throws SQLException 
	 * @throws InstanceAlreadyExistsException  if function name already exists in db.
	 */
	public FunctionVO addFunction(FunctionVO functionVO, InputStream fileStream, String fileName) throws InstanceAlreadyExistsException, SQLException, IOException  {
		return mAddFunction(functionVO, fileStream, fileName);
	}

	/**
	 * List all functions of user with user id.
	 * @param userId 
	 * @return
	 * @throws SQLException 
	 * @throws Exception 
	 */
	public List<FunctionVO> listAllFunctions(String userId) throws SQLException {
		return mListAllFunctions(userId);
	}

	/**
	 * Add function version to function.
	 * Save file input stream into file path "/data/PortalChache/functions/<functionId>/<versionId>.<ext>" and add function in database
	 * @param versionVO version object to be add
	 * @param fileStream file input stream
	 * @param fileName file name used to get extention to save file 
	 * @return FunctionVersionVO object
	 * @throws SQLException 
	 * @throws IOException 
	 * @throws Exception
	 */
	public FunctionVersionVO addFunctionVersion(FunctionVersionVO versionVO, InputStream fileStream, String fileName) throws IOException, SQLException  {
		return mAddFunctionVersion(versionVO, fileStream, fileName);
	}

	/**
	 * List all versions of a given function id.
	 * @param FunctionVO
	 * @return
	 * @throws SQLException 
	 * @throws Exception 
	 */
	public List<FunctionVersionVO> listAllVersion(String functionId) throws SQLException {
		return mListAllVersions(functionId);
	}

	/**
	 *  Get function with given function id and  version id
	 * @param functionId
	 * @param versionId
	 * @return FunctionVO object
	 * @throws Exception
	 */
	public FunctionVO getFunction(String functionId, String versionId,String userId) throws SQLException {
		return mGetFunction(functionId, versionId,userId);
	}

	/**
	 * Get all versions of function for given version ids. 
	 * @param versionIds comma seperated list of version ids.
	 * @return List of FunctionVersionVO  object
	 * @throws SQLException 
	 * @throws Exception
	 */
	public List<FunctionVersionVO> getFunctionVersions(String versionIds) throws SQLException   {
		return mGetFunctionVersions(versionIds);
	}

	/**
	 * Get object of function for given function id.
	 * @param functionId function id 
	 * @return FunctionVO object
	 * @throws Exception 
	 */
	public FunctionVO getFunction(String functionId) throws SQLException {
		return mGetFunction(functionId);
	}

	/**
	 * delete a function with function Id.
	 * @param functionId 
	 * @return deleted function funcationId
	 * @throws Exception 
	 */
	public String deleteFunction(String functionId) throws SQLException {
		return mDeleteFunction(functionId);
	}

	/**
	 * Delete version of function 
	 * @param FunctionVO
	 * @return deleted function funcationId
	 * @throws Exception 
	 */
	public String deleteFunctionVersion(String functionId, String versionId) throws SQLException {
		return mDeleteFunctionVersion(functionId, versionId);
	}

	//****************************PRIVATE METHODS*************************************



	private FunctionVO mGetFunction(String functionId, String versionId,String userId) throws SQLException {
		return new FunctionsEngine().getFunction(functionId, versionId,userId);
	}

	private List<FunctionVersionVO> mGetFunctionVersions(String versionIds) throws SQLException {

		List<String> versionIdsList = new ArrayList<>();

		String[] versionIdsArr = versionIds.split(",");


		for (int i = 0; i < versionIdsArr.length; i++) {

			String versionId = versionIdsArr[i].trim();

			if(!StringFunctions.isNullOrWhitespace(versionId)) {
				versionIdsList.add(versionId);
			}
		}

		return new FunctionsEngine().getFunctionVersions(versionIdsList);
	}

	private FunctionVO mGetFunction(String functionId) throws SQLException {
		return new FunctionsEngine().getFunction(functionId);
	}

	private FunctionVO mAddFunction(FunctionVO functionVO, InputStream fileStream, String fileName) throws InstanceAlreadyExistsException, SQLException, IOException  {
		FunctionsEngine functionsEngine = new FunctionsEngine();
		if(functionsEngine.checkFunctionNameExist(functionVO.getName(), functionVO.getUserId())){
			throw new InstanceAlreadyExistsException("Function name "+ functionVO.getName() +" already exists");
		}

		functionVO.setFunctionId(Common.getRandomId());

		FunctionVersionVO versionVO = functionVO.getVersions().get(0);
		String versionId = Common.getRandomId();
		versionVO.setFunctionVersionId(versionId);
		versionVO.setFunctionId(functionVO.getFunctionId());

		String path = saveFile(fileStream, functionVO.getFunctionId(), versionId, fileName);

		versionVO.setFunctionBody(path);

		functionVO = functionsEngine.addFunction(functionVO);

		versionVO.setFunctionBody(PortalCommon.getInstance().createPublicUrl(path, Constants.UI_FOLDER_NAME));

		return functionVO;
	}

	private FunctionVersionVO mAddFunctionVersion(FunctionVersionVO versionVO, InputStream fileStream, String fileName) throws IOException, SQLException {

		versionVO.setFunctionVersionId(Common.getRandomId());

		String path = saveFile(fileStream, versionVO.getFunctionId(), versionVO.getFunctionVersionId(), fileName);

		versionVO.setFunctionBody(path);

		FunctionsEngine functionsEngine = new FunctionsEngine();
		int maxVersion = functionsEngine.getMaxVersion(versionVO.getFunctionId());

		versionVO.setVersion(maxVersion + 1);

		FunctionVersionVO functionVersionVO = functionsEngine.addFunctionVersion(versionVO);

		functionVersionVO.setFunctionBody(PortalCommon.getInstance().createPublicUrl(path, Constants.UI_FOLDER_NAME));

		return functionVersionVO;
	}

//	private String saveFile(InputStream fileStream, String functionId, String versionId, String fileName) throws IOException {
//		String pathname = Constants.PORTAL_FILES_PATH+"functions" +Constant.localFileSeparator + functionId;
//		OutputStream out = null;
//		try {
//			File file = new File(pathname);
//
//			if(file.exists()) {
//				FileUtils.deleteQuietly(file);
//			} else {			
//				file.mkdirs();
//			}
//
//			String extention = FilenameUtils.getExtension(fileName);
//			if(StringFunctions.isNullOrWhitespace(extention)) {
//				extention = "zip";
//			}
//			String tempEncPath =TempFiles.getTempFolderPath() + versionId;
//
//			pathname = pathname + Constant.localFileSeparator + versionId + "." + extention;
//			file = new File(tempEncPath);
//			boolean fileCreated = file.createNewFile();
//			if(!fileCreated){
//				//Already exists with temp name 
//				FileUtils.deleteQuietly(file);
//				fileCreated = file.createNewFile();
//			}
//			out = new FileOutputStream(file);
//			byte[] buf = new byte[1024];
//			int len;
//			while((len=fileStream.read(buf))>0){
//				out.write(buf,0,len);
//			}
//			FileEncryptionDecryption.Encrypt_File(tempEncPath, pathname, new CredProvider().getEcnKey());
//	
//	} finally {
//		try {
//			if(out != null) {
//				out.close();
//			}
//		}catch (Exception e)
//		{
//			PALogger.ERROR(e);
//		}
//
//		try {
//			fileStream.close();
//		} catch (Exception e) 
//		{
//			PALogger.ERROR(e);
//		}
//	}
//
//	return pathname;
//}
	
	private String saveFile(InputStream fileStream, String functionId, String versionId, String fileName)
			throws IOException {
		String pathname = Constants.PORTAL_FILES_PATH + "functions" + Constant.localFileSeparator + functionId;
		OutputStream out = null;
		try {
			File file = buildFile(pathname);

			if (file.exists()) {
				file.delete();
			} else {
				file.mkdirs();
			}

			String extention = FilenameUtils.getExtension(fileName);
			if (StringFunctions.isNullOrWhitespace(extention)) {
				extention = "zip";
			}
			String tempEncPath = TempFiles.getTempFolderPath() + versionId;

			pathname = pathname + Constant.localFileSeparator + versionId + "." + extention;
			file = buildFile(tempEncPath);
			file.createNewFile();

			out = buildFileOutputStream(file);
			byte[] buf = new byte[1024];
			int len;
			while ((len = fileStream.read(buf)) > 0) {
				out.write(buf, 0, len);
			}

			FileEncryptionDecryption.Encrypt_File(tempEncPath, pathname, buildCredProvider().getEcnKey());
		} finally {
			try {
				if (out != null) {
					out.close();
				}
			} catch (Exception e) {
				PALogger.ERROR(e);
			}

			try {
				fileStream.close();
			} catch (Exception e) {
				PALogger.ERROR(e);
			}
		}

		return pathname;
	}

	public CredProvider buildCredProvider() {
		return new CredProvider();
	}

	public FileOutputStream buildFileOutputStream(File file) throws FileNotFoundException {
		return new FileOutputStream(file);
	}

	public File buildFile(String pathname) {
		return new File(pathname);
	}

	private List<FunctionVO> mListAllFunctions(String userId) throws SQLException {
		FunctionsEngine functionsEngine = new FunctionsEngine();
		return functionsEngine.listAllFunctions(userId);
	}

	private List<FunctionVersionVO> mListAllVersions(String functionId) throws SQLException {
		FunctionsEngine functionsEngine = new FunctionsEngine();
		return functionsEngine.listAllVersion(functionId, false);
	}

	private String mDeleteFunction(String functionId) throws SQLException {
		FunctionsEngine functionsEngine = new FunctionsEngine();
		functionsEngine.deleteFunction(functionId);
		return functionId;
	}

	private String mDeleteFunctionVersion(String functionId, String versionId) throws SQLException {
		FunctionsEngine functionsEngine = new FunctionsEngine();
		functionsEngine.deleteFunctionVersion(functionId, versionId);
		return functionId;
	}
}
