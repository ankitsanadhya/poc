/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.framework;

import java.sql.SQLException;
import java.util.List;

import com.mwp.p.common.enums.PortalDBEnum.AD_TYPE;
import com.mwp.p.common.vo.AdZoneVO;
import com.mwp.p.dal.engine.AdZoneEngine;

/**
 * this class access data from adZone table
 * @author root
 *
 */
public class AdZone
{
	/**
	 * method to insert ad zone
	 * @param adZoneObj{@link AdZoneVO}
	 * @return {@link AdZoneVO}
	 * @throws SQLException 
	 */
	public AdZoneVO add(AdZoneVO adZoneObj) throws SQLException
	{
		return mAdd(adZoneObj);
	}
	
	/**
	 * method to edit sort order of zone
	 * @param sortOrder
	 * @param adId
	 * @return
	 * @throws SQLException 
	 */
	public boolean editSortOrder(int sortOrder, String adId) throws SQLException
	{
		return mEditSortOrder(sortOrder, adId);
	}
	
	/**
	 * method to delete a zone
	 * @param adId
	 * @return
	 * @throws SQLException 
	 */
	public boolean delete(String adId) throws SQLException
	{
		return mDelete(adId);
	}
	/**
	 * method to get ad zone for given adId and zoneId
	 * @param adId
	 * @param zoneId
	 * @return  {@link AdZoneVO}
	 * @throws SQLException 
	 */
	public AdZoneVO get(String adId, String zoneId) throws SQLException
	{
		return mGet(adId, zoneId);
	}
	/**
	 * list all ad zones
	 * @return List<{@link AdZoneVO}>
	 * @throws SQLException 
	 */
	public List<AdZoneVO> list() throws SQLException
	{
		return mList();
	}
	
	/**
	 * list zone according to type
	 * @param type
	 *  @return List<{@link AdZoneVO}>
	 * @throws SQLException
	 */
	public List<AdZoneVO> listByType(AD_TYPE type) throws SQLException
	{
		return mListByType(type);
	}
	
	/**
	 * list zone by categoryId
	 * @param categoryId
	 * @return List<{@link AdZoneVO}>
	 * @throws SQLException
	 */
	public List<AdZoneVO> listByCategory(String categoryId) throws SQLException
	{
		return mListByCategory(categoryId);
	}
	
	//PRIVATE METHODS
	
	private AdZoneVO mAdd(AdZoneVO adZoneObj) throws SQLException
	{
		AdZoneEngine zoneEng= new AdZoneEngine();
		return zoneEng.add(adZoneObj);
	}
	
	private boolean mEditSortOrder(int sortOrder, String adId) throws SQLException
	{
		AdZoneEngine zoneEng= new AdZoneEngine();
		return zoneEng.editSortOrder(sortOrder, adId);
	}
	
	private boolean mDelete(String adId) throws SQLException
	{
		AdZoneEngine zoneEng= new AdZoneEngine();
		return zoneEng.delete(adId);
	}
	
	private AdZoneVO mGet(String adId, String zoneId) throws SQLException
	{
		AdZoneEngine zoneEng= new AdZoneEngine();
		return zoneEng.get(adId, zoneId);
	}
	private List<AdZoneVO> mList() throws SQLException
	{
		AdZoneEngine zoneEng= new AdZoneEngine();
		return zoneEng.list();
	}
	
	private List<AdZoneVO> mListByType(AD_TYPE type) throws SQLException
	{
		AdZoneEngine zoneEng= new AdZoneEngine();
		return zoneEng.listByType(type);
	}
	private List<AdZoneVO> mListByCategory(String categoryId) throws SQLException
	{
		AdZoneEngine zoneEng= new AdZoneEngine();
		return zoneEng.listByCategory(categoryId);
	}
}
