/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.framework;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.amazonaws.services.route53.model.ChangeAction;
import com.mwp.common.Common;
import com.mwp.common.StringFunctions;
import com.mwp.common.constant.Constant;
import com.mwp.common.constant.ErrorMessage;
import com.mwp.common.enums.ApplicationDefaultType;
import com.mwp.common.enums.DeviceTypeEnum;
import com.mwp.common.enums.InstallJobStatusEnum;
import com.mwp.common.enums.NodeType;
import com.mwp.common.enums.OwnershipEnum;
import com.mwp.common.enums.SW_PLATFORMS;
import com.mwp.common.enums.StateEnum;
import com.mwp.common.enums.TypeEnum;
import com.mwp.common.vo.AuthorizationsVO;
import com.mwp.common.vo.DeviceNodeVO;
import com.mwp.common.vo.DeviceVO;
import com.mwp.common.vo.FilterObject;
import com.mwp.common.vo.InstallJobVO;
import com.mwp.common.vo.PlatformVO;
import com.mwp.logger.PALogger;
import com.mwp.p.common.Constants;
import com.mwp.p.common.vo.DeviceApplicationVO;
import com.mwp.p.dal.engine.ApplicationTypeEngine;
import com.mwp.p.dal.engine.AssignedRelayPortsEngine;
import com.mwp.p.dal.engine.DeviceLabelEngine;
import com.mwp.p.dal.engine.DevicesEngine;
import com.mwp.p.dal.engine.DiscoveryJarDetailsEngine;
import com.mwp.p.dal.engine.InstallJobEngine;
import com.mwp.p.framework.ManageDomainNameGoogle.DomainOperation;

/**
 * This class provides all functionality related to devices and nodes.List devices, node of kubernetes cluster,   
 * 
 */
public class Devices {

	/**
	 * List devices of user.
	 * @param userId user id
	 * @param deviceId if deviceId is empty or null then all devices of user will be listed with nodes otherwise all kubernetes node devices will be list for single cluster with devcieId.
	 * @param isListLabels Also list labels with device objects if this param is true.
	 * @return list of DeviceVO object with all node devices set in nodes property.
	 * @throws Exception
	 */
	public List<DeviceVO> listDevice(String userId, String deviceId, boolean isListLabels) throws SQLException {
		return mListDevice(userId, deviceId,isListLabels);
	}

	
	/**
	 *  List cluster of a user. 
	 * @param userId user id
	 * @return
	 * @throws SQLException
	 * @author PS
	 */
	public List<DeviceVO> listKubenetesClusterForUser(String userId) throws SQLException {		
		return listKubenetesClusterForUser(userId, null);
	}
	
	/**
	 * 
	 * @param userId
	 * @param clusterId cluster id which is to get for user
	 * @return
	 * @throws SQLException
	 */
	public List<DeviceVO> listKubenetesClusterForUser(String userId, String clusterId) throws SQLException {		
		return mListKubenetesClusterForUser(userId, clusterId);
	}
	
	/**
	 * List all application info, all application that exist on device using paging.
	 * @param pageNo page number
	 * @param pageSize number of applications to be returned in one page of result
	 * @param userId user Id
	 * @param deviceId device Id 
	 * @return hash map of result with keys-> totalPages,  pageNo, pageSize , data.hashmap value of key "data" contains List<DeviceApplicationVO>
	 * @throws Exception
	 */
	public Map<String, Object> listDeviceApplication(int pageNo, int pageSize, String userId, String deviceId) throws SQLException {
		return mListDeviceApplication(pageNo, pageSize, userId, deviceId);
	}


	/**
	 * List all applications of device for given device Id.
	 * @param authVo
	 * @param deviceId
	 * @return
	 * @throws Exception
	 */
	public List<DeviceApplicationVO> listAllAppsOfDevice(AuthorizationsVO authVo, String deviceId) throws SQLException {
		return mListAllAppOfDevice(authVo, deviceId);
	} 

	public Map<String, Object> listAppsOfDevice(String userId, String deviceId,List<FilterObject> filters,int pageNo, int pageSize) throws SQLException {
		return mListAppOfDevice(userId, deviceId, filters, pageNo, pageSize);
	} 



	/**
	 * Add or update device application in database, update check on deviceId, appId.
	 * i.e. Only one entry will for deviceId-appId
	 * @param deviceVO
	 * @return
	 * @throws Exception 
	 */
	public DeviceApplicationVO addDeviceApplication(DeviceApplicationVO deviceApplication) throws SQLException 
	{
		DevicesEngine de = new DevicesEngine();
		return de.addDeviceApplication(deviceApplication);
	}

	
	/**
	 * add or update device application in deviceapplicationDB. Exists check is on appId and deviceId keys.
	 * @param list of deviceApplication
	 * @return
	 * @throws SQLException
	 */
	public List<String> addUpdateDeviceApplication(List<DeviceApplicationVO> deviceApps) throws SQLException
	{
		List<String> appIDs = new ArrayList<>();
		for (DeviceApplicationVO deviceApplicationVO : deviceApps) 
		{
			appIDs.add(addDeviceApplication(deviceApplicationVO).getApplicationId());
		}
		return appIDs;
	}

	


	/**
	 * update isActivationConfirmed to 1 for given deviceId
	 * @param deviceId
	 * @throws Exception 
	 */
	public void updateActivationStatus(String deviceId) throws SQLException {
		mUpdateActivationStatus(deviceId);
	}

	/**
	 * Activate device
	 * String macAddress, String hostName, String machineId, String nativeAppId, String deviceName, String licenseKey , String userId
	 * @param deviceVO
	 * @return
	 * @throws Exception 
	 */
	public  Map<String, Object>  activateDevice(DeviceVO deviceVO, String licenseKey,String networkJson, String jwtPublicKey) throws Exception {
		return mActivateDevice(deviceVO,licenseKey, networkJson, jwtPublicKey);
	}


	/**
	 * check if device is available.
	 * @param 
	 * @return
	 * @throws SQLException 
	 * @throws Exception 
	 */
	public boolean isDeviceExist(String deviceId,String userid) throws SQLException{
		return mIsDeviceExist(deviceId,userid);
	}


	/**
	 * check if device name is available.
	 * @param deviceName
	 * @param macAddress if mac address can be empty in case of cluster
	 * @return
	 * @throws SQLException
	 */
	public boolean isDeviceNameAvailable(String deviceName, String macAddress) throws SQLException{
		return mIsDeviceNameAvailable(deviceName, macAddress);
	}

	/**
	 * This method remove device-application relation from deviceApplication, 
	 * and change device status = 'DELETED'.
	 * @param deviceId
	 * @param userId
	 * @return
	 * @throws SQLException 
	 */
	public DeviceVO deleteDeviceApplication(String deviceId, String userId) throws SQLException {
		return mDeleteDeviceApplication(deviceId, userId);
	}

	/**
	 * Delete device node from cluster. Also factory reset the node device and delete all entries related to it. 
	 * @param nodeId the node id of device 
	 * @param deviceId cluster id from which the node to be deleted
	 * @param canDeleteMaster if true then master node will be deleted without error. otherwise throw exception if master node delete requested. 
	 * @return true when delete successful false otherwise.
	 * @throws SQLException
	 */
	public boolean deleteClusterNode(String nodeId,String deviceId, boolean canDeleteMaster) throws SQLException {
		return mDeleteClusterNode(nodeId, deviceId, canDeleteMaster);
	}


	/**
	 * search devices using  filters and paging. 
	 * @param pageNo page number
	 * @param pageSize number of result to be returned in one page of result.  
	 * @param filters (sort, search text, start with, start end, etc.).
	 * @return hash map of result with keys-> totalPages,  pageNo, pageSize , data.hashmap value of key "data" contains List<DeviceVO>
	 * @throws Exception
	 */
	public Map<String, Object> searchDevices(int pageNo, int pageSize, Map<String, Object> filters) throws SQLException {
		return new DevicesEngine().searchDevice(pageNo, pageSize, filters);
	}

	/**
	 * Get all information of device by device hostName.if device id is of kubernetescluster then the child node devices will set in nodes property.   
	 * @param hostName
	 * @return DeviceVO object 
	 * @throws SQLException
	 */
	public DeviceVO getDeviceByHostName(String hostName) throws SQLException {
		return new DevicesEngine().getDeviceByHostName(hostName);
	}

	
	private DeviceVO mDeleteDeviceApplication(String deviceId, String userId) throws SQLException 
	{
//		VirtualURLEngine engg= new VirtualURLEngine();
//		List<String> domainNames = engg.listDomainNames(deviceId) ;

		DeviceVO deviceVO = new DevicesEngine().deleteDeviceApplication(deviceId, userId);
	
		try{

			for (DeviceNodeVO nodeVO : deviceVO.getNodes()) 
			{	
				if(nodeVO.getDiscoveryDetailsVO() != null)
				{
					String[] ipAddressArr = nodeVO.getDiscoveryDetailsVO().getsIPAddress().split(","); 
					String ipAddress = ipAddressArr[0];
					if(ipAddressArr.length > 1){
						ipAddress = ipAddressArr[1];
					}
					String localDeviceName = "l-"+nodeVO.getDeviceName().trim();

					switch (Constants.getDNS_SERVER()) {
					case AMZ:
						ManageDomainName.runCommand(ChangeAction.DELETE, nodeVO.getDeviceName(), ipAddress);
						ManageDomainName.runCommand(ChangeAction.DELETE, localDeviceName, nodeVO.getDiscoveryDetailsVO().getsLocalIPAddress());
						break;
					case AZR:
						break;
					case GOO:
						ManageDomainNameGoogle.runCommand(DomainOperation.Delete, nodeVO.getDeviceName(), ipAddress, "");
						ManageDomainNameGoogle.runCommand(DomainOperation.Delete,localDeviceName, nodeVO.getDiscoveryDetailsVO().getsLocalIPAddress(),"");
						break;
					case JD:
						ManageDomainNameJD.runCommand(DomainOperation.Delete, nodeVO.getDeviceName(), ipAddress, "");
						ManageDomainNameJD.runCommand(DomainOperation.Delete,localDeviceName, nodeVO.getDiscoveryDetailsVO().getsLocalIPAddress(),"");
						break;
					default:
						break;
					}


					if(!StringFunctions.isNullOrWhitespace(nodeVO.getDiscoveryDetailsVO().getsRelayServerAddress()))
					{
						// Run delete amazon command  - 

						ipAddress=nodeVO.getDiscoveryDetailsVO().getsRelayServerAddress();
						String rAddressName = "r-"+nodeVO.getDeviceName().trim();

						switch (Constants.getDNS_SERVER()) {
						case AMZ:
							ManageDomainName.runCommand(ChangeAction.DELETE, rAddressName, ipAddress);
							ManageDomainName.runCommand(ChangeAction.DELETE, nodeVO.getDeviceName(), ipAddress);
							break;
						case AZR:
							break;
						case GOO:
							ManageDomainNameGoogle.runCommand(DomainOperation.Delete, rAddressName, ipAddress, "");
							ManageDomainNameGoogle.runCommand(DomainOperation.Delete,nodeVO.getDeviceName(), ipAddress,"");
							break;
						case JD:
							ManageDomainNameJD.runCommand(DomainOperation.Delete, rAddressName, ipAddress, "");
							ManageDomainNameJD.runCommand(DomainOperation.Delete,nodeVO.getDeviceName(), ipAddress,"");
							break;
						default:
							break;
						}

					}	
					if((deviceVO.getDeviceType() == DeviceTypeEnum.DockerCompose ||
							(deviceVO.getDeviceType() == DeviceTypeEnum.KubernetesCluster && nodeVO.getDeviceRole() == NodeType.MASTER && nodeVO.getDeviceState() ==  StateEnum.Active))
							&& (!StringFunctions.isNullOrWhitespace(ipAddress)))
						{	
//							for (String domainName : domainNames) 
//							{
//								switch (Constants.getDNS_SERVER()) {
//								case AMZ:
//									ManageDomainName.runCommand(ChangeAction.DELETE,domainName, ipAddress);
//									break;
//								case AZR:
//									break;
//								case GOO:
//									ManageDomainNameGoogle.runCommand(DomainOperation.Delete,domainName,ipAddress,"");
//									break;
//								case JD:
//									ManageDomainNameJD.runCommand(DomainOperation.Delete,domainName,ipAddress,"");
//									break;
//								default:
//									break;
//								}
//
//							}
						}
					
				}
			}
			//TOD call any query for cluster after delete  all node??

		}catch(Exception ex){
			PALogger.ERROR(ex);	
		}
		return deviceVO;
	}

	private boolean mDeleteClusterNode(String nodeId, String deviceId,boolean canDeleteMaster) throws SQLException 
	{
		DeviceNodeVO nodeVO = new DevicesEngine().deleteClusterNode(nodeId, deviceId, canDeleteMaster);

		if(nodeVO != null && nodeVO.getDiscoveryDetailsVO() != null){
				String[] ipAddressArr = nodeVO.getDiscoveryDetailsVO().getsIPAddress().split(","); 
				String ipAddress = ipAddressArr[0];
				if(ipAddressArr.length > 1){
					ipAddress = ipAddressArr[1];
				}

				String localDeviceName = "l-"+nodeVO.getDeviceName().trim();

				switch (Constants.getDNS_SERVER()) {
				case AMZ:
					ManageDomainName.runCommand(ChangeAction.DELETE, nodeVO.getDeviceName(), ipAddress);		
					ManageDomainName.runCommand(ChangeAction.DELETE, localDeviceName, nodeVO.getDiscoveryDetailsVO().getsLocalIPAddress());
					break;
				case AZR:
					break;
				case GOO:
					ManageDomainNameGoogle.runCommand(DomainOperation.Delete, nodeVO.getDeviceName(), ipAddress, "");
					ManageDomainNameGoogle.runCommand(DomainOperation.Delete, localDeviceName, nodeVO.getDiscoveryDetailsVO().getsLocalIPAddress(), "");
					break;
				case JD:
					ManageDomainNameJD.runCommand(DomainOperation.Delete, nodeVO.getDeviceName(), ipAddress, "");
					ManageDomainNameJD.runCommand(DomainOperation.Delete, localDeviceName, nodeVO.getDiscoveryDetailsVO().getsLocalIPAddress(), "");
					break;
				default:
					break;
				}

				

				String relayServerAddress = nodeVO.getDiscoveryDetailsVO().getsRelayServerAddress();
				if(!StringFunctions.isNullOrWhitespace(relayServerAddress)){
					// Run delete amazon command  - 

					String rAddressName = "r-"+nodeVO.getDeviceName().trim();


					switch (Constants.getDNS_SERVER()) {
					case AMZ:
						ManageDomainName.runCommand(ChangeAction.DELETE, rAddressName, relayServerAddress);
						ManageDomainName.runCommand(ChangeAction.DELETE, nodeVO.getDeviceName(), relayServerAddress);
						break;
					case AZR:
						break;
					case GOO:
						ManageDomainNameGoogle.runCommand(DomainOperation.Delete, rAddressName, relayServerAddress, "");
						ManageDomainNameGoogle.runCommand(DomainOperation.Delete, nodeVO.getDeviceName(), relayServerAddress, "");
						break;
					case JD:
						ManageDomainNameJD.runCommand(DomainOperation.Delete, rAddressName, relayServerAddress, "");
						ManageDomainNameJD.runCommand(DomainOperation.Delete, nodeVO.getDeviceName(), relayServerAddress, "");
						break;
					default:
						break;
					}

				
				}
			}
		
		return true;
	}



	private boolean mIsDeviceExist(String deviceId,String userId) throws SQLException {
		DevicesEngine devicesEngine=new DevicesEngine();
		return devicesEngine.isDeviceExist(deviceId, userId);

	}


	private List<DeviceVO> mListDevice(String userId, String deviceId, boolean isListLabels) throws SQLException {
		DevicesEngine devicesEngine=new DevicesEngine();
		return devicesEngine.listDevice(userId, deviceId,isListLabels);

	}

	private List<DeviceVO> mListKubenetesClusterForUser(String userId, String clusterId) throws SQLException {
		DevicesEngine devicesEngine=new DevicesEngine();
		return devicesEngine.listKubenetesClusterForUser(userId,clusterId);

	}
	private Map<String, Object>  mListDeviceApplication(int pageNo, int pageSize, String userId, String deviceId) throws SQLException {
		DevicesEngine devicesEngine=new DevicesEngine();
		return devicesEngine.listDeviceApplication(pageNo, pageSize, userId, deviceId);
	}


	private List<DeviceApplicationVO> mListAllAppOfDevice(AuthorizationsVO authVo, String deviceId) throws SQLException
	{
		DevicesEngine devicesEngine=new DevicesEngine();
		return devicesEngine.listAllAppOfDevice( authVo, deviceId);
	}


	public Map<String, Object> mListAppOfDevice(String userId, String deviceId,List<FilterObject> filters,int pageNo, int pageSize) throws SQLException
	{
		DevicesEngine devicesEngine=new DevicesEngine();
		return devicesEngine.listAppOfDevice(userId, deviceId, filters, pageNo, pageSize);

	}



	private void mUpdateActivationStatus(String deviceId) throws SQLException {
		DevicesEngine devicesEngine=new DevicesEngine();
		devicesEngine.updateActivationStatus(deviceId);
	}


	
	/**
	 * Activate device if device not already exists in database and license key is valid.
	 * if same device is activating with same macAddress, (possibly after factory reset) reuse the same device id.  
	 * @param deviceVO device object to be added.
	 * @param licenceKey licenceKey
	 * @param networkJson network json string.
	 * @return HashMap<String, Object> with nodeId and deviceId key value pair.
	 * @throws Exception "Device name not available.", "Invalid License.", "Device platform not supported."
	 */ 
	private HashMap<String, Object> mActivateDevice(DeviceVO deviceVO, String licenceKey, String networkJson,
			String jwtPublicKey) throws Exception {
		
		/**
		 *  Comment because this method always true.
		 */
		// if(checkLicenceValid(licenceKey))
		// {
		// Check if device name is unique.
		if (isDeviceNameAvailable(deviceVO.getDeviceName(), deviceVO.getNodeVO().getMacAddress()))
		{
			// Check if PlatformActualName exist in platform
			PlatformVO platFormVO = new Platform().getPlatForm(deviceVO.getPlatformActualName());
			if (platFormVO == null) {
				throw new Exception("Device " + deviceVO.getPlatformActualName() + " platform not supported.");
			} else {
				deviceVO.setPlatformId(platFormVO.getPlatformId());
			}
			// if same device is activating with same macAddress, (possibly
			// after factory reset or partial activation) reuse the same device
			// id.
			DeviceVO deviceVoDb = checkActivation(deviceVO.getNodeVO().getMacAddress());

			String nodeId = "";
			String deviceId = "";
			if (deviceVoDb == null) {
				deviceId = Common.getRandomId();
				nodeId = Common.getRandomId();
			} else {
				deviceId = deviceVoDb.getDeviceId();
				nodeId = deviceVoDb.getNodeVO().getNodeId();
			}
			deviceVO.setActivationConfirmed(true);
			deviceVO.setDeviceId(deviceId);
			deviceVO.getNodeVO().setDeviceId(deviceId);// assuming the node list
														// will not empty-PS
			deviceVO.getNodeVO().setDeviceName(deviceVO.getDeviceName());
			deviceVO.getNodeVO().setDeviceRole(NodeType.NODE);
			deviceVO.getNodeVO().setNodeId(nodeId);
			if (deviceVO.getSoftwarePlatformName() == SW_PLATFORMS.KUBERNETES) {
				deviceVO.setDeviceType(DeviceTypeEnum.KubernetesDevice);
				deviceVO.setSwPlatformId(new ApplicationTypeEngine().getTypeId(ApplicationDefaultType.kubernetes));
			} else {
				deviceVO.setDeviceType(DeviceTypeEnum.DockerCompose);
				deviceVO.setSwPlatformId(new ApplicationTypeEngine().getTypeId(ApplicationDefaultType.dockercompose));

			}
			new DevicesEngine().addDevice(deviceVO, networkJson);

			new DiscoveryJarDetailsEngine().deleteDiscoveryJarDetails(deviceVO.getNodeVO().getMacAddress());
			new AssignedRelayPortsEngine().updateAssignMacdevice(deviceVO.getNodeVO().getMacAddress(), nodeId);


			String jwtKeyPath = String.format(Constant.EDGE_JWT_PUBLIC_KEY_PATH, deviceVO.getNodeVO().getMacAddress());
			File jwtKeyPathFile = new File(jwtKeyPath);
			if (!jwtKeyPathFile.exists()) {
				jwtKeyPathFile.getParentFile().mkdirs();
			}

			FileUtils.writeStringToFile(jwtKeyPathFile, jwtPublicKey);

			// Commented as - Now no need to delete host name on successful
			// activation - PS

			HashMap<String, Object> result = new HashMap<>();
			result.put("deviceId", deviceVO.getDeviceId());
			result.put("nodeId", deviceVO.getNodeVO().getNodeId());
			return result;
		} else {
			throw new Exception(ErrorMessage.DEVICE_NAME_NOT_AVAILABLE);
		}
		// }
		// else
		// throw new Exception(ErrorMessage.INVALID_LICENSE);

	}

//	private boolean checkLicenceValid(String licenceKey) {
//		//TODO Licence server code
//		return true;
//	}



	private boolean mIsDeviceNameAvailable(String deviceName, String macAddress) throws SQLException
	{
		deviceName = deviceName.toLowerCase();


		//query devices to check if device name already being used
		DevicesEngine devicesEngine=new DevicesEngine();
		String dbMacAddress = devicesEngine.getMacAddress(deviceName);
		if(!StringFunctions.isNullOrWhitespace(dbMacAddress))
		{	
			// true Device name is available for use. else //Device name is already been taken from some other user.
			return  dbMacAddress.equals(macAddress);
			
		}

		//query to check if devicename already resereved for domain name
//		VirtualURLEngine urlMapEngg= new VirtualURLEngine();
//		boolean isNameUsed = urlMapEngg.isDomainNameExits(deviceName);
//		if(isNameUsed)
//			return false;

		//Check if device name is not restricted - form pixeom restricted device name list.
		//May be we can have this list in database with the flag to check - contains or equals
		String[] restrctarray = {"Mypixeom","pixeom","pxsmartstorage","meghaware","concierge","cloudtop","21c3","cloudoptix","pxn","relay","irelay","listing","ilisting","www","pst","artik","iothub","pixeomx1","x1","megha"};
		for (String restrctname : restrctarray) {
			if (deviceName.contains(restrctname)){ // Nobody can activate using this devicename
				return false; //Device name is reserved
			}
		}

		return true;
	}

	//If there is device with same macAddress from the same user, create a copy of device's record into Activation history table and return the old device id, otherwise return empty device id.
	private DeviceVO checkActivation(String macAddress) throws SQLException {
		DevicesEngine devicesEngine=new DevicesEngine();
		DeviceVO deviceVO = devicesEngine.getDeviceDetails(macAddress);
		if(deviceVO!=null && !StringFunctions.isNullOrWhitespace(deviceVO.getDeviceId()))
			{
				try{
					devicesEngine.addDeviceDetailsInActivationHistory(deviceVO);
				}
				catch (Exception e) {
					PALogger.ERROR(e);	
				}
			}
		return deviceVO;
	}

	/**
	 * This method give query for check device exist in db,
	 * corresponding to given macaddress param.
	 * @param productID
	 * @return  	HashMap<String, Object> with Status and ErrorMessage if status is false 
	 */
	public Map<String, Object> isProductIDUnique(String productID, String hostName) throws SQLException {
		HashMap<String, Object> hashResult = new HashMap<>();
		boolean isDeviceExists =  new DevicesEngine().isDeviceExistByMacAddress(productID);
		boolean isHostnameExists = false;  
		if(!StringFunctions.isNullOrWhitespace(hostName))
			isHostnameExists = new DevicesEngine().isHostNameExists(hostName);


		if(isDeviceExists || isHostnameExists)
		{
			hashResult.put("Status", false);
			hashResult.put("DuplicateProductID", isDeviceExists);
			hashResult.put("DuplicateHostName", isHostnameExists);
			hashResult.put("ErrorMessage", "Duplicate productId/hostName.");
		}else{
			hashResult.put("Status", true);
		}
		return hashResult;
	}


	/**
	 * List all devices along with boxStaticsModifiedDate, latest boxStatics ,latest appInstallTime , dHBRdate to use in utility that shows devices info using paging.
	 * Basically this method is used to analyze the behavior of devices.  
	 * @param pageNo page number 
	 * @param pageSize number of applications to be returned in one page of result.
	 * @param userId user Id
	 * @return hash map of result with keys-> totalPages,  pageNo, pageSize , data.hashmap value of key "data" contains List<DeviceUtilityVO> 
	 * @throws Exception
	 */
	public Map<String, Object> listDevicesUtilities(int pageNo, int pageSize, String userId) throws SQLException
	{
		return mListDevicesUtilities(pageNo, pageSize, userId);
	}


	private  Map<String, Object>  mListDevicesUtilities(int pageNo, int pageSize, String userId) throws SQLException
	{
		DevicesEngine devicesEngine =  new DevicesEngine();
		return devicesEngine.listDevicesUtility(pageNo, pageSize, userId);
	}

	/**
	 * Search all devices along with boxStaticsModifiedDate, latest boxStatics ,latest appInstallTime , dHBRdate to use in utility that shows devices info using paging.
	 * Basically this method is used to analyze the behavior of devices.  
	 * @param pageNo page number 
	 * @param pageSize number of applications to be returned in one page of result.
	 * @param userId user Id
	 * @param filters filters keys can be "dHBRDate" , "DeviceId" , "BSModifiedDate", "appInstallTime" and value can have start and end value of all the keys.  
	 * @return hash map of result with keys-> totalPages,  pageNo, pageSize , data.hashmap value of key "data" contains List<DeviceUtilityVO> 
	 * @throws SQLException
	 */
	public Map<String, Object> searchDevicesUtilities(int pageNo, int pageSize, String userId,Map<String,String> filters) throws SQLException
	{
		return mSearchDevicesUtilities(pageNo, pageSize, userId, filters);
	}


	private  Map<String, Object>  mSearchDevicesUtilities(int pageNo, int pageSize, String userId,Map<String,String> filters) throws SQLException
	{
		DevicesEngine devicesEngine =  new DevicesEngine();
		return devicesEngine.searchDevicesUtility(pageNo, pageSize, userId, filters);

	}

	/**
	 * Get platform Id of device Id.
	 * @param deviceId
	 * @return
	 * @throws Exception
	 */
	public String getPlatformId(String deviceId)throws SQLException
	{
		DevicesEngine devicesEngine =  new DevicesEngine();
		return devicesEngine.getPlatformId(deviceId);
	}

	public DeviceTypeEnum getDeviceType(String deviceId)throws SQLException
	{
		DevicesEngine devicesEngine =  new DevicesEngine();
		return devicesEngine.getDeviceType(deviceId);
	}

	/**


	/**
	 *  get owner id of device id
	 * @param deviceId
	 * @return
	 * @throws SQLException
	 */
	public String getUserId(String deviceId)throws SQLException
	{
		DevicesEngine devicesEngine =  new DevicesEngine();
		return devicesEngine.getUserId(deviceId);
	}

	/**
	 * this method return true if all devices belong to same owner else false
	 * @param deviceIds
	 * @param userId
	 * @return
	 * @throws SQLException
	 */
	public boolean isSameOwnerDevice(List<String> deviceIds,String userId) throws SQLException
	{
		DevicesEngine devicesEngine =  new DevicesEngine();
		return devicesEngine.isSameOwnerDevice(deviceIds, userId);
	}

	public Map<String, String> getDevicesOwner(List<String> deviceIds) throws SQLException
	{
		DevicesEngine devicesEngine =  new DevicesEngine();
		return devicesEngine.getDevicesOwner(deviceIds);
	}
	/**
	 * Get the updates of applications available for device. 
	 * @param deviceId device id
	 * @param installedAppIds installed application ids on device
	 * @param platformId
	 * @return ArrayList<HashMap<String, String>> HashMap<String, String> contains "appId", and "appVersionId" as key. 
	 * @throws SQLException
	 */
	public List<HashMap<String, String>> isUpdateAvilable(String deviceId, List<String> installedAppIds,String platformId) throws SQLException
	{
		return mIsUpdateAvilable(deviceId, installedAppIds,platformId);
	}

	private List<HashMap<String, String>> mIsUpdateAvilable(String deviceId,List<String> installedAppIds,String platformId) throws SQLException
	{
		DevicesEngine devicesEngine =  new DevicesEngine();
		return devicesEngine.isUpdateAvilable(deviceId,installedAppIds,  platformId);

	}

	/**
	 * Schedule operation for job for an application on device.Submit job to timer tasks to run on time scheduleTicks. 
	 * @param userId user Id
	 * @param deviceId device id on which the operation to be performed. 
	 * @param operation the operation to be performed.
	 * @param scheduleTicks the ticks to schedule operation
	 * @throws SQLException 
	 */
	public void scheduleOperation(String userId, String deviceId, String operation, long scheduleTicks) throws SQLException {
		mScheduleOperation(userId, deviceId, operation, scheduleTicks);
	}

	/**
	 * This method schedules operation system update in batches for all devices given in list.
	 * The batch size, interval, sizefactor and server count is used from Constant.TIMERS("/opt/timers") file, if file is not available then default values from constants is used.  
	 * @param deviceOwnerIds hashmap of device id and its owner id
	 * @param deviceIds
	 * @param operation
	 * @throws Exception
	 */
	public void scheduleOperation(Map<String, String> deviceOwnerIds , List<String> deviceIds, String operation) throws SQLException {
		mScheduleOperationAll(deviceOwnerIds, deviceIds, operation);
	}

	private void mScheduleOperation(String userId, String deviceId, String operation, Long schedularTicks) throws SQLException {
		InstallJobEngine job = new InstallJobEngine();
		
		 InstallJobVO jobVO = new InstallJobVO();
		jobVO.setAppId(Constant.EDGECORE_SYSTEM_UPDATE_APPNAME);
		jobVO.setAppVersion("");
		jobVO.setStatus(InstallJobStatusEnum.PENDING);
		jobVO.setLastModified(0);
		jobVO.setobjectId(deviceId);
		jobVO.setTimeStamp(schedularTicks);						
		jobVO.setType(TypeEnum.SystemUpdates);
		jobVO.setUserId(userId);
		jobVO.setInstalledJobId(Common.getRandomId());
		jobVO.setOperation(operation);

		job.addJob(jobVO);
	}

	private void mScheduleOperationAll(Map<String, String> deviceOwnerIds, List<String> listDevices, String operation) throws SQLException
	{
		long schedularTicks = 0;

		int batchSize = Constant.DEFAULT_BATCHSIZE;
		long interval = Constant.DEFAULT_INTERVAL;
		int serverCount = Constant.DEFALUT_SERVER_COUNT;
		if(buildFile(Constant.TIMERS).exists()){
			try{
				JSONParser parser = buildJsonParser();
				JSONObject obj = (JSONObject) parser.parse(buildFileReader());
				serverCount = Integer.parseInt(obj.get("serverCount").toString());

				batchSize = Integer.parseInt(obj.get("batchSize").toString()) * serverCount;
				interval = Long.parseLong(obj.get("interval").toString());
			}catch(Exception e){
				PALogger.ERROR(e);	
			}
		}else{
			batchSize = batchSize*serverCount;
		}

		int batchCount = 0;
		long intervalToAdd = 0;

		long currentTimestamp = new Date().getTime();
		for (String deviceId : listDevices) 
		{
			batchCount++;
			//			  schedule job for now()+ intervalToAdd
			schedularTicks = currentTimestamp + intervalToAdd;

			mScheduleOperation(deviceOwnerIds.get(deviceId), deviceId, operation, schedularTicks);

			if(batchCount % batchSize == 0)
			{
				currentTimestamp = new Date().getTime();
				intervalToAdd += interval;
			}
		}	

	}

	/**
	 * This method gives all applications using paging and 
	 * filters (category, sort, search text, start with, start end, etc.).	
	 * @param userId
	 * @param pageNo page number 
	 * @param pageSize number of applications in one page.
	 * @param filters (category, sort, search text, start with, start end, etc.).
	 * @param listUpdateVersions
	 * @param ownership
	 * @param authVo
	 * @return hash map of result with keys-> totalPages,  pageNo, pageSize , data.hashmap value of key "data" contains List<DeviceVO>
	 * @throws SQLException
	 */
	public Map<String, Object> listDeviceFilter(String userId,int pageNo, int pageSize, List<FilterObject> filters, boolean listUpdateVersions,OwnershipEnum ownership, AuthorizationsVO authVo) throws SQLException 
	{
		return mListDeviceFilter(userId, pageNo, pageSize, filters, listUpdateVersions,ownership,authVo);
	}

	public Map<String, Object> mListDeviceFilter(String userId,int pageNo, int pageSize, List<FilterObject> filters, boolean listUpdateVersions,OwnershipEnum ownership,AuthorizationsVO authVo) throws SQLException 
	{
		DevicesEngine devicesEngine =  new DevicesEngine();
		return devicesEngine.listDeviceFilter(userId, pageNo, pageSize, filters, listUpdateVersions,ownership,authVo);
	}

	/**
	 * Remove a nodeDevice added in cluster device.Add removed device entry as individual kubernetes device.
	 * @param nodeId node id of device  to be removed.
	 * @param deviceId  cluster id from which the node to be removed.
	 * @param userId user id.
	 * @throws Exception
	 */

	public void removeNodeFromCluster(String nodeId, String deviceId, String userId) throws Exception
	{
		mRemoveNodeFromCluster(nodeId, deviceId, userId);
	}

	private void mRemoveNodeFromCluster(String nodeId, String deviceId,  String userId) throws Exception
	{
		new DevicesEngine().removeNodeFromCluster(nodeId, deviceId, userId);
	}

	/**
	 * Add existing device to all the labels in labelIds.Firstly remove device from all existing labels then add with list of labels in parameters. 
	 * @param labelIds list of label ids.
	 * @param deviceId device id to be added in labels.
	 * @return true if successfully inserted false otherwise.
	 * @throws Exception
	 */
	public boolean addDeviceToLabels(List<String> labelIds, String deviceId) throws SQLException
	{
		return mAddDeviceToLabels(labelIds, deviceId);
	}

	private boolean mAddDeviceToLabels(List<String> labelIds, String deviceId) throws SQLException
	{
		return new DeviceLabelEngine().addDeviceToLabels(labelIds, deviceId);
	}

	public List<HashMap<String, String>> getCount() throws SQLException
	{
		return mGetCount();
	}
	private List<HashMap<String, String>> mGetCount() throws SQLException
	{
		return new DevicesEngine().getCount();
	}

	/**
	 * Update cluster active master state.Make the node as active master with id nodeId and make other as backup master. 
	 * @param nodeId
	 * @return
	 * @throws SQLException
	 */
	public boolean updateClusterActiveMaster(String nodeId) throws SQLException
	{
		return mUpdateClusterActiveMaster(nodeId);
	}
	/**
	 * This method return list of related groups of device
	 * @param deviceId : device id of requested device
	 * @return : List of groups
	 * @throws SQLException 
	 */
	public List<String> listGroupsOfDevice(String deviceId, List<String> groupIds) throws SQLException {
		return mListGroupsOfDevice(deviceId, groupIds);
	}

	private List<String> mListGroupsOfDevice(String deviceId, List<String> groupIds) throws SQLException {

		return new DevicesEngine().listGroupsOfDevice(deviceId, groupIds);
	}


	/**
	 * this method returns hashmap with deviceids and list of group in which that device is added
	 * @param deviceIds
	 * @return
	 * @throws SQLException
	 */
	public Map<String, List<String>>  listGroupsOfDevices(List<String> deviceIds) throws SQLException {
		return mListGroupsOfDevices( deviceIds);
	}
	private Map<String, List<String>>  mListGroupsOfDevices(List<String> deviceIds) throws SQLException 
	{
		return new DevicesEngine().listGroupsOfDevices(deviceIds);
	}
	

	private boolean mUpdateClusterActiveMaster(String nodeId) throws SQLException
	{
		return new DevicesEngine().updateClusterActiveMaster(nodeId);
	}
	/**
	 * Function checks whether cluster exists and also checks whether the relationship between cluster and node exists when cluster is available
	 * @param clusterId
	 * @param nodeId
	 * @author ps
	 * @throws Exception with error message containing {@link ErrorMessage} CLUSTER_NOT_FOUND when cluster with cluster id does not exists in database or DEVICE_NOT_FOUND when deviceId is not associated with cluster id 
	 */
	public void checkClusterNodeExsitance(String clusterId, String nodeId) throws Exception 
	{
		new DevicesEngine().checkClusterNodeExsitance(clusterId, nodeId);
	}

	/**
	 * Checks whether the any of device with specified id in List exist 
	 * @param deviceIds
	 * @author DB
	 * @throws Exception with error message containing {@link ErrorMessage} DEVICE_NOT_FOUND when entry in database with any of deviceId in list is found 
	 */

	public void checkDeviceExist(List<String> deviceIds) throws Exception 
	{
		new DevicesEngine().checkDeviceExists(deviceIds);

	}
	
	public FileReader buildFileReader() throws FileNotFoundException {
		return new FileReader(Constant.TIMERS);
	}


	public JSONParser buildJsonParser() {
		return new JSONParser();
	}


	public File buildFile(final String pathName) {
		return new File(pathName);
	}
}
