/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.framework;

import java.sql.SQLException;
import java.util.List;

import com.mwp.common.enums.ApplicationDefaultType;
import com.mwp.common.enums.DeviceTypeEnum;
import com.mwp.common.enums.Status;
import com.mwp.common.vo.DeviceNodeMasterVO;
import com.mwp.common.vo.DeviceVO;
import com.mwp.common.vo.PlatformVO;
import com.mwp.p.dal.engine.ApplicationTypeEngine;
import com.mwp.p.dal.engine.ClusterEngine;

/**
 * This class manages kubernetes clusters.Create new cluster from devices and can add devices to exiting cluster.  
 *
 */
public class Cluster
{	
	/**
	 * Create a cluster with the kubernetes devices.
	 * @param clusterName The name of cluster to be created.
	 * @param userId user Id.
	 * @param clusterId the cluster id saved on box. 
	 * @param platformActualName actual name of platform.  
	 * @param listProductId  HashMap<String, String> Role of device as Key( Master/Node) , mac Address as value.
	 * Note: one and only one device in list must have role as MASTER.  
	 * @return new cluster object as DeviceVO that contains DeviceNodeVO in nodes property. 
	 * @throws Exception 1. if cluster with same name already exists.
	 * 2. if platform with given name not found.
	 */
	public DeviceVO createCluster( String clusterName, String userId, String clusterId, String platformActualName,   List<DeviceNodeMasterVO> listProductId) throws Exception
	{
		return mCreateCluster(clusterName, userId, clusterId, platformActualName, listProductId);
	}

	private DeviceVO mCreateCluster(String clusterName, String userId, String clusterId, String platformActualName,   List<DeviceNodeMasterVO>  listProductId) throws Exception
	{
		if(new Devices().isDeviceNameAvailable(clusterName,  userId))
		{
			/*
			 * create object of cluster
			 */
			DeviceVO clusterDeviceVO =  new DeviceVO();
			clusterDeviceVO.setDeviceId(clusterId);//TODO check for unique id
			clusterDeviceVO.setUserId(userId);		
			clusterDeviceVO.setDeviceName(clusterName);
			clusterDeviceVO.setDeviceStatus(Status.ACTIVE);
			clusterDeviceVO.setActivationConfirmed(true);
			clusterDeviceVO.setDeviceType(DeviceTypeEnum.KubernetesCluster);
			clusterDeviceVO.setSwPlatformId(new ApplicationTypeEngine().getTypeId(ApplicationDefaultType.kubernetes));
			
			PlatformVO platFormVO = new Platform().getPlatForm(platformActualName);
			if(platFormVO == null){
				throw new Exception("Device "+ platformActualName +" platform not supported.");
			}else{
				clusterDeviceVO.setPlatformId(platFormVO.getPlatformId());
			}

			return new ClusterEngine().createCluster(clusterDeviceVO, listProductId);
		}
		else
			throw new Exception("cluser with name " + clusterName + " already exists");
	}

	/**
	 * Add a device to existing cluster.
	 * @param clusterId cluster id in which the device to be added  
	 * @param listProductId  List<DeviceNodeMasterVO>  Role of device  Master/Node) , mac Address, and State of master device.
	 * @throws SQLException
	 */
	public void addDevicesToCluster(String clusterId, List<DeviceNodeMasterVO>  listProductId) throws SQLException
	{
		/*
		 * create object of cluster
		 */
		DeviceVO clusterDeviceVO =  new DeviceVO();
		clusterDeviceVO.setDeviceId(clusterId);
		clusterDeviceVO.setDeviceStatus(Status.ACTIVE);
		clusterDeviceVO.setActivationConfirmed(true);
		clusterDeviceVO.setDeviceType(DeviceTypeEnum.KubernetesCluster);

		new ClusterEngine().addDevicesToCluster(clusterDeviceVO, listProductId);
	}

	public boolean updateClusterName(String clusterDeviceId, String clusterName) throws SQLException
	{
		return new ClusterEngine().updateClusterName(clusterDeviceId, clusterName);

	}

}
