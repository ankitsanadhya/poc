/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.framework;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import com.mwp.common.vo.CategoryVO;
import com.mwp.p.dal.engine.CategoriesEngine;

/**
 * This class manages Categories. add, update, list , delete categories.   
 * @author 
 *
 */
public class Categories {

	
	/**
	 * This method gives all Categories using paging.
	 * @param pageNo
	 * @param pageSize
	 * @param searchText
	 * @return
	 * @throws Exception
	 */
	public Map<String, Object> listCategories(int pageNo, int pageSize,
			String searchText) throws SQLException {
		return mListCategories(pageNo, pageSize, searchText);
	}

	/**
	 * This method gives all Categories using paging.
	 * @param pageNo
	 * @param pageSize
	 * @return
	 * @throws Exception
	 */
	public Map<String, Object> listCategories(int pageNo, int pageSize)
			throws SQLException {
		return listCategories(pageNo, pageSize, "");
	}

	/**
	 * This method gives list of category according to requested 'search text'."
	 * 
	 * @param searchText
	 * @return 
	 * @throws Exception
	 */
	public Map<String, Object> listCategories(String searchText)
			throws SQLException {
		return listCategories(1, 5, searchText);
	}

	/**
	 * Returns List of {@link CategoryVO}
	 * of default categories.
	 * 
	 * @return list of categoryVOs
	 * @throws Exception
	 */
	public List<CategoryVO> listDefaultCategories() throws SQLException {
		return mListDefaultCategories();
	}

	/**
	 * Returns {@link CategoryVO}
	 * according to requested categoryId.
	 * @param categoryId
	 * @return categoryVO of requested categoryId
	 * @throws Exception
	 */
	public CategoryVO getCategory(String categoryId) throws SQLException {
		return mGetCategory(categoryId);

	}

	/**
	 * Returns updated {@link CategoryVO}
	 * update category status/name which id specified in category object.
	 * @param categoryVO
	 * @return updated categoryVO
	 * @throws Exception
	 */
	public CategoryVO editCategory(CategoryVO categoryVO) throws Exception {
		return mEditCategory(categoryVO);

	}

	/**
	 * Remove category change status = 'SUSPENDED' in database.
	 * @param categoryId
	 * @throws Exception
	 */
	public void deleteCategory(String categoryId) throws SQLException {
		mDeleteCategory(categoryId);

	}

	/**
	 * This method add category in category database.
	 * @param categoryVO
	 * @return
	 * @throws Exception
	 */
	public CategoryVO addCategory(CategoryVO categoryVO) throws SQLException {
		return mAddCategory(categoryVO);

	}

	

	private Map<String, Object> mListCategories(int pageNo, int pageSize,
			String searchText) throws SQLException {
		CategoriesEngine categoriesEngine = new CategoriesEngine();
		return categoriesEngine.searchCategories(pageNo, pageSize, searchText);
	}

	private CategoryVO mGetCategory(String categoryId) throws SQLException {
		CategoriesEngine categoriesEngine = new CategoriesEngine();
		return categoriesEngine.getCategory(categoryId);
	}

	private CategoryVO mEditCategory(CategoryVO categoryVO) throws Exception {
		CategoriesEngine categoriesEngine = new CategoriesEngine();
		return categoriesEngine.editCategory(categoryVO);
	}

	private void mDeleteCategory(String categoryId) throws SQLException {
		CategoriesEngine categoriesEngine = new CategoriesEngine();
		categoriesEngine.deleteCategory(categoryId);
	}

	private CategoryVO mAddCategory(CategoryVO categoryVO) throws SQLException {
		CategoriesEngine categoriesEngine = new CategoriesEngine();
		return categoriesEngine.addCategory(categoryVO);
	}

	private List<CategoryVO> mListDefaultCategories() throws SQLException {
		CategoriesEngine categoriesEngine = new CategoriesEngine();
		return categoriesEngine.listDefaultCategory();
	}

}
