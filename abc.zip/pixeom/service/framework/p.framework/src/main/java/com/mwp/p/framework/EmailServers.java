/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.framework;

import java.sql.SQLException;
import java.util.List;

import com.mwp.common.CredProvider;
import com.mwp.common.vo.EmailServersVO;
import com.mwp.p.dal.engine.EmailServerEngine;
import com.pa.crypto.StringEncryptionDecryption;

/**
 * this class access data from email server table
 * @author root
 *
 */
public class EmailServers 
{

	/**
	 * method to get email server
	 * @return  {@link EmailServersVO}
	 * @throws SQLException 
	 */
	public EmailServersVO getEmailServer() throws SQLException
	{
		return mgetEmailServer();
	}
	/**
	 * list all email servers 
	 * @return
	 * @throws SQLException
	 */
	public List<EmailServersVO> listsAll(boolean toDecryptResult) throws SQLException
	{
		return mListsAll(toDecryptResult);
	}

	public List<EmailServersVO> listsAllOrderByPriority() throws SQLException
	{
		return mListsAllOrderByPriority();
	}
	/**
	 * insert in email server
	 * @param relayServerVo
	 * @return
	 * @throws Exception 
	 */
	public  EmailServersVO insert(EmailServersVO emailServerVo) throws Exception 
	{
		return mInsert(emailServerVo);
	}
	
	/**
	 * update in email server
	 * @param relayServerVo
	 * @return
	 * @throws SQLException
	 */
	public  EmailServersVO update(EmailServersVO emailServerVo) throws SQLException 
	{
		return mUpdate(emailServerVo);
	}

	/**
	 * delete email server
	 * @param sRelayServerId
	 * @throws SQLException
	 */
	public  void delete(String serverId) throws SQLException 
	{
		mDelete(serverId);
	}
	private EmailServersVO mgetEmailServer() throws SQLException
	{
		EmailServerEngine emailServerEng= new EmailServerEngine();
		return emailServerEng.getEmailServer();
	}
	
	private List<EmailServersVO> mListsAll(boolean toDecryptResult) throws SQLException
	{
		EmailServerEngine engg = new EmailServerEngine();
		return engg.listsAll(toDecryptResult);
	}
	
	private List<EmailServersVO> mListsAllOrderByPriority() throws SQLException
	{
		EmailServerEngine engg = new EmailServerEngine();
		return engg.listsAllOrderByPriority();
	}

	/**
	 * insert in email server
	 * @param relayServerVo
	 * @return
	 * @throws Exception 
	 */
	private  EmailServersVO mInsert(EmailServersVO relayServerVo) throws Exception 
	{
		String key = buildCredProvider().getEcnKey();
		EmailServerEngine engg = new EmailServerEngine();
		return engg.insert(relayServerVo.getServerId(), relayServerVo.getServerAddress(), relayServerVo.getServerName(), relayServerVo.getStatus(), StringEncryptionDecryption.encrypt(relayServerVo.getUsername(),key),  StringEncryptionDecryption.encrypt(relayServerVo.getPassword(),key), relayServerVo.getPort(), relayServerVo.getPriority(), relayServerVo.getisTLS());
	}
	
	public CredProvider buildCredProvider() {
		return new CredProvider();
	}
	
	/**
	 * update in email server
	 * @param relayServerVo
	 * @return
	 * @throws SQLException
	 */
	private  EmailServersVO mUpdate(EmailServersVO relayServerVo) throws SQLException 
	{
		String key = buildCredProvider().getEcnKey();
		EmailServerEngine engg = new EmailServerEngine();
		return engg.update(relayServerVo.getServerId(), relayServerVo.getServerAddress(), relayServerVo.getServerName(), relayServerVo.getStatus(),  StringEncryptionDecryption.encrypt(relayServerVo.getUsername(),key),  StringEncryptionDecryption.encrypt(relayServerVo.getPassword(),key), relayServerVo.getPort(), relayServerVo.getPriority(), relayServerVo.getisTLS());
	}
	
	private  void mDelete(String serverId) throws SQLException 
	{
		EmailServerEngine engg = new EmailServerEngine();
		 engg.delete(serverId);
	}
	
}
