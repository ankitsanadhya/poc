/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.framework;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;

import com.mwp.common.Common;
import com.mwp.common.CredProvider;
import com.mwp.common.ImageThumbCreater;
import com.mwp.common.TempFiles;
import com.mwp.common.constant.Constant;
import com.mwp.common.vo.AppResourceVO;
import com.mwp.logger.PALogger;
import com.mwp.p.common.Constants;
import com.mwp.p.common.PortalCommon;
import com.pa.crypto.FileEncryptionDecryption;

/**
 * This class provide functionality
 *
 */
public class PortalFileUpload {

	String image = "img";
	String thumb = "thumb";
	

	/**
	 * Create base path for portal data cache  
	 * @param folderName
	 * @param uniqueId
	 * @return "/data/PortalCache/folderName/uniqueId/"
	 */
	public String getBasePath(String folderName, String uniqueId){
		String basePath = Constants.PORTAL_CACHE_PATH + folderName + Constant.localFileSeparator  + uniqueId + Constant.localFileSeparator;
		createDirPath(basePath);
		return basePath;
	}

	/**
	 * Write the input stream to a file
	 * @param inuptStream
	 * @param tempPath
	 * @return
	 * @throws IOException
	 */
	public String inputStreamToFile(InputStream inuptStream,String tempPath) throws IOException 
	{
		String filename = null;

		byte[] bufarr=buildIOUtilsToByteArray(inuptStream);
		filename = tempPath; 
		final File tempFile = buildFile(filename);
		try {

			FileUtils.writeByteArrayToFile(tempFile, bufarr);

		} catch (IOException e) 
		{

			PALogger.ERROR(e);
		}
		return tempFile.getAbsolutePath();
	}

	public void uploadAppResources(List<AppResourceVO> resourceVOs, Map<String, String> inputstreamHash) throws IOException {
		for (AppResourceVO appResourceVO : resourceVOs) {
			String tempFilePath = inputstreamHash.get(appResourceVO.getFieldName());

			File tempFile = buildFile(tempFilePath);
			FileInputStream inputstream = buildFileInputStream(tempFile);

			File file = buildFile(appResourceVO.getFilePath()).getParentFile();
			if(!file.exists()) {
				file.mkdirs();
			}

			uploadFile(inputstream, tempFile.getName() + Constant.localFileSeparator, file.getPath() + Constant.localFileSeparator, appResourceVO.isEncrypted(), tempFilePath);
		}
	}

	/**
	 * Upload attachment to path synchronously
	 * @param inputStreaHash
	 * @param uploadPath
	 * @param doencyption
	 * @param isThumbReq
	 * @return
	 * @throws Exception
	 */
	public Map<String,Object> uploadAttachmentInline(Map<String, String> inputStreaHash,String uploadPath,boolean doencyption,boolean isThumbReq) throws Exception
	{
		String shareUrl="";
		String imageUploadPath="";
		String thumbShareUrl="";
		String thumbPath = "";
		FileInputStream inputstreamthumb = null;
		Map<String,Object> param = new HashMap<>();
		Set<String> strkey = inputStreaHash.keySet();
		for(String fileName : strkey) {
			String tmpFileValue = inputStreaHash.get(fileName);
			FileInputStream inputstream = buildFileInputStream(buildFile(tmpFileValue));

			imageUploadPath = uploadPath + fileName;
			if(isThumbReq){
				inputstreamthumb = buildFileInputStream(buildFile(tmpFileValue));
				thumbPath = getImagePath(true, uploadPath);
			}
			uploadFileInline(inputstream,inputstreamthumb, fileName, doencyption, uploadPath, thumbPath,tmpFileValue);

			shareUrl = PortalCommon.getInstance().createPublicUrl(imageUploadPath, Constants.UI_FOLDER_NAME);

			param.put("imagePath", imageUploadPath);
			param.put("shareUrl", shareUrl);
			param.put("thumbShareUrl", thumbShareUrl);
		}
		return param;
	}

	private void uploadFileInline(InputStream inputStream,InputStream thumbInputStream, String fileName, boolean doEncryption, String uploadPath, String thumbPath,String  sourcePath) throws Exception{
		uploadFile(inputStream, fileName, uploadPath, doEncryption,sourcePath);
		if(thumbInputStream != null){
			if(!Common.isSpecialFormatImageFile(fileName)){
				String temppath = TempFiles.getTempFolderPath();
				String filepath = temppath+fileName;
				filepath = inputStreamToFile(thumbInputStream, filepath);
				String fileThumbnPath =  temppath+"thumb"+fileName;
				fileThumbnPath = ImageThumbCreater.createThumbnail(filepath, fileThumbnPath);

				InputStream newThumbStream = buildFileInputStream(buildFile(fileThumbnPath));
				uploadFile(newThumbStream, fileName, thumbPath, doEncryption,sourcePath);
			}else{
				uploadFile(thumbInputStream, fileName, thumbPath, doEncryption,sourcePath);
			}
		}
	}

	private String uploadFile(InputStream inputStream, String fileName,String uploadPath, boolean doEncryption,String sourcePath) throws IOException
	{
		InputStream in = null;
		try
		{
			if(doEncryption)
			{
				FileEncryptionDecryption.Encrypt_File(sourcePath, uploadPath + fileName, buildCredProvider().getEcnKey());
				FileUtils.deleteQuietly(buildFile(sourcePath));
			}
			else
			{
				in = inputStream;
				java.nio.file.Path destination = Paths.get(uploadPath + fileName);
				buildFilesCopy(in, destination);
			}
		return "Successful";
		}finally{
			try {
				if(in != null)
					in.close();
			} catch (IOException e) {
				PALogger.ERROR(e);	
			}
		}
	}

	private String getImagePath(boolean isThumbImage, String basePath)
	{
		String localvalue = null;
		if(isThumbImage)
			localvalue = basePath + thumb + Constant.localFileSeparator;
		else
			localvalue = basePath + image + Constant.localFileSeparator;
		return localvalue;
	}

	private void createDirPath(String basePath){
		File folder=buildFile(basePath);
		if (!folder.exists())
			folder.mkdirs();
	}
	
	/**
	 * This method copy file.
	 * @param source which file wants to copy
	 * @param dest where to paste file.
	 * @throws IOException
	 */
	public void copyFile(File source, File dest) throws IOException {
	    buildFilesCopyPath(source, dest);
	}

	public Path buildFilesCopyPath(File source, File dest) throws IOException {
		return Files.copy(source.toPath(), dest.toPath(), StandardCopyOption.REPLACE_EXISTING);
	}

	public File buildFile(String filename) {
		return new File(filename);
	}
	public FileInputStream buildFileInputStream(File tempFile) throws FileNotFoundException {
		return new FileInputStream(tempFile);
	}
	public long buildFilesCopy(InputStream in, java.nio.file.Path destination) throws IOException {
		return Files.copy(in,  destination, StandardCopyOption.REPLACE_EXISTING);
	}
	
	public byte[] buildIOUtilsToByteArray(InputStream inuptStream) throws IOException {
		return IOUtils.toByteArray(inuptStream);
	}
	
	public CredProvider buildCredProvider() {
		return new CredProvider();
	}
}
