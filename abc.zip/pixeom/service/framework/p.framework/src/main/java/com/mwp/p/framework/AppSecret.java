/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.mwp.p.framework;

import java.sql.SQLException;
import java.util.List;

import com.mwp.common.StringFunctions;
import com.mwp.common.enums.SecretTypeEnum;
import com.mwp.common.yamlparser.SecretVersionVO;
import com.mwp.common.yamlparser.SecretVo;
import com.mwp.p.dal.engine.AppSecretEngine;

public class AppSecret
{
	public SecretVo insert(SecretVo secretObj, boolean isAddSecretVO)throws Exception
	{
		return mInsert(secretObj, isAddSecretVO);
	}
	
	public SecretVo edit(SecretVo secretObj,boolean toUploadFile)throws Exception
	{
		return mEdit(secretObj, toUploadFile);
	}
	
	public boolean delete(String appSecertId)throws SQLException
	{
		return mDelete(appSecertId);
	}
	
	/*
	 * Add method for delteAppSecretVersion using appSecretVersionId.
	 */
	public boolean deleteAppSecretVersion(String appSecertVersionId)throws SQLException
	{
		return mDeleteAppSecretVersion(appSecertVersionId);
	}
	
	public List<SecretVo> listByAppId(String appId)throws SQLException
	{
		return mListByAppId(appId);
	}
	public SecretVo get(String appSecretId) throws SQLException
	{
		return mGet(appSecretId);
	}
	
	public String getFileUploadPath(String appId,String appSecretId)
	{
		return "/data/files/app/secrets/" +appId + "/" + appSecretId + "/";
	}
	private SecretVo mInsert(SecretVo secretObj, boolean isAddSecretVO)throws Exception
	{
		for (SecretVersionVO svo : secretObj.getListSecretVersion()) {
			String path= getFileUploadPath(secretObj.getAppId(), svo.getAppSecretVersionId()) + svo.getFileName();
			if(svo.getType().name().equals(SecretTypeEnum.file.name()))
				svo.setValue(path);
		}

		SecretVo returnObj =new AppSecretEngine().insert(secretObj, isAddSecretVO);
		return returnObj;
	}
	
	private SecretVo mEdit(SecretVo secretObj, boolean toUploadFile)throws Exception
	{
		if(secretObj.getListSecretVersion().get(0).getType().name().equals(SecretTypeEnum.file.name()) && toUploadFile)
		{
			for (SecretVersionVO svo : secretObj.getListSecretVersion()) {
				String path= getFileUploadPath(secretObj.getAppId(), svo.getAppSecretVersionId())+ svo.getFileName();
				svo.setValue(path);
			}
		}
		SecretVo returnObj =new AppSecretEngine().edit(secretObj);
		return returnObj;
	}
	
	private boolean mDelete(String appSecertId)throws SQLException
	{
		return new AppSecretEngine().delete(appSecertId);
	}
	
	private boolean mDeleteAppSecretVersion(String appSecretVersionId)throws SQLException
	{
		AppSecretEngine secretEngg= new AppSecretEngine();
		String appSecretID = secretEngg.getAppSecretIdIfLastVersion(appSecretVersionId);
		if(StringFunctions.isNullOrWhitespace(appSecretID))
			return new AppSecretEngine().deleteAppSecretVersion(appSecretVersionId);
		else
			return new AppSecretEngine().delete(appSecretID);
	}
	
	private List<SecretVo> mListByAppId(String appId)throws SQLException
	{
		return new AppSecretEngine().listByAppId(appId);
	}
	private SecretVo mGet(String appSecretId) throws SQLException
	{
		return new AppSecretEngine().get(appSecretId);
	}
	
}
