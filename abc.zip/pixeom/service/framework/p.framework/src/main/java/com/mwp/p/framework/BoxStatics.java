/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.framework;

import java.sql.SQLException;

import com.mwp.p.dal.engine.BoxStaticsEngine;

/**
 * Manages box Statistics for device.List and add statistics for a device.
 *
 */
public class BoxStatics {
	
	/**
	 * Add box statistics for a device.  
	 * @param deviceId
	 * @param statics statistics object.
	 * @throws SQLException
	 */
	public void insert(String deviceId, String statics) throws SQLException{
		mInsert(deviceId, statics);
	}
	
	private void mInsert(String deviceId, String statics) throws SQLException{
		BoxStaticsEngine boxStaticsEngine = new BoxStaticsEngine();
		boxStaticsEngine.addStatics(deviceId, statics);
	}
	
	/**
	 * List statistics for given device id. 
	 * @param deviceId
	 * @return Hashmap of modified date as key and statistics text as value. 
	 * @throws SQLException
	 */
	public Object list(String deviceId) throws SQLException{
		return mList(deviceId);
	}
	
	private Object mList(String deviceId) throws SQLException{
		BoxStaticsEngine boxStaticsEngine = new BoxStaticsEngine();
		return boxStaticsEngine.getBoxStatics(deviceId);
	}
}
