/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.framework.docker;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.core.MediaType;

import org.apache.http.Header;

import com.google.gson.Gson;
import com.mwp.common.Client;
import com.mwp.common.StringFunctions;
import com.mwp.common.constant.Constant;
import com.mwp.p.common.Constants;
import com.mwp.p.common.vo.LayerVO;

public class RegistryClient {
	private String registryPath;
	private String authorizationHeader;
	/**
	 * @param registryPath Path of registry server
	 * @param authorizationHeader Value of authorization key
	 */
	public RegistryClient(String registryPath) {
		this.registryPath = registryPath;
	}

	/**
	 * This method return all repository in json list, sorted order available in the registry.
	 * @throws Exception 
	 */
	public String getAllRepositories(){
		try
		{
			return Client.callServer(registryPath, "v2", "_catalog", "GET", "", null, null, authorizationHeader);
		}
		catch(Exception ex)
		{
			return getAllRepositories();
		}

	}

	/**
	 * This method return all repository in json list, sorted order available in the registry.
	 * impose a maximum limit and return specified portion of repositories
	 * @param noOfEntity Limit the number of entries in each response.
	 * @param nextMarker Marker value from previous response.
	 * @throws IOException 
	 * @throws KeyStoreException 
	 * @throws NoSuchAlgorithmException 
	 * @throws KeyManagementException 
	 * @throws Exception 
	 */
	public String getAllRepositories(int noOfEntity, String lastRepoName) throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException, IOException  {
		Map<Object, Object> queryParam = new HashMap<>();
		queryParam.put("n", noOfEntity);
		queryParam.put("last", lastRepoName);

		return Client.callServer(registryPath, "v2", "_catalog", "GET", "", queryParam, null, authorizationHeader);

	}

	


	/**
	 * Get info of required repository
	 * @param imagePath Combination of application and image name i.e libray/ubuntu
	 * @param version Version of image also known as tag i.e. latest/1.0.0.1
	 * @throws Exception 
	 */
	public String getManifestInfo(String imagePath, String version, String portalAuth) throws Exception {
		HashMap<String, Object> responseHeader = new HashMap<>();
		HashMap<String, String> headers = new HashMap<>();
		headers.put("Authorization", authorizationHeader);
		headers.put("Accept", "application/vnd.docker.distribution.manifest.v2+json");

		try
		{
			return Client.callServer(registryPath, "v2", imagePath, "GET", "manifests/" + version, null, null, headers, MediaType.APPLICATION_JSON_TYPE, responseHeader,0,0,0);

		}
		catch(Exception ex)
		{
			if(getAuthenticationFromHeaders(responseHeader, portalAuth))
			{
				headers.put("Authorization", authorizationHeader);
				headers.put("Accept", "application/vnd.docker.distribution.manifest.v2+json");
				return Client.callServer(registryPath, "v2", imagePath, "GET", "manifests/"+version, null, null, headers, MediaType.APPLICATION_JSON_TYPE, responseHeader,0,0,0);
			}
			else
			{
				throw ex;
			}
		}
	}

	/**
	 * This method returns all version
	 * @param imagePath Combination of application and image name i.e libray/ubuntu
	 * @throws IOException 
	 * @throws KeyStoreException 
	 * @throws NoSuchAlgorithmException 
	 * @throws KeyManagementException 
	 * @throws Exception 
	 */
	public String getVersions(String imagePath) throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException, IOException  {
		return Client.callServer(registryPath, "v2", imagePath, "GET", "tags/list", null, null, authorizationHeader);
	}

	/**
	 * This method get the next result set, a client would issue the request as follows, limiting the number of results to noOfEntity and marker value from previous response.
	 * @param imagePath Combination of application and image name i.e libray/ubuntu
	 * @param aNoOfEntity Limiting the number of results to 'noOfEntity'.
	 * @param aNextMarker Marker value from previous response.
	 * @throws IOException 
	 * @throws KeyStoreException 
	 * @throws NoSuchAlgorithmException 
	 * @throws KeyManagementException 
	 */
	public String getVersions(String imagePath, int noOfEntity, String lastRepoName) throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException, IOException {

		Map<Object, Object> queryParam = new HashMap<>();
		queryParam.put("n", noOfEntity);
		queryParam.put("last", lastRepoName);

		return Client.callServer(registryPath, "v2", imagePath, "GET", "tags/list", queryParam, null, authorizationHeader);
	}
	
	
	/**
	 * This method push the lauer on clair servier
	 * @param imagePath Combination of application and image name i.e libray/ubuntu
	 * @param aNoOfEntity Limiting the number of results to 'noOfEntity'.
	 * @param aNextMarker Marker value from previous response.
	 * @throws IOException 
	 * @throws KeyStoreException 
	 * @throws NoSuchAlgorithmException 
	 * @throws KeyManagementException 
	 */
	public String pushLayer(LayerVO layer) throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException, IOException  {
		//ADD GET AUTHANTICATION ON FAILIER
		HashMap<String, String> headers = new HashMap<>();
		headers.put("Authorization", authorizationHeader);
		layer.setHeaders(headers);
		
		HashMap<String, LayerVO> requestBody = new HashMap<>();
		requestBody.put("Layer", layer);
		ClairClient clairclient = new ClairClient();
		return clairclient.pushLayer(new Gson().toJson(requestBody));//handle case if failed
	}
	
	
	

	/**
	 * This method delete image from the registry.
	 * @param imagePath Combination of application and image name i.e libray/ubuntu
	 * @param version Version of image also known as tag i.e. latest/1.0.0.1.
	 * @throws IOException 
	 * @throws KeyStoreException 
	 * @throws NoSuchAlgorithmException 
	 * @throws KeyManagementException 
	 * @throws Exception 
	 */
	public String deleteImage(String imagePath ,String version) throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException, IOException  {
		return mDeleteImage(imagePath,version);
	}

	private String mDeleteImage(String imagePath,String version) throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException, IOException   {

		HashMap<String, Object> resultHeaders = new HashMap<>();

		HashMap<String, String> requestHeaders = new HashMap<>();
		requestHeaders.put("Authorization", authorizationHeader);
		requestHeaders.put("Accept", "application/vnd.docker.distribution.manifest.v2+json");

		Client.callServer(registryPath, "v2", imagePath, "GET", "manifests/" + version, null, null, requestHeaders, MediaType.APPLICATION_JSON_TYPE, resultHeaders,0,0,0);

		if(resultHeaders.containsKey("Headers")) {
			Header[] header = (Header[]) resultHeaders.get("Headers");
			String digest = "";
			for (Header headers : header) {
				if(headers.getName().equals("Docker-Content-Digest")) {
					digest = headers.getValue();
					break;
				}
			}

			Client.callServer(registryPath, "v2", imagePath, "DELETE", "manifests/" + digest, null, null, authorizationHeader);
		}
		return null;
	}


	
/**
 * 
 * @param responseHeader
 * @param auth: authentication of portal when getting authentication of private registry else empty.
 * @return
 * @throws IOException 
 * @throws KeyStoreException 
 * @throws NoSuchAlgorithmException 
 * @throws KeyManagementException 
 * @throws Exception
 */
	private boolean getAuthenticationFromHeaders(Map<String, Object> responseHeader,String portalAuth) throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException, IOException
	{
		boolean returnVal = false;
		if(responseHeader.containsKey("Headers") && responseHeader.get("Headers") != null)
		{
			Header[] header = (Header[]) responseHeader.get("Headers");

			/*Key : Server ,Value : nginx
			Key : Date ,Value : Tue, 02 Jan 2018 12:38:41 GMT
			Key : Content-Type ,Value : application/json; charset=utf-8
			Key : Content-Length ,Value : 146
			Key : Connection ,Value : keep-alive
			Key : Docker-Distribution-Api-Version ,Value : registry/2.0
			Key : Www-Authenticate ,Value : Bearer realm="https://portaldev.pixeom.net/p.service/api/token",service="Pixeom Docker Registry",scope="repository:library/ubuntu:pull"
			Key : Docker-Distribution-Api-Version ,Value : registry/2.0
			 */

			String authheader="";
			for (Header h : header) {
				if(h.getName().equals("Www-Authenticate"))
				{
					authheader = h.getValue() ;
					break;
				}		
			}

			if(!StringFunctions.isNullOrWhitespace(authheader))
			{
				String ipport = "";
				String serviceName ="";
				Map<Object, Object> queryparam =  new HashMap<>();
			
				String[] authvalue = authheader.split(",");

				for (int i = 0; i < authvalue.length; i++) {

					String[] splitedVal =  authvalue[i].split("=");

					String splitedstr = splitedVal[1];

					splitedstr = splitedstr.substring(splitedstr.indexOf('\"') + 1, splitedstr.lastIndexOf('\"'));
					if(i==0)
					{
						splitedstr = splitedstr.endsWith("/") ? splitedstr.substring(0,splitedstr.lastIndexOf("/")) : splitedstr;
						serviceName = splitedstr.substring(splitedstr.lastIndexOf("/") + 1);
						ipport = splitedstr.substring(0,splitedstr.lastIndexOf("/"));

					}
					else
					{
						queryparam.put(splitedVal[0],splitedstr);
					}
				}

			
				
					String responce;
					responce = Client.callServer(ipport, serviceName, "", "GET", "", queryparam, null, ipport.contains(Constants.PORTAL_SERVICE_NAME) ? portalAuth : "");
					Map<String, String> val = Client.getGson().fromJson(responce,Map.class);
					if(val.containsKey("token"))
					{
						authorizationHeader = Constant.BEARER + val.get("token");
						returnVal = true;
					}
				
			}

		}
		
		return returnVal;
	}





}