/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.mwp.p.utility;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.google.gson.Gson;
import com.google.gson.internal.LinkedTreeMap;
import com.mwp.common.Common;
import com.mwp.common.enums.RuleServerType;
import com.mwp.common.enums.RuleType;
import com.mwp.common.vo.RuleVO;
import com.mwp.logger.PALogger;
import com.mwp.p.framework.Rule;

public class RuleMoniterService {

	public void moniterRule(){
		Rule rule = new Rule();
		try {
			List<RuleVO> relayRules = rule.listsAll();
			for (RuleVO ruleVO : relayRules) {

				switch (ruleVO.getRuleType()) {
				case relay:
					MoniterRelayServer mrs = new MoniterRelayServer();
					LinkedTreeMap<String, Object> ht = new LinkedTreeMap<>();
					Gson json = new Gson();
					ht=json.fromJson(ruleVO.getRuleValue(), ht.getClass());
					int compareValue= Integer.parseInt(ht.get("ruleValue").toString());
					int maxrelay= Integer.parseInt(ht.get("maxRelay").toString());
					mrs.moniterRelay(compareValue,maxrelay,ruleVO.getServerType(),ruleVO.getRuleId(), false);//test the bit 
					break;
				case storage:      
					StorageMonitorService storagemonitorservice=new StorageMonitorService();
					LinkedTreeMap<String, Object> htStorage= new LinkedTreeMap<>();				
					ht=new Gson().fromJson(ruleVO.getRuleValue(), htStorage.getClass());
					int compareStorageValue= Integer.parseInt(ht.get("ruleValue").toString());					
					int diskIncreaseSize= Integer.parseInt(ht.get("diskIncreaseSize").toString());
					int maxDiskSize= Integer.parseInt((ht.get("maxDiskSize").toString()));					
					
					storagemonitorservice.monitorStorageService(compareStorageValue,ruleVO.getRuleId(),diskIncreaseSize,maxDiskSize);
					break;
				default:
					break;
				}
			}
		} catch (SQLException e) {

			PALogger.ERROR(e);
		}
	}
}
