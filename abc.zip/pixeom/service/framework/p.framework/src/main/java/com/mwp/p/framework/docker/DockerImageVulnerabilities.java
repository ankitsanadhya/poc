/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.framework.docker;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

import com.google.gson.Gson;
import com.mwp.logger.PALogger;
import com.mwp.p.common.vo.LayerFeatureVO;
import com.mwp.p.common.vo.LayerVO;
import com.mwp.p.common.vo.ManifestImage;
import com.mwp.p.common.vo.ManifestVO;
import com.mwp.p.common.vo.VulnerabilitiesVO;
import com.mwp.p.common.vo.LayerFeatureParentObject;

public class DockerImageVulnerabilities {


	public String checkImageVulnerabilities(String imagePath , String authtoken,String imageTag ) throws Exception {
		return mCheckImageVulnerabilities(imagePath, authtoken ,imageTag);
	}

	private String mCheckImageVulnerabilities(String imagePath , String authtoken,String imageTag) throws Exception {

		String registrypPath = imagePath.substring(0,imagePath.indexOf("/"));
		registrypPath = (registrypPath.equals("docker.io")) ? "registry-1." + registrypPath : registrypPath;

		imagePath = imagePath.substring(imagePath.indexOf("/") + 1);
		imagePath  =  imagePath.endsWith("/") ? imagePath.substring(0,imagePath.lastIndexOf("/")) : imagePath;
		Gson jsonobj = new Gson();

		String format= "Docker";
		int layerCount ;

		RegistryClient registryClient = new  RegistryClient(registrypPath);//, Constant.BEARER + token

		PALogger.INFO("++++++++++++++++++++++++++++Requesting ON registryClient for GetManifestInfo+++++++++++++++++++++++++++++");
		
		String returnval = registryClient.getManifestInfo(imagePath, imageTag,authtoken);
		PALogger.INFO("++++++++++++++++++++++++++++Reques DONE ON registryClient for GetManifestInfo+++++++++++++++++++++++++++++");


		ManifestImage manifestimage ;
		manifestimage = jsonobj.fromJson(returnval, ManifestImage.class);

		PALogger.INFO("++++++++++++++++++++++++++++Manifest FsLayers+++++++++++++++++++++++++++++");
		PALogger.INFO(manifestimage.getManifests().toString());
		PALogger.INFO("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");

		String parent = "";
		ClairClient clairclient = new ClairClient();
		String platformserver = registrypPath.startsWith("http") ? registrypPath : (registrypPath.startsWith("localhost") ? ("http://"+registrypPath) : ("https://" + registrypPath));
		platformserver = platformserver.endsWith("/")?platformserver:(platformserver+"/");
		layerCount = manifestimage.getManifests().size();
		for (int i = manifestimage.getManifests().size() -1; i >=0 ; i--) 
		{
			ManifestVO layer = manifestimage.getManifests().get(i);
			String layername = layer.getDigest().split(":")[1];

			PALogger.INFO("++++++++++++++++++++++++++++Requeing ON clairclient for Layer : " + layername + "+++++++++++++++++++++++++++++");
			PALogger.INFO("++++++++++++++++++++++++++++Requesing ON clairclient for ParentLayer : " + parent + "+++++++++++++++++++++++++++++");


			LayerVO layervo  = new LayerVO();
			layervo.setName(layername);

			/*
			 * https://portaldevhub.pixeom.net/v2/5a33c5a8fee80/hello-node/blobs/sha256:a3ed95caeb02ffe68cdd9fd84406680ae93d633cb16422d00e8a7c22955b46d4
			 */				

			layervo.setPath(platformserver + "v2/" + imagePath + "/blobs/" + layer.getDigest());
			PALogger.INFO("++++++++++++++ Layer Registery Path : " + layervo.getPath() + "+++++++++++++++++++++++++++++");

			
			layervo.setParent(parent);
			layervo.setFormat(format);


			
			try
			{
				String returnobj = registryClient.pushLayer(layervo);



				PALogger.INFO("++++++++++++++ Layer Registery Responce FOR : " + layervo.getPath() + "+++++++++++++++++++++++++++++");
				PALogger.INFO(returnobj);
				PALogger.INFO("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");


			} catch (Exception e) {
				PALogger.ERROR(e);	
			}


			parent = layername;
		}

		String layerName = manifestimage.getManifests().get(0).getDigest().split(":")[1];
		PALogger.INFO("++++++++++++++ Layer Name To Analyze : " + layerName + "+++++++++++++++++++++++++++++");
		String returnobj = clairclient.analyzeLayer(layerName);


		LayerFeatureParentObject  layerobj = jsonobj.fromJson(returnobj, LayerFeatureParentObject.class);


		LinkedHashMap<String, List<VulnerabilitiesVO>> vulnerabilities = new LinkedHashMap<>();
		vulnerabilities.put("Defcon1", new ArrayList<>());
		vulnerabilities.put("Critical", new ArrayList<>());
		vulnerabilities.put("High", new ArrayList<>());
		vulnerabilities.put("Medium", new ArrayList<>());
		vulnerabilities.put("Low", new ArrayList<>());
		vulnerabilities.put("Negligible", new ArrayList<>());
		vulnerabilities.put("Unknown", new ArrayList<>());

		//"Unknown", "Negligible", "Low", "Medium", "High", "Critical", "Defcon1"
		for (LayerFeatureVO feature : layerobj.getLayer().getFeatures()) {

			List<VulnerabilitiesVO> vulnerability = feature.getVulnerabilities();
			if(vulnerability != null)
			{
				for (VulnerabilitiesVO v : vulnerability) {

					if(vulnerabilities.containsKey(v.getSeverity()))
					{
						vulnerabilities.get(v.getSeverity()).add(v);
					}

				}

			}

		}


		PALogger.INFO("++++++++++++++ Layer Registery Responce FOR : " + layerName + "+++++++++++++++++++++++++++++");
		PALogger.INFO(vulnerabilities.toString());
		PALogger.INFO("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");

		HashMap<String, Object> returnHashmap = new HashMap<>();
		returnHashmap.put("LayerCount", layerCount);
		
		returnHashmap.put("Vulnerabilities", vulnerabilities);
		return jsonobj.toJson(returnHashmap);

		
	}

	
}
