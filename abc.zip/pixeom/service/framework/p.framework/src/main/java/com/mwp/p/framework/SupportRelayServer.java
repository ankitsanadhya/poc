/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.framework;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.google.gson.Gson;
import com.mwp.common.CredProvider;
import com.mwp.common.Mailer;
import com.mwp.common.StringFunctions;
import com.mwp.common.constant.Constant;
import com.mwp.common.enums.TokenEnum.TOKENSTATUS;
import com.mwp.common.vo.DeviceVO;
import com.mwp.common.vo.EmailServersVO;
import com.mwp.common.vo.TokenVO;
import com.mwp.logger.PALogger;
import com.mwp.p.common.Constants;
import com.mwp.p.common.vo.LockRelayPortsVO;
import com.mwp.p.common.vo.RelayServerVO;
import com.mwp.p.common.vo.SupportAssignedRelayPortsVO;
import com.mwp.p.dal.engine.DevicesEngine;
import com.mwp.p.dal.engine.SupportRelayServerEngine;
import com.mwp.p.dal.engine.TokenEngine;
import com.pa.crypto.StringEncryptionDecryption;

public class SupportRelayServer {

	private int portSegmentSize = 1;


	public Map<String, Object> setupSupportRelay(String hostName, String email , String token, boolean callByAdmin) throws SQLException
	{
		Map<String, Object> hashResult = new HashMap<>();
		boolean isValidToken = isValidToken(token);
		PALogger.INFO("Email: "+email+" token: "+token+" hostName: "+hostName+" isValidToken: "+isValidToken);
		if(isValidToken) {
			SupportAssignedRelayPortsVO supportAssignedRelayPortsVO = isAssignRelay(hostName);

			if(supportAssignedRelayPortsVO == null) {
				hashResult=setrelayserver(token,hostName,callByAdmin);
			} else {//Already assigned ports
				PALogger.INFO("===== relay ports are already assigned for ===="+ hostName +"============");


				int relayServerIsAlive = buildRelayServers().checkIfRelayServerIsAlive(supportAssignedRelayPortsVO.getsRelayServerId(),true,true);
				PALogger.INFO("=====Check if already assigned relay isalive===="+ supportAssignedRelayPortsVO.getsRelayServerId() +"============");
				if(relayServerIsAlive == 200) {
					RelayServerVO supportRelayServer = getRelayServerDetails(supportAssignedRelayPortsVO.getsRelayServerId(),callByAdmin);

					hashResult.put("Status", "Success");
					hashResult.put("relayServer", supportRelayServer);
					if(callByAdmin){
						hashResult.put("sRUserName", supportRelayServer.getsRUserName());
						hashResult.put("sRPassword", supportRelayServer.getsRPassword());
						hashResult.put("sHostKey", supportRelayServer.getsHostKey());
					}else{
						String key = buildCredProvider().getEcnKey();
						String userName = StringEncryptionDecryption.encrypt(StringEncryptionDecryption.decrypt(supportRelayServer.getsRUserName(),key), hostName);
						String pwd = StringEncryptionDecryption.encrypt(StringEncryptionDecryption.decrypt(supportRelayServer.getsRPassword(),key), hostName);	
						String sHostKey = StringEncryptionDecryption.encrypt(StringEncryptionDecryption.decrypt(supportRelayServer.getsHostKey(),key), hostName);	
						
						
						hashResult.put("sRUserName", userName);
						hashResult.put("sRPassword", pwd);
						hashResult.put("sHostKey", sHostKey);
					}
					
					
					hashResult.put("RelayServerAddress", supportRelayServer.getsRelayServerAddress());
					hashResult.put("RPort", String.valueOf(supportRelayServer.getnRPort())); 
					hashResult.put("PortSegmentStart", String.valueOf(supportAssignedRelayPortsVO.getnPortSegmentStart()));
					//Udpate token status in supporttokens table
					boolean isUpdated=	updateSupportToken(token, TOKENSTATUS.ENABLED);
					PALogger.INFO("Support token updated :_" +isUpdated); 
					hashResult.put(Constant.SUPPORTTOKENDETAILS, getSupportTokenDetail(token));					
					return hashResult;
				} else {					
					hashResult=setrelayserver(token,hostName,callByAdmin);
				}

			}

			if(StringFunctions.isNullOrWhitespace(hashResult.get("ErrorMessage"))) {
				return hashResult;
			} else {
				hashResult.put("Status", "Failure");
				hashResult.put("ErrorMessage", hashResult.get("ErrorMessage"));
				hashResult.put("Details", hashResult);
				return hashResult;
			}
		} else {
			hashResult.put("Status", "Failure");
			hashResult.put("ErrorMessage", "Invalid suport token.");
			return hashResult;
		}		

	}
	
	//Added a supportTokenId required to update the token status as supporttoken is primarykey field.
	public Map<String, Object> setupDeleteSupportRelay(String hostName, String email , String token) throws SQLException, IOException, ParseException { // added an arguement supportTokenId
		Map<String, Object> hashResult = new HashMap<>();
		PALogger.INFO("Email: "+email+" token: "+token+" hostName: "+hostName);		
		isAssignRelay(hostName);
		//Update token status in support token table;
		boolean updateResult = updateSupportToken(token,TOKENSTATUS.DISABLED);
		if(!updateResult){
			hashResult.put("Status", "Failure");
			hashResult.put("ErrorMessage", "Unable to update devicedetails, please try again.");
			return hashResult;
		}
		JSONParser parser = buildJSONParser();
		JSONObject obj = (JSONObject) parser.parse(buildFileReader());
		String portalUrl = "https://" + obj.get("portalUrl").toString() + Constant.localFileSeparator;

			String logoPath= "/var/www/html/" + Constants.UI_FOLDER_NAME + "/images/emailicons/favicon.ico";

			//			http://localhost:4200/pp/feedback
			String technicalSupportUrl = portalUrl + Constant.PORTAL_UI_FOLDER_NAME + "/feedback";

			PALogger.INFO("sendDeleteSupportTokenEmail "+email+" "+token+" "+logoPath+" "+portalUrl);

		List<EmailServersVO> listEmailServer = new EmailServers().listsAllOrderByPriority();
		buildMailer(listEmailServer).sendDeleteSupportTokenEmail(email, token, technicalSupportUrl); 		
		hashResult.put("Status", "Success");
		hashResult.put("ErrorMessage", "Token device mark as deleted.");
		return hashResult;		
	}

	public Map<String, Object> generateSupportToken(String email, String hostName,String userId,long expiryTime,String nodeId) {
		Map<String, Object> hashResult = new HashMap<>();
		
		try{

			TokenVO supportTokenData= new TokenEngine().generateSupportToken(email, hostName,userId,expiryTime,nodeId);
			hashResult.put("Status", "Success");
			hashResult.put(Constant.DATA, supportTokenData);
			return hashResult;
		}catch(Exception ex){
			hashResult.put("Status", "Failure");
			hashResult.put("ErrorMessage", ex.getMessage());
			return hashResult;
		}
	}


	
	/**
	 * list all support relay servers with used and available count
	 * @return
	 * @throws SQLException
	 */
	public List<RelayServerVO> listsAllSupportRelayServer(boolean callByAdmin) throws SQLException
	{
		return mListsAllSupportRelayServer(callByAdmin);
	}

	/**
	 * insert in support relay server
	 * @param relayServerVo
	 * @return
	 * @throws Exception 
	 */
	public  RelayServerVO insertSupportRelayServer(RelayServerVO relayServerVo, boolean  callByAdmin) throws Exception 
	{
		return mInsertSupportRelayServer(relayServerVo, callByAdmin);
	}
	
	/**
	 * update in support relay server
	 * @param relayServerVo
	 * @return
	 * @throws SQLException
	 */
	public  RelayServerVO updateSupportRelayServer(RelayServerVO relayServerVo, boolean callByAdmin) throws SQLException 
	{
		return mUpdateSupportRelayServer(relayServerVo, callByAdmin);
	}

	/**
	 * delete support relay server
	 * @param sRelayServerId
	 * @throws SQLException
	 */
	public  void deleteSupportRelayServer(String sRelayServerId) throws SQLException 
	{
		mDeleteSupportRelayServer(sRelayServerId);
	}
	public Map<String, Object> sendTokenOnEmail(String email, String token, String deviceId) throws SQLException, IOException, ParseException {
		HashMap<String, Object> hashResult = new HashMap<>();
		DeviceVO deviceVO = new DevicesEngine().getDevice(deviceId, false);
		if(deviceVO != null){
			
			JSONParser parser = buildJSONParser();
			JSONObject obj = (JSONObject) parser.parse(buildFileReader());

			String portalUrl = "https://" + obj.get("portalUrl").toString() + Constant.localFileSeparator;

			//			http://localhost:4200/pp/connect=sdfsd/support/
			String supportURL = portalUrl + Constant.PORTAL_UI_FOLDER_NAME + "/connect=" + deviceVO.getDeviceName() + Constant.localFileSeparator + "support" + Constant.localFileSeparator;

			//			http://localhost:4200/pp/feedback
			String technicalSupportUrl = portalUrl + Constant.PORTAL_UI_FOLDER_NAME + "/feedback";

			String logoPath= "/var/www/html/" + Constants.UI_FOLDER_NAME + "/images/emailicons/favicon.ico";

			PALogger.INFO("sendTokenOnEmail "+email+" "+token+" "+supportURL+" "+logoPath+" "+technicalSupportUrl);


			List<EmailServersVO> listEmailServer = new EmailServers().listsAllOrderByPriority();
			buildMailer(listEmailServer).sendSupportTokenEmail(email, token, supportURL, technicalSupportUrl);

			hashResult.put("Status", "Success");
			hashResult.put("Email", email);
			return hashResult;
		} else {
			hashResult.put("Status", "Failure");
			hashResult.put("ErrorMessage", "No discovery details found.");
			return hashResult;
		}


	}

	
	public Map<String, String> supportRelayServerDetails(String deviceId)throws SQLException  {
		return mSupportRelayServerDetails(deviceId);
	}
	
	public Map<String, String> mSupportRelayServerDetails(String deviceId) throws SQLException {				
		return new DevicesEngine().listSupportRelayDetails(deviceId);	
	}
	/*
	 * validating token. 
	 */	
	private boolean isValidToken(String token) throws SQLException 
	{
		TokenVO tokenVO = new TokenEngine().checkValidToken(token);
		return tokenVO != null;
	}

	/*
	 * get token details.
	 */	
	public Map<String, Object> GetSupportTokenDetails(String nodeId) throws SQLException 
	{		
		TokenVO tokenVO=new TokenEngine().getTokenDetails(nodeId);
		Map<String, Object> detail = new HashMap<>();
		detail.put(Constant.DATA, tokenVO);
		return detail;
	}	

	private SupportAssignedRelayPortsVO isAssignRelay(String deviceId) throws SQLException {
		return new SupportRelayServerEngine().getSupportAssignedRelayPorts(deviceId);
	}

	private Map<String, Object> setrelayserver(String token,String hostName, boolean callByAdmin) throws SQLException { // added an arguement supportTokenId
		Map<String, Object> hashResult = new HashMap<>();
		List<RelayServerVO> allrelayserver = getRelayServers(callByAdmin);
		boolean isRelayServerAssigned = false;
		boolean isLockGranted = false;
		String errorMessage="";
		if(!allrelayserver.isEmpty()) {
			for (Iterator iterator = allrelayserver.iterator(); iterator.hasNext();) {
				RelayServerVO relayServerVO = (RelayServerVO) iterator.next();
				int retryCount = 0;
				int relayServerIsAlive = buildRelayServers().checkIfRelayServerIsAlive(relayServerVO.getsRelayServerID(),false,false);
				PALogger.INFO("=====RelayServerIsAlive===="+ relayServerIsAlive +"============");
				if(relayServerIsAlive == 200) {
					while(retryCount < 3){
						PALogger.INFO("=====get relay server id and port range===="+ relayServerVO.getsRelayServerID() +"======"+ relayServerVO.getnPortRangeEnd() +"======");
						Integer portSegmentStart = getAvailablePortRange(hostName, relayServerVO.getsRelayServerID(), relayServerVO.getnPortRangeEnd());
						PALogger.INFO("=====PortSegmentStart===="+ portSegmentStart +"============");
						if(portSegmentStart == 0)
						{
							portSegmentStart = relayServerVO.getnPortRangeStart();
							PALogger.INFO("=====PortSegmentStart===="+ portSegmentStart +"============");
						}
						if(!StringFunctions.isNullOrWhitespace(portSegmentStart)) {

							RelayServerVO supportRelayServer = getRelayServerDetails(relayServerVO.getsRelayServerID(), callByAdmin);
							isLockGranted  = lockPortSegment(hostName, relayServerVO.getsRelayServerID(), portSegmentStart);
							PALogger.INFO("=====IsLockGranted===="+ isLockGranted +"============");
							if(isLockGranted){

								hashResult.put("Status", "Success");
								hashResult.put("relayServer", supportRelayServer);
								hashResult.put("PortSegmentStart", String.valueOf(portSegmentStart));
								if(callByAdmin){
									hashResult.put("sRUserName", supportRelayServer.getsRUserName());
									hashResult.put("sRPassword", supportRelayServer.getsRPassword());
									hashResult.put("sHostKey", supportRelayServer.getsHostKey());
								}else{
									String key = buildCredProvider().getEcnKey();
									String userName = StringEncryptionDecryption.encrypt(StringEncryptionDecryption.decrypt(supportRelayServer.getsRUserName(),key), hostName);
									String pwd = StringEncryptionDecryption.encrypt(StringEncryptionDecryption.decrypt(supportRelayServer.getsRPassword(),key), hostName);	
									String hostKey = StringEncryptionDecryption.encrypt(StringEncryptionDecryption.decrypt(supportRelayServer.getsHostKey(),key), hostName);	
									
									hashResult.put("sRUserName", userName);
									hashResult.put("sRPassword", pwd);
									hashResult.put("sHostKey",hostKey);
								}
								hashResult.put("RelayServerAddress", supportRelayServer.getsRelayServerAddress());
								hashResult.put("RPort", String.valueOf(supportRelayServer.getnRPort())); 
								isRelayServerAssigned = true;
								//udpate token status.
								boolean  isUpdated=updateSupportToken(token, TOKENSTATUS.ENABLED);
								PALogger.INFO("Support token updated :_" +isUpdated);
								hashResult.put(Constant.SUPPORTTOKENDETAILS, getSupportTokenDetail(hostName));
								break;
							} else {
								errorMessage="No relay ports available.";
							}
						}
						retryCount++;
					}
					if(isRelayServerAssigned){
						break;
					}
				}
			}
		}
		if(!isRelayServerAssigned){
			hashResult.put("Status", "Failure");
			errorMessage = "No relay server available.";			
		}
		hashResult.put("ErrorMessage", errorMessage);
		return hashResult;
	}

	private TokenVO getSupportTokenDetail(String token) throws SQLException{

		return new TokenEngine().getTokenDetailsByToken(token);		
	}

	// Update Token Status
	private boolean updateSupportToken(String supportToken ,TOKENSTATUS status) throws SQLException{
		return new TokenEngine().updateTokenstatus(supportToken , status);
	}	

	private List<RelayServerVO> getRelayServers(boolean callByAdmin) throws SQLException {
		return  new SupportRelayServerEngine().getSupportRelayServers(callByAdmin);
	}

	private Integer getAvailablePortRange(String deviceId, String relayServerId, int portRangeEnd) throws SQLException {
		Integer assinedPorts = new SupportRelayServerEngine().getAlreadyAssignedPorts(deviceId, relayServerId);
		if(assinedPorts != null){
			PALogger.INFO("=====Already assigned ports===="+ assinedPorts +"============");
			if(!StringFunctions.isNullOrWhitespace(assinedPorts)){
				return 	assinedPorts;
			}
		}		
		int portsegment = getMaxRelayPort(relayServerId);
		PALogger.INFO("=====GetAvailablePortRange===="+ portsegment +"============");
		if((portsegment + (portSegmentSize-1)) > portRangeEnd) {
			List<SupportAssignedRelayPortsVO> lstAvailablePorts = new SupportRelayServerEngine().getAvailablePorts(relayServerId); // list all assigned ports on this relay server where status is AVAILABLE
			if(!lstAvailablePorts.isEmpty()) {
				PALogger.INFO("=====lstAvailablePorts===="+ new Gson().toJson(lstAvailablePorts) +"============");
				new SupportRelayServerEngine().deleteDeviceAssignedPorts(lstAvailablePorts.get(0).getsDeviceId());			
				return lstAvailablePorts.get(0).getnPortSegmentStart();
			}
			else{
				return null;
			}
		} else {
			return portsegment;
		}
	}

	private int getMaxRelayPort(String relayServerId) throws SQLException {
		int maxAvailablePortSegment = new SupportRelayServerEngine().getMaxRelayPort(relayServerId);
		if(maxAvailablePortSegment == 0){
			return 0;
		}
		else{
			return maxAvailablePortSegment + portSegmentSize;	    	
		}
	}

	private RelayServerVO getRelayServerDetails(String relayServerId, boolean callByAdmin) throws SQLException {
		return new SupportRelayServerEngine().getSupportRelayServers(relayServerId, callByAdmin);
	}

	private boolean lockPortSegment(String deviceId,String relayServerId, int portSegmentStart) throws SQLException{
		SupportRelayServerEngine supportRelayServerEngine = new SupportRelayServerEngine();
		supportRelayServerEngine.placeBid(deviceId, relayServerId, portSegmentStart);
		if(isDeviceBidWon(deviceId, relayServerId, portSegmentStart)){
			//We need to create cron job to delete bids older than x Minuts
			supportRelayServerEngine.addAssignedRelayPorts(deviceId, relayServerId, portSegmentStart);
			return true;
		}else{
			supportRelayServerEngine.deleteDeviceBids(deviceId);
			return false;
		}
	}



	private boolean isDeviceBidWon(String deviceId, String relayServerId, int portSegmentStart) throws SQLException{
		SupportRelayServerEngine supportRelayServerEngine = new SupportRelayServerEngine();
		supportRelayServerEngine.deleteExpiredLocks();
		List<LockRelayPortsVO> bids = supportRelayServerEngine.listBids(relayServerId, portSegmentStart);
		
		for (Iterator iterator = bids.iterator(); iterator.hasNext();) 
		{
			LockRelayPortsVO lockRelayPortsVO = (LockRelayPortsVO) iterator.next();
			PALogger.INFO("=====bids========"+ lockRelayPortsVO.getnPortSegmentStart() +"==========="+ deviceId +"======"+ lockRelayPortsVO.getdModified() +"======");
		}
		PALogger.INFO("=====bids===="+ new Gson().toJson(bids) +"============");
		return bids.get(0).getsDeviceID().equals(deviceId);
	}

	public String listBids(String relayServerId, int portSegmentStart){
		return "SELECT sDeviceID,dModified FROM supportlockrelayports "
				+ "WHERE sRelayServerID = '"+ relayServerId +"' AND nPortSegmentStart = "+ portSegmentStart +" ORDER BY dModified";
	}

	public String deleteExpiredLocks() {
		return "DELETE FROM supportlockrelayports WHERE dModified < (NOW() - INTERVAL 5 MINUTE) ";
	}

	private List<RelayServerVO> mListsAllSupportRelayServer(boolean callByAdmin) throws SQLException
	{
		SupportRelayServerEngine engg = new SupportRelayServerEngine();
		return engg.listsAllSupportRelayServer(callByAdmin);
	}

	/**
	 * insert in support relay server
	 * @param relayServerVo
	 * @return
	 * @throws Exception 
	 */
	private  RelayServerVO mInsertSupportRelayServer(RelayServerVO relayServerVo, boolean callByAdmin) throws Exception 
	{
		SupportRelayServerEngine engg = new SupportRelayServerEngine();
		return engg.insertSupportRelayServer(relayServerVo.getsRelayServerID(), relayServerVo.getsRelayServerAddress(), relayServerVo.getsRelayName(), relayServerVo.getnPortRangeStart(), relayServerVo.getnPortRangeEnd(), relayServerVo.getsDeviceLimit(), relayServerVo.getnStatus(),relayServerVo.getsRUserName(),relayServerVo.getsRPassword(), relayServerVo.getsHostKey(), relayServerVo.getnRPort(), relayServerVo.getsPriority(), callByAdmin);
	}
	

	/**
	 * update in support relay server
	 * @param relayServerVo
	 * @return
	 * @throws SQLException
	 */
	private  RelayServerVO mUpdateSupportRelayServer(RelayServerVO relayServerVo, boolean callByAdmin) throws SQLException 
	{
		SupportRelayServerEngine engg = new SupportRelayServerEngine();
		return engg.updateSupportRelayServer(relayServerVo.getsRelayServerID(), relayServerVo.getsRelayServerAddress(), relayServerVo.getsRelayName(), relayServerVo.getnStatus(), relayServerVo.getsRUserName(), relayServerVo.getsRPassword(), relayServerVo.getsHostKey(), relayServerVo.getnRPort(), relayServerVo.getsPriority(), callByAdmin);
	}
	
	private  void mDeleteSupportRelayServer(String sRelayServerId) throws SQLException 
	{
		SupportRelayServerEngine engg = new SupportRelayServerEngine();
		 engg.delete(sRelayServerId);
	}
	/**
	 * Delete support token.
	 * @param token
	 * @return
	 * @throws SQLException
	 */
	public boolean DeleteSupportToken(String token) throws SQLException 
	{
		return mDeleteSupportToken(token);
	}

	private boolean mDeleteSupportToken(String token) throws SQLException 
	{
		return  new TokenEngine().deleteTokenDetails(token);
		
	}
	
	public RelayServers buildRelayServers() {
		return new RelayServers();
	}
	
	public Mailer buildMailer(List<EmailServersVO> listEmailServer) {
		return new Mailer(listEmailServer);
	}

	public FileReader buildFileReader() throws FileNotFoundException {
		return new FileReader(Constant.LISTING_SERVER_FILE);
	}

	public JSONParser buildJSONParser() {
		return new JSONParser();
	}
	
	public CredProvider buildCredProvider() {
		return new CredProvider();
	}

}
