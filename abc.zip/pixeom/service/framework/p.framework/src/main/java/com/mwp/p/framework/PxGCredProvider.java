/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.framework;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.security.AccessControlException;

import com.google.api.gax.core.CredentialsProvider;
import com.google.auth.http.HttpTransportFactory;
import com.google.auth.oauth2.GoogleCredentials;

/*
 * Provides google credentials read from a credentials path.
 */
public class PxGCredProvider implements CredentialsProvider {

	private String credentialsPath = null;
	static final PxHttpTransportFactory HTTP_TRANSPORT_FACTORY = new PxHttpTransportFactory();
	public PxGCredProvider(String credentialsPath) {
		this.credentialsPath = credentialsPath;
	}
	
	/**
	 * Read credentials from file and return GoogleCredentials.Use PxHttpTransportFactory in 
	 */
	public GoogleCredentials getCredentials() throws IOException {
		return getDefaultCredentialsUnsynchronized(HTTP_TRANSPORT_FACTORY);
	}

	

	
	boolean isFile(File file) {
		return file.isFile();
	}

	InputStream readStream(File file) throws FileNotFoundException {
		return new FileInputStream(file);
	}

	private final GoogleCredentials getDefaultCredentialsUnsynchronized(HttpTransportFactory transportFactory) throws IOException {

		// First try the environment variable
		GoogleCredentials credentials = null;		    
		if (credentialsPath != null && credentialsPath.length() > 0) {
			InputStream credentialsStream = null;
			try {
				File credentialsFile = new File(credentialsPath);
				if (!isFile(credentialsFile)) {
					// Path will be put in the message from the catch block below
					throw new IOException("File does not exist.");
				}
				credentialsStream = readStream(credentialsFile);
				credentials = GoogleCredentials.fromStream(credentialsStream, transportFactory);
			} catch (IOException e) {
				// Although it is also the cause, the message of the caught exception can have very
				// important information for diagnosing errors, so include its message in the
				// outer exception message also.
				throw new IOException(String.format("Error reading credential file from environment variable %s, value '%s': %s",credentialsPath, credentialsPath, e.getMessage()), e);
			} catch (AccessControlException expected) {
				// Exception querying file system is expected on App-Engine
			} finally {
				if (credentialsStream != null) {
					credentialsStream.close();
				}
			}
		}


		return credentials;
	}

	

	
	
}
