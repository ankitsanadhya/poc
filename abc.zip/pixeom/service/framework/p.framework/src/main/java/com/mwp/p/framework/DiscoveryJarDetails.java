/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.framework;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.amazonaws.services.route53.model.ChangeAction;
import com.mwp.common.StringFunctions;
import com.mwp.common.constant.Constant;
import com.mwp.common.enums.RelayEnum.NetworkTypeEnum;
import com.mwp.common.vo.DiscoveryJarDetailsVO;
import com.mwp.logger.PALogger;
import com.mwp.p.common.Constants;
import com.mwp.p.common.PortalCommon;
import com.mwp.p.dal.engine.DiscoveryJarDetailsEngine;
import com.mwp.p.dal.engine.RelayServersEngine;
import com.mwp.p.framework.ManageDomainNameGoogle.DomainOperation;

public class DiscoveryJarDetails {

	public Map<String, Object> setJARDiscoveryDetails(String macAddress, String hostName, String iPAddress, String localIPAddress, String chatInputChannel, 
			String chatOutputChannel, String chatSubscriptionChannel, String nodeCommunicationPort, String openStackPort,
			String tomcatPort, String port1, String port2, String port3, String port4, String port5, String rURLTomcatPort, 
			String rAddress, int status, String relayServerID, NetworkTypeEnum networkType) throws SQLException 
	{
		

		if(status == 0){
			status = 4;	
		} else {
			status = 1;
		}

		DiscoveryJarDetailsVO detailsVO = isDiscoveryJARDetailsExists(macAddress);
		new DiscoveryJarDetailsEngine().updateDiscoveryDetails(macAddress, hostName, iPAddress, localIPAddress, chatInputChannel, 
				chatOutputChannel, chatSubscriptionChannel, nodeCommunicationPort, openStackPort, tomcatPort, 
				port1, port2, port3, port4, port5, rURLTomcatPort,  rAddress, 
				 status, networkType, relayServerID);


		PALogger.INFO("=====Set discovery jar details for this HostName '" + hostName + "' ============");
		String relayServerAddress = new RelayServersEngine().getRelayServerAddress(relayServerID);
		if(!StringFunctions.isNullOrWhitespace(relayServerAddress)){
			PALogger.INFO("=====RelayServerAddress in set Discovery JAR Details===="+ relayServerAddress +"============");
		}	


		switch (Constants.getDNS_SERVER()) {
		case AMZ:
			ManageDomainName.runCommand(ChangeAction.UPSERT, hostName, relayServerAddress);
			break;
		case AZR:
			break;
		case GOO:
			if(detailsVO == null || StringFunctions.isNullOrWhitespace(detailsVO.getsRelayServerAddress())){
				ManageDomainNameGoogle.runCommand(DomainOperation.Add, hostName, relayServerAddress, "");
			}else if(!detailsVO.getsRelayServerID().equals(relayServerAddress)) {
				ManageDomainNameGoogle.runCommand(DomainOperation.Edit, hostName, relayServerAddress, detailsVO.getsRelayServerAddress());
			}
			break;
		case JD:
			if(detailsVO == null || StringFunctions.isNullOrWhitespace(detailsVO.getsRelayServerAddress())){
				ManageDomainNameJD.runCommand(DomainOperation.Add, hostName, relayServerAddress, "");
			}else if(!detailsVO.getsRelayServerID().equals(relayServerAddress)) {
				ManageDomainNameJD.runCommand(DomainOperation.Edit, hostName, relayServerAddress, detailsVO.getsRelayServerAddress());
			}
			break;
		default:
			break;
		}



		new DiscoveryJarDetailsEngine().updateDiscoveryDetailsConnectUrl("https://" + relayServerID + ":" + tomcatPort + "/" + PortalCommon.getInstance().getUIPath()  + "/", macAddress);
		HashMap<String, Object>  hashResult = new HashMap<>();
		hashResult.put("Status", "Success");
		return hashResult;
	}

	public Map<String, Object> deleteDiscoveryJarDetails(String macAddress) throws SQLException {
		new DiscoveryJarDetailsEngine().deleteDiscoveryJarDetails(macAddress);
		HashMap<String, Object>  hashResult = new HashMap<>();
		hashResult.put("Status" , "Success");
		hashResult.put("Details", macAddress);
		return hashResult;
	}

	public Map<String, Object> setupRelayJARDiscoveryDetails(String macAddress, int deviceStatus, String guid, long timestamp, 
			 String email, String hostName, String swLicense, String hwConfig, String iPAddress, String localIPAddress, 
			String chatInputChannel, String chatOutputChannel, String chatSubscriptionChannel, String nodeCommunicationPort, String openStackPort, 
			String tomcatPort, String port1, String port2, String port3, String port4, String port5, String rURLTomcatPort, 
			String rAddress, String isSetRURL, int status) throws Exception{
		Map<String, Object>  hashResult = new HashMap<>();
		Map<String, Object> validationResult = new ValidationInfo().checkValidationInfo(macAddress, deviceStatus, guid, 
				timestamp,  email, hostName, swLicense, hwConfig);
		String statusTemp = "";
		String errorMessage = "";
		// uncomment code for use in android-ntl
		if(validationResult.size() > 0) {  // Not require validationResult - ntl, va // Use in validationInfo - ntl, va, hu
			statusTemp = validationResult.get("Status").toString();
			errorMessage = validationResult.get("ErrorMessage").toString();
			if("Failure".equals(statusTemp) && "Duplicate MAC Address.".equals(errorMessage)) {
				hashResult.put("Status" , "Failure");
				hashResult.put("validationResult", validationResult);
				return hashResult;
			}
		}

		DiscoveryJarDetailsVO detailsVO = getDiscoveryJARDetails(macAddress);			

		if(detailsVO != null && !StringFunctions.isNullOrWhitespace(detailsVO.getsRelayServerID())) {

			int relayServerIsAlive = buildRelayServers().checkIfRelayServerIsAlive(detailsVO.getsRelayServerID(),true,false);
			PALogger.INFO("=====Check if already assigned relay isalive ===="+ detailsVO.getsRelayServerID() +"============");
			if(relayServerIsAlive == 200) {

				NetworkTypeEnum networkType = detailsVO.getsNetworkType();
				String relayServerID = detailsVO.getsRelayServerID();				

				chatInputChannel = detailsVO.getsChatInputChannel();
				chatOutputChannel = detailsVO.getsChatOutputChannel();
				chatSubscriptionChannel = detailsVO.getsChatSubscriptionChannel();
				nodeCommunicationPort = detailsVO.getsNodeCommunicationPort();
				openStackPort = detailsVO.getsOpenStackPort();
				tomcatPort = detailsVO.getsTomcatPort();
				port1 = detailsVO.getsPort1();
				rURLTomcatPort = detailsVO.getsRURLTomcatPort();
				rAddress = detailsVO.getsRAddress();


				setJARDiscoveryDetails(macAddress, hostName, iPAddress, localIPAddress, chatInputChannel, chatOutputChannel, 
						chatSubscriptionChannel, nodeCommunicationPort, openStackPort,  tomcatPort, port1, port2, port3, port4, port5, 
						rURLTomcatPort,  rAddress, status, relayServerID, networkType);

				detailsVO = getDiscoveryJARDetails(macAddress);
				hashResult.put("Status" , "Success");
				hashResult.put("Details", detailsVO);
				hashResult.put("validationResult", validationResult);
				return hashResult;
			}
		}

		errorMessage = buildRelayServers().setRelayServer(macAddress, macAddress, hostName, iPAddress, 
				localIPAddress, chatInputChannel, chatOutputChannel, chatSubscriptionChannel, 
				nodeCommunicationPort, openStackPort,  tomcatPort, 
				port1, port2, port3, port4, port5, rURLTomcatPort,  
				rAddress, isSetRURL, status, false);

		detailsVO = getDiscoveryJARDetails(macAddress);


		if("".equals(errorMessage)){
			hashResult.put("Status" , "Success");
			hashResult.put("Details", detailsVO);
			hashResult.put("validationResult", validationResult);	
			return hashResult;
		} 
		else {
			hashResult.put("Status" , "Failure");
			hashResult.put("ErrorMessage" , errorMessage);
			hashResult.put("Details", detailsVO);
			hashResult.put("validationResult", validationResult);
			return hashResult;
		}	
	}

	public RelayServers buildRelayServers() {
		return new RelayServers();
	}

	/**
	 * Get all non activated devices.
	 * @param externalIP
	 * @return
	 * @throws SQLException
	 */
	public List<DiscoveryJarDetailsVO> getNonActivatedDevices(String externalIP) throws SQLException {
		return mGetNonActivatedDevices(externalIP);
	}

	/**
	 * Get non activated devices.
	 * @param hostName
	 * @return
	 * @throws Exception 
	 */
	public DiscoveryJarDetailsVO getDiscoveryJarDetailsUsingHostName(String hostName) throws Exception {
		DiscoveryJarDetailsVO  detailsVO = new DiscoveryJarDetailsEngine().getDiscoveryJarDetailsUsingHostName(hostName);
		if(detailsVO == null) {
			throw new Exception(Constant.NOTFOUND);
		}
		return detailsVO;
	}

	public void updateInactiveDeviceHeartbeat(String productId) throws SQLException {
		new DiscoveryJarDetailsEngine().updateInactiveDeviceHeartbeat(productId);
	}

	private List<DiscoveryJarDetailsVO> mGetNonActivatedDevices(String externalIP) throws SQLException {
		return new DiscoveryJarDetailsEngine().getNonActivatedDevices(externalIP);
	}

	public DiscoveryJarDetailsVO getDiscoveryJARDetails(String macAddress) throws SQLException {
		return new DiscoveryJarDetailsEngine().getDiscoveryJarDetailsWithRelay(macAddress);
	}

	private DiscoveryJarDetailsVO isDiscoveryJARDetailsExists(String macAddress) throws SQLException {
		return new DiscoveryJarDetailsEngine().getDiscoveryJarDetails(macAddress);
	}
}
