/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.framework;

import java.sql.SQLException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import com.google.gson.Gson;
import com.mwp.common.StringFunctions;
import com.mwp.common.vo.ValidationInfoVO;
import com.mwp.logger.PALogger;
import com.mwp.p.dal.engine.ValidationInfoEngine;

/**
 * This class manages validations for devices.  
 */
public class ValidationInfo {

	public Map<String, Object> checkValidationInfo(String macAddress, int status, String guid, long timestamp, 
			String email, String hostName, String swLicense, String hwConfig) throws SQLException {
		/*
		 * To solve issue - in case when box misses the newly generated timestamp, 
		 * then listing server can verify the box on the next heartbeat with the previous timestamp. - ntl, va, hu
		 */
		long previousTS = timestamp;
		PALogger.INFO("==CheckValidationInfo==MACAddress==" + macAddress + "==status=="+status+"==guid=="+guid+"==timestamp=="+timestamp+"==hostName=="+hostName);
		HashMap<String, Object> hashResult = new HashMap<>();
		ValidationInfoVO validInfoVO = getValidationInfo(macAddress);
		/*
		 * check for new device.
		 */
		if(isNewDevice(status, guid, timestamp)) {
			return hashResult;

		} else {
			if(validInfoVO == null){
				hashResult.put("Status", "Failure");
				hashResult.put("ErrorMessage", "ValidationInfo not found.");
				hashResult.put("Info", validInfoVO);
				return hashResult;
			}
			PALogger.INFO("===== Bogus Device Check===M=" + validInfoVO.getsMACAddress() + "==" + macAddress + "===============G=" + validInfoVO.getsGUID() + "==" + guid + "=======");
			PALogger.INFO("=====GET ValidationInfo===" + new Gson().toJson(validInfoVO) + "=======");

			if(guid.equals(validInfoVO.getsGUID()) && macAddress.equals(validInfoVO.getsMACAddress())) {
				PALogger.INFO("===== genuine Device Check=== " + validInfoVO.getnTimestamp() + "!=" + timestamp + "===============G=" + validInfoVO.getnPreviousTS() + "!=" + previousTS + "=======");
				if((timestamp != validInfoVO.getnTimestamp()) && (previousTS != validInfoVO.getnPreviousTS())) {
				
					validInfoVO.setnStatus(-1);
					hashResult.put("Status", "Failure");
					hashResult.put("ErrorMessage", "Invalid Info provided by genuine device.");
					validInfoVO.setEmail(email);
					validInfoVO.setHostName(hostName);
					validInfoVO.setHwConfig(hwConfig);
					validInfoVO.setSwLicense(swLicense);
					hashResult.put("Info", validInfoVO);

					return hashResult;
				} else {
					timestamp = new Date().getTime();
					status = 0;

					validInfoVO.setnStatus(status);
					validInfoVO.setnTimestamp(timestamp);

					validInfoVO.setEmail(email);
					validInfoVO.setHostName(hostName);
					validInfoVO.setHwConfig(hwConfig);
					validInfoVO.setSwLicense(swLicense);
					if(timestamp == validInfoVO.getnTimestamp())
						validInfoVO.setnPreviousTS(previousTS);					
					/*
					 * update validation info in db.
					 */
					PALogger.INFO("===== updateValidationInfo===" + new Gson().toJson(validInfoVO) + "=======");
					new ValidationInfoEngine().updateValidationInfo(validInfoVO);

					hashResult.put("Status", "Success");
					hashResult.put("ErrorMessage", "");
					hashResult.put("Info", validInfoVO);
					hashResult.put("licenseInfo", "");
					return hashResult;
				}
			} else {
				validInfoVO.setEmail(email);
				validInfoVO.setHostName(hostName);
				validInfoVO.setHwConfig(hwConfig);
				validInfoVO.setSwLicense(swLicense);
				validInfoVO.setnStatus(-1);
				hashResult.put("Status", "Failure");
				hashResult.put("ErrorMessage", "Bogus device called.");
				hashResult.put("Info", validInfoVO);

				return hashResult;
			}

		}
	}

	private boolean isNewDevice(int status, String guid, long timestamp) {
		return (status == 0 
				&& (StringFunctions.isNullOrWhitespace(guid) || guid.equals("0"))
				&& (StringFunctions.isNullOrWhitespace(timestamp) || timestamp <= 1000)) ;
			
	}

	private ValidationInfoVO getValidationInfo(String macAddress) throws SQLException {
		return new ValidationInfoEngine().getValidationInfo(macAddress);
	}


	public Map<String, Object> isProductIDUnique(String productID) throws SQLException  {
		HashMap<String, Object> hashResult = new HashMap<>();
		ValidationInfoVO infoVO = new ValidationInfoEngine().getValidationInfo(productID);
		if(infoVO == null){
			hashResult.put("Status", true);
		}else{
			hashResult.put("Status", false);
			hashResult.put("ErrorMessage", "Duplicate MAC Address.");
		}
		return hashResult;
	}

	private HashMap<String, Object> checkLicense(String activationKey, String productID) { // Check the status of license - ntl, va  
		return null;
	}

}
