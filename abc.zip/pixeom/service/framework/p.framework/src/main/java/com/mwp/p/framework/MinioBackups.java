/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.framework;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONException;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.xmlpull.v1.XmlPullParserException;

import com.google.gson.Gson;
import com.mwp.common.StringFunctions;
import com.mwp.common.constant.Constant;
import com.mwp.common.constant.ErrorMessage;
import com.mwp.common.enums.AppBackupTaskStatus;
import com.mwp.common.vo.AppBackupTaskVO;
import com.mwp.common.vo.AppBackupTaskVOPortal;
import com.mwp.common.vo.ApplicationPlatformVO;
import com.mwp.common.vo.AuthorizationsVO;
import com.mwp.common.vo.DeviceVO;
import com.mwp.common.vo.MinioVO;
import com.mwp.logger.PALogger;
import com.mwp.p.common.ClusterCmd;
import com.mwp.p.dal.engine.ApplicationPlatformEngine;
import com.mwp.p.dal.engine.DeveloperApplicationsEngine;
import com.mwp.p.dal.engine.VersionEngine;
import com.mwp.p.vo.VeleroBackupJsonVO;

import io.minio.MinioClient;
import io.minio.Result;
import io.minio.errors.ErrorResponseException;
import io.minio.errors.InsufficientDataException;
import io.minio.errors.InternalException;
import io.minio.errors.InvalidArgumentException;
import io.minio.errors.InvalidBucketNameException;
import io.minio.errors.InvalidEndpointException;
import io.minio.errors.InvalidPortException;
import io.minio.errors.MinioException;
import io.minio.errors.NoResponseException;
import io.minio.errors.RegionConflictException;
import io.minio.messages.Item;

/**
 * The class provide methods to manage minio user and buckets example create user , list bucket, create bucket etc...  
 * @author PS
 */
public class MinioBackups {

	//	********************************* PRIVATE VARIABLES STARTED*********************************
	//	/**
	//	 * access key that is given at the time of minio configuration
	//	 */
	//	//	private static String portalMinioAccessKey = "accesskeyexample";
	//	private static String portalMinioAccessKey = "key";
	//
	//	/**
	//	 * secret key that is given at the time of minio configuration
	//	 */
	//	//	private static String portalMinioSecretKey = "secretkeyexample";
	//	private static String portalMinioSecretKey = "password";

	private static MinioVO _minio;

	public static MinioVO getMinioVO(){
		if(_minio == null){
			_minio = Constant.getMinio();
		}
		return _minio;
	}

	/**
	 * Alias Name that is given to minio URL , and it is used when we create user by command  
	 */
	private static String aliasName = "portalminio";

	private static String backupsFolder = "backups";

	public final String PLATFORM_NOT_FOUND = "Platform not found for application.";
	public final String APP_NOT_FOUND = "Application not found.";
	public final String APP_VERSION_NOT_FOUND = "App version not found.";

	/**
	 * portal minio url
	 */
	//	private static String minioUrl = "http://10.10.0.2:9000/";
	//	private static String minioUrl = "http://192.168.14.13:9000/";

	/**
	 * portal minio url
	 */
	private static MinioClient minioClient = null;



	//	********************************* PRIVATE VARIABLES END *********************************

	//	********************************* PUBLIC METHODS STARTED*********************************

	//		/**
	//		 * Get minio url
	//		 * @return
	//		 */
	//		public static String GetMinioUrl(){
	//			return minioUrl;
	//		}


	/**
	 * Get minio url
	 * @return
	 * @throws InvalidPortException 
	 * @throws InvalidEndpointException 
	 */
	public MinioClient GetMinioClient() throws InvalidEndpointException, InvalidPortException{
		if(minioClient == null)
			minioClient = new MinioClient(getMinioVO().getUrl(), getMinioVO().getAccessKey(), getMinioVO().getSecretKey());// throws InvalidEndpointException, InvalidPortException;\
		return minioClient;
	}


	/**
	 * Method used to create user in minio cloud
	 * Default policy is taken with read and write permission
	 * @param authToken
	 * @throws Exception 
	 */
	public void CreateMinioUser(String userId, String userPassword) throws Exception
	{
		/**
		 * Default policy is taken with read and write permission 
		 */
		String policy = "readwrite";
		CreateMinioUser(userId, userPassword, policy);
	}

	/**
	 * Method used to create user in minio cloud
	 * @param authToken
	 * @throws Exception 
	 */
	public void CreateMinioUser(String userId, String userPassword, String policy) throws Exception
	{
		mCreateMinioUser(userId, userPassword, policy);
	}

	/**
	 * Method used to create user in minio cloud
	 * @param clusterId
	 * @return true if bucket create else return false if bucket already exists
	 * @throws InvalidKeyException
	 * @throws InvalidBucketNameException
	 * @throws RegionConflictException
	 * @throws NoSuchAlgorithmException
	 * @throws InsufficientDataException
	 * @throws NoResponseException
	 * @throws ErrorResponseException
	 * @throws InternalException
	 * @throws IOException
	 * @throws XmlPullParserException
	 * @throws InvalidEndpointException
	 * @throws InvalidPortException
	 */
	public boolean CreateMinioBucket(String clusterId) throws InvalidEndpointException, InvalidPortException, InvalidKeyException, InvalidBucketNameException, NoSuchAlgorithmException, InsufficientDataException, NoResponseException, ErrorResponseException, InternalException, IOException, XmlPullParserException, RegionConflictException
	{
		MinioClient minioClient = GetMinioClient(); //new MinioClient(getMinioVO().getUrl(), getMinioVO().getAccessKey(), getMinioVO().getSecretKey());// throws InvalidEndpointException, InvalidPortException
		if(minioClient.bucketExists(clusterId))// InvalidKeyException, InvalidBucketNameException, NoSuchAlgorithmException, InsufficientDataException, NoResponseException, ErrorResponseException, InternalException, IOException, XmlPullParserException
		{
			return false; 
		}
		minioClient.makeBucket(clusterId);	//RegionConflictException	
		return true;
	}

	public List<AppBackupTaskVOPortal> ListAllBackups(AuthorizationsVO authVO) throws Exception{
		return mListBackups(authVO, null, null);
	}

	public List<AppBackupTaskVOPortal> ListAllBackupsOfApplicationForCluster(AuthorizationsVO authVO, String clusterId, String appId) throws Exception{
		return mListBackups(authVO, clusterId, appId);
	}

	public List<AppBackupTaskVOPortal> ListAllBackupsOfACluster(AuthorizationsVO authVO, String clusterId) throws Exception{
		return mListBackups(authVO, clusterId, null);
	}

	public List<AppBackupTaskVOPortal> ListAllBackupsOfAnApp(AuthorizationsVO authVO, String appId) throws Exception{
		return mListBackups(authVO, null, appId);
	}

	//	********************************* PUBLIC METHODS END*********************************


	//	********************************* PRIVATE METHODS STARTED*********************************


	private void mCreateMinioUser(String userAccessKey, String userSecretKey, String policy) throws Exception
	{
		/**
		 * Step 1 Register the minio url and give alias name to it
		 * Each time we run this command it only overwrite the alias.Run successfully without error
		 * muliple aliases can be given to url and from each alias we can add user 
		 */
		addAlias(aliasName, getMinioVO().getUrl(), getMinioVO().getAccessKey(), getMinioVO().getSecretKey());

		/**
		 * Add user to minio cloud
		 */
		addUser(aliasName, userAccessKey, userSecretKey, policy);
	}


	private void addAlias( String aliasName, String minioUrl, String adminAccessKey, String adminSecretKey) throws InterruptedException, ExecutionException, TimeoutException, MinioException {
		//mc config host add test1 http://10.10.0.2:9000/minio/ accesskeyexample secretkeyexample

		List<String> cmd = new ArrayList<>();
		cmd.add("mc");
		cmd.add("config");
		cmd.add("host");
		cmd.add("add");
		cmd.add(aliasName);
		cmd.add(minioUrl);
		cmd.add(adminAccessKey);
		cmd.add(adminSecretKey);

		String result = ClusterCmd.getInstance().executeCommand(cmd);
		if(result.contains("successfully")){
			return;
		}else {
			PALogger.ERROR("Create alias failed in minio cloud OUTPUT ---> \n" + result + "\n");
			throw new MinioException("Add alias failed");
		}			
	}


	private void addUser( String aliasName, String userAccessKey, String userSecretKey, String policy) throws Exception{	

		List<String> cmd = new ArrayList<>();
		cmd.add("mc");
		cmd.add("admin");
		cmd.add("user");
		cmd.add("add");
		cmd.add(aliasName);
		cmd.add(userAccessKey);
		cmd.add(userSecretKey);
		cmd.add(policy);

		String result = ClusterCmd.getInstance().executeCommand(cmd);
		if(result.contains("successfully")){
			return;
		}else {
			PALogger.ERROR("Create user failed in minio cloud OUTPUT ---> \n" + result + "\n");
			throw new MinioException("Add minio user failed");
		}		
	}


	private List<AppBackupTaskVOPortal>  mListBackups(AuthorizationsVO authVO, String clusterId, String appId) throws Exception{

		List<AppBackupTaskVOPortal> listBackups = new ArrayList<>();

		List<DeviceVO> userClusters = getUserAvailableClusters(clusterId, authVO.getUserId());

		boolean  isAppIdPriovided = false;

		if(!StringFunctions.isNullOrWhitespace(appId)){
			isAppIdPriovided = true;
		}

		/**
		 * for each cluster of current user
		 */
		for (DeviceVO userCluster : userClusters) {
			if(!GetMinioClient().bucketExists(userCluster.getDeviceId()))
				continue;

			String minioBucketName = userCluster.getDeviceId();
			String prefix = MinioBackups.backupsFolder + Constant.localFileSeparator;


			if(isAppIdPriovided){
				prefix += appId;
			}
			final String arkBackupJsonFileName = "velero-backup.json";

			PALogger.INFO("LISTING STARTED FOR BUCKET OBJECTS FOR MINIO BUCKET ID/CLUSTER ID = " + minioBucketName + "  PREFIX  " + prefix); 
			Iterable<Result<Item>> objectList = listMinioBucketObjects(GetMinioClient(), minioBucketName, prefix);
			PALogger.INFO("LISTING COMPLETED FOR BUCKET OBJECTS FOR MINIO BUCKET ID/CLUSTER ID = " + minioBucketName + "  PREFIX  " + prefix);

			for (Result<Item> result : objectList) {
				Item resultObject  = result.get();

				PALogger.INFO("\nCLUSTER BACKUPNAME --> " + resultObject.objectName());

				String jsonFilePath = resultObject.objectName() + arkBackupJsonFileName;

				VeleroBackupJsonVO arkBackupJsonOBJECT = readVeleroJsonObject(minioBucketName, jsonFilePath);

				if(arkBackupJsonOBJECT != null && arkBackupJsonOBJECT.getStatus().getPhase().equals(status_phase.Completed.name())){

					/**
					 * Create AppBackupTaskPortal object 
					 */
					//					AppBackupTaskVOPortal appBackupTaskVOPortal  = createAppBackupTaskVOPortalObject(authVO,"48594405674541338188866ba243329f", "testrks", arkBackupJsonOBJECT);
					AppBackupTaskVOPortal appBackupTaskVOPortal  = createAppBackupTaskVOPortalObject(authVO, userCluster.getDeviceId(), userCluster.getDeviceName(), arkBackupJsonOBJECT);
					if(appBackupTaskVOPortal != null) {
						listBackups.add(appBackupTaskVOPortal);
					}

				}else{
					if(arkBackupJsonOBJECT == null){
						/**
						 * if backup metadata file is not exists foir backup then do not add to list  
						 */
						PALogger.ERROR("\nCAN NOT READ \"" + arkBackupJsonFileName + "\" file for BACKUP --> " + resultObject.objectName());
					}else{
						/**
						 * if backup status phase is not completed then do not add to list  
						 */
						PALogger.INFO("\nCLUSTER BACKUPNAME STATUS IS NOT COMPELETD --> " + resultObject.objectName() 
						+ " STATUS IS " + arkBackupJsonOBJECT.getStatus());
					}
				}
			}
		}
		return listBackups;
	}

	/**
	 * Get users all available clusters 
	 * @param clusterId
	 * @param userId
	 * @return
	 * @throws Exception
	 */
	private List<DeviceVO> getUserAvailableClusters(String clusterId, String userId) throws Exception {
		List<DeviceVO> userClusters = new ArrayList<>();
		/**
		 * if cluster id not provided then return all backups belong to existing cluster of user
		 */
		if(StringFunctions.isNullOrWhitespace(clusterId)){
			/**
			 * 	Get all kubernetes clusters of this user
			 */
			userClusters = new Devices().listKubenetesClusterForUser(userId);
		}
		else
		{
			userClusters = new Devices().listKubenetesClusterForUser(userId, clusterId);

			if(userClusters.isEmpty()){
				throw new Exception(ErrorMessage.DEVICE_NOT_FOUND);
			}
		}
		return userClusters;
	}


	private VeleroBackupJsonVO readVeleroJsonObject(String minioBucketName, String arkJsonFilePath)
			throws InvalidKeyException, InvalidBucketNameException, NoSuchAlgorithmException, InsufficientDataException,
			NoResponseException, ErrorResponseException, InternalException, InvalidArgumentException,
			InvalidEndpointException, InvalidPortException, IOException, XmlPullParserException, ParseException,
			JSONException {
		try (InputStream stream = GetMinioClient().getObject(minioBucketName, arkJsonFilePath);) {

			Object jsonObject = buildJsonParser().parse(buildBufferReader(stream));

			VeleroBackupJsonVO arkBackupObject = new Gson().fromJson(jsonObject.toString(), VeleroBackupJsonVO.class);
			return arkBackupObject;
		} catch (Exception ex) {
			PALogger.ERROR(ex);
		}
		return null;
	}

	private Iterable<Result<Item>> listMinioBucketObjects(MinioClient minioClient, String bucketName, String prefix) throws XmlPullParserException{
		Iterable<Result<Item>> objectList = minioClient.listObjects(bucketName, prefix, false);

		return objectList;
	}

	private AppBackupTaskVOPortal createAppBackupTaskVOPortalObject(AuthorizationsVO authVO, String clusterDeviceId, String userClusterName, VeleroBackupJsonVO arkBackupJsonOBJECT) throws Exception{

		String[] arrSplittedString = arkBackupJsonOBJECT.getMetadata().getName().split("-");

		String appId = arrSplittedString[0];
		long backupCreatedTimeOnBox =  Long.parseLong(arrSplittedString[1]);
		String appVersion = arkBackupJsonOBJECT.getMetadata().getLabels().get("appVersion");
		String appVersionId = arkBackupJsonOBJECT.getMetadata().getLabels().get("appVersionId");
		String platformActualName = arkBackupJsonOBJECT.getMetadata().getLabels().get("platformName");

		String objectName = arkBackupJsonOBJECT.getMetadata().getName();

		boolean isError = false;
		String appName = null;
		/**
		 * Get device application platform 
		 */
		ApplicationPlatformVO appPlatformVO = new ApplicationPlatformEngine().getDeviceApplicationPlatForm(appId, clusterDeviceId);

		//If Platform exists
		if(appPlatformVO == null)
		{
			isError = true;
			if(StringUtils.isNotEmpty(authVO.getApplicationId())) {
				throw new Exception(PLATFORM_NOT_FOUND);
			}
		} else {

			//IF app exists
			appName = new DeveloperApplicationsEngine().getAppName(appId);

			if(StringUtils.isEmpty(appName)) {
				isError = true;
				if(StringUtils.isNotEmpty(authVO.getApplicationId())) {
					PALogger.INFO("MinioBackups -> APP NOT EXISTS");
					throw new Exception(APP_NOT_FOUND); 
				}
			} else {

				//Check version exists
				List<String> versions = new VersionEngine().getAllVersionNumbers(appId, appPlatformVO.getAppPlatformId());

				if(!versions.contains(appVersion)) {
					isError = true;

					if(StringUtils.isNotEmpty(authVO.getApplicationId())) {
						PALogger.INFO("MinioBackups -> App version id not found for application "
								+ "\n appId " + appId 
								+ "\n version.getAppPlatformId() " + appPlatformVO.getAppPlatformId()
								+ "\n version.getVersionNumber() " + appVersion);

						throw new Exception(APP_VERSION_NOT_FOUND);
					}

				}
			}
		}

		if(isError) {
			return null;
		} else {
			AppBackupTaskVOPortal appBackupTaskVOPortal = new AppBackupTaskVOPortal(); 


			AppBackupTaskVO appBackupTaskVO = new AppBackupTaskVO();
			appBackupTaskVO.setApplicationId(appId);
			appBackupTaskVO.setAppName(appName);
			appBackupTaskVO.setAppVersion(appVersion);
			appBackupTaskVO.setAppVersionId(appVersionId);
			appBackupTaskVO.setArkBackupName(objectName);
			appBackupTaskVO.setStatus(AppBackupTaskStatus.ACTIVE);
			//Should replace with backup time.
			appBackupTaskVO.setStartedTime(backupCreatedTimeOnBox);
			appBackupTaskVO.setCompletedTime(backupCreatedTimeOnBox);
			appBackupTaskVO.setPlatformName(platformActualName);

			appBackupTaskVOPortal.setAppBackupTaskVO(appBackupTaskVO);
			appBackupTaskVOPortal.setClusterId(clusterDeviceId);
			appBackupTaskVOPortal.setClusterName(userClusterName);

			return appBackupTaskVOPortal;
		}
	}
	
	public JSONParser buildJsonParser() {
		return new JSONParser();
	}
	
	public BufferedReader buildBufferReader(InputStream stream) {
		return new BufferedReader(buildInputStreamReader(stream));
	}


	public InputStreamReader buildInputStreamReader(InputStream stream) {
		return new InputStreamReader(stream);
	}


	//	********************************* PRIVATE METHODS END*********************************
}

enum status_phase{
	Completed,

}