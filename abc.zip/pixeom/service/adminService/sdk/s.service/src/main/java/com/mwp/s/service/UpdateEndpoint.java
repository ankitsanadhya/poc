package com.mwp.s.service;


import java.security.InvalidParameterException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.constraints.NotNull;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.mwp.common.AuthHelper;
import com.mwp.common.ReturnObject;
import com.mwp.common.constant.Constant;
import com.mwp.common.constant.PermissionResources;
import com.mwp.common.enums.ActivityOperation;
import com.mwp.common.constant.PermissionResourceKeys;
import com.mwp.common.vo.AuthorizationsVO;
import com.mwp.common.vo.ErrorVo;
import com.mwp.common.vo.GroupReleaseVO;
import com.mwp.logger.PALogger;
import com.mwp.p.common.AdminPermissionCheck;
import com.mwp.p.common.Constants;
import com.mwp.p.framework.ActivityLogs;
import com.mwp.s.framework.AppUpdate;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/** <h1>DevicesEndpoint</h1>
 * Class hosted at the URI path "/devices"
 * <p>
 * Class manage devices, list devices, list application of devices.
 * </p>
 * @author akh
 * @version 0.0.1
 * @since   2016-08-30 
 */
@Path("/update")
@Api( value = "/update",produces=MediaType.APPLICATION_JSON,  
description = "Class manage insert updates and check updates .")
public class UpdateEndpoint {
	@Context
	private HttpServletResponse response;
	@Context
	private HttpServletRequest request;

	/**
	 * Method processing HTTP GET requests, producing "application/json" MIME media-type.
	 * <p> 
	 * This method gives check updates available and list them for given device.
	 * </p>
	 * @param httpHeaders
	 * @return String that will be send back as a response of type json.
	 */
	@GET
	@Consumes({ MediaType.APPLICATION_JSON })
	@ApiOperation( value = "List of updates.", 
	notes = "List of updates.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_NOT_FOUND, message = "Device doesn't exists.")
	} )
	public void checkUpdates(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,
			@ApiParam(value = "HashTable", required = false) @QueryParam("details") String details)
	{
		mcheckUpdates(authToken, details);
	}
	
	

	/** Method processing HTTP POST requests, producing "application/json" MIME media type.
	 * <p>
	 * This method require application id, group id, version to insert update,
	 * input hashmap requires require these properties ( group id, version)
	 * </p>
	 * @param  hashmap 
	 * @param httpHeaders
	 * @return Json string
	 * @throws Exception 
	 */
	@POST
	@Consumes({MediaType.APPLICATION_JSON})
	@Path("/{appid}")
	@ApiOperation( value = "release update.",
	notes = "release update.")
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized.") 
	} )
	public void releaseUpdate(@Context HttpServletRequest request,@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,
			@ApiParam(value = "id of application.", required = true)  @NotNull @PathParam("appid") String appId,
			@ApiParam(value = " insert app.", required = true) HashMap<String, Object> updateObj) {
		mReleaseUpdate(authToken,appId,updateObj);
	}

	private void mcheckUpdates(String authToken,String updateDetailsParam)
	{
		try {
			AuthorizationsVO authvo = new AuthHelper().getAuthorizationsVO(authToken, Constants.AUTH_SERVER_IP_PORT);

			Hashtable<String, Object> updateDetails  = new Gson().fromJson(updateDetailsParam,new TypeToken<Hashtable<String, Object>>() {}.getType());
		
			
			String currentVersion = updateDetails.get("currentVersion").toString();
			String deviceId ="";
			String name = "";
			String hwPlatform = "";
			String swPlatform ="";
			if(updateDetails.containsKey("deviceId"))
			{
				 deviceId = updateDetails.get("deviceId").toString();
			}
			else
			{
				 name = updateDetails.get("name").toString();
				 hwPlatform = updateDetails.get("hwPlatform").toString();
				 swPlatform = updateDetails.get("swPlatform").toString();
			}

			AppUpdate updateObj= new AppUpdate();
			List<GroupReleaseVO> versions= 	updateObj.checkUpdates(name, hwPlatform, swPlatform, authvo.getUserId(), currentVersion,deviceId);
			HashMap<String, Object> resultMap=new HashMap<String, Object>();
			resultMap.put(Constant.DATA, versions);

			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);

		} catch (Exception e) {
			PALogger.ERROR(e);
			if(e.getMessage() != null && e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to list updates.", "Unable to list updates.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
		}
	}
	private void mReleaseUpdate(String authToken,String appId, HashMap<String, Object> updateDetails)
	{
		try {
			AuthorizationsVO authvo = new AuthHelper().getAuthorizationsVO(authToken, Constants.AUTH_SERVER_IP_PORT);

			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.UPDATE_GROUP_RELEASES_RELEASE));
			AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, true);

			
			String version = updateDetails.get("version").toString();
			String lastVersion = updateDetails.get("lastCompatibleVersion").toString();
			if(!isValidVersion(version))
				throw new InvalidParameterException("Invalid version.");
			if(!isValidVersion(lastVersion))
				throw new InvalidParameterException("Invalid last compatible version.");
			if(!compareVersion(version, lastVersion))
				throw new InvalidParameterException("Last compatible version can not be greater than version.");
			
			String grpId = updateDetails.get("grpId").toString();
			String metadata = updateDetails.get("metadata").toString();
			AppUpdate updateObj= new AppUpdate();
			updateObj.releaseUpdate(appId, version,lastVersion, grpId,metadata);
			
			new ActivityLogs().insert(authvo.getUserId(), ActivityOperation.releaseUpdate.name(), new Gson().toJson(updateDetails));
			ReturnObject.createResponse(Constant.SUCCESS, null, null, response);

		}
		catch (InvalidParameterException e) 
		{
			PALogger.ERROR(e);
			ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_BAD_REQUEST , e.getMessage(), e.getMessage());
			ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
		}
		catch (Exception e) {
			PALogger.ERROR(e);
			if(e.getMessage().equals(Constant.UNAUTHORIZED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to release update.", "Unable to release update.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
		}
	}
	
	private boolean isValidVersion(String version)
	{
		boolean isValid =false;
		String[] versionArr = version.split("\\.");
		if(versionArr.length != 4)
			return isValid;
		for (String number : versionArr) 
		{
			if(Integer.parseInt(number) != 0)
			{
				isValid= true;
				break;
			}
		}
			return isValid;
	}
	/**
	 * true if version is greater or equal to last version; 
	 * false if version is less than last version
	 * @param version
	 * @param lastVersion
	 * @return
	 */
	private boolean compareVersion(String version,String lastVersion)
	{
		String[] versionArr = version.split("\\.");
		String[] lastVersionArr = lastVersion.split("\\.");
		boolean versionGreater= false;
		boolean bothEqual= true;
		
		for (int i = 0; i < lastVersionArr.length; i++) 
		{
			if(Integer.parseInt(versionArr[i]) > Integer.parseInt(lastVersionArr[i]))
			{
				bothEqual =false;
				versionGreater =true;
				break;
			}
			if(Integer.parseInt(lastVersionArr[i]) > Integer.parseInt(versionArr[i]))
			{
				bothEqual =false;
				versionGreater =false;
				break;
			}
		}
		if(versionGreater || bothEqual)
			return true;
		else
			return false;
	}
	
	
}
