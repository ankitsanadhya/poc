package com.mwp.s.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.ValidationException;
import javax.validation.constraints.NotNull;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import com.google.gson.Gson;
import com.mwp.common.AuthHelper;
import com.mwp.common.ReturnObject;
import com.mwp.common.constant.Constant;
import com.mwp.common.constant.PermissionResources;
import com.mwp.common.enums.ActivityOperation;
import com.mwp.common.constant.PermissionResourceKeys;
import com.mwp.common.vo.ApplicationUserVO;
import com.mwp.common.vo.AuthorizationsVO;
import com.mwp.common.vo.ErrorVo;
import com.mwp.common.vo.GroupReleaseVO;
import com.mwp.logger.PALogger;
import com.mwp.p.common.AdminPermissionCheck;
import com.mwp.p.common.Constants;
import com.mwp.p.framework.ActivityLogs;
import com.mwp.s.common.GroupsVO;
import com.mwp.s.framework.Groups;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/** <h1>AppEndpoint</h1>
 * Class hosted at the URI path "/application"
 * <p>
 * Class manage  add,edit,delete,list apps
 * </p>
 */
//description = "Class manage add,delete,list groups and insert list and delete group users."
@Path("/groups")
@Api( value = "/groups",produces=MediaType.APPLICATION_JSON)
public class GroupsEndpoint
{
	//create group
	//delete group
	//List group
	//add users
	//delete users
	//list users
	@Context
	private HttpServletResponse response;
	@Context
	private HttpServletRequest request;

	/** Method processing HTTP POST requests, producing "application/json" MIME media type.
	 * <p>
	 * This method require name
	 * input hashmap requires require these properties ( name)
	 * </p>
	 * @param  hashmap 
	 * @param httpHeaders
	 * @return Json string
	 * @throws Exception 
	 */
	@POST
	@Consumes({MediaType.APPLICATION_JSON})
	@ApiOperation( value = "insert group.",
	notes = "insert group.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized.") 
	} )
	public void insertGroup(@Context HttpServletRequest request,@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,
			@ApiParam(value = " insert grp.", required = true) HashMap<String, Object> grpDetails) {
		mInsertGroup(authToken,grpDetails);
	}



	@GET
	@Consumes({MediaType.APPLICATION_JSON})
	@ApiOperation( value = "list group.",
	notes = "list group.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized.") 
	} )
	public void listGroup(@Context HttpServletRequest request,@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken
			) {
		mListGroup(authToken);
	}

	@GET
	@Path("/groupreleases/{grpid}")
	@Consumes({ MediaType.APPLICATION_JSON })
	@ApiOperation( value = "List group releases.", 
	notes = "List group releases.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
	} )
	public void listGroupReleases(@ApiParam(value = "id of group.", required = true)  @NotNull @PathParam("grpid") String grpid, @ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken)
	{
		mList(authToken, grpid);
	}
	
	@GET
	@Path("/listusers")
	@Consumes({ MediaType.APPLICATION_JSON })
	@ApiOperation( value = "List group releases.", 
	notes = "List portal users.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
	} )
	public void listPortalUsers(@HeaderParam("Authorization") String authToken,
			@ApiParam( value = "Pageing page no.", required = false ) @QueryParam("pageNo") @DefaultValue("0") final int pageNo,
					@ApiParam( value = "item per page to fetch", required = false ) @QueryParam("pageSize") final int pageSize,
					@ApiParam( value = "Search string", required = false )  @QueryParam("filters") String filters) 
	{
		mListPortalUsers(authToken,pageNo,pageSize,filters);
	}




	/** Method processing HTTP DELETE requests, producing "application/json" MIME media type.
	 * <p>
	 * This method delete  group from db.
	 * <p>
	 * @param grpId.
	 * @param httpHeaders
	 * @return
	 * @throws Exception 
	 */
	@DELETE
	@Consumes({MediaType.APPLICATION_JSON})
	@Path("/{grpid}")
	@ApiOperation( value = "Delete group.", 
	notes = "delete group.")
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_NOT_FOUND, message = "Group doesn't exists.")
	} )
	public void deleteGroup(@ApiParam(value = "id of group.", required = true)  @NotNull @PathParam("grpid") String grpid,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken) throws ValidationException {
		mDeleteGroup(authToken, grpid);
	}

	///////////////grp users
	/** Method processing HTTP POST requests, producing "application/json" MIME media type.
	 * <p>
	 * This method require appusersids,grpid
	 * </p>
	 * @param  hashmap 
	 * @param httpHeaders
	 * @return Json string
	 * @throws Exception 
	 */
	@POST
	@Consumes({MediaType.APPLICATION_JSON})
	@Path("/{grpid}")
	@ApiOperation( value = "insert group users.",
	notes = "insert group users.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized.") 
	} )
	public void insertUsers(@Context HttpServletRequest request,@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,
			@ApiParam(value = "id of group.", required = true)  @NotNull @PathParam("grpid") String grpid,
			@ApiParam(value = " insert users.", required = true) List<String> appUserIds) {
		mInsertUsers(authToken, grpid, appUserIds);
	}



	@GET
	@Consumes({MediaType.APPLICATION_JSON})
	@Path("/{grpid}")
	@ApiOperation( value = "list group users.",
	notes = "list group users.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized.") 
	} )
	public void listGroupUsers(@Context HttpServletRequest request,@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,
			@ApiParam(value = "id of group.", required = true)  @NotNull @PathParam("grpid") String grpid) {
		mListUsers(authToken, grpid);
	}



	/** Method processing HTTP DELETE requests, producing "application/json" MIME media type.
	 * <p>
	 * This method delete  group users from db.
	 * <p>
	 * @param grpId.
	 * @param httpHeaders
	 * @return
	 * @throws Exception 
	 */
	@DELETE
	@Consumes({MediaType.APPLICATION_JSON})
	@Path("/{grpid}/users")
	@ApiOperation( value = "Delete group user.", 
	notes = "delete group user.")
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_NOT_FOUND, message = "Group user doesn't exists.")
	} )
	public void deleteUser(@ApiParam(value = "id of group.", required = true)  @NotNull @PathParam("grpid") String grpid,
			@ApiParam(value = " insert users.", required = true) List<String> appUserIds,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken) throws ValidationException {
		mDeleteUser(authToken, grpid, appUserIds);
	}




	private void mInsertGroup(String authToken, HashMap<String, Object> grpDetails) 
	{
		try {
			AuthorizationsVO authvo = new AuthHelper().getAuthorizationsVO(authToken, Constants.AUTH_SERVER_IP_PORT);

			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.UPDATE_GROUP_ADD));
			AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, true);
//			if(authvo.getRole() != RoleEnum.Admin) 
//			{
//				throw new Exception(Constant.UNAUTHORIZED);
//			}
			String name = grpDetails.get("name").toString();

			Groups obj= new Groups();
			GroupsVO retObj=	obj.addGrp(name);
			
			//insert activity
			new ActivityLogs().insert(authvo.getUserId(), ActivityOperation.insertUpdateGroup.name(), new Gson().toJson(retObj));
			HashMap<String, Object> resultMap=new HashMap<String, Object>();
			resultMap.put(Constant.DATA, retObj);			
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);

		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to insert group.", "Unable to insert group.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			PALogger.ERROR(e);
		}

	}

	private void mListGroup(String authToken) {
		try {
			AuthorizationsVO authvo = new AuthHelper().getAuthorizationsVO(authToken, Constants.AUTH_SERVER_IP_PORT);
			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.UPDATE_GROUP_LIST));
			AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, true);
//			if(authvo.getRole() != RoleEnum.Admin) 
//			{
//				throw new Exception(Constant.UNAUTHORIZED);
//			}
			Groups obj= new Groups();
			List<GroupsVO> retLst=	obj.listGrp();

			HashMap<String, Object> resultMap=new HashMap<String, Object>();
			resultMap.put(Constant.DATA, retLst);			
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);

		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to list group", "Unable to list group.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			PALogger.ERROR(e);
		}

	}
	private void mDeleteGroup(String authToken, String grpid) {
		try {
			AuthorizationsVO authvo = new AuthHelper().getAuthorizationsVO(authToken, Constants.AUTH_SERVER_IP_PORT);

			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.UPDATE_GROUP_DELETE));
			AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, true);
//			if(authvo.getRole() != RoleEnum.Admin) 
//			{
//				throw new Exception(Constant.UNAUTHORIZED);
//			}
			Groups obj= new Groups();
			obj.deleteGrp(grpid);
			Map<String, Object> map = new HashMap<>();
			map.put("groupId", grpid);
			new ActivityLogs().insert(authvo.getUserId(), ActivityOperation.deleteUpdateGroup.name(), new Gson().toJson(map));

			ReturnObject.createResponse(Constant.SUCCESS, null, null, response);

		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to delete group", "Unable to delete app.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			PALogger.ERROR(e);
		}

	}

	////////grp users//////////


	private void mInsertUsers(String authToken,String grpId,List<String> appUserIds) 
	{
		try {
			AuthorizationsVO authvo = new AuthHelper().getAuthorizationsVO(authToken, Constants.AUTH_SERVER_IP_PORT);

			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.UPDATE_GROUP_USER_ADD));
			AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, true);
//			if(authvo.getRole() != RoleEnum.Admin) 
//			{
//				throw new Exception(Constant.UNAUTHORIZED);
//			}
			Groups obj= new Groups();
			obj.addUsers(grpId, appUserIds);

			//insert activity
			Map<String, Object> map = new HashMap<>();
			map.put("groupId", grpId);
			map.put("appUserids", appUserIds);
			new ActivityLogs().insert(authvo.getUserId(), ActivityOperation.insertUpdateGroupUser.name(), new Gson().toJson(map));
			ReturnObject.createResponse(Constant.SUCCESS, null, null, response);

		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to insert user.", "Unable to insert user.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			PALogger.ERROR(e);
		}

	}

	private void mListUsers(String authToken,String grpID) {
		try {
			AuthorizationsVO authvo = new AuthHelper().getAuthorizationsVO(authToken, Constants.AUTH_SERVER_IP_PORT);

			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.UPDATE_GROUP_USER_LIST));
			AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, true);
//			if(authvo.getRole() != RoleEnum.Admin) 
//			{
//				throw new Exception(Constant.UNAUTHORIZED);
//			}
			Groups obj= new Groups();
			List<ApplicationUserVO> retLst=	obj.ListUsers(grpID);

			HashMap<String, Object> resultMap=new HashMap<String, Object>();
			resultMap.put(Constant.DATA, retLst);			
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);

		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to list uses", "Unable to list user.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			PALogger.ERROR(e);
		}

	}
	private void mDeleteUser(String authToken, String grpid, List<String> appUserIds) {
		try {
			AuthorizationsVO authvo = new AuthHelper().getAuthorizationsVO(authToken, Constants.AUTH_SERVER_IP_PORT);

			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.UPDATE_GROUP_USER_DELETE));
			AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, true);

			Groups obj= new Groups();
			obj.deleteUser(appUserIds, grpid);

			Map<String, Object> map = new HashMap<>();
			map.put("groupId", grpid);
			map.put("appUserids", appUserIds);
			new ActivityLogs().insert(authvo.getUserId(), ActivityOperation.deleteUpdateGroupUser.name(), new Gson().toJson(map));

			ReturnObject.createResponse(Constant.SUCCESS, null, null, response);

		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to delete user", "Unable to delete user.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			PALogger.ERROR(e);
		}

	}

	private void mList(String authToken, String grpid)
	{
		try {
			AuthorizationsVO authvo = new AuthHelper().getAuthorizationsVO(authToken, Constants.AUTH_SERVER_IP_PORT);

			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.UPDATE_GROUP_USER_LIST));
			AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, true);

			Groups groups= new Groups();
			List<GroupReleaseVO> groupReleases = groups.list(grpid);
			HashMap<String, Object> resultMap=new HashMap<>();
			resultMap.put(Constant.DATA, groupReleases);

			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);

		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to list group releases.", "Unable to list group releases.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			PALogger.ERROR(e);
		}
	}



	private void mListPortalUsers(String authToken,int pageNumber,int pageSize, String filters)
	{
		try {
			AuthorizationsVO authvo = new AuthHelper().getAuthorizationsVO(authToken, Constants.AUTH_SERVER_IP_PORT);
			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.UPDATE_GROUP_USER_LIST));
			AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, true);

			Groups groups= new Groups();
			HashMap<String, Object> output = groups.listPortalUsers(authToken,pageNumber,pageSize,filters);


			ReturnObject.createResponse(Constant.SUCCESS, output, null, response);

		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to list group releases.", "Unable to list group releases.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			PALogger.ERROR(e);
		}
	}

}
