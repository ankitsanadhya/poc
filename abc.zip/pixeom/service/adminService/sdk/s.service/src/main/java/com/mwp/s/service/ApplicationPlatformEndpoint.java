package com.mwp.s.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.ValidationException;
import javax.validation.constraints.NotNull;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import com.google.gson.Gson;
import com.mwp.common.AuthHelper;
import com.mwp.common.ReturnObject;
import com.mwp.common.constant.Constant;
import com.mwp.common.constant.PermissionResources;
import com.mwp.common.enums.ActivityOperation;
import com.mwp.common.constant.PermissionResourceKeys;
import com.mwp.common.vo.AuthorizationsVO;
import com.mwp.common.vo.ErrorVo;
import com.mwp.logger.PALogger;
import com.mwp.p.common.AdminPermissionCheck;
import com.mwp.p.common.Constants;
import com.mwp.p.framework.ActivityLogs;
import com.mwp.s.common.ApplicationUpdatePlatformVO;
import com.mwp.s.framework.ApplicationPlatform;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/** <h1>AppEndpoint</h1>
 * Class hosted at the URI path "/application"
 * <p>
 * Class manage  add,edit,delete,list apps
 * </p>
 */
@Path("/application")
@Api( value = "/application",produces=MediaType.APPLICATION_JSON,  
description = "Class manage add,edit,delete,list apps.")
public class ApplicationPlatformEndpoint 
{
	@Context
	private HttpServletResponse response;
	@Context
	private HttpServletRequest request;

	/** Method processing HTTP PUT requests, producing "application/json" MIME media type.
	 * <p>
	 * This method require metadata,appid
	 * input hashmap requires require these properties ( metadata)
	 * </p>
	 * @param  hashmap 
	 * @param httpHeaders
	 * @return Json string
	 * @throws Exception 
	 */
	@PUT
	@Consumes({MediaType.APPLICATION_JSON})
	@Path("/{appid}")
	@ApiOperation( value = "update app.",
	notes = "update app.")
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized.") 
	} )
	public void UpdateApp(@Context HttpServletRequest request,@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,
			@ApiParam( value = "id of application.", required = true ) @PathParam("appid") String appId,
			@ApiParam(value = " update app.", required = true) HashMap<String, Object> appDetails) {
		mUpdateApp(authToken,appId,appDetails);
	}
	
	
	/** Method processing HTTP POST requests, producing "application/json" MIME media type.
	 * <p>
	 * This method require name, hwPlatform, swPlatform, metadata
	 * input hashmap requires require these properties ( name, hwPlatform, swPlatform, metadata)
	 * </p>
	 * @param  hashmap 
	 * @param httpHeaders
	 * @return Json string
	 * @throws Exception 
	 */
	@POST
	@Consumes({MediaType.APPLICATION_JSON})
	@ApiOperation( value = "insert app.",
	notes = "insert app.")
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized.") 
	} )
	public void insertApp(@Context HttpServletRequest request,@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,
			@ApiParam(value = " insert app.", required = true) HashMap<String, Object> appDetails) {
		mInsertApp(authToken,appDetails);
	}

	@GET
	@Consumes({MediaType.APPLICATION_JSON})
	@ApiOperation( value = "list apps.",
	notes = "list app.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized.") 
	} )
	public void listApps(@Context HttpServletRequest request,@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken
		) {
		mListApp(authToken);
	}
	
	/** Method processing HTTP DELETE requests, producing "application/json" MIME media type.
	 * <p>
	 * This method delete  application info from db.
	 * <p>
	 * @param appId.
	 * @param httpHeaders
	 * @return
	 * @throws Exception 
	 */
	@DELETE
	@Consumes({MediaType.APPLICATION_JSON})
	@Path("/{appid}")
	@ApiOperation( value = "Delete  application .", 
	notes = "delete application.")
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_NOT_FOUND, message = "Application detail doesn't exists.")
	} )
	public void delete(@ApiParam(value = "id of application.", required = true)  @NotNull @PathParam("appid") String appId,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken) throws ValidationException {
		mDelete(authToken, appId);
	}

	private void mInsertApp(String authToken,HashMap<String, Object> appDetails)
	{
		try {
			AuthorizationsVO authvo = new AuthHelper().getAuthorizationsVO(authToken, Constants.AUTH_SERVER_IP_PORT);

			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.UPDATE_APP_ADD));
			AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, true);
			
//			if(authvo.getRole() != RoleEnum.Admin) 
//			{
//				throw new Exception(Constant.UNAUTHORIZED);
//			}
			String name = appDetails.get("name").toString();
			String hwPlatform = appDetails.get("hwPlatform").toString();
			String swPlatform = appDetails.get("swPlatform").toString();

			String metadata = appDetails.get("metadata").toString();

			//name, hwPlatform, swPlatform, metadata
			ApplicationPlatform obj= new ApplicationPlatform();
			ApplicationUpdatePlatformVO retObj=	obj.Insert(name, hwPlatform, swPlatform, metadata);

			//insert activity
			new ActivityLogs().insert(authvo.getUserId(), ActivityOperation.insertApp.name(), new Gson().toJson(appDetails));

			HashMap<String, Object> resultMap=new HashMap<String, Object>();
			resultMap.put(Constant.DATA, retObj);			
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);

		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			} 
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e.getMessage(),"Unable to insert app.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			PALogger.ERROR(e);
		}
	}
	
	private void mListApp(String authToken)
	{
		try {
			AuthorizationsVO authvo = new AuthHelper().getAuthorizationsVO(authToken, Constants.AUTH_SERVER_IP_PORT);

			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.UPDATE_APP_LIST));
			AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, true);

			ApplicationPlatform obj= new ApplicationPlatform();
			List<ApplicationUpdatePlatformVO> retLst=	obj.listApp();

			HashMap<String, Object> resultMap=new HashMap<String, Object>();
			resultMap.put(Constant.DATA, retLst);			
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);

		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to list app", "Unable to list app.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			PALogger.ERROR(e);
		}
	}
	
	private void mUpdateApp(String authToken, String appID, HashMap<String, Object> appDetails)
	{
		try {
			AuthorizationsVO authvo = new AuthHelper().getAuthorizationsVO(authToken, Constants.AUTH_SERVER_IP_PORT);

			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.UPDATE_APP_EDIT));
			AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, true);
//			if(authvo.getRole() != RoleEnum.Admin) 
//			{
//				throw new Exception(Constant.UNAUTHORIZED);
//			}
			String metadata = appDetails.get("metadata").toString();
			String name = "";
			String hwPlatform ="";
			String swPlatform ="";
			if(appDetails.containsKey("name"))
				name = appDetails.get("name").toString();
			if(appDetails.containsKey("hwPlatform"))
				hwPlatform = appDetails.get("hwPlatform").toString();
			if(appDetails.containsKey("swPlatform"))
				swPlatform = appDetails.get("swPlatform").toString();

			//name, hwPlatform, swPlatform, metadata
			ApplicationPlatform obj= new ApplicationPlatform();
			obj.Update(appID, name, hwPlatform, swPlatform, metadata);
			
			//insert activity
			Map<String, Object> map = new HashMap<>();
			map.put("appId", appID);
			new ActivityLogs().insert(authvo.getUserId(), ActivityOperation.updateApp.name(), new Gson().toJson(map));
			
//			HashMap<String, Object> resultMap=new HashMap<String, Object>();
//			resultMap.put(Constant.DATA, retObj);			
			ReturnObject.createResponse(Constant.SUCCESS, null, null, response);

		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e.getMessage(),"Unable to update app.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			PALogger.ERROR(e);
		}
	}
	
	
	private void mDelete(String authToken, String appId)
	{
		try {
			AuthorizationsVO authvo = new AuthHelper().getAuthorizationsVO(authToken, Constants.AUTH_SERVER_IP_PORT);

			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.UPDATE_APP_DELETE));
			AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, true);

			ApplicationPlatform obj= new ApplicationPlatform();
			obj.delete(appId);
			
			//insert activity
			Map<String, Object> map = new HashMap<>();
			map.put("appId", appId);
			new ActivityLogs().insert(authvo.getUserId(), ActivityOperation.deleteApp.name(), new Gson().toJson(map));
			
			ReturnObject.createResponse(Constant.SUCCESS, null, null, response);

		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to delete app", "Unable to delete app.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			PALogger.ERROR(e);
		}
	}
	
	//delete app
	//update app
	//list
}
