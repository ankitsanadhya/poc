package com.mwp.s.application;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

import org.glassfish.jersey.media.multipart.MultiPartFeature;

import com.mwp.logger.PALogger;
import com.mwp.s.engine.UpdateDatabaseEngine;

import io.swagger.jaxrs.config.BeanConfig;

@ApplicationPath("/api")
public class ApplicationConfig extends Application {



	public ApplicationConfig() {
		BeanConfig beanConfig = new BeanConfig();
		beanConfig.setVersion("1.0.2");
		//        beanConfig.setSchemes(new String[]{"http"});
		//        beanConfig.setHost("localhost:8880");
		beanConfig.setBasePath("/s.service/api");
		beanConfig.setResourcePackage("com.mwp.s.service");
		beanConfig.setScan(true);
		
		UpdateDatabaseEngine.getInstance();
	}



	@Override
	public Set<Class<?>> getClasses() {

		Set<Class<?>> resources = new java.util.HashSet<>();

		PALogger.INFO("REST configuration starting: getClasses()");            

		//features
		//this will register Jackson JSON providers
		resources.add(org.glassfish.jersey.jackson.JacksonFeature.class);
		//we could also use this:
		//resources.add(com.fasterxml.jackson.jaxrs.json.JacksonJaxbJsonProvider.class);

		//instead let's do it manually:
//		resources.add(AuthJacksonJsonProvider.class);
//		resources.add(ApplicationsEndpoint.class);
//		resources.add(BannersEndpoint.class);
//		resources.add(CategoriesEndpoint.class);
//		resources.add(DeveloperApplicationsEndpoint.class);
//		resources.add(DevicesEndpoint.class);
//		resources.add(FiltersEndpoint.class);
//		resources.add(GroupsEndpoint.class);
//		resources.add(ProjectsEndpoint.class);
//		resources.add(SortsEndpoint.class);
//		resources.add(ApplicationVersionsEndpoint.class);
//		resources.add(PermissionEndpoint.class);
//		resources.add(ApplicationServiceEndpoint.class);
//		resources.add(LoginEndpoint.class);
//		resources.add(UserEndPoint.class);
//		resources.add(LogoutEndpoint.class);
//		resources.add(PortalStartEndpoint.class);
//		resources.add(DockerWebTokenEndPoint.class);
//		resources.add(TestEndPoint.class);
		//==> we could also choose packages, see below getProperties()

		resources.add(MultiPartFeature.class);
		resources.add(io.swagger.jaxrs.listing.ApiListingResource.class);
		resources.add(io.swagger.jaxrs.listing.SwaggerSerializers.class);

		PALogger.INFO("REST configuration ended successfully.");
		return resources;
	}

	@Override
	public Set<Object> getSingletons() {
		return Collections.emptySet();
	}

	@Override
	public Map<String, Object> getProperties() {
		Map<String, Object> properties = new HashMap<>();

		//in Jersey WADL generation is enabled by default, but we don't 
		//want to expose too much information about our apis.
		//therefore we want to disable wadl (http://localhost:8080/service/application.wadl should return http 404)
		//see https://jersey.java.net/nonav/documentation/latest/user-guide.html#d0e9020 for details
		//properties.put("jersey.config.server.wadl.disableWadl", true);

		//we could also use something like this instead of adding each of our resources
		//explicitly in getClasses():
		//properties.put("jersey.config.server.provider.packages", "com.nabisoft.tutorials.mavenstruts.service");
		properties.put("jersey.config.server.provider.packages", "com.mwp.s");

		return properties;
	}    
}