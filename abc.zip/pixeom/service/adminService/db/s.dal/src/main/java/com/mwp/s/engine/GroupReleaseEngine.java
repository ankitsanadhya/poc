package com.mwp.s.engine;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.management.Query;
import javax.xml.crypto.dsig.keyinfo.RetrievalMethod;

import com.mwp.common.Common;
import com.mwp.common.StringFunctions;
import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.common.vo.GroupReleaseVO;
import com.mwp.common.vo.QueryVO;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.s.common.enums.UpdateServiceDBEnum;
import com.mwp.s.dal.ApplicationPlatformDB;
import com.mwp.s.dal.GroupReleaseDB;
import com.mwp.s.dal.GroupUserDB;

public class GroupReleaseEngine {

	public void Insert(String grpId, String appId, String version, String lastVersion, String metadata)
			throws SQLException {
		mInsert(grpId, appId, version, lastVersion, metadata);
	}

	public List<GroupReleaseVO> checkUpdates(String name, String hwPlatform, String swPlatform, String appUserId,
			String currentVersion, String deviceId) throws SQLException {
		return mCheckUpdates(name, hwPlatform, swPlatform, appUserId, currentVersion, deviceId);
	}

	private void mInsert(String grpId, String appId, String version, String lastVersion, String metadata)
			throws SQLException {
		GroupReleaseDB dbObj = new GroupReleaseDB();
		String grpReleaseId = mIsExists(grpId, appId);
		String sql = "";
		QueryVO queryVO = null;
		if (StringFunctions.isNullOrWhitespace(grpReleaseId)) {
			sql = dbObj.Insert();

			queryVO = new SqlQueryBuilder(UpdateDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
					.appendQuery(sql).addParameter(Common.getRandomId()).addParameter(grpId).addParameter(appId)
					.addParameter(version).addParameter(lastVersion).addParameter(metadata).build();

		} else {
			sql = dbObj.Update();

			queryVO = new SqlQueryBuilder(UpdateDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
					.appendQuery(sql).addParameter(version).addParameter(metadata).addParameter(lastVersion)
					.addParameter(grpReleaseId).build();
		}

		UpdateDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
	}
	// String[] versionArr = currentVersion.split("\\.");
	// sb.append("Select * ");
	// sb.append(" FROM ");
	// sb.append(UpdateServiceDBEnum.TABLE_NAMES.groupRelease);
	// sb.append(" WHERE ");
	// sb.append(UpdateServiceDBEnum.APP_GROUP_RELEASE.groupId);
	//
	// sb.append(getUserGroupIDsByIN(userGroupIDs));
	//// sb.append(" IN (SELECT 'ALL' UNION (");
	//// sb.append(new GroupUserDB().getUserGroupIDs(appUserId));
	//
	// sb.append(" and ");
	//
	// sb.append(UpdateServiceDBEnum.APP_GROUP_RELEASE.appId);
	//
	// SqlQueryBuilder builder = new SqlQueryBuilder();
	// builder.appendQueryIN(appIdCount);
	//
	//// sb.append(" IN (");
	//// if (!StringFunctions.isNullOrWhitespace(deviceId))
	//// sb.append(new ApplicationPlatformDB().getAppIdByDeviceId(deviceId,
	// appUserId));
	//// else
	//// sb.append(new ApplicationPlatformDB().getAppId(name, hwPlatform,
	// swPlatform));
	//// sb.append(")");
	//
	// sb.append(" and ");
	// sb.append("CONCAT(");
	// sb.append("LPAD(SUBSTRING_INDEX(SUBSTRING_INDEX(version, '.', 1), '.',
	// -1), 10, '0'),");
	// sb.append("LPAD(SUBSTRING_INDEX(SUBSTRING_INDEX(version, '.', 2), '.',
	// -1), 10, '0'),");
	// sb.append("LPAD(SUBSTRING_INDEX(SUBSTRING_INDEX(version, '.', 3), '.',
	// -1), 10, '0'),");
	// sb.append("LPAD(SUBSTRING_INDEX(SUBSTRING_INDEX(version, '.', 4), '.',
	// -1), 10, '0')");
	// sb.append(") ");
	// sb.append(" > ");
	// sb.append("CONCAT(");
	// sb.append("LPAD(");
	// sb.append("?");
	// //sb.append(versionArr[0]);
	// sb.append(", 10, '0'),");
	// sb.append("LPAD(");
	// sb.append("?");
	//// sb.append(versionArr[1]);
	// sb.append(", 10, '0'),");
	// sb.append("LPAD(");
	// sb.append("?");
	//// sb.append(versionArr[2]);
	// sb.append(", 10, '0'),");
	// sb.append("LPAD(");
	// sb.append("?");
	//// sb.append(versionArr[3]);
	// sb.append(", 10, '0')");
	// sb.append(")");

	private List<GroupReleaseVO> mCheckUpdates(String name, String hwPlatform, String swPlatform, String appUserId,
			String currentVersion, String deviceId) throws SQLException {
		List<GroupReleaseVO> versions = new ArrayList<>();

		List<String> groupIds = getGroupIds(appUserId);
		List<String> appIds = getAppIds(name, hwPlatform, swPlatform, appUserId, deviceId);

		GroupReleaseDB releaseDb = new GroupReleaseDB();

		String[] versionArr = currentVersion.split("\\.");

		if(groupIds.isEmpty()){
			groupIds.add("");
		}
		
		if(appIds.isEmpty()){
			appIds.add("");
		}
		
		String sql = releaseDb.get(groupIds, appIds);

		QueryVO queryVO = new SqlQueryBuilder(
				UpdateDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameters(groupIds).addParameters(appIds).addParameter(versionArr[0])
						.addParameter(versionArr[1]).addParameter(versionArr[2]).addParameter(versionArr[3]).build();

		try (ResultSet rs = UpdateDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				versions.add(parseGroupReleaseVO(rs));
			}
		}
		return versions;
	}

	private List<String> getAppIds(String name, String hwPlatform, String swPlatform, String appUserId, String deviceId)
			throws SQLException {

		QueryVO queryVO = null;
		List<String> appIds = new ArrayList<>();
		if (!StringFunctions.isNullOrWhitespace(deviceId)) {
			String sql = new ApplicationPlatformDB().getAppIdByDeviceId();
			queryVO = new SqlQueryBuilder(UpdateDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
					.appendQuery(sql).addParameter("Appliance").addParameter(deviceId).addParameter(appUserId).build();

		} else {
			String sql = new ApplicationPlatformDB().getAppId();
			queryVO = new SqlQueryBuilder(UpdateDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
					.appendQuery(sql).addParameter(name).addParameter(hwPlatform).addParameter(swPlatform).build();
		}

		try (ResultSet rs = UpdateDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				appIds.add(rs.getString(UpdateServiceDBEnum.APP_PLATFORM.appId.name()));
			}
		}

		return appIds;
	}

	private List<String> getGroupIds(String appUserId) throws SQLException {
		String sql = new GroupUserDB().getUserGroupIDs();
		List<String> list = new ArrayList<>();

		QueryVO queryVO = new SqlQueryBuilder(
				UpdateDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(appUserId).build();

		try (ResultSet rs = UpdateDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				list.add(rs.getString(UpdateServiceDBEnum.APP_GROUP_USERS.groupId.name()));
			}
		}

		return list;
	}

	public List<GroupReleaseVO> list(String grpid) throws SQLException {
		return mList(grpid);
	}

	private List<GroupReleaseVO> mList(String grpid) throws SQLException {
		List<GroupReleaseVO> groupReleases = new ArrayList<>();
		GroupReleaseDB releaseDb = new GroupReleaseDB();
		String sql = releaseDb.list();

		QueryVO queryVO = new SqlQueryBuilder(
				UpdateDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(grpid).build();

		try (ResultSet rs = UpdateDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				groupReleases.add(parseGroupReleaseVO(rs));
			}
		}
		return groupReleases;
	}

	private GroupReleaseVO parseGroupReleaseVO(ResultSet rs) throws SQLException {
		GroupReleaseVO groupRelease = new GroupReleaseVO();
		groupRelease.setAppId(rs.getString(UpdateServiceDBEnum.APP_GROUP_RELEASE.appId.name()).toString());
		groupRelease.setGroupId(rs.getString(UpdateServiceDBEnum.APP_GROUP_RELEASE.groupId.name()).toString());
		groupRelease
				.setGrpReleaseId(rs.getString(UpdateServiceDBEnum.APP_GROUP_RELEASE.grpReleaseId.name()).toString());
		groupRelease.setMetadata(rs.getString(UpdateServiceDBEnum.APP_GROUP_RELEASE.metadata.name()).toString());
		groupRelease.setVersion(rs.getString(UpdateServiceDBEnum.APP_GROUP_RELEASE.version.name()).toString());
		groupRelease.setLastCompatibleVersion(
				rs.getString(UpdateServiceDBEnum.APP_GROUP_RELEASE.lastCompatibleVersion.name()).toString());

		return groupRelease;
	}

	private String mIsExists(String grpID, String appId) throws SQLException {
		GroupReleaseDB dbObj = new GroupReleaseDB();
		String sql = dbObj.IsExists();
		QueryVO queryVO = new SqlQueryBuilder(
				UpdateDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(grpID).addParameter(appId).build();

		try (ResultSet rs = UpdateDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				return rs.getString(UpdateServiceDBEnum.APP_GROUP_RELEASE.grpReleaseId.name());
			}
		}
		return "";
	}
}
