package com.mwp.s.dal;

import java.util.List;

import com.mwp.common.Common;
import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.db.Interface.IConnection;
import com.mwp.p.common.Constants;
import com.mwp.s.common.enums.UpdateServiceDBEnum;
import com.mwp.s.engine.UpdateDatabaseEngine;

public class GroupUserDB {

	public String Insert() {
		return mInsert();
	}

	public String Delete(List<String> appUserIds) {
		return mDelete(appUserIds);
	}

	public String ListUsers() {
		return mListUsers();
	}

//	public String GetUser(String appUserId, String grpID) {
//		return mGet(appUserId, grpID);
//	}

	private String mInsert() {
		StringBuilder sb = new StringBuilder();
		sb.append("INSERT INTO ");
		sb.append(UpdateServiceDBEnum.TABLE_NAMES.groupUsers);
		sb.append(" ( ");
		sb.append(UpdateServiceDBEnum.APP_GROUP_USERS.grpUserId.name());
		sb.append(", ");
		sb.append(UpdateServiceDBEnum.APP_GROUP_USERS.groupId.name());
		sb.append(", ");
		sb.append(UpdateServiceDBEnum.APP_GROUP_USERS.appUserId.name());
		sb.append(", ");
		sb.append(UpdateServiceDBEnum.APP_GROUPS.dateCreated.name());
		sb.append(", ");
		sb.append(UpdateServiceDBEnum.APP_GROUPS.dateModified.name());
		sb.append(" ) VALUES ( ");
		sb.append("?");
		//sb.append(dbCon.formatString(Common.getRandomId()));
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(grpId));
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(appUserId));
		sb.append(", ");
		sb.append(" NOW()");
		sb.append(", ");
		sb.append(" NOW()");
		sb.append(" ) ");
		return sb.toString();
	}

	public String getUserGroupIDs() {
		return mGetUserGroupIDs();
	}

	private String mGetUserGroupIDs() {
		StringBuilder sb = new StringBuilder();
		sb.append("Select distinct ");
		sb.append(UpdateServiceDBEnum.APP_GROUP_USERS.groupId.name());
		sb.append(" FROM ");
		sb.append(UpdateServiceDBEnum.TABLE_NAMES.groupUsers);
		sb.append(" WHERE ");
		sb.append(UpdateServiceDBEnum.APP_GROUP_USERS.appUserId);
		sb.append(" = ");
		sb.append("?");
		//sb.append(dbCon.formatString(appUserId));

		return sb.toString();
	}

	private String mDelete(List<String> appUserIds) {
		SqlQueryBuilder builder = new SqlQueryBuilder();
		builder.appendQuery("DELETE ");
		builder.appendQuery(" FROM ");
		builder.appendQuery(UpdateServiceDBEnum.TABLE_NAMES.groupUsers);
		builder.appendQuery(" WHERE ");
		builder.appendQuery(UpdateServiceDBEnum.APP_GROUP_USERS.appUserId);
		builder.appendQueryIN(appUserIds);
//		builder.appendQuery(" IN (");
//		builder.appendQuery(dbCon.formatStringForIn(appUserIds));
//		builder.appendQuery(")");
		
		builder.appendQuery(" AND ");
		builder.appendQuery(UpdateServiceDBEnum.APP_GROUP_USERS.groupId);
		builder.appendQuery(" = ");
		//builder.appendQuery(dbCon.formatString(grpID));
		builder.appendQuery("?");
		return builder.getQuery().toString();
	}

	private String mListUsers() {
		// SELECT * FROM AuthDb.Users INNER JOIN AuthDb.ApplicationUser ON
		// (AuthDb.Users.userId = AuthDb.ApplicationUser.userId) inner join
		// groupUsers on groupUsers.appUserId = AuthDb.ApplicationUser.appUserId
		// WHERE AuthDb.ApplicationUser. appId =
		// '41ff73c9719a42bdb0348355114ceb82';
		/*
		 * StringBuilder sb = new StringBuilder(); sb.append("SELECT * ");
		 * sb.append(" FROM ");
		 * sb.append(UpdateServiceDBEnum.TABLE_NAMES.groupUsers);
		 * sb.append(" WHERE ");
		 * sb.append(UpdateServiceDBEnum.APP_GROUP_USERS.groupId);
		 * sb.append(" = "); sb.append(dbCon.formatString(grpID));
		 * 
		 * return sb.toString();
		 */
//dbCon.formatString(Constants.PORTAL_APPLICATION_ID)
		return "SELECT AuthDb.ApplicationUser.appUserId, AuthDb.Users.firstName,AuthDb.Users.lastName, AuthDb.Users.emailId, AuthDb.Users.profilePicturePath FROM AuthDb.Users INNER JOIN AuthDb.ApplicationUser ON (AuthDb.Users.userId = AuthDb.ApplicationUser.userId) inner join groupUsers on groupUsers.appUserId = AuthDb.ApplicationUser.appUserId WHERE AuthDb.ApplicationUser. appId = "
				+ "?" + " and groupUsers.groupId ="
				+ "?";
	}

//	private String mGet(String appUserId, String grpID) {
//		StringBuilder sb = new StringBuilder();
//		sb.append("SELECT * ");
//		sb.append(" FROM ");
//		sb.append(UpdateServiceDBEnum.TABLE_NAMES.groupUsers);
//		sb.append(" WHERE ");
//		sb.append(UpdateServiceDBEnum.APP_GROUP_USERS.appUserId);
//		sb.append(" = ");
//		sb.append(dbCon.formatString(appUserId));
//		sb.append(" AND ");
//		sb.append(UpdateServiceDBEnum.APP_GROUP_USERS.groupId);
//		sb.append(" = ");
//		sb.append(dbCon.formatString(grpID));
//
//		return sb.toString();
//	}

	// add
	// delete
	// list
	// getUSer
}
