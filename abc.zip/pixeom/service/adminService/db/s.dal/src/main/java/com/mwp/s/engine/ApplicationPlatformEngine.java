package com.mwp.s.engine;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import com.mwp.common.Common;
import com.mwp.common.StringFunctions;
import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.common.vo.QueryVO;
import com.mwp.s.common.ApplicationUpdatePlatformVO;
import com.mwp.s.common.enums.UpdateServiceDBEnum;
import com.mwp.s.dal.ApplicationPlatformDB;

public class ApplicationPlatformEngine
{

	public ApplicationUpdatePlatformVO Insert(String name,String hwPlatform, String swPlatform, String metadata) throws SQLException 
	{
		return mInsert( name, hwPlatform, swPlatform, metadata);
	}
	//	public String isExists(String name,String hwPlatform, String swPlatform) throws SQLException 
	//	{
	//		return mIsExists(name, hwPlatform, swPlatform);
	//	}
	public void Update(String appID,String name, String hwPlatform,String swPlatform, String metadata) throws SQLException 
	{
		mUpdate(appID,name, hwPlatform, swPlatform, metadata);
	}

	public void delete(String appID) throws SQLException 
	{
		mDelete(appID);
	}

	public ApplicationUpdatePlatformVO get(String appId) throws SQLException 
	{
		return mget(appId);
	}

	public List<ApplicationUpdatePlatformVO> listApp() throws SQLException 
	{
		return mList();
	}

	private String mIsExists(String name, String hwPlatform, String swPlatform) throws SQLException {
		String appId = "";
		ApplicationPlatformDB dbObj = new ApplicationPlatformDB();
		// String sql = dbObj.getAppId(name, hwPlatform, swPlatform);
		String sql = dbObj.getAppId();

		QueryVO queryVO = new SqlQueryBuilder(
				UpdateDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(name).addParameter(hwPlatform).addParameter(swPlatform).build();

		try (ResultSet rs = UpdateDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				appId = rs.getString(UpdateServiceDBEnum.APP_PLATFORM.appId.name());
			}
		}
		return appId;
	}

	private ApplicationUpdatePlatformVO mInsert(String name, String hwPlatform, String swPlatform, String metadata)
			throws SQLException {
		ApplicationPlatformDB dbObj = new ApplicationPlatformDB();
		String appId = mIsExists(name, hwPlatform, swPlatform);
		QueryVO queryVO = null;
		if (!StringFunctions.isNullOrWhitespace(appId))
			throw new SQLException("Application already exists.");
		else {
			appId = Common.getRandomId();
			// sql = dbObj.Insert(appId, name, hwPlatform, swPlatform,
			// metadata);
			String sql = dbObj.Insert();
			queryVO = new SqlQueryBuilder(UpdateDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
					.appendQuery(sql).addParameter(appId).addParameter(name).addParameter(hwPlatform)
					.addParameter(swPlatform).addParameter(metadata).build();

			UpdateDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);

			return mget(appId);
		}
	}

	private void mUpdate(String appID, String name, String hwPlatform, String swPlatform, String metadata)
			throws SQLException {
		ApplicationPlatformDB dbObj = new ApplicationPlatformDB();
		String appId = mIsExists(name, hwPlatform, swPlatform);
		if (!StringFunctions.isNullOrWhitespace(appId) && !appId.equals(appID))
			throw new SQLException("Application already exists.");
		else {
			List<String> parameters = new LinkedList<>();
			parameters.add(metadata);
			if (!StringFunctions.isNullOrWhitespace(name)) {
				parameters.add(name);
			}

			if (!StringFunctions.isNullOrWhitespace(hwPlatform)) {
				parameters.add(hwPlatform);
			}
			if (!StringFunctions.isNullOrWhitespace(swPlatform)) {
				parameters.add(swPlatform);
			}
			parameters.add(appID);
			
			String sql = dbObj.UpdateMetadata(name, hwPlatform, swPlatform);
			QueryVO queryVO = new SqlQueryBuilder(
					UpdateDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
							.addParameters(parameters).build();
			UpdateDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
		}
	}

	private void mDelete(String appID) throws SQLException 
	{
		ApplicationPlatformDB dbObj = new ApplicationPlatformDB();
		String sql = dbObj.delete();
		QueryVO queryVO = new SqlQueryBuilder(
				UpdateDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(appID).build();
		UpdateDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
	}

	private ApplicationUpdatePlatformVO mget(String appId) throws SQLException 
	{
		ApplicationPlatformDB dbObj = new ApplicationPlatformDB();
		ApplicationUpdatePlatformVO appObj = null;
		String sql = dbObj.get();
		QueryVO queryVO = new SqlQueryBuilder(
				UpdateDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(appId).build();

		try (ResultSet rs = UpdateDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				appObj = parseAppResult(rs);
			}
		}
		return appObj;
	}

	private List<ApplicationUpdatePlatformVO> mList() throws SQLException 
	{
		ApplicationPlatformDB dbObj = new ApplicationPlatformDB();
		List<ApplicationUpdatePlatformVO> lstObj = new ArrayList<>();
		ApplicationUpdatePlatformVO appObj = null;
		String sql = dbObj.listApps();

		QueryVO queryVO = new SqlQueryBuilder(
				UpdateDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql).build();

		try (ResultSet rs = UpdateDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				appObj = parseAppResult(rs);
				lstObj.add(appObj);
			}
		}
		return lstObj;
	}

	private ApplicationUpdatePlatformVO parseAppResult(ResultSet rs) throws SQLException
	{
		ApplicationUpdatePlatformVO appObj= new ApplicationUpdatePlatformVO();
		appObj.setAppID(rs.getString(UpdateServiceDBEnum.APP_PLATFORM.appId.name()).toString());
		appObj.setName(rs.getString(UpdateServiceDBEnum.APP_PLATFORM.name.name()).toString());
		appObj.setHwPlatform(rs.getString(UpdateServiceDBEnum.APP_PLATFORM.hwPlatform.name()).toString());
		appObj.setSwPlatform(rs.getString(UpdateServiceDBEnum.APP_PLATFORM.swPlatform.name()).toString());
		appObj.setMetadata(rs.getString(UpdateServiceDBEnum.APP_PLATFORM.metadata.name()).toString());
		appObj.setCreatedDate(rs.getTimestamp(UpdateServiceDBEnum.APP_PLATFORM.dateCreated.name()).getTime());
		appObj.setModifiedDate(rs.getTimestamp(UpdateServiceDBEnum.APP_PLATFORM.dateModified.name()).getTime());
		return appObj;
	}
}
