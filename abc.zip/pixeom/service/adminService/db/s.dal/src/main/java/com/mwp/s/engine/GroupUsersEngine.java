package com.mwp.s.engine;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mwp.a.common.Constants;
import com.mwp.a.dbenum.ApplicationUserKeyEnum;
import com.mwp.a.dbenum.AuthTableEnum;
import com.mwp.a.dbenum.UserKeyEnum;
import com.mwp.common.Common;
import com.mwp.common.CredProvider;
import com.mwp.common.StringFunctions;
import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.common.constant.Constant;
import com.mwp.common.vo.ApplicationUserVO;
import com.mwp.common.vo.QueryVO;
import com.mwp.s.dal.GroupUserDB;
import com.pa.crypto.StringEncryptionDecryption;

public class GroupUsersEngine 
{
	public void Insert(String grpId, String appUserId) throws SQLException 
	{
		mInsert(grpId,appUserId);
	}

	public void DeleteUser(List<String> appUserIds,String grpID)  throws SQLException 
	{
		mDeleteUser(appUserIds, grpID);
	}
	public List<ApplicationUserVO> ListUsers(String grpID) throws SQLException 
	{
		return mListUsers(grpID);
	}

	private void mInsert(String grpId, String appUserId) 
	{
		GroupUserDB dbObj = new GroupUserDB();
		String sql = dbObj.Insert();

		try {
			QueryVO queryVO = new SqlQueryBuilder(
					UpdateDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
							.addParameter(Common.getRandomId()).addParameter(grpId).addParameter(appUserId).build();
			UpdateDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
			// UpdateDatabaseEngine.getInstance().getConnection().executeUpdate(sql);
		} catch (SQLException e) {
			// todo handle constraint voilation exception
			// TODO: handle exception
		}
	}

	private void mDeleteUser(List<String> appUserIds, String grpID) throws SQLException 
	{
		GroupUserDB dbObj= new GroupUserDB();
		String sql = dbObj.Delete(appUserIds);
		QueryVO queryVO = new SqlQueryBuilder(
				UpdateDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameters(appUserIds).addParameter(grpID).build();
		UpdateDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
		
	}


	private  List<ApplicationUserVO> mListUsers(String grpID) throws SQLException 
	{
		GroupUserDB dbObj = new GroupUserDB();
		List<ApplicationUserVO> retList = new ArrayList<>();
		String sql = dbObj.ListUsers();

		QueryVO queryVO = new SqlQueryBuilder(
				UpdateDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(Constant.PORTAL_APPLICATION_ID).addParameter(grpID).build();

		try (ResultSet rs = UpdateDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				retList.add(parseResultSet(rs));
			}
		}
		return retList;
	}

	private ApplicationUserVO parseResultSet(ResultSet result) throws SQLException
	{
		ApplicationUserVO appUser = new ApplicationUserVO();
		//		appUser.setUserId(result.getString( AuthTableEnum.Users.name() + "." + UserKeyEnum.userId.name()));
		appUser.setFirstName(StringEncryptionDecryption.decrypt(result.getString( AuthTableEnum.Users.name() + "." + UserKeyEnum.firstName.name()),new CredProvider().getEcnKey()));
		appUser.setLastName(StringEncryptionDecryption.decrypt(result.getString( AuthTableEnum.Users.name() + "." + UserKeyEnum.lastName.name()),new CredProvider().getEcnKey()));
		//		appUser.setUserName(result.getString( AuthTableEnum.Users.name() + "." + UserKeyEnum.userName.name()));
		appUser.setEmailId(StringEncryptionDecryption.decrypt(result.getString( AuthTableEnum.Users.name() + "." + UserKeyEnum.emailId.name()),new CredProvider().getEcnKey()));
		//		appUser.setDob(result.getString( AuthTableEnum.Users.name() + "." + UserKeyEnum.dob.name()));
		//		appUser.setGender(GenderEnum.values()[result.getInt( AuthTableEnum.Users.name() + "." + UserKeyEnum.gender.name())]);
		//		appUser.setContactNo(result.getString( AuthTableEnum.Users.name() + "." + UserKeyEnum.contactNo.name()));
		//		appUser.setCountry(result.getString( AuthTableEnum.Users.name() + "." + UserKeyEnum.country.name()));
		appUser.setProfilePicturePath(result.getString( AuthTableEnum.Users.name() + "." + UserKeyEnum.profilePicturePath.name()));		
		appUser.setShareUrl(createShareUrl(appUser.getProfilePicturePath()));
		//		appUser.setUserStatus(UserStatusEnum.values()[result.getInt( AuthTableEnum.Users.name() + "." + UserKeyEnum.userStatus.name())]);
		//		appUser.setDefaultDeveloper(result.getBoolean( AuthTableEnum.Users.name() + "." + UserKeyEnum.isDeveloper.name()));
		//		appUser.setEmailVerificationId(result.getString( AuthTableEnum.Users.name() + "." + UserKeyEnum.verificationId.name()));

		appUser.setAppUserId(result.getString( AuthTableEnum.ApplicationUser.name() + "." + ApplicationUserKeyEnum.appUserId.name()));
		//		appUser.setAppId(result.getString( AuthTableEnum.ApplicationUser.name() + "." + ApplicationUserKeyEnum.appId.name()));
		//		appUser.setRole(RoleEnum.values()[result.getInt(AuthTableEnum.ApplicationUser.name() + "." + ApplicationUserKeyEnum.role.name())]);
		//		appUser.setStatus(result.getInt( AuthTableEnum.ApplicationUser.name() + "." + ApplicationUserKeyEnum.status.name()));
		//		appUser.setCreatedDate(result.getTimestamp(AuthTableEnum.ApplicationUser.name() + "." + ApplicationUserKeyEnum.createdDate.name()).getTime());
		//		appUser.setModifiedDate(result.getTimestamp(AuthTableEnum.ApplicationUser.name() + "." + ApplicationUserKeyEnum.modifiedDate.name()).getTime());	

		//		appUser.setJwtJson(result.getString( AuthTableEnum.ApplicationUser.name() + "." + ApplicationUserKeyEnum.jwtJSON.name()));
		//		appUser.setJwtPrivateKey(result.getString( AuthTableEnum.ApplicationUser.name() + "." + ApplicationUserKeyEnum.jwtPrivateKey.name()));
		//		appUser.setJwtPublicKey(result.getString( AuthTableEnum.ApplicationUser.name() + "." + ApplicationUserKeyEnum.jwtPublicKey.name()));

		return appUser;
	}

	private String createShareUrl(String imagePath) {
		try {
			if (!StringFunctions.isNullOrWhitespace(imagePath)) {
				imagePath = imagePath.split(Constants.dataFolderName)[1];
				return "https://localhost:443/" + Constants.UIFolderName + Constant.localFileSeparator
						+ Constants.dataFolderName + imagePath;
			}
		} catch (Exception e) {
			return "";
		}
		return "";
	}
}
