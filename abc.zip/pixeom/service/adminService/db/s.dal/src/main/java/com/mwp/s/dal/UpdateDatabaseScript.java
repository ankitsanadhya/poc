package com.mwp.s.dal;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.LinkedHashMap;
import java.util.List;

import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.common.vo.QueryVO;
import com.mwp.db.Interface.IDatabaseScript;
import com.mwp.db.engine.vo.DatabaseScriptVO;
import com.mwp.s.common.enums.UpdateServiceDBEnum;



public class UpdateDatabaseScript implements IDatabaseScript {

	private String dbName = "";
	public UpdateDatabaseScript(String dbName) {
		this.dbName = dbName;
	}

	DatabaseScriptVO updateScript;
	public DatabaseScriptVO getDatabaseScript(int currentVersion) {
		return mGetDatabaseScript(currentVersion);
	}

	public LinkedHashMap<Integer, DatabaseScriptVO> getUpdateScript(int dbVersion, int currentVersion) {
		return mGetUpdateScript(dbVersion, currentVersion);
	}

	public String getDBVersionQuery() {
		return mGetDBVersionQuery();
	}
	public String getDBUpdateVersionQuery(int currentVersion) {
		return mGetDBUpdateVersionQuery(currentVersion);
	}

	/**
	 * 
	 * @return query string of update version from t999.
	 */
	private String mGetDBUpdateVersionQuery(int currentVersion) {
		return "UPDATE t999 SET version = "+currentVersion;
	}
	/**
	 * get query for select db version from t999.
	 * @return
	 */
	private String mGetDBVersionQuery() {
		return "SELECT version FROM t999";
	}


	/**
	 * This method give creation script of update database and default  insertion script.
	 * @return
	 */
	private DatabaseScriptVO mGetDatabaseScript(int currentVersion)
	{
		DatabaseScriptVO databaseScript = new DatabaseScriptVO();

		List<String> ddlQueries = new ArrayList<>();
		ddlQueries.add("USE " + this.dbName);
		ddlQueries.add(createSystemPlatform());
		ddlQueries.add(createGroups());
		ddlQueries.add(createGroupUsers());
		ddlQueries.add(createGroupRealease());
		ddlQueries.add("CREATE TABLE IF NOT EXISTS `t999` (version int(4) DEFAULT 0)");

		List<QueryVO> dmlQueries = new ArrayList<>();
		dmlQueries.add(insertVersion(currentVersion));
		databaseScript.setDdlQueries(ddlQueries);
		databaseScript.setDmlQueries(dmlQueries);

		return databaseScript;
	}
	
	private QueryVO insertVersion(int currentVersion) {
		String sql = "INSERT INTO t999 (version) VALUES (?)";
		return new SqlQueryBuilder().appendQuery(sql).addParameter(currentVersion).build();
	}

	/**
	 * This method give latest update script of database,
	 * compare from db version and latest version of db from code. 
	 * @param dbVersion
	 * @param currentVersion
	 * @return Hashtable<Integer, DatabaseScriptVO>
	 */
	private LinkedHashMap<Integer, DatabaseScriptVO> mGetUpdateScript(int dbVersion, int currentVersion){
		LinkedHashMap<Integer, DatabaseScriptVO> hashDbScriptVO = new LinkedHashMap<Integer, DatabaseScriptVO>();
		/**
		 * getting all upgrade ddl queries.
		 */
		Hashtable<Integer,ArrayList<String>> upgradeDDL = getUpgradeDDLQueries();
		/**
		 * getting all upgrade dml queries.
		 */
		Hashtable<Integer,ArrayList<QueryVO>> upgradeDML = getUpgradeDMLQueries();

		// Fill only those ddl and dml queries which are new for DB. Skip already Exceuted queries.
		for(int i=dbVersion+1; i<=currentVersion; i++){
			DatabaseScriptVO databaseScript = new DatabaseScriptVO();
			List<String> ddlQueries = new ArrayList<>();
			List<QueryVO> dmlQueries = new ArrayList<>();

			//Fill ddlQueries here
			if(upgradeDDL.containsKey(i)){
				ddlQueries.addAll(upgradeDDL.get(i));
			}
			//Fill dmlQueries here
			if(upgradeDML.containsKey(i)){
				dmlQueries.addAll(upgradeDML.get(i));
			}
			databaseScript.setDdlQueries(ddlQueries);
			databaseScript.setDmlQueries(dmlQueries);
			hashDbScriptVO.put(i, databaseScript);
		}
		return hashDbScriptVO;
	}

	/**
	 * always put all ddl values in hashtable form of 
	 * ArrayList<String> and key is the version(1,2,3...), 
	 * @return Hashtable<Integer,ArrayList<String>>
	 */
	private Hashtable<Integer,ArrayList<String>> getUpgradeDDLQueries()
	{
		Hashtable<Integer,ArrayList<String>> upgradeMap = new Hashtable<Integer, ArrayList<String>>();

		//		/*** Version 1 ***/
		//		ArrayList<String> ddl_1 = new ArrayList<String>();
		//		ddl_1.add("CREATE TABLE IF NOT EXISTS `t999` (version int(4) DEFAULT 0)");
		//		upgradeMap.put(1, ddl_1);

		return upgradeMap;

	}
	/**
	 * always put all dml values in hashtable form of 
	 * ArrayList<String> and key is the version(1,2,3...), 
	 * @return Hashtable<Integer,ArrayList<String>>
	 */
	private Hashtable<Integer,ArrayList<QueryVO>> getUpgradeDMLQueries()
	{
		Hashtable<Integer,ArrayList<QueryVO>> upgradeMap = new Hashtable<Integer, ArrayList<QueryVO>>();
		/*** Version 1 ***/
		//		ArrayList<String> dml_1 = new ArrayList<String>();
		//		dml_1.add("INSERT INTO t999 (version) VALUES (0)");
		//		upgradeMap.put(1, dml_1);
		return upgradeMap;
	}
	
	private String createSystemPlatform()
	{	
		StringBuilder qry = new StringBuilder("CREATE TABLE IF NOT EXISTS ");
		qry.append(UpdateServiceDBEnum.TABLE_NAMES.applicationPlatform.name()); 
		qry.append( " (" );
		qry.append( UpdateServiceDBEnum.APP_PLATFORM.appId.name()); 
		qry.append( " varchar(32) NOT NULL,");				
		qry.append( UpdateServiceDBEnum.APP_PLATFORM.name.name()); 
		qry.append( " varchar(50) NOT NULL,");
		qry.append( UpdateServiceDBEnum.APP_PLATFORM.hwPlatform.name()); 
		qry.append( " varchar(32) NOT NULL,");
		qry.append( UpdateServiceDBEnum.APP_PLATFORM.swPlatform.name()); 
		qry.append( " varchar(32) NOT NULL,");
		qry.append( UpdateServiceDBEnum.APP_PLATFORM.metadata.name()); 
		qry.append( " Text  DEFAULT NULL,");
		qry.append( UpdateServiceDBEnum.APP_PLATFORM.dateCreated.name()); 
		qry.append( " timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP, ");
		qry.append( UpdateServiceDBEnum.APP_PLATFORM.dateModified.name()); 
		qry.append( " timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, ");
		qry.append( " PRIMARY KEY (");
		qry.append( UpdateServiceDBEnum.APP_PLATFORM.appId.name()); 
		qry.append( "),");
		qry.append( " UNIQUE KEY sys_Unique (");
		qry.append( UpdateServiceDBEnum.APP_PLATFORM.name.name()); 
		qry.append( ", ");
		qry.append( UpdateServiceDBEnum.APP_PLATFORM.hwPlatform.name()); 
		qry.append( ", ");
		qry.append( UpdateServiceDBEnum.APP_PLATFORM.swPlatform.name()); 
		qry.append( ")) ENGINE=InnoDB DEFAULT CHARSET=utf8 " );
		return qry.toString();
	}
	
	private String createGroups()
	{	
		StringBuilder qry = new StringBuilder("CREATE TABLE IF NOT EXISTS ");
		qry.append(UpdateServiceDBEnum.TABLE_NAMES.groups.name()); 
		qry.append( " (" );
		qry.append( UpdateServiceDBEnum.APP_GROUPS.groupId.name()); 
		qry.append( " varchar(32) NOT NULL,");	
		qry.append( UpdateServiceDBEnum.APP_GROUPS.name.name()); 
		qry.append( " varchar(50) NOT NULL,");
		qry.append( UpdateServiceDBEnum.APP_GROUPS.dateCreated.name()); 
		qry.append( " timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP, ");
		qry.append( UpdateServiceDBEnum.APP_GROUPS.dateModified.name()); 
		qry.append( " timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, ");
		qry.append( " PRIMARY KEY (");
		qry.append( UpdateServiceDBEnum.APP_GROUPS.groupId.name()); 
		qry.append( "),");
		qry.append( " UNIQUE KEY sysGrp_Unique (");
		qry.append( UpdateServiceDBEnum.APP_GROUPS.name.name());  
		qry.append( ")) ENGINE=InnoDB DEFAULT CHARSET=utf8 " );
		return qry.toString();
	}
	
	private String createGroupUsers()
	{
		StringBuilder qry = new StringBuilder("CREATE TABLE IF NOT EXISTS ");
		qry.append(UpdateServiceDBEnum.TABLE_NAMES.groupUsers.name()); 
		qry.append( " (" );
		qry.append( UpdateServiceDBEnum.APP_GROUP_USERS.grpUserId.name()); 
		qry.append( " varchar(32) NOT NULL,");				
		qry.append( UpdateServiceDBEnum.APP_GROUP_USERS.groupId.name()); 
		qry.append( " varchar(32) NOT NULL,");
		qry.append( UpdateServiceDBEnum.APP_GROUP_USERS.appUserId.name()); 
		qry.append( " varchar(32) NOT NULL,");
		qry.append( UpdateServiceDBEnum.APP_GROUP_USERS.dateCreated.name()); 
		qry.append( " timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP, ");
		qry.append( UpdateServiceDBEnum.APP_GROUP_USERS.dateModified.name()); 
		qry.append( " timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, ");
		qry.append( " PRIMARY KEY (");
		qry.append( UpdateServiceDBEnum.APP_GROUP_USERS.grpUserId.name()); 
		qry.append( "),");
		qry.append( " UNIQUE KEY grp_user_Unique (");
		qry.append( UpdateServiceDBEnum.APP_GROUP_USERS.groupId.name()); 
		qry.append( ", ");
		qry.append( UpdateServiceDBEnum.APP_GROUP_USERS.appUserId.name()); 
		qry.append( "),");
		qry.append( " CONSTRAINT `grp_user_ibfk_2` FOREIGN KEY (");
		qry.append( UpdateServiceDBEnum.APP_GROUP_USERS.groupId.name());
		qry.append( " )REFERENCES ");
		qry.append(UpdateServiceDBEnum.TABLE_NAMES.groups.name()); 
		qry.append( " (" );
		qry.append( UpdateServiceDBEnum.APP_GROUPS.groupId.name()); 
		qry.append( ") ON DELETE CASCADE" );
		qry.append( ") ENGINE=InnoDB DEFAULT CHARSET=utf8 " );
		return qry.toString();
	}
	
	private String createGroupRealease()
	{	
		StringBuilder qry = new StringBuilder("CREATE TABLE IF NOT EXISTS ");
		qry.append(UpdateServiceDBEnum.TABLE_NAMES.groupRelease.name()); 
		qry.append( " (" );
		qry.append( UpdateServiceDBEnum.APP_GROUP_RELEASE.grpReleaseId.name()); 
		qry.append( " varchar(32) NOT NULL,");				
		qry.append( UpdateServiceDBEnum.APP_GROUP_RELEASE.groupId.name()); 
		qry.append( " varchar(32) NOT NULL,");
		qry.append( UpdateServiceDBEnum.APP_GROUP_RELEASE.appId.name()); 
		qry.append( " varchar(32) NOT NULL,");
		qry.append( UpdateServiceDBEnum.APP_GROUP_RELEASE.version.name()); 
		qry.append( " varchar(32) NOT NULL,");
		qry.append( UpdateServiceDBEnum.APP_GROUP_RELEASE.lastCompatibleVersion.name()); 
		qry.append( " varchar(32) NOT NULL,");
		qry.append( UpdateServiceDBEnum.APP_GROUP_RELEASE.metadata.name()); 
		qry.append( " TEXT,");
		qry.append( UpdateServiceDBEnum.APP_GROUP_RELEASE.dateCreated.name()); 
		qry.append( " timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP, ");
		qry.append( UpdateServiceDBEnum.APP_GROUP_RELEASE.dateModified.name()); 
		qry.append( " timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, ");
		qry.append( " PRIMARY KEY (");
		qry.append( UpdateServiceDBEnum.APP_GROUP_RELEASE.grpReleaseId.name()); 
		qry.append( "),");
		qry.append( " UNIQUE KEY grp_release_Unique (");
		qry.append( UpdateServiceDBEnum.APP_GROUP_RELEASE.groupId.name()); 
		qry.append( ", ");
		qry.append( UpdateServiceDBEnum.APP_GROUP_RELEASE.appId.name()); 
		qry.append( "),");
		qry.append( " CONSTRAINT `grp_release_ibfk_2` FOREIGN KEY (");
		qry.append( UpdateServiceDBEnum.APP_GROUP_RELEASE.appId.name());
		qry.append( " )REFERENCES ");
		qry.append(UpdateServiceDBEnum.TABLE_NAMES.applicationPlatform.name()); 
		qry.append( " (" );
		qry.append( UpdateServiceDBEnum.APP_PLATFORM.appId.name()); 
		qry.append( ") ON DELETE CASCADE" );
		qry.append( ") ENGINE=InnoDB DEFAULT CHARSET=utf8 " );
		return qry.toString();
	}

	@Override
	public String getDBUpdateVersionQuery() {
		// TODO Auto-generated method stub
		return null;
	}

}
