package com.mwp.s.dal;

public class SystemDbUpdateScript {

	private String dbName = "";
	public SystemDbUpdateScript(String db_Name) {
		dbName = db_Name;
	}
}