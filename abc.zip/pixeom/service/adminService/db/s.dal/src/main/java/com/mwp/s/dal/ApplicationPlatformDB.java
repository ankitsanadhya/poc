package com.mwp.s.dal;


import com.mwp.common.StringFunctions;
import com.mwp.db.Interface.IConnection;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.s.common.enums.UpdateServiceDBEnum;
import com.mwp.s.engine.UpdateDatabaseEngine;

public class ApplicationPlatformDB
{
	public String Insert() 
	{
		return mInsert();
	}
	private String mInsert() 
	{
		StringBuilder sb = new StringBuilder();
		sb.append("INSERT INTO ");
		sb.append(UpdateServiceDBEnum.TABLE_NAMES.applicationPlatform);
		sb.append(" ( ");
		sb.append(UpdateServiceDBEnum.APP_PLATFORM.appId.name());
		sb.append(", ");
		sb.append(UpdateServiceDBEnum.APP_PLATFORM.name.name());
		sb.append(", ");
		sb.append(UpdateServiceDBEnum.APP_PLATFORM.hwPlatform.name());
		sb.append(", ");
		sb.append(UpdateServiceDBEnum.APP_PLATFORM.swPlatform.name());
		sb.append(", ");
		sb.append(UpdateServiceDBEnum.APP_PLATFORM.metadata.name());
		sb.append(", ");
		sb.append(UpdateServiceDBEnum.APP_PLATFORM.dateCreated.name());
		sb.append(", ");
		sb.append(UpdateServiceDBEnum.APP_PLATFORM.dateModified.name());
		sb.append(" ) VALUES ( ");
		sb.append("?");
//		sb.append(dbCon.formatString(appId));
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(name));
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(hwPlatform));
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(swPlatform));
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(metadata));	
		sb.append(", ");
		sb.append(" NOW()");
		sb.append(", ");
		sb.append(" NOW()");
		sb.append(" ) ");
		return sb.toString();
	}
	public String getAppId() 
	{
		return mGetAppId();
	}
	
	public String getAppIdByDeviceId() 
	{
		return mGetAppIdByDeviceId();
	}
	private String mGetAppId() 
	{
		StringBuilder sb = new StringBuilder();
		sb.append("Select ");
		sb.append(UpdateServiceDBEnum.APP_PLATFORM.appId.name());
		sb.append(" FROM ");
		sb.append(UpdateServiceDBEnum.TABLE_NAMES.applicationPlatform);
		sb.append(" WHERE ");
		sb.append(UpdateServiceDBEnum.APP_PLATFORM.name);
		sb.append(" = ");
		sb.append("?");
//		sb.append(dbCon.formatString(name));
		sb.append(" and ");
		sb.append(UpdateServiceDBEnum.APP_PLATFORM.hwPlatform);
		sb.append(" = ");
		sb.append("?");
//		sb.append(dbCon.formatString(hwPlatform));
		sb.append(" and ");
		sb.append(UpdateServiceDBEnum.APP_PLATFORM.swPlatform);
		sb.append(" = ");
		sb.append("?");
//		sb.append(dbCon.formatString(swPlatform));

		return sb.toString();
	}
	
//	private String getswPlatformIdFromDevices(String deviceId) 
//	{
//		StringBuilder sb = new StringBuilder();
//
//		sb.append("Select ");
//		sb.append(DEVICES.swPlatformId);
//		sb.append(" FROM platformportal.");
//		sb.append(PortalDBEnum.TABLE_NAMES.devices);		
//		sb.append(" WHERE ");
//		sb.append(DEVICES.deviceId);
//		sb.append(" = ");
//		sb.append(dbCon.formatString(deviceId));
//
//		return sb.toString();
//	}
//	
//	private String gethwPlatformIdFromDevices(String deviceId) 
//	{
//		StringBuilder sb = new StringBuilder();
//
//		sb.append("Select ");
//		sb.append(DEVICES.platformId);
//		sb.append(" FROM platformportal.");
//		sb.append(PortalDBEnum.TABLE_NAMES.devices);		
//		sb.append(" WHERE ");
//		sb.append(DEVICES.deviceId);
//		sb.append(" = ");
//		sb.append(dbCon.formatString(deviceId));
//
//		return sb.toString();
//	}
	private String mGetAppIdByDeviceId() 
	{
		StringBuilder sb = new StringBuilder();
		sb.append("Select ");
		sb.append(UpdateServiceDBEnum.APP_PLATFORM.appId.name());
		sb.append(" FROM ");
		sb.append(UpdateServiceDBEnum.TABLE_NAMES.applicationPlatform);
		sb.append(" INNER JOIN platformportal.");
		sb.append(PortalDBEnum.TABLE_NAMES.devices);
		sb.append(" as devices on ");
		sb.append(UpdateServiceDBEnum.APP_PLATFORM.hwPlatform);
		sb.append(" = ");
		sb.append("devices.");
		sb.append(PortalDBEnum.DEVICES.platformId);
		sb.append(" and ");
		sb.append(UpdateServiceDBEnum.APP_PLATFORM.swPlatform);
		sb.append(" = ");
		sb.append("devices.");
		sb.append(PortalDBEnum.DEVICES.swPlatformId);
		sb.append(" WHERE ");
		sb.append(UpdateServiceDBEnum.APP_PLATFORM.name);
		sb.append(" = ");
		sb.append("?");
		//sb.append(dbCon.formatString("Appliance"));
		sb.append(" and ");
		sb.append("devices.");
		sb.append(PortalDBEnum.DEVICES.deviceId);
		sb.append(" = ");
		sb.append("?");
//		sb.append(dbCon.formatString(deviceId));
		sb.append(" and ");
		sb.append("devices.");
		sb.append(PortalDBEnum.DEVICES.userId);
		sb.append(" = ");
		sb.append("?");
//		sb.append(dbCon.formatString(userId));
		return sb.toString();
		
//		StringBuilder sb = new StringBuilder();
//		sb.append("Select ");
//		sb.append(UpdateServiceDBEnum.APP_PLATFORM.appId.name());
//		sb.append(" FROM ");
//		sb.append(UpdateServiceDBEnum.TABLE_NAMES.applicationPlatform);
//		sb.append(" WHERE ");
//		sb.append(UpdateServiceDBEnum.APP_PLATFORM.name);
//		sb.append(" = ");
//		sb.append(dbCon.formatString("Appliance"));
//		sb.append(" and ");
//		sb.append(UpdateServiceDBEnum.APP_PLATFORM.hwPlatform);
//		sb.append(" = (");
//		sb.append(gethwPlatformIdFromDevices(deviceId));
//		sb.append(") and ");
//		sb.append(UpdateServiceDBEnum.APP_PLATFORM.swPlatform);
//		sb.append(" = (");
//		sb.append(getswPlatformIdFromDevices(deviceId));
//		sb.append(")");
//
//		return sb.toString();
	}
	
	
	public String UpdateMetadata(String name, String hwPlatform,String swPlatform) 
	{
		return mUpdateMetadata(name,  hwPlatform, swPlatform);
	}
	
	private String mUpdateMetadata(String name, String hwPlatform,String swPlatform) 
	{
		StringBuilder sb = new StringBuilder();
		sb.append("UPDATE ");
		sb.append(UpdateServiceDBEnum.TABLE_NAMES.applicationPlatform);
		StringBuilder updateStream = new StringBuilder();
		updateStream.append(" SET ");
		updateStream.append(UpdateServiceDBEnum.APP_PLATFORM.metadata.name());
		updateStream.append(" = ");
		//updateStream.append(dbCon.formatString(metadata));
		updateStream.append("?");
		if(!StringFunctions.isNullOrWhitespace(name))
		{
			updateStream.append(" , ");
			updateStream.append(UpdateServiceDBEnum.APP_PLATFORM.name.name());
			updateStream.append(" = ");
			updateStream.append("?");
			//updateStream.append(dbCon.formatString(name));	
		}
		if(!StringFunctions.isNullOrWhitespace(hwPlatform))
		{
			updateStream.append(" , ");
			updateStream.append(UpdateServiceDBEnum.APP_PLATFORM.hwPlatform.name());
			updateStream.append(" = ");
			updateStream.append("?");
			//updateStream.append(dbCon.formatString(hwPlatform));	
		}
		if(!StringFunctions.isNullOrWhitespace(swPlatform))
		{
			updateStream.append(" , ");
			updateStream.append(UpdateServiceDBEnum.APP_PLATFORM.swPlatform.name());
			updateStream.append(" = ");
			updateStream.append("?");
//			updateStream.append(dbCon.formatString(swPlatform));	
		}
		
		sb.append(updateStream);	
		sb.append(" WHERE ");
		sb.append(UpdateServiceDBEnum.APP_PLATFORM.appId.name());
		sb.append(" = ");
		sb.append("?");
//		sb.append(dbCon.formatString(appId));	
		return sb.toString();
	}
	
	public String delete() 
	{
		return mDelete();
	}
	private String mDelete() 
	{
		StringBuilder sb = new StringBuilder();
		sb.append("DELETE FROM ");
		sb.append(UpdateServiceDBEnum.TABLE_NAMES.applicationPlatform);	
		sb.append(" WHERE ");
		sb.append(UpdateServiceDBEnum.APP_PLATFORM.appId.name());
		sb.append(" = ");
		sb.append("?");
//		sb.append(dbCon.formatString(appId));	
		return sb.toString();
	}
	
	public String get() {
		return mGet();
	}

	public String listApps() {
		return mListApps();
	}

	private String mGet() {
		StringBuilder sb = new StringBuilder();
		sb.append("Select *");
		sb.append(" FROM ");
		sb.append(UpdateServiceDBEnum.TABLE_NAMES.applicationPlatform);
		sb.append(" WHERE ");
		sb.append(UpdateServiceDBEnum.APP_PLATFORM.appId);
		sb.append(" = ");
		sb.append("?");
		// sb.append(dbCon.formatString(appID));
		return sb.toString();
	}

	private String mListApps() {
		StringBuilder sb = new StringBuilder();
		sb.append("Select *");
		sb.append(" FROM ");
		sb.append(UpdateServiceDBEnum.TABLE_NAMES.applicationPlatform);
		return sb.toString();
	}
	
}
