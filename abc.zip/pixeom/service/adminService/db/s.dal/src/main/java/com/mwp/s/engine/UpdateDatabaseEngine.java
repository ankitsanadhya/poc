package com.mwp.s.engine;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import com.mwp.common.Common;
import com.mwp.common.CredProvider;
import com.mwp.common.FileBasedLock;
import com.mwp.common.StringFunctions;
import com.mwp.db.Interface.IConnection;
import com.mwp.db.Interface.IDatabaseScript;
import com.mwp.db.connection.MysqlConnection;
import com.mwp.db.engine.DatabaseEngine;
import com.mwp.logger.PALogger;
import com.mwp.s.dal.SystemDbUpdateScript;
import com.mwp.s.dal.UpdateDatabaseScript;

public class UpdateDatabaseEngine extends DatabaseEngine {

	private static DatabaseEngine instance;
	private static final String DB_NAME = "SystemUpdate";
	private static final int CURRENT_VERSION = 1;
	private static String DB_SERVER_PATH = "localhost:3306";
	private static String DB_USERNAME = "root";
	//private static String DB_PASSWORD = "Pichola@)!*";

	static {
		String tempPath = System.getProperty("java.io.tmpdir");
		File lockFile = new File(tempPath + DB_NAME + "_lock.file");

		FileBasedLock dbCreateLock = new FileBasedLock();
		dbCreateLock.getLock(lockFile);

		MysqlConnection connection = null;
		try {
			List<String> dbServerSettings =  Common.getDbServerSettings();
			if(dbServerSettings.size() == 2){
				String dbServerAddress =  dbServerSettings.get(0).trim();				
				if(!StringFunctions.isNullOrWhitespace(dbServerAddress)){
					DB_SERVER_PATH = dbServerAddress; 
				}

				String dbServerUser =  dbServerSettings.get(1).trim();				
				if(!StringFunctions.isNullOrWhitespace(dbServerUser)){
					DB_USERNAME = dbServerUser; 
				}

//				String dbServerPwd =  dbServerSettings.get(2).trim();				
//				if(!StringFunctions.isNullOrWhitespace(dbServerPwd)){
//					DB_PASSWORD = dbServerPwd; 
//				}
			}
			connection = new MysqlConnection(DB_NAME, DB_SERVER_PATH, DB_USERNAME, new CredProvider().getMysqlPwd());
		} catch (ClassNotFoundException e) 
		{
			PALogger.ERROR(e);	
			System.exit(0);
		} catch (IOException e) {
			PALogger.ERROR(e);
			System.exit(0);
		}

		instance = new UpdateDatabaseEngine(CURRENT_VERSION, connection);

		dbCreateLock.releaseLock();

	}


	public static DatabaseEngine getInstance() {
		return instance;
	}

	/**
	 * initiate db coonection, pass version and coonection to super class,
	 * if database not exist in mysql schema then create, if exist then execute update script.
	 * @param version current version of db which define in constant.
	 * @param connection
	 */
	private UpdateDatabaseEngine(int version, IConnection connection) {
		super(version, connection, DB_NAME);

		//		File dbFile = new File("/var/lib/mysql/" + DB_NAME); 

		IDatabaseScript updateDatabaseScript = new UpdateDatabaseScript(DB_NAME);
		this.configureDatabase(updateDatabaseScript);
		//DB- Moved this logic to centralized base class which takes decision whether to update existing database or to create the database if it not exists
		//		if(!dbFile.exists()|| !connection.isValid(DB_NAME)) {
		//			try {
		//				createDatabase(updateDatabaseScript);
		//			} catch (SQLException e) {
		//				PALogger.ERROR(e);
		//				System.exit(0);
		//			} 
		//		} else {
		//			try {
		//				int dbVersion = 0;
		//				try{// getting version from database, this execution in try/catch because t999 table not exist in db.
		//					ResultSet resultSet = this.getConnection().executeSelect(updateDatabaseScript.getDBVersionQuery());
		//					if(resultSet.next()){
		//						dbVersion = resultSet.getInt("version");
		//					}
		//				}catch(SQLException ex){
		//					PALogger.ERROR(ex);
		//				}
		//				//call base class method for updating database.
		//				updateDatabase(dbVersion, updateDatabaseScript);
		//			} catch (SQLException e) {
		//				PALogger.ERROR(e);
		//				System.exit(0);
		//			}
		//		}
	}

	/**
	 * This methods is used to update database
	 * @param dbVersion : current database version 
	 * @param dbScripts : create database script
	 * @throws SQLException
	 * 
	 */
	@Override
	protected void updateDatabase(int dbVersion) throws Exception {
		/**
		 * getting latest update script by comparing dbVersion(exist in t999 db) 
		 * and currentVersion(exist in constant).
		 */

		UpdateDatabaseScript createScript = new UpdateDatabaseScript(DB_NAME);
		SystemDbUpdateScript updateScript = new SystemDbUpdateScript(DB_NAME);
		switch (dbVersion +1) {
		//NOTE: No breaks in SWITCH 
		//case 2:
		//	getConnection().executeUpdatesInTransaction(updateScript.fixedCreatedDateScript());
		//	getConnection().executeUpdate(createScript.getDBUpdateVersionQuery(2));
		//case 2:
		//	getConnection().executeUpdate(updateScript.alterAppVersionSize());
		//	getConnection().executeUpdate(createScript.getDBUpdateVersionQuery(2));
		}
	}
}
