package com.mwp.s.dal;

import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import com.mwp.common.Common;
import com.mwp.common.StringFunctions;
import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.db.Interface.IConnection;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.s.common.enums.UpdateServiceDBEnum;
import com.mwp.s.engine.UpdateDatabaseEngine;

public class GroupReleaseDB 
{

	public String Insert() 
	{
		return mInsert();
	}
	private String mInsert() 
	{
		StringBuilder sb = new StringBuilder();
		sb.append("INSERT INTO ");
		sb.append(UpdateServiceDBEnum.TABLE_NAMES.groupRelease);
		sb.append(" ( ");
		sb.append(UpdateServiceDBEnum.APP_GROUP_RELEASE.grpReleaseId.name());
		sb.append(", ");
		sb.append(UpdateServiceDBEnum.APP_GROUP_RELEASE.groupId.name());
		sb.append(", ");
		sb.append(UpdateServiceDBEnum.APP_GROUP_RELEASE.appId.name());
		sb.append(", ");
		sb.append(UpdateServiceDBEnum.APP_GROUP_RELEASE.version.name());
		sb.append(", ");
		sb.append(UpdateServiceDBEnum.APP_GROUP_RELEASE.lastCompatibleVersion.name());
		sb.append(", ");
		sb.append(UpdateServiceDBEnum.APP_GROUP_RELEASE.metadata.name());
		sb.append(", ");
		sb.append(UpdateServiceDBEnum.APP_GROUP_RELEASE.dateCreated.name());
		sb.append(", ");
		sb.append(UpdateServiceDBEnum.APP_GROUP_RELEASE.dateModified.name());
		sb.append(" ) VALUES ( ");
		sb.append("?");
//		sb.append(dbCon.formatString(Common.getRandomId()));
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(grpId));
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(appId));
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(version));
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(lastVersion));
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(metadata));
		sb.append(", ");
		sb.append(" NOW()");
		sb.append(", ");
		sb.append(" NOW()");
		sb.append(" ) ");
		return sb.toString();
	}
	
	public String get(List<String> userGroupIDs,List<String> appIdCount) 
	{
		return mGet(userGroupIDs, appIdCount);
	}
	
	private String mGet(List<String> userGroupIDs,List<String> appIdCount) 
	{
		StringBuilder sb = new StringBuilder();
		//String[] versionArr = currentVersion.split("\\.");
		sb.append("Select * ");
		sb.append(" FROM ");
		sb.append(UpdateServiceDBEnum.TABLE_NAMES.groupRelease);
		sb.append(" WHERE ");
		sb.append(UpdateServiceDBEnum.APP_GROUP_RELEASE.groupId);
		
		sb.append(getUserGroupIDsByIN(userGroupIDs));
//		sb.append(" IN (SELECT 'ALL' UNION (");
//		sb.append(new GroupUserDB().getUserGroupIDs(appUserId));
		
		sb.append(" and ");
		
		sb.append(UpdateServiceDBEnum.APP_GROUP_RELEASE.appId);
		
		SqlQueryBuilder builder = new SqlQueryBuilder();
		builder.appendQueryIN(appIdCount);
		
//		sb.append(" IN (");
//		if (!StringFunctions.isNullOrWhitespace(deviceId))
//			sb.append(new ApplicationPlatformDB().getAppIdByDeviceId(deviceId, appUserId));
//		else
//			sb.append(new ApplicationPlatformDB().getAppId(name, hwPlatform, swPlatform));
//		sb.append(")");
		
		sb.append(" and ");
		sb.append("CONCAT(");
		sb.append("LPAD(SUBSTRING_INDEX(SUBSTRING_INDEX(version, '.', 1), '.', -1), 10, '0'),");
		sb.append("LPAD(SUBSTRING_INDEX(SUBSTRING_INDEX(version, '.', 2), '.', -1), 10, '0'),");
		sb.append("LPAD(SUBSTRING_INDEX(SUBSTRING_INDEX(version, '.', 3), '.', -1), 10, '0'),");
		sb.append("LPAD(SUBSTRING_INDEX(SUBSTRING_INDEX(version, '.', 4), '.', -1), 10, '0')");
		sb.append(") ");
		sb.append(" > ");
		sb.append("CONCAT(");
		sb.append("LPAD(");
		sb.append("?");
		//sb.append(versionArr[0]);
		sb.append(", 10, '0'),");
		sb.append("LPAD(");
		sb.append("?");
//		sb.append(versionArr[1]);
		sb.append(", 10, '0'),");
		sb.append("LPAD(");
		sb.append("?");
//		sb.append(versionArr[2]);
		sb.append(", 10, '0'),");
		sb.append("LPAD(");
		sb.append("?");
//		sb.append(versionArr[3]);
		sb.append(", 10, '0')");
		sb.append(")");

		sb.append(" ORDER BY ");
		sb.append("CONCAT(");
		sb.append("LPAD(SUBSTRING_INDEX(SUBSTRING_INDEX(version, '.', 1), '.', -1), 10, '0'),");
		sb.append("LPAD(SUBSTRING_INDEX(SUBSTRING_INDEX(version, '.', 2), '.', -1), 10, '0'),");
		sb.append("LPAD(SUBSTRING_INDEX(SUBSTRING_INDEX(version, '.', 3), '.', -1), 10, '0'),");
		sb.append("LPAD(SUBSTRING_INDEX(SUBSTRING_INDEX(version, '.', 4), '.', -1), 10, '0')");
		sb.append(") DESC ");

		return sb.toString();
	}
	
	
	private String getUserGroupIDsByIN(Collection<?> objects){
		return " IN (SELECT 'ALL' UNION (" + objects.stream().map(it -> "?").collect(Collectors.joining(",")) + "))";
	}
	
	public String list() 
	{
		return mList();
	}
	
	private String mList() 
	{
		StringBuilder sb = new StringBuilder();
		sb.append("Select * ");
		sb.append(" FROM ");
		sb.append(UpdateServiceDBEnum.TABLE_NAMES.groupRelease);
		sb.append(" WHERE ");
		sb.append(UpdateServiceDBEnum.APP_GROUP_RELEASE.groupId);
		sb.append(" = ");
		sb.append("?");
//		sb.append(dbCon.formatString(grpid));
		return sb.toString();
	}

	public String IsExists() 
	{
		return mIsExists();
	}
	private String mIsExists() 
	{
		StringBuilder sb = new StringBuilder();
		sb.append("Select * ");
		sb.append(" FROM ");
		sb.append(UpdateServiceDBEnum.TABLE_NAMES.groupRelease);
		sb.append(" WHERE ");
		sb.append(UpdateServiceDBEnum.APP_GROUP_RELEASE.groupId);
		sb.append(" =");
		sb.append("?");
//		sb.append(dbCon.formatString(grpId));
		sb.append(" and ");
		sb.append(UpdateServiceDBEnum.APP_GROUP_RELEASE.appId);
		sb.append(" = ");
		sb.append("?");
//		sb.append(dbCon.formatString(appId));
		
		return sb.toString();
	}
	
	public String Update() 
	{
		return mUpdate();
	}
	private String mUpdate() 
	{
		StringBuilder sb = new StringBuilder();
		sb.append("UPDATE ");
		sb.append(UpdateServiceDBEnum.TABLE_NAMES.groupRelease);
		sb.append(" set ");
		sb.append(UpdateServiceDBEnum.APP_GROUP_RELEASE.version.name());
		sb.append(" = ");
		sb.append("?");
		//sb.append(dbCon.formatString(version));
		sb.append(" , ");
		sb.append(UpdateServiceDBEnum.APP_GROUP_RELEASE.metadata.name());
		sb.append(" = ");
		sb.append("?");
//		sb.append(dbCon.formatString(metadata));
		sb.append(" , ");
		sb.append(UpdateServiceDBEnum.APP_GROUP_RELEASE.lastCompatibleVersion.name());
		sb.append(" = ");
		sb.append("?");
//		sb.append(dbCon.formatString(lastVersion));
		sb.append(" WHERE ");
		sb.append(UpdateServiceDBEnum.APP_GROUP_RELEASE.grpReleaseId.name());
		sb.append(" = ");
		sb.append("?");
//		sb.append(dbCon.formatString(grpReleaseID));
		return sb.toString();
	}
	
//	public String DeleteVersion(String appID,String version) 
//	{
//		return mDeleteVersion(appID, version);
//	}
//	private String mDeleteVersion(String appID,String version) 
//	{
//		StringBuilder sb = new StringBuilder();
//		sb.append("DELETE FROM ");
//		sb.append(UpdateServiceDBEnum.TABLE_NAMES.groupRelease);
//		sb.append(" WHERE ");
//		sb.append(UpdateServiceDBEnum.APP_GROUP_RELEASE.appId.name());
//		sb.append(" = ");
//		sb.append(dbCon.formatString(appID));
//		sb.append(" AND ");
//		sb.append(UpdateServiceDBEnum.APP_GROUP_RELEASE.version.name());
//		sb.append(" = ");
//		sb.append(dbCon.formatString(version));
//		return sb.toString();
//	}

	
}
