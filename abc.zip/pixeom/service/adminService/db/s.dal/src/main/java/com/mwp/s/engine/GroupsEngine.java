package com.mwp.s.engine;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mwp.common.Common;
import com.mwp.common.StringFunctions;
import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.common.vo.QueryVO;
import com.mwp.s.common.GroupsVO;
import com.mwp.s.common.enums.UpdateServiceDBEnum;
import com.mwp.s.dal.GroupDB;

public class GroupsEngine {
	public GroupsVO Insert(String name) throws SQLException {
		return mInsert(name);
	}

	public GroupsVO Get(String grpID) throws SQLException {
		return mGet(grpID);
	}

	public List<GroupsVO> listGrp() throws SQLException {
		return mListgrp();
	}

	public void deleteGrp(String grpID) throws SQLException {
		mDeleteGrp(grpID);
	}

	private GroupsVO mInsert(String name) throws SQLException {
		GroupDB dbObj = new GroupDB();
		// check grp
		String grpID = mIsExists(name);
		if (StringFunctions.isNullOrWhitespace(grpID)) {
			grpID = Common.getRandomId();
			String sql = dbObj.Insert();
			
			QueryVO queryVO = new SqlQueryBuilder(
					UpdateDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
							.addParameter(grpID).addParameter(name).build();

			
			UpdateDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
		}

		return mGet(grpID);
	}

	private String mIsExists(String name) throws SQLException {
		GroupDB dbObj = new GroupDB();
		String sql = dbObj.isExists();

		QueryVO queryVO = new SqlQueryBuilder(
				UpdateDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(name).build();

		try (ResultSet rs = UpdateDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				return rs.getString(UpdateServiceDBEnum.APP_GROUPS.groupId.name());
			}
		} 
		return "";
	}

	private GroupsVO mGet(String grpID) throws SQLException {
		GroupDB dbObj = new GroupDB();
		String sql = dbObj.get();
		QueryVO queryVO = new SqlQueryBuilder(
				UpdateDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
						.addParameter(grpID).build();

		try (ResultSet rs = UpdateDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				return parseGrpResult(rs);
			}
		}
		return null;
	}

	private List<GroupsVO> mListgrp() throws SQLException {
		GroupDB dbObj = new GroupDB();
		List<GroupsVO> retList = new ArrayList<>();
		String sql = dbObj.list();
		QueryVO queryVO = new SqlQueryBuilder(
				UpdateDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql).build();

		try (ResultSet rs = UpdateDatabaseEngine.getInstance().getConnection().executeQuery(queryVO)) {
			while (rs.next()) {
				retList.add(parseGrpResult(rs));
			}
		}

		GroupsVO grpObj = new GroupsVO();
		grpObj.setGrpId("ALL");
		grpObj.setName("Public Release");
		grpObj.setCreatedDate(System.currentTimeMillis());
		grpObj.setModifiedDate(System.currentTimeMillis());
		retList.add(grpObj);
		
		return retList;
	}

	private void mDeleteGrp(String grpID) throws SQLException {
		GroupDB dbObj = new GroupDB();
		String sql = dbObj.delete();
		QueryVO queryVO = new SqlQueryBuilder(
				UpdateDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString()).appendQuery(sql)
				.addParameter(grpID)
				.build();
		UpdateDatabaseEngine.getInstance().getConnection().executeUpdate(queryVO);
	}

	private GroupsVO parseGrpResult(ResultSet rs) throws SQLException {
		GroupsVO grpObj = new GroupsVO();
		grpObj.setGrpId(rs.getString(UpdateServiceDBEnum.APP_GROUPS.groupId.name()).toString());
		grpObj.setName(rs.getString(UpdateServiceDBEnum.APP_GROUPS.name.name()).toString());
		grpObj.setCreatedDate(rs.getTimestamp(UpdateServiceDBEnum.APP_GROUPS.dateCreated.name()).getTime());
		grpObj.setModifiedDate(rs.getTimestamp(UpdateServiceDBEnum.APP_GROUPS.dateModified.name()).getTime());
		return grpObj;
	}
}
