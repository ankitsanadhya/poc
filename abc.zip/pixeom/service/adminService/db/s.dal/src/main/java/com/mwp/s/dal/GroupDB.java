package com.mwp.s.dal;

import com.mwp.s.common.enums.UpdateServiceDBEnum;

public class GroupDB 
{

	public String Insert() 
	{
		return mInsert();
	}
	private String mInsert() 
	{
		StringBuilder sb = new StringBuilder();
		sb.append("INSERT INTO ");
		sb.append(UpdateServiceDBEnum.TABLE_NAMES.groups);
		sb.append(" ( ");
		sb.append(UpdateServiceDBEnum.APP_GROUPS.groupId.name());
		sb.append(", ");
		sb.append(UpdateServiceDBEnum.APP_GROUPS.name.name());
		sb.append(", ");
		sb.append(UpdateServiceDBEnum.APP_GROUPS.dateCreated.name());
		sb.append(", ");
		sb.append(UpdateServiceDBEnum.APP_GROUPS.dateModified.name());
		sb.append(" ) VALUES ( ");
		sb.append("?");
//		sb.append(dbCon.formatString(grpID));
		sb.append(", ");
		sb.append("?");
//		sb.append(dbCon.formatString(name));
		sb.append(", ");
		sb.append(" NOW()");
		sb.append(", ");
		sb.append(" NOW()");
		sb.append(" ) ");
		return sb.toString();
	}
	
	public String isExists() 
	{
		return mIsExists();
	}
	private String mIsExists()  
	{
		StringBuilder sb = new StringBuilder();
		sb.append("Select *");
		sb.append(" FROM ");
		sb.append(UpdateServiceDBEnum.TABLE_NAMES.groups);
		sb.append(" WHERE ");
		sb.append(UpdateServiceDBEnum.APP_GROUPS.name);
		sb.append(" = ");
		sb.append("?");
//		sb.append(dbCon.formatString(name));

		return sb.toString();
	}
	public String list() 
	{
		return mList();
	}
	private String mList()  
	{
		StringBuilder sb = new StringBuilder();
		sb.append("Select *");
		sb.append(" FROM ");
		sb.append(UpdateServiceDBEnum.TABLE_NAMES.groups);
		return sb.toString();
	}
	
	public String delete() 
	{
		return mDelete();
	}
	private String mDelete()  
	{
		StringBuilder sb = new StringBuilder();
		sb.append("DELETE ");
		sb.append(" FROM ");
		sb.append(UpdateServiceDBEnum.TABLE_NAMES.groups);
		sb.append(" WHERE ");
		sb.append(UpdateServiceDBEnum.APP_GROUPS.groupId);
		sb.append(" = ");
		sb.append("?");
//		sb.append(dbCon.formatString(grpID));
		return sb.toString();
	}
	public String get() 
	{
		return mGet();
	}
	private String mGet()  
	{
		StringBuilder sb = new StringBuilder();
		sb.append("Select *");
		sb.append(" FROM ");
		sb.append(UpdateServiceDBEnum.TABLE_NAMES.groups);
		sb.append(" WHERE ");
		sb.append(UpdateServiceDBEnum.APP_GROUPS.groupId);
		sb.append(" = ");
		sb.append("?");
//		sb.append(dbCon.formatString(grpId));

		return sb.toString();
	}
}
