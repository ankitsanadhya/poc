package com.mwp.s.framework;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.HttpMethod;

import com.google.gson.Gson;
import com.mwp.common.Client;
import com.mwp.common.constant.Constant;
import com.mwp.common.vo.ApplicationUserVO;
import com.mwp.common.vo.GroupReleaseVO;
import com.mwp.p.common.Constants;
import com.mwp.s.common.GroupsVO;
import com.mwp.s.engine.GroupReleaseEngine;
import com.mwp.s.engine.GroupUsersEngine;
import com.mwp.s.engine.GroupsEngine;

public class Groups
{
	//add
	//delete
	//list grp
	public GroupsVO addGrp(String name) throws SQLException 
	{
		return mAddGrp(name);
	}
	public List<GroupsVO> listGrp() throws SQLException 
	{
		return mListgrp();
	}
	public void deleteGrp(String grpID) throws SQLException 
	{
		mDeleteGrp(grpID);
	}

	//list grpuser
	//add user
	//delete user

	public void addUser(String grpId, String appUserId) throws SQLException 
	{
		mAddUser(grpId,appUserId);
	}

	public void addUsers(String grpId, List<String> appUserIds) throws SQLException 
	{
		for (String appUserID : appUserIds)
		{
			mAddUser(grpId,appUserID);
		}

	}

	public void deleteUser(List<String> appUserIds,String grpID)  throws SQLException 
	{
		mDeleteUser(appUserIds, grpID);
	}
	public List<ApplicationUserVO> ListUsers(String grpID) throws SQLException 
	{
		return mListUsers(grpID);
	}


	private GroupsVO mAddGrp(String name) throws SQLException
	{
		GroupsEngine engg= new GroupsEngine();
		return	engg.Insert(name);
	}
	private List<GroupsVO> mListgrp() throws SQLException {

		GroupsEngine engg= new GroupsEngine();
		return	engg.listGrp();
	}
	private void mDeleteGrp(String grpID) throws SQLException
	{
		GroupsEngine engg= new GroupsEngine();
		engg.deleteGrp(grpID);
	}
	private void mAddUser(String grpId, String appUserId) throws SQLException 
	{
		GroupUsersEngine engg= new GroupUsersEngine();
		engg.Insert(grpId, appUserId);
	}

	private void mDeleteUser(List<String> appUserIds,String grpID)  throws SQLException 
	{
		GroupUsersEngine engg= new GroupUsersEngine();
		engg.DeleteUser(appUserIds, grpID);
	}
	private List<ApplicationUserVO> mListUsers(String grpID) throws SQLException 
	{
		GroupUsersEngine engg= new GroupUsersEngine();
		return engg.ListUsers(grpID);
	}
	public List<GroupReleaseVO> list(String grpid) throws SQLException 
	{
		return mList(grpid);
	}
	private  List<GroupReleaseVO> mList(String grpid) throws SQLException
	{
		GroupReleaseEngine engg= new GroupReleaseEngine();
		return engg.list(grpid);

	}

	public  HashMap<String, Object> listPortalUsers(String authToken,int pageNumber,int pageSize, String filters) throws Exception
	{
		return mListPortalUsers(authToken,pageNumber,pageSize,filters);
	}
	private  HashMap<String, Object> mListPortalUsers(String authToken,int pageNumber,int pageSize, String filters) throws Exception
	{
		if(authToken==null || authToken.trim().equals("")) {
			throw new Exception(Constant.UNAUTHORIZED);
		}else{			
			if(!authToken.contains("bearer") && !authToken.contains("basic")) {
				authToken = Constant.BEARER + authToken;	
			}
			Map<Object,Object> queryParam = new HashMap<Object,Object>();
			queryParam.put("pageNo", pageNumber);
			queryParam.put("pageSize", pageSize);
			queryParam.put("filters", filters);
			
			///list
			//String result= Client.callServer(Constants.AUTH_SERVER_IP_PORT, "a.service/api", "applications/41ff73c9719a42bdb0348355114ceb82/user", "GET", "list/users", null, null, authToken);
			String result= Client.callServer(Constants.AUTH_SERVER_IP_PORT, Constants.AUTH_SERVICE_NAME, "applications", HttpMethod.GET, Constants.PORTAL_APPLICATION_ID  +   "/user/listfilter/users", queryParam, null, authToken);
			HashMap<String, Object> data = new Gson().fromJson(result, HashMap.class);
			String dataGson = new Gson().toJson(data.get(Constant.DATA));
			HashMap<String, Object>  output = new Gson().fromJson(dataGson, HashMap.class);				
			return output;
		}
	}
	
//	public static void main(String[] args) throws Exception {
//		new Groups().listPortalUsers("bearer 82c56a0cab28ca62ec420e69eff7495f");
//	}





}
