package com.mwp.s.framework;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
//    	//new platform with all
//    	//new platform with new grpname
//    	//same platform with same grpname different member
//    	//same platform with other grp
//    	//
//        PALogger.INFO( "Hello World!" );
//        AppUpdate obj = new AppUpdate();
//        List<String> appUserIds= new ArrayList<String>();
//        appUserIds.add("475cfa002d684d419f338cf0851e7f97");
//        
//        List<String> appUserIds2= new ArrayList<String>();
//        appUserIds2.add("23");
//        
//        List<String> appUserIds3= new ArrayList<String>();
//        appUserIds3.add("33");
//        
//        try 
//        {
//        	//obj.releaseUpdate("1f5cd2401e4547a8ae33ccf84bd38ffd", "0.0.2", "ef3fe87a169343f5b758f3be52826344");
////			//obj.insertUpdate("edgeCore", "x86", "docker", "008", "", null, "0.0.1");
////		obj.insertUpdate("edgeCore", "x86", "docker", "009", "g01", appUserIds, "0.0.2");
////			 appUserIds.add("5");
////			 obj.insertUpdate("edgeCore", "x86", "docker", "008", "g01", appUserIds, "0.0.2");
////		        appUserIds.add("6");
////			obj.insertUpdate("edgeCore", "x86", "docker", "008", "g02", appUserIds, "0.0.3");
////			obj.insertUpdate("edgeCore", "x86", "docker", "008", "g02", appUserIds, "0.0.4");
////			
////			obj.insertUpdate("edgeCore", "x86", "kuber", "008", "", null, "0.0.1");
////			obj.insertUpdate("edgeCore", "x86", "kuber", "008", "g01", appUserIds, "0.0.2");
//			
//			ApplicationPlatform appObj= new ApplicationPlatform();
//		//	ApplicationUpdatePlatformVO a3=	appObj.Insert("edgeCore", "da1d8e2299e945cbb24979b81487e686", "66316e41d90247b4943c698fc98f6b9e", "009");
//		//List<ApplicationUpdatePlatformVO> lstObj=	appObj.listApp();
//		//	appObj.delete("4e9f71aa87504b5b88cb9b3126b3e009");
//			
//			//ApplicationUpdatePlatformVO a4=appObj.Insert("edgeCore", "x86", "kuber", "008");
//        	Groups grp = new Groups();
//      //  	GroupsVO voObj = grp.addGrp("test23");
//     //   grp.addUsers(voObj.getGrpId(), appUserIds);
//        
//        Groups grp2 = new Groups();
//    //	GroupsVO voObj2 = grp2.addGrp("grp2");
//  //  grp2.addUsers(voObj2.getGrpId(), appUserIds2);
//    
//    Groups grp3 = new Groups();
////	GroupsVO voObj3 = grp3.addGrp("grp3");
////grp3.addUsers(voObj3.getGrpId(), appUserIds3);
//        
//       // obj.releaseUpdate(a3.getAppID(), "0.0.42",voObj2.getGrpId());
//       // obj.releaseUpdate(a3.getAppID(), "0.0.44",voObj.getGrpId());
//   VersionInfo info = new VersionInfo();
//   info.setType("patch");
//   info.setRealeasenotes("nothing new");
//   info.setFilePath("/etc/a.txt");
//    obj.releaseUpdate("e9466f497435478fb075925f9c5e94b6", "0.0.2.0","",new Gson().toJson(info));
//      //  obj.releaseUpdate(a3.getAppID(), "0.0.47",voObj3.getGrpId());
//     //  List<String> users=  grp.ListUsers("ef3fe87a169343f5b758f3be52826344");
//     //  grp.deleteUser("34", "ef3fe87a169343f5b758f3be52826344");
//        
////        	GroupsVO grpv2 = grp.addGrp("g3");
////        	List<GroupsVO> lstgrp = grp.listGrp();
////        	grp.deleteGrp(grpvo1.getGrpId());
//			
//
//        	
//		List<String> version =	obj.checkUpdates("edgeCore", "x86", "kuber", "32", "0.0.0.0");
//		List<String> version2 =	obj.checkUpdates("edgeCore", "x86", "docker", "11", "0.0.0.0");
//		List<String> version3 =	obj.checkUpdates("edgeCore", "x86", "docker", "11", "0.0.0.2");
//		PALogger.INFO(version.size());
//		PALogger.INFO(version2.size());
//		PALogger.INFO("done");
//		} catch (SQLException e) 
//        {
//			// TODO Auto-generated catch block
//			PALogger.ERROR(e);
//		}
    }
}
