package com.mwp.s.framework;

import java.sql.SQLException;
import java.util.List;

import com.mwp.common.StringFunctions;
import com.mwp.common.vo.GroupReleaseVO;
import com.mwp.s.engine.GroupReleaseEngine;

public class AppUpdate 
{
	public List<GroupReleaseVO> checkUpdates(String name,String hwPlatform, String swPlatform,String appUserId,String currentVersion, String deviceId) throws SQLException 
	{
		return mCheckUpdates(name, hwPlatform, swPlatform, appUserId, currentVersion,  deviceId);
	}
	private  List<GroupReleaseVO> mCheckUpdates(String name,String hwPlatform, String swPlatform,String appUserId,String currentVersion, String deviceId ) throws SQLException
	{
		GroupReleaseEngine engg= new GroupReleaseEngine();
		return engg.checkUpdates(name, hwPlatform, swPlatform, appUserId, currentVersion,  deviceId);
		
	}
	public void releaseUpdate(String appId,String version,String lastVersion, String grpID, String metadata) throws SQLException
	{
		mReleaseUpdate(appId, version,lastVersion, grpID,metadata);
	}
	
	private void mReleaseUpdate(String appId,String version,String lastVersion, String grpID, String metadata) throws SQLException
	{
		GroupReleaseEngine releaseEngg = new GroupReleaseEngine();
		if(StringFunctions.isNullOrWhitespace(grpID))//it means this release is for all
			releaseEngg.Insert("ALL", appId, version,lastVersion,metadata);
		else
			releaseEngg.Insert(grpID, appId, version,lastVersion,metadata);
		//if groupname is null or empty then entry in grpRelease with "all" groupID
		//else insert in group and group users then in grpRealease
	}
	
	

}
