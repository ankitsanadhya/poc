package com.mwp.s.framework;

import java.sql.SQLException;
import java.util.List;

import com.mwp.s.common.ApplicationUpdatePlatformVO;
import com.mwp.s.engine.ApplicationPlatformEngine;

public class ApplicationPlatform 
{

	//add
	//edit
	//delete
	//list
	
	public ApplicationUpdatePlatformVO Insert(String name,String hwPlatform, String swPlatform, String metadata) throws SQLException 
	{
		return mInsert( name, hwPlatform, swPlatform, metadata);
	}

	public void Update(String appID,String name, String hwPlatform,String swPlatform, String metadata) throws SQLException 
	{
		 mUpdate(appID,name,hwPlatform,swPlatform, metadata);
	}
	
	public void delete(String appID) throws SQLException 
	{
		mDelete(appID);
	}
	
	public List<ApplicationUpdatePlatformVO> listApp() throws SQLException 
	{
		return mList();
	}
	
	private ApplicationUpdatePlatformVO mInsert(String name,String hwPlatform, String swPlatform, String metadata) throws SQLException 
	{
		ApplicationPlatformEngine engg = new ApplicationPlatformEngine();
		return engg.Insert(name, hwPlatform, swPlatform, metadata);
	}

	private void mUpdate(String appID,String name, String hwPlatform,String swPlatform,String metadata) throws SQLException 
	{
		ApplicationPlatformEngine engg = new ApplicationPlatformEngine();
		 engg.Update(appID,name, hwPlatform, swPlatform, metadata);
	}
	
	private void mDelete(String appID) throws SQLException 
	{
		ApplicationPlatformEngine engg = new ApplicationPlatformEngine();
		 engg.delete(appID);
	}
	
	private List<ApplicationUpdatePlatformVO> mList() throws SQLException 
	{
		ApplicationPlatformEngine engg = new ApplicationPlatformEngine();
		return engg.listApp();
	}
}
