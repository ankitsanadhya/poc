package com.mwp.s.common;

import com.mwp.logger.PALogger;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        PALogger.INFO( "Hello World!" );
    }
}
