/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.mwp.p.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import com.google.gson.Gson;
import com.mwp.common.ReturnObject;
import com.mwp.common.constant.Constant;
import com.mwp.common.constant.PermissionResourceKeys;
import com.mwp.common.constant.PermissionResources;
import com.mwp.common.enums.ActivityOperation;
import com.mwp.common.vo.AuthorizationsVO;
import com.mwp.common.vo.ErrorVo;
import com.mwp.common.vo.PortVO;
import com.mwp.common.vo.ServiceEndpointVO;
import com.mwp.logger.PALogger;
import com.mwp.p.authhelper.GrpcAuthHelper;
import com.mwp.p.common.Constants;
import com.mwp.p.framework.ActivityLogs;
import com.mwp.p.framework.Applications;
import com.mwp.p.framework.ServiceEndpoints;
import com.mwp.p.utility.Utility;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

//description = "This class manage host and ports for predefine services."
@Path("/services")
@Api(value = "/services", produces = MediaType.APPLICATION_JSON)
public class ApplicationServiceEndpoint {

	@Context
	private HttpServletResponse response;

	@GET
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/{appid}/endpoint")
	@ApiOperation(value = "Check service endpoint available or not", notes = "Check service endpoint available or not", response = Boolean.class)
	@ApiResponses({
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to Check Service."),
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_NOT_FOUND, message = "Application not found.")
			})
	public void checkServiceEndpointAvailable(
			@ApiParam(value = "Applicatio id", required = true) @PathParam("appid") String appId,
			@ApiParam(value = "Endpoint name", required = true) @QueryParam("endpoint") String endpoint,
			@ApiParam(value = "Authorization token", required = true) @HeaderParam("Authorization") String authToken) {
		mCheckServiceEndpointAvailable(appId, endpoint, authToken);
	}
	
	@GET
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/{appid}/portexist")
	@ApiOperation(value = "Check service port available or not", notes = "Check service port available or not", response = Boolean.class)
	@ApiResponses({
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_NOT_ACCEPTABLE, message = Constants.UNABLE_TO_RESERVE_PORT_FOR_APPLICATION)
		})
	public void checkApplicationPortExist(
			@ApiParam(value = "Applicatio id", required = true) @PathParam("appid") String appId,
			@ApiParam(value = "Endpoint name", required = true) @QueryParam("internalPort") String internalPort,
			@ApiParam(value = "Endpoint name", required = true) @QueryParam("externalPort") String externalPort,
			@ApiParam(value = "Authorization token", required = true) @HeaderParam("Authorization") String authToken) {
		mCheckApplicationPortExist(appId, externalPort,  authToken);
	}

	@POST
	@Consumes({ MediaType.APPLICATION_JSON })
	@ApiOperation(value = "reserver service endpoint for app.", notes = "reserver service endpoint for app.", response = HashMap.class)
	@ApiResponses({
			@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
			@ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to reserve service endpoint for application."), })
	public void reserveServiceEndpoint(
			@ApiParam(value = "Object of ServiceEndpointVO.", required = true) ServiceEndpointVO serviceEndpointVO,
			@ApiParam(value = "Authorization token", required = false) @HeaderParam("Authorization") String authToken) {
		mReserveServiceEndpoint(serviceEndpointVO, authToken);
	}
	
	@POST
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/{appid}/portexist")
	@ApiOperation(value = "reserver application port for app.", notes = "reserver application port for app.", response = HashMap.class)
	@ApiResponses({
			@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
			@ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = Constants.UNABLE_TO_RESERVE_PORT_FOR_APPLICATION), })
	public void checkApplicationPortExist(
			@ApiParam(value = "Applicatio id", required = true) @PathParam("appid") String appId,
			@ApiParam(value = "Object of ServiceEndpointVO.", required = true) List<PortVO> ports,
			@ApiParam(value = "Authorization token", required = false) @HeaderParam("Authorization") String authToken) {
		mCheckApplicationPortExist(appId, ports, authToken);
	}
	
	private void mCheckServiceEndpointAvailable(String appId, String endpoint,
			String authToken) {
		try {
			// CHECK AUTH TOKEN ...
			// Execute the opearion if Owner of the app OR push on the app
			AuthorizationsVO authVo=new GrpcAuthHelper().getAuthorizationsVO(authToken);
			Applications applications=new Applications();
			// #AKH_01_1
			String appOwnerId = applications.getUserIdOfApp(appId);

			if (appOwnerId != null) {
				if (!appOwnerId.equals(authVo.getUserId())) {

					Utility.checkPermission(authVo.getGroupPermissions(), PermissionResources.getString(PermissionResourceKeys.APP_VERSION_CREATE), appId);
				}

				boolean isAvailable = new ServiceEndpoints().checkServiceEndpointAvailable(appId, endpoint);

				Map<String, Object> resultMap = new HashMap<>();
				
				resultMap.put(Constant.DATA, isAvailable);
				
				ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);
			}
			else{
				//if Application not found for given application Id then throw NOTFOUND exception. 
				throw new Exception(Constant.NOTFOUND);
			}
			
		} catch (Exception e) {
			PALogger.ERROR(e);	
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			} else if(e.getMessage().equals(Constant.NOTFOUND)) {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_NOT_FOUND,
						"Application not found", "No application found with requested app ID");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			} else if(e.getMessage().equals(Constant.NOTPERMITTED)) {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			} else {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"Unable to check service", "Unable to check service");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
		}
	}

	private void mReserveServiceEndpoint(ServiceEndpointVO serviceEndpointVO,
			String authToken) {
		try {
			// CHECK AUTH TOKEN...
          // Execute the opearion if Owner of the app OR push on the app
			AuthorizationsVO authVo=new GrpcAuthHelper().getAuthorizationsVO(authToken);
			Applications applications=new Applications();
			//AKH_01_1
			String appOwnerId = applications.getUserIdOfApp(serviceEndpointVO.getAppId());
			if(!appOwnerId.equals(authVo.getUserId()))
			{
				Utility.checkPermission(authVo.getGroupPermissions(), PermissionResources.getString(PermissionResourceKeys.APP_VERSION_CREATE), serviceEndpointVO.getAppId());
			}
			ServiceEndpointVO endpointVO = new ServiceEndpoints().reserveServiceEndpoint(serviceEndpointVO);
			//add in activity table
			new ActivityLogs().insert(authVo.getUserId(),ActivityOperation.reserveServiceEndpoint.name(), new Gson().toJson(serviceEndpointVO));
			Map<String, Object> resultMap = new HashMap<>();
			resultMap.put(Constant.DATA, endpointVO);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null,response);
		} catch (Exception e) {		
			if(e.getMessage().equals(Constant.UNAUTHORIZED)) {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			} else if(e.getMessage().equals(Constant.NOTPERMITTED)) {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			} else {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Unable to reserve service endpoint for application.", "Unable to reserve service endpoint for application.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			PALogger.ERROR(e);	
		}
	}
	
	/**
	 * check given application external port assigned for any other application.
	 * @param appId
	 * @param serviceEndpointVO
	 * @param authToken
	 */
	private void mCheckApplicationPortExist(String appId, List<PortVO> ports,
			String authToken) {
		try {
			// CHECK AUTH TOKEN...
          // Execute the opearion if Owner of the app OR push on the app
			AuthorizationsVO authVo=new GrpcAuthHelper().getAuthorizationsVO(authToken);
			Applications applications=new Applications();
			//AKH_01_1
			String appOwnerId = applications.getUserIdOfApp(appId);
			if(!appOwnerId.equals(authVo.getUserId()))
			{
				Utility.checkPermission(authVo.getGroupPermissions(), PermissionResources.getString(PermissionResourceKeys.APP_VERSION_CREATE), appId);
			}
			boolean isExist = new ServiceEndpoints().reserveApplicationPort(ports, appId);
			Map<String, Object> resultMap = new HashMap<>();
			resultMap.put(Constant.DATA, isExist);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null,response);
		} catch (Exception e) {		
			if(e.getMessage().equals(Constant.UNAUTHORIZED)) {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			} else if(e.getMessage().equals(Constant.NOTPERMITTED)) {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			} else {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, Constants.UNABLE_TO_RESERVE_PORT_FOR_APPLICATION, Constants.UNABLE_TO_RESERVE_PORT_FOR_APPLICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			PALogger.ERROR(e);	
		}
	}
	
	/**
	 * check given application external port assigned for any other application.
	 * @param appId
	 * @param serviceEndpointVO
	 * @param authToken
	 */
	private void mCheckApplicationPortExist(String appId, String externalPort,
			String authToken) {
		try {
			// CHECK AUTH TOKEN...
          // Execute the opearion if Owner of the app OR push on the app
			AuthorizationsVO authVo=new GrpcAuthHelper().getAuthorizationsVO(authToken);
			Applications applications=new Applications();
			//AKH_01_1
			String appOwnerId = applications.getUserIdOfApp(appId);
			if(!appOwnerId.equals(authVo.getUserId()))
			{
				Utility.checkPermission(authVo.getGroupPermissions(), PermissionResources.getString(PermissionResourceKeys.APP_VERSION_CREATE), appId);
			}
			boolean isExist = new ServiceEndpoints().reserveApplicationPort(appId, externalPort);
			Map<String, Object> resultMap = new HashMap<>();
			resultMap.put(Constant.DATA, isExist);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null,response);
		} catch (Exception e) {		
			if(e.getMessage().equals(Constant.UNAUTHORIZED)) {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			} else if(e.getMessage().equals(Constant.NOTPERMITTED)) {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			} else {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_NOT_ACCEPTABLE, e.getMessage(), Constants.UNABLE_TO_RESERVE_PORT_FOR_APPLICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			PALogger.ERROR(e);	
		}
	}
}

/**
 * History of check-in or issue resolved
 * 
 * 01 - 12-10-2016 
 * AKH_01_1
 * Use getUserIdOfApp instead of getAppDetail because we only require userId of application. 
 * 
 */