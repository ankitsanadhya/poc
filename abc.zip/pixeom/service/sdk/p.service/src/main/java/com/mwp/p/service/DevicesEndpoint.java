/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.service;


import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.ValidationException;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.mwp.common.AuthHelper;
import com.mwp.common.Client;
import com.mwp.common.ReturnObject;
import com.mwp.common.StringFunctions;
import com.mwp.common.Utils;
import com.mwp.common.constant.Constant;
import com.mwp.common.constant.ErrorMessage;
import com.mwp.common.constant.PermissionResourceKeys;
import com.mwp.common.constant.PermissionResources;
import com.mwp.common.enums.ActivityOperation;
import com.mwp.common.enums.CommandEnum;
import com.mwp.common.enums.OwnershipEnum;
import com.mwp.common.enums.StatusEnum.VERSION_STATUS;
import com.mwp.common.vo.AuthorizationsVO;
import com.mwp.common.vo.DeviceNodeMasterVO;
import com.mwp.common.vo.DeviceVO;
import com.mwp.common.vo.ErrorVo;
import com.mwp.common.vo.FilterObject;
import com.mwp.common.vo.GroupsVO;
import com.mwp.common.vo.QueryVO;
import com.mwp.common.vo.ValidationInfoVO;
import com.mwp.common.vo.VersionVO;
import com.mwp.logger.PALogger;
import com.mwp.p.authhelper.GrpcAuthHelper;
import com.mwp.p.common.Constants;
import com.mwp.p.common.vo.AppCommandVO;
import com.mwp.p.common.vo.DeviceApplicationVO;
import com.mwp.p.dal.DeviceApplicationsDB;
import com.mwp.p.dal.engine.PortalDatabaseEngine;
import com.mwp.p.dal.engine.ValidationInfoEngine;
import com.mwp.p.dal.engine.VersionEngine;
import com.mwp.p.framework.ActivityLogs;
import com.mwp.p.framework.Applications;
import com.mwp.p.framework.Cluster;
import com.mwp.p.framework.DeveloperApplications;
import com.mwp.p.framework.Devices;
import com.mwp.p.utility.Utility;
import com.sun.research.ws.wadl.HTTPMethods;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/** <h1>DevicesEndpoint</h1>
 * Class hosted at the URI path "/devices"
 * <p>
 * Class manage devices, list devices, list application of devices.
 * </p>
 * @author akh
 * @version 0.0.1
 * @since   2016-08-30 
 */


//description = "Class manage devices, list devices, list application of devices."
@Path("/devices")
@Api( value = "/devices",produces=MediaType.APPLICATION_JSON)
public class DevicesEndpoint {
	@Context
	private HttpServletResponse response;
	@Context
	private HttpServletRequest request;

	/**
	 * Method processing HTTP GET requests, producing "application/json" MIME media-type.
	 * <p> 
	 * This method gives list of device.
	 * </p>
	 * @param httpHeaders
	 * @return String that will be send back as a response of type json.
	 */
	@GET
	@Consumes({ MediaType.APPLICATION_JSON })
	@ApiOperation( value = "List of devices.", 
	notes = "List of devices.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to get list of devices.")
	} )
	public void listDevice(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken){
		mListDevice(authToken, "", true);
	}

	/**
	 * Method processing HTTP GET requests, producing "application/json" MIME media-type.
	 * <p> 
	 * This method gives list of device.
	 * </p>
	 * @param httpHeaders
	 * @return String that will be send back as a response of type json.
	 */
	@GET
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/{deviceid}")
	@ApiOperation( value = "List of devices by device id.", 
	notes = "List of devices by device id.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to get list of devices by device id.")
	} )
	public void getDevice(@ApiParam(value = "deviceid", required = false) @PathParam("deviceid") String deviceId,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken){
		mListDevice(authToken, deviceId, true);
	}


	/**
	 * Method processing HTTP GET requests, producing "application/json" MIME media-type.
	 * 
	 * <p> This method gives list device of application.</p>
	 * @param deviceId request previous page information. 
	 * @param pageNo request previous page information.
	 * @param pageSize request number of categories give in one call.
	 * @param httpHeaders
	 * @return String that will be send back as a response of type json.
	 */
	@GET
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/pages/{pageno}{deviceid:(/device/[^/]+?)?}")
	//@Path("/{pageno}/deviceid/{deviceid}") because we req deviceid optional.
	@ApiOperation( value = "list device of application using paging.", 
	notes = "list device of application using paging.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to get list of devices.")		 
	} )
	public void listDeviceApps(@ApiParam(value = "", required = false) @PathParam("pageno") @DefaultValue("1") int pageNo, 
			@ApiParam(value = "deviceid", required = false) @PathParam("deviceid") String deviceId,
			@ApiParam(value = "", required = false) @QueryParam("pagesize") @DefaultValue("20") int pageSize,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken){
		mListDeviceApps(authToken, pageNo, pageSize, deviceId);
	}

	/**
	 * Method processing HTTP GET requests, producing "application/json" MIME media-type.
	 * 
	 * <p> This method  list device of application.</p>
	 * @param deviceId request previous page information. 
	 * @param pageNo request previous page information.
	 * @param pageSize request number of categories give in one call.
	 * @param httpHeaders
	 * @return String that will be send back as a response of type json.
	 */
	@GET
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/allapps{deviceid:(/device/[^/]+?)?}")
	@ApiOperation( value = "list all application of device .", 
	notes = "list all application of device", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to get list of devices.")
	} )
	public void listAllAppsOfDevice(@ApiParam(value = "deviceid", required = false) @PathParam("deviceid") String deviceId,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken){
		mListAllAppsOfDevice(authToken, deviceId);
	}


	/**
	 * Method processing HTTP GET requests, producing "application/json" MIME media-type.
	 * 
	 * <p> This method gives list device of application.</p>
	 * @param deviceId request previous page information. 
	 * @param pageNo request previous page information.
	 * @param pageSize request number of categories give in one call.
	 * @param httpHeaders
	 * @return String that will be send back as a response of type json.
	 */
	@GET
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/check/{devicename}")
	@ApiOperation( value = "Check device name available.", 
	notes = "Check device name available.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to Check device name available.")
	} )
	public void checkDeviceNameAvailable(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,
			@ApiParam(value = "", required = true) @PathParam("devicename") String deviceName, 
			@ApiParam(value = "macaddress", required = true) @QueryParam("macaddress") String macAddress,
			@ApiParam(value = "userid", required = true) @QueryParam("userid") String userid){
		mCheckDeviceNameAvailable(authToken, deviceName, macAddress);	

	}

	/**
	 * Method processing HTTP GET requests, producing "application/json" MIME
	 * media-type.
	 * 
	 * <p>
	 * This method gives application detail according to requested
	 * applicationId.
	 * </p>
	 * 
	 * @param applicationId
	 * @param httpHeaders
	 * @return
	 */
	@GET
	@Consumes({ MediaType.APPLICATION_JSON })
	//@Path("/{appid}/device/{deviceid}")
	@Path("/{deviceid}/app/{appid}")
	@ApiOperation(value = "application detail according to requested appid and deviceid.", notes = "application detail according to requested appid and deviceid.", response = HashMap.class)
	@ApiResponses({
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to get application detail.")
	})
	public void getInstalledDeviceAppDetailNoPage(@ApiParam(value = "Authorization token", required =true) @HeaderParam("Authorization") String authToken,
			@ApiParam(value = "deviceid of application which details required.", required = true)  @PathParam("deviceid") @NotNull String deviceId,
			@ApiParam(value = "appid of application which details required.", required = true)  @PathParam("appid") @NotNull String applicationId) throws ValidationException {
		mGetInstalledDeviceAppDetail(authToken, applicationId, deviceId);
	}



	/**
	 * Method processing HTTP GET requests, producing "application/json" MIME
	 * media-type.
	 * 
	 * <p>
	 * This method gives application detail according to requested
	 * applicationId.
	 * </p>
	 * 
	 * @param applicationId
	 * @param httpHeaders
	 * @return
	 */
	@GET
	@Consumes({ MediaType.APPLICATION_JSON })
	//@Path("/{appid}/device/{deviceid}")
	@Path("/{deviceid}/app/{appid}/pages/{pageno}")
	@ApiOperation(value = "application detail according to requested appid and deviceid.", notes = "application detail according to requested appid and deviceid.", response = HashMap.class)
	@ApiResponses({
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to get application detail according to requested appid and deviceid.")
	})
	public void getInstalledDeviceAppDetail(@ApiParam(value = "Authorization token", required =true) @HeaderParam("Authorization") String authToken,
			@ApiParam(value = "requested page no for list application.", required = false) @Min(1) @PathParam("pageno") @DefaultValue("1") int pageNo,
			@ApiParam(value = "requested page size number of element return in a list application.", required = false) @Min(1) @QueryParam("pagesize") @DefaultValue("5") int pageSize,
			//			@ApiParam(value = "deviceid of application which details required.", required = true)  @PathParam("deviceid") @NotNull String deviceId,
			@ApiParam(value = "appid of application which details required.", required = true)  @PathParam("appid") @NotNull String applicationId) throws ValidationException {
		mGetInstalledDeviceAppDetail(authToken, applicationId,pageNo,pageSize);
	}


	/**
	 * Method processing HTTP GET requests, producing "application/json" MIME
	 * media-type.
	 * 
	 * <p>
	 * This method gives List of application according to requested search text.
	 * </p>
	 * 
	 * @param pageNo
	 *            request previous page information.
	 * @param pageSize
	 *            request number of applications give in one call.
	 * @param searchText
	 *            requested text for list applications where application name
	 *            starts with 'text'.
	 * @param httpHeaders
	 * @return String that will be send back as a response of type json.
	 */
	@GET
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/search/pages/{pageno}")
	@ApiOperation(value = "List application using requested search text param", notes = "List of application according to requested search text param", response = HashMap.class)
	@ApiResponses({
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to get list of devices.")
	})
	public void search(
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,
			@ApiParam(value = "requested page no for list application.", required = false) @Min(1) @PathParam("pageno") @DefaultValue("1") int pageNo,
			@ApiParam(value = "requested page size number of element return in a list application.", required = false) @Min(1) @QueryParam("pagesize") @DefaultValue("5") int pageSize,
			@ApiParam(value = "HashTable", required = false) @QueryParam("filters") String filters) throws ValidationException{
		mSearch(authToken, pageNo, pageSize, filters);
	}

	/** Method processing HTTP POST requests, producing "application/json" MIME media type.
	 * <p>
	 * This method require DeviceVO object and licenseKey for activate device, check deviceName available or not,
	 * if entry with macAddress already exist then update other info in db.
	 * DeviceVO require these properties (macAddress, hostName, machineId, nativeAppId, deviceName, userId)
	 * </p>
	 * @param activationDetails hashmap of DeviceVO and licenseKey.
	 * @param httpHeaders
	 * @return Json string
	 * @throws Exception 
	 */
	@POST
	@Consumes({MediaType.APPLICATION_JSON})
	@Path("/activate")
	@ApiOperation( value = "activate device.",
	notes = "activate device.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to activate devices.") 
	} )
	public void activateDevice(@Context HttpServletRequest request,@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,
			@ApiParam(value = "updated category object.", required = true) Map<String, Object> activationDetails) {
		mActivateDevice(authToken, activationDetails,request);
	}

	
	/** Method processing HTTP POST requests, producing "application/json" MIME media type.
	 * <p>
	 * This method require DeviceApplicationVO object for add device,
	 * 
	 * </p>
	 * @param deviceVO object of DeviceVO.
	 * @param httpHeaders
	 * @return Json string
	 * @throws Exception 
	 */
	@POST
	@Consumes({MediaType.APPLICATION_JSON})
	@Path("{deviceId}/application")
	@ApiOperation( value = "Add or update application device in to db.",
	notes = "If appId exists for deviceId it updates the entry else create new entry for appId-deviceId.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to add device application.")
	} )
	public void addDeviceApplication(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,
			@ApiParam(value = "", required = true) @PathParam("deviceId") String deviceId, 
			@ApiParam(value = "add device object.", required = true) DeviceApplicationVO deviceAppVO) {
		mAddDeviceApplication(authToken, deviceAppVO);
	}

	/** Method processing HTTP POST requests, producing "application/json" MIME media type.
	 * <p>
	 * This method require DeviceApplicationVO object for add device,
	 * 
	 * </p>
	 * @param deviceVO object of DeviceVO.
	 * @param httpHeaders
	 * @return Json string
	 * @throws Exception 
	 */
	@POST
	@Consumes({MediaType.APPLICATION_JSON})
	@Path("{deviceId}/applications")
	@ApiOperation( value = "Add or update applications of given device in to db.",
	notes = "If appId exists for deviceId it updates the entry else create new entry for appId-deviceId.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to add device application.")	 
	} )
	public void addDeviceApplications(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,
			@ApiParam(value = "", required = true) @PathParam("deviceId") String deviceId, 
			@ApiParam(value = "add device object.", required = true) List<DeviceApplicationVO> deviceAppVOs) {
		mAddDeviceApplication(authToken, deviceAppVOs);
	}

	/** Method processing HTTP PUT requests, producing "application/json" MIME media type.
	 * <p>
	 * This method require deviceId  for update activation status of device
	 * </p>
	 * @param httpHeaders
	 * @return Json string
	 * @throws Exception 
	 */
	@PUT
	@Consumes({MediaType.APPLICATION_JSON})
	@Path("/{deviceid}/updateactivation")
	@ApiOperation( value = "update device.",
	notes = "update device.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to update device activate status.") 
	} )
	public void updateActivationStatus(@ApiParam(value = "id of application.", required = true) @PathParam("deviceid") String deviceId,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken) 
	{
		mUpdateActivationStatus(authToken, deviceId);
	}
	/** Method processing HTTP POST requests, producing "application/json" MIME media type.
	 * <p>
	 * This method remove device-application relation from deviceApplication, 
	 * and change device status = 'DELETED'.
	 * </p>
	 * @param deviceId of Device.
	 * @param httpHeaders
	 * @return Json string
	 * @throws Exception
	 */
	@DELETE
	@Consumes({MediaType.APPLICATION_JSON})
	@Path("/{deviceid}")
	@ApiOperation( value = "delete device.",
	notes = "delete device.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_NOT_FOUND, message = "Requested Appliance not found." ),
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to delete device application.")
	} )
	public void deleteDeviceApplication(@ApiParam(value = "id of device.", required = true) @PathParam("deviceid") String deviceId,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken) {
		mDeleteDeviceApplication(authToken, deviceId);
	}


	/** Method processing HTTP POST requests, producing "application/json" MIME media type.
	 * <p>
	 * This method require list of devices to create cluster from existing activated devices.
	 * clusterName the display name of cluster
	 * </p>
	 * @param devicesList List of DeviceVO.
	 * @param httpHeaders
	 * @return Json string of DeviceVO object type 
	 * @throws Exception 
	 */
	@POST
	@Consumes({MediaType.APPLICATION_JSON})
	@Path("/cluster")
	@ApiOperation( value = "create cluster.",
	notes = "cretate cluster for devices.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to create cluster.")
	} )
	public void createCluster(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,
			@ApiParam(value = "cluster name", required = true) @QueryParam("name") String clusterName,
			@ApiParam(value = "platform name", required = true) @QueryParam("platform") String platformActualName,
			@ApiParam(value = "List of devices to add in cluster.", required = true) Map<String, Object> listProductId) {
		mCreateCluster(authToken, clusterName, platformActualName, listProductId);
	}

	/**
	 * Method processing HTTP GET requests, producing "application/json" MIME media-type.
	 * 
	 * <p> This method  list latest version available for install on given device.</p>
	 * @param deviceId request previous page information. 
	 * @param httpHeaders
	 * @return String that will be send back as a response of type json.
	 */
	@GET
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/listupdates/{deviceid}")
	@ApiOperation( value = "list latest version of application to be updated on device .", 
	notes = "list latest version of application to be updated on device", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to get list latest version of application.")		 
	} )
	public void listUpdates(@ApiParam(value = "deviceid", required = false) @PathParam("deviceid") String deviceId,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken){
		mListUpdates(authToken, deviceId);
	}


	@GET
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/searchdevice/pages/{pageno}/ownership/{ownership}")
	@ApiOperation(value = "List devices using requested search text param", notes = "List of devcies according to requested search text param", response = HashMap.class)
	@ApiResponses({
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to search of devices.")
	})
	public void searchDevice
	(
			@ApiParam(value = "requested page no for list devcie.", required = false) @Min(1) @PathParam("pageno") @DefaultValue("1") int pageNo,
			@ApiParam(value = "requested page size number of element return in a list device.", required = false) @Min(1) @QueryParam("pagesize") @DefaultValue("5") int pageSize,
			@ApiParam(value = "listing device for admin,owner,invitee,both(owner and invitee)", required = false) @Min(0) @PathParam("ownership") @DefaultValue("0") int ownership,
			@ApiParam(value = "FilterObject", required = false) @QueryParam("filters") String filters,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken) throws ValidationException{
		mSearchDevices(authToken,pageNo, pageSize, filters,ownership);
	}

	/**
	 * Method processing HTTP GET requests, producing "application/json" MIME media-type.
	 * 
	 * <p> This method  list latest version available for install on given device.</p>
	 * @param deviceId request previous page information. 
	 * @param httpHeaders
	 * @return String that will be send back as a response of type json.
	 */
	@GET
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/{hostname}/device")
	@ApiOperation( value = "get info of device.", 
	notes = "get info of device.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to find device.")
	} )
	public void getDeviceByHostName(@ApiParam(value = "hostname", required = false) @PathParam("hostname") String hostName,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken){
		mGetDeviceByHostName(authToken, hostName);
	}

	@GET
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/{deviceid}/groups")
	@ApiOperation(value = "List groups of device", notes = "List assigned groups of devcie", response = HashMap.class)
	@ApiResponses({
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to  list group of device."),
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
	})
	public void listGroupsOfDevice(
			@ApiParam(value = "Authorization token", required =true) @HeaderParam("Authorization") String authToken,
			@ApiParam(value = "application id", required = true)  @PathParam("deviceid") String deviceid) {
		mListGroupsOfDevice(authToken, deviceid);
	}



	private void mCreateCluster(String authToken, String clusterName, String platformActualName, Map<String, Object> mapObject)
	{
		try{
			//CHECK AUTH TOKEN...
			String userId = new GrpcAuthHelper().checkAuthorization(authToken);

			String clusterId = mapObject.get("ClusterId").toString();
			//Changes according to multimaster implementation-PS
			TypeToken<DeviceNodeMasterVO> dn = new TypeToken<DeviceNodeMasterVO>() {};
			List<DeviceNodeMasterVO> listProductId = new Gson().fromJson(mapObject.get("Nodes").toString(), new TypeToken<List<DeviceNodeMasterVO>>(){}.getType());

			//Check for cluster Id
			DeviceVO clusterDeviceVO = new Cluster().createCluster(clusterName, userId, clusterId, platformActualName, listProductId);

			Map<String, Object> resultMap=new HashMap<>();
			resultMap.put(Constant.DATA, clusterDeviceVO);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);
		}  catch (Exception e) {
			PALogger.ERROR(e);	
			ErrorVo errorVo = new ErrorVo(
					HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
					"Unable to add cluster.",
					"Unable to add cluster.");
			ReturnObject.createResponse(Constant.FAILURE, null, errorVo,
					response);	
			PALogger.ERROR(e);	

		}
	}


	private void mUpdateCluster(String authToken,String clusterDeviceId, String clusterName)
	{
		try{
			//CHECK AUTH TOKEN...
			new GrpcAuthHelper().checkAuthorization(authToken);
			boolean result = new Cluster().updateClusterName(clusterDeviceId, clusterName);

			Map<String, Object> resultMap=new HashMap<>();
			resultMap.put(Constant.DATA, result);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);
		}  catch (Exception e) {
			PALogger.ERROR(e);	
			ErrorVo errorVo = new ErrorVo(
					HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
					"Unable to add cluster.",
					"Unable to add cluster.");
			ReturnObject.createResponse(Constant.FAILURE, null, errorVo,
					response);	
			PALogger.ERROR(e);	

		}
	}

	@POST
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/devicelist{schedule:(/schedule/[^/]+?)?}")
	@ApiOperation(value = "method execute operation command (systemUpdate).", notes = "method execute operation command (systemUpdate).", response = String.class, responseContainer = "String")
	@ApiResponses({
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized.")})
	public void execute(
			@ApiParam(value = "deviceIds from which we want to executed.", required = true) List<String> deviceIds,
			@ApiParam(value = "operation(systemUpdate) which we want to on app.", required = true) @QueryParam("operation") String operation,
			@ApiParam(value = "schedule", required = false) @PathParam("schedule") String scheduleTicks,
			@ApiParam(value = "Authorization token", required = true) @HeaderParam("Authorization") String authToken) {
		mExecute(authToken,deviceIds,operation,scheduleTicks);
	}

	private void mExecute(String authToken,List<String> deviceIds,String operation, String scheduleTicksValue) 
	{
		try {
			// CHECK AUTH TOKEN...
			// Execute that operation if user has device or not.
			AuthorizationsVO authorizationsVO = new GrpcAuthHelper().getAuthorizationsVO(authToken);
			long scheduleTicks = 0;
			Devices devices = new Devices();
			List<String> lstPermissions = new ArrayList<>();
		    //PP added new operation checks for new jobs which submitted from UI 
			CommandEnum operationEnum = CommandEnum.valueOf(operation);
			
			if(CommandEnum.systemUpdate == operationEnum) 	
				lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.APPLIANCES_SYSTEM_UPDATE));
			else if(CommandEnum.systemReboot == operationEnum) 
				lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.APPLIANCES_SYSTEM_REBOOT));	
			else if(CommandEnum.systemShutdown == operationEnum) 
				lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.APPLIANCES_SYSTEM_SHUTDOWN));
			else if(CommandEnum.systemFactoryReset == operationEnum) 
				lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.APPLIANCES_SYSTEM_FACTORYRESET));	
			else if(CommandEnum.systemReset == operationEnum) 
				lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.APPLIANCES_SYSTEM_RESET));
			
			
			Utility.checkEdgecorePermissionForDevices(authorizationsVO, lstPermissions, deviceIds, false);
			Map<String, String>	 deviceOwners = new Devices().getDevicesOwner(deviceIds);
			if(!StringFunctions.isNullOrWhitespace(scheduleTicksValue)){
				scheduleTicks = Long.parseLong(scheduleTicksValue.split("/")[2]);
				for (String deviceId : deviceIds) {
					devices.scheduleOperation(deviceOwners.get(deviceId), deviceId, operation, scheduleTicks);
				}
			}else{
				devices.scheduleOperation(deviceOwners, deviceIds, operation);
				}
			//insert activity in log
			Map<String, Object> map = new HashMap<>();
			map.put("deviceIds", deviceIds);
			new ActivityLogs().insert(authorizationsVO.getUserId(), operation, new Gson().toJson(map));
			
		}  catch (Exception e) {
			PALogger.ERROR(e);	
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else{
				ErrorVo errorVo = new ErrorVo(
						HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"Unable to submit job.",
						"");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,
						response);
			}
		}
	}

	/** Method processing HTTP POST requests, producing "application/json" MIME media type.
	 * <p>
	 * This method require DeviceVO object for update device,
	 * if entry with macAddress already exist then update other info in db.
	 * DeviceVO require these properties (macAddress, hostName, machineId, nativeAppId, deviceName, userId)
	 * </p>
	 * @param deviceVO object of DeviceVO.
	 * @param httpHeaders
	 * @return Json string
	 * @throws Exception 
	 */
	@PUT
	@Consumes({MediaType.APPLICATION_JSON})
	@Path("/cluster")
	@ApiOperation( value = "add device to cluster.",
	notes = "add device to cluster.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_CONFLICT, message = "" )	 
	} )
	public void addDeviceToCluster(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,
			@ApiParam(value = "List of devices to add in cluster.", required = true)  Map<String, Object> mapObject)
	{
		mAddDeviceToCluster(authToken, mapObject);
	}

	private void mAddDeviceToCluster(String authToken,  Map<String, Object> mapObject) {
		try
		{
			//CHECK AUTH TOKEN...
			String userId = new GrpcAuthHelper().checkAuthorization(authToken);

			String clusterId = mapObject.get("ClusterId").toString();
			List<DeviceNodeMasterVO> listProductId = new Gson().fromJson(mapObject.get("Nodes").toString(), new TypeToken<List<DeviceNodeMasterVO>>(){}.getType());

			if(listProductId.isEmpty())
				throw new Exception(Constant.NOTFOUND);
			new Cluster().addDevicesToCluster(clusterId, listProductId);

			//insert activity in log
			new ActivityLogs().insert(userId, ActivityOperation.addDeviceToCluster.name(), new Gson().toJson(mapObject));
			Map<String, Object> resultMap=new HashMap<>();
			resultMap.put(Constant.DATA, "");
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);
		} 
		catch (Exception e) 
		{
			PALogger.ERROR(e);	
			ErrorVo errorVo = null;
			if(e.getMessage().equals(Constant.NOTFOUND))
			{
				errorVo = new ErrorVo(
						HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"No nodes found to add.",
						"No nodes found to add.");

			}
			else
			{
				errorVo = new ErrorVo(
						HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"Unable to add device to cluster.",
						"Unable to add device to cluster.");

			}
			ReturnObject.createResponse(Constant.FAILURE, null, errorVo,
					response);	
			PALogger.ERROR(e);
		}}

	private void mSearch(String authToken,int pageNo, int pageSize,
			String filters) 
	{
		try {
			new GrpcAuthHelper().checkAuthorization(authToken);
			Map<String, Object> filtersObject = null;
			if(!StringFunctions.isNullOrWhitespace(filters)) {
				filtersObject = new Gson().fromJson(filters,new TypeToken<Hashtable<String, Object>>() {}.getType());
			}
			Map<String, Object> resultMap = new Devices().searchDevices(pageNo,pageSize, filtersObject);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null,response);
		}  catch (Exception e) {
			PALogger.ERROR(e);
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(
						HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"Unable to list devices.",
						"Unable to list devices.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,
						response);
			}
		}
	}

	/** Method processing HTTP POST requests, producing "application/json" MIME media type.
	 * <p>
	 * This method remove device-application relation from deviceApplication, 
	 * and change device status = 'DELETED'.
	 * </p>
	 * @param deviceId of Device.
	 * @param httpHeaders
	 * @return Json string
	 * @throws Exception
	 */
	@DELETE
	@Consumes({MediaType.APPLICATION_JSON})
	@Path("/newdevice/{productId}")
	@ApiOperation( value = "delete new device.",
	notes = "delete new device.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_CONFLICT, message = "device not exist." )	 
	} )
	public void deleteNewDeviceApplication(@ApiParam(value = "id of device.", required = true) @PathParam("productId") String productId,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken) {
		mDeleteNewDeviceApplication(authToken, productId);
	}


	private void mDeleteNewDeviceApplication(String authToken, String productId) {
		try {
			//CHECK AUTH TOKEN...
			String userId = new GrpcAuthHelper().checkAuthorization(authToken);
			List<QueryVO> queries = new DeviceApplicationsDB().deleteNewDeviceApplication(productId);
			PortalDatabaseEngine.getInstance().getConnection().executeUpdatesInTransaction(queries);
			//insert activity in log
			Map<String, String> map = new HashMap<>();
			map.put("productId", productId);
			new ActivityLogs().insert(userId, ActivityOperation.deleteDeviceApplication.name(), new Gson().toJson(map));

			ReturnObject.createResponse(Constant.SUCCESS, productId, null, response);

		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to list device app.", "Unable to list device app.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			PALogger.ERROR(e);	
		}

	}


	private void mDeleteDeviceApplication(String authToken, String deviceId) {
		try {
			AuthorizationsVO authorizationsVO = null;
			if(!StringFunctions.isNullOrWhitespace(authToken) && authToken.toLowerCase().startsWith(Constant.JWT_BEARER.toLowerCase())) {
				authorizationsVO = new AuthHelper().checkJwtToken(authToken, response);
			}else{
				//CHECK AUTH TOKEN...
				authorizationsVO = new GrpcAuthHelper().getAuthorizationsVO(authToken);			
			}
				Devices devices=new Devices();

				List<String> lstPermissions = new ArrayList<>();
				lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.APPLIANCES_DELETEOFFLINE));
				Utility.checkEdgecorePermission(authorizationsVO, lstPermissions, deviceId, false);

				String deviceOwner= "";
				List<String> devicesLst = new ArrayList<>();
				devicesLst.add(deviceId);
				Map<String, String> out=  devices.getDevicesOwner(devicesLst);
				if(out.containsKey(deviceId))
					deviceOwner =out.get(deviceId);
				DeviceVO result = devices.deleteDeviceApplication(deviceId, deviceOwner);
				ReturnObject.createResponse(Constant.SUCCESS, result.getDeviceId(), null, response);
			}
			catch (Exception e) {
				PALogger.ERROR(e);	
				if(e.getMessage().equals(ErrorMessage.DEVICE_NOT_FOUND)){
					ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_NOT_FOUND , "Requested Appliance not found.", "Requested Appliance not found.");
					ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
				}
				else if(e.getMessage().equals(Constant.NOTPERMITTED))
				{
					ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
					ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
				}
				else if(e.getMessage().equals(Constant.UNAUTHORIZED)){
					ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
					ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
				}else{
					ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to list device app.", "Unable to list device app.");
					ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
				}
			}
		}

	private void mListDevice(String authToken, String deviceId, boolean isListLabels)
	{
		try {
			//CHECK AUTH TOKEN...
			String userId = new GrpcAuthHelper().checkAuthorization(authToken);

			Devices devices=new Devices();
			List< DeviceVO>listDeviceVOs=devices.listDevice(userId, deviceId,isListLabels);
			Map<String, Object> resultMap=new HashMap<>();
			resultMap.put(Constant.DATA, listDeviceVOs);

			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);

		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to list devices.", "Unable to list devices.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			PALogger.ERROR(e);	
		}
	}

	private void mActivateDevice(String authToken,Map<String, Object> activationDetails,HttpServletRequest request)
	{
		try {
			//CHECK AUTH TOKEN...
			new GrpcAuthHelper().checkAuthorization(authToken);

			Gson gson=new Gson();
			String strDevice = gson.toJson(activationDetails.get("device"));
			DeviceVO deviceVO = gson.fromJson(strDevice, DeviceVO.class);
			String licenseKey = activationDetails.get("licenseKey").toString();

			String network = activationDetails.get("network").toString();
			Map<String, String> networkMap= new HashMap<>();
			networkMap.put("boxNetwork", network);
			networkMap.put("ipAddress", request.getHeader("X-Real-IP"));
			String networkStr = gson.toJson(networkMap);

			String jwtPublicKey = activationDetails.get("jwtPublicKey").toString();
			//call activateDevice method.
			Map<String, Object> deviceNodeIdMap = new Devices().activateDevice(deviceVO, licenseKey,networkStr,jwtPublicKey);

			long timestamp = new Date().getTime();
			ValidationInfoVO validInfoVO = new ValidationInfoVO();
			validInfoVO.setnPreviousTS(0);
			validInfoVO.setnStatus(0);
			validInfoVO.setnTimestamp(timestamp);
			validInfoVO.setsCode("0");
			validInfoVO.setsGUID(Utils.randomUUID());
			validInfoVO.setsInternetAddress("0.0.0.0");
			validInfoVO.setsMACAddress(deviceVO.getNodeVO().getMacAddress());

			validInfoVO.setEmail(deviceVO.getNodeVO().getEmail());
			validInfoVO.setHostName(deviceVO.getNodeVO().getHostName());
			validInfoVO.setHwConfig("");
			validInfoVO.setSwLicense("");
			/*
			 * add validation info in db.
			 */			
			new ValidationInfoEngine().addValidationInfo(validInfoVO);


			Map<String, Object> result = deviceNodeIdMap;//Assigjing deviceId and nodeId in result 
			result.put("validationResult", validInfoVO);

			//generate validation info


			Map<String, Object> resultMap=new HashMap<>();
			resultMap.put(Constant.DATA, result);			
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);

		} catch (Exception e) {
			PALogger.ERROR(e);	
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if (e.getMessage().equals(ErrorMessage.DEVICE_NAME_NOT_AVAILABLE) ||
					e.getMessage().equals(ErrorMessage.INVALID_LICENSE))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR ,e.getMessage(), e.getMessage());
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}

			else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to activate device.", "Unable to activate device.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
		}
	}



	private void mListDeviceApps(String authToken, int pageNo, int pageSize, String deviceId)
	{
		try {
			//CHECK AUTH TOKEN...
			String userId=new GrpcAuthHelper().checkAuthorization(authToken);
			if(!StringFunctions.isNullOrWhitespace(deviceId)){
				deviceId = deviceId.replace("/device/", "").trim();
			}
			Devices devices=new Devices();
			// list only user's devices.
			Map<String, Object> resultMap = devices.listDeviceApplication(pageNo, pageSize, userId, deviceId);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);

		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to list device app.", "Unable to list device app.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			PALogger.ERROR(e);	
		}
	}


	private void mListAllAppsOfDevice(String authToken, String deviceId)
	{
		try {
			//CHECK AUTH TOKEN...
			AuthorizationsVO authVo=new GrpcAuthHelper().getAuthorizationsVO(authToken);
			
			Devices devices=new Devices();
			// list only user's devices.
			List<DeviceApplicationVO> appList=devices.listAllAppsOfDevice(authVo, deviceId);
			Map<String, Object> resultMap=new HashMap<>();
			resultMap.put(Constant.DATA, appList);

			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);

		} catch (Exception e)
		{
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to list device app.", "Unable to list device app.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			PALogger.ERROR(e);	
		}
	}


	private void mCheckDeviceNameAvailable(String authToken, String deviceName, String macAddress)
	{
		try {
			//CHECK AUTH TOKEN...
			new GrpcAuthHelper().checkAuthorization(authToken);

			boolean result = new Devices().isDeviceNameAvailable(deviceName, macAddress);
			Map<String, Object> resultMap=new HashMap<>();
			resultMap.put(Constant.DATA, result);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);

		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to get device name.", "Unable to get device name.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			PALogger.ERROR(e);	
		}
	}


	private void mAddDeviceApplication(String authToken, DeviceApplicationVO deviceAppVO) {
		try {
			AuthorizationsVO authVo;
			if(authToken.toLowerCase().startsWith(Constant.JWT_BEARER.toLowerCase())) {
		
				authVo = new AuthHelper().checkJwtToken(authToken, response);
			}
			else{
					//CHECK AUTH TOKEN...
				authVo = new AuthorizationsVO();
				authVo.setUserId(new GrpcAuthHelper().checkAuthorization(authToken));
			}
			//call addDeviceApplication method.
			deviceAppVO = new Devices().addDeviceApplication(deviceAppVO);
			//insert activity in log
			new ActivityLogs().insert(authVo.getUserId(), ActivityOperation.addDeviceApplication.name(), new Gson().toJson(deviceAppVO));
			

			//Create response 
			Map<String, Object> resultMap=new HashMap<>();
			resultMap.put(Constant.DATA, deviceAppVO);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);
		} catch (Exception e) {
			PALogger.ERROR(e);	
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, e);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to add device application.", e);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			PALogger.ERROR(e);	
		}
	}

	private void mAddDeviceApplication(String authToken, List<DeviceApplicationVO> deviceAppVOs) {
		try {
			if(authToken.toLowerCase().startsWith(Constant.JWT_BEARER.toLowerCase())) {

				new AuthHelper().checkJwtToken(authToken, response);
			}
			else{
				//CHECK AUTH TOKEN...
				new GrpcAuthHelper().checkAuthorization(authToken);
			}
			//call addDeviceApplication method.
			List<String> appIDs = new Devices().addUpdateDeviceApplication(deviceAppVOs);

			//Create response 
			Map<String, Object> result=new HashMap<>();
			result.put(Constant.DATA, appIDs);
			ReturnObject.createResponse(Constant.SUCCESS, result, null, response);
		} 
		catch (Exception e) 
		{
			PALogger.ERROR(e);	
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, e);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to add device applications.", e);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			PALogger.ERROR(e);	
		}
	}


	private void mUpdateActivationStatus(String authToken, String deviceId) {
		try 
		{
			//CHECK AUTH TOKEN...
			new GrpcAuthHelper().checkAuthorization(authToken);
			//call addDevice method.
			new Devices().updateActivationStatus(deviceId);
			Map<String, Object> resultMap=new HashMap<>();
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);

		} catch (Exception e) {
			PALogger.ERROR(e);	
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to update device.", "Unable to update device.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			PALogger.ERROR(e);	
		}
	}
	
	//AKH_01_1
	private void mGetInstalledDeviceAppDetail(String authToken, String appId, String deviceId) {
		try {
			// CHECK AUTH TOKEN...
			AuthorizationsVO authorizationsVO =	new GrpcAuthHelper().getAuthorizationsVO(authToken);
			DeviceApplicationVO deviceappVO = new Applications().getInstalledDeviceAppDetail(appId, deviceId);

			List<AppCommandVO> actions = null;

			if(authorizationsVO!=null)
			{
				List<String> grpIds =null;
				if(authorizationsVO.getGroupPermissions()!=null)
					grpIds = new ArrayList<>(authorizationsVO.getGroupPermissions().keySet());
				actions = new Applications().getAppCommandsForUser(appId, authorizationsVO.getUserId(),grpIds);
			}

			Map<String, Object> data = new HashMap<>();
			data.put("application", deviceappVO);

			if (actions!=null) {
				data.put("actions", actions);
			}


			Map<String, Object> resultMap = new HashMap<>();
			resultMap.put(Constant.DATA, data);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null,response);
		} 
		catch (Exception e) {
			PALogger.ERROR(e);	
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(
						HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"Unable to get application detail.",
						"Unable to get application detail");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,
						response);
			}
		}
	}



	private void mGetInstalledDeviceAppDetail(String authToken, String appId,int pageNo, int pageSize) {
		try {
			// CHECK AUTH TOKEN...
			AuthorizationsVO authorizationsVO =	new GrpcAuthHelper().getAuthorizationsVO(authToken);
			Map<String, Object> deviceappVO = new Applications().getInstalledDeviceAppDetail(appId,pageNo,pageSize);

			List<AppCommandVO> actions = null;

			if(authorizationsVO!=null)
			{
				List<String> grpIds =null;
				if(authorizationsVO.getGroupPermissions()!=null)
					grpIds = new ArrayList<>(authorizationsVO.getGroupPermissions().keySet());
				actions = new Applications().getAppCommandsForUser(appId, authorizationsVO.getUserId(),grpIds);
			}

			Map<String, Object> data = new HashMap<>();
			data.put("application", deviceappVO.get(Constant.DATA));

			if (actions!=null) {
				data.put("actions", actions);
			}

			deviceappVO.put(Constant.DATA, data);
			ReturnObject.createResponse(Constant.SUCCESS, deviceappVO, null,response);
		} 
		catch (Exception e) {
			PALogger.ERROR(e);	
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(
						HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"Unable to get application detail.",
						"Unable to get application detail");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,
						response);
			}
		}
	}





	@DELETE
	@Consumes({MediaType.APPLICATION_JSON})
	@Path("/{deviceid}/nodes/{nodeid}")
	@ApiOperation( value = "delete node from cluster.",
	notes = "delete node from cluster.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_CONFLICT, message = "device not exist." )	 
	} )
	public void deleteCluserNode(@ApiParam(value = "id of device.", required = true) @PathParam("deviceid") String deviceId,
			@ApiParam(value = "id of node.", required = true) @PathParam("nodeid") String nodeId,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken) {
		mDeleteCluserNode(authToken, nodeId, deviceId);
	}


	private void mDeleteCluserNode(String authToken, String nodeId, String deviceId) {
		try {
			//CHECK AUTH TOKEN...
			String userId = new GrpcAuthHelper().checkAuthorization(authToken);
			Devices devices=new Devices();
			PALogger.INFO("********** deleteClusterNode ****** nodeId: "+ nodeId + " deviceId: "+deviceId);
			boolean result = devices.deleteClusterNode(nodeId, deviceId,  false);
			//insert activity in log
			Map<String, String> map = new HashMap<>();
			map.put("nodeId", nodeId);
			map.put("deviceId", deviceId);
			new ActivityLogs().insert(userId, ActivityOperation.deleteClusterNode.name(), new Gson().toJson(map));

			ReturnObject.createResponse(Constant.SUCCESS, result, null, response);
		}
		catch (Exception e) {
			PALogger.ERROR(e);	
			if(e.getMessage().equals(ErrorMessage.DEVICE_NOT_FOUND)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_NOT_FOUND , "Requested Appliance not found.", "Requested Appliance not found.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to list device app.", "Unable to list device app.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
		}
	}

	@DELETE
	@Consumes({MediaType.APPLICATION_JSON})
	@Path("/nodes/{nodeid}/olddeviceid/{deviceid}")
	@ApiOperation( value = "delete node from cluster.",
	notes = "remove node from cluster without factory reset.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_CONFLICT, message = "device not exist." )	 
	} )
	public void softFactoryResetNode(@ApiParam(value = "the previous id of device before added in cluster.", required = true) @PathParam("deviceid") String oldDeviceId,
			@ApiParam(value = "id of node.", required = true) @PathParam("nodeid") String nodeId,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken) {
		mSoftFactoryResetNode(authToken, nodeId, oldDeviceId);
	}

	private void mSoftFactoryResetNode(String authToken, String nodeId, String oldDeviceId) {
		try {
			String userId  = "";
			if(!StringFunctions.isNullOrWhitespace(authToken) && authToken.toLowerCase().startsWith(Constant.JWT_BEARER.toLowerCase())) {
				userId = new AuthHelper().checkJwtToken(authToken, response).getUserId();
			}else{
			
			//CHECK AUTH TOKEN...
			userId = new GrpcAuthHelper().checkAuthorization(authToken);
			}
			Devices devices=new Devices();
			devices.removeNodeFromCluster(nodeId, oldDeviceId, userId);
			
			//insert activity in log
			Map<String, String> map = new HashMap<>();
			map.put("nodeId", nodeId);
			map.put("oldDeviceId", oldDeviceId);
			new ActivityLogs().insert(userId, ActivityOperation.softFactoryResetNode.name(), new Gson().toJson(map));
			ReturnObject.createResponse(Constant.SUCCESS, null, null, response);
		}
		catch (Exception e) {
			PALogger.ERROR(e);	
			if(e.getMessage().equals(ErrorMessage.DEVICE_NOT_FOUND)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_NOT_FOUND , "Requested Appliance not found.", "Requested Appliance not found.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(ErrorMessage.MASTER_DELETE_REQUEST)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_NOT_ACCEPTABLE , "Can not factory reset master device.", "Can not factory reset master device.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to list device app.", "Unable to list device app.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
		}
	}

	private void mListUpdates(String authToken, String deviceId) {
		try {
			AuthorizationsVO authVo;
			if(authToken.toLowerCase().startsWith(Constant.JWT_BEARER.toLowerCase())) {

				authVo=new AuthHelper().checkJwtToken(authToken, response);
			}
			else{
				//CHECK AUTH TOKEN...
				 authVo=new GrpcAuthHelper().getAuthorizationsVO(authToken);
			}
			
			String userId=authVo.getUserId();
			Devices devices=new Devices();

			List<DeviceApplicationVO> userApps = new ArrayList<>();
			
			Map<String, Object> ownerMap;
			List<Map<String, Object>> ownerInviteAppVersions = new ArrayList<>();
			boolean isInvitee = false;
			List<VERSION_STATUS> filterVersionStatus = new ArrayList<>();
			filterVersionStatus.add(VERSION_STATUS.LIVE);
			filterVersionStatus.add(VERSION_STATUS.REVIEWED);
			List<DeviceApplicationVO> appList=devices.listAllAppsOfDevice(authVo, deviceId);
			for (DeviceApplicationVO deviceApplicationVO : appList) 
			{
				List<VersionVO> versionVOs;
				if(deviceApplicationVO.getUserId().equals(userId))
				{//APP OWNER

					versionVOs = new DeveloperApplications().getVersionsOfApplication(deviceApplicationVO.getApplicationId(), userId, deviceApplicationVO.getVerionId(), deviceApplicationVO.getVersionVO().getAppPlatformId(), filterVersionStatus);
					if(!versionVOs.isEmpty())
					{
						ownerMap = new HashMap<>();
						ownerMap.put("appId", deviceApplicationVO.getApplicationId());
						ownerMap.put("versions", versionVOs);				
						ownerInviteAppVersions.add(ownerMap);
					}
				}else
				{//Check if invitee or user
					isInvitee = false;
					try{
						Utility.checkPermission(authVo.getGroupPermissions(),PermissionResources.getString(PermissionResourceKeys.APP_VERSION_INSTALL), deviceApplicationVO.getApplicationId());
						isInvitee  = true;
					}catch(Exception e){
						if(StringFunctions.isNullOrWhitespace(e.getMessage()) || !e.getMessage().equals(Constant.NOTPERMITTED)){
							throw e;
						}
					}
					if(isInvitee){
						versionVOs = new VersionEngine().getVersionsOfGroupApp(deviceApplicationVO.getApplicationId(),authVo,deviceApplicationVO.getVersionVO().getVersionId(), deviceApplicationVO.getVersionVO().getAppPlatformId(), filterVersionStatus);
						if(!versionVOs.isEmpty())
						{
							ownerMap = new HashMap<>();
							ownerMap.put("appId", deviceApplicationVO.getApplicationId());
							ownerMap.put("versions", versionVOs);				
							ownerInviteAppVersions.add(ownerMap);
						}
					}
					else
					{
						userApps.add(deviceApplicationVO);
					}
				}
			}




			List<Map<String, String>> installedAppVersionList = new ArrayList<>();
			if(!userApps.isEmpty())
			{
				
				Applications app = new Applications();
				for (DeviceApplicationVO userApp : userApps) {
					boolean isUpdateAvailable =  app.getUpdateAvailableForInstalledApp(userApp.getApplicationId(), userApp.getVerionId(), userApp.getVersionVO().getAppPlatformId());
					if(isUpdateAvailable){
						Map<String, String> appVersions= new HashMap<>();
						appVersions.put("appId", userApp.getApplicationId());
						installedAppVersionList.add(appVersions);
					}
				}

			}

			boolean isUpdateFound = false;
			if(!installedAppVersionList.isEmpty() || !ownerInviteAppVersions.isEmpty())
				isUpdateFound = true;
			Map<String, Object> resultMap=new HashMap<>();
			resultMap.put("InstalledApp", installedAppVersionList);
			resultMap.put("OwnerApp", ownerInviteAppVersions);
			resultMap.put("isUpdateFound", isUpdateFound);


			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);

		} catch (Exception e)
		{
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to list device app.", "Unable to list device app.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			PALogger.ERROR(e);	
		}
	}

	private void mSearchDevices(String authToken ,int pageNo, int pageSize,String filters,int ownershipOrdinal) {
		try {
			AuthorizationsVO authorizationsVO;
			if(authToken.toLowerCase().startsWith(Constant.JWT_BEARER.toLowerCase())) {
			
				authorizationsVO=  new AuthHelper().checkJwtToken(authToken, response);
			}
			else{
				//CHECK AUTH TOKEN...
				 authorizationsVO = new GrpcAuthHelper().getAuthorizationsVO(authToken);
			}
			List<FilterObject> filtersObject = null;
			if(!StringFunctions.isNullOrWhitespace(filters))
			{
				filtersObject = new Gson().fromJson(filters,new TypeToken<ArrayList<FilterObject>>() {}.getType());
			}
			Devices device = new Devices();
			OwnershipEnum ownership= OwnershipEnum.values()[ownershipOrdinal];
			Map<String, Object> resultMap = device.listDeviceFilter(authorizationsVO.getUserId(),pageNo,pageSize, filtersObject, false,ownership,authorizationsVO);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null,response);
		}  
		catch (Exception e) {
			PALogger.ERROR(e);	
			ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,"Unable to list applications.","Unable to list applications.");
			ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);	
			PALogger.ERROR(e);	

		}
	}

	/** Method processing HTTP POST requests, producing "application/json" MIME media type.
	 * <p>
	 * This method require labelIds list and device id to add device in multiple labels.
	 * </p>
	 * @param 
	 * @param httpHeaders
	 * @return Json string
	 * @throws Exception 
	 */ 
	@PUT
	@Consumes({MediaType.APPLICATION_JSON})
	@Path("/deviceId/{deviceid}/labels")
	@ApiOperation( value = "add device to label.",
	notes = "add Devices to lable.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_CONFLICT, message = "")  
	} )
	public void addDeviceLabel(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,
			@ApiParam(value = "id of device.", required = true) @PathParam("deviceid") String deviceId,
			@ApiParam(value = "list of labels.", required = true) List<String> listLabelIds)

	{
		mAddDeviceToLabels(deviceId, listLabelIds, authToken);
	}

	private void mAddDeviceToLabels(  String deviceId, List<String> labelIds, String authToken) 
	{
		try {
			String userId = 	new GrpcAuthHelper().checkAuthorization(authToken);
			new Devices().addDeviceToLabels(labelIds, deviceId);
			//insert activity in log
			Map<String, Object> map = new HashMap<>();
			map.put("labelIds", labelIds);
			map.put("deviceId", deviceId);
			new ActivityLogs().insert(userId, ActivityOperation.addDeviceLabel.name(), new Gson().toJson(map));
			
			Map<String, Object> resultMap=new HashMap<>();
			resultMap.put(Constant.DATA, true);

			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);
		} catch (Exception e) {
			PALogger.ERROR(e);	
			if(e.getMessage().equals(Constant.UNAUTHORIZED)) {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			} else {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to add device to label list.", "Unable to add device to label list.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			PALogger.ERROR(e);	
		}
	}

	private void mListGroupsOfDevice(String authToken, String deviceId) {
		try {
			AuthorizationsVO authorizationsVO = new GrpcAuthHelper().getAuthorizationsVO(authToken);
			Devices deviceObj = new Devices();
			List<String> groupsIds;
			//If device owner list all groups otherwise list only groups that this user is invited to. 
			String adminUserId = deviceObj.getUserId(deviceId);
			if(adminUserId.equals(authorizationsVO.getUserId())){
				groupsIds = deviceObj.listGroupsOfDevice(deviceId, null);
			}else{
				groupsIds = deviceObj.listGroupsOfDevice(deviceId, (authorizationsVO.getGroupPermissions()==null || authorizationsVO.getGroupPermissions().isEmpty()) ? null :new ArrayList<String>(authorizationsVO.getGroupPermissions().keySet()));
			}

			if(!groupsIds.isEmpty()){
				//call auth method for list groups...
				Map<Object,Object> queryParam = new HashMap<>();
				queryParam.put("groupids", new Gson().toJson(groupsIds));
				String result = Client.callServer(Constants.AUTH_SERVER_IP_PORT,Constants.AUTH_SERVICE_NAME, "group",  HTTPMethods.GET.name(), "list", queryParam, null, Constant.BEARER + authToken);
				ReturnObject.createResponse(Constant.SUCCESS, new Gson().fromJson(result, Map.class), null, response);
			}
			else {
				List<GroupsVO> groupsVOs = new ArrayList<>();
				Map<String, Object> resultMap = new HashMap<>();
				resultMap.put(Constant.DATA, groupsVOs);
				ReturnObject.createResponse(Constant.SUCCESS, resultMap, null,
						response);
			}
		} 
		catch (Exception e) {
			PALogger.ERROR(e);	
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(
						HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"Unable to list groups of device.",
						"Unable to list groups of device.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,
						response);
			}
		}
	}



	private void mGetDeviceByHostName(String authToken ,String hostName){
		try{
			//CHECK AUTH TOKEN...
			new GrpcAuthHelper().checkAuthorization(authToken);

			Devices device = new Devices();
			DeviceVO deviceVO = device.getDeviceByHostName(hostName);
			Map<String, Object> resultMap = new HashMap<>();
			resultMap.put(Constant.DATA, deviceVO);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null,response);
		} catch (Exception e) {
			PALogger.ERROR(e);	
			ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,"Unable to find device.","Unable to find device.");
			ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);	
			PALogger.ERROR(e);	

		}
	}


	/** Method processing HTTP POST requests, producing "application/json" MIME media type.
	 * <p>
	 * The method check whether the cluster with cluster id exists or not.And if cluster exists then the node exists in this cluster or not.
	 * </p>
	 * @param cluster id
	 * @param node id
	 * @param httpHeaders	 * 
	 * @return Json string
	 * @throws Exception
	 */
	@GET
	@Consumes({MediaType.APPLICATION_JSON})
	@Path("/check/{clusterid}/{nodeid}")
	@ApiOperation( value = " check if cluster exists or device exists or not.",
	notes = "check cluster and node exists or not.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_CONFLICT, message = "device not exist." )	 
	} )
	public void checkCluterNodeExists(@ApiParam(value = "id of cluster.", required = true) @PathParam("clusterid") String clusterId,
			@ApiParam(value = "id of device.", required = true) @PathParam("nodeid") String nodeId,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken) {
		mCheckCluterNodeExists( clusterId, nodeId);
	}


	@GET
	@Consumes({MediaType.APPLICATION_JSON})
	@Path("/check")
	@ApiOperation( value = " check if any of the devices exists with specified ids sent as list.",
	notes = "check if any of the devices exists with specified ids sent as list.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_CONFLICT, message = "Device not found." )	 
	} )
	public void checkCluterIdsExists(@ApiParam(value = "list of device ids.", required = true) @QueryParam("deviceids") String deviceIds,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken) {
		mCheckAnyDeviceExist( deviceIds);
	}


	/**
	 * Checks whether any of supplied device ids exist or not
	 * @param authToken
	 * @param deviceIds
	 * @author DB,RA
	 */
	private void mCheckAnyDeviceExist(String deviceIds)
	{
		try 
		{
			Devices devices= new Devices();
			Gson gsonObject = new Gson();
			TypeToken<ArrayList<String>> token = new TypeToken<ArrayList<String>>() {};
			ArrayList<String> deviceidList = gsonObject.fromJson(deviceIds, token.getType());
			devices.checkDeviceExist(deviceidList);

			ReturnObject.createResponse(Constant.SUCCESS, null, null, response);

		} catch (Exception e) {
			PALogger.ERROR(e);
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(ErrorMessage.DEVICE_NOT_FOUND))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , ErrorMessage.DEVICE_NOT_FOUND, ErrorMessage.DEVICE_NOT_FOUND);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			
			else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to get device.", "Unable to get device.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
		}
	}

	private void mCheckCluterNodeExists(String clusterId, String nodeId)
	{
		try {
			Devices devices=new Devices();

			devices.checkClusterNodeExsitance(clusterId, nodeId);

			ReturnObject.createResponse(Constant.SUCCESS, null, null, response);

		} catch (Exception e) {
			PALogger.ERROR(e);
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(ErrorMessage.DEVICE_NOT_FOUND))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , ErrorMessage.DEVICE_NOT_FOUND, ErrorMessage.DEVICE_NOT_FOUND);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(ErrorMessage.CLUSTER_NOT_FOUND))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , ErrorMessage.CLUSTER_NOT_FOUND, ErrorMessage.CLUSTER_NOT_FOUND);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to get device.", "Unable to get device.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
		}
	}

	

}

/**
 * History of check-in or issue resolved
 * 
 * 01 - 12-10-2016 
 * AKH_01_1
 * Shifted getInstalledDeviceAppDetail FROM ApplicationsEndpoint.
 * 
 */
