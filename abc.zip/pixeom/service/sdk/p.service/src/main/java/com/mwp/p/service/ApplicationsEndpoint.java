/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.service;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicInteger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.ValidationException;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import org.apache.commons.fileupload.FileItemIterator;
import org.apache.commons.fileupload.FileItemStream;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.fileupload.util.Streams;
import org.apache.commons.io.FileUtils;

import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.mwp.common.AuthHelper;
import com.mwp.common.Client;
import com.mwp.common.CommandExecutor;
import com.mwp.common.Common;
import com.mwp.common.ReturnObject;
import com.mwp.common.StringFunctions;
import com.mwp.common.TempFiles;
import com.mwp.common.constant.Constant;
import com.mwp.common.constant.ErrorMessage;
import com.mwp.common.constant.PermissionResourceKeys;
import com.mwp.common.constant.PermissionResources;
import com.mwp.common.enums.ActivityOperation;
import com.mwp.common.enums.ApplicationDefaultType;
import com.mwp.common.enums.CommandEnum;
import com.mwp.common.enums.StatusEnum.VERSION_STATUS;
import com.mwp.common.vo.AppInstallDetailsVO;
import com.mwp.common.vo.AppResourceVO;
import com.mwp.common.vo.ApplicationDetailsVO;
import com.mwp.common.vo.ApplicationPlatformVO;
import com.mwp.common.vo.ApplicationVO;
import com.mwp.common.vo.AuthorizationsVO;
import com.mwp.common.vo.ErrorVo;
import com.mwp.common.vo.FilterObject;
import com.mwp.common.vo.GroupsVO;
import com.mwp.common.vo.VersionVO;
import com.mwp.common.yamlparser.SecretVo;
import com.mwp.logger.PALogger;
import com.mwp.p.authhelper.GrpcAuthHelper;
import com.mwp.p.common.AdminPermissionCheck;
import com.mwp.p.common.Constants;
import com.mwp.p.common.vo.AppCommandVO;
import com.mwp.p.common.vo.AppTypeVO;
import com.mwp.p.dal.engine.ApplicationResourceEngine;
import com.mwp.p.dal.engine.VersionEngine;
import com.mwp.p.framework.ActivityLogs;
import com.mwp.p.framework.Applications;
import com.mwp.p.framework.DeveloperApplications;
import com.mwp.p.framework.Devices;
import com.mwp.p.framework.Platform;
import com.mwp.p.framework.PortalFileUpload;
import com.mwp.p.utility.Utility;
import com.pa.crypto.StringEncryptionDecryption;
import com.sun.research.ws.wadl.HTTPMethods;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * <h1>ApplicationsEndpoint</h1> Class hosted at the URI path "/applications"
 * <p>
 * Class manage application, return list top application in a category, search
 * application according to filters, suggest application according to type text,
 * give details of application and manage install/uninstall/update command.
 * </p>
 * 
 * @author akh
 * @version 0.0.1
 * @since 2016-08-30
 */

// "Class manage application, return list top application in a category,
//"search application according to filters, suggest application according to type text,
//"give details of application and manage install/uninstall/update command."
@Path("/applications")
@Api(value = "/applications", produces = MediaType.APPLICATION_JSON)
public class ApplicationsEndpoint {

	@Context
	private HttpServletResponse response;



	/**
	 * Method processing HTTP GET requests, producing "application/json" MIME
	 * media-type.
	 * 
	 * <p>
	 * This method gives List of application according to requested search text.
	 * </p>
	 * 
	 * @param pageNo
	 *            request previous page information.
	 * @param pageSize
	 *            request number of applications give in one call.
	 * @param searchText
	 *            requested text for list applications where application name
	 *            starts with 'text'.
	 * @param httpHeaders
	 * @return String that will be send back as a response of type json.
	 */
	@GET
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/search/pages/{pageno}")
	@ApiOperation(value = "List application using requested search text param", notes = "List of application according to requested search text param", response = HashMap.class)
	@ApiResponses({
		@ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to search applications.")})
	public void search(
			@ApiParam(value = "requested page no for list application.", required = false) @Min(1) @PathParam("pageno") @DefaultValue("1") int pageNo,
			@ApiParam(value = "requested page size number of element return in a list application.", required = false) @Min(1) @QueryParam("pagesize") @DefaultValue("5") int pageSize,
			@ApiParam(value = "FilterObject", required = false) @QueryParam("filters") String filters) throws ValidationException{
		mSearch(pageNo, pageSize, filters);
	}

	/**
	 * Method processing HTTP GET requests, producing "application/json" MIME
	 * media-type.
	 * 
	 * <p>
	 * This method gives List of application which start with 'search text'
	 * application name.
	 * </p>
	 * 
	 * @param searchText
	 *            requested text for list applications where application name
	 *            starts with 'text'.
	 * @param httpHeaders
	 * @return String that will be send back as a response of type json.
	 */
	@GET
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/suggestion")
	@ApiOperation(value = "List application using requested search text param", notes = "List of application according to requested search text param", response = HashMap.class)
	@ApiResponses({
		@ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to get suggestions applications.")})
	public void suggestion(
			@ApiParam(value = "list application where application name start with 'search text'.", required = true) 
			@QueryParam("searchtext") String searchText) {
		mSuggestion(searchText);
	}

	/**
	 * Method processing HTTP GET requests, producing "application/json" MIME
	 * media-type.
	 * 
	 * <p>
	 * This method gives application detail according to requested
	 * applicationId.
	 * </p>
	 * 
	 * @param applicationId
	 * @param httpHeaders
	 * @return
	 */
	@GET
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/{appid}")
	@ApiOperation(value = "application detail according to requested applicationId.", notes = "application detail according to requested applicationId.", response = HashMap.class)
	@ApiResponses({
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to get applications."),
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized.")
	})
	public void getAppDetail(@ApiParam(value = "Authorization token", required =true) @HeaderParam("Authorization") String authToken,
			@ApiParam(value = "appid of application which details required.", required = true)  @PathParam("appid") @NotNull String applicationId) throws ValidationException {
		mGetAppDetail(authToken, applicationId);
	}

	@GET
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/{appid}/install/{deviceid}/device")
	@ApiOperation(value = "application detail according to requested applicationId.", notes = "application detail according to requested applicationId.", response = HashMap.class)
	@ApiResponses({
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to get detail applications."),
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse(code = HttpServletResponse.SC_NO_CONTENT, message = "Application not supported on your device platform.") })
	public void getInstallAppDetail(@ApiParam(value = "Authorization token", required =false) @HeaderParam("Authorization") String authToken,
			@ApiParam(value = "versionId", required = false) @QueryParam("versionId") String versionId,
			@ApiParam(value = "appid of application which details required.", required = true) @PathParam("appid") String applicationId,
			@ApiParam(value = "deviceid of device where want to application install.", required = true) @PathParam("deviceid") String deviceId) {
		mGetInstallAppDetail(authToken, applicationId,versionId,deviceId);
	}
	//AKH_01_2

	/**
	 * Method processing HTTP GET requests, producing "application/json" MIME media-type.
	 * 
	 * <p>
	 * This method check update for requested application,
	 * which have already existing appVersionId.
	 * </p>
	 * @param authToken
	 * @param appVersionId
	 * @throws ValidationException
	 */
	@GET
	@Consumes({ MediaType.APPLICATION_JSON })
	@Produces({ MediaType.APPLICATION_JSON })
	@Path("/{appid}/checkupdate/version/{versionid}")
	@ApiOperation(value = "Check version of requested appVersionId", notes = "Check version of requested appVersionId.", response = HashMap.class)
	@ApiResponses({
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to check update of applications."),
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized.")
	})
	public void checkUpdate(@ApiParam(value = "Authorization token", required =true) @HeaderParam("Authorization") String authToken,
			@ApiParam(value = "appId of application.", required = true)  @PathParam("appid") @NotNull String appId,
			@ApiParam(value = "versionId of application.", required = true)  @PathParam("versionid") @NotNull String appVersionId) throws ValidationException {
		mCheckUpdate(authToken,appId,appVersionId);
	}


	@POST
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/{appid}/devicelist{schedule:(/schedule/[^/]+?)?}")
	@ApiOperation(value = "method execute operation command (install/uninstall/update).", notes = "method execute operation command (install/uninstall/update).", response = String.class, responseContainer = "String")
	@ApiResponses({
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to execute."),
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
	})
	public void executeAll(
			@ApiParam(value = "applicationId which we want executed.", required = true) @PathParam("appid") String applicationId,
			@ApiParam(value = "deviceId from which we want to executed.", required = true) List<String> deviceIds,	
			@ApiParam(value = "operation(install/uninstall/update) which we want to on app.", required = true) @QueryParam("operation") String operation,
			@ApiParam(value = "versionId", required = false) @QueryParam("versionId") String versionId,	
			@ApiParam(value = "isRetainSecret", required = false) @QueryParam("isRetainSecret") boolean retainSecret,
			@ApiParam(value = "schedule", required = false) @PathParam("schedule") String scheduleTicks,
			@ApiParam(value = "Authorization token", required = true) @HeaderParam("Authorization") String authToken) 
	{
		mExecuteAll(authToken,applicationId,deviceIds,operation,versionId,scheduleTicks,false,null,retainSecret);
	}

	@POST
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/{appid}/secretdevicelist{schedule:(/schedule/[^/]+?)?}")
	@ApiOperation(value = "method execute operation command (install/uninstall/update).", notes = "method execute operation command (install/uninstall/update).", response = String.class, responseContainer = "String")
	@ApiResponses({
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to execute."),
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
	})
	public void executeSecretAll(
			@ApiParam(value = "applicationId which we want executed.", required = true) @PathParam("appid") String applicationId,
			@ApiParam(value = "deviceId from which we want to executed.", required = true) Map<String, Object> ids,	
			@ApiParam(value = "operation(install/uninstall/update) which we want to on app.", required = true) @QueryParam("operation") String operation,
			@ApiParam(value = "versionId", required = false) @QueryParam("versionId") String versionId,	
			@ApiParam(value = "isRetainSecret", required = false) @QueryParam("isRetainSecret") boolean retainSecret,
			@ApiParam(value = "schedule", required = false) @PathParam("schedule") String scheduleTicks,
			@ApiParam(value = "Authorization token", required = true) @HeaderParam("Authorization") String authToken) 
	{
		mExecuteAll(authToken, applicationId, null, operation, versionId, scheduleTicks, true, ids, retainSecret);
	}




	@GET
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/{appid}/groups")
	@ApiOperation(value = "List groups of application", notes = "List assigned groups of app", response = HashMap.class)
	@ApiResponses({
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to get list group of applications."),
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
	})
	public void listGroupsOfApp(
			@ApiParam(value = "Authorization token", required =true) @HeaderParam("Authorization") String authToken,
			@ApiParam(value = "application id", required = true)  @PathParam("appid") String appId) {
		mListGroupsOfApp(authToken, appId);
	}

	@GET
	@Path("/appType")
	@Consumes({MediaType.APPLICATION_JSON})
	@ApiOperation( value = "List of application type", 
	notes = "List of  application types.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to get all applications type."),
	} )
	public void getAllAppType()
	{
		mgetAllAppType();
	}

	@GET
	@Path("/{appid}/resources")
	@ApiOperation( value = "Upload application resource file", notes = "Upload application resource file.", 
	response = AppResourceVO.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to add app version details." )
	} )
	public void getAppResources(@ApiParam(value = "id of application.", required = true) @PathParam("appid") String appId,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken) 
	{
		mGetAppResources(authToken, appId);
	}

	@POST	
	@Path("/validateyaml")
	@ApiOperation( value = "Validate YAML", 
	notes = "validate yaml on portal.")
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_BAD_REQUEST, message = "Invalid composer file provided."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to add app version details." )
	} )
	public void validateYaml(@Context HttpServletRequest uploadedInputStream,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken) 
	{
		mValidateYamlFile(authToken, uploadedInputStream);
	}

	@POST
	@Path("/{appid}/resources")
	@ApiOperation( value = "Upload application resource file", notes = "Upload application resource file.", 
	response = AppResourceVO.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to add app version details." )
	} )
	public void uploadAppResource(@Context HttpServletRequest uploadedInputStream,
			@ApiParam(value = "id of application.", required = true) @PathParam("appid") String appId,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken) 
	{
		mUploadAppResource(authToken, appId, uploadedInputStream);
	}

	@DELETE
	@Path("/{appid}/resources/{resourceId}")
	@ApiOperation( value = "Upload application resource file", notes = "Upload application resource file.", 
	response = AppResourceVO.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to add app version details." )
	} )
	public void deleteAppResource(@ApiParam(value = "id of application.", required = true) @PathParam("appid") String appId,
			@ApiParam(value = "id of resource.", required = true) @PathParam("resourceId") String resourceId,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken) 
	{
		mDeleteAppResource(authToken, appId, resourceId);
	}

	private void mListGroupsOfApp(String authToken, String appId) {
		try {
			AuthorizationsVO authorizationsVO = new GrpcAuthHelper().getAuthorizationsVO(authToken);
			Applications applications = new Applications();
			List<String> groupsIds;
			//If app owner list all groups otherwise list only groups that this user is invited to. 
			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_PROJECTS));
			AdminPermissionCheck.checkAdminPermission(authorizationsVO, lstPermissions, true);

			String adminUserId = new Applications().getUserIdOfApp(appId);
			if(adminUserId.equals(authorizationsVO.getUserId())){
				groupsIds = applications.listGroupsOfApp(appId, null);
			}else{
				groupsIds = applications.listGroupsOfApp(appId, (authorizationsVO.getGroupPermissions()==null || authorizationsVO.getGroupPermissions().isEmpty()) ? null :new ArrayList<String>(authorizationsVO.getGroupPermissions().keySet()));
			}

			if(!groupsIds.isEmpty()){
				//call auth method for list groups...
				Map<Object,Object> queryParam = new HashMap<>();
				queryParam.put("groupids", new Gson().toJson(groupsIds));
				String result = Client.callServer(Constants.AUTH_SERVER_IP_PORT,Constants.AUTH_SERVICE_NAME, "group",  HTTPMethods.GET.name(), "list", queryParam, null, Constant.BEARER + authToken);
				ReturnObject.createResponse(Constant.SUCCESS, new Gson().fromJson(result, Map.class), null, response);
			}
			else {
				List<GroupsVO> groupsVOs = new ArrayList<>();
				Map<String, Object> resultMap = new HashMap<>();
				resultMap.put(Constant.DATA, groupsVOs);
				ReturnObject.createResponse(Constant.SUCCESS, resultMap, null,
						response);
			}
		} 
		catch (Exception e) {
			PALogger.ERROR(e);	
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(
						HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"Unable to list groups of app.",
						"Unable to list groups of app.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,
						response);
			}
		}
	}


	private void mSearch(int pageNo, int pageSize,
			String filters) {
		try {
			List<FilterObject> filtersObject = null;
			if(!StringFunctions.isNullOrWhitespace(filters)) {				
				filtersObject = new Gson().fromJson(filters,
						new TypeToken<ArrayList<FilterObject>>() {
				}.getType());			
			}

			Applications applications = new Applications();
			Map<String, Object> resultMap = applications.searchApps(pageNo,
					pageSize, filtersObject,false);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null,
					response);
		}  catch (Exception e) {
			PALogger.ERROR(e);	
			ErrorVo errorVo = new ErrorVo(
					HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
					Constants.UNABLE_TO_LIST_APPLICATIONS,
					Constants.UNABLE_TO_LIST_APPLICATIONS);
			ReturnObject.createResponse(Constant.FAILURE, null, errorVo,
					response);			

		}
	}
	private void mValidateYamlFile(String authToken, HttpServletRequest uploadedInputStream) {

		ServletFileUpload fileUpload = new ServletFileUpload();

		Map<String,Object> resultMap = new HashMap<>();
		String tempfilepath = TempFiles.getTempFolderPath() ;
		try {
			//CHECK AUTH TOKEN...
			AuthorizationsVO authVo = new GrpcAuthHelper().getAuthorizationsVO(authToken);


			String filename = "validate.yml";
			if(ServletFileUpload.isMultipartContent(uploadedInputStream))
			{
				FileItemIterator items = fileUpload.getItemIterator(uploadedInputStream);
				while (items.hasNext())
				{
					FileItemStream item = items.next();
					if (!item.isFormField()) 
					{
						try(InputStream inputstream = item.openStream()){
							new PortalFileUpload().inputStreamToFile(inputstream,tempfilepath + filename);
						}
					}
				}
			}
			HashMap<String, String>  result = mValidateYaml(tempfilepath + filename);

			if(result.get("result").equals("0")){ // SUCCESS

				resultMap.put(Constant.DATA, true);
				ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);

			} else { // ERROR
				String validateresult ="";
				try{
					validateresult = result.get("message");
					PALogger.INFO(validateresult);

					String temppath = "'" + tempfilepath + filename + "' ";

					if(validateresult.indexOf(temppath) > 0)// filepath is exist
					{
						validateresult = validateresult.replace(temppath, "");

					}else if(validateresult.indexOf( tempfilepath + filename) > 0)
					{
						validateresult = validateresult.replace(tempfilepath + filename, "");
					}				

				}catch (Exception e) {
					PALogger.ERROR(e);	
				}
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_BAD_REQUEST , validateresult, validateresult);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}

		}catch (Exception e) {
			PALogger.ERROR(e);	
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			} 
			else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to validate composer file.", "Unable to validate composer file.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			PALogger.ERROR(e);	
		}
		finally {
			FileUtils.deleteQuietly(new File(tempfilepath));
		}

	}
	private HashMap<String, String> mValidateYaml(String filepath) throws InterruptedException, IOException, ExecutionException, TimeoutException{

		HashMap<String, String> result = new HashMap<>();
		List<String> command = new ArrayList<>();
		command.add("docker-compose");
		command.add("-f");
		command.add(filepath);
		command.add("config");
		command.add("-q");

		AtomicInteger exitValue = new AtomicInteger(-1);

		String msg = new CommandExecutor().Execute(command, exitValue);
		result.put("result", String.valueOf(exitValue.get()));
		result.put("message", msg);
		PALogger.TRACE(result);
		return result;
	}


	private void mSuggestion( String searchText) {
		try {
			Applications applications = new Applications();
			List<ApplicationVO> applicationVOs = applications
					.listApps(searchText);
			Map<String, Object> resultMap = new HashMap<>();
			resultMap.put(Constant.DATA, applicationVOs);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null,
					response);
		} catch (Exception e) {

			PALogger.ERROR(e);
			ErrorVo errorVo = new ErrorVo(
					HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
					Constants.UNABLE_TO_LIST_APPLICATIONS,
					Constants.UNABLE_TO_LIST_APPLICATIONS);
			ReturnObject.createResponse(Constant.FAILURE, null, errorVo,
					response);			
		}
	}

	private void mGetAppDetail(String authToken, String applicationId) {
		try {
			// CHECK AUTH TOKEN...
			AuthorizationsVO authorizationsVO = null;
			if(!StringFunctions.isNullOrWhitespace(authToken)) {
				authorizationsVO =	new GrpcAuthHelper().getAuthorizationsVO(authToken);
			}

			Applications applications = new Applications();
			ApplicationDetailsVO applicationVO = applications.getAppDetail(applicationId,authorizationsVO !=null ? authorizationsVO.getUserId():"");
			List<AppCommandVO> actions = null;

			//if user not loggedin then no need to set actions of app - BY RA
			if(authorizationsVO!=null)
			{
				List<String> grpIds =null;
				if(authorizationsVO.getGroupPermissions()!=null)
					grpIds = new ArrayList<>(authorizationsVO.getGroupPermissions().keySet());
				actions = applications.getAppCommandsForUser(applicationId, authorizationsVO.getUserId(),grpIds);
			}


			if (applicationVO!=null) {
				//AKH_01_1
				Map<String, Object> data = new HashMap<>();
				data.put("application", applicationVO);

				if (actions!=null) {
					data.put("actions", actions);
				}
				Map<String, Object> resultMap = new HashMap<>();
				resultMap.put(Constant.DATA, data);
				ReturnObject.createResponse(Constant.SUCCESS, resultMap, null,
						response);
			}
			else{
				//if Application not found for given application Id then throw NOTFOUND exception. 
				throw new Exception(Constant.NOTFOUND);
			}
		} 
		catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTFOUND)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_NOT_FOUND , "Application not found", "No application found with requested application Id");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else{
				ErrorVo errorVo = new ErrorVo(
						HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"Unable to get application detail.",
						"Unable to get application detail");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,
						response);

			}
			PALogger.ERROR(e);	

		}
	}

	private void mGetInstallAppDetail(String authToken, String applicationId,String versionId, String deviceId) {
		try {

			if(authToken.toLowerCase().startsWith(Constant.JWT_BEARER.toLowerCase())) {

				new AuthHelper().checkJwtToken(authToken, response);
			}
			else{
					// CHECK AUTH TOKEN...
				new GrpcAuthHelper().checkAuthorization(authToken);
			}
		
			Applications applications = new Applications();
			ApplicationPlatformVO appPlatformVO = new Platform().getDeviceApplicationPlatForm(applicationId, deviceId);
			if(appPlatformVO == null){
				throw new Exception(Constant.NOTFOUND);
			}
			AppInstallDetailsVO applicationVO = applications.getAppInstallDetail(applicationId, versionId, appPlatformVO.getAppPlatformId());

			applicationVO.setSecretKey(StringEncryptionDecryption.encrypt(applicationVO.getSecretKey(), deviceId));

			/*
			 * If any invitee or app owner install version of app then versionId always set.
			 * InstalledByUser property use for check updates on box. if this property TRUE then box user check only next available versions
			 * otherwise check for LIVE version.
			 */
			if(!StringFunctions.isNullOrWhitespace(versionId))
				applicationVO.setDeveloperAppInstall(true);

			Map<String, Object> resultMap = new HashMap<>();
			resultMap.put(Constant.DATA, applicationVO);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null,
					response);
		} 
		catch (Exception e) {
			PALogger.ERROR(e);	
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			} else if(e.getMessage().equals(Constant.NOTFOUND)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_NO_CONTENT,
						"Application not supported on your device platform.","Application not supported on your device platform.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,
						response);
			}
			else if(e.getMessage().equals(ErrorMessage.APPLICATION_NOT_FOUND))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						ErrorMessage.APPLICATION_NOT_FOUND, ErrorMessage.APPLICATION_NOT_FOUND);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,
						response);
			}
			else{
				ErrorVo errorVo = new ErrorVo(
						HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"Unable to get application detail.",
						"Unable to get application detail");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,
						response);
			}

		}
	}


	/**
	 * 
	 * @param authToken
	 * @param applicationId
	 * @param deviceId
	 * @param operation
	 * @param versionId
	 * @param scheduleTicks If null then executes right now, else long ticks at time when it needs to be scheduled
	 */

	private void mExecuteAll(String authToken,String applicationId,List<String> deviceIds,String operation,String versionId, String scheduleTicksValue,boolean isSecrets, Map<String, Object> ids, boolean retainSecret) 
	{
		try 
		{
			final String RESOURCES = "resources";
			List<String> resourcesIds = null;
			List<SecretVo> lstSecretVo= new ArrayList<>();
			AuthorizationsVO authorizationsVO; 
			if(authToken.toLowerCase().startsWith(Constant.JWT_BEARER.toLowerCase())) {

				authorizationsVO = new AuthHelper().checkJwtToken(authToken, response);
			}
			else{

			// CHECK AUTH TOKEN...
			// Execute that operation if user has device or not.
			 authorizationsVO = new GrpcAuthHelper().getAuthorizationsVO(authToken);
			}
			//if call is executed for custom secrets, get secrets and devices from ids hashmap.
			if(isSecrets)
			{
				deviceIds= (List<String>) ids.get("devices") ;
				if(ids.containsKey("secrets")){
					String str= new Gson().toJson(ids.get("secrets"));
					lstSecretVo = new Gson().fromJson(str, new TypeToken<ArrayList<SecretVo>>(){}.getType());
				}
				if(ids.containsKey(RESOURCES)) {
					resourcesIds = (List<String>) ids.get(RESOURCES) ;
				}
			}
			CommandEnum operationEnum = CommandEnum.valueOf(operation);
			Applications applications=new Applications();
			long scheduleTicks = 0;
			List<String> lstPermissions = new ArrayList<>();
			if(CommandEnum.installApplication == operationEnum
					||CommandEnum.updateApplication == operationEnum
					||CommandEnum.updateAppSecret == operationEnum)
				lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.APPLIANCES_APP_INSTALL));
			else if(CommandEnum.uninstallApplication == operationEnum )
				lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.APPLIANCES_APP_UNINSTALL));
			else if(CommandEnum.startApplication == operationEnum) //PP added new operation checks for new jobs which submitted from UI 
				lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.APPLIANCES_APP_START));
			else if(CommandEnum.restartApplication == operationEnum) 
				lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.APPLIANCES_APP_RESTART));
			else if(CommandEnum.stopApplication == operationEnum) 
				lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.APPLIANCES_APP_STOP));
			Utility.checkEdgecorePermissionForDevices(authorizationsVO, lstPermissions, deviceIds, false);

			Map<String, String>	 deviceOwners = new Devices().getDevicesOwner(deviceIds);
			if(!StringFunctions.isNullOrWhitespace(scheduleTicksValue))
			{
				scheduleTicks = Long.parseLong(scheduleTicksValue.split("/")[2]);

				for (String deviceId : deviceIds) 
				{
					applications.scheduleOperation(deviceOwners.get(deviceId), applicationId, deviceId, operation, versionId, scheduleTicks,lstSecretVo,retainSecret, resourcesIds);	
				}
			}
			else{
				applications.scheduleOperationAll(deviceOwners, applicationId, deviceIds, operation, versionId,lstSecretVo,retainSecret, resourcesIds);
			}

			//add in activity log
			HashMap<String, Object> map = new HashMap<>();
			map.put("ApplicationId", applicationId);
			map.put("DeviceIds", deviceIds);
			//here operation is same as in ActivityOperationEnum
			new ActivityLogs().insert(authorizationsVO.getUserId(),operation, new Gson().toJson(map));


		}  catch (Exception e) {
			PALogger.ERROR(e);	
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			//#HDV_01_1
			else if(e.getMessage().equals(Constant.VERSIONNOTAVAILABLE) || e.getMessage().equals(Constant.APPISNOTAVAILABLE)) 
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR ,e.getMessage(), e.getMessage());
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else{
				ErrorVo errorVo = new ErrorVo(
						HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"Unable to submit job.",
						"");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,
						response);
			}

		}

	}


	private void mCheckUpdate(String authToken,String appId,String appVersionId) {
		try {
			AuthorizationsVO authVo;
			if(authToken.toLowerCase().startsWith(Constant.JWT_BEARER.toLowerCase())) {

				 authVo=new AuthHelper().checkJwtToken(authToken, response);
			}
			else{
					//CHECK AUTH TOKEN...
				 authVo=new GrpcAuthHelper().getAuthorizationsVO(authToken);
			}
		
			String userId=authVo.getUserId();
			List<String> lstDetails = new Applications().getAppVersionAndUserIdOfApp(appVersionId);
			if(!lstDetails.isEmpty()){
				String appOwnerId = lstDetails.get(1);
				String appPlatformId = lstDetails.get(2);
				List<VersionVO> lstVersions;
				Map<String, Object> data = new HashMap<>();
				List<VERSION_STATUS> filterVersionStatus = new ArrayList<>();
				filterVersionStatus.add(VERSION_STATUS.LIVE);
				filterVersionStatus.add(VERSION_STATUS.REVIEWED);				 
				if(appOwnerId.equals(userId)){//APP OWNER
					lstVersions = new DeveloperApplications().getVersionsOfApplication(appId, userId, appVersionId, appPlatformId, filterVersionStatus);
					data.put("versions", lstVersions);
				}else{//Check if invitee or user
					boolean isInvitee = false;
					try{
						Utility.checkPermission(authVo.getGroupPermissions(),PermissionResources.getString(PermissionResourceKeys.APP_VERSION_INSTALL), appId);
						isInvitee  = true;
					}catch(Exception e){
						if(StringFunctions.isNullOrWhitespace(e.getMessage()) || !e.getMessage().equals(Constant.NOTPERMITTED)){
							throw e;
						}
					}
					if(isInvitee){
						lstVersions = new VersionEngine().getVersionsOfGroupApp(appId,authVo,appVersionId, appPlatformId, filterVersionStatus);
						data.put("versions", lstVersions);
					}
					else{
						boolean  isUpdateAvailable=new Applications().getUpdateAvailableForInstalledApp(appId, appVersionId, appPlatformId);
						data.put("isUpdateAvailable", isUpdateAvailable);
					}
				}
				Map<String, Object> resultMap = new HashMap<>();
				resultMap.put(Constant.DATA, data);

				ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);
			}else{
				//if Application not found for given application Id then throw NOTFOUND exception. 
				throw new Exception(Constant.NOTFOUND);
			}


		} catch (Exception e) {
			System.out.println(e);
			e.printStackTrace();
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"Unable to check update", "Unable to check update");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			PALogger.ERROR(e);	
		}
	}

	private void mgetAllAppType() 
	{

		try
		{

			DeveloperApplications developerApplications=new DeveloperApplications();
			List<AppTypeVO> typeVOs = developerApplications.getAllAppType();
			Map<String, Object> resultMap = new HashMap<>();
			resultMap.put(Constant.DATA, typeVOs);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);
		} 
		catch (Exception e) 
		{

			ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,"Unable to list application type", "Unable to list application type");
			ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);

			PALogger.ERROR(e);	
		}
	}

	private void mGetAppResources(String authToken, String appId) {
		try {
			AuthorizationsVO authVo = new GrpcAuthHelper().getAuthorizationsVO(authToken);
			String appOwnerId = new Applications().getUserIdOfApp(appId);
			if(!appOwnerId.equals(authVo.getUserId())) {
				Utility.checkPermission(authVo.getGroupPermissions(), PermissionResources.getString(PermissionResourceKeys.APP_RESOURCES_LIST), appId);
			}

			ApplicationResourceEngine applicationResourceEngine = new ApplicationResourceEngine();
			List<AppResourceVO> appResourceVOs = applicationResourceEngine.getForApp(appId);

			Map<String,Object> data = new HashMap<>();
			data.put(Constant.DATA, appResourceVOs);
			ReturnObject.createResponse(Constant.SUCCESS, data, null, response);

		} catch (Exception e) {
			PALogger.ERROR(e);	
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			} else if(e.getMessage().equals(Constant.NOTPERMITTED)) {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			} else {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to list application resource.", "Unable to list application resource.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
		}
	}

	private void mUploadAppResource(String authToken, String appId, HttpServletRequest uploadedInputStream) {
		Map<String, String> formItems = new HashMap<>();
		Map<String, String> inputstreamHash = new HashMap<>();
		try {

			AuthorizationsVO authVo = new GrpcAuthHelper().getAuthorizationsVO(authToken);
			String appOwnerId = new Applications().getUserIdOfApp(appId);
			if(!appOwnerId.equals(authVo.getUserId())) {
				Utility.checkPermission(authVo.getGroupPermissions(), PermissionResources.getString(PermissionResourceKeys.APP_RESOURCES_CREATE), appId);
			}

			if(ServletFileUpload.isMultipartContent(uploadedInputStream)) {

				ServletFileUpload fileUpload = new ServletFileUpload();
				FileItemIterator items = fileUpload.getItemIterator(uploadedInputStream);

				while (items.hasNext()) {
					FileItemStream item = items.next();
					if (!item.isFormField()) {
						try(InputStream inputstream = item.openStream()){
							String tempfilepath = new PortalFileUpload().inputStreamToFile(inputstream, TempFiles.getTempFolderPath() + item.getName());

							inputstreamHash.put(item.getFieldName(), tempfilepath);
						}
					} else {
						try(InputStream inputstream = item.openStream()){
							formItems.put(item.getFieldName(), Streams.asString(inputstream));
						}
					}
				}

				Type listAppResourcesType =  new TypeToken<ArrayList<AppResourceVO>>(){}.getType();
				List<AppResourceVO> appResourceVOs = new Gson().fromJson(formItems.get("resources"), listAppResourcesType);

				ApplicationVO appvo = new Applications().getApplicationBasicDetail(appId);
				List<AppTypeVO> types = new DeveloperApplications().getAllAppType();
				ApplicationDefaultType type = ApplicationDefaultType.dockercompose;
				for (AppTypeVO appTypeVO : types) {
					if(appvo.getAppTypeId().equals(appTypeVO.getTypeId())){
						type =  ApplicationDefaultType.valueOf(appTypeVO.getType());
					}
				}

				String uploadResourceBasePath = Constants.PORTAL_FILES_PATH + Constants.PORTAL_APP_FOLDER_NAME + Constant.localFileSeparator + appId + Constant.localFileSeparator;

				for (AppResourceVO appResourceVO : appResourceVOs) {
					appResourceVO.setAppId(appId);
					appResourceVO.setAppResourceId(Common.getRandomId());

					appResourceVO.setFilePath(inputstreamHash.get(appResourceVO.getFieldName()));
					if(!Utility.validateResource(type, appResourceVO)) {
						throw new Error("Invalid " + appResourceVO.getKind().getDisplayName() + " file provided for " + appResourceVO.getServiceName() + " service.");
					}

					appResourceVO.setFilePath(uploadResourceBasePath + appResourceVO.getKind().getFolderName() + appResourceVO.getAppResourceId() + Constant.localFileSeparator + new File(inputstreamHash.get(appResourceVO.getFieldName())).getName());
				}

				new PortalFileUpload().uploadAppResources(appResourceVOs, inputstreamHash);
				List<AppResourceVO> appResourceVOsDb = new ApplicationResourceEngine().add(appResourceVOs);

				//add activity log in db
				ActivityOperation operation = ActivityOperation.addAppResources;
				HashMap<String, String> map = new HashMap<>();
				map.put("applicationId", appId);
				new ActivityLogs().insert(authVo.getUserId(),operation.name(), new Gson().toJson(map));

				Map<String,Object> data = new HashMap<>();
				data.put(Constant.DATA, appResourceVOsDb);
				ReturnObject.createResponse(Constant.SUCCESS, data, null, response);
			} else {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constants.UNABLE_TO_UPLOAD_APPLICATION_RESOURCE,  Constants.UNABLE_TO_UPLOAD_APPLICATION_RESOURCE);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
		} catch (Error e) {
			ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , e.getMessage(), e.getMessage());
			ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
		} catch (Exception e) {
			PALogger.ERROR(e);	
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			} else if(e.getMessage().equals(Constant.NOTPERMITTED)) {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			} else {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR ,  Constants.UNABLE_TO_UPLOAD_APPLICATION_RESOURCE,  Constants.UNABLE_TO_UPLOAD_APPLICATION_RESOURCE);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
		} finally {
			for (Entry<String, String> tempFiles : inputstreamHash.entrySet()) {
				FileUtils.deleteQuietly(new File(tempFiles.getValue()).getParentFile());
			}
		}
	}

	private void mDeleteAppResource(String authToken, String appId, String resourceId) {
		try {

			AuthorizationsVO authVo = new GrpcAuthHelper().getAuthorizationsVO(authToken);
			String appOwnerId = new Applications().getUserIdOfApp(appId);
			if(!appOwnerId.equals(authVo.getUserId())) {
				Utility.checkPermission(authVo.getGroupPermissions(), PermissionResources.getString(PermissionResourceKeys.APP_RESOURCES_DELETE), appId);
			}
			AppResourceVO appResourceVO = new ApplicationResourceEngine().delete(resourceId);
			FileUtils.deleteDirectory(new File(appResourceVO.getFilePath()).getParentFile());
			Map<String,Object> data = new HashMap<>();
			data.put(Constant.DATA, appResourceVO);
			ReturnObject.createResponse(Constant.SUCCESS, data, null, response);			
		} catch (Exception e) {
			PALogger.ERROR(e);	
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			} else if(e.getMessage().equals(Constant.NOTPERMITTED)) {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			} else {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR ,  Constants.UNABLE_TO_UPLOAD_APPLICATION_RESOURCE,  Constants.UNABLE_TO_UPLOAD_APPLICATION_RESOURCE);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
		}
	}
}

/**
 * History of check-in or issue resolved
 * 
 * 01 - 12-10-2016 
 * AKH_01_1
 * Remove projectVO from returnParam, because companyName and companyWebAddress set in applicationVO object.
 * AKH_01_2
 * Shifted getInstalledDeviceAppDetail to DevicesEndpoint.
 * 
 * 01
 * 01-08-2018
 * HDV_01_1
 * Add catch block for require error messages.# BugId 1830. 
 */
