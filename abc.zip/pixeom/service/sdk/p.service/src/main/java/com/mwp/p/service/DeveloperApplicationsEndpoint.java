/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.service;

import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import javax.validation.ValidationException;
import javax.validation.constraints.NotNull;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import org.apache.commons.fileupload.FileItemIterator;
import org.apache.commons.fileupload.FileItemStream;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.fileupload.util.Streams;
import org.apache.commons.io.FileUtils;

import com.google.gson.Gson;
import com.mwp.common.AuthHelper;
import com.mwp.common.Common;
import com.mwp.common.ReturnObject;
import com.mwp.common.StringFunctions;
import com.mwp.common.TempFiles;
import com.mwp.common.Utils;
import com.mwp.common.constant.Constant;
import com.mwp.common.constant.ErrorMessage;
import com.mwp.common.constant.PermissionResourceKeys;
import com.mwp.common.constant.PermissionResources;
import com.mwp.common.enums.ActivityOperation;
import com.mwp.common.enums.SecretTypeEnum;
import com.mwp.common.enums.Status;
import com.mwp.common.enums.StatusEnum.VERSION_STATUS;
import com.mwp.common.vo.ApplicationDetailsVO;
import com.mwp.common.vo.ApplicationImagesVO;
import com.mwp.common.vo.ApplicationPlatformVO;
import com.mwp.common.vo.ApplicationVO;
import com.mwp.common.vo.AuthorizationsVO;
import com.mwp.common.vo.DevAppDetailsVO;
import com.mwp.common.vo.ErrorVo;
import com.mwp.common.vo.VersionVO;
import com.mwp.common.yamlparser.SecretVo;
import com.mwp.logger.PALogger;
import com.mwp.p.authhelper.GrpcAuthHelper;
import com.mwp.p.common.AdminPermissionCheck;
import com.mwp.p.common.Constants;
import com.mwp.p.common.PortalCommon;
import com.mwp.p.common.vo.AppCommandVO;
import com.mwp.p.common.vo.DeveloperApplicationVO;
import com.mwp.p.common.vo.ProjectVO;
import com.mwp.p.framework.ActivityLogs;
import com.mwp.p.framework.AppSecret;
import com.mwp.p.framework.Applications;
import com.mwp.p.framework.DeveloperApplications;
import com.mwp.p.framework.Platform;
import com.mwp.p.framework.PortalFileUpload;
import com.mwp.p.framework.Projects;
import com.mwp.p.utility.Utility;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;


/** <h1>DeveloperApplicationsEndpoint</h1>
 * Class hosted at the URI path "/devapps"
 * <p>
 * Class manage application of developer, list invited application, add/update/delete application,
 * give developer application detail(list of version, version details), publish application.
 * </p>
 * @author akh
 * @version 0.0.1
 * @since   2016-08-30 
 */
// "Class manage application of developer, list invited application, add/update/delete application,"
// "give developer application detail(list of version, version details), publish application."
@Path("/devapps")
@Api( value = "/devapps",produces=MediaType.APPLICATION_JSON)
public class DeveloperApplicationsEndpoint {

	@Context
	private HttpServletResponse response;

	/**
	 * Method processing HTTP GET requests, producing "application/json" MIME media-type.
	 * <p> 
	 * This method return List of user application 
	 * </p>  
	 * @param httpHeaders
	 * @return
	 */
	@GET
	@Consumes({MediaType.APPLICATION_JSON})
	@ApiOperation( value = "List of user application", 
	notes = "List of user application.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to get list Application Of User.")
	} )
	public void listApplicationOfUser(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken){
		mListApplicationOfUser(authToken);
	}

	/**
	 * Method processing HTTP GET requests, producing "application/json" MIME media-type.
	 * <p> 
	 * This method return List of invited application 
	 * (developerApp - Status/version/count/repositry) of developer.
	 * </p>  
	 * @param httpHeaders
	 * @return
	 */
	@GET
	@Consumes({MediaType.APPLICATION_JSON})
	@Path("/invited")
	@ApiOperation( value = "List of invited application", 
	notes = "List of invited application.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to get List of invited application.") 
	} )
	public void listInvitedApps(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken){
		mListInvitedApps(authToken);
	}

	/**
	 * Method processing HTTP GET requests, producing "application/json" MIME media-type.
	 * 
	 * <p> 
	 * This method return detail of developer application (listVersion, versionDetail).
	 * </p>  
	 * @param appId of project.
	 * @param httpHeaders
	 * @return
	 */

	@GET
	@Consumes({MediaType.APPLICATION_JSON})
	@Path("/{appid}")
	@ApiOperation( value = "Get details of developer application", 
	notes = "application details.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to get developer Application details."),
		@ApiResponse( code = HttpServletResponse.SC_NOT_FOUND, message = "Application detail doesn't exists.")
	} )
	public void getDeveloperAppDetails(@ApiParam(value = "id of application.", required = true)@NotNull @PathParam("appid") String appId,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken)throws ValidationException{
		mGetDeveloperAppDetails(authToken, appId);
	}

	/**
	 * Method processing HTTP GET requests, producing "application/json" MIME media-type.
	 * 
	 * <p> 
	 * This method return secretKey of application. 
	 * </p>  
	 * @param appId a unique id of application.
	 * @param httpHeaders
	 * @return
	 */
	@GET
	@Consumes("application/json")
	@Produces("application/json")
	@Path("/{appid}/info")
	@ApiOperation( value = "info of app.", 
	notes = "info of app.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to get Application information.")	 
	} )
	public void getApplicationInfo(@ApiParam( value = "id of application.", required = true ) @PathParam("appid") String appId,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken){
		mGetApplicationInfo(authToken, appId);
	}


	/**
	 * Method processing HTTP GET requests, producing "application/json" MIME media-type.
	 * 
	 * <p>
	 * This method gives application version command according to requested
	 * applicationId and appVersionId
	 * </p>
	 * @param authToken
	 * @param applicationId
	 * @param appVersionId
	 * @throws ValidationException
	 */
	@GET
	@Consumes({ MediaType.APPLICATION_JSON })
	@Produces({ MediaType.APPLICATION_JSON })
	@Path("/{appid}/version/{versionid}/commands")
	@ApiOperation(value = "application version command according to requested applicationId and appVersionId", notes = "application version command according to requested applicationId and appVersionId.", response = HashMap.class)
	@ApiResponses({
		@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to get App version commands.")
	})
	public void getAppVersionCommand(@ApiParam(value = "Authorization token", required =true) @HeaderParam("Authorization") String authToken,
			@ApiParam(value = "appid of application which commands are required.", required = true)  @PathParam("appid") @NotNull String applicationId,
			@ApiParam(value = "versionId of application which commands are required.", required = true)  @PathParam("versionid") @NotNull String appVersionId) throws ValidationException {
		mGetAppVersionCommand(authToken, applicationId,appVersionId);
	}

	/**
	 * Method processing HTTP GET requests, producing "application/json" MIME media-type.
	 * 
	 * <p>
	 * This method gives all applicable versions of application
	 * (gives all version of application after requested versionId if available)
	 * </p>
	 * @param authToken
	 * @param applicationId
	 * @param appVersionId
	 * @throws ValidationException
	 */
	@GET
	@Consumes({ MediaType.APPLICATION_JSON })
	@Produces({ MediaType.APPLICATION_JSON })
	@Path("/{appid}/versions/{versionid}")
	@ApiOperation(value = "List application versions according to requested applicationId and appVersionId", notes = "list application versions according to requested applicationId and appVersionId.", response = HashMap.class)
	@ApiResponses({
		@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to get Available Version of Application.")
	})
	public void getAvailableVersionofApplication(@ApiParam(value = "Authorization token", required =true) @HeaderParam("Authorization") String authToken,
			@ApiParam(value = "appid of application which versions are required.", required = true)  @PathParam("appid") @NotNull String applicationId,
			@ApiParam(value = "versionId of application which versions are required.", required = true)  @PathParam("versionid") @NotNull String appVersionId) throws ValidationException {
		mGetAvailableVersionofApplication(authToken, applicationId,appVersionId);
	}

	/**
	 * Method processing HTTP GET requests, producing "application/json" MIME media-type.
	 * <p> 
	 * This method return List of invited application 
	 * (developerApp - Status/version/count/repositry) of developer.
	 * </p>  
	 * @param httpHeaders
	 * @return
	 */
	@GET
	@Consumes({MediaType.APPLICATION_JSON})
	@Path("/platform")
	@ApiOperation( value = "List of application platform", 
	notes = "List of platform.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to get list application platform.")		 
	} )
	public void listPlatform(){
		mListPlatform();
	}


	/** Method processing HTTP POST requests, producing "application/json" MIME media type.
	 * <p>
	 * This method add developer application detail.
	 * <p>
	 * @param appDetailVO object details of applicationDetailVO
	 * @param httpHeaders 
	 * @return Json string
	 * @throws Exception 
	 */
	@POST
	@Consumes({MediaType.APPLICATION_JSON})
	@ApiOperation( value = "Add developer application detail.", 
	notes = "add developer application detail.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to get list Application Of User."),
		@ApiResponse(code = HttpServletResponse.SC_NOT_FOUND, message = "No project found with given project ID."),
		@ApiResponse(code = HttpServletResponse.SC_CONFLICT, message = "Application already exists with same title or repository name.")
	})
	public void create(@ApiParam(value = "application details object.", required = true) @Valid @NotNull ApplicationDetailsVO appDetailVO,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken)throws ValidationException {
		mCreate(authToken, appDetailVO);
	}

	/** Method processing HTTP POST requests, producing "application/json" MIME media type.
	 * <p>
	 * This method add developer application detail.
	 * <p>
	 * @param appDetailVO object details of applicationDetailVO
	 * @param httpHeaders 
	 * @return Json string
	 * @throws Exception 
	 */
	@POST
	@Path("/project")
	@Consumes({MediaType.APPLICATION_JSON})
	@ApiOperation( value = "Add developer application detail.", 
	notes = "add developer application detail.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to create Application."),
		@ApiResponse(code = HttpServletResponse.SC_NOT_FOUND, message = "No application found with given project ID."),
		@ApiResponse(code = HttpServletResponse.SC_CONFLICT, message = "Application already exists with same title or repository name.")
	})
	public void createapp(@ApiParam(value = "ProjectVO, ApplicationVO in map class object; with keys: project, application.", required = true)  @Valid @NotNull String args,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken)throws ValidationException {
		mcreateApp(authToken, args);
	}

	@POST
	@Path("/{appid}/logo")
	@ApiOperation( value = "Upload logo of developer application", 
	notes = "Upload logo of developer application.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to upload logo of developer application.")
	})
	public void uploadLogo(@Context HttpServletRequest uploadedInputStream,
			@ApiParam(value = "id of application.", required = true) @PathParam("appid") String appId,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken) 
	{
		mUploadImage(authToken, appId, uploadedInputStream, true);
	}

	@POST
	@Path("/{appid}/image")
	@ApiOperation( value = "Upload attachment of developer application", 
	notes = "Upload attachment of developer application.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to upload logo of developer application.")
	})
	public void uploadImage(@Context HttpServletRequest uploadedInputStream,
			@ApiParam(value = "id of application.", required = true) @PathParam("appid") String appId,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken) 
	{
		mUploadImage(authToken, appId, uploadedInputStream, false);
	}

	/** Method processing HTTP PUT requests, producing "application/json" MIME media type.
	 * <p>
	 * This method update developer application detail.
	 * <p>
	 * @param appDetailVO updated object of applicationDetailVO
	 * @param httpHeaders 
	 * @return Json string
	 * @throws Exception 
	 */
	@PUT
	@Consumes({MediaType.APPLICATION_JSON})
	@Path("/{appid}")
	@ApiOperation( value = "Update developer application detail.", 
	notes = "updated object of applicationDetailVO.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_NOT_FOUND, message = "No application found with given project ID."),
		@ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to update developer application.")
	} )
	public void edit(@ApiParam(value = "id of application.", required = true) @NotNull @PathParam("appid") String appId,
			@ApiParam(value = "updated object of applicationDetailVO.", required = true)  @Valid @NotNull ApplicationDetailsVO appDetailVO,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken) throws ValidationException{
		mEdit(authToken, appDetailVO);
	}

	/** Method processing HTTP DELETE requests, producing "application/json" MIME media type.
	 * <p>
	 * This method delete developer application info from db.
	 * <p>
	 * @param appId of project.
	 * @param httpHeaders
	 * @return
	 * @throws Exception 
	 */
	@DELETE
	@Consumes({MediaType.APPLICATION_JSON})
	@Path("/{appid}")
	@ApiOperation( value = "Delete developer application detail.", 
	notes = "delete object of application detail.")
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to delete developer application.")
	})
	public void delete(@ApiParam(value = "id of application.", required = true)  @NotNull @PathParam("appid") String appId,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken) throws ValidationException {
		mDelete(authToken, appId);
	}

	/** Method processing HTTP DELETE requests, producing "application/json" MIME media type.
	 * <p>
	 * This method delete developer application info from db.
	 * <p>
	 * @param appId of project.
	 * @param httpHeaders
	 * @return
	 * @throws Exception 
	 */
	@DELETE
	@Consumes({MediaType.APPLICATION_JSON})
	@Path("/{appid}/image/{appimageid}")
	@ApiOperation( value = "Delete developer application detail.", 
	notes = "delete object of application detail.")
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to delete developer application image.")
	} )
	public void deleteAppImage(@ApiParam(value = "id of application.", required = true)  @NotNull @PathParam("appid") String appId,
			@ApiParam(value = "id of applicationImage.", required = true)  @NotNull @PathParam("appimageid") String appImageId,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken) throws ValidationException {
		mDeleteAppImage(authToken, appId, appImageId);
	}

	@GET
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/repo/{reponame}{app:(/app/[^/]+?)?}")
	@ApiOperation(value = "Check if repository name is available to use.", notes = "Check if repository name is available to use.", response = String.class, responseContainer = "String")
	@ApiResponses({
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Repository name already exists."),
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
	})
	public void isRepoNameAvailable(@ApiParam(value = "reponame", required = true) @PathParam("reponame") String reponame,
			@ApiParam(value = "app", required = false) @PathParam("app") String appid,
			@ApiParam(value = "Authorization token", required = true) @HeaderParam("Authorization") String authToken) {
		mIsRepoNameAvailable(authToken, reponame, appid);
	}

	@POST
	@Path("/appSecret/{appid}")
	@ApiOperation( value = "Add app secret.", 
	notes = "Add app secret.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to add app secret for application."),
		@ApiResponse(code = HttpServletResponse.SC_NOT_FOUND, message = "No application found with given app ID."),
		@ApiResponse(code = HttpServletResponse.SC_CONFLICT, message = "Application secret already exists with same display name.")
	})
	public void createAppSecret(@Context HttpServletRequest uploadedInputStream,
			@ApiParam(value = "id of application.", required = true) @PathParam("appid") String appId,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken) {
		mAddAppSecret(authToken, appId, uploadedInputStream);
	}

	@POST
	@Path("/appSecretedit/{appid}")
	@ApiOperation( value = "Edit app secret.", 
	notes = "Edit app secret.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_NOT_FOUND, message = "No application found with given app ID."),
		@ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to add app secret for application."),
		@ApiResponse(code = HttpServletResponse.SC_CONFLICT, message = "Application secert already exists with same display name.")

	} )
	public void editAppSecret(@Context HttpServletRequest uploadedInputStream,
			@ApiParam(value = "id of application.", required = true) @NotNull @PathParam("appid") String appId,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken){
		mEditAppSecret(authToken, appId, uploadedInputStream);
	}

	@DELETE
	@Consumes({MediaType.APPLICATION_JSON})
	@Path("/appSecret/{appid}/{appSecretId}")
	@ApiOperation( value = "Delete  application secret.", 
	notes = "delete application secret.")
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_NOT_FOUND, message = "No applicationsecret found with given ID."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to delete application secret.")
	})
	public void deleteAppSecret(@ApiParam(value = "id of application.", required = true)  @NotNull @PathParam("appid") String appId,
			@ApiParam(value = "app secret id of application.", required = true)  @NotNull @PathParam("appSecretId") String appSecretId,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken) throws ValidationException {
		mDeleteAppSecret(authToken, appSecretId, appId);
	}

	@DELETE
	@Consumes({MediaType.APPLICATION_JSON})
	@Path("/appSecretVersion/{appid}/{appSecretVersionId}")
	@ApiOperation( value = "Delete  application secret.", 
	notes = "delete application secret.")
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_NOT_FOUND, message = "No applicationsecretversion found with given ID."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to delete application secret.")
	})
	public void deleteAppSecretVersion(@ApiParam(value = "id of application.", required = true)  @NotNull @PathParam("appid") String appId,
			@ApiParam(value = "app secret version id of application.", required = true)  @NotNull @PathParam("appSecretVersionId") String appSecretVersionId,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken) throws ValidationException {
		mDeleteAppSecretVersion(authToken, appSecretVersionId, appId);
	}

	@GET
	@Path("/appSecret/{appid}")
	@Consumes({MediaType.APPLICATION_JSON})
	@ApiOperation( value = "List of application secret", 
	notes = "List of application secret.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_NOT_FOUND, message = "No application found with given app ID."),
		@ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to get list of Application secret.")
	} )
	public void listAppSecret(@ApiParam(value = "id of application.", required = true)  @NotNull @PathParam("appid") String appId,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken){
		mListAppSecret(authToken, appId);
	}

	@GET
	@Path("/appSecret/{appid}/{appSecretId}")
	@Consumes({MediaType.APPLICATION_JSON})
	@ApiOperation( value = "get application secret", 
	notes = "get application secret.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_NOT_FOUND, message = "No application found with given app ID."),
		@ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to get Application secret.")
	} )
	public void getAppSecret(@ApiParam(value = "id of application.", required = true)  @NotNull @PathParam("appid") String appId,
			@ApiParam(value = "app secret id of application.", required = true)  @NotNull @PathParam("appSecretId") String appSecretId,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken){
		mGetAppSecret(authToken, appId,appSecretId);
	}


	private void mIsRepoNameAvailable(String authToken, String repoName, String appId) {
		try {
			//CHECK AUTH TOKEN...
			new GrpcAuthHelper().checkAuthorization(authToken);

			if(!StringFunctions.isNullOrWhitespace(appId))			{
				appId = appId.split("/")[2];
			}

			List<String> lstReponames = new ArrayList<>();
			lstReponames.add(repoName);
			List<String> lstReponameTaken = new DeveloperApplications().isRepoNameAvailable(lstReponames, appId);

			if(!lstReponameTaken.isEmpty()){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_BAD_REQUEST, ErrorMessage.REPO_NAME_TAKEN, "");
				errorVo.setErrorExplanation(lstReponameTaken.toString());
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
				return;
			}
			Map<String, Object> resultMap=new HashMap<>();
			resultMap.put(Constant.DATA, true);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);

		} catch (Exception e) {
			PALogger.ERROR(e);	
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to get device name.", "Unable to get device name.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
		}
	}

	private void mUploadImage(String authToken, String appId, HttpServletRequest uploadedInputStream, boolean isAppLogo) {
		final String IMAGE_UPLOAD_FAILED = "image upload failed.";
		try {
			//CHECK AUTH TOKEN...
			new GrpcAuthHelper().checkAuthorization(authToken);

			String extension = "";
			String fileName ="";
			Map<String, String> formItems=new HashMap<>();
			Map<String, String> inputstreaHash= new HashMap<>();
			ServletFileUpload fileUpload = new ServletFileUpload();
			int seqNo = 0;
			if(ServletFileUpload.isMultipartContent(uploadedInputStream))
			{
				FileItemIterator items = fileUpload.getItemIterator(uploadedInputStream);
				while (items.hasNext())
				{
					FileItemStream item = items.next();
					if (!item.isFormField()) 
					{
						try(InputStream inputstream = item.openStream()){
							int i = fileName.lastIndexOf('.');
							if (i > 0) {
								extension = fileName.substring(i+1);
							}
							String getneratedFilename = Common.getRandomId()+"."+extension;
							String tempfilepath = new PortalFileUpload().inputStreamToFile(inputstream, TempFiles.getTempFolderPath() + getneratedFilename);
							inputstreaHash.put(getneratedFilename, tempfilepath);
							if(!Utils.checkImageMimeType(tempfilepath)){
								throw new Exception("invalid image.");
							}
						}
					}
					else 
					{
						try(InputStream fieldValue= item.openStream()){
							formItems.put(item.getFieldName(), Streams.asString(fieldValue));
							if(item.getFieldName().equals("fileName")){
								fileName = formItems.get("fileName");
							}
						}
					}
				}
				isAppLogo = Boolean.parseBoolean(formItems.get("isapplogo"));
				if(!isAppLogo){
					seqNo = Integer.parseInt(formItems.get("seqno"));
				}
				appId = formItems.get("appid");
			}
			PortalFileUpload pfu = new PortalFileUpload();
			String uploadBasePath = pfu.getBasePath(Constants.PORTAL_APP_FOLDER_NAME, appId);
			Map<String,Object> resultMap = pfu.uploadAttachmentInline(inputstreaHash,uploadBasePath, false, false);
			if(resultMap.size() > 0){
				if(!isAppLogo){
					ApplicationImagesVO appImagesVO = new DeveloperApplications().addApplicationImage(appId, resultMap.get("imagePath").toString(), seqNo);
					resultMap.put(Constant.DATA, appImagesVO);
				} else {
					new DeveloperApplications().updateApplicationLogo(appId, resultMap.get("imagePath").toString());
				}

				ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);
			}else{
				throw new Exception(IMAGE_UPLOAD_FAILED);
			}
		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			} else {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						IMAGE_UPLOAD_FAILED, IMAGE_UPLOAD_FAILED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			PALogger.ERROR(e);	
		}
	}

	private void mListInvitedApps(String authToken) {
		try {
			// CHECK AUTH TOKEN...
			AuthorizationsVO authorizationsVO = new GrpcAuthHelper().getAuthorizationsVO(authToken);
			DeveloperApplications developerApplications=new DeveloperApplications();
			List<DeveloperApplicationVO> developerApplicationVOs=new ArrayList<>();
			List<String> groupIds = null;
			if(authorizationsVO.getGroupPermissions()!=null)
				groupIds = new ArrayList<>(authorizationsVO.getGroupPermissions().keySet());
			if(groupIds!=null && !groupIds.isEmpty())
				developerApplicationVOs = developerApplications.listInvitedApps(groupIds);
			HashMap<String, Object> resultMap = new HashMap<>();
			resultMap.put(Constant.DATA, developerApplicationVOs);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);
		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						Constants.UNABLE_TO_LIST_INVITED_APPLICATION, Constants.UNABLE_TO_LIST_INVITED_APPLICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			PALogger.ERROR(e);	
		}
	}

	@SuppressWarnings("unchecked")
	private void mcreateApp(String authToken, String args){
		try {
			Gson gson = new Gson();
			Map<String, Object> argsMap = gson.fromJson(args, Map.class);

			String project = gson.toJson(argsMap.get("project"));
			String application = gson.toJson(argsMap.get("application"));

			ProjectVO projectVO = gson.fromJson(project, ProjectVO.class);
			ApplicationDetailsVO appDetailVO = gson.fromJson(application, ApplicationDetailsVO.class);

			// CHECK AUTH TOKEN...
			// Execute that operation if user is owner of  same project.
			AuthorizationsVO authorizationsVO = new GrpcAuthHelper().getAuthorizationsVO(authToken);

			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_PROJECTS));
			AdminPermissionCheck.checkAdminPermission(authorizationsVO, lstPermissions, true);

			DeveloperApplications developerApplications = new DeveloperApplications();
			// Check if application already exists, If exits then it will throw 'Application already exists' error - PSH.
			developerApplications.isApplicationExits(appDetailVO.getTitle());

			List<String> lstRepoNames = appDetailVO.getPlatFormList().stream().map(ApplicationPlatformVO::getRepositoryName).collect(Collectors.toList());					
			List<String> lstReponameTaken = developerApplications.isRepoNameAvailable(lstRepoNames, appDetailVO.getApplicationId());

			if(!lstReponameTaken.isEmpty()){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_BAD_REQUEST, ErrorMessage.REPO_NAME_TAKEN, "");
				errorVo.setErrorExplanation(lstReponameTaken.toString());
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
				return;
			}

			//create project
			Projects projects = new Projects();
			projectVO.setStatus(Status.ACTIVE);
			projectVO.setUserId(authorizationsVO.getUserId());
			ProjectVO addedProjectVO = projects.addProject(projectVO);

			appDetailVO.setProjectId(addedProjectVO.getProjectId());
			appDetailVO.setUserId(authorizationsVO.getUserId());
			appDetailVO.setAppStatus(Status.ACTIVE);
			ApplicationDetailsVO applicationDetailsVO = developerApplications.createApplication(appDetailVO);

			// Copy image from pp folder to PortalFileUpload.getBasePath(Constants.PORTAL_APP_FOLDER_NAME, appId)
			// Then update into database - PSH
			if(appDetailVO.getDefaultIcon() != null && !appDetailVO.getDefaultIcon().equals("")){
				PortalFileUpload fileUpload = new PortalFileUpload();
				// Make new file path where file get copy - PSH
				String newFilePath = fileUpload.getBasePath(Constants.PORTAL_APP_FOLDER_NAME, applicationDetailsVO.getApplicationId());
				// Copy file from source to destination - PSH
				String orignalFilePath = Constants.IAMAGES_APP_ICON_PATH;
				File sourceFile = new File(orignalFilePath + appDetailVO.getDefaultIcon());
				File destinationFilePath = new File(newFilePath + sourceFile.getName());
				fileUpload.copyFile(sourceFile, destinationFilePath);
				// Create public URL - PSH
				String shareUrl = PortalCommon.getInstance().createPublicUrl(destinationFilePath.getPath(), Constants.UI_FOLDER_NAME);
				// Insert into database 
				new DeveloperApplications().updateApplicationLogo(applicationDetailsVO.getApplicationId(), destinationFilePath.getPath());
				applicationDetailsVO.setIcon(shareUrl);
			}

			for (ApplicationPlatformVO platform : appDetailVO.getPlatFormList()) {
				//Add ApplicationRepository
				platform.setAppId(applicationDetailsVO.getApplicationId());
				developerApplications.addAppRepo(platform);
			} 

			Map<String, Object> data = new HashMap<>();
			data.put("project", addedProjectVO);
			data.put("app", applicationDetailsVO);

			Map<String, Object> resultMap = new HashMap<>();
			resultMap.put(Constant.DATA, data);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);			
		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTFOUND)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_NOT_FOUND, "project not found", "No project found with given project ID");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			} else if(e.getMessage().equals("Application already exists")){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_CONFLICT, "Application already exists", "Application already exists with same title or repository name.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}else if(e.getMessage().startsWith(ErrorMessage.REPO_NAME_TAKEN)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_BAD_REQUEST, e.getMessage(), "");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			else
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"Unable to create application.", "Unable to create application.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			PALogger.ERROR(e);	
		}
	}

	private void mCreate(String authToken, ApplicationDetailsVO appDetailVO) {
		try {
			// CHECK AUTH TOKEN...
			// Execute that operation if user is owner of  same project.
			AuthorizationsVO authorizationsVO = new GrpcAuthHelper().getAuthorizationsVO(authToken);
			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_PROJECTS));
			AdminPermissionCheck.checkAdminPermission(authorizationsVO, lstPermissions, true);

			Projects projects=new Projects();
			ProjectVO projectVO=projects.getProjectDetail(appDetailVO.getProjectId());
			if (projectVO!=null) { //returns projectVO 
				if (projectVO.getUserId().equals(authorizationsVO.getUserId())) {
					DeveloperApplications developerApplications = new DeveloperApplications();

					// Check if application already exists, If exits then it will throw 'Application already exists' error - PSH.
					developerApplications.isApplicationExits(appDetailVO.getTitle());
					List<String> lstRepoNames = appDetailVO.getPlatFormList().stream().map(ApplicationPlatformVO::getRepositoryName).collect(Collectors.toList());					
					List<String> lstReponameTaken = developerApplications.isRepoNameAvailable(lstRepoNames, appDetailVO.getApplicationId());

					if(!lstReponameTaken.isEmpty()){
						ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_BAD_REQUEST, ErrorMessage.REPO_NAME_TAKEN, "");
						errorVo.setErrorExplanation(lstReponameTaken.toString());
						ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
						return;
					}

					appDetailVO.setUserId(authorizationsVO.getUserId());
					appDetailVO.setAppStatus(Status.ACTIVE);

					ApplicationDetailsVO applicationDetailsVO = developerApplications.createApplication(appDetailVO);

					// Copy image from pp folder to PortalFileUpload.getBasePath(Constants.PORTAL_APP_FOLDER_NAME, appId)
					// Then update into database - PSH
					if(appDetailVO.getDefaultIcon() != null && !appDetailVO.getDefaultIcon().equals("")){
						PortalFileUpload fileUpload = new PortalFileUpload();
						// Make new file path where file get copy - PSH
						String newFilePath = fileUpload.getBasePath(Constants.PORTAL_APP_FOLDER_NAME, applicationDetailsVO.getApplicationId());
						// Copy file from source to destination - PSH
						String orignalFilePath = Constants.IAMAGES_APP_ICON_PATH;

						File sourceFile = new File(orignalFilePath + appDetailVO.getDefaultIcon());
						File destinationFilePath = new File(newFilePath + sourceFile.getName());
						fileUpload.copyFile(sourceFile, destinationFilePath);
						// Create public URL - PSH
						String shareUrl = PortalCommon.getInstance().createPublicUrl(destinationFilePath.getPath(), Constants.UI_FOLDER_NAME);
						// Insert into database 
						new DeveloperApplications().updateApplicationLogo(applicationDetailsVO.getApplicationId(), destinationFilePath.getPath());
						applicationDetailsVO.setIcon(shareUrl);
					}

					for (ApplicationPlatformVO platform : appDetailVO.getPlatFormList()) {
						//Add ApplicationRepository
						platform.setAppId(applicationDetailsVO.getApplicationId());
						developerApplications.addAppRepo(platform);
					} 


					HashMap<String, Object> resultMap = new HashMap<String, Object>();
					resultMap.put(Constant.DATA, applicationDetailsVO);
					ReturnObject.createResponse(Constant.SUCCESS, resultMap,
							null, response);
				} else {
					throw new Exception(Constant.NOTPERMITTED);
				}
			}
			else
			{
				//if project not found for given project Id then throw NOTFOUND exception. 
				throw new Exception(Constant.NOTFOUND);	
			}

		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTFOUND)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_NOT_FOUND,
						"project not found", "No project found with given project ID");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			else if(e.getMessage().equals("Application already exists")){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_CONFLICT, "Application already exists", "Application already exists with same title.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			} 
			else
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"Unable to create application.", "Unable to create application.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			PALogger.ERROR(e);	
		}
	}

	private void mEdit(String authToken, ApplicationDetailsVO appDetailVO) {
		try {
			// CHECK AUTH TOKEN...
			// Execute that operation if user is owner of  same project.
			AuthorizationsVO authorizationsVO = new GrpcAuthHelper().getAuthorizationsVO(authToken);
			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_PROJECTS));
			AdminPermissionCheck.checkAdminPermission(authorizationsVO, lstPermissions, true);

			Projects projects=new Projects();
			ProjectVO projectVO=projects.getProjectDetail(appDetailVO.getProjectId());
			if (projectVO!=null) {
				if (projectVO.getUserId().equals(authorizationsVO.getUserId())) 
				{
					DeveloperApplications developerApplications = new DeveloperApplications();
					// Check if application name already exits, If exits then it will throw 'Application name already exits' error .
					developerApplications.isAppNameAlreadyExist(appDetailVO.getTitle(), appDetailVO.getApplicationId());
					ApplicationDetailsVO applicationDetailsVO = developerApplications.updateApplication(appDetailVO);

					// Copy image from pp folder to PortalFileUpload.getBasePath(Constants.PORTAL_APP_FOLDER_NAME, appId)
					// Then update into database - PSH
					if(appDetailVO.getDefaultIcon() != null && !appDetailVO.getDefaultIcon().equals("")){
						PortalFileUpload fileUpload = new PortalFileUpload();
						// Make new file path where file get copy - PSH
						String newFilePath = fileUpload.getBasePath(Constants.PORTAL_APP_FOLDER_NAME, applicationDetailsVO.getApplicationId());
						// Copy file from source to destination - PSH
						String orignalFilePath = Constants.IAMAGES_APP_ICON_PATH;

						File sourceFile = new File(orignalFilePath + appDetailVO.getDefaultIcon());
						File destinationFilePath = new File(newFilePath + sourceFile.getName());
						fileUpload.copyFile(sourceFile, destinationFilePath);
						// Create public URL - PSH
						String shareUrl = PortalCommon.getInstance().createPublicUrl(destinationFilePath.getPath(), Constants.UI_FOLDER_NAME);
						// Insert into database 
						new DeveloperApplications().updateApplicationLogo(applicationDetailsVO.getApplicationId(), destinationFilePath.getPath());
						applicationDetailsVO.setIcon(shareUrl);
					}

					for (ApplicationPlatformVO platform : appDetailVO.getPlatFormList()) {
						if(StringFunctions.isNullOrWhitespace(platform.getAppPlatformId())){
							//Add ApplicationRepository
							platform.setAppId(applicationDetailsVO.getApplicationId());
							developerApplications.addAppRepo(platform);
						}
					} 

					Map<String, Object> resultMap = new HashMap<>();
					resultMap.put(Constant.DATA, applicationDetailsVO);
					ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);
				} else {
					//if project not found for given project Id then throw NOTFOUND exception. 
					throw new Exception(Constant.NOTPERMITTED);
				}
			}
			else
			{
				throw new Exception(Constant.NOTFOUND);
			}
		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTFOUND)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_NOT_FOUND,"project not found", "No project found with given project ID");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals("Application name already exists"))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , e.getMessage(), e.getMessage());
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"Unable to update application", "Unable to update application");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			PALogger.ERROR(e);	
		}
	}

	private void mDelete(String authToken, String appId) {
		try {
			// CHECK AUTH TOKEN...
			AuthorizationsVO authorizationsVO = new GrpcAuthHelper().getAuthorizationsVO(authToken);


			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_PROJECTS));
			AdminPermissionCheck.checkAdminPermission(authorizationsVO, lstPermissions, true);
			String userId=authorizationsVO.getUserId();
			// only owner of app can delete that app.
			DeveloperApplications developerApplications=new DeveloperApplications();
			developerApplications.deleteApplication(appId,userId);
			Map<String, Object> resultMap=new HashMap<>();
			resultMap.put(Constant.DATA, appId);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);

		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"Unable to delete application", "Unable to delete application");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			PALogger.ERROR(e);	
		}
	}

	private void mGetDeveloperAppDetails(String authToken, String appId) {
		try {
			/* CHECK AUTH TOKEN...and get hash table for group and its permission. 
			   This will return all groups, NOT only appId specific groups
			 */
			AuthorizationsVO authVo=new GrpcAuthHelper().getAuthorizationsVO(authToken);
			//removed this check because if user have invitaion in user group then he can get app details bug 1545
			/*
			 * Get all the application details
			 * If owner of the app, all the version should be visible and permission should be returned
			 * else if invitee of the app, assigned version and its permission should be returned 
			 */

			//Create Developer application VO object. This object is used to call methods. NOT returned to UI

			DeveloperApplications developerApplications=new DeveloperApplications();

			//Get details of application.  This includes versions/permission according to user role

			DevAppDetailsVO detailsVO = developerApplications.getDevAppDetails(appId, authVo, null);

			if (detailsVO!=null) { 
				// get detail executed by owner and those user which have either push or pull  or  publish permission.
				if (!detailsVO.getAppOwnerId().equals(authVo.getUserId())) {
					List<String> lstPortalPermissionEnums=new ArrayList<>();
					lstPortalPermissionEnums.add(PermissionResources.getString(PermissionResourceKeys.APP_VERSION_CREATE));
					lstPortalPermissionEnums.add(PermissionResources.getString(PermissionResourceKeys.APP_VERSION_INSTALL));
					lstPortalPermissionEnums.add(PermissionResources.getString(PermissionResourceKeys.APP_VERSION_PUBLISH));
					lstPortalPermissionEnums.add(PermissionResources.getString(PermissionResourceKeys.APP_VERSION_UNPUBLISH));
					Utility.checkPermission(authVo.getGroupPermissions(),lstPortalPermissionEnums, appId,false);
					/*
					 * check user have push privilege or not so UI take decision to show createApp Version button. 
					 */
					lstPortalPermissionEnums.clear();
					lstPortalPermissionEnums.add(PermissionResources.getString(PermissionResourceKeys.APP_VERSION_CREATE));
					try{
						Utility.checkPermission(authVo.getGroupPermissions(),lstPortalPermissionEnums, appId,false);
						detailsVO.setPrivilege(PermissionResources.getString(PermissionResourceKeys.APP_VERSION_CREATE));
					}catch (Exception e) {
						detailsVO.setPrivilege("");
					}
				}else{
					detailsVO.setPrivilege(PermissionResources.getString(PermissionResourceKeys.APP_VERSION_CREATE));
				}
				//AKH_01_1
				Map<String, Object> data = new HashMap<>();
				data.put("devappdetail", detailsVO);

				Map<String, Object> resultMap = new HashMap<>();
				resultMap.put(Constant.DATA, data);
				ReturnObject.createResponse(Constant.SUCCESS, resultMap, null,
						response);
			}
			else
			{
				throw new Exception(Constant.NOTFOUND);
			}


		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTFOUND)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_NOT_FOUND , "Application not found", "No application found with requested application Id");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"Unable to get application detail", "Unable to get application detail");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			PALogger.ERROR(e);	
		}
	}

	private void mListApplicationOfUser(String authToken) {

		try {
			// CHECK AUTH TOKEN...
			AuthorizationsVO authVo=new GrpcAuthHelper().getAuthorizationsVO(authToken);
			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_PROJECTS));
			AdminPermissionCheck.checkAdminPermission(authVo, lstPermissions, true);

			String userId = authVo.getUserId();

			DeveloperApplications developerApplications=new DeveloperApplications();
			List<ApplicationVO> applicationVOs = developerApplications.listApplicationOfUser(userId);
			Map<String, Object> resultMap = new HashMap<>();
			resultMap.put(Constant.DATA, applicationVOs);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);
		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"Unable to list application of user", "Unable to list application of user");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			PALogger.ERROR(e);	
		}
	}

	/**
	 * this method give secretKey of application,
	 * get detail from auth server using authToken, userId, appId
	 * @param authToken
	 * @param appId
	 */
	private void mGetApplicationInfo(String authToken, String appId) {
		try {
			// CHECK AUTH TOKEN...
			String userId = new GrpcAuthHelper().checkAuthorization(authToken);
			/**
			 * call getSecretKey() method of application class,
			 * for getting application secretKey according to appId and userId( which is appOwnerId).
			 */
			String secretKey = new Applications().getSecretKey(appId, userId);
			Map<String, Object> resultMap = new HashMap<>();
			resultMap.put(Constant.DATA, secretKey);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);

		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"Unable to get app detail", "Unable to get app detail");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			PALogger.ERROR(e);	
		}
	}

	private void mGetAppVersionCommand(String authToken, String applicationId, String appVersionId) {
		try {
			AuthorizationsVO authorizationsVO;
			if(authToken.toLowerCase().startsWith(Constant.JWT_BEARER.toLowerCase())) {
						authorizationsVO = new AuthHelper().checkJwtToken(authToken, response);
			}
			else{
				// CHECK AUTH TOKEN...
				 authorizationsVO = new GrpcAuthHelper().getAuthorizationsVO(authToken);
			}
			List<String> grpIds =null;
			if(authorizationsVO.getGroupPermissions()!=null){
				grpIds = new ArrayList<>(authorizationsVO.getGroupPermissions().keySet());
			}
			
			List<AppCommandVO> appCommandVOs=new DeveloperApplications().getAppVersionCommand(authorizationsVO.getUserId(), applicationId, appVersionId, grpIds);
			Map<String, Object> resultMap = new HashMap<>();
			resultMap.put(Constant.DATA, appCommandVOs);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);

		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"Unable to get app version command", "Unable to get app version command");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			PALogger.ERROR(e);	
		}

	}

	private void mGetAvailableVersionofApplication(String authToken,
			String applicationId, String appVersionId) {
		try {
			// CHECK AUTH TOKEN...
			String userId = new GrpcAuthHelper().checkAuthorization(authToken);
			List<VERSION_STATUS> filterVersionStatus = new ArrayList<>();
			filterVersionStatus.add(VERSION_STATUS.LIVE);
			filterVersionStatus.add(VERSION_STATUS.REVIEWED);	
			filterVersionStatus.add(VERSION_STATUS.OLDRELEASED);
			filterVersionStatus.add(VERSION_STATUS.UPLOADING);
			List<VersionVO> versionVOs= new DeveloperApplications().getVersionsOfApplication(applicationId, userId, appVersionId, "", filterVersionStatus);
			Map<String, Object> resultMap = new HashMap<>();
			resultMap.put(Constant.DATA, versionVOs);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);

		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"Unable to list versions", "Unable to list versions");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			PALogger.ERROR(e);	
		}

	}

	private void mDeleteAppImage(String authToken, String appId, String appImageId) {
		try {
			// CHECK AUTH TOKEN...
			String userId = new GrpcAuthHelper().checkAuthorization(authToken);
			/*
			 * only owner of app can delete that appImage.
			 */
			if(userId.equals(new Applications().getUserIdOfApp(appId))){
				new DeveloperApplications().deleteAppImage(appId, appImageId);
				Map<String, Object> resultMap=new HashMap<>();
				resultMap.put(Constant.DATA, appImageId);
				ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);
			}else{
				throw new Exception(Constant.NOTPERMITTED);
			}
		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"Unable to delete application", "Unable to delete application");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			PALogger.ERROR(e);	
		}
	}

	private void mListPlatform() {
		try {

			Platform platform = new Platform();
			Map<String, Object> resultMap = new HashMap<>();
			resultMap.put(Constant.DATA, platform.getAllPlatForm());
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);
		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						Constants.UNABLE_TO_LIST_INVITED_APPLICATION, Constants.UNABLE_TO_LIST_INVITED_APPLICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			PALogger.ERROR(e);	
		}
	}

	private void mAddAppSecret(String authToken, String appId,HttpServletRequest uploadedInputStream)
	{
		HashMap<String, String> formItems=new HashMap<>();
		HashMap<String, String> inputstreaHash= new HashMap<>();
		SecretVo secretObj =null;
		ServletFileUpload fileUpload = new ServletFileUpload();
		try {
			// CHECK AUTH TOKEN...
			AuthorizationsVO authVo=new GrpcAuthHelper().getAuthorizationsVO(authToken);
			Applications applications=new Applications();
			String appOwnerId = applications.getUserIdOfApp(appId);
			if (!StringFunctions.isNullOrWhitespace(appOwnerId)) 
			{
				String appSecretId ="";
				String appSecretVersionId = "";
				if (!appOwnerId.equals(authVo.getUserId()))
				{
					List<String> lstPermissions = new ArrayList<>();
					lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.APP_SECRET_CREATE));
					Utility.checkPermission(authVo.getGroupPermissions(),lstPermissions, appId, false);

				}
				String tempfilepath = "";
				String fileName ="";
				boolean isAddSecretVO = false;
				if(ServletFileUpload.isMultipartContent(uploadedInputStream))
				{
					FileItemIterator items = fileUpload.getItemIterator(uploadedInputStream);

					while (items.hasNext())
					{
						FileItemStream item = items.next();
						if (!item.isFormField()) 
						{
							try(InputStream inputstream = item.openStream()){
								tempfilepath = new PortalFileUpload().inputStreamToFile(inputstream, TempFiles.getTempFolderPath() + item.getName());
								fileName = item.getName();
								inputstreaHash.put(item.getName(), tempfilepath);
							}
						}
						else 
						{
							try(InputStream fieldValue= item.openStream()){
								formItems.put(item.getFieldName(), Streams.asString(fieldValue));
							}
						}
					}
					secretObj =  new Gson().fromJson(formItems.get("secret"), SecretVo.class);
					if(StringFunctions.isNullOrWhitespace(secretObj.getAppSecretId())){
						appSecretId =Common.getRandomId();
						secretObj.setAppSecretId(appSecretId);
						isAddSecretVO = true;
					}
					appSecretVersionId = Common.getRandomId();
					secretObj.getListSecretVersion().get(0).setAppSecretVersionId(appSecretVersionId);
					secretObj.getListSecretVersion().get(0).setFileName(fileName);
					secretObj.getListSecretVersion().get(0).setAppSecretId(secretObj.getAppSecretId());
					secretObj.getListSecretVersion().get(0).setAppUserId(authVo.getUserId());
				}

				AppSecret secret = new AppSecret();

				SecretVo retObj= secret.insert(secretObj, isAddSecretVO);

				Map<String, Object> resultMap = new HashMap<>();
				if(secretObj.getListSecretVersion().get(0).getType().name().equals(SecretTypeEnum.file.name()))
				{
					String uploadBasePath =secret.getFileUploadPath(appId, appSecretVersionId);
					PortalFileUpload pfu = new PortalFileUpload();
					File file = new File(uploadBasePath);
					if(!file.exists()) {

						file.mkdirs();
					}
					resultMap = pfu.uploadAttachmentInline(inputstreaHash,uploadBasePath, true, false);

				}
				//add activity in db
				new ActivityLogs().insert(authVo.getUserId(), ActivityOperation.addAppSecret.name(), new Gson().toJson(secretObj));
				resultMap.put(Constant.DATA,retObj );
				ReturnObject.createResponse(Constant.SUCCESS, resultMap,null, response);
			}
			else{
				//if Application not found for given application Id then throw NOTFOUND exception. 
				throw new Exception(Constant.NOTFOUND);
			}
		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, "");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else if(e.getMessage().equals(Constant.NOTFOUND)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_NOT_FOUND , "Application not found", "");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED,"");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().contains("already exists."))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_CONFLICT ,e.getMessage(),"");//"Secret key or display name already exists","");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,"Unable to add app secret", "");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			PALogger.ERROR(e);	
		}
	}

	private void mEditAppSecret(String authToken, String appId,HttpServletRequest uploadedInputStream)
	{
		HashMap<String, String> formItems=new HashMap<>();
		HashMap<String, String> inputstreaHash= new HashMap<>();
		SecretVo secretObj =null;
		ServletFileUpload fileUpload = new ServletFileUpload();
		try {
			// CHECK AUTH TOKEN...
			AuthorizationsVO authVo=new GrpcAuthHelper().getAuthorizationsVO(authToken);
			Applications applications=new Applications();
			String appOwnerId = applications.getUserIdOfApp(appId);
			if (!StringFunctions.isNullOrWhitespace(appOwnerId)) 
			{
				if (!appOwnerId.equals(authVo.getUserId()))
				{
					List<String> lstPermissions = new ArrayList<>();
					lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.APP_SECRET_EDIT));
					Utility.checkPermission(authVo.getGroupPermissions(),lstPermissions, appId, false);

				}
				String tempfilepath = "";
				String fileName ="";
				boolean toUploadFile= false;
				if(ServletFileUpload.isMultipartContent(uploadedInputStream))
				{
					FileItemIterator items = fileUpload.getItemIterator(uploadedInputStream);

					while (items.hasNext())
					{
						FileItemStream item = items.next();
						if (!item.isFormField()) 
						{
							try(InputStream inputstream = item.openStream()){
								tempfilepath = new PortalFileUpload().inputStreamToFile(inputstream, TempFiles.getTempFolderPath() + item.getName());
								fileName = item.getName();
								inputstreaHash.put(item.getName(), tempfilepath);
								toUploadFile =true;
							}
						}
						else 
						{
							try(InputStream fieldValue= item.openStream()){
								formItems.put(item.getFieldName(), Streams.asString(fieldValue));
							}
						}
					}
					secretObj =  new Gson().fromJson(formItems.get("secret"), SecretVo.class);
					secretObj.getListSecretVersion().get(0).setFileName(fileName);
				}

				AppSecret secret = new AppSecret();


				SecretVo retObj= secret.edit(secretObj,toUploadFile);
				Map<String, Object> resultMap = new HashMap<>();
				if(retObj.getListSecretVersion().get(0).getType().name().equals(SecretTypeEnum.file.name()) && toUploadFile)
				{
					String uploadBasePath =secret.getFileUploadPath(appId, secretObj.getListSecretVersion().get(0).getAppSecretVersionId());
					PortalFileUpload pfu = new PortalFileUpload();
					File file = new File(uploadBasePath);
					if(!file.exists()) {

						file.mkdirs();
					}
					else
					{
						FileUtils.cleanDirectory(file);
					}
					resultMap = pfu.uploadAttachmentInline(inputstreaHash,uploadBasePath, true, false);

				}
				//add activity in db
				new ActivityLogs().insert(authVo.getUserId(), ActivityOperation.editAppSecret.name(), new Gson().toJson(secretObj));
				resultMap.put(Constant.DATA,retObj );
				ReturnObject.createResponse(Constant.SUCCESS, resultMap,null, response);
			}
			else{
				//if Application not found for given application Id then throw NOTFOUND exception. 
				throw new Exception(Constant.NOTFOUND);
			}
		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, "");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else if(e.getMessage().equals(Constant.NOTFOUND)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_NOT_FOUND , "Application not found", "");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED,"");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().contains("already exists."))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_CONFLICT ,e.getMessage(),"");//"Secret key or display name already exists","");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,"Unable to edit app secret", "");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			PALogger.ERROR(e);	
		}
	}
	/*
	 * Add method for delteAppSecretVersion using appSecretVersionId.
	 */
	private void mDeleteAppSecretVersion(String authToken, String appSecretVersionId,String appId) {
		try {
			// CHECK AUTH TOKEN...
			AuthorizationsVO authVo=new GrpcAuthHelper().getAuthorizationsVO(authToken);
			Applications applications=new Applications();
			String appOwnerId = applications.getUserIdOfApp(appId);
			if (!StringFunctions.isNullOrWhitespace(appOwnerId)) 
			{
				if (!appOwnerId.equals(authVo.getUserId()))
				{
					List<String> lstPermissions = new ArrayList<>();
					lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.APP_SECRET_DELETE));
					Utility.checkPermission(authVo.getGroupPermissions(),lstPermissions, appId, false);

				}
				AppSecret secret = new AppSecret();
				Map<String, Object> resultMap = new HashMap<>();
				resultMap.put(Constant.DATA,secret.deleteAppSecretVersion(appSecretVersionId));
				ReturnObject.createResponse(Constant.SUCCESS, resultMap,null, response);
			}
			else{
				//if Application not found for given application Id then throw NOTFOUND exception. 
				throw new Exception(Constant.NOTFOUND);
			}
		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, "");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else if(e.getMessage().equals(Constant.NOTFOUND)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_NOT_FOUND , "AppSecretVersion not found", "");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED,"");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,"Unable to delete app secret", "");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			PALogger.ERROR(e);	
		}
	}

	private void mDeleteAppSecret(String authToken, String appSecretId,String appId) {
		try {
			// CHECK AUTH TOKEN...
			AuthorizationsVO authVo=new GrpcAuthHelper().getAuthorizationsVO(authToken);
			Applications applications=new Applications();
			String appOwnerId = applications.getUserIdOfApp(appId);
			if (!StringFunctions.isNullOrWhitespace(appOwnerId)) 
			{
				if (!appOwnerId.equals(authVo.getUserId()))
				{
					List<String> lstPermissions = new ArrayList<>();
					lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.APP_SECRET_DELETE));
					Utility.checkPermission(authVo.getGroupPermissions(),lstPermissions, appId, false);

				}
				AppSecret secret = new AppSecret();
				Map<String, Object> resultMap = new HashMap<>();
				resultMap.put(Constant.DATA,secret.delete(appSecretId) );
				//add activity in db
				HashMap<String, String> map = new HashMap<>();
				map.put("applicationId", appId);
				map.put("appSecretId", appSecretId);

				new ActivityLogs().insert(authVo.getUserId(), ActivityOperation.deleteAppSecret.name(), new Gson().toJson(map));

				ReturnObject.createResponse(Constant.SUCCESS, resultMap,null, response);
			}
			else{
				//if Application not found for given application Id then throw NOTFOUND exception. 
				throw new Exception(Constant.NOTFOUND);
			}
		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, "");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else if(e.getMessage().equals(Constant.NOTFOUND)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_NOT_FOUND , "AppSecret not found", "");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED,"");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,"Unable to delete app secret", "");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			PALogger.ERROR(e);	
		}
	}

	private void mListAppSecret(String authToken,String appId) {
		try
		{
			AuthorizationsVO authVo=new GrpcAuthHelper().getAuthorizationsVO(authToken);

			Applications applications=new Applications();
			String appOwnerId = applications.getUserIdOfApp(appId);
			if (!StringFunctions.isNullOrWhitespace(appOwnerId)) 
			{
				if (!appOwnerId.equals(authVo.getUserId()))
				{
					List<String> lstPermissions = new ArrayList<>();
					lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.APP_SECRET_LIST));
					Utility.checkPermission(authVo.getGroupPermissions(),lstPermissions, appId, false);

				}
				AppSecret secret = new AppSecret();
				Map<String, Object> resultMap = new HashMap<>();
				resultMap.put(Constant.DATA, secret.listByAppId(appId));
				ReturnObject.createResponse(Constant.SUCCESS, resultMap,null, response);
			}
			else{
				//if Application not found for given application Id then throw NOTFOUND exception. 
				throw new Exception(Constant.NOTFOUND);
			}
		} catch (Exception e)
		{
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, "");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else if(e.getMessage().equals(Constant.NOTFOUND)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_NOT_FOUND , "Application not found", "");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED,"");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"Unable to list app secret", "");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			PALogger.ERROR(e);	
		}
	}


	private void mGetAppSecret(String authToken,String appId,String appSecretId) {
		try
		{
			AuthorizationsVO authVo=new GrpcAuthHelper().getAuthorizationsVO(authToken);

			Applications applications=new Applications();
			String appOwnerId = applications.getUserIdOfApp(appId);
			if (!StringFunctions.isNullOrWhitespace(appOwnerId)) 
			{
				if (!appOwnerId.equals(authVo.getUserId()))
				{
					List<String> lstPermissions = new ArrayList<>();
					lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.APP_SECRET_LIST));
					Utility.checkPermission(authVo.getGroupPermissions(),lstPermissions, appId, false);

				}
				AppSecret secret = new AppSecret();
				Map<String, Object> resultMap = new HashMap<>();
				resultMap.put(Constant.DATA, secret.get(appSecretId));
				ReturnObject.createResponse(Constant.SUCCESS, resultMap,null, response);
			}
			else{
				//if Application not found for given application Id then throw NOTFOUND exception. 
				throw new Exception(Constant.NOTFOUND);
			}
		} catch (Exception e)
		{
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, "");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else if(e.getMessage().equals(Constant.NOTFOUND)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_NOT_FOUND , "Application not found", "");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED,"");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"Unable to get app secret", "");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			PALogger.ERROR(e);	
		}
	}

}

/**
 * History of check-in or issue resolved
 * 
 * 01 - 12-10-2016 
 * AKH_01_1
 * Remove projectVO from returnParam, because companyName and companyWebAddress set in detailsVO object. 
 * 
 */
