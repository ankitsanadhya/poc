/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.service;

import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;

import com.google.gson.Gson;
import com.mwp.common.Client;
import com.mwp.common.ReturnObject;
import com.mwp.common.constant.Constant;
import com.mwp.common.vo.ErrorVo;
import com.mwp.logger.PALogger;
import com.mwp.p.common.Constants;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Path("/jwt-tokens")
@Api(value = "/jwt-tokens", produces = MediaType.APPLICATION_JSON)
public class JwtTokenEndpoint {

	@Context
	private HttpServletResponse response;
	@Context
	private HttpHeaders httpHeaders;
	@Context
	private HttpServletRequest request;

	@GET
	@Produces({ MediaType.APPLICATION_JSON })
	@ApiOperation( value = "Get new JWT Token", notes = "Get new JWT Token")
	@ApiResponses
	( {
		@ApiResponse( code = HttpServletResponse.SC_OK, message = "Token generated successfully" )
	} )
	public void generate(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken) 
	{
		mGenerate(authToken);
	}

	@POST
	@Produces({ MediaType.APPLICATION_JSON })
	@Path("generate-auth-code-token")
	@ApiOperation( value = "Get new code - token pair for user", notes = "Get new code - token pair for user")
	@ApiResponses
	( {
		@ApiResponse( code = HttpServletResponse.SC_OK, message = "Token generated successfully" )
	} )
	public void genereteAuthCodeToken(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken, 
			@ApiParam(value = "user jwt token", required = true) String jwtToken) 
	{
		mGenereteAuthCodeToken(authToken, jwtToken);
	}

	private void mGenerate(String authToken) 
	{
		try {
			
			if(!authToken.contains("bearer") && !authToken.contains("basic")) {
				authToken = Constant.BEARER + authToken;	
			}
			
			String result= Client.callServer(Constants.AUTH_SERVER_IP_PORT, "a.service/api", "jwt-tokens", "GET", "", null, null, authToken);
			HashMap<String, String> data =  new Gson().fromJson(result, HashMap.class);
			ReturnObject.createResponse(Constant.SUCCESS, data, null, response);
		} catch (Exception e) {
			PALogger.ERROR(e);
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, e.getMessage());
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Unable to get app version command", e.getMessage());
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
		}
	}

	private void mGenereteAuthCodeToken(String authToken, String jwtToken) {
		try {

			if(!authToken.contains("bearer") && !authToken.contains("basic")) {
				authToken = Constant.BEARER + authToken;	
			}

			String result= Client.callServer(Constants.AUTH_SERVER_IP_PORT, "a.service/api", "token/generate", "POST", "", null, jwtToken, authToken);
			HashMap<String, String> data =  new Gson().fromJson(result, HashMap.class);
			ReturnObject.createResponse(Constant.SUCCESS, data, null, response);
		} catch (Exception e) {
			PALogger.ERROR(e);
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, e.getMessage());
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Unable to get app version command", e.getMessage());
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
		}
	}
}