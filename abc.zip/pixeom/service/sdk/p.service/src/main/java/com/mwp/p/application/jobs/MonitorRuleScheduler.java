/** 
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com) 
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL 
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC. 
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD 
 * IN STRICTEST CONFIDENCE. 
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */ 

package com.mwp.p.application.jobs;

import com.mwp.common.interfaces.IScheduledJob;
import com.mwp.logger.PALogger;
import com.mwp.p.utility.RuleMoniterService;


/**
 * This class run a thread regularly in a time interval and delete garbage collection like deleted apps,projects and versions etc.;
 * @author root
 *
 */
public class MonitorRuleScheduler implements IScheduledJob
{
	// property used for specifying the interval in which scrub thread runs.
	private static final long RULE_INTERVAL = 300000; //5 Minute
	static MonitorRuleScheduler monitorRuleService;

	/**
	 * Method used for monitor rule.
	 * @throws Exception
	 */

	public void init()	
	{
		boolean isProcessRunning=false;
		while(true)
		{
			try
			{
				if(isProcessRunning)
					return;
				isProcessRunning=true;
				// Call Method for monitor rule.
				RuleMoniterService rm = new RuleMoniterService();
				rm.moniterRule();
				isProcessRunning=false;

			}catch(Exception e)
			{
				isProcessRunning=false;
				PALogger.ERROR(e);	
			}
			finally
			{
				try {
					Thread.sleep(RULE_INTERVAL);
				} catch (InterruptedException e) {
					PALogger.ERROR(e);	
					//Thread.currentThread().interrupt();
				}
			}

		}
	}
}