/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.service;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.constraints.NotNull;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;

import org.apache.commons.io.FileUtils;

import com.google.gson.Gson;
import com.mwp.common.AuthHelper;
import com.mwp.common.CredProvider;
import com.mwp.common.ReturnObject;
import com.mwp.common.StringFunctions;
import com.mwp.common.TempFiles;
import com.mwp.common.constant.Constant;
import com.mwp.common.constant.PermissionResourceKeys;
import com.mwp.common.constant.PermissionResources;
import com.mwp.common.enums.ActivityOperation;
import com.mwp.common.enums.RoleEnum;
import com.mwp.common.vo.AppResourceVO;
import com.mwp.common.vo.AuthorizationsVO;
import com.mwp.common.vo.ErrorVo;
import com.mwp.common.vo.FunctionVO;
import com.mwp.common.vo.VersionVO;
import com.mwp.logger.PALogger;
import com.mwp.p.authhelper.GrpcAuthHelper;
import com.mwp.p.common.AdminPermissionCheck;
import com.mwp.p.common.Constants;
import com.mwp.p.common.enums.ResourceType;
import com.mwp.p.common.vo.DownloadResourceVO;
import com.mwp.p.dal.engine.ApplicationResourceEngine;
import com.mwp.p.dal.engine.DeveloperApplicationsEngine;
import com.mwp.p.framework.ActivityLogs;
import com.mwp.p.framework.DiscoveryDetails;
import com.mwp.p.framework.Download;
import com.mwp.p.framework.Functions;
import com.pa.crypto.FileEncryptionDecryption;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Path("/download")
@Api(value = "/download", produces = MediaType.APPLICATION_JSON)
public class DownloadEndpoint {

	@Context
	private HttpServletResponse response;
	@Context
	private HttpHeaders httpHeaders;
	@Context
	private HttpServletRequest request;


	@POST
	@Produces({ MediaType.APPLICATION_JSON })
	@ApiOperation( value = "Gets download link.", notes = "Gets secured download link.")
	@ApiResponses
	({
		@ApiResponse( code = HttpServletResponse.SC_NO_CONTENT, message = "Not a valid file path." ),

		@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = "Request requires HTTP authentication"),
		@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = "Access denied."),

		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to get download link.")
	})
	public void get(@Context HttpServletRequest request,@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,
			@ApiParam(value = "Path of the file to download.", required = true) @NotNull String resourceId) {
		mGet(authToken,request, resourceId);
	}

	@POST
	@Path("/resource")
	@Produces({ MediaType.APPLICATION_JSON })
	@ApiOperation( value = "adds resource.", notes = "Adds download resource.")
	@ApiResponses
	({
		@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = "Request requires HTTP authentication"),
		@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = "Access denied."),

		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to add resource.")
	})
	public void addResource(@Context HttpServletRequest request,@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,
			@ApiParam(value = "DownloadResourceVO object ", required = true) @NotNull DownloadResourceVO resourceVO) {
		mAdd(authToken, resourceVO);
	}

	@PUT
	@Path("/resource/{resourceid}")
	@Produces({ MediaType.APPLICATION_JSON })
	@ApiOperation( value = "Edit resource.", notes = "Edits download resource.")
	@ApiResponses
	({
		@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = "Request requires HTTP authentication"),
		@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = "Access denied."),

		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to edit resource.")
	})
	public void editResource(@Context HttpServletRequest request,@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,
			@ApiParam(value = "Resource id.", required = true) @NotNull @PathParam("resourceid") String resourceId,
			@ApiParam(value = "DownloadResourceVO object ", required = true) @NotNull DownloadResourceVO resourceVO) {
		mEdit(authToken,resourceId, resourceVO);
	}
	@PUT
	@Path("/resource/order")
	@Produces({ MediaType.APPLICATION_JSON })
	@ApiOperation( value = "edit resource order.", notes = "Edits download resource order.")
	@ApiResponses
	({
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to edit resource order.")
	})
	public void updateResourceOrder(@Context HttpServletRequest request,@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,
			@ApiParam(value = "id order map ", required = true) @NotNull Map<String, Integer> idOrderMap) {
		mUpdateResourceOrder(authToken,idOrderMap);
	}
	@DELETE
	@Path("/resource/{resourceid}")
	@Produces({ MediaType.APPLICATION_JSON })
	@ApiOperation( value = "Delete download resource.", notes = "Deletes download resource.")
	@ApiResponses
	({
		@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = "Request requires HTTP authentication"),
		@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = "Access denied."),

		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to delete resource.")
	})
	public void deleteResource(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,
			@ApiParam(value = "Resource id which we need to delete.", required = true) @NotNull @PathParam("resourceid") String resourceId) {
		mDelete(authToken, resourceId);
	}

	@GET
	@Path("/resource/")
	@Produces({ MediaType.APPLICATION_JSON })
	@ApiOperation( value = "delete resource.", notes = "Deletes download resource.")
	@ApiResponses
	({
		@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = "Request requires HTTP authentication"),
		@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = "Access denied."),

		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to delete resource.")
	})
	public void listResource(@Context HttpServletRequest request,@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,
			@ApiParam(value = "resource type.", required = false) @NotNull @QueryParam("resourceType") String resourceType) {
		mList(authToken, resourceType);
	}


	@POST
	@Path("/getlink")
	@Produces({ MediaType.APPLICATION_JSON })
	@ApiOperation( value = "This method returns the download URL of the selected software for download.",
	notes = "This method returns the download URL of the selected software for download.")
	@ApiResponses
	({
		@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = "Request requires HTTP authentication"),
		@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = "Access denied."),

		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to get downlod link."),

		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Incorrect password.")
	})
	public void getlink(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,
			@ApiParam(value = "Path of the file to download.", required = true) @NotNull Map<String, String> pathpasswrd) {
		mGet(authToken, request, pathpasswrd.get("resourceId"),pathpasswrd.get("password"));
	}


	/*@GET
	@Produces({ MediaType.APPLICATION_JSON })
	@ApiOperation( value = "Available software updates.", notes = "Available software updates.")
	@ApiResponses
	({
		@ApiResponse( code = HttpServletResponse.SC_NOT_FOUND, message = "requested file not found." ),

		@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = "Request requires HTTP authentication"),
		@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = "Access denied."),

		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to get Info.")
	})
	public void getSoftwaresUpdates(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken) {
		mGetSoftwares(authToken);
	}*/







	@GET
	@Path("{secureToken}")
	@Produces({ MediaType.APPLICATION_JSON })
	@ApiOperation( value = "Push file for download.", notes = "Push file for download.")
	@ApiResponses
	({
		@ApiResponse( code = HttpServletResponse.SC_NOT_FOUND, message = "Requested file not found." ),

		@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = "Request requires HTTP authentication"),
		@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = "Access denied."),

		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to download file.")
	})
	public void downloadFile(@ApiParam(value = "Push file for download.", required = true) @NotNull @PathParam("secureToken") String secureToken) {
		mDownloadFile(secureToken);
	}

	@GET
	@Path("/yml/device/{deviceId}/appId/{appId}/version/{versionId}")
	@Produces({ MediaType.APPLICATION_JSON })
	@ApiOperation( value = "This method is used to download the yaml file of a particular application version.", notes = "This method is used to download the yaml file of a particular application version.")
	@ApiResponses
	({
		@ApiResponse( code = HttpServletResponse.SC_NOT_FOUND, message = "Requested file not found." ),
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Download url expired."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to download file.")
	})
	public void downloadYml(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,
			@ApiParam(value = "The unique Id of the Appliance.", required = true) @NotNull @PathParam("deviceId") String deviceId,
			@ApiParam(value = "The unique Id of the application version.", required = true)@PathParam("versionId") String versionId,
			@ApiParam(value = "The unique Id of the Appliaction.", required = true)@PathParam("appId") String appId) {
		mDownloadYml(deviceId,versionId,authToken,appId);
	}


	@GET
	@Path("/secret/device/{deviceId}/version/{versionId}/secret/{secret}/key/{key}")
	@Produces({ MediaType.APPLICATION_JSON })
	@ApiOperation( value = "Push file for download.", notes = "Push file for download.")
	@ApiResponses
	({
		@ApiResponse( code = HttpServletResponse.SC_NOT_FOUND, message = "Requested file not found." ),

		@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = "Request requires HTTP authentication"),
		@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = "Access denied."),

		@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = "Download url expired."),

		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to download file.")
	})
	public void downloadSecret(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,@ApiParam(value = "Push file for download.", required = true) @NotNull @PathParam("deviceId") String deviceId ,@PathParam("versionId") String versionId,@PathParam("secret") String secret,@PathParam("key") String key) {
		mDownloadSecret(deviceId,versionId,secret,authToken,key);
	}
	
	@GET
	@Path("/secret/device/{deviceId}/version/{versionId}/secret/{secret}")
	@Produces({ MediaType.APPLICATION_JSON })
	@ApiOperation( value = "Push file for download.", notes = "Push file for download.")
	@ApiResponses
	({
		@ApiResponse( code = HttpServletResponse.SC_NOT_FOUND, message = "Requested file not found." ),

		@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = "Request requires HTTP authentication"),
		@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = "Access denied."),

		@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = "Download url expired."),

		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to download file.")
	})
	public void downloadSecret(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,@ApiParam(value = "Push file for download.", required = true) @NotNull @PathParam("deviceId") String deviceId ,@PathParam("versionId") String versionId,@PathParam("secret") String secret) {
		mDownloadSecret(deviceId,versionId,secret,authToken,null);
	}



	@GET
	@Path("/secret/device/{deviceId}/app/{appId}/secret/{secretId}/filename/{filename}")
	@Produces({ MediaType.APPLICATION_JSON })
	@ApiOperation( value = "Push file for download.", notes = "Push file for download.")
	@ApiResponses
	({
		@ApiResponse(code = HttpServletResponse.SC_NOT_FOUND, message = "Requested file not found." ),

		@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = "Request requires HTTP authentication"),
		@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = "Access denied."),

		@ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to download file.")
	})
	public void downloadOptionalSecret(
			@ApiParam(value = "Authorization token",required=true)@HeaderParam("Authorization") String authToken,
			@ApiParam(value = "Push file for download.", required = true) @NotNull @PathParam("deviceId") String deviceId ,
			@ApiParam(value = "The unique id of the Appliance.", required = true) @PathParam("appId") String appId,
			@ApiParam(value = "The unique id of the Secret.", required = true) @PathParam("secretId") String secretId,
			@ApiParam(value = "The unique id of the Filename.", required = true) @PathParam("filename") String filename) {
		mDownloadOptionalSecret(secretId,filename,deviceId,appId,authToken);
	}

	@GET
	@Path("/function/device/{deviceId}/functionVersion/{versionId}/function/{functionId}")
	@Produces({ MediaType.APPLICATION_JSON })
	@ApiOperation( value = "Push file for download.", notes = "Push file for download.")
	@ApiResponses
	({
		@ApiResponse( code = HttpServletResponse.SC_NOT_FOUND, message = "Requested file not found." ),

		@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = "Request requires HTTP authentication"),
		@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = "Access denied."),

		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to download file.")
	})
	public void downloadFunction(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,
			@ApiParam(value = "Push file for download.", required = true) @NotNull @PathParam("deviceId") String deviceId ,
			@ApiParam(value = "The unique id of the Version.", required = true) @PathParam("versionId") String versionId,
			@ApiParam(value = "The unique id of the Function id.", required = true) @PathParam("functionId") String functionId) {
		mDownloadFunctions(deviceId,versionId,functionId,authToken);
	}


	@GET
	@Path("/functions/{functionId}/version/{versionId}")
	@Produces({ MediaType.APPLICATION_JSON })
	@ApiOperation( value = "Push file for download.", notes = "Push file for download.")
	@ApiResponses
	({
		@ApiResponse( code = HttpServletResponse.SC_NOT_FOUND, message = "Requested file not found." ),

		@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = "Request requires HTTP authentication"),
		@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = "Access denied."),

		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to download file.")
	})
	public void downloadFunctionDec(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken ,
			@ApiParam(value = "The unique id of the Version id.", required = true)@PathParam("versionId") String versionId,
			@ApiParam(value = "The unique id of the Function id.", required = true)@PathParam("functionId") String functionId) {
		mDownloadFunctionDec(versionId,functionId,authToken);
	}

	@GET
	@Path("/apps/{appId}/resources/{resourceId}")
	@Produces({ MediaType.APPLICATION_OCTET_STREAM })
	@ApiOperation( value = "Download application YML.", notes = "Push file for download.")
	@ApiResponses({
		@ApiResponse( code = HttpServletResponse.SC_NOT_FOUND, message = "Requested file not found." ),

		@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = "Request requires HTTP authentication"),
		@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = "Access denied."),

		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to download file.")
	})
	public void downloadAppResource(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,
			@ApiParam(value = "The unique id of the Application id.", required = true) @PathParam("appId") String appId,
			@ApiParam(value = "Push file for download.", required = true) @PathParam("resourceId") String resourceId) {
		mDownloadAppResource(authToken, appId, resourceId);
	}

	@GET
	@Path("/yml/appId/{appId}/version/{versionId}")
	@Produces({ MediaType.APPLICATION_OCTET_STREAM })
	@ApiOperation( value = "Download application YML.", notes = "Push file for download.")
	@ApiResponses({
		@ApiResponse( code = HttpServletResponse.SC_NOT_FOUND, message = "Requested file not found." ),

		@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = "Request requires HTTP authentication"),
		@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = "Access denied."),

		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to download file.")
	})
	public void downloadYml(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,
			@ApiParam(value = "Push file for download.", required = true) @PathParam("versionId") String versionId, 
			@ApiParam(value = "The unique id of the Application id.", required = true) @PathParam("appId") String appId) {
		mDownloadYmlDec(versionId,authToken,appId);
	}

	@GET
	@Path("/device/{deviceId}/version/{versionId}/config/{config}/key/{key}")
	@Produces({ MediaType.APPLICATION_JSON })
	@ApiOperation( value = "Push file for download.", notes = "Push file for download.")
	@ApiResponses
	({
		@ApiResponse( code = HttpServletResponse.SC_NOT_FOUND, message = "requested file not found." ),
		
		@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = "Request requires HTTP authentication"),
		@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = "Access denied."),
		
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to download file.")
	})
	public void downloadconfig(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,@ApiParam(value = "Push file for download.", required = true) @NotNull @PathParam("deviceId") String deviceId ,@PathParam("versionId") String versionId,@PathParam("config") String config,@PathParam("key") String key) {
		mDownloadConfig(deviceId,versionId,config,authToken,key);
	}

	@GET
	@Path("/device/{deviceId}/version/{versionId}/config/{config}")
	@Produces({ MediaType.APPLICATION_JSON })
	@ApiOperation( value = "Push file for download.", notes = "Push file for download.")
	@ApiResponses
	({
		@ApiResponse( code = HttpServletResponse.SC_NOT_FOUND, message = "requested file not found." ),
		
		@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = "Request requires HTTP authentication"),
		@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = "Access denied."),
		
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to download file.")
	})
	public void downloadconfig(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,@ApiParam(value = "Push file for download.", required = true) @NotNull @PathParam("deviceId") String deviceId ,@PathParam("versionId") String versionId,@PathParam("config") String config) {
		mDownloadConfig(deviceId,versionId,config,authToken,null);
	}

	private void mGet(String authToken,HttpServletRequest request, String resourceId) {
		try {
			String userid = new GrpcAuthHelper().checkAuthorization(authToken);

			HashMap<String, String> param = new HashMap<>();
			param.put("resourceId", resourceId);
			String ipReal = new DiscoveryDetails().getClientIP(request);
			param.put("requestIP", ipReal);
			new ActivityLogs().insert(userid, ActivityOperation.getDownload.name(), new Gson().toJson(param));
			
			Download download = new Download();
			String result = download.getUrl(resourceId);

			Map<String, Object> resultMap = new HashMap<>();
			resultMap.put(Constant.DATA, result);

			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);

		} catch (Exception e) {
			PALogger.ERROR(e);	

			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			} else if(e.getMessage().equals(Constant.NOTFOUND)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_NOT_FOUND, "Requested file not found.", "");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			} else {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to get downlod link.", e);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
		}
	}

	private void mGet(String authToken, HttpServletRequest request, String resourceId, String password) {
		try {

			String userid =  new GrpcAuthHelper().checkAuthorization(authToken);

			HashMap<String, String> param = new HashMap<>();
			param.put("resourceId", resourceId);
			String ipReal = new DiscoveryDetails().getClientIP(request);
			param.put("requestIP", ipReal);
			new ActivityLogs().insert(userid, ActivityOperation.getDownload.name(), new Gson().toJson(param));

			Download download = new Download();
			String result = download.getUrl(resourceId,password);

			Map<String, Object> resultMap = new HashMap<>();
			resultMap.put(Constant.DATA, result);

			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);

		} catch (Exception e) {
			PALogger.ERROR(e);	

			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			} else if(e.getMessage().equals(Constant.NOTFOUND)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_NOT_FOUND, "Requested file not found.", "");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			} 
			else if(e.getMessage().equals(Constant.INCORRECTLOGIN)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Incorrect password.", "");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to get downlod link.", e);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
		}
	}

	private void mDownloadFile(String secureToken) {
		try {

			PALogger.INFO("Query Start: " + System.currentTimeMillis());
			Download download = new Download();
			String filePath = download.downloadFile(secureToken);


			File file = new File(filePath);

			if(!file.exists()) {
				throw new Exception(Constant.NOTFOUND);
			}

			response.setContentType(MediaType.APPLICATION_OCTET_STREAM);
			response.setStatus(HttpServletResponse.SC_OK);
			response.setHeader("content-disposition", "attachment; filename=" + file.getName());
			response.addHeader("Content-Length", Long.toString(file.length()));

			FileInputStream input = new FileInputStream(file);
			byte[] buffer = new byte[32000];
			int read = 0;
			try {
				while ((read = input.read(buffer)) != -1) {
					response.getOutputStream().write(buffer,0,read);
					response.getOutputStream().flush();
				}
			} finally {
				input.close();
			}

			response.getOutputStream().flush();
			response.getOutputStream().close();
		} catch (Exception e) {
			PALogger.ERROR("Query End: " + System.currentTimeMillis());
			PALogger.ERROR(e);	
			ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to download file", e);
			if(e.getMessage().equals(Constant.UNAUTHORIZED)) {
				errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , "Download url expired.", ".");
			} else if(e.getMessage().equals(Constant.NOTFOUND)) {
				errorVo = new ErrorVo(HttpServletResponse.SC_NOT_FOUND, "Requested file not found.", "");
			}
			ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
		}
	}
	
	
	private void mDownloadYml(String deviceId,String versionnId,String authToken,String appId) {
		
		String tempDecPath="";
		String tempEncPath="";
		
		try {

			if(authToken.toLowerCase().startsWith(Constant.JWT_BEARER.toLowerCase())) {

				new AuthHelper().checkJwtToken(authToken, response);
			}
			else{
				new GrpcAuthHelper().checkAuthorization(authToken);
			}

			
			PALogger.INFO("Query Start: " + System.currentTimeMillis());
			
			DeveloperApplicationsEngine applicationsEngine = new DeveloperApplicationsEngine();
			VersionVO versionVO =  applicationsEngine.getVersionDetails(appId, versionnId);
			File file = new File(versionVO.getConfigYmlPath());
			String name = file.getName();
			
			Download download = new Download();
			String filePath = Constants.PORTAL_FILES_PATH + Constants.PORTAL_YML_FOLDER_NAME + Constant.localFileSeparator + versionnId+ Constant.localFileSeparator+name;

			tempDecPath =TempFiles.getTempFolderPath() + name;
			FileEncryptionDecryption.Decrypt_File(filePath, tempDecPath , new CredProvider().getEcnKey());

			tempEncPath =TempFiles.getTempFolderPath() + name;
			FileEncryptionDecryption.Encrypt_File(tempDecPath, tempEncPath, deviceId);
			
			download.writeFile(tempEncPath, response);

		} catch (Exception e) {
			PALogger.ERROR("Query End: " + System.currentTimeMillis());
			PALogger.ERROR(e);	
			ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to download file", e);
			if(e.getMessage().equals(Constant.UNAUTHORIZED)) {
				errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , "Download url expired.", ".");
			} else if(e.getMessage().equals(Constant.NOTFOUND)) {
				errorVo = new ErrorVo(HttpServletResponse.SC_NOT_FOUND, "Requested file not found.", "");
			}
			ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
		}
		finally {
			FileUtils.deleteQuietly(new File(tempDecPath).getParentFile());
			FileUtils.deleteQuietly(new File(tempEncPath).getParentFile());
			
		}
	}

	private void mDownloadAppResource(String authToken, String appId, String resourceId) {
		try {

			new GrpcAuthHelper().checkAuthorization(authToken);

			ApplicationResourceEngine applicationResourceEngine = new ApplicationResourceEngine();
			AppResourceVO appResourceVO = applicationResourceEngine.get(resourceId);
			if(appResourceVO != null && appResourceVO.getAppId().equals(appId)) {			
				PALogger.INFO("Query Start: " + System.currentTimeMillis());
				Download download = new Download();

				download.writeFile(appResourceVO.getFilePath(), response);
			} else {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_NOT_FOUND, "Requested file not found.", "");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
		} catch (Exception e) {
			PALogger.ERROR("Query End: " + System.currentTimeMillis());
			PALogger.ERROR(e);	
			ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to download file", e);
			if(e.getMessage().equals(Constant.UNAUTHORIZED)) {
				errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , "Download url expired.", ".");
			} else if(e.getMessage().equals(Constant.NOTFOUND)) {
				errorVo = new ErrorVo(HttpServletResponse.SC_NOT_FOUND, "Requested file not found.", "");
			}
			ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
		}
	}

	private void mDownloadYmlDec(String versionnId,String authToken,String appId) {
		String tempFilePath = "";
		try {
		    
			if(authToken.toLowerCase().startsWith(Constant.JWT_BEARER.toLowerCase())) {

				new AuthHelper().checkJwtToken(authToken, response);
			}
			else{
				new GrpcAuthHelper().checkAuthorization(authToken);
			}
			tempFilePath = TempFiles.getTempFolderPath();
			
			DeveloperApplicationsEngine applicationsEngine = new DeveloperApplicationsEngine();
			VersionVO versionVO =  applicationsEngine.getVersionDetails(appId, versionnId);
			File file = new File(versionVO.getConfigYmlPath());
			String name = file.getName();
			
			
			PALogger.INFO("Query Start: " + System.currentTimeMillis());
			Download download = new Download();
			String filePath = Constants.PORTAL_FILES_PATH + Constants.PORTAL_YML_FOLDER_NAME + Constant.localFileSeparator + versionnId+ Constant.localFileSeparator+name;

			String tempDecPath = tempFilePath + name;
			FileEncryptionDecryption.Decrypt_File(filePath, tempDecPath , new CredProvider().getEcnKey());
			
			
			download.writeFile(tempDecPath, response);

		} catch (Exception e) {
			PALogger.ERROR("Query End: " + System.currentTimeMillis());
			PALogger.ERROR(e);	
			ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to download file", e);
			if(e.getMessage().equals(Constant.UNAUTHORIZED)) {
				errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , "Download url expired.", ".");
			} else if(e.getMessage().equals(Constant.NOTFOUND)) {
				errorVo = new ErrorVo(HttpServletResponse.SC_NOT_FOUND, "Requested file not found.", "");
			}
			ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
		}
		finally {
			FileUtils.deleteQuietly(new File(tempFilePath));
		}
	}
	
	private void mDownloadSecret(String deviceId,String versionId,String secretName,String authToken,String key) {
		String tempDecPath="";
		String tempEncPath="";
		try {

			if(authToken.toLowerCase().startsWith(Constant.JWT_BEARER.toLowerCase())) {

				new AuthHelper().checkJwtToken(authToken, response);
			}
			else{
				new GrpcAuthHelper().checkAuthorization(authToken);
			}
			
			PALogger.INFO("Query Start: " + System.currentTimeMillis());
			Download download = new Download();
			String filePath = Constants.PORTAL_FILES_PATH + Constants.PORTAL_YML_FOLDER_NAME + Constant.localFileSeparator + versionId+ Constant.localFileSeparator+"secret"+Constant.localFileSeparator+ key+ Constant.localFileSeparator+ secretName;

			if(!new File(filePath).exists())
				filePath = Constants.PORTAL_FILES_PATH + Constants.PORTAL_YML_FOLDER_NAME + Constant.localFileSeparator + versionId+ Constant.localFileSeparator+"secret"+Constant.localFileSeparator+secretName;
				
			tempDecPath =TempFiles.getTempFolderPath() + secretName+"Dec";
			FileEncryptionDecryption.Decrypt_File(filePath, tempDecPath, new CredProvider().getEcnKey());
			
			tempEncPath =TempFiles.getTempFolderPath() + secretName;
			FileEncryptionDecryption.Encrypt_File(tempDecPath, tempEncPath, deviceId);

			download.writeFile(tempEncPath, response);
			
			

		} catch (Exception e) {
			PALogger.ERROR("Query End: " + System.currentTimeMillis());
			PALogger.ERROR(e);	
			ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to download file", e);
			if(e.getMessage().equals(Constant.UNAUTHORIZED)) {
				errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , "Download url expired.", ".");
			} else if(e.getMessage().equals(Constant.NOTFOUND)) {
				errorVo = new ErrorVo(HttpServletResponse.SC_NOT_FOUND, "Requested file not found.", "");
			}
			ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
		}
		finally{
			FileUtils.deleteQuietly(new File(tempDecPath).getParentFile());
			FileUtils.deleteQuietly(new File(tempEncPath).getParentFile());
		}
	}
	
	private void mDownloadConfig(String deviceId,String versionId,String configName,String authToken,String key) {
		String tempDecPath="";
		String tempEncPath="";
		try {

			if(authToken.toLowerCase().startsWith(Constant.JWT_BEARER.toLowerCase())) {

				new AuthHelper().checkJwtToken(authToken, response);
			}
			else{
				new GrpcAuthHelper().checkAuthorization(authToken);
			}
			
			PALogger.INFO("Query Start: " + System.currentTimeMillis());
			Download download = new Download();
			String filePath = Constants.PORTAL_FILES_PATH + Constants.PORTAL_YML_FOLDER_NAME + Constant.localFileSeparator + versionId+ Constant.localFileSeparator+"config"+ Constant.localFileSeparator + key + Constant.localFileSeparator+ configName;

			if(!new File(filePath).exists())
				filePath = Constants.PORTAL_FILES_PATH + Constants.PORTAL_YML_FOLDER_NAME + Constant.localFileSeparator + versionId+ Constant.localFileSeparator+"config"+Constant.localFileSeparator+ configName;
				
			tempDecPath =TempFiles.getTempFolderPath() + configName+"Dec";
			FileEncryptionDecryption.Decrypt_File(filePath, tempDecPath, new CredProvider().getEcnKey());
			
			tempEncPath =TempFiles.getTempFolderPath() + configName;
			FileEncryptionDecryption.Encrypt_File(tempDecPath, tempEncPath, deviceId);

			download.writeFile(tempEncPath, response);
			
			

		} catch (Exception e) {
			PALogger.ERROR("Query End: " + System.currentTimeMillis());
			PALogger.ERROR(e);	
			ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to download file", e);
			if(e.getMessage().equals(Constant.UNAUTHORIZED)) {
				errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , "Download url expired.", ".");
			} else if(e.getMessage().equals(Constant.NOTFOUND)) {
				errorVo = new ErrorVo(HttpServletResponse.SC_NOT_FOUND, "Requested file not found.", "");
			}
			ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
		}
		finally{
			FileUtils.deleteQuietly(new File(tempDecPath).getParentFile());
			FileUtils.deleteQuietly(new File(tempEncPath).getParentFile());
		}
	}
	
	private void mDownloadFunctions(String deviceId,String functionVersionId,String functionId,String authToken) {
		try {

			if(authToken.toLowerCase().startsWith(Constant.JWT_BEARER.toLowerCase())) {

				new AuthHelper().checkJwtToken(authToken, response);
			}
			else{
				new GrpcAuthHelper().checkAuthorization(authToken);
			}
			
			PALogger.INFO("Query Start: " + System.currentTimeMillis());
			Download download = new Download();
			String filePath = Constants.PORTAL_FILES_PATH + Constants.PORTAL_FUNCTION_FOLDER_NAME + Constant.localFileSeparator +functionId + Constant.localFileSeparator+ functionVersionId+".zip";

			String tempDecPath =TempFiles.getTempFolderPath() + functionId+"Dec";
			FileEncryptionDecryption.Decrypt_File(filePath, tempDecPath, new CredProvider().getEcnKey());
			
			
			String tempEncPath =TempFiles.getTempFolderPath() + functionId;
			FileEncryptionDecryption.Encrypt_File(tempDecPath, tempEncPath, deviceId);
			
			download.writeFile(tempEncPath, response);

		} catch (Exception e) {
			PALogger.ERROR("Query End: " + System.currentTimeMillis());
			PALogger.ERROR(e);	
			ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to download file", e);
			if(e.getMessage().equals(Constant.UNAUTHORIZED)) {
				errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , "Download url expired.", ".");
			} else if(e.getMessage().equals(Constant.NOTFOUND)) {
				errorVo = new ErrorVo(HttpServletResponse.SC_NOT_FOUND, "Requested file not found.", "");
			}
			ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
		}
	}
	
	private void mDownloadFunctionDec(String functionVersionId,String functionId,String authToken) {
		try {
			String userId = "";
			if(authToken.toLowerCase().startsWith(Constant.JWT_BEARER.toLowerCase())) {

				userId =  new AuthHelper().checkJwtToken(authToken, response).getUserId();
			}
			else{
				userId = new GrpcAuthHelper().checkAuthorization(authToken);
			}
			
			Functions functions = new Functions();
			FunctionVO functionVO = functions.getFunction(functionId, functionVersionId,userId);
			
			if(functionVO == null){
				throw new Exception(Constant.NOTFOUND);
			}
			
			PALogger.INFO("Query Start: " + System.currentTimeMillis());
			Download download = new Download();
			
			String functionPath = download.getFunctionUrl(functionId, functionVersionId);
			
			Map<String, Object> resultMap = new HashMap<>();
			resultMap.put(Constant.DATA, functionPath);

			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);

		} catch (Exception e) {
			PALogger.ERROR("Query End: " + System.currentTimeMillis());
			PALogger.ERROR(e);	
			ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to download file", e);
			if(e.getMessage().equals(Constant.UNAUTHORIZED)) {
				errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , "Download url expired.", ".");
			} else if(e.getMessage().equals(Constant.NOTFOUND)) {
				errorVo = new ErrorVo(HttpServletResponse.SC_NOT_FOUND, "Function not found.", "");
			}
			ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
		}
	}
	
	
	private void mDownloadOptionalSecret(String secretId ,String fileName,String deviceId,String appId,String authToken) {
		
		String tempDecPath="";
		String tempEncPath="";
		try {

			if(authToken.toLowerCase().startsWith(Constant.JWT_BEARER.toLowerCase())) {

				new AuthHelper().checkJwtToken(authToken, response);
			}
			else{
				new GrpcAuthHelper().checkAuthorization(authToken);
			}
			
			PALogger.INFO("Query Start: " + System.currentTimeMillis());
			Download download = new Download();
			String filePath = Constants.PORTAL_FILES_PATH + "app" + Constant.localFileSeparator +"secrets"+Constant.localFileSeparator+  appId+Constant.localFileSeparator+ secretId+Constant.localFileSeparator+fileName;
			tempDecPath =TempFiles.getTempFolderPath() + fileName+"Dec";
			FileEncryptionDecryption.Decrypt_File(filePath, tempDecPath, new CredProvider().getEcnKey());
			
			tempEncPath =TempFiles.getTempFolderPath() + fileName;
			FileEncryptionDecryption.Encrypt_File(tempDecPath, tempEncPath, deviceId);

			download.writeFile(tempEncPath, response);
			
			FileUtils.deleteQuietly(new File(tempDecPath));
			FileUtils.deleteQuietly(new File(tempEncPath));

		} catch (Exception e) {
			PALogger.ERROR("Query End: " + System.currentTimeMillis());
			PALogger.ERROR(e);	
			ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to download file", e);
			if(e.getMessage().equals(Constant.UNAUTHORIZED)) {
				errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , "Download url expired.", ".");
			} else if(e.getMessage().equals(Constant.NOTFOUND)) {
				errorVo = new ErrorVo(HttpServletResponse.SC_NOT_FOUND, "Requested file not found.", "");
			}
			ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
		}
		finally{
			FileUtils.deleteQuietly(new File(tempDecPath).getParentFile());
			FileUtils.deleteQuietly(new File(tempEncPath).getParentFile());
		}
	}


	private void mAdd(String authToken,DownloadResourceVO resourceVO) {
		try {

			AuthorizationsVO authvo = new GrpcAuthHelper().getAuthorizationsVO(authToken);
		
			if( authvo.getRole() != RoleEnum.Admin) 
			{
				throw new Exception(Constant.UNAUTHORIZED);
			}

			DownloadResourceVO retObj = new Download().add(resourceVO);

			Map<String, Object> resultMap = new HashMap<>();
			resultMap.put(Constant.DATA, retObj);

			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);


		} catch (Exception e) {
			
			PALogger.ERROR(e);	
			ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to add resource", e);
			if(e.getMessage().equals(Constant.UNAUTHORIZED))
			{
				errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, ".");
			} 
			ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
		}
	}
	
	

	
	private void mEdit(String authToken,String resourceId, DownloadResourceVO resourceVO) {
		try {

			AuthorizationsVO authvo = new GrpcAuthHelper().getAuthorizationsVO(authToken);
		
			if( authvo.getRole() != RoleEnum.Admin) 
			{
				throw new Exception(Constant.UNAUTHORIZED);
			}

			if(!resourceId.equals(resourceVO.getResourceId()))
				throw new Exception(Constant.UNAUTHORIZED);
			DownloadResourceVO retObj = new Download().edit(resourceVO);

			Map<String, Object> resultMap = new HashMap<>();
			resultMap.put(Constant.DATA, retObj);

			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);


		} catch (Exception e) {
			
			PALogger.ERROR(e);	
			ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to edit resource", e);
			if(e.getMessage().equals(Constant.UNAUTHORIZED))
			{
				errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, ".");
			} 
			ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
		}
	}

	
	private void mUpdateResourceOrder(String authToken,Map<String, Integer> idOrderMap) 
	{
		try {

			AuthorizationsVO authvo = new GrpcAuthHelper().getAuthorizationsVO(authToken);
		
			if( authvo.getRole() != RoleEnum.Admin) 
			{
				throw new Exception(Constant.UNAUTHORIZED);
			}

			new Download().updateSortOrder(idOrderMap);

			Map<String, Object> resultMap = new HashMap<>();
			resultMap.put(Constant.DATA, "true");

			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);


		} catch (Exception e) {
			
			PALogger.ERROR(e);	
			ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to edit resource", e);
			if(e.getMessage().equals(Constant.UNAUTHORIZED))
			{
				errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, ".");
			} 
			ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
		}
	}

	
	private void mDelete(String authToken,String resourceId) {
		try {

			AuthorizationsVO authvo = new GrpcAuthHelper().getAuthorizationsVO(authToken);
		
			if( authvo.getRole() != RoleEnum.Admin) 
			{
				throw new Exception(Constant.UNAUTHORIZED);
			}

			new Download().delete(resourceId);

			Map<String, Object> resultMap = new HashMap<>();
			resultMap.put(Constant.DATA, "true");

			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);


		} catch (Exception e) {
			
			PALogger.ERROR(e);	
			ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to delete resource", e);
			if(e.getMessage().equals(Constant.UNAUTHORIZED))
			{
				errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, ".");
			} 
			ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
		}
	}
	private void mList(String authToken,String resourceType) {
		try {

			AuthorizationsVO authvo = new GrpcAuthHelper().getAuthorizationsVO(authToken);
		
			List<DownloadResourceVO> rtrnLst = new ArrayList<>();
			if( authvo.getRole() == RoleEnum.Admin || 
					Constant.isWholePortalAccess()) 
			{
				rtrnLst = new Download().listResouces(resourceType);
			}
			else
			{
				List<String> lstPermissions = new ArrayList<>();
				if(!StringFunctions.isNullOrWhitespace(resourceType))
				{
				if(resourceType.equals(ResourceType.software.name()))
					lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_SOFTWARE));
				else if(resourceType.equals(ResourceType.document.name()))
					lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_DOCS));
				else 
				{
					throw new Exception(Constant.NOTPERMITTED);
				}

				}
				else
				{
					lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_DOCS));
					lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_SOFTWARE));
				}
				
				AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, true);
				
				List<String> groupIds = null;
				if(authvo.getGroupPermissions()!=null)
				{
					groupIds = new ArrayList<>(authvo.getGroupPermissions().keySet());
				if(groupIds!=null && !groupIds.isEmpty())
					rtrnLst = new Download().listResoucesInGroups(groupIds,resourceType);
				}
			}

			Map<String, Object> resultMap = new HashMap<>();
			resultMap.put(Constant.DATA, rtrnLst);

			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);


		} catch (Exception e) {
			
			PALogger.ERROR(e);	
			ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to list resource", e);
			if(e.getMessage().equals(Constant.UNAUTHORIZED))
			{
				errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, ".");
			} 
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				 errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
		}
	}

}