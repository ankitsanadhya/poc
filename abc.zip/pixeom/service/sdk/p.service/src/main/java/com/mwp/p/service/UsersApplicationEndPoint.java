/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.mwp.p.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.mwp.common.ReturnObject;
import com.mwp.common.constant.Constant;
import com.mwp.common.vo.DeviceVO;
import com.mwp.common.vo.ErrorVo;
import com.mwp.logger.PALogger;
import com.mwp.p.authhelper.GrpcAuthHelper;
import com.mwp.p.framework.UsersApplication;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Path("/usersapp")
public class UsersApplicationEndPoint 
{



	@Context
	private HttpServletResponse response;
	@Context
	private HttpHeaders httpHeaders;
	@Context
	private HttpServletRequest request;




	@GET
	@Produces({ MediaType.APPLICATION_JSON })
	@Consumes({MediaType.APPLICATION_JSON})
	@Path("/listDevice")
	@ApiOperation( value = "Find device detail with userIds", notes = "Find device detail with userIds", response = DeviceVO.class )
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "User with such email doesn't exists" ),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to get device detail" )
	} )
	public void listDevice(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,
			@ApiParam(value = "appid.", required = true) @QueryParam("appid") String appid){
		mlistDevice(authToken,appid);
	}


	private void mlistDevice(String authToken,String appid) {
		try {
			new GrpcAuthHelper().checkAuthorization(authToken);

			UsersApplication user = new UsersApplication();

			Map<String, Object> resultMap = new HashMap<>();
			resultMap.put(Constant.DATA, user.listDevice(appid));

			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);

		} catch (Exception e) {
			PALogger.ERROR(e);	

			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			} 
			else {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to get device list.", e);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
		}
	}
	//=======================================


	@GET
	@Produces({ MediaType.APPLICATION_JSON })
	@Consumes({MediaType.APPLICATION_JSON})
	@Path("/listDeviceApplication")
	@ApiOperation( value = "Find applications of  detail with userIds", notes = "Find applications of  detail with userIds", response = DeviceVO.class )
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "User with such email doesn't exists" ),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to get device applications." )
	} )
	public void listDeviceApplication(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,
			@ApiParam(value = "deviceid.", required = true) @QueryParam("deviceid") String deviceid){
		mlistDeviceApplication(authToken, deviceid);
	}


	private void mlistDeviceApplication(String authToken, String deviceid) {
		try {
			new GrpcAuthHelper().checkAuthorization(authToken);

			UsersApplication user = new UsersApplication();

			Map<String, Object> resultMap = new HashMap<>();
			resultMap.put(Constant.DATA, user.listDeviceApplication(deviceid));

			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);

		} catch (Exception e) {
			PALogger.ERROR(e);	

			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			} 
			else {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to get device list.", e);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
		}
	}


	@GET
	@Produces({ MediaType.APPLICATION_JSON })
	@Consumes({MediaType.APPLICATION_JSON})
	@Path("/listUsersDeviceApplication")
	@ApiOperation( value = "Find applications of  detail with userIds", notes = "Find applications of  detail with userIds", response = DeviceVO.class )
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "User with such email doesn't exists" ),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to get device applications." )
	} )
	public void listUsersDeviceApplication(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,
			@ApiParam(value = "userids.", required = true) @QueryParam("userids") String gsonuserids){

		ArrayList<String>  userids = new Gson().fromJson(gsonuserids,  new TypeToken<ArrayList<String>>(){}.getType());
		mlistUsersDeviceApplication(authToken, userids);
	}




	public void mlistUsersDeviceApplication(String authToken,List<String> userids) {
		try {
			new GrpcAuthHelper().checkAuthorization(authToken);

			UsersApplication user = new UsersApplication();

			Map<String, Object> resultMap = new HashMap<>();
			resultMap.put(Constant.DATA, user.listusersDeviceApplication(userids));

			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);

		} catch (Exception e) {
			PALogger.ERROR(e);	

			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			} 
			else {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to get device list.", e);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
		}
	}
	//=======================================



	@GET
	@Produces({ MediaType.APPLICATION_JSON })
	@Consumes({MediaType.APPLICATION_JSON})
	@Path("/listUsersApps")
	@ApiOperation( value = "Find Users Apps detail with userIds", notes = "Find Users Apps detail with userIds", response = DeviceVO.class )
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "User with such email doesn't exists" ),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to get Users Apps detail" )
	} )
	public void listUsersApps(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,
			@ApiParam(value = "useridsList.", required = true) @QueryParam("userid") String gsonuserids){
		ArrayList<String>  userids = new Gson().fromJson(gsonuserids,  new TypeToken<ArrayList<String>>(){}.getType());
		mlistUsersApps(authToken,userids);
	}




	private void mlistUsersApps(String authToken, ArrayList<String> userids) {
		try {
			new GrpcAuthHelper().checkAuthorization(authToken);

			UsersApplication user = new UsersApplication();

			Map<String, Object> resultMap = new HashMap<>();
			resultMap.put(Constant.DATA, user.listUsersApps(userids));

			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);

		} catch (Exception e) {
			PALogger.ERROR(e);	

			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			} 
			else {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to get Users Apps detail.", e);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
		}
	}




	@GET
	@Produces({ MediaType.APPLICATION_JSON })
	@Consumes({MediaType.APPLICATION_JSON})
	@Path("/listApplicationVersion")
	@ApiOperation( value = "Find Users Apps detail with userIds", notes = "Find Users Apps detail with userIds", response = DeviceVO.class )
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "User with such email doesn't exists" ),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to get Users Apps detail" )
	} )
	public void listApplicationVersion(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,
			@ApiParam(value = "appid.", required = true) @QueryParam("appid") String appid){
		mlistApplicationVersion(authToken,appid);
	}

	private void mlistApplicationVersion(String authToken,String appid) {
		try {
			new GrpcAuthHelper().checkAuthorization(authToken);
			UsersApplication user = new UsersApplication();

			Map<String, Object> resultMap = new HashMap<>();
			resultMap.put(Constant.DATA, user.listApplicationVersion(appid));

			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);

		} catch (Exception e) {
			PALogger.ERROR(e);	

			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			} 
			else {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to get Users Apps detail.", e);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
		}
	}


	@GET
	@Produces({ MediaType.APPLICATION_JSON })
	@Consumes({MediaType.APPLICATION_JSON})
	@Path("/listUsersApplicationVersion")
	@ApiOperation( value = "Find Users Apps detail with userIds", notes = "Find Users Apps detail with userIds", response = DeviceVO.class )
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "User with such email doesn't exists" ),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to get Users Apps detail" )
	} )
	public void listUsersApplicationVersion(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,
			@ApiParam(value = "useridsList.", required = true) @QueryParam("userids") String gsonuserids){
		ArrayList<String>  userids = new Gson().fromJson(gsonuserids,  new TypeToken<ArrayList<String>>(){}.getType());
		mlistApplicationVersion(authToken,userids);
	}


	private void mlistApplicationVersion(String authToken,ArrayList<String> userid) {
		try {
			new GrpcAuthHelper().checkAuthorization(authToken);
			UsersApplication user = new UsersApplication();

			Map<String, Object> resultMap = new HashMap<>();
			resultMap.put(Constant.DATA, user.listUsersApplicationVersion(userid));

			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);

		} catch (Exception e) {
			PALogger.ERROR(e);	

			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			} 
			else {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to get Users Apps detail.", e);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
		}
	}
	//=======================================


}
