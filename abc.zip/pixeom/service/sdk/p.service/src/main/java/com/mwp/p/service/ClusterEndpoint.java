/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.mwp.p.service;

import java.lang.reflect.Type;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.mwp.common.Client;
import com.mwp.common.ReturnObject;
import com.mwp.common.StringFunctions;
import com.mwp.common.constant.Constant;
import com.mwp.common.enums.ActivityOperation;
import com.mwp.common.enums.RuleServerType;
import com.mwp.common.vo.ErrorVo;
import com.mwp.logger.PALogger;
import com.mwp.p.authhelper.GrpcAuthHelper;
import com.mwp.p.common.Constants;
import com.mwp.p.common.vo.ClusterVO;
import com.mwp.p.common.vo.MonitorVO;
import com.mwp.p.framework.ActivityLogs;
import com.mwp.p.utility.MoniterRelayServer;
import com.mwp.p.utility.StorageMonitorService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Path("/cluster")
@Api(value = "/cluster", produces = MediaType.APPLICATION_JSON)
public class ClusterEndpoint {

	@Context
	private HttpServletResponse response;

	@GET
	@ApiOperation(value = "", notes = "get data of cluster.", response = String.class, responseContainer = "String")
	@ApiResponses({
			@ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to list cluster.") })
	public void list(
			@ApiParam(value = "Authorization token", required = true) @HeaderParam("Authorization") String authToken)
			throws Exception {
		try {
			new GrpcAuthHelper().checkAuthorization(authToken);
			Map<String, Object> resultMap = new HashMap<>();
			resultMap.put(Constant.DATA, mlist());
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);
		} catch (SQLException e) {
			PALogger.ERROR(e);
			ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Unable to list cluster.",
					Constants.CLUSTER_DATA);
			ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
		}

	}

	private ClusterVO mlist() throws Exception {

		String output = new StorageMonitorService().doLinuxCommand("gcloud container clusters list --format json");
		Type typeOfObjectsList = new TypeToken<ArrayList<ClusterVO>>() {
		}.getType();
		List<ClusterVO> clusters = Client.getGson().fromJson(output, typeOfObjectsList);

		if (!clusters.isEmpty())
			return clusters.get(0);
		else
			throw new Exception("Cluster not exist.");
	}

	@GET
	@Path("/monitor")
	@ApiOperation(value = "/monitor", notes = "monitor disk storage area and add disk if needed.", response = String.class, responseContainer = "String")
	@ApiResponses({
			@ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to list cluster.") })
	public void monitordata(
			@ApiParam(value = "Authorization token", required = true) @HeaderParam("Authorization") String authToken)
			throws Exception {
		try {
			Map<String, Object> data = new HashMap<>();
			new GrpcAuthHelper().checkAuthorization(authToken);
			Map<String, Object> resultMap = new HashMap<>();
			data.put(Constant.DATA + "Monitor", mMonitorData());
			data.put(Constant.DATA + "Cluster", mlist());
			resultMap.put(Constant.DATA, data);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);
		} catch (Exception e) {
			PALogger.ERROR(e);
			ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e.getMessage(), e.getMessage());
			ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
		}

	}

	@POST
	@Path("/adddisk/{baseSize}")
	@ApiOperation(value = "/adddisk/{baseSize})", notes = "monitor disk storage area and add disk if needed.", response = String.class, responseContainer = "String")
	@ApiResponses({ @ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
			@ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to add category."), })
	public void addDisk(
			@ApiParam(value = "Authorization token", required = true) @HeaderParam("Authorization") String authToken,
			@ApiParam(value = "", required = true) @PathParam("baseSize") String baseSizeData) throws Exception {
		try {
			// CHECK AUTH TOKEN...
			String userId = new GrpcAuthHelper().checkAuthorization(authToken);
			Map<String, Object> resultMap = new HashMap<>();

			long basesizedata = Math.round(Double.parseDouble(baseSizeData));

			resultMap.put(Constant.DATA, new StorageMonitorService().addDisk(1, basesizedata));
			// add activity in database
			Map<String, String> map = new HashMap<>();
			map.put("baseSize", baseSizeData);
			new ActivityLogs().insert(userId, ActivityOperation.addDisk.name(), new Gson().toJson(map));
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);
		} catch (Exception e) {
			PALogger.ERROR(e);
			ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Add disk failed.",
					Constants.CLUSTER_DATA);
			ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
		}

	}

	@POST
	@Path("/addrelay/{reuleservertype}")
	@ApiOperation(value = "/addrelay/{reuleservertype}", notes = "monitor disk storage area and add disk if needed.", response = String.class, responseContainer = "String")
	@ApiResponses({ @ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
			@ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to add category."), })
	public void addRelay(
			@ApiParam(value = "Authorization token", required = true) @HeaderParam("Authorization") String authToken,
			@ApiParam(value = "", required = true) @PathParam("reuleservertype") String ruleServerType)
			throws Exception {
		try {
			// CHECK AUTH TOKEN...
			String userId = new GrpcAuthHelper().checkAuthorization(authToken);

			Map<String, Object> resultMap = new HashMap<>();

			if (ruleServerType.equals(RuleServerType.relay.name()))
				resultMap.put(Constant.DATA, new MoniterRelayServer().addRelayOnDemand(RuleServerType.relay, true));
			else
				resultMap.put(Constant.DATA,
						new MoniterRelayServer().addRelayOnDemand(RuleServerType.supportRelay, false));
			// add activity in database
			Map<String, String> map = new HashMap<>();
			map.put("ruleServerType", ruleServerType);
			new ActivityLogs().insert(userId, ActivityOperation.addRelay.name(), new Gson().toJson(map));
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);
		} catch (Exception e) {
			PALogger.ERROR(e);
			ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, ".", Constants.CLUSTER_DATA);
			ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
		}

	}

	private MonitorVO mMonitorData() throws Exception {
		HashMap<String, Object> hashMap = new HashMap<>();
		List<String> clusterMonitoring = new ArrayList<>();
		try {
			String cmdToMonitor = "kubectl exec -it $(kubectl get pods | grep -m 1 ^nfs-server | awk {'print $1'}) -- df --output=size,used,avail,pcent /dev/sdb";

			ArrayList<String> s = new ArrayList<>();
			s.add(Constants.BIN_BASH);
			s.add("-c");
			s.add(cmdToMonitor);

			clusterMonitoring = new StorageMonitorService().clusterMonitoring(s);

			PALogger.INFO("static " + clusterMonitoring);

			ArrayList<String> keysList = new ArrayList<>(Arrays.asList(clusterMonitoring.get(0).split(" ")));

			Iterator<String> keys = keysList.listIterator();

			while (keys.hasNext()) {
				String ele = keys.next();
				if (StringFunctions.isNullOrWhitespace(ele))
					keys.remove();
			}
			PALogger.INFO(" Keys list" + keysList);
			ArrayList<String> valuesList = new ArrayList<>(Arrays.asList(clusterMonitoring.get(1).split(" ")));
			Iterator<String> values = valuesList.listIterator();
			while (values.hasNext()) {
				String ele = values.next();
				if (StringFunctions.isNullOrWhitespace(ele))
					values.remove();
			}
			PALogger.INFO(" Values list" + valuesList);
			for (int i = 0; i < valuesList.size(); i++) {
				if (keysList.get(i).equals("1K-blocks")) {
					keysList.remove(i);
					keysList.add(i, "totalSize");
				}
				hashMap.put(keysList.get(i), valuesList.get(i));
			}
			PALogger.INFO("" + hashMap);

			String baseSize = "";
			long basesizedata = 0;
			String baseSizeCmd = "gcloud --quiet compute disks list  --filter=\"name=" + Constants.getDataDiskName()
					+ "\" | sed -n '2p' | awk {'print $3'}";
			PALogger.INFO(" Exeecuting command" + baseSizeCmd);
			ArrayList<String> s2 = new ArrayList<>();
			s2.add(Constants.BIN_BASH);
			s2.add("-c");
			s2.add(baseSizeCmd);

			baseSize = new StorageMonitorService().getBaseSize(s2);
			try {
				PALogger.INFO(" getBaseSize OUTPUT: " + baseSize);
				if (hashMap.size() == 0 || baseSize.equals(""))
					throw new Exception("Monitor data not exist.");
				basesizedata = Long.parseLong(baseSize);
			} catch (Exception ex) {
				PALogger.ERROR(ex);
				throw new Exception("Monitor data not exist.");
			}
			MonitorVO monitorVo = new MonitorVO();
			monitorVo.setTotalSize(hashMap.get("totalSize").toString());
			monitorVo.setAvailableSize(hashMap.get("Avail").toString());
			monitorVo.setUsedSize(hashMap.get("Used").toString());
			monitorVo.setUsedPercentage(hashMap.get("Use%").toString());
				monitorVo.setAvailablePercentage(100-Integer.parseInt(monitorVo.getUsedPercentage().replace("%",""))+"%");
			monitorVo.setTotalBaseSize(basesizedata);
			return monitorVo;

		} catch (Exception e) {
			PALogger.ERROR("***********mMonitorData Exception********");
			PALogger.ERROR(e);
			PALogger.ERROR("" + e.getMessage());

			throw new Exception(e);
		}
	}

	public static void main(String[] args) {
		ClusterEndpoint cl = new ClusterEndpoint();
		try {
			String baseSize = "";
			long basesizedata = 0;
			String baseSizeCmd = "gcloud --quiet compute disks list  --filter=\"name=" + Constants.getDataDiskName()
					+ "\" | sed -n '2p' | awk {'print $3'}";
			ArrayList<String> s2 = new ArrayList<>();
			s2.add(Constants.BIN_BASH);
			s2.add("-c");
			s2.add(baseSizeCmd);
			baseSize = new StorageMonitorService().getBaseSize(s2);
			if (baseSize.equals(""))
				basesizedata = Long.parseLong(baseSize);
			PALogger.INFO("" + basesizedata);
			cl.mlist();
			cl.mMonitorData();

		} catch (Exception e) {
			PALogger.ERROR("" + e.getMessage());
			PALogger.ERROR(e);
		}
	}
}
