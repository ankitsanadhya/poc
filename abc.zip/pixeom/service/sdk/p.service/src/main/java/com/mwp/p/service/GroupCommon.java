/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.mwp.p.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.Context;

import com.google.gson.Gson;
import com.mwp.common.Client;
import com.mwp.common.ReturnObject;
import com.mwp.common.constant.Constant;
import com.mwp.common.constant.PermissionResourceKeys;
import com.mwp.common.constant.PermissionResources;
import com.mwp.common.enums.RoleEnum;
import com.mwp.common.vo.AuthorizationsVO;
import com.mwp.common.vo.CodeVO;
import com.mwp.common.vo.ErrorVo;
import com.mwp.common.vo.GroupsVO;
import com.mwp.logger.PALogger;
import com.mwp.p.authhelper.GrpcAuthHelper;
import com.mwp.p.common.AdminPermissionCheck;
import com.mwp.p.common.Constants;
import com.mwp.p.framework.Groups;
import com.sun.research.ws.wadl.HTTPMethods;

public class GroupCommon 
{
	@Context
	private HttpServletResponse response;

	
	protected void mCreateGroup(String authToken, GroupsVO groupVO,boolean isAdminGrp, HttpServletResponse responseObj) {
		try {
			// CHECK AUTH TOKEN...
			AuthorizationsVO authvo=new GrpcAuthHelper().getAuthorizationsVO(authToken);
			
			response= responseObj;
			if(isAdminGrp && authvo.getRole() != RoleEnum.Admin) 
				{
					throw new Exception(Constant.UNAUTHORIZED);
				}
			
			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_APPLIANCES));
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_PROJECTS));
			AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, false);
			
			groupVO.setAppId(Constants.PORTAL_APPLICATION_ID);// set protal appID
			groupVO.setAppUserId(authvo.getUserId());

			String result = Client.callServer(Constants.AUTH_SERVER_IP_PORT, Constants.AUTH_SERVICE_NAME, "group", HTTPMethods.POST.name(), "", null, groupVO, Constant.BEARER + authToken);//Create group
			ReturnObject.createResponse(Constant.SUCCESS, new Gson().fromJson(result, Map.class), null, response);
		

		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"Unable to create group", "Unable to create group");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			PALogger.ERROR(e);	
		}

	}

	protected void mEditGroup(String authToken, GroupsVO groupVO,boolean isAdminGrp,HttpServletResponse adminResponse) {
		try {
			// CHECK AUTH TOKEN...
			AuthorizationsVO authvo=new GrpcAuthHelper().getAuthorizationsVO(authToken);
			response= adminResponse;
			if(isAdminGrp && authvo.getRole() != RoleEnum.Admin) 
				{
					throw new Exception(Constant.UNAUTHORIZED);
				}
			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_APPLIANCES));
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_PROJECTS));
			AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, false);
			
			// Add auth token for authorizing.
			groupVO.setAppId(Constants.PORTAL_APPLICATION_ID);// set protal appID
			String result = Client.callServer(Constants.AUTH_SERVER_IP_PORT,Constants.AUTH_SERVICE_NAME, "group",  HTTPMethods.PUT.name(), "", null, groupVO, Constant.BEARER + authToken);
			ReturnObject.createResponse(Constant.SUCCESS, new Gson().fromJson(result, Map.class), null, response);
			

		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"Unable to update group", "Unable to update group");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			PALogger.ERROR(e);	
		}
	}

	protected void mDeleteGroup(String authToken, String groupId,boolean isAdminGrp,String filter, HttpServletResponse adminResponse) {
		try {
			// CHECK AUTH TOKEN...
			AuthorizationsVO authvo=new GrpcAuthHelper().getAuthorizationsVO(authToken);
			response=adminResponse;
			if(isAdminGrp && authvo.getRole() != RoleEnum.Admin) 
				{
					throw new Exception(Constant.UNAUTHORIZED);
				}
			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_APPLIANCES));
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_PROJECTS));
			AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, false);
			// Add auth token for authorizing.
			Client.callServer(Constants.AUTH_SERVER_IP_PORT,Constants.AUTH_SERVICE_NAME, "group",  HTTPMethods.DELETE.name(), groupId, null, null, Constant.BEARER + authToken);
			// to remove all apps, app versions and devices from group
			//user group(apps); admin group(edgecore) on portal
			
			new Groups().deleteGroupResources(groupId,filter);
			ReturnObject.createResponse(Constant.SUCCESS, null, null, response);

		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"Unable to delete group", "Unable to delete group");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			PALogger.ERROR(e);	
		}
	}
	
	protected void mRemoveMemberFromGroup(String authToken,String groupId,String userId,boolean isAdminGrp, HttpServletResponse adminResponse) {
		try {
			// CHECK AUTH TOKEN...
			AuthorizationsVO authvo =	new GrpcAuthHelper().getAuthorizationsVO(authToken);
			response=adminResponse;
			if(isAdminGrp && authvo.getRole() != RoleEnum.Admin) 
				{
					throw new Exception(Constant.UNAUTHORIZED);
				}
			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_APPLIANCES));
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_PROJECTS));
			AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, false);
			// Add Auth token for authorizing.
			String result = Client.callServer(Constants.AUTH_SERVER_IP_PORT,Constants.AUTH_SERVICE_NAME, "group",  HTTPMethods.DELETE.name(), groupId +"/user/"+userId, null, null,  Constant.BEARER + authToken);
			ReturnObject.createResponse(Constant.SUCCESS, new Gson().fromJson(result, Map.class), null, response);
		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"Unable to remove member from group", "Unable to remove member from group");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			PALogger.ERROR(e);	
		}
	}

	protected void mInvite(String authToken, CodeVO codeVo,boolean isAdminGrp, HttpServletResponse adminResponse) {
		try {
			// CHECK AUTH TOKEN...
		AuthorizationsVO authvo =	new GrpcAuthHelper().getAuthorizationsVO(authToken);
		response=adminResponse;
			if(isAdminGrp && authvo.getRole() != RoleEnum.Admin) 
				{
					throw new Exception(Constant.UNAUTHORIZED);
				}
			
			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_APPLIANCES));
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_PROJECTS));
			AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, false);
			codeVo.setAppId(Constants.PORTAL_APPLICATION_ID);

			String result = Client.callServer(Constants.AUTH_SERVER_IP_PORT,Constants.AUTH_SERVICE_NAME, "group",  HTTPMethods.POST.name(), "code", null, codeVo, Constant.BEARER + authToken);
			ReturnObject.createResponse(Constant.SUCCESS, new Gson().fromJson(result, Map.class), null, response);

		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"Unable to generate invitation.", "Unable to generate invitation.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			PALogger.ERROR(e);	
		}
	}

	protected void mEditCode(String authToken, CodeVO codeVo,boolean isAdminGrp, HttpServletResponse adminResponse) {
		try {
			//CHECK AUTH TOKEN...
			AuthorizationsVO authvo=new GrpcAuthHelper().getAuthorizationsVO(authToken);
			
			response=adminResponse;
			if(isAdminGrp && authvo.getRole() != RoleEnum.Admin) 
				{
					throw new Exception(Constant.UNAUTHORIZED);
				}
			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_APPLIANCES));
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_PROJECTS));
			AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, false);

			codeVo.setAppId(Constants.PORTAL_APPLICATION_ID);
			// Add Auth token for authorizing.
			String result = Client.callServer(Constants.AUTH_SERVER_IP_PORT,Constants.AUTH_SERVICE_NAME, "group",  HTTPMethods.PUT.name(), "code", null, codeVo,  Constant.BEARER + authToken);
			ReturnObject.createResponse(Constant.SUCCESS, new Gson().fromJson(result, Map.class), null, response);

		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"Unable to update code", "Unable to update code");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			PALogger.ERROR(e);	
		}
	}

	protected void mDeleteCode(String authToken, String codeId,boolean isAdminGrp, HttpServletResponse adminResponse) {
		try {
			// CHECK AUTH TOKEN...
			AuthorizationsVO authvo=new GrpcAuthHelper().getAuthorizationsVO(authToken);
			
			response= adminResponse;
			if(isAdminGrp && authvo.getRole() != RoleEnum.Admin) 
				{
					throw new Exception(Constant.UNAUTHORIZED);
				}
			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_APPLIANCES));
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_PROJECTS));
			AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, false);
			// Add Auth token for authorizing.
			String result = Client.callServer(Constants.AUTH_SERVER_IP_PORT,Constants.AUTH_SERVICE_NAME, "group", HTTPMethods.DELETE.name(), "code/"+codeId, null, null,  Constant.BEARER + authToken);
			ReturnObject.createResponse(Constant.SUCCESS, new Gson().fromJson(result, Map.class), null, response);

		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"Unable to delete code", "Unable to delete code");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			PALogger.ERROR(e);	
		}
	}
}
