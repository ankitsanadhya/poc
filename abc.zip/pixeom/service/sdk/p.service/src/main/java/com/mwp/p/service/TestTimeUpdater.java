/** 
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com) 
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL 
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC. 
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD 
 * IN STRICTEST CONFIDENCE. 
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */ 

package com.mwp.p.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mwp.logger.PALogger;
import com.mwp.p.common.enums.PortalDBEnum;
import com.mwp.p.dal.engine.PortalDatabaseEngine;

public class TestTimeUpdater {

	public static void main(String[] args) 
	{
//		int month=Integer.parseInt(args[0]);
//		
//		try
//		{
//			//Update time back to months and minute back in BoxStatic ,DeviceApplication, discoveryDetail...	
//
//			String hb = updateHeartBeatRateTime(month);
//			String app = updateAppInstallTime(month);
//			String bs = updateBoxStaticsTime( month);
//
//			List<String> queriesUpdate =   new   ArrayList<>();
//			queriesUpdate.add(hb);
//			queriesUpdate.add(app);
//			queriesUpdate.add(bs);
//
//
//			PortalDatabaseEngine.getInstance().getConnection().executeUpdatesInTransaction(queriesUpdate);
//			PALogger.INFO("data update.");
//
//		}
//		catch (SQLException e)
//		{
//			PALogger.ERROR(""+e.getMessage());				
//			PALogger.ERROR(e);	
//		}
	}


	private static String updateAppInstallTime(int monthBack)
	{
		String updateAppTimeQuery = 
				"UPDATE " + PortalDBEnum.TABLE_NAMES.deviceapplications.name()
				+ " SET ";

		String dateMonthPart = " DATE_SUB("
				+ PortalDBEnum.DEVICE_APPLICATIONS.modifiedDate.name() 
				+ " , "
				+ " Interval " + monthBack + " month "
				+ ")";
	
		dateMonthPart = " DATE_SUB("
				+  dateMonthPart
				+ " , "
				+ " Interval FLOOR(RAND() * (60)) minute "
				+ ")";

		dateMonthPart = " DATE_SUB("
				+  dateMonthPart
				+ " , "
				+ " Interval FLOOR(RAND() * (60)) second "
				+ ")";
		
		updateAppTimeQuery +=  PortalDBEnum.DEVICE_APPLICATIONS.modifiedDate.name()
				+ " = " 
				+  dateMonthPart;

		return updateAppTimeQuery;	
	}


	private static String updateBoxStaticsTime(int monthBack)
	{
		String updateBoxStaticsQuery = 
				"UPDATE " + PortalDBEnum.TABLE_NAMES.boxStatics.name()
				+ " SET " + PortalDBEnum.BOX_STATICS.modifiedDate.name() + " = ";

		String dateMonthPart = " DATE_SUB("
				+ PortalDBEnum.BOX_STATICS.modifiedDate.name() 
				+ " , "
				+ " Interval " + monthBack + " month "
				+ ")";

		dateMonthPart = " DATE_SUB("
				+  dateMonthPart
				+ " , "
				+ " Interval FLOOR(RAND() * (60)) minute "
				+ ")";

		dateMonthPart = " DATE_SUB("
				+  dateMonthPart
				+ " , "
				+ " Interval FLOOR(RAND() * (60)) second "
				+ ")";
		
		updateBoxStaticsQuery = updateBoxStaticsQuery + dateMonthPart;


		return updateBoxStaticsQuery;

	}


	private static String updateHeartBeatRateTime(int monthBack)
	{
		String updateHeartBeatQuery = 
				"UPDATE " + PortalDBEnum.TABLE_NAMES.discoverydetails.name()
				+ " SET "
				+ PortalDBEnum.DISCOVERY_DETAILS.dHBRdate.name()
				+ " = ";			
		
		String dateMonthPart = " DATE_SUB("
				+ PortalDBEnum.DISCOVERY_DETAILS.dHBRdate.name() 
				+ " , "
				+ " Interval " + monthBack + " month "
				+ ")";
	
		dateMonthPart = " DATE_SUB("
					+  dateMonthPart
					+ " , "
					+ " Interval FLOOR(RAND() * (60)) minute "
					+ ")";
		
		dateMonthPart = " DATE_SUB("
				+  dateMonthPart
				+ " , "
				+ " Interval FLOOR(RAND() * (60)) second "
				+ ")";
	

		updateHeartBeatQuery = updateHeartBeatQuery + dateMonthPart;



		return updateHeartBeatQuery; 
	}

}
