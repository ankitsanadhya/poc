/** 
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com) 
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL 
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC. 
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD 
 * IN STRICTEST CONFIDENCE. 
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */

package com.mwp.p.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import com.google.gson.Gson;
import com.mwp.common.Client;
import com.mwp.common.ReturnObject;
import com.mwp.common.StringFunctions;
import com.mwp.common.constant.Constant;
import com.mwp.common.enums.RoleEnum;
import com.mwp.common.vo.AuthorizationsVO;
import com.mwp.common.vo.ErrorVo;
import com.mwp.common.vo.ManagePermissionVO;
import com.mwp.logger.PALogger;
import com.mwp.p.authhelper.GrpcAuthHelper;
import com.mwp.p.common.Constants;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

// description = "This class use for permission."
@Path("/permissions")
@Api(value = "/permissions")
public class PermissionEndpoint {

	@Context
	private HttpServletResponse response;
	
	@POST
	@Consumes({ MediaType.APPLICATION_JSON })
	@Produces({ MediaType.APPLICATION_JSON })
	@ApiOperation( value = "perform operation on permission ", notes = "perform operation on permission")
	@ApiResponses
	( {
		@ApiResponse( code = HttpServletResponse.SC_CREATED, message = "Operation executed successfully" )
	} )
	public void executePermission(@ApiParam(value = "Authorization token", required =true) @HeaderParam("Authorization") String authToken,
			@ApiParam(value = "This is object type", required = true) List<ManagePermissionVO> permissionLst) 
	{
		mExecutePermission(authToken, permissionLst);
	}
	@GET
	@Produces({ MediaType.APPLICATION_JSON })
	@Consumes({ MediaType.APPLICATION_JSON })
	@ApiOperation( value = "List all permission for given application by application id.", notes = "List all permission for given application by application id.")
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to list permission.")		 
	} )
	public void listPermission(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,
			@ApiParam(value = "label key and value", required = false) @QueryParam("label") String labels)
	{
		mListPermission(authToken,labels);
		
	}
	
	@GET
	@Consumes({ MediaType.APPLICATION_JSON })
	@Produces({ MediaType.APPLICATION_JSON })
	@Path("role")
	@ApiOperation( value = "List role ", notes = "List role")
	@ApiResponses
	( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to list role.")	
	} )
	public void listRole(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,
			@ApiParam(value = "label key and value", required = false) @QueryParam("label") String labels) 
	{
		mListRole(authToken,labels);
	}
	
	
	@DELETE
	@Produces({ MediaType.APPLICATION_JSON })
	@Path("{permissionid}/permissionlabel")
	@ApiOperation( value = "Delete permission label", notes = "Delete permission label")
	@ApiResponses
	( {
		@ApiResponse( code = HttpServletResponse.SC_OK, message = "Permission label deleted successfully" ),
		@ApiResponse( code = HttpServletResponse.SC_NOT_FOUND, message = "Permission label does not exsits")
	} )
	public void deleteLabel(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,
			@ApiParam(value = "Permission Id", required = true ) @PathParam( "permissionid" ) final String permissionid,
			@ApiParam(value = "label key and value", required = true) @QueryParam("label") String labels)
	{
		mDelete(authToken,permissionid,labels,false);
	} 
	
	@DELETE
	@Produces({ MediaType.APPLICATION_JSON })
	@Path("{roleid}/rolelabel")
	@ApiOperation( value = "Delete role label", notes = "Delete role label")
	@ApiResponses
	( {
		@ApiResponse( code = HttpServletResponse.SC_OK, message = "Role label deleted successfully" ),
		@ApiResponse( code = HttpServletResponse.SC_NOT_FOUND, message = "Role label does not exsits")
	} )
	public void deleteRoleLabel(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,
			@ApiParam( value = "Role Id", required = true ) @PathParam( "roleid" ) final String roleId,
			@ApiParam(value = "label key and value", required = true) @QueryParam("label") String labels)
	{
		mDelete(authToken, roleId,labels,true);
	} 
	
	private void mExecutePermission(String authToken, List<ManagePermissionVO> permissionLst ) 
	{
		try
		{
			AuthorizationsVO authvo = new GrpcAuthHelper().getAuthorizationsVO(authToken);
//			List<String> lstPermissions = new ArrayList<>();
//			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_GROUPS));
//			AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, true);
			if(authvo.getRole()!=RoleEnum.Admin)
				throw new Exception(Constant.NOTPERMITTED);
			
			
				Client.callServer(Constants.AUTH_SERVER_IP_PORT, Constants.AUTH_SERVICE_NAME, "permissions","POST", "", null, permissionLst, Constant.BEARER + authToken);	
				ReturnObject.createResponse(Constant.SUCCESS, null, null, response);

		} catch (Exception e)
		{
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"Unable to perform operation.", "Unable to perform operation.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			PALogger.ERROR(e);	
		}
	}

	private void  mListPermission(String authToken,String labels) {
		try {
			// CHECK AUTH TOKEN...
			new GrpcAuthHelper().checkAuthorization(authToken);
			
			Map<Object, Object> labelMap =new HashMap<>();
			if(!StringFunctions.isNullOrWhitespace(labels))
			labelMap.put("label", labels);
			
			String result = Client.callServer(Constants.AUTH_SERVER_IP_PORT,Constants.AUTH_SERVICE_NAME,"permissions", "GET", "", labelMap, null, Constant.BEARER + authToken);
			ReturnObject.createResponse(Constant.SUCCESS, new Gson().fromJson(result, Map.class), null, response);

		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"Unable to list permission", "Unable to list permission");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			PALogger.ERROR(e);	
		}
	}
	
	private void  mListRole(String authToken,String labels) {
		try {
			// CHECK AUTH TOKEN...
			new GrpcAuthHelper().checkAuthorization(authToken);
			Map<Object, Object> labelMap =new HashMap<>();
			if(!StringFunctions.isNullOrWhitespace(labels))
			labelMap.put("label", labels);
			
			
			String result = Client.callServer(Constants.AUTH_SERVER_IP_PORT,Constants.AUTH_SERVICE_NAME,"permissions", "GET", "role",labelMap, null, Constant.BEARER + authToken);
			ReturnObject.createResponse(Constant.SUCCESS, new Gson().fromJson(result, Map.class), null, response);

		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"Unable to list role", "Unable to list role ");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			PALogger.ERROR(e);	
		}
	}

	private void  mDelete(String authToken,String id, String labels, boolean isRole) {
		try {
			// CHECK AUTH TOKEN...
			AuthorizationsVO authvo = new GrpcAuthHelper().getAuthorizationsVO(authToken);
			
			if(authvo.getRole()!=RoleEnum.Admin)
				throw new Exception(Constant.NOTPERMITTED);
			
		
			Map<Object, Object> labelMap =new HashMap<>();
			if(!StringFunctions.isNullOrWhitespace(labels))
				labelMap.put("label", labels);
			
			String action =id+ "/" ;
			if(isRole)
				action = "rolelabel";
			else
				action =  "permissionlabel";
			
			
			String result = Client.callServer(Constants.AUTH_SERVER_IP_PORT,Constants.AUTH_SERVICE_NAME,"permissions", "DELETE", action,labelMap, null, Constant.BEARER + authToken);
			ReturnObject.createResponse(Constant.SUCCESS, new Gson().fromJson(result, Map.class), null, response);

		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"Unable to delete label ", "Unable to delete label");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			PALogger.ERROR(e);	
		}
	}


	
}
