/** 
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com) 
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL 
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC. 
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD 
 * IN STRICTEST CONFIDENCE. 
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */ 

package com.mwp.p.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import javax.validation.ValidationException;
import javax.validation.constraints.NotNull;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.mwp.common.AllowSSL;
import com.mwp.common.Client;
import com.mwp.common.ReturnObject;
import com.mwp.common.StringFunctions;
import com.mwp.common.constant.Constant;
import com.mwp.common.constant.PermissionResourceKeys;
import com.mwp.common.constant.PermissionResources;
import com.mwp.common.enums.RoleEnum;
import com.mwp.common.vo.ApplicationVO;
import com.mwp.common.vo.AuthorizationsVO;
import com.mwp.common.vo.CodeVO;
import com.mwp.common.vo.DeviceVO;
import com.mwp.common.vo.ErrorVo;
import com.mwp.common.vo.GroupsVO;
import com.mwp.common.vo.VersionVO;
import com.mwp.logger.PALogger;
import com.mwp.p.authhelper.GrpcAuthHelper;
import com.mwp.p.common.AdminPermissionCheck;
import com.mwp.p.common.Constants;
import com.mwp.p.framework.Applications;
import com.mwp.p.framework.DeveloperApplications;
import com.mwp.p.framework.Devices;
import com.mwp.p.framework.Groups;
import com.sun.research.ws.wadl.HTTPMethods;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/** <h1>GroupsEndpoint</h1>
 * Class hosted at the URI path "/groups"
 * <p>
 * Class manage group, return list group, list members,
 * list of group application, add application in group,
 * give details of group and manage create/update/delete group info.
 * </p>
 * @author akh
 * @version 0.0.1
 * @since   2016-08-30 
 */

//description = "Class manage group, return list group, list members,list of group application, add application in group,give details of group and manage create/update/delete group info." 
@Path("/groups")
@Api( value = "/groups")
public class GroupsEndpoint {

	@Context
	private HttpServletResponse response;

	/**
	 * Method processing HTTP GET requests, producing "application/json" MIME media-type.
	 * 
	 * <p> 
	 * This method return List of group. 
	 * </p>  
	 * @param httpHeaders
	 * @return
	 */
	@GET
	@Consumes("application/json")
	@Produces("application/json")
	@ApiOperation( value = "List of group.", 
	notes = "List of group.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to list group." )			 
	} )
	public void listGroup(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken){
		mListGroup(authToken);
	}
	
	@GET
	@Consumes("application/json")
	@Produces("application/json")
	@Path("/listwithpermissions")
	@ApiOperation( value = "List of group.", 
	notes = "List of group.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to list group." ),		
	} )
	
	public void listGroupWithPermissions(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,
			@ApiParam(value = "label", required = false) @QueryParam("label") String label) {
		mListGroupWithPermissions(authToken, label);
	}

	
	@GET
	@Consumes("application/json")
	@Produces("application/json")
	@Path("/listinvitedgroups")
	@ApiOperation( value = "List of invited group.", 
	notes = "List of invited group.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to list group." ),		
	} )
	
	public void listInvitedGroupWithPermissions(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,
			@ApiParam(value = "label", required = false) @QueryParam("label") String label) {
		mListInvitedGroupWithPermissions(authToken, label);
	}
	/**
	 * Method processing HTTP GET requests, producing "application/json" MIME media-type.
	 * 
	 * <p> 
	 * This method return details of group. 
	 * </p>  
	 * @param groupId a unique id of group.
	 * @param httpHeaders
	 * @return
	 */
	@GET
	@Consumes("application/json")
	@Produces("application/json")
	@Path("/{id}")
	@ApiOperation( value = "details of group.", 
	notes = "details of group.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to get group detail." )			 
	} )
	public void getGroupDetail(@ApiParam( value = "group id.", required = true ) @PathParam("id") @NotNull String groupId,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken)throws ValidationException{
		mGetGroupDetail(authToken, groupId);
	}

	/**
	 * Method processing HTTP GET requests, producing "application/json" MIME media-type.
	 * 
	 * <p> 
	 * This method return list member of group. 
	 * </p>  
	 * @param groupId a unique id of group.
	 * @param httpHeaders
	 * @return
	 */
	@GET
	@Consumes("application/json")
	@Produces("application/json")
	@Path("/{id}/members")
	@ApiOperation( value = "list member of group.", 
	notes = "list member of group.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to list group member." )			 
	} )
	public void listMember(@ApiParam( value = "group id.", required = true ) @PathParam("id")@NotNull String groupId,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken)throws ValidationException {
		mListMember(authToken, groupId);
	}

	/**
	 * Method processing HTTP GET requests, producing "application/json" MIME media-type.
	 * 
	 * <p> 
	 * This method return list application of group. 
	 * </p>  
	 * @param groupId a unique id of group.
	 * @param httpHeaders
	 * @return
	 */
	@GET
	@Consumes("application/json")
	@Produces("application/json")
	@Path("/{id}/apps")
	@ApiOperation( value = "list application of group.", 
	notes = "list application of group.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to list group applications." )			 
	} )
	public void listGroupApp(@ApiParam( value = "group id.", required = true ) @PathParam("id") @NotNull String groupId,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken)throws ValidationException{
		mListGroupApp(authToken, groupId);
	}

	
	/**
	 * Method processing HTTP GET requests, producing "application/json" MIME media-type.
	 * 
	 * <p> 
	 * This method return list devices of group. 
	 * </p>  
	 * @param groupId a unique id of group.
	 * @param httpHeaders
	 * @return
	 */
	@GET
	@Consumes("application/json")
	@Produces("application/json")
	@Path("/{id}/edgecore")
	@ApiOperation( value = "list device of group.", 
	notes = "list device of group.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to list group applications." )			 
	} )
	public void listGroupEdgeCores(@ApiParam( value = "group id.", required = true ) @PathParam("id") @NotNull String groupId,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken)throws ValidationException{
		mListGroupDevices(authToken, groupId);
	}

	/**
	 * 
	 * @param groupId
	 * @param applicationId
	 * @return
	 */
	@GET
	@Produces({ MediaType.APPLICATION_JSON })
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/{id}/listgroupcode")
	@ApiOperation( value = "Find group Code by application user id and group id.", notes = "Find group Code by application user id and group id.")
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Request requires HTTP authentication" ),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to list group code" )
	} )
	public void listGroupCode(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,
			@ApiParam( value = "Group Id", required = true ) @PathParam( "id" ) @NotNull  String groupId )throws ValidationException{
		mListGroupCode(authToken,groupId);
	}

	/**
	 * List pending members of group by group id.
	 * @param groupId
	 * @param authToken
	 */
	@GET
	@Produces({ MediaType.APPLICATION_JSON })
	@Path("{groupid}/pendingmember")
	@ApiOperation( value = "List pending members of group by group id.", notes = "List pending members of group by group id.")
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED , message = "Request requires HTTP authentication" ),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to get List pending members of group.")
	} )
	public void getPendingGroupMembers(@ApiParam( value = "Group Id", required = true ) @PathParam( "groupid" ) String groupId,
			@ApiParam(value = "Authorization token", required = true) @HeaderParam("Authorization") String authToken) {
		mGetPendingGroupMembers(authToken, groupId);
	}

	/** Method processing HTTP POST requests, producing "application/json" MIME media type.
	 * <p>
	 * This method create group application.
	 * <p>
	 * @param groupVO object details of group
	 * @param httpHeaders 
	 * @return Json string
	 * @throws Exception 
	 */
	@POST
	@Consumes("application/json")
	@Produces("application/json")
	@ApiOperation( value = "create group application.", 
	notes = "create group application.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED , message = Constant.NOTPERMITTED ),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to create group.")
	} )
	public void createGroup(@ApiParam(value = "GroupVO class object.", required = true)  @Valid @NotNull GroupsVO groupVO,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken) throws ValidationException{
		GroupCommon grp = new GroupCommon();
		grp.mCreateGroup(authToken, groupVO,false,response);
	}

	@POST
	@Produces({ MediaType.APPLICATION_JSON })
	@Path("/email/{email}")
	@ApiOperation( value = "Verify code with ", notes = "Find application user by e-mail and send temp token on that e-mail id.")
	@ApiResponses
	( {
		@ApiResponse( code = HttpServletResponse.SC_NO_CONTENT, message = "Invalid data." ),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to verify code." ),
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED , message = Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION )
	} )
	public void verifyCode(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,
			@ApiParam( value = "Your email id from which user going to verify.", required = false ) @PathParam("email") @NotNull String email,
			@ApiParam( value = "Code is String which is given by owner/admin.", required = true ) @FormParam("code") @NotNull String code) throws ValidationException
	{
		mVerifyCode(authToken,email,code);

	}

	/** Method processing HTTP POST requests, producing "application/json" MIME media type.
	 * <p>
	 * This method add application detail to group.
	 * <p>
	 * @param groupId a unique id of group.
	 * @param appId a unique id of application.
	 * @param versionIds , list of versionIds.
	 * @param httpHeaders
	 * @return Json string
	 * @throws Exception 
	 */
	@POST
	@Consumes("application/json")
	@Produces("application/json")
	@Path("/{id}/apps/{appid}")
	@ApiOperation( value = "add application to group.", 
	notes = "add application to group.")
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = Constant.NOTPERMITTED ),
		@ApiResponse( code = HttpServletResponse.SC_NOT_FOUND, message = "Application not found." ),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message =  "Unable to add application from group.")		 
	} )
	public void addAppToGroup(@ApiParam( value = "group id.", required = true ) @PathParam("id") @NotNull String groupId,
			@ApiParam( value = "app id.", required = true ) @PathParam("appid") @NotNull String appId,
			@ApiParam( value = "version id's of application.", required = false )  List<String> versionIds,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken) throws ValidationException{
		mAddAppToGroup(authToken,appId,groupId,versionIds);		
	}
	
	/** Method processing HTTP POST requests, producing "application/json" MIME media type.
	 * <p>
	 * This method add Appliance  to group.
	 * <p>
	 * @param groupId a unique id of group.
	 * @param deviceId a unique id of device.
	 * @param httpHeaders
	 * @return Json string
	 * @throws Exception 
	 */
	@POST
	@Consumes("application/json")
	@Produces("application/json")
	@Path("/{id}/edgecore")
	@ApiOperation( value = "add devices to group.", 
	notes = "add devices to group.")
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = Constant.NOTPERMITTED ),
		@ApiResponse( code = HttpServletResponse.SC_NOT_FOUND, message = "Device not found." ),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message =  "Unable to add device to group.")		 
	} )
	public void addDevicesToGroup(@ApiParam( value = "group id.", required = true ) @PathParam("id") @NotNull String groupId,
			@ApiParam( value = "device id.", required = true )  List<String> deviceIds,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken) throws ValidationException{
		mAddDevicesToGroup(authToken,deviceIds,groupId);		
	}

	/** Method processing HTTP POST requests, producing "application/json" MIME media type.
	 * <p>
	 * This method invite member on group.
	 * <p>
	 * @param groupId a unique id of group.
	 * @param emails list of comma separated email's.
	 * @param httpHeaders
	 * @return Json string
	 * @throws Exception 
	 */
	@POST
	@Produces({ MediaType.APPLICATION_JSON })
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/code")
	@ApiOperation( value = "invite member on group.", 
	notes = "invite member on group.", 
	response = String.class, responseContainer = "String")
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to invite member." )	 
	} )
	public void invite(@ApiParam(value = "Code object", required = true)  @Valid @NotNull CodeVO codeVo,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken) throws ValidationException{
		GroupCommon grp = new GroupCommon();
		grp.mInvite(authToken, codeVo,false,response);

	}

	/** Method processing HTTP PUT requests, producing "application/json" MIME media type.
	 * <p>
	 * This method remove application detail from group.
	 * <p>
	 * @param groupId a unique id of group.
	 * @param appId a unique id of application.
	 * @param versionIds Optional parameter, list of comma separated application version.
	 * @param httpHeaders
	 * @return Json string
	 * @throws Exception 
	 */
	@PUT
	@Consumes("application/json")
	@Produces("application/json")
	@Path("/{id}/apps/{appid}")
	@ApiOperation( value = "remove application to group.", 
	notes = "remove application to group." 
			)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = Constant.NOTPERMITTED),
		@ApiResponse( code = HttpServletResponse.SC_NOT_FOUND, message = "Application not found."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to remove appliocation from group." )	 
	} )
	public void removeAppFromGroup(@ApiParam( value = "group id.", required = true ) @PathParam("id") @NotNull String groupId,
			@ApiParam( value = "application id.", required = true ) @PathParam("appid") String appId,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken)throws ValidationException {
		mRemoveAppFromGroup(authToken, appId, groupId);

	}
	
	
	/** Method processing HTTP PUT requests, producing "application/json" MIME media type.
	 * <p>
	 * This method remove device  from group.
	 * <p>
	 * @param groupId a unique id of group.
	 * @param deviceId a unique id of device.
	 * @param httpHeaders
	 * @return Json string
	 * @throws Exception 
	 */
	@PUT
	@Consumes("application/json")
	@Produces("application/json")
	@Path("/{id}/edgecore/{deviceid}")
	@ApiOperation( value = "remove device from group.", 
	notes = "remove device from group." 
			)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = Constant.NOTPERMITTED),
		@ApiResponse( code = HttpServletResponse.SC_NOT_FOUND, message = "Device not found."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to remove device from group." )	 
	} )
	public void removeEdgeCoreFromGroup(@ApiParam( value = "group id.", required = true ) @PathParam("id") @NotNull String groupId,
			@ApiParam( value = "device id.", required = true ) @PathParam("deviceid") String deviceid,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken)throws ValidationException {
		mRemoveEdgeCoreFromGroup(authToken, deviceid, groupId);

	}

	/**
	 * 
	 * @param codeVo
	 */
	@PUT
	@Produces({ MediaType.APPLICATION_JSON })
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/{id}/code")
	@ApiOperation( value = "Edit code", notes = "Edit code")
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION ),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to update code.")
	} )
	public void editCode(@ApiParam( value = "group id.", required = true ) @PathParam("id") String groupId,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,
			@ApiParam(value = "Code object", required = true)  @NotNull @Valid CodeVO codeVo)throws ValidationException{
		GroupCommon grp = new GroupCommon();
		grp.mEditCode(authToken, codeVo,false,response);
	}

	/** Method processing HTTP PUT requests, producing "application/json" MIME media type.
	 * <p>
	 * This method update group information.
	 * <p>
	 * @param groupVO object details of group
	 * @param httpHeaders 
	 * @return Json string
	 * @throws Exception 
	 */
	@PUT
	@Consumes("application/json")
	@Produces("application/json")
	@Path("/{id}")
	@ApiOperation( value = "update group application.", 
	notes = "update group application.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to update group.")			 
	} )
	public void editGroup(@ApiParam( value = "group id.", required = true ) @PathParam("id")  @ NotNull String groupId,
			@ApiParam(value = "GroupVO class object.", required = true) @NotNull @Valid GroupsVO groupVO,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken) throws ValidationException {
		GroupCommon grp = new GroupCommon();
		grp.mEditGroup(authToken, groupVO,false,response);
	}


	/** Method processing HTTP PUT requests, producing "application/json" MIME media type.
	 * <p>
	 * This method update group application versions.
	 * <p>
	 * @param groupId unique id of group.
	 * @param appId   unique id of group application.
	 * @param versionIdsWithOperation mapping of versionIds and action on 
	 * @param authToken
	 */

	@PUT
	@Consumes("application/json")
	@Produces("application/json")
	@Path("/{id}/apps/{appid}/versions")
	@ApiOperation( value = "update group application versions.", 
	notes = "update group application versions." 
			)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION),
		@ApiResponse( code = HttpServletResponse.SC_NOT_FOUND, message = "Application not found."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to update group appliocation version.")	 
	} )
	public void updateGroupAppVersion(@ApiParam( value = "group id.", required = true ) @NotNull @PathParam("id") String groupId,
			@ApiParam( value = "application id.", required = true ) @PathParam("appid") String appId,
			@ApiParam( value = "versionIds mapping", required = true ) Map<String,Boolean> versionIdsWithOperation,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken) {
		mUpdateGroupAppVersion(authToken, appId, groupId,versionIdsWithOperation);

	}

	/** Method processing HTTP DELETE requests, producing "application/json" MIME media type.
	 * <p>
	 * This method delete group info from db.
	 * <p>
	 * @param groupId a unique id of group.
	 * @param httpHeaders
	 * @return
	 * @throws Exception 
	 */
	@DELETE
	@Consumes("application/json")
	@Produces("application/json")
	@Path("/{id}")
	@ApiOperation( value = "delete group detail.", 
	notes = "delete group info from db.")
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to delete group.")			 
	} )
	public void deleteGroup(@ApiParam( value = "group id.", required = true ) @PathParam("id") @NotNull String groupId,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,
			@ApiParam(value = "filter", required = false) @QueryParam("filter") String filter) throws ValidationException {
		//	 
		GroupCommon grp = new GroupCommon();
		grp.mDeleteGroup(authToken, groupId,false,filter,response);
	}

	/**
	 * This method for delete code.
	 * @param codeId
	 * @return
	 */
	@DELETE
	@Produces({ MediaType.APPLICATION_JSON })
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/code/{codeId}")
	@ApiOperation( value = "Delete code", notes = "Delete code")
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION ),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to delete code.")
	} )
	public void deleteCode(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,
			@ApiParam( value = "Code Id", required = true ) @NotNull @PathParam( "codeId" ) final String codeId)throws ValidationException{
		GroupCommon grp = new GroupCommon();
		grp.mDeleteCode(authToken,codeId,false,response);
	}

	/** Method processing HTTP PUT requests, producing "application/json" MIME media type.
	 * <p>
	 * This method remove member/user from group.
	 * <p>
	 * @param groupId a unique id of group.
	 * @param userId a unique id of member.
	 * @param httpHeaders
	 * @return Json string
	 * @throws Exception 
	 */
	@DELETE
	@Consumes("application/json")
	@Produces("application/json")
	@Path("/{id}/members/{userid}")
	@ApiOperation( value = "remove member from group.", 
	notes = "remove member from group.", 
	response = String.class, responseContainer = "String")
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to remove member from group." )	 
	} )
	public void removeMemberFromGroup(@ApiParam( value = "group id.", required = true ) @NotNull @PathParam("id") String groupId,
			@ApiParam( value = "user id.", required = true ) @NotNull @PathParam("userid") String userId,
			@ApiParam( value = "group id.", required = true )  Map<String, Boolean> appIds,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken) throws ValidationException{
		GroupCommon grp = new GroupCommon();
		grp.mRemoveMemberFromGroup(authToken,groupId,userId,false,response);

	}

	@GET
	@Consumes({MediaType.APPLICATION_JSON})
	@Path("/{groupid}/app/{appid}/versions")
	@ApiOperation( value = "List of invited application", 
	notes = "List of invited application.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to get application detail.")			 
	} )
	public void getInvitedVersionsOfApp(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,
			@ApiParam(value = "id of application.", required = true)@NotNull @PathParam("appid") String appId,
			@ApiParam(value = "id of group.", required = true)@NotNull @PathParam("groupid") String groupId){
		mGetInvitedVersionsOfApp(authToken, appId, groupId);
	}

	private void mGetInvitedVersionsOfApp(String authToken, String appId, String groupId) {
		try {
			// CHECK AUTH TOKEN...
			String userId=new GrpcAuthHelper().checkAuthorization(authToken);
			DeveloperApplications developerApplications =new DeveloperApplications();
			
			Applications applications=new Applications();
			String appOwnerId = applications.getUserIdOfApp(appId);
			boolean isowner= appOwnerId.equals(userId);
			
			List<VersionVO> versionVOs = developerApplications.getInvitedVersionsOfGroup(appId, groupId, null);

			if(versionVOs == null)
			{
				//it means invitation not found
				if(isowner)
				{
					ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_NOT_FOUND , "Application not found in group.", "Application not found in group.");
					ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
				}
				else
				{
					ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_NOT_FOUND , "Invitation not found", "Application invitation doesn't exists.");
					ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
				}
			}
			else
			{
				if(versionVOs.isEmpty() && !isowner)
				{
					ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_NOT_FOUND , "No versions found.", "No versions found.");
					ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
				}
				else
				{
					boolean isAllVersionInvited = developerApplications.isAllVersionsInvited(appId, groupId);

					Map<String, Object> data = new HashMap<>();
					data.put("Versions", versionVOs);
					data.put("isAllVersionsInvited", isAllVersionInvited);

					Map<String, Object> resultMap = new HashMap<>();
					resultMap.put(Constant.DATA, data);
					ReturnObject.createResponse(Constant.SUCCESS, resultMap, null,response);
				}
			}
		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"Unable to get application detail", "Unable to get application detail");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			PALogger.ERROR(e);	
		}
	}






	private void mListGroup(String authToken) {
		try {
			// CHECK AUTH TOKEN...
			new GrpcAuthHelper().checkAuthorization(authToken);
			// Add auth token for authorizing.
			String result = Client.callServer(Constants.AUTH_SERVER_IP_PORT,Constants.AUTH_SERVICE_NAME, "group",  HTTPMethods.GET.name(), "", null, null, Constant.BEARER + authToken);
			ReturnObject.createResponse(Constant.SUCCESS, new Gson().fromJson(result, Map.class), null, response);

		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"Unable to list group", "Unable to list group");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			PALogger.ERROR(e);	
		}
	}
	
	private void mListInvitedGroupWithPermissions(String authToken, String label) {
		try {
			// CHECK AUTH TOKEN...
			new GrpcAuthHelper().checkAuthorization(authToken);
			Map<Object, Object> labelMap =new HashMap<>();
			if(!StringFunctions.isNullOrWhitespace(label))
			labelMap.put("label", label);
			// Add auth token for authorizing.
			String result = Client.callServer(Constants.AUTH_SERVER_IP_PORT,Constants.AUTH_SERVICE_NAME, "group",  HTTPMethods.GET.name(), "listinvitedgroups", labelMap, null, Constant.BEARER + authToken);
			ReturnObject.createResponse(Constant.SUCCESS, new Gson().fromJson(result, Map.class), null, response);
		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"Unable to list group", "Unable to list group");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			PALogger.ERROR(e);	
		}
	}
	
	private void mListGroupWithPermissions(String authToken, String label) {
		try {
			// CHECK AUTH TOKEN...
			AuthorizationsVO authvo = new GrpcAuthHelper().getAuthorizationsVO(authToken);
			if(authvo.getRole()!= RoleEnum.Admin)
			{
				List<String> lstPermissions = new ArrayList<>();
				Map<String, String> labelmap  = null;
				String key ="";
				String value = "";
				if(!StringFunctions.isNullOrWhitespace(label))
				{
					labelmap  = new Gson().fromJson(label,new TypeToken<Map<String, String>>() {}.getType());
					if(labelmap.containsKey("labelKey")) 
						key = labelmap.get("labelKey");
					if(labelmap.containsKey("labelValue"))
						value= labelmap.get("labelValue");
					
					if(value.equals(PermissionResources.getString(PermissionResourceKeys.ROLE_LABEL_VALUE_APP)))
						lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_PROJECTS));
					else if(value.equals(PermissionResources.getString(PermissionResourceKeys.ROLE_LABEL_VALUE_APPLIANCE)))
						lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_APPLIANCES));
					else
						throw new Exception(Constant.NOTPERMITTED);	
				}
				
			}
			
			Map<Object, Object> labelMap =new HashMap<>();
			if(!StringFunctions.isNullOrWhitespace(label))
			labelMap.put("label", label);
			
			// Add auth token for authorizing.
			String result = Client.callServer(Constants.AUTH_SERVER_IP_PORT,Constants.AUTH_SERVICE_NAME, "group",  HTTPMethods.GET.name(), "listwithpermissions", labelMap, null, Constant.BEARER + authToken);
			ReturnObject.createResponse(Constant.SUCCESS, new Gson().fromJson(result, Map.class), null, response);

		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"Unable to list group", "Unable to list group");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			PALogger.ERROR(e);	
		}
	}

	private void mGetGroupDetail(String authToken, String groupId) {
		try {
			// CHECK AUTH TOKEN...
			AuthorizationsVO authvo = new GrpcAuthHelper().getAuthorizationsVO(authToken);
			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_APPLIANCES));
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_PROJECTS));
			AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, false);
			
			// Add auth token for authorizing.
			String result = Client.callServer(Constants.AUTH_SERVER_IP_PORT,Constants.AUTH_SERVICE_NAME, "group",  HTTPMethods.GET.name(), groupId, null, null, Constant.BEARER + authToken);
			ReturnObject.createResponse(Constant.SUCCESS, new Gson().fromJson(result, Map.class), null, response);

		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"Unable to get group detail", "Unable to get group detail");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			PALogger.ERROR(e);	
		}
	}

	private void mListMember(String authToken, String groupId) {
		try {
			// CHECK AUTH TOKEN...
			AuthorizationsVO authvo = new GrpcAuthHelper().getAuthorizationsVO(authToken);
			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_APPLIANCES));
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_PROJECTS));
			AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, false);
			
			// Add auth token for authorizing.
			String result = Client.callServer(Constants.AUTH_SERVER_IP_PORT,Constants.AUTH_SERVICE_NAME, "group",  HTTPMethods.GET.name(), groupId+"/members", null, null, Constant.BEARER + authToken);
			ReturnObject.createResponse(Constant.SUCCESS, new Gson().fromJson(result, Map.class), null, response);

		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"Unable to list group member", "Unable to list group member");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			PALogger.ERROR(e);	
		}
	}

	private void mListGroupApp(String authToken, String groupId) {
		try {
			// CHECK AUTH TOKEN...
			AuthorizationsVO authvo = new GrpcAuthHelper().getAuthorizationsVO(authToken);
			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_PROJECTS));
			AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, true);
			
			Groups groups=new Groups();
			List<ApplicationVO> applicationVOs=groups.listGroupApp(groupId);
			Map<String, Object> resultMap=new HashMap<>();
			resultMap.put(Constant.DATA, applicationVOs);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);

		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"Unable to list group applications", "Unable to list group applications");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			PALogger.ERROR(e);	
		}
	}

	private void mAddAppToGroup(String authToken, String appId, String groupId, List<String> versionIds) {
		try {
			//CHECK AUTH TOKEN...
			// Execute that operation if user is owner of that group.AuthorizationsVO authvo = new AuthHelper().getAuthorizationsVO(authToken);
			AuthorizationsVO authvo = new GrpcAuthHelper().getAuthorizationsVO(authToken);
			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_PROJECTS));
			AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, true);
			
			
			String userId=authvo.getUserId();
			String result = Client.callServer(Constants.AUTH_SERVER_IP_PORT,Constants.AUTH_SERVICE_NAME, "group",  HTTPMethods.GET.name(), groupId, null, null, Constant.BEARER + authToken);
			GroupsVO groupsVo= Client.parseResult(result, GroupsVO.class);
			// App Owner same as group owner 
			Applications applications=new Applications();
			//AKH_01_1
			String appOwnerId = applications.getUserIdOfApp(appId);

			if (appOwnerId != null) {
				if (groupsVo != null && groupsVo.getAppUserId().equals(userId) && appOwnerId.equals(userId)) {
					Groups groups = new Groups();
					groups.addAppToGroup(appId, groupId, versionIds);
					Map<String, Object> resultMap = new HashMap<>();
					resultMap.put(Constant.DATA, groups.listGroupApp(groupId));
					ReturnObject.createResponse(Constant.SUCCESS, resultMap,
							null, response);
				} else {
					throw new Exception(Constant.NOTPERMITTED);
				}
			}
			else{
				//if Application not found for given application Id then throw NOTFOUND exception. 
				throw new Exception(Constant.NOTFOUND); 
			}
		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTFOUND))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_NOT_FOUND,
						"Application not found", "No application found with requested app ID");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"Unable to add application from group", "Unable to add application from group");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			PALogger.ERROR(e);	
		}
	}

	private void mRemoveAppFromGroup(String authToken, String appId, String groupId) {
		try {
			// Execute that operation if user is owner of that group.
			AuthorizationsVO authvo = new GrpcAuthHelper().getAuthorizationsVO(authToken);
			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_PROJECTS));
			AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, true);
			
			String userId=authvo.getUserId();
			String result = Client.callServer(Constants.AUTH_SERVER_IP_PORT,Constants.AUTH_SERVICE_NAME, "group",  HTTPMethods.GET.name(), groupId, null, null, Constant.BEARER + authToken);
			GroupsVO groupsVo = Client.parseResult(result, GroupsVO.class);

			// App Owner same as group owner 
			Applications applications=new Applications();
			//AKH_01_1
			String appOwnerId = applications.getUserIdOfApp(appId);

			if (!StringFunctions.isNullOrWhitespace(appOwnerId)) {
				if (groupsVo != null && groupsVo.getAppUserId().equals(userId) && appOwnerId.equals(userId)) {
					Groups groups = new Groups();
					groups.removeAppToGroup(appId, groupId);
					Map<String, Object> resultMap = new HashMap<>();
					resultMap.put(Constant.DATA, groupId);
					ReturnObject.createResponse(Constant.SUCCESS, resultMap,
							null, response);
				} else {
					throw new Exception(Constant.NOTPERMITTED);
				}
			}
			else
			{
				//if Application not found for given application Id then throw NOTFOUND exception. 
				throw new Exception(Constant.NOTFOUND);
			}

		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTFOUND)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_NOT_FOUND , "Application not found", "No application found with requested application Id");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"Unable to remove appliocation from group", "Unable to remove appliocation from group");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			PALogger.ERROR(e);	
		}
	}
	
	private void mRemoveEdgeCoreFromGroup(String authToken, String deviceId, String groupId) {
		try {
			// Execute that operation if user is owner of that group.
			AuthorizationsVO authvo = new GrpcAuthHelper().getAuthorizationsVO(authToken);
			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_APPLIANCES));
			AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, true);
			
			String userId=authvo.getUserId();
			String result = Client.callServer(Constants.AUTH_SERVER_IP_PORT,Constants.AUTH_SERVICE_NAME, "group",  HTTPMethods.GET.name(), groupId, null, null, Constant.BEARER + authToken);
			GroupsVO groupsVo = Client.parseResult(result, GroupsVO.class);

			// App Owner same as group owner 
			Devices device = new Devices();
			//AKH_01_1
			String deviceOwnerId = device.getUserId(deviceId);

			if (!StringFunctions.isNullOrWhitespace(deviceOwnerId)) {
				if (groupsVo != null && groupsVo.getAppUserId().equals(userId) && deviceOwnerId.equals(userId)) {
					Groups groups = new Groups();
					groups.removeEdgeCoreFromGroup(deviceId, groupId);
					Map<String, Object> resultMap = new HashMap<>();
					resultMap.put(Constant.DATA, groupId);
					ReturnObject.createResponse(Constant.SUCCESS, resultMap,
							null, response);
				} else {
					throw new Exception(Constant.NOTPERMITTED);
				}
			}
			else
			{
				//if device not found for given device Id then throw NOTFOUND exception. 
				throw new Exception(Constant.NOTFOUND);
			}

		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTFOUND)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_NOT_FOUND , "Device not found", "No device found with requested device id");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"Unable to remove device from group", "Unable to remove device from group");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			PALogger.ERROR(e);	
		}
	}
	


	
	private void mAddDevicesToGroup(String authToken, List<String> deviceIds, String groupId) {
		try {
			//CHECK AUTH TOKEN...
			// Execute that operation if user is owner of that group.
			AuthorizationsVO authvo = new GrpcAuthHelper().getAuthorizationsVO(authToken);
			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_APPLIANCES));
			AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, true);
			
			String userId=authvo.getUserId();
			String result = Client.callServer(Constants.AUTH_SERVER_IP_PORT,Constants.AUTH_SERVICE_NAME, "group",  HTTPMethods.GET.name(), groupId, null, null, Constant.BEARER + authToken);
			GroupsVO groupsVo= Client.parseResult(result, GroupsVO.class);
			
			if(groupsVo != null && groupsVo.getAppUserId().equals(userId))
			{
				// Device Owner same as group owner 
				Devices devices=new Devices();
				boolean isSameOwner = devices.isSameOwnerDevice(deviceIds, userId);
				if (isSameOwner) 
				{
					Groups groups = new Groups();
					for (String deviceId : deviceIds) 
					{
						groups.addEdgeCoreToGroup(deviceId, groupId);
					}
				
					Map<String, Object> resultMap = new HashMap<>();
					resultMap.put(Constant.DATA, groups.listGroupEdgeCore(groupId));
					ReturnObject.createResponse(Constant.SUCCESS, resultMap,
							null, response);
				} 
				else {
					throw new Exception(Constant.NOTPERMITTED);
				}
			}
			else
			{
				throw new Exception(Constant.NOTPERMITTED);
			}

		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTFOUND))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_NOT_FOUND,
						"Device not found", "No device found with requested device id");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"Unable to add device to group", "Unable to add device to group");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			PALogger.ERROR(e);	
		}
	}


	private void mListGroupDevices(String authToken, String groupId)
	{
		try {
			// CHECK AUTH TOKEN...
			AuthorizationsVO authvo = new GrpcAuthHelper().getAuthorizationsVO(authToken);
			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_APPLIANCES));
			AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, true);
			
			Groups groups=new Groups();
			List<DeviceVO> lstdevice=groups.listGroupEdgeCore(groupId);
			Map<String, Object> resultMap=new HashMap<>();
			resultMap.put(Constant.DATA, lstdevice);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);

		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"Unable to list group devices", "Unable to list group devices");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			PALogger.ERROR(e);	
		}
	}
	

	private void mListGroupCode(String authToken, String groupId) {
		try {
			// CHECK AUTH TOKEN...
			AuthorizationsVO authvo = new GrpcAuthHelper().getAuthorizationsVO(authToken);
			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_PROJECTS));
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_APPLIANCES));
			AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, false);
			
			// Add Auth token for authorizing.
			String result = Client.callServer(Constants.AUTH_SERVER_IP_PORT, Constants.AUTH_SERVICE_NAME, "group", HTTPMethods.GET.name(), groupId+"/codes", null, null,  Constant.BEARER + authToken);
			ReturnObject.createResponse(Constant.SUCCESS, new Gson().fromJson(result, Map.class), null, response);

		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"Unable to list group code", "Unable to list group code");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			PALogger.ERROR(e);	
		}
	}

	private void mVerifyCode(String authToken, String email, String code) {
		//Put outside to close the client and response
		HttpResponse httpresponse = null;
		HttpPost post = null;
		try {
			// CHECK AUTH TOKEN...
			new GrpcAuthHelper().checkAuthorization(authToken);


			HttpClient httpclient = AllowSSL.getClientConnection(false);
			post = new HttpPost(Constants.AUTH_SERVER_IP_PORT + Constants.AUTH_SERVICE_NAME + "/applications/"+Constants.PORTAL_APPLICATION_ID+"/user"+"/email/"+email);

			// Setup form data
			List<NameValuePair> nameValuePairs = new ArrayList<>();
			nameValuePairs.add(new BasicNameValuePair("code", code));
			post.setEntity(new UrlEncodedFormEntity(nameValuePairs));

			post.setHeader("Authorization", authToken.contains("bearer")?authToken:(Constant.BEARER +authToken));
			// Execute request
			httpresponse = httpclient.execute(post);

			// Check response status and read data
			if (httpresponse.getStatusLine().getStatusCode() == HttpStatus.SC_OK) 
			{
				String data = EntityUtils.toString(httpresponse.getEntity());
				CodeVO codeObj= Client.parseResult(data, CodeVO.class);
				
				String result = Client.callServer(Constants.AUTH_SERVER_IP_PORT,Constants.AUTH_SERVICE_NAME, "group",  HTTPMethods.GET.name(), codeObj.getGroupId(), null, null, Constant.BEARER + authToken);
				ReturnObject.createResponse(Constant.SUCCESS, new Gson().fromJson(result, Map.class), null, response);

			}
			else if (httpresponse.getStatusLine().getStatusCode() == HttpStatus.SC_NO_CONTENT) {
				ErrorVo err = new ErrorVo(HttpServletResponse.SC_NO_CONTENT, "Invalid data", "Invalid data");
				ReturnObject.createResponse(Constant.FAILURE,null , err, response);
			}
			else
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"Invalid code", "Unable to verify code");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}

		}  
		catch (Exception e) 
		{
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"Unable to verify code ", "Unable to verify code");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
		} finally {
			//DB -Possible leak solved. Release resources acquired by request and response
			Client.releaseResponse(post, httpresponse);
		}
	}

	private void mUpdateGroupAppVersion(String authToken, String appId,
			String groupId, Map<String, Boolean> versionIdsWithOperation) {
		try {
			// CHECK AUTH TOKEN...
			// Execute that operation if user is owner of that group.
			AuthorizationsVO authvo = new GrpcAuthHelper().getAuthorizationsVO(authToken);
			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_PROJECTS));
			AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, true);
			String userId=authvo.getUserId();
			String result = Client.callServer(Constants.AUTH_SERVER_IP_PORT,Constants.AUTH_SERVICE_NAME, "group",  HTTPMethods.GET.name(), groupId, null, null, Constant.BEARER + authToken);
			GroupsVO groupsVo = Client.parseResult(result, GroupsVO.class);
			// App Owner same as group owner 
			Applications applications=new Applications();
			//AKH_01_1
			String appOwnerId = applications.getUserIdOfApp(appId);

			if (appOwnerId != null) {
				if (groupsVo != null && groupsVo.getAppUserId().equals(userId) && appOwnerId.equals(userId)) {
					Groups groups = new Groups();
					groups.updateGroupVersion(appId, groupId,
							versionIdsWithOperation);
					Map<String, Object> resultMap = new HashMap<>();
					resultMap.put(Constant.DATA, groupId);
					ReturnObject.createResponse(Constant.SUCCESS, resultMap,
							null, response);
				} else {
					throw new Exception(Constant.NOTPERMITTED);
				}

			}
			else
			{
				//if Application not found for given application Id then throw NOTFOUND exception. 
				throw new Exception(Constant.NOTFOUND);
			}

		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTFOUND)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_NOT_FOUND , "Application not found", "No application found with requested application Id");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"Unable to update group appliocation version.", "Unable to update group appliocation version.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			PALogger.ERROR(e);	
		}

	}

	/**
	 * this method list all pending members of group
	 * @param groupId
	 */
	private void mGetPendingGroupMembers(String authToken, String groupId) {
		try {
			//CHECK AUTH TOKEN...
			AuthorizationsVO authvo = new GrpcAuthHelper().getAuthorizationsVO(authToken);
			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_PROJECTS));
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_APPLIANCES));
			AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, false);
			String result = Client.callServer(Constants.AUTH_SERVER_IP_PORT,Constants.AUTH_SERVICE_NAME, "group",  HTTPMethods.GET.name(), groupId+"/pendingmember", null, null, Constant.BEARER + authToken);
			ReturnObject.createResponse(Constant.SUCCESS, new Gson().fromJson(result, Map.class), null, response);
		}
		catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to get List pending members of group.", "Unable to get List pending members of group.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
		}
	}
	
	
	

	
}

/**
 * History of check-in or issue resolved
 * 
 * 01 - 12-10-2016 
 * AKH_01_1
 * Use getUserIdOfApp instead of getAppDetail because we only require userId of application. 
 * 
 */