/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.constraints.NotNull;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import com.google.gson.Gson;
import com.mwp.common.AuthHelper;
import com.mwp.common.ReturnObject;
import com.mwp.common.StringFunctions;
import com.mwp.common.constant.Constant;
import com.mwp.common.constant.PermissionResourceKeys;
import com.mwp.common.constant.PermissionResources;
import com.mwp.common.enums.ActivityOperation;
import com.mwp.common.vo.AuthorizationsVO;
import com.mwp.common.vo.DiscoveryDetailsVO;
import com.mwp.common.vo.DiscoveryJarDetailsVO;
import com.mwp.common.vo.ErrorVo;
import com.mwp.common.vo.ValidationInfoVO;
import com.mwp.logger.PALogger;
import com.mwp.p.authhelper.GrpcAuthHelper;
import com.mwp.p.common.AdminPermissionCheck;
import com.mwp.p.dal.engine.DevicesEngine;
import com.mwp.p.framework.ActivityLogs;
import com.mwp.p.framework.Devices;
import com.mwp.p.framework.DiscoveryDetails;
import com.mwp.p.framework.DiscoveryJarDetails;
import com.mwp.p.framework.SupportRelayServer;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/** <h1>DeveloperApplicationsEndpoint</h1>
 * Class hosted at the URI path "/devapps"
 * <p>
 * Class manage application of developer, list invited application, add/update/delete application,
 * give developer application detail(list of version, version details), publish application.
 * </p>
 * @author akh
 * @version 0.0.1
 * @since   2016-08-30 
 */
//"Class manage device discovery details, relay server, discoveryJarDetails."
@Path("/discovery")
@Api( value = "/discovery",produces=MediaType.APPLICATION_JSON)
public class DeviceDiscoveryEndpoint {

	@Context
	private HttpServletResponse response;

	@Context
	private HttpServletRequest request;

	/**
	 * Method processing HTTP GET requests, producing "application/json" MIME media-type.
	 * <p> 
	 * This method return internet router ip 
	 * </p>  
	 * @param httpHeaders
	 * @return
	 */
	@GET
	@Consumes({MediaType.APPLICATION_JSON})
	@Path("/routerip")
	@ApiOperation( value = "get internet router ip", 
	notes = "get internet router ip.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_NOT_FOUND, message = "Doesn't get router ip."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to get internet router ip.")

	} )
	public void getInternetRouterIP(@Context HttpServletRequest request,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken){
		mGetInternetRouterIP(authToken, request);
	}

	/**
	 * Method processing HTTP GET requests, producing "application/json" MIME media-type.
	 * <p> 
	 * This method return internet router ip 
	 * </p>  
	 * @param httpHeaders
	 * @return
	 */
	@GET
	@Consumes({MediaType.APPLICATION_JSON})
	@Path("/{deviceId}/details")
	@ApiOperation( value = "get discovery details", 
	notes = "get discovery details.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_NOT_FOUND, message = "Doesn't get router ip."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to get discovery details.")			 
	} )
	public void getDiscoveryDetails(@Context HttpServletRequest request,
			@ApiParam(value="Device Id",required=true)@PathParam("deviceId") String deviceId,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken){
		mGetDiscoveryDetails(authToken, deviceId);
	}

	/* Method processing HTTP GET requests, producing "application/json" MIME media-type.
	 * <p> 
	 * This method return internet router ip 
	 * </p>  
	 * @param httpHeaders
	 * @return
	 */
	@GET
	@Consumes({MediaType.APPLICATION_JSON})
	@Path("/device-name/{deviceName}")
	@ApiOperation( value = "", 
	notes = "get discovery detail by name.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_BAD_REQUEST, message = "no device detail found "),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to get discovery details.")
	} )
	public void getDiscoveryDetailsByName(@Context HttpServletRequest request,
			@ApiParam(value="Device Name",required=true)@PathParam("deviceName") String deviceName,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken){
		mGetDiscoveryDetailsByName(authToken, deviceName, request);
	}

	@GET
	@Consumes({MediaType.APPLICATION_JSON})
	@Path("/devices")
	@ApiOperation( value = "get discovery jar detail", 
	notes = "get discovery jar detail.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_BAD_REQUEST, message = "no device detail found "),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to get discovery jar details.")		 
	} )
	public void getDiscoveryJarDetails(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken){
		mGetDiscoveryJarDetails(authToken);
	}

	/**
	 * Method processing HTTP GET requests, producing "application/json" MIME media-type.
	 * <p> 
	 * This method return internet router ip 
	 * </p>  
	 * @param httpHeaders
	 * @return
	 */
	@GET
	@Consumes({MediaType.APPLICATION_JSON})
	@Path("/checkuniqueid")
	@ApiOperation( value = "check unique id.", 
	notes = "check unique id.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_BAD_REQUEST, message = "no device detail found "),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to check unique id.")				 
	} )
	public void checkUniqueId(@Context HttpServletRequest request,
			@ApiParam(value="Product Id",required=true)@QueryParam("productId") String productId,
			@ApiParam(value="Host name",required=false)@QueryParam("hostName") String hostName,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken){
		mCheckUniqueId(authToken, productId,hostName);
	}

	/** Method processing HTTP POST requests, producing "application/json" MIME media type.
	 * <p>
	 * This method update discovery details with new connect ip url.
	 * <p>
	 * @param deviceDetails mapping of device detail(deviceId, deviceName, ipAddress, port, backCallerRestPath) and action on 
	 * @param authToken
	 */

	@POST
	@Consumes("application/json")
	@Produces("application/json")
	@Path("/canconnect")
	@ApiOperation( value = "to check portal alive or not.", 
	notes = "to check portal alive or not." 
			)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_NOT_FOUND, message = "device detail not found."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to connect portal.")	
	} )
	public void canConnect(@ApiParam( value = "details of device mapping", required = true ) Map<String,String> deviceDetails,
			@ApiParam(value="Authorization token",required=false)@HeaderParam("Authorization") String authToken) {
		mCanConnect(authToken, deviceDetails);

	}

	/** Method processing HTTP POST requests, producing "application/json" MIME media type.
	 * <p>
	 * This method update discovery details with new connect ip url.
	 * <p>
	 * @param deviceDetails mapping of device detail(deviceId, deviceName, ipAddress, port, backCallerRestPath) and action on 
	 * @param authToken
	 */

	//Added query param for isActive bit.
	@POST
	@Consumes("application/json")
	@Produces("application/json")
	@Path("/updateheartbeat")
	@ApiOperation( value = "update device heartbeat by device Id.", 
	notes = "update device heartbeat by device Id." 
			)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_NOT_FOUND, message = "device detail not found."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to update discovery details with new connect ip url.")	
	} )
	public void updateDeviceHeartbeat(@ApiParam( value = "details of device mapping", required = true ) String deviceId,
			@ApiParam(value="is Active master ",required=true)@QueryParam("isActive") Boolean isActive,
			@ApiParam(value="Authorization token",required=false)@HeaderParam("Authorization") String authToken) {
		mUpdateDeviceHeartbeat(authToken, deviceId, isActive);

	}

	/** Method processing HTTP POST requests, producing "application/json" MIME media type.
	 * <p>
	 * This method update discovery details with new connect ip url.
	 * <p>
	 * @param deviceDetails mapping of device detail(deviceId, deviceName, ipAddress, port, backCallerRestPath) and action on 
	 * @param authToken
	 */

	@POST
	@Consumes("application/json")
	@Produces("application/json")
	@Path("/updateheartbeatinactive")
	@ApiOperation( value = "update inactive device heartbeat by device Id.", 
	notes = "update inactive device heartbeat by device Id." 
			)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_NOT_FOUND, message = "device detail not found."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to update inactive device heartbeat by device Id.")		 
	} )
	public void updateInactiveDeviceHeartbeat(@ApiParam( value = "details of device mapping", required = true ) String productId,
			@ApiParam(value="Authorization token",required=false)@HeaderParam("Authorization") String authToken) {
		mUpdateInactiveDeviceHeartbeat(authToken, productId);

	}

	/** Method processing HTTP POST requests, producing "application/json" MIME media type.
	 * <p>
	 * This method update discovery detail- connectURL, networkType and other details.
	 * <p>
	 * @param deviceDetails mapping of device detail(deviceId, deviceName, ipAddress, port, backCallerRestPath) and action on 
	 * @param authToken
	 */

	@POST
	@Consumes("application/json")
	@Produces("application/json")
	@Path("/setconnecturl")
	@ApiOperation( value = "update discovery detail.", 
	notes = "update discovery detail." 
			)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_NOT_FOUND, message = "set connect url failed."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to update discovery detail.")	
	} )
	public void setConnectURL(@ApiParam( value = "DiscoveryDetailsVO object", required = true )@NotNull DiscoveryDetailsVO discoveryDetails,
			@ApiParam(value="Authorization token",required=false)@HeaderParam("Authorization") String authToken) {
		mSetConnectURL(authToken, discoveryDetails);
	}

	/** Method processing HTTP POST requests, producing "application/json" MIME media type.
	 * <p>
	 * This method update group application versions.
	 * <p>
	 * @param deviceDetails mapping of device detail(deviceId, deviceName, ipAddress, port, backCallerRestPath) and action on 
	 * @param authToken
	 */

	@POST
	@Consumes("application/json")
	@Produces("application/json")
	@Path("/checkurlaccessible")
	@ApiOperation( value = "check url connected/accessible from internet.", 
	notes = "check url connected/accessible from internet." 
			)
	@ApiResponses( {
	} )
	public void checkIfURLAccessibleFromInternet(@ApiParam( value = "deviceDetails(IPAddress, port, deviceId, backCallerRestPath)", required = true )Map<String,String> deviceDetails,
			@ApiParam(value="Authorization token",required=false)@HeaderParam("Authorization") String authToken) {
		mCheckIfURLAccessibleFromInternet(authToken, deviceDetails);
	}

	/** Method processing HTTP POST requests, producing "application/json" MIME media type.
	 * <p>
	 * This method add details in discoveryDetails db.
	 * <p>
	 * @param detailsVO DiscoverJarDetailsVO object.
	 * @param validInfo ValidationInfoVO object.
	 * @param authToken
	 */
	@POST
	@Consumes("application/json")
	@Produces("application/json")
	@Path("/publish")
	@ApiOperation( value = "add details in discoveryDetails db.", 
	notes = "add details in discoveryDetails db." 
			)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_NOT_FOUND, message = "publish discover failed."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to publish discovery detail.")	
	} )
	public void publishDiscoveryDetails(@ApiParam( value = "Discovery Jar Details", required = true ) Map<String,Object> deviceDetails, 
			@ApiParam(value="Authorization token",required=false)@HeaderParam("Authorization") String authToken) {
		mPublishDiscoveryDetails(authToken, deviceDetails);
	}

	/** Method processing HTTP POST requests, producing "application/json" MIME media type.
	 * <p>
	 * This method update group application versions.
	 * <p>
	 * @param deviceDetails mapping of device detail(deviceId, deviceName, ipAddress, port, backCallerRestPath) and action on 
	 * @param authToken
	 */
	@POST
	@Consumes("application/json")
	@Produces("application/json")
	@Path("/setuprelaydetails")
	@ApiOperation( value = "if relayserver alive then add device info in DiscoveryDetails else add in RelayServer db.", 
	notes = "add in discoveryDetails or relayServer db." 
			)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_NOT_FOUND, message = "setup relay discovery details failed.."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to setup relay discovery details.")
	} )
	public void setupRelayDiscoveryDetails(@ApiParam( value = "Discovery Jar Details", required = true ) Map<String,Object> deviceDetails,
			@ApiParam(value="Authorization token",required=false)@HeaderParam("Authorization") String authToken) {
		mSetupRelayDiscoveryDetails(authToken, deviceDetails);
	}

	/** Method processing HTTP POST requests, producing "application/json" MIME media type.
	 * <p>
	 * This method add device details in discoverJarDetails db.
	 * <p>
	 * @param detailsVO DiscoveryJarDetailsVO object.
	 * @param validInfo ValidationInfoVO object. 
	 * @param authToken
	 */
	@POST
	@Consumes("application/json")
	@Produces("application/json")
	@Path("/setuprelaydetailsmacaddress")
	@ApiOperation( value = "if relayserver alive then add device info in DiscoveryDetails else add in RelayServer db.", 
	notes = "add device details in discoverJarDetails db." 
			)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_NOT_FOUND, message = "setup relay discovery details failed."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to setup relay discovery details and mac address.")
	} )
	public void setupRelayDiscoveryDetailsMACAddress(@ApiParam( value = "Discovery Jar Details", required = true )Map<String,Object> deviceDetails,
			@ApiParam(value="Authorization token",required=false)@HeaderParam("Authorization") String authToken) {
		mSetupRelayDiscoveryDetailsMACAddress(authToken, deviceDetails);
	}

	/** Method processing HTTP POST requests, producing "application/json" MIME media type.
	 * <p>
	 * This method add device details in discoverJarDetails db.
	 * <p>
	 * @param detailsVO DiscoveryJarDetailsVO object.
	 * @param validInfo ValidationInfoVO object. 
	 * @param authToken
	 */
	@POST
	@Consumes("application/json")
	@Produces("application/json")
	@Path("/setupsupportrelay")
	@ApiOperation( value = "setup support relay in discoverJarDetails db.", 
	notes = "setup support relay in discoverJarDetails db." 
			)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_NOT_FOUND, message = "setup support relay discovery details failed."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to setup support relay discovery details.")	 
	} )
	public void setupSupportRelay(@ApiParam( value = "Discovery Jar Details", required = true ) Map<String,Object> deviceDetails,
			@ApiParam(value="Authorization token",required=false)@HeaderParam("Authorization") String authToken) {
		mSetupSupportRelay(authToken, deviceDetails);
	}

	/** Method processing HTTP POST requests, producing "application/json" MIME media type.
	 * <p>
	 * This method add device details in discoverJarDetails db.
	 * <p>
	 * @param detailsVO DiscoveryJarDetailsVO object.
	 * @param validInfo ValidationInfoVO object. 
	 * @param authToken
	 */
	@POST
	@Consumes("application/json")
	@Produces("application/json")
	@Path("/sendemail")
	@ApiOperation( value = "send token on email.", 
	notes = "send token on email." 
			)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_NOT_FOUND, message = "send token on email failed."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to send token on email.")
	} )
	public void sendTokenOnEmail(@ApiParam( value = "Discovery Jar Details", required = true ) Map<String,Object> deviceDetails,
			@ApiParam(value="Authorization token",required=false)@HeaderParam("Authorization") String authToken) {
		mSendTokenOnEmail(authToken, deviceDetails);
	}

	/** Method processing HTTP PUT requests, producing "application/json" MIME media type.
	 * <p>
	 * This method update discoveryDetails.
	 * <p>
	 * @param deviceDetails mapping of device detail(deviceId, deviceName, ipAddress, port, backCallerRestPath) and action on 
	 * @param authToken
	 */
	@PUT
	@Consumes("application/json")
	@Produces("application/json")
	@Path("/setupdeletesupportrelay")
	@ApiOperation( value = "update device supportToken.", 
	notes = "update device supportToken" 
			)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_NOT_FOUND, message = "setup relay discovery details failed."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to update device supportToken.")
	} )
	public void setupDeleteSupportRelay(@ApiParam( value = "detail(hostName, email, token) mapping", required = true )Map<String,Object> deviceDetails,
			@ApiParam(value="Authorization token",required=false)@HeaderParam("Authorization") String authToken) {
		mSetupDeleteSupportRelay(authToken, deviceDetails);
	}


	/** Method processing HTTP PUT requests, producing "application/json" MIME media type.
	 * <p>
	 * This method update discoveryDetails.
	 * <p>
	 * @param deviceDetails mapping of device detail(deviceId, deviceName, ipAddress, port, backCallerRestPath) and action on 
	 * @param authToken
	 */
	@PUT
	@Consumes("application/json")
	@Produces("application/json")
	@Path("/setrurldetails")
	@ApiOperation( value = "update discoveryDetails if url(RAddress:RURLTomcatPort) connected to box.", 
	notes = "update discoveryDetails if url(RAddress:RURLTomcatPort) connected to box." 
			)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_NOT_FOUND, message = "setup url(RAddress:RURLTomcatPort) failed."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to setup url(RAddress:RURLTomcatPort) .")
	} )
	public void setRURLDetails(@ApiParam( value = "detail(deviceId, deviceName, ipAddress, port, backCallerRestPath) mapping", required = true ) Map<String,String> deviceDetails,
			@ApiParam(value="Authorization token",required=false)@HeaderParam("Authorization") String authToken) {
		mSetRURLDetails(authToken, deviceDetails);
	}

	/** Method processing HTTP PUT requests, producing "application/json" MIME media type.
	 * <p>
	 * This method delete row from discoveryJarDetails using MACAddress.
	 * <p>
	 * @param macaddress unique id of discoverJarDetails row. 
	 * @param authToken
	 */
	@DELETE
	@Consumes("application/json")
	@Produces("application/json")
	@Path("/{macaddress}")
	@ApiOperation( value = "Delete device discovery detail.", 
	notes = "Delete device discovery detail." 
			)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_NOT_FOUND, message = "Delete device discovery detail failed."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to Delete device discovery detail.")	 
	} )
	public void deleteDeviceDiscoveryjar(@ApiParam( value = "macaddress", required = true ) @NotNull @PathParam("macaddress") String macaddress,
			@ApiParam(value="Authorization token",required=false)@HeaderParam("Authorization") String authToken) {
		mDeleteDeviceDiscoveryjar(authToken, macaddress);
	}


	/**
	 * Method processing HTTP GET requests, producing "application/json" MIME media-type.
	 * <p> 
	 * This method return internet router ip 
	 * </p>  
	 * @param httpHeaders
	 * @return
	 */
	@GET
	@Consumes({MediaType.APPLICATION_JSON})
	@Path("/{deviceId}/supportrelayserverdetails")
	@ApiOperation( value = "get support relay server detail.", 
	notes = "get support relay server detail.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_NOT_FOUND, message = "Doesn't get router ip."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to get support token detail.")	
	} )
	public void getSupportRelayServerDetails(@Context HttpServletRequest request,
			@ApiParam(value="Device Id",required=true)@PathParam("deviceId") String deviceId,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken){
		mGetSupportRelayServerDetails(authToken, deviceId);
	}

	/** Method processing HTTP POST requests, producing "application/json" MIME media type.
	 * <p>
	 * This method add device details in discoverJarDetails db.
	 * <p>
	 * @param detailsVO DiscoveryJarDetailsVO object.
	 * @param validInfo ValidationInfoVO object. 
	 * @param authToken
	 */
	@POST
	@Consumes("application/json")
	@Produces("application/json")
	@Path("/generatesupporttoken")
	@ApiOperation( value = "generate support token.", 
	notes = "generate support token." 
			)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_NOT_FOUND, message = "generate support token failed."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to generate support token.") 
	} )
	public void generateSupportToken(@ApiParam( value = " Generate support token.", required = true ) Map<String,Object> deviceDetails,
			@ApiParam(value="Authorization token",required=false)@HeaderParam("Authorization") String authToken) {
		mGenerateSupportToken(authToken, deviceDetails);
	}

	/** Method processing HTTP GET requests, producing "application/json" MIME media type.
	 * <p>
	 * This method returns support token details.
	 * <p>
	 * @param detailsVO DiscoveryJarDetailsVO object.
	 * @param validInfo ValidationInfoVO object. 
	 * @param authToken
	 */
	@GET	
	@Produces("application/json")
	@Path("/supportTokenDetails/{nodeid}")
	@ApiOperation( value = "Get support token details.", 
	notes = "Get support token details." 
			)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_NOT_FOUND, message = "Get support token detail failed."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to Get support token detail.") 
	} )
	public void supportTokenDetail(@ApiParam( value = " Get support token details.", required = true )@PathParam("nodeid") String nodeId,
			@ApiParam(value="Authorization token",required=false)@HeaderParam("Authorization") String authToken) {
		mGetSupportToken(authToken, nodeId);
	}

	/** Method processing HTTP DELETE requests, producing "application/json" MIME media type.
	 * <p>
	 * This method delete support token details.
	 * <p>
	 * @param token  
	 * @param authToken
	 * @throws Exception 
	 */
	@DELETE	
	@Produces("application/json")
	@Path("/SupportToken/{token}")
	@ApiOperation( value = "Get support token details.", 
	notes = "Get support token details." 
			)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_NOT_FOUND, message = "Get support token detail failed."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to Get support token detail.") 
	} )
	public void deleteSupportTokenDetail(@ApiParam( value = " Support token.", required = true )@PathParam("token") String token,
			@ApiParam(value="Authorization token",required=false)@HeaderParam("Authorization") String authToken) {
		mDeleteSupportToken(authToken, token);
	}


	private void mDeleteSupportToken(String authToken, String token) {
		try {
			// TODO Auto-generated method stub		
			if( new AuthHelper().checkJwtToken(authToken, response) == null)
				return;
			Map<String, Object> resultMap =new HashMap<>();  
			boolean istokenDeleted= new SupportRelayServer().DeleteSupportToken(token);
			if(istokenDeleted)
			{
				resultMap.put(Constant.DATA, "Support Token deleted successfully");
				resultMap.put(Constant.SUCCESS, "SUCCESS");
			}else{
				resultMap.put(Constant.DATA, "Delete Support Token failed.");
				resultMap.put(Constant.SUCCESS, "FAILED");
			}			
		}
		catch (Exception e) {
			PALogger.ERROR(e);	
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}			
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"Unable to delete support token.", "Unable to delete support token.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
		}
	}

	private void mGetSupportRelayServerDetails(String authToken, String deviceId) {
		try {

			AuthorizationsVO authvo = new GrpcAuthHelper().getAuthorizationsVO(authToken);

			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.SUPPORT_TOKEN_GENERATE));
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.SUPPORT_TOKEN_DELETE));
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.SUPPORT_TOKEN_LIST));

			AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, false);

			PALogger.INFO("mGetSupportRelayServerDetails - "+request);
			Map<String, String> supportServerDetails = new SupportRelayServer().supportRelayServerDetails(deviceId);
			PALogger.INFO("mGetSupportRelayServerDetails - "+ supportServerDetails);
			HashMap<String, Object>  resultMap =  new HashMap<>();
			resultMap.put(Constant.DATA, supportServerDetails);
			resultMap.put(Constant.SUCCESS, "SUCCESS");
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);

		} catch (Exception e) {
			PALogger.ERROR(e);	
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTFOUND)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_NOT_FOUND , "internet router ip not found.", "internet router ip not found.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"internet router ip not found.", "internet router ip not found.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
		}
	}

	private void mDeleteDeviceDiscoveryjar(String authToken, String macaddress) {
		try {
			if( new AuthHelper().checkJwtToken(authToken, response) == null)
				return;
			Map<String, Object> details = new DiscoveryJarDetails().deleteDiscoveryJarDetails(macaddress);
			ReturnObject.createResponse(Constant.SUCCESS, details, null, response);

		} catch (Exception e) {
			PALogger.ERROR(e);	
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTFOUND)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_NOT_FOUND , "device detail not found", "No device detail found with requested application Id");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"delete device discoveryJar failed. "+macaddress, "delete device discoveryJar failed. "+macaddress);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
		}
	}

	private void mSetRURLDetails(String authToken, Map<String, String> deviceDetails) {
		try {
			if( new AuthHelper().checkJwtToken(authToken, response) == null)
				return;
			Map<String, Object> details = new DiscoveryDetails().setRURLDetails(deviceDetails.get("deviceId"), deviceDetails.get("RURLTomcatPort"),  
					deviceDetails.get("RAddress"), deviceDetails.get("isCheck"), deviceDetails.get("backCallerRestPath"));
			ReturnObject.createResponse(Constant.SUCCESS, details, null, response);

		} catch (Exception e) {
			PALogger.ERROR(e);	
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTFOUND)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_NOT_FOUND , "device detail not found", "No device detail found with requested application Id");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"set RURLDetails failed. "+deviceDetails.get("deviceId"), "set RURLDetails failed. "+deviceDetails.get("deviceId"));
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
		}
	}

	private void mCanConnect(String authToken, Map<String, String> deviceDetails) {
		try {
			if( new AuthHelper().checkJwtToken(authToken, response) == null)
				return;
			Map<String, Object> resultMap = new DiscoveryDetails().canConnectNew(deviceDetails.get("ipAddress"), deviceDetails.get("port"), 
					deviceDetails.get("deviceId"), deviceDetails.get("deviceName"), deviceDetails.get("port5"), deviceDetails.get("backCallerRestPath"));
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);
		} catch (Exception e) {
			PALogger.ERROR(e);	
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTFOUND)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_NOT_FOUND , "device detail not found", "No device detail found with requested application Id");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"can connect failed. "+deviceDetails.get("deviceId"), "can connect failed. "+deviceDetails.get("deviceId"));
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
		}
	}

	private void mGetInternetRouterIP(String authToken, HttpServletRequest request) {
		try {
			// CHECK AUTH TOKEN...
			if( new AuthHelper().checkJwtToken(authToken, response) == null)
				return;
			PALogger.INFO("mGetInternetRouterIP - "+request);
			String ipReal = new DiscoveryDetails().getClientIP(request);
			PALogger.INFO("mGetInternetRouterIP - "+ipReal);
			Map<String, Object>  resultMap =  new HashMap<>();
			resultMap.put("IPReal", ipReal);
			resultMap.put("Status", Constant.SUCCESS);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);

		} catch (Exception e) {
			PALogger.ERROR(e);	
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTFOUND)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_NOT_FOUND , "internet router ip not found.", "internet router ip not found.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"internet router ip not found.", "internet router ip not found.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
		}
	}

	private void mGetDiscoveryDetails(String authToken, String deviceId) {
		try {
			// CHECK AUTH TOKEN...
			new GrpcAuthHelper().checkAuthorization(authToken);

			DiscoveryDetailsVO discoveryDetails = (new DiscoveryDetails()).getDiscoveryDetails(deviceId);			
			Map<String, Object>  resultMap =  new HashMap<>();
			//DB, RA Note: WHENEVER discoveryDetails key is changed, do remember to change it where this function is invoked 
			resultMap.put("discoveryDetails", discoveryDetails);
			resultMap.put("Status", Constant.SUCCESS);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);

		} catch (Exception e) {
			PALogger.ERROR(e);	
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTFOUND)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_NOT_FOUND , "device detail not found", "No device detail found with requested application Id");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"device detail not found.", "device detail not found.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
		}
	}

	private void mGetDiscoveryDetailsByName(String authToken, String deviceName, HttpServletRequest request) {
		try {
			// CHECK AUTH TOKEN...
			// Execute that operation if user is owner of that group.
			new GrpcAuthHelper().checkAuthorization(authToken);
			Map<String, Object>  resultMap =  new HashMap<>();
			try{
				DiscoveryDetailsVO discoveryDetails = (new DiscoveryDetails()).getDiscoveryDetailsByName(deviceName);	
				discoveryDetails.setIPReal(new DiscoveryDetails().getClientIP(request));
				resultMap.put("discoveryDetails", discoveryDetails);
			}catch (Exception e) {
				if(e.getMessage().contains(Constant.NOTFOUND)){
					DiscoveryJarDetailsVO discoveryDetails = (new DiscoveryJarDetails()).getDiscoveryJarDetailsUsingHostName(deviceName);	
					discoveryDetails.setIPReal(new DiscoveryDetails().getClientIP(request));
					resultMap.put("discoveryDetails", discoveryDetails);
				}
			}

			resultMap.put("Status", Constant.SUCCESS);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);

		} catch (Exception e) {
			PALogger.ERROR(e);	
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTFOUND)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_BAD_REQUEST , "Device detail not found.", "No device detail found with requested device name");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"device detail not found.", "device detail not found.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
		}
	}

	private void mGetDiscoveryJarDetails(String authToken) {
		try {
			// CHECK AUTH TOKEN...
			new GrpcAuthHelper().getAuthorizationsVO(authToken);
			DiscoveryDetails details = new DiscoveryDetails();
			String externalIP = details.getClientIP(request);
			Map<String, Object>  resultMap =  new HashMap<>();
			resultMap.put("discoveryDetails", new DiscoveryJarDetails().getNonActivatedDevices(externalIP));
			resultMap.put("Status", Constant.SUCCESS);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);
		} catch (Exception e) {
			PALogger.ERROR(e);	
			ErrorVo errorVo = null;
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
			} else if(e.getMessage().equals(Constant.NOTFOUND)){
				errorVo = new ErrorVo(HttpServletResponse.SC_NOT_FOUND , "device detail not found", "No device detail found with requested application Id");
			} else if(e.getMessage().equals(Constant.NOTPERMITTED)) {
				errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
			} else {
				errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Unable to get device detail.", "Unable to get device detail.");
			}
			ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
		}
	}



	private void mCheckIfURLAccessibleFromInternet(String authToken, Map<String, String> deviceDetails) {
		try {
			// CHECK AUTH TOKEN...
			if( new AuthHelper().checkJwtToken(authToken, response) == null)
				return;
			Map<String, Object> hashResult = new DiscoveryDetails().checkRestConnectNew(deviceDetails.get("ipAddress"), deviceDetails.get("port"), deviceDetails.get("deviceId"), deviceDetails.get("backCallerRestPath"));
			ReturnObject.createResponse(Constant.SUCCESS, hashResult, null, response);

		} catch (Exception e) {
			PALogger.ERROR(e);	
			Map<String, Object> hashResult = new HashMap<>();
			hashResult.put("Status", "Failure");
			ReturnObject.createResponse(Constant.SUCCESS, hashResult, null, response);
		}
	}

	private void mSetConnectURL(String authToken, DiscoveryDetailsVO discoveryDetails) {
		try {
			// CHECK AUTH TOKEN...
			if( new AuthHelper().checkJwtToken(authToken, response) == null)
				return;
			Map<String, Object> resultMap = new DiscoveryDetails().setConnectURLRelay(discoveryDetails.getsIPAddress(), discoveryDetails.getsNetworkType(), discoveryDetails.getsRelayServerID(), discoveryDetails.getsChatInputChannel(), 
					discoveryDetails.getsChatOutputChannel(), discoveryDetails.getsChatSubscriptionChannel(), discoveryDetails.getsNodeCommunicationPort(), discoveryDetails.getsOpenStackPort(), discoveryDetails.getsTomcatPort(), 
					discoveryDetails.getsPort1(), discoveryDetails.getsPort2(), discoveryDetails.getsPort3(), discoveryDetails.getsPort4(), discoveryDetails.getsPort5(), discoveryDetails.getsRURLTomcatPort(),  discoveryDetails.getsRAddress(), discoveryDetails.getsDeviceID());
			resultMap.put(Constant.DATA, discoveryDetails);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);

		} catch (Exception e) {
			PALogger.ERROR(e);	
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTFOUND)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_NOT_FOUND , "set connectUrl failed. "+ discoveryDetails.getsDeviceID(), "set connectUrl failed. "+ discoveryDetails.getsDeviceID());
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"set connectUrl failed. "+ discoveryDetails.getsDeviceID(), "set connectUrl failed. "+ discoveryDetails.getsDeviceID());
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
		}
	}

	private void mPublishDiscoveryDetails(String authToken, Map<String,Object> reqHash) {
		try {
			if( new AuthHelper().checkJwtToken(authToken, response) == null)
				return;
			Gson json = new Gson();
			String detailsJson = json.toJson(reqHash.get("DetailsVO"));
			DiscoveryJarDetailsVO detailsVO = json.fromJson(detailsJson, DiscoveryJarDetailsVO.class);

			String validJson = json.toJson(reqHash.get("ValidationInfoVO"));
			ValidationInfoVO validInfo = json.fromJson(validJson, ValidationInfoVO.class);
			PALogger.INFO("==PublishDiscoveryDetails==DetailsVO=== "+detailsJson+"  ===ValidationInfoVO=== "+validJson);
			Map<String, Object> detail = new DiscoveryDetails().receiveDiscoveryDetails(detailsVO, validInfo);
			ReturnObject.createResponse(Constant.SUCCESS, detail, null, response);

		} catch (Exception e) {
			PALogger.ERROR(e);	
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTFOUND)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_NOT_FOUND , "publish discover failed.", "publish discover failed.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"publish discover failed.", "publish discover failed.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
		}

	}

	private void mSetupRelayDiscoveryDetails(String authToken, Map<String, Object> reqHash) {
		try {
			if( new AuthHelper().checkJwtToken(authToken, response) == null)
				return;
			Gson json = new Gson();
			String detailsJson = json.toJson(reqHash.get("DetailsVO"));
			DiscoveryJarDetailsVO detailsVO = json.fromJson(detailsJson, DiscoveryJarDetailsVO.class);

			String validJson = json.toJson(reqHash.get("ValidationInfoVO"));
			ValidationInfoVO validInfo = json.fromJson(validJson, ValidationInfoVO.class);
			PALogger.INFO("==SetupRelayDiscoveryDetails==DetailsVO=== "+detailsJson+"  ===ValidationInfoVO=== "+validJson);
			Map<String, Object> detail = new DiscoveryDetails().receiveRelayDiscoveryDetails(detailsVO, validInfo);
			ReturnObject.createResponse(Constant.SUCCESS, detail, null, response);

		} catch (Exception e) {
			PALogger.ERROR(e);	
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTFOUND)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_NOT_FOUND , "setup relay discovery failed.", "setup relay discovery failed.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"setup relay discovery failed.", "setup relay discovery failed.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
		}
	}

	private void mSetupRelayDiscoveryDetailsMACAddress(String authToken, Map<String, Object> reqHash) {
		try {
			if( new AuthHelper().checkJwtToken(authToken, response) == null)
				return;

			Gson json = new Gson();
			String detailsJson = json.toJson(reqHash.get("DetailsVO"));
			DiscoveryJarDetailsVO detailsVO = json.fromJson(detailsJson, DiscoveryJarDetailsVO.class);

			String validJson = json.toJson(reqHash.get("ValidationInfoVO"));
			ValidationInfoVO validInfo = json.fromJson(validJson, ValidationInfoVO.class);
			PALogger.INFO("==SetupRelayDiscoveryDetailsMACAddress==DetailsVO=== "+detailsJson+"  ===ValidationInfoVO=== "+validJson);
			Map<String, Object> detail = new DiscoveryDetails().receiveJARRelayDiscoveryDetails(detailsVO, validInfo);
			ReturnObject.createResponse(Constant.SUCCESS, detail, null, response);
		} catch (Exception e) {
			PALogger.ERROR(e);	
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTFOUND)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_NOT_FOUND , "setup relay discovery macaddress failed.", "setup relay discovery macaddress failed.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"setup relay discovery macaddress failed.", "setup relay discovery macaddress failed.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
		}
	}

	private void mSetupSupportRelay(String authToken, Map<String, Object> reqHash) {
		try {
			// CHECK AUTH TOKEN...
			String userId =  new GrpcAuthHelper().checkAuthorization(authToken);
			String hostName = reqHash.get("hostName").toString().trim();
			String email = reqHash.get("email").toString().trim();
			String token = reqHash.get("token").toString().trim();

			PALogger.INFO("==mSetupSupportRelay==hostName=== "+ hostName +"  ===email=== " + email+ "===token====" + token);
			Map<String, Object> detail = new SupportRelayServer().setupSupportRelay(hostName, email, token, false);
			//insert activity
			Map<String, Object> map = new HashMap<>();
			map.put("hostName", hostName);
			map.put("email", email);

			new ActivityLogs().insert(userId, ActivityOperation.setupSupportRelay.name(), new Gson().toJson(map));
			ReturnObject.createResponse(Constant.SUCCESS, detail, null, response);

		} catch (Exception e) {
			PALogger.ERROR(e);	
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTFOUND)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_NOT_FOUND , "setup relay discovery macaddress failed.", "setup relay discovery macaddress failed.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"setup relay discovery macaddress failed.", "setup relay discovery macaddress failed.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
		}
	}

	private void mSendTokenOnEmail(String authToken, Map<String, Object> reqHash) {
		try {
			// CHECK AUTH TOKEN...
			new GrpcAuthHelper().checkAuthorization(authToken);
			String deviceId = reqHash.get("deviceId").toString().trim();
			String email = reqHash.get("email").toString().trim();
			String token = reqHash.get("token").toString().trim();

			PALogger.INFO("==mSendTokenOnEmail==deviceId=== "+ deviceId +"  ===email=== " + email+ "===token====" + token);
			Map<String, Object> detail = new SupportRelayServer().sendTokenOnEmail(email, token, deviceId);
			ReturnObject.createResponse(Constant.SUCCESS, detail, null, response);

		} catch (Exception e) {
			PALogger.ERROR(e);	
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTFOUND)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_NOT_FOUND , "setup relay discovery macaddress failed.", "setup relay discovery macaddress failed.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"setup relay discovery macaddress failed.", "setup relay discovery macaddress failed.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
		}
	}

	private void mSetupDeleteSupportRelay(String authToken,Map<String, Object> reqHash) {
		try {
			// CHECK AUTH TOKEN...
			String  userId =new GrpcAuthHelper().checkAuthorization(authToken);
			String hostName = reqHash.get("hostName").toString().trim();
			String email = reqHash.get("email").toString().trim();
			String token = reqHash.get("token").toString().trim();

			PALogger.INFO("==mSetupDeleteSupportRelay==hostName=== "+ hostName +"  ===email=== " + email+ "===token====" + token);
			Map<String, Object> detail = new SupportRelayServer().setupDeleteSupportRelay(hostName, email, token);
			//insert activity
			Map<String, Object> map = new HashMap<>();
			map.put("hostName", hostName);
			map.put("email", email);

			new ActivityLogs().insert(userId, ActivityOperation.setupDeleteSupportRelay.name(), new Gson().toJson(map));
			ReturnObject.createResponse(Constant.SUCCESS, detail, null, response);

		} catch (Exception e) {
			PALogger.ERROR(e);	
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTFOUND)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_NOT_FOUND , "setup relay discovery macaddress failed.", "setup relay discovery macaddress failed.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"setup relay discovery macaddress failed.", "setup relay discovery macaddress failed.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
		}
	}

	private void mCheckUniqueId(String authToken, String productId,String hostName) {
		try {
			if( new AuthHelper().checkJwtToken(authToken, response) == null)
				return;
			if(StringFunctions.isNullOrWhitespace(productId))
				throw new IllegalArgumentException("productId is required.");
			Map<String, Object>  resultMap = new Devices().isProductIDUnique(productId, hostName);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);
		} catch (Exception e) {
			PALogger.ERROR(e);	
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTFOUND)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_NOT_FOUND , "validationInfo not found", "No validationInfo found with requested application Id");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						e.getMessage(), e.getMessage());
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
		}
	}

	private void mUpdateDeviceHeartbeat(String authToken, String deviceId, Boolean isActive) {
		try {
			// CHECK AUTH TOKEN...
			if( new AuthHelper().checkJwtToken(authToken, response) == null)
				return;
			DiscoveryDetails details = new DiscoveryDetails();
			details.updateDeviceHeartbeat(deviceId);
			//PS_1
			if(isActive != null && isActive)
			{
				new DevicesEngine().updateClusterActiveMaster(deviceId);
			}
			Map<String, Object>  resultMap =  new HashMap<>();
			resultMap.put("discoveryDetails", deviceId);
			resultMap.put("Status", Constant.SUCCESS);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);
		} catch (Exception e) {
			PALogger.ERROR(e);	
			ErrorVo errorVo = null;
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
			} else if(e.getMessage().equals(Constant.NOTFOUND)){
				errorVo = new ErrorVo(HttpServletResponse.SC_NOT_FOUND , "device detail not found", "No device detail found with requested application Id");
			} else if(e.getMessage().equals(Constant.NOTPERMITTED)) {
				errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
			} else {
				errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Unable to get device detail.", "Unable to get device detail.");
			}
			ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
		}
	}

	private void mUpdateInactiveDeviceHeartbeat(String authToken, String productId) {
		try {
			if( new AuthHelper().checkJwtToken(authToken, response) == null)
				return;

			DiscoveryJarDetails details = new DiscoveryJarDetails();
			details.updateInactiveDeviceHeartbeat(productId);
			Map<String, Object>  resultMap =  new HashMap<>();
			resultMap.put("discoveryJarDetails", productId);
			resultMap.put("Status", Constant.SUCCESS);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);
		} catch (Exception e) {
			PALogger.ERROR(e);	
			ErrorVo errorVo = null;
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
			} else if(e.getMessage().equals(Constant.NOTFOUND)){
				errorVo = new ErrorVo(HttpServletResponse.SC_NOT_FOUND , "device detail not found", "No device detail found with requested application Id");
			} else if(e.getMessage().equals(Constant.NOTPERMITTED)) {
				errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
			} else {
				errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Unable to get device detail.", "Unable to get device detail.");
			}
			ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
		}
	}


	private void mGenerateSupportToken(String authToken, Map<String, Object> reqHash) {
		try {
			// CHECK AUTH TOKEN...
			String userId = new GrpcAuthHelper().checkAuthorization(authToken);
			AuthorizationsVO authvo = new GrpcAuthHelper().getAuthorizationsVO(authToken);
			String hostName = reqHash.get("hostName").toString().trim();
			String email = reqHash.get("email").toString().trim();
			String deviceName = reqHash.get("deviceName").toString().trim();
			String tokenExpiryString= reqHash.get("tokenExpiry").toString().trim();
			String nodeId = reqHash.get("nodeId").toString().trim();
			long tokenExpiry=Long.parseLong(tokenExpiryString);
			PALogger.INFO("==mGenerateSupportToken==hostName=== "+ hostName +"  ===email=== " + email+ "===deviceName====" + deviceName+" token expired in "+tokenExpiryString +" hours." );
			Map<String, Object> detail = new SupportRelayServer().generateSupportToken(email, hostName,authvo.getUserId(),tokenExpiry,nodeId);

			//insert activity
			Map<String, Object> map = new HashMap<>();
			map.put("hostName", hostName);
			map.put("email", email);

			new ActivityLogs().insert(userId, ActivityOperation.generateSupportToken.name(), new Gson().toJson(map));
			ReturnObject.createResponse(Constant.SUCCESS, detail, null, response);

		} catch (Exception e) {
			PALogger.ERROR(e);	
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTFOUND)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_NOT_FOUND , "setup relay discovery macaddress failed.", "setup relay discovery macaddress failed.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"setup relay discovery macaddress failed.", "setup relay discovery macaddress failed.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
		}
	}



	private void mGetSupportToken(String authToken, String nodeId) {
		try {
			// CHECK AUTH TOKEN...
			new GrpcAuthHelper().checkAuthorization(authToken);	
			PALogger.INFO("==mGetSupportToken==nodeId is === "+ nodeId);
			Map<String, Object> detail = new SupportRelayServer().GetSupportTokenDetails(nodeId);			
			ReturnObject.createResponse(Constant.SUCCESS, detail, null, response);
		} catch (Exception e) {
			PALogger.ERROR(e);	
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTFOUND)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_NOT_FOUND , "setup relay discovery macaddress failed.", "setup relay discovery macaddress failed.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"setup relay discovery macaddress failed.", "setup relay discovery macaddress failed.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
		}
	}


}

/*
	Change History : 
	 PS_1: Update active master of cluster and set others as backup.
 */
