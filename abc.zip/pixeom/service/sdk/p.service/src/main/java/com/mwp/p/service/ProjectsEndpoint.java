/** 
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com) 
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL 
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC. 
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD 
 * IN STRICTEST CONFIDENCE. 
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */

package com.mwp.p.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import javax.validation.ValidationException;
import javax.validation.constraints.NotNull;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import com.mwp.common.ReturnObject;
import com.mwp.common.constant.Constant;
import com.mwp.common.constant.PermissionResourceKeys;
import com.mwp.common.constant.PermissionResources;
import com.mwp.common.enums.Status;
import com.mwp.common.vo.ApplicationVO;
import com.mwp.common.vo.AuthorizationsVO;
import com.mwp.common.vo.ErrorVo;
import com.mwp.logger.PALogger;
import com.mwp.p.authhelper.GrpcAuthHelper;
import com.mwp.p.common.AdminPermissionCheck;
import com.mwp.p.common.vo.ProjectVO;
import com.mwp.p.framework.Projects;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/** <h1>ProjectsEndpoint</h1>
 * Class hosted at the URI path "/projects"
 * <p>
 * Class manage projects of developer, list projects, create/update/delete project,
 * project detail, list application of project.
 * </p>
 * @author akh
 * @version 0.0.1
 * @since   2016-08-30 
 */

//description = "Class manage projects, list projects, create/update/delete project, project detail, list application of project."
@Path("/projects")
@Api( value = "/projects", produces=MediaType.APPLICATION_JSON)
public class ProjectsEndpoint {
	@Context
	private HttpServletResponse response;

	/**
	 * Method processing HTTP GET requests, producing "application/json" MIME media-type.
	 * <p> This method return list of project.</p>
	 * @param httpHeaders
	 * @return
	 */
	@GET
	@Consumes({MediaType.APPLICATION_JSON})
	@ApiOperation( value = "List of project.", 
	notes = "List of project.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to list project."),
	} )
	public void listProject(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken){
		mListProject(authToken);	
	}

	/**
	 * Method processing HTTP GET requests, producing "application/json" MIME media-type	.
	 * 
	 * <p> This method return project detail according to requested projectId.</p>
	 * @param projectId
	 * @param httpHeaders
	 * @return
	 */
	@GET
	@Consumes({MediaType.APPLICATION_JSON})
	@Path("/{id}")
	@ApiOperation( value = "Get project detail.", 
	notes = "project detail according to requested projectId", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = Constant.NOTPERMITTED),
		@ApiResponse( code = HttpServletResponse.SC_NOT_FOUND, message = "No project found with requested project ID."),		
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to get project detail."),
	} )
	public void getProjectDetail(@ApiParam(value = "id of project.", required = true) @NotNull @PathParam("id") String projectId, 
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken) throws ValidationException{
		mGetProjectDetail(authToken, projectId);
	}
	
	/**
	 * Method processing HTTP GET requests, producing "application/json" MIME media-type.
	 * 
	 * <p> This method gives List of application according to projectId.</p>
	 * @param projectId unique id of project.  
	 * @param httpHeaders
	 * @return
	 */

	@GET
	@Consumes({MediaType.APPLICATION_JSON})
	@Path("/listapps/{id}")
	@ApiOperation( value = "List of project application", 
	notes = "List of project application.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to list project apps."),
	} )
	public void listProjectApps(@ApiParam(value = "projectId", required = false) @NotNull @PathParam("id") String projectId,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken) throws ValidationException{
		mListProjectApps(authToken, projectId);
	}

	/** Method processing HTTP POST requests, producing "application/json" MIME media type.
	 * <p>
	 * This method add project info.
	 * <p>
	 * @param projectVO object details of Project
	 * @param httpHeaders 
	 * @return Json string
	 * @throws Exception 
	 */
	@POST
	@Consumes({MediaType.APPLICATION_JSON})
	@ApiOperation( value = "Add project detail", 
	notes = "add project info.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to create project."),
	} )
	public void createProject(@ApiParam(value = "ProjectVO class object.", required = true)  @Valid @NotNull ProjectVO projectVO,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken) throws ValidationException
	{
		mCreateProject(authToken, projectVO);
	}
	
	/** Method processing HTTP PUT requests, producing "application/json" MIME media type.
	 * <p>
	 * This method update project info according to projectId which exist in project object.
	 * <p>
	 * @param projectVO object details of Project
	 * @param httpHeaders 
	 * @return Json string
	 * @throws Exception 
	 */
	@PUT
	@Consumes({MediaType.APPLICATION_JSON})
	@Path("/{id}")
	@ApiOperation( value = "Update project detail.", 
	notes = "update project info according to projectId which exist in project object.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = Constant.NOTPERMITTED),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to update  project.")			 
	} )
	public void editProject(@ApiParam(value = "id of project.", required = true) @PathParam("id") @NotNull String projectId,
			@ApiParam(value = "ProjectVO class object.", required = true) @Valid @NotNull ProjectVO projectVO,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken) throws ValidationException{
		mEditProject(authToken, projectVO);
	}

	/** Method processing HTTP DELETE requests, producing "application/json" MIME media type.
	 * <p>
	 * This method delete project info from db.
	 * <p>
	 * @param projectId unique id of project.
	 * @return
	 * @throws Exception 
	 */
	@DELETE
	@Consumes({MediaType.APPLICATION_JSON})
	@Path("/{id}")
	@ApiOperation( value = "delete project detail.", 
	notes = "delete project info from db."
			)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to remove project."),
	} )
	public void removeProject(@ApiParam(value = "id of project.", required = true) @PathParam("id") @NotNull String projectId,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken) throws ValidationException {
		mRemoveProject(authToken, projectId);
	}

	private void mCreateProject(String authToken, ProjectVO projectVO)  {
		try {
			// CHECK AUTH TOKEN...
			AuthorizationsVO authVo=new GrpcAuthHelper().getAuthorizationsVO(authToken);
			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_PROJECTS));
			AdminPermissionCheck.checkAdminPermission(authVo, lstPermissions, true);
			
			String userId = authVo.getUserId();
			
			Projects projects = new Projects();
			projectVO.setStatus(Status.ACTIVE);
			projectVO.setUserId(userId);
			ProjectVO addedProjectVO =projects.addProject(projectVO);
			Map< String, Object> resultMap=new HashMap<>();
			resultMap.put(Constant.DATA, addedProjectVO);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);

		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"Unable to create project", "Unable to create project");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			PALogger.ERROR(e);	
		}
	}

	private void mListProject(String authToken) {
		try {
			// CHECK AUTH TOKEN...
			
			AuthorizationsVO authVo=new GrpcAuthHelper().getAuthorizationsVO(authToken);
			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_PROJECTS));
			AdminPermissionCheck.checkAdminPermission(authVo, lstPermissions, true);
			
			String userId = authVo.getUserId();
			Projects projects =new Projects();
			List<ProjectVO> listProjectVOs =projects.listProject(userId);
			Map< String, Object> resultMap=new HashMap<>();
			resultMap.put(Constant.DATA, listProjectVOs);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);

		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"Unable to list project.", "Unable to list project.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			PALogger.ERROR(e);	
		}
	}
	
	private void mGetProjectDetail(String authToken, String projectId) {
		try {
			// CHECK AUTH TOKEN...
			AuthorizationsVO authVo=new GrpcAuthHelper().getAuthorizationsVO(authToken);
			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_PROJECTS));
			AdminPermissionCheck.checkAdminPermission(authVo, lstPermissions, true);
			
			String userId = authVo.getUserId();
			Projects projects =new Projects();
			ProjectVO projectVO =projects.getProjectDetail(projectId);
			if (projectVO!=null) {
				if (projectVO.getUserId().equals(userId)) {
					Map<String, Object> resultMap = new HashMap<>();
					resultMap.put(Constant.DATA, projectVO);
					ReturnObject.createResponse(Constant.SUCCESS, resultMap,
							null, response);
				} else {
					throw new Exception(Constant.NOTPERMITTED);
				}
			}
			else{
				throw new Exception(Constant.NOTFOUND);
			}

		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTFOUND))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_NOT_FOUND ,"project not found", "No project found with requested project ID");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"Unable to get project detail", "Unable to get project detail");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			PALogger.ERROR(e);	
		}
	}

	private void mEditProject(String authToken, ProjectVO projectVO) {
		try {
			// CHECK AUTH TOKEN...
			AuthorizationsVO authVo=new GrpcAuthHelper().getAuthorizationsVO(authToken);
			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_PROJECTS));
			AdminPermissionCheck.checkAdminPermission(authVo, lstPermissions, true);
			
			String userId = authVo.getUserId();
			Projects projects =new Projects();
			ProjectVO updatedProjectVO =projects.updateProject(projectVO);
			// Edit project if user is owner of that project.
			if(projectVO.getUserId().equals(userId))
			{
				Map<String, Object> resultMap=new HashMap<>();
				resultMap.put(Constant.DATA, updatedProjectVO);
				ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);
			}
			else
			{
				throw new Exception(Constant.NOTPERMITTED);
			}
		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"Unable to update project", "Unable to update  project");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			PALogger.ERROR(e);	
		}
	}

	private void mRemoveProject(String authToken, String projectId) {
		try {
			// CHECK AUTH TOKEN...
			// remove project if user is owner of that project.
			AuthorizationsVO authVo=new GrpcAuthHelper().getAuthorizationsVO(authToken);
			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_PROJECTS));
			AdminPermissionCheck.checkAdminPermission(authVo, lstPermissions, true);
			
			String userId = authVo.getUserId();
			Projects projects =new Projects();
			projects.deleteProject(projectId,userId);
			Map<String, Object> resultMap=new HashMap<>();
			resultMap.put(Constant.DATA, projectId);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);

		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"Unable to remove project", "Unable to remove project");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			PALogger.ERROR(e);	
		}
	}

	private void mListProjectApps(String authToken, String projectId) {
		try {
			// CHECK AUTH TOKEN...
			// List project app if user is owner of that project.
			AuthorizationsVO authVo=new GrpcAuthHelper().getAuthorizationsVO(authToken);
			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_PROJECTS));
			AdminPermissionCheck.checkAdminPermission(authVo, lstPermissions, true);
			
			String userId = authVo.getUserId();
			Projects projects =new Projects();
			List<ApplicationVO> applicationVOs =projects.listProjectApps(projectId,userId);
			Map<String, Object> resultMap=new HashMap<>();
			resultMap.put(Constant.DATA, applicationVOs);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);

		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"Unable to list project apps", "Unable to list project apps");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			PALogger.ERROR(e);	
		}
	}

}
