/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;
import javax.validation.constraints.Min;
import javax.ws.rs.Consumes;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import com.mwp.common.AuthHelper;
import com.mwp.common.ReturnObject;
import com.mwp.common.constant.Constant;
import com.mwp.common.vo.DockerEventVO;
import com.mwp.common.vo.ErrorVo;
import com.mwp.logger.PALogger;
import com.mwp.p.authhelper.GrpcAuthHelper;
import com.mwp.p.framework.DockerEvents;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/** <h1>DockerEventEndpoint</h1>
 * Class hosted at the URI path "/dockerevent"
 * <p>
 * Class manage docker event logs of applications on different devices ,
 * insert box logs on portal,and list them.
 * </p>
 * @version 0.0.1
 * @since   2017-11-20 
 */


//description = "Class manage docker event logs of applications on different devices ,insert box logs on portal,and list them.." 
@Path("/dockerevent")
@Api( value = "/dockerevent",produces=MediaType.APPLICATION_JSON)
public class DockerEventEndpoint 
{
	@Context
	private HttpServletResponse response;


	/** Method processing HTTP POST requests, producing "application/json" MIME media type.
	 * <p>
	 * This method require DeviceApplicationVO object for add device,
	 * 
	 * </p>
	 * @param deviceVO object of DeviceVO.
	 * @param httpHeaders
	 * @return Json string
	 * @throws Exception 
	 */
	@POST
	@Consumes({MediaType.APPLICATION_JSON})
	@Path("{deviceId}/")
	@ApiOperation( value = "Add docker event logs of  applications of device in to db.",
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to Add docker event logs of  application.")
	} )
	public void addLogs(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,
			@ApiParam(value = "", required = true) @PathParam("deviceId") String deviceId, 
			@ApiParam(value = "add docker evnets object.", required = true) List<DockerEventVO> eventVOs) {
		mAddLogs(authToken, eventVOs);
	}
	
	/**
	 * Method processing HTTP GET requests, producing "application/json" MIME media-type.
	 * <p> 
	 * This method gives application's docker event logs
	 * </p>
	 * @param httpHeaders
	 * @return String that will be send back as a response of type json.
	 */
	@GET
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("{applicationId}/pages/{pageno}")
	@ApiOperation( value = "List application's docker event logs", 
	notes = "List application's docker event logs", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to get List application's docker event logs.")
	} )
	public void listLogs(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,
			@ApiParam(value = "", required = true) @PathParam("applicationId") String applicationId, 
			@ApiParam(value = "requested page no ", required = true) @Min(1) @PathParam("pageno")  int pageNo,
			@ApiParam(value = "", required = false) @QueryParam("pagesize") @DefaultValue("10") int pageSize)
	{
		mListLogs( authToken,applicationId,  pageNo,pageSize);
	}
	

	private void mAddLogs(String authToken, List<DockerEventVO> eventVOs) 
	{
		try 
		{

			if(authToken.toLowerCase().startsWith(Constant.JWT_BEARER.toLowerCase())) {

				new AuthHelper().checkJwtToken(authToken, response);
			}
			else{
			//CHECK AUTH TOKEN...
			new GrpcAuthHelper().checkAuthorization(authToken);
			}
			List<String> logIDs = new DockerEvents().insert(eventVOs);

			//Create response 
			Map<String, Object> result=new HashMap<>();
			result.put(Constant.DATA, logIDs);
			ReturnObject.createResponse(Constant.SUCCESS, result, null, response);
		} 
		catch (Exception e) 
		{
			PALogger.ERROR(e);	
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, e);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to add docker event log.", e);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			PALogger.ERROR(e);	
		}
	}
	
	private void mListLogs(String authToken, String appID, int pageNum, int pageSize)
	{
		try 
		{
			//CHECK AUTH TOKEN...
			new GrpcAuthHelper().checkAuthorization(authToken);
			ReturnObject.createResponse(Constant.SUCCESS, new DockerEvents().listByPage(pageNum, appID,pageSize), null, response);
		} 
		catch (Exception e) 
		{
			PALogger.ERROR(e);	
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, e);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to list docker event log.", e);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			PALogger.ERROR(e);	
		}
		
	}
}
