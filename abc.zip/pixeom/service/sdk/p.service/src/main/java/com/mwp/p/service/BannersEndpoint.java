/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import com.mwp.common.ReturnObject;
import com.mwp.common.constant.Constant;
import com.mwp.common.vo.ErrorVo;
import com.mwp.logger.PALogger;
import com.mwp.p.authhelper.GrpcAuthHelper;
import com.mwp.p.common.enums.PortalDBEnum.AD_TYPE;
import com.mwp.p.common.vo.AdZoneVO;
import com.mwp.p.framework.AdZone;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/** <h1>BannersEndpoint</h1>
 * Class hosted at the URI path "/banners"
 * <p>
 * Class manage banner, return list of banner.
 * </p>
 * @author akh
 * @version 0.0.1
 * @since   2016-08-30 
 */

//description = "Class manage banner, return list of banner."
@Path("/banners")
@Api( value = "/banners")
public class BannersEndpoint 
{
	@Context
	private HttpServletResponse response;

	/**
	 * method to add ad zone object in database
	 * @param adZoneVO
	 * @param authToken
	 */
	@POST
	@Produces({ MediaType.APPLICATION_JSON })
	@Consumes({ MediaType.APPLICATION_JSON })
	@ApiOperation( value = "Add new ad zone", notes = "Add new ad zone")
	@ApiResponses
	( {
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "unable to Add new ad zone" ),
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized.")
	} )
	public void add(@ApiParam(value = "ad zone object", required = true) AdZoneVO adZoneVO,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken)
	{
		mAdd(adZoneVO, authToken);
	}

	/**
	 * method to edit sort order of zones
	 * @param sortOrder
	 * @param adId
	 * @param authToken
	 */
	@PUT
	@Produces({ MediaType.APPLICATION_JSON })
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("{adId}/sortOrder/{sortOrder}")
	@ApiOperation( value = "Edit sort order", notes = "Edit sort order")
	@ApiResponses
	( {
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "unable to edit new ad zone" ),
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized.")
	} )
	public void edit(@ApiParam(value = "sort order", required = true)  @PathParam( "sortOrder" ) int sortOrder,
			@ApiParam(value = "ad id", required = true) @PathParam( "adId" )  String adId,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken) 
	{
		mEdit(sortOrder, adId, authToken);
	}

	/**
	 * method to delete ad zone
	 * @param adId
	 * @param authToken
	 */
	@DELETE
	@Produces({ MediaType.APPLICATION_JSON })
	@Path("{adId}")
	@ApiOperation( value = "Delete ad zone", notes = "Delete ad zone")
	@ApiResponses
	( {
		@ApiResponse( code = HttpServletResponse.SC_OK, message = "ad zone deleted successfully" ),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "unable to delete ad."),
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized.")
	} )
	public void delete(@ApiParam(value = "ad id", required = true) @PathParam( "adId" )  String adId,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken)
	{
		mDelete(adId, authToken);
	} 


	/**
	 * method to list zones according to type
	 * @param type int value for AD_TYPE enum
	 * @param authToken
	 */
	@GET
	@Produces({ MediaType.APPLICATION_JSON })
	@Path("/type/{type}")
	@ApiOperation( value = "list all ad zone according to type.", notes = "list all ad zone according to type.")
	@ApiResponses
	( {
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "unable to list ad by type."),
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized.")
	} )
	public void listByType(@ApiParam(value = "type", required = true) @PathParam( "type" )  int type) 
	{
		mListByType(type);
	}

	/**
	 * method to list ad zone for given category
	 * @param categoryId
	 * @param authToken
	 */
	@GET
	@Produces({ MediaType.APPLICATION_JSON })
	@Path("/category/{categoryId}")
	@ApiOperation( value = "list all ad zone according to categoryId.", notes = "list all ad zone according to categoryId.")
	@ApiResponses
	( {
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "unable to get list of ad by category."),
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized.")		 
	} )
	public void listByCategory(@ApiParam(value = "categoryId", required = true) @PathParam( "categoryId" )  String categoryId,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken) 
	{
		mListByCategory(categoryId, authToken);
	}

	//PRIVATE METHOD


	private void mAdd(AdZoneVO adZoneVO, String authToken)
	{
		try {
			// CHECK AUTH TOKEN...
			new GrpcAuthHelper().checkAuthorization(authToken);

			Map<String, Object> resultMap = new HashMap<>();

			//add zone 
			AdZone adZoneObj= new AdZone();
			AdZoneVO returnObj = adZoneObj.add(adZoneVO);

			//generate return object
			resultMap.put(Constant.DATA, returnObj);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);
		} 
		catch (Exception e) 
		{
			if(e.getMessage().equals(Constant.UNAUTHORIZED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						e.getMessage(), e.getMessage());
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			PALogger.ERROR(e);	
		}
	}


	private void mEdit( int sortOrder, String adId, String authToken) 
	{
		try {
			// CHECK AUTH TOKEN...
			new GrpcAuthHelper().checkAuthorization(authToken);

			Map<String, Object> resultMap = new HashMap<>();

			//edit sort order
			AdZone adZoneObj= new AdZone();
			boolean result = adZoneObj.editSortOrder(sortOrder, adId);


			//generate return object
			resultMap.put(Constant.DATA, result);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);
		} 
		catch (Exception e) 
		{
			if(e.getMessage().equals(Constant.UNAUTHORIZED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						e.getMessage(), e.getMessage());
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			PALogger.ERROR(e);	
		}
	}


	private void mDelete(String adId, String authToken)
	{
		try {
			// CHECK AUTH TOKEN...
			new GrpcAuthHelper().checkAuthorization(authToken);

			Map<String, Object> resultMap = new HashMap<>();

			//delete ad 
			AdZone adZoneObj= new AdZone();
			boolean result = adZoneObj.delete(adId);

			//generate return object
			resultMap.put(Constant.DATA, result);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);
		} 
		catch (Exception e) 
		{
			if(e.getMessage().equals(Constant.UNAUTHORIZED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						e.getMessage(), e.getMessage());
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			PALogger.ERROR(e);	
		}
	} 



	private void mListByType(int type) 
	{
		try {

			Map<String, Object> resultMap = new HashMap<>();

			//list ad zone according to type defalut or app
			AdZone adZoneObj= new AdZone();
			List<AdZoneVO> lstAdZone = adZoneObj.listByType(AD_TYPE.values()[type]);

			//generate return object
			resultMap.put(Constant.DATA, lstAdZone);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);
		} 
		catch (Exception e) 
		{
			if(e.getMessage().equals(Constant.UNAUTHORIZED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						e.getMessage(), e.getMessage());
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			PALogger.ERROR(e);	
		}
	}


	private void mListByCategory(String categoryId, String authToken) 
	{
		try {
			// CHECK AUTH TOKEN...
			new GrpcAuthHelper().checkAuthorization(authToken);

			Map<String, Object> resultMap = new HashMap<>();

			//list ad zone according to category
			AdZone adZoneObj= new AdZone();
			List<AdZoneVO> lstAdZone = adZoneObj.listByCategory(categoryId);

			//generate return object
			resultMap.put(Constant.DATA, lstAdZone);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);
		} 
		catch (Exception e) 
		{
			if(e.getMessage().equals(Constant.UNAUTHORIZED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						e.getMessage(), e.getMessage());
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			PALogger.ERROR(e);	
		}
	}

	


}
