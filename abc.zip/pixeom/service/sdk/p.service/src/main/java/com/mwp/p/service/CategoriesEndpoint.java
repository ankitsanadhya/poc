/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.mwp.p.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import javax.validation.ValidationException;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import com.google.gson.Gson;
import com.mwp.common.ReturnObject;
import com.mwp.common.constant.Constant;
import com.mwp.common.enums.ActivityOperation;
import com.mwp.common.vo.CategoryVO;
import com.mwp.common.vo.ErrorVo;
import com.mwp.logger.PALogger;
import com.mwp.p.authhelper.GrpcAuthHelper;
import com.mwp.p.framework.ActivityLogs;
import com.mwp.p.framework.Categories;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/** <h1>CategoriesEndpoint</h1>
 * Class hosted at the URI path "/categories"
 * <p>
 * Class manage category, return List of top category according to application which are most installed by user,
 * list of category according to paging, gives category detail according to requested categoryId,
 * add/update category status/name, List of categories according to requested search text, list default category.
 * </p>
 * @author akh
 * @version 0.0.1
 * @since   2016-08-30 
 */

//description = "Class manage category, return List of top category according to application which are most installed by user,"
		// "list of category according to paging, gives category detail according to requested categoryId,"
		// "add/update category status/name, List of categories according to requested search text, list default category." 

@Path("/categories")
@Api( value = "/categories",produces=MediaType.APPLICATION_JSON)
public class CategoriesEndpoint {

	@Context
	private HttpServletResponse response;

	/**
	 * Method processing HTTP GET requests, producing "application/json" MIME media-type.
	 * 
	 * <p> This method gives List of default category.</p>
	 * 
	 * @param httpHeaders
	 * @return String that will be send back as a response of type json.
	 */
	@GET
	@Consumes({MediaType.APPLICATION_JSON})
	@ApiOperation( value = "List default category", 
	notes = "List of default category.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "unable to list default Category." )		 			 
	} )
	public void listDefault(){
		mListDefault();
	}
	
	/**
	 * Method processing HTTP GET requests, producing "application/json" MIME media-type.
	 * 
	 * <p> This method gives List of categories using paging.</p>
	 * 
	 * @param pageNo request previous page information.
	 * @param pageSize request number of categories give in one call.
	 * @param httpHeaders
	 * @return String that will be send back as a response of type json.
	 */
	@GET
	@Consumes({MediaType.APPLICATION_JSON})
	@Path("/pages/{pageno}")
	@ApiOperation( value = "List of category using paging.", 
	notes = "List of category using paging.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "unable to list Categories." )			 			 
	} )
	public void list(@ApiParam(value = "requested page no for list category.", required = false) @Min(1)@PathParam("pageno") @DefaultValue("1") int pageNo,  
			@ApiParam( value = "requested page size number of element return in a list category.", required = false )@Min(1) @QueryParam("pagesize") @DefaultValue( "20" ) int pageSize
			)throws ValidationException{
		mList(pageNo, pageSize);
	}

	/**
	 * Method processing HTTP GET requests, producing "application/json" MIME media-type.
	 * 
	 * <p> This method gives category detail according to requested categoryId.</p>
	 * @param categoryId requested categoryId for getting detail of category.
	 * @param httpHeaders
	 * @return
	 */
	@GET
	@Consumes({MediaType.APPLICATION_JSON})
	@Path("/{id}")
	@ApiOperation( value = "category detail according to requested categoryId.", 
	notes = "category detail according to requested categoryId.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to get category detail."),
		@ApiResponse(code = HttpServletResponse.SC_NOT_FOUND, message = "No category found with requested category ID."),
	} )
	public void getCategory(@ApiParam(value = "requested categoryId for getting detail of category.", required = true) @NotNull @PathParam("id") String categoryId, 
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken)throws ValidationException{
		mGetCategory(authToken, categoryId);
	}

	/**
	 * Method processing HTTP GET requests, producing "application/json" MIME media-type.
	 * <p> This method gives List of category according to requested 'search text' and
	 * using paging.</p>
	 * @param pageNo request previous page information.
	 * @param pageSize request number of categories give in one call.
	 * @param httpHeaders
	 * @return String that will be send back as a response of type json.
	 */
	@GET
	@Consumes({MediaType.APPLICATION_JSON})
	@Path("/search/pages/{pageno}")
	@ApiOperation( value = "List category", 
	notes = "List of category according to requested 'search text' and using paging.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to search category."), 			 
	} )
	public void search(
			@ApiParam( value = "requested page no for list application.", required = false ) @Min(1)@PathParam("pageno") @DefaultValue( "1" ) int pageNo, 
			@ApiParam( value = "requested page size number of element return in a list application.", required = false )@Min(1) @QueryParam("pagesize") @DefaultValue( "5" ) int pageSize, 
			@ApiParam( value = "list category where name start with 'search text'.", required = true ) @QueryParam("searchtext") String searchtext
			)throws ValidationException{
		mSearch(pageNo, pageSize, searchtext);
	}
	
	

	/**
	 * Method processing HTTP GET requests, producing "application/json" MIME media-type.
	 * 
	 * <p> This method gives suggested list of category which start with 'search text' category name.</p>
	 * @param searchText
	 * @param httpHeaders
	 * @return String that will be send back as a response of type json.
	 */
	@GET
	@Consumes({MediaType.APPLICATION_JSON})
	@Path("/suggestion")
	@ApiOperation( value = "List suggested category", 
	notes = "List of category according to requested 'search text'.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to get suggestion category detail."),
	} )
	public void suggestion(@ApiParam( value = "list category where name start with 'search text'.", required = true ) @QueryParam("searchtext") String searchText
			){
		mSuggestion(searchText);
	}

	/** Method processing HTTP POST requests, producing "application/json" MIME media type.
	 * <p>
	 * This method add category object, if not exist with same name in db.
	 * </p>
	 * @param categoryVO add category object in db.
	 * @param httpHeaders
	 * @return Json string
	 * @throws Exception 
	 */
	@POST
	@Consumes({MediaType.APPLICATION_JSON})
	@ApiOperation( value = "add category.", 
	notes = "add category object, if not exist with same name in db.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to add category."),	 			 
	} )
	public void addCategory(@ApiParam(value = "updated category object.", required = true) @Valid @NotNull CategoryVO categoryVO,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken) throws ValidationException {
		mAddCategory(authToken, categoryVO);
	}

	/** Method processing HTTP PUT requests, producing "application/json" MIME media type.
	 * <p>
	 * This method update category status/name which id specified in category object,
	 * </p>
	 * @param categoryVO updated category object which we update in db.
	 * @param httpHeaders
	 * @return Json string
	 * @throws Exception 
	 */
	@PUT
	@Consumes({MediaType.APPLICATION_JSON})
	@Path("/{id}")
	@ApiOperation( value = "update category.", 
	notes = "update category status/name which id specified in category object.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to update category."),	 			 
	} )
	public void editCategory(@ApiParam(value = "requested categoryId for getting detail of category.", required = true) @NotNull @PathParam("id") String categoryId,
			@ApiParam(value = "updated category object.", required = true)  @Valid @NotNull CategoryVO categoryVO,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken)throws ValidationException {
		mEditCategory(authToken, categoryVO);
	}

	/** Method processing HTTP DELETE requests, producing "application/json" MIME media type.
	 * <p>
	 * This method change category status = 'SUSPENDED' in category db.
	 * </p>
	 * @param categoryId of category which we want to remove.
	 * @param httpHeaders
	 * @return
	 * @throws Exception 
	 */
	@DELETE
	@Consumes({MediaType.APPLICATION_JSON})
	@Path("/{id}")
	@ApiOperation( value = "remove category.", 
	notes = "remove category change status = 'SUSPENDED' in db.")
	@ApiResponses( {
		@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to delete category detail."),			 			 
	} )
	public void deleteCategory(@ApiParam(value = "requested categoryId for getting detail of category.", required = true) @NotNull @PathParam("id") String categoryId,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken) throws ValidationException{
		mDeleteCategory(authToken, categoryId);
	}

	
	private void mList( int pageNo, int pageSize)
	{
		try {
			Categories categories=new Categories();
			Map<String, Object> resultMap=categories.listCategories(pageNo,pageSize);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);

		} catch (Exception e) {

			PALogger.ERROR(e);	
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to list categories.", "Unable to list categories");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);

		}
	}

	private void mGetCategory(String authToken, String categoryId)
	{
		try {
			//CHECK AUTH TOKEN...
			new GrpcAuthHelper().checkAuthorization(authToken);

			Categories categories=new Categories();
			CategoryVO categoryVO =categories.getCategory(categoryId);
			if (categoryVO!=null) {
				Map<String, Object> resultMap = new HashMap<>();
				resultMap.put(Constant.DATA, categoryVO);
				ReturnObject.createResponse(Constant.SUCCESS, resultMap, null,
						response);
			}
			else
			{
				throw new Exception(Constant.NOTFOUND);
			}

		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTFOUND)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_NOT_FOUND,
						"Category not found", "No category found with requested category ID");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to get category details", "Unable to get category details");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			PALogger.ERROR(e);	
		}

	}

	private void mEditCategory(String authToken, CategoryVO categoryVO)
	{
		try {
			//CHECK AUTH TOKEN...
			String userId = new GrpcAuthHelper().checkAuthorization(authToken);
			Categories categories=new Categories();
			CategoryVO editedCategoryVO =categories.editCategory(categoryVO);
			//add activity in database
			new ActivityLogs().insert(userId, ActivityOperation.editCategory.name(), new Gson().toJson(categoryVO));
			Map<String, Object> resultMap=new HashMap<>();
			resultMap.put(Constant.DATA, editedCategoryVO);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);

		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to update category.", "Unable to update category.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			PALogger.ERROR(e);	
		}
	}

	private void mDeleteCategory(String authToken, String categoryId)
	{
		try {
			//CHECK AUTH TOKEN...
			String userId = new GrpcAuthHelper().checkAuthorization(authToken);
			Categories categories=new Categories();
			categories.deleteCategory(categoryId);
			//add activity in database
			Map<String, String> map = new HashMap<>();
			map.put("categoryId", categoryId);
			new ActivityLogs().insert(userId, ActivityOperation.deleteCategory.name(), new Gson().toJson(map));
			Map<String, Object> resultMap=new HashMap<>();
			resultMap.put(Constant.DATA, categoryId);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);

		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to delete category", "Unable to delete category");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			PALogger.ERROR(e);	
		}

	}

	private void mAddCategory(String authToken, CategoryVO categoryVO)
	{
		try {
			//CHECK AUTH TOKEN...
			String userId = new GrpcAuthHelper().checkAuthorization(authToken);
			Categories categories=new Categories();
			CategoryVO addedCategoryVO =categories.addCategory(categoryVO);
			//add activity in database
			new ActivityLogs().insert(userId, ActivityOperation.addCategory.name(), new Gson().toJson(addedCategoryVO));
			Map<String, Object> resultMap=new HashMap<>();
			resultMap.put(Constant.DATA, addedCategoryVO);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);

		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to add category.", "Unable to add category.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			PALogger.ERROR(e);	
		}
	}

	private void mSearch( int pageNo, int pageSize, String searchtext)
	{
		try {

			Categories categories=new Categories();
			Map<String, Object> resultMap =categories.listCategories(pageNo,pageSize,searchtext);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);

		} catch (Exception e) {

				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to find  category.", "Unable to find  category");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);

		}
	}

	private void mListDefault()
	{
		try {

			Categories categories=new Categories();
			List<CategoryVO> categoryVOs=categories.listDefaultCategories();
			Map<String, Object> resultMap=new HashMap<>();
			resultMap.put(Constant.DATA, categoryVOs);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);

		} catch (Exception e) {
			PALogger.ERROR(e);	
			ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to list default categories.", "Unable to list default categories");
			ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);

		}
	}

	private void mSuggestion( String searchText)
	{
		try {
//			//CHECK AUTH TOKEN...
			Categories categories=new Categories();
			Map<String, Object> hashMap =categories.listCategories(searchText);
			ReturnObject.createResponse(Constant.SUCCESS, hashMap, null, response);

		} catch (Exception e) {

			PALogger.ERROR(e);	
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to list categories.", "Unable to list categories");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);

		}
	}

}
