/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
/**
 * 
 */
package com.mwp.p.service;

import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;
import javax.validation.constraints.NotNull;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import com.mwp.common.ReturnObject;
import com.mwp.common.constant.Constant;
import com.mwp.common.constant.PermissionResourceKeys;
import com.mwp.common.constant.PermissionResources;
import com.mwp.common.vo.AuthorizationsVO;
import com.mwp.common.vo.ErrorVo;
import com.mwp.logger.PALogger;
import com.mwp.p.authhelper.GrpcAuthHelper;
import com.mwp.p.framework.Applications;
import com.mwp.p.framework.docker.DockerImageVulnerabilities;
import com.mwp.p.utility.Utility;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * <h1>DockerRegistryEndpoint</h1> Class hosted at the URI path "/registry"
 * <p>
 * Class manage functions, analyze images stored in a private or public Docker registry
 * for security vulnerabilities.
 * </p>
 * 
 * @author RA
 * @version 0.0.1
 * @since 2017-11-20
 */

//description = "Class manage functions, analyze images stored in a private or public Docker registry for security vulnerabilities."
@Path("/registry")
@Api(value = "/registry", produces = MediaType.APPLICATION_JSON)
public class DockerRegistryEndpoint {

	@Context
	private HttpServletResponse response;
	
	@GET
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/{appid}/image/analyse")
	@ApiOperation(value = "LayerCount and Vulnerabilities of requested image", notes = "LayerCount and Vulnerabilities of requested image (Return response in RAW format)", response = HashMap.class)
	@ApiResponses({
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to get LayerCount and Vulnerabilities of requested image.") 
		})
	public void checkImageVulnerabilities(@ApiParam(value = "Authorization token", required =true) @HeaderParam("Authorization") String authToken,
			@ApiParam(value = "id of application.", required = true) @PathParam("appid") String appId,
			@ApiParam(value = "image path of docker registry.", required = true)  @QueryParam("imagepath") @NotNull String imagepath,
			@ApiParam(value = "vulnerabilities with severity level higher than or equal to this threshold will be outputted. Supported levels are Unknown, Negligible, Low, Medium, High, Critical, Defcon1. Default is Unknown.", required = false)  @QueryParam("severitylevel") String severityLevel,
			@ApiParam(value = "how many outputted vulnerabilities Klar can tolerate before returning.", required = false)  @QueryParam("threshold") String threshold) {
		mCheckImageVulnerabilities(authToken, appId, imagepath);
	}
	
	private void mCheckImageVulnerabilities(String authToken, String appId, String imagePath) {
		try {
			
			AuthorizationsVO authorizationsVO = new GrpcAuthHelper().getAuthorizationsVO(authToken);

			Applications applications=new Applications();

			String appOwnerId = applications.getUserIdOfApp(appId);
			if(!appOwnerId.equals(authorizationsVO.getUserId())){
				Utility.checkPermission(authorizationsVO.getGroupPermissions(), PermissionResources.getString(PermissionResourceKeys.APP_VERSION_INSTALL), appId);
			}

			/* * create a basic auth to get authentication of private registry Server */  
			String creds = authToken + ":" + appId; 
			authToken = Base64.getEncoder().encodeToString(creds.getBytes());
			/*
			 *split image path and get version and path  
			 */
			String[] splitPath = imagePath.split(":");
			imagePath = splitPath[0];
			String imageTag =  splitPath[1];
			
			

			DockerImageVulnerabilities dockerImageVulnerabilities = new DockerImageVulnerabilities();
			String result = dockerImageVulnerabilities.checkImageVulnerabilities(imagePath, authToken, imageTag);

			Map<String, Object> resultMap = new HashMap<>();
			resultMap.put(Constant.DATA, result);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null,response);

		} catch (Exception e) {
			PALogger.ERROR(e);	
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			} else {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Unable to validate image.", "Unable to validate image.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
		}
	}
	
	
	/*Status:
		  Implementation of get Authentication when request failed using response header on both Public and private registry server DONE.
		  Implementation of get Manifests from Public registry server DONE
		  Implementation of push layer on Clair server from both Public and private registry server.DONE
		  Implementation of analyze layer on clair server.DONE*/
	
}
