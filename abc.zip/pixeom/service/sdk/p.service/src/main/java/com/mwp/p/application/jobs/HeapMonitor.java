/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.application.jobs;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;

import org.apache.commons.io.FileUtils;

import com.mwp.common.constant.Constant;
import com.mwp.common.interfaces.IScheduledJob;
import com.mwp.logger.PALogger;

public class HeapMonitor implements IScheduledJob{

	private long defaultInterval = Constant.getHeapDumpInterval();
	private int dumpsToKeep = Constant.getHeapDumpsToKeep();
	private File monitorFlagFile = new File("/opt/app_engine/heapMonitor");
	private String dumpBasePath  = "/opt/app_engine/heapDumps/";
	private File heapDumpPath = new File(dumpBasePath);
	private String baseLineFileName = "hd-";
	private String baseLineFileExtension = ".hprof";
	private HeapDumper heapDumper = new HeapDumper();
	private SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
	
	@Override
	public void init() {
		monitorHeap();
	}

	private void monitorHeap(){
		//Create directory structure if does not exists.
		if(!heapDumpPath.exists())
			heapDumpPath.mkdirs();
		//Cleanup on startup in case there are left overs from last runs.
		rotateDumps();		
		String dumpFilePath = dumpBasePath + baseLineFileName; 
		while(true) {
			try {
				//Take heap dump if heap monitor file exists.
				if(isMonitor()){
					String dumpFileName = dumpFilePath + dateFormatter.format(new Date()) + baseLineFileExtension; 
					heapDumper.dumpHeap(dumpFileName, false);
					//Cleanup dumps
					rotateDumps();
				}
			} catch(Exception e) {
				PALogger.ERROR(e);	
			} finally {
				printHeapMemory(); //Printed Heap memory in log files - DB 
				try {
					Thread.sleep(defaultInterval);
				} catch (InterruptedException e) {
					PALogger.ERROR(e);
					//Thread.currentThread().interrupt();
				}
			}
		}

	}

	private void rotateDumps(){
		/*
		 * 1. List files from heap dump path.
		 * 2. Filter files which starts with base name
		 * 3. Order by last modified time of dump files - latest at top.
		 * 4. Skip number of files to keep as history.
		 * 5. Delete rest of the files.
		 * */
		Arrays.asList(heapDumpPath.listFiles()).stream()
				.filter(file -> isNameLikeBaseLine(file.getName()))
				.sorted(new Comparator<File>() {
					@Override
					public int compare(File o1, File o2) {
						int answer;
						if (o1.lastModified() == o2.lastModified()) {
							answer = 0;
						} else if (o1.lastModified() > o2.lastModified()) {
							answer = -1;
						} else {
							answer = 1;
						}
						return answer;
					}
				}).skip(dumpsToKeep).forEach(file-> FileUtils.deleteQuietly(file));;
	}
	
	private boolean isNameLikeBaseLine(String fileName){
		//return true if file name starts with base dump file name then return true otherwise false.
		return fileName.startsWith(baseLineFileName);
	}

	private boolean isMonitor(){
		//return weather the heap monitor file exists or not.
		return monitorFlagFile.exists();
	}
	
	private void printHeapMemory() {
		try {
			long heapSize = Runtime.getRuntime().totalMemory();
			PALogger.INFO("##### UPDATE BOX_STATICS_ON_PORTAL COMPLETED heapSize  ###### "+ heapSize);
			long heapMaxSize = Runtime.getRuntime().maxMemory();
			PALogger.INFO("##### UPDATE BOX_STATICS_ON_PORTAL COMPLETED heapMaxSize  ###### "+ heapMaxSize);
			long heapFreeSize = Runtime.getRuntime().freeMemory();
			PALogger.INFO("##### UPDATE BOX_STATICS_ON_PORTAL COMPLETED heapFreeSize  ###### "+ heapFreeSize);
		} catch (Exception e) {
			//DO Nothing
		}
	}
}
