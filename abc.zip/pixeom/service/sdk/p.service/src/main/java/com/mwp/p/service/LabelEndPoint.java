/** 
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com) 
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL 
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC. 
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD 
 * IN STRICTEST CONFIDENCE. 
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */ 

package com.mwp.p.service;

import java.sql.SQLIntegrityConstraintViolationException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import com.google.gson.Gson;
import com.mwp.common.Common;
import com.mwp.common.ReturnObject;
import com.mwp.common.StringFunctions;
import com.mwp.common.constant.Constant;
import com.mwp.common.enums.ActivityOperation;
import com.mwp.common.vo.DeviceVO;
import com.mwp.common.vo.ErrorVo;
import com.mwp.common.vo.LabelVO;
import com.mwp.logger.PALogger;
import com.mwp.p.authhelper.GrpcAuthHelper;
import com.mwp.p.framework.ActivityLogs;
import com.mwp.p.framework.Labels;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/** <h1>LabelEndpoint</h1>
 * Class hosted at the URI path "/labels"
 * <p>
 * Class manage labels, list labels, delete and edit labels in which device can hierarchically manage
 * </p>
 * @author ps
 * @version 0.0.1
 * @since   2017-10-31 
 */
//description = "Class manage labels, list labels."
@Path("/labels")
@Api( value = "/labels",produces=MediaType.APPLICATION_JSON)
public class LabelEndPoint 
{
	@Context
	private HttpServletResponse response;

	/** Method processing HTTP POST requests, producing "application/json" MIME media type.
	 * <p>
	 * This method require labelVO object for add label,
	 * LabelVO require these properties (labelName, parentLabelId, userId)
	 * </p>
	 * @param labelVO object of LabelVO type.
	 * @param httpHeaders
	 * @return Json string
	 * @throws Exception 
	 */	
	@POST
	@Consumes({MediaType.APPLICATION_JSON})
	@ApiOperation( value = "add lable.",
	notes = "add lable.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to add new label." )	 
	} )
	public void addLabel(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,
			@ApiParam(value = "add label object.", required = true) LabelVO labelVO) {
		mAddLabel(authToken, labelVO);
	}

	private void mAddLabel(String authToken, LabelVO labelVO) {
		try {
			//CHECK AUTH TOKEN...
			String userId = new GrpcAuthHelper().checkAuthorization(authToken);
			//call addLabel method.
			labelVO.setUserId(userId);
			labelVO.setLabelId(Common.getRandomId());
			if(StringFunctions.isNullOrWhitespace(labelVO.getParentLabelId()))
				labelVO.setParentLabelId(Constant.ROOT_LABEL_ID);

			labelVO = new Labels().addLabel(labelVO); 
			Map<String, Object> resultMap=new HashMap<>();
			resultMap.put(Constant.DATA, labelVO);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);
		} 
		 catch (SQLIntegrityConstraintViolationException e) {
			 PALogger.ERROR(e);
			 ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Label name already exists.", "Label name already exists.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
		
		 }
		catch (Exception e) {
			PALogger.ERROR(e);
			if(e.getMessage().equals(Constant.UNAUTHORIZED)) {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			} else {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to add new label.", "Unable to add label.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
		}
	}


	/** Method processing HTTP POST requests, producing "application/json" MIME media type.
	 * <p>
	 * This method require labelVO object for add label,
	 * LabelVO require these properties (labelName, parentLabelId, userId)
	 * </p>
	 * @param labelVO object of LabelVO type.
	 * @param httpHeaders
	 * @return Json string
	 * @throws Exception 
	 */	
	@PUT
	@Consumes({MediaType.APPLICATION_JSON})
	@ApiOperation( value = "edit lable.",
	notes = "edit lable name.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to edit label name." )	 
	} )
	public void editLabel(
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,			
			@ApiParam(value = "edit label object.", required = true) LabelVO labelVO) 
	{
		mEditLabel(authToken, labelVO);
	}

	private void mEditLabel(String authToken, LabelVO labelVO) {
		try {
			//CHECK AUTH TOKEN...
			new GrpcAuthHelper().checkAuthorization(authToken);
			//call addLabel method.

			labelVO = new Labels().editLabel(labelVO); 
			Map<String, Object> resultMap=new HashMap<>();
			resultMap.put(Constant.DATA, labelVO);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);

		}
		catch (SQLIntegrityConstraintViolationException e) {
			
			PALogger.ERROR(e);	
			ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Label name already exists.", "Label name already exists.");
			ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
		}
		catch (Exception e) {
			PALogger.ERROR(e);	
			if(e.getMessage().equals(Constant.UNAUTHORIZED)) {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			} else {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to edit label name.", "Unable to edit label name.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			PALogger.ERROR(e);	
		}
	}

	/**
	 * Method processing HTTP GET requests, producing "application/json" MIME media-type.
	 * <p> 
	 * This method gives list of all hierarchy labels.
	 * </p>
	 * @param httpHeaders
	 * @return String that will be send back as a response of type json.
	 */
	@GET
	@Consumes({ MediaType.APPLICATION_JSON })
	@ApiOperation( value = "List of labels.", 
	notes = "List of labels.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to list labels.")
	} )
	public void listLabels(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,
			@ApiParam(value = "id of parent label", required = true) @QueryParam("parentlabelid") String parentLabelId)
	{
		mListLabels(authToken);
	}

	private void mListLabels(String authToken)
	{
		try {
			//CHECK AUTH TOKEN...
			String userId = new GrpcAuthHelper().checkAuthorization(authToken);

		
			Labels labels=new Labels();
			List<LabelVO>listLablesVOs = labels.listLabels(userId);
			Map<String, Object> resultMap=new HashMap<>();
			resultMap.put(Constant.DATA, listLablesVOs);

			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);

		} catch (Exception e) {
			PALogger.ERROR(e);	
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to list labels.", "Unable to list labels.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			
		}
	}

	/**
	 * Method processing HTTP GET requests, producing "application/json" MIME media-type.
	 * <p> 
	 * This method gives list of all hierarchy labels.
	 * </p>
	 * @param httpHeaders
	 * @return String that will be send back as a response of type json.
	 */
	@DELETE
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("lid/{labelid}")
	@ApiOperation( value = "Delete label.", 
	notes = "Delete label.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to delete label.")
	} )
	public void deletelabel(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,
			@ApiParam(value = "id of label.", required = true) @PathParam("labelid") String labelId)
	{
		mdeletelabel(authToken, labelId);
	}

	private void mdeletelabel(String authToken, String labelId)
	{
		try {
			//CHECK AUTH TOKEN...
			String userId = new GrpcAuthHelper().checkAuthorization(authToken);
			if(labelId.equals(Constant.ROOT_LABEL_ID)){
				throw new Exception("Can not delete "+ Constant.ROOT_LABEL_NAME);
			}
		
			Labels labels=new Labels();
			Boolean issuccess = labels.deleteLabel(labelId, userId);
			Map<String, Object> resultMap=new HashMap<>();
			resultMap.put(Constant.DATA, issuccess);

			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);

		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to delete label.", "Unable to delete label.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			PALogger.ERROR(e);	
		}
	}

	/** Method processing HTTP POST requests, producing "application/json" MIME media type.
	 * <p>
	 * This method require labelId and device id to add device to particular label.
	 * LabelVO require these properties (labelName, parentLabelId, userId)
	 * </p>
	 * @param labelVO object of LabelVO type.
	 * @param httpHeaders
	 * @return Json string
	 * @throws Exception 
	 */ 
	@GET
	@Consumes({MediaType.APPLICATION_JSON})
	@Path("lid/{labelid}")
	@ApiOperation( value = "get device of label.",
	notes = "get device from label.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to get device of label." )  
	} )
	public void getDevicesofLabel(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,
			@ApiParam(value = "id of label.", required = true) @PathParam("labelid") String labelId)
	{
		mgetDevicesofLabel(authToken, labelId);
	}

	private void mgetDevicesofLabel(String authToken, String labelId)
	{
		try {
			//CHECK AUTH TOKEN...
			String userId = new GrpcAuthHelper().checkAuthorization(authToken);

			List<DeviceVO> lst = new Labels().getDevicesofLabel(labelId, userId);
			Map<String, Object> resultMap=new HashMap<>();
			resultMap.put(Constant.DATA, lst);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);

		} catch (Exception e) {
			PALogger.ERROR(e);	
			if(e.getMessage().equals(Constant.UNAUTHORIZED)) {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			} else {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to get device of label.", "Unable to get device of label.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			PALogger.ERROR(e);	
		}
	}

	/** Method processing HTTP POST requests, producing "application/json" MIME media type.
	 * <p>
	 * This method require labelId and device id to add device to particular label.
	 * LabelVO require these properties (labelName, parentLabelId, userId)
	 * </p>
	 * @param labelVO object of LabelVO type.
	 * @param httpHeaders
	 * @return Json string
	 * @throws Exception 
	 */ 
	@POST
	@Consumes({MediaType.APPLICATION_JSON})
	@Path("lid/{labelid}/did/{deviceid}")
	@ApiOperation( value = "add device to label.",
	notes = "add Device to lable.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to update device label." )  
	} )
	public void addDeviceToLabel(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,
			@ApiParam(value = "id of label.", required = true) @PathParam("labelid") String labelId,
			@ApiParam(value = "id of device.", required = true) @PathParam("deviceid") String deviceId)
	{
		mUpdateDeviceLabel(authToken, labelId, deviceId);
	}

	/** Method processing HTTP POST requests, producing "application/json" MIME media type.
	 * <p>
	 * This method require labelId and device id to add device to particular label.
	 * LabelVO require these properties (labelName, parentLabelId, userId)
	 * </p>
	 * @param labelVO object of LabelVO type.
	 * @param httpHeaders
	 * @return Json string
	 * @throws Exception 
	 */ 
	@POST
	@Consumes({MediaType.APPLICATION_JSON})
	@Path("lid/{labelid}/action/{action}")
	@ApiOperation( value = "add device to label.",
	notes = "add Devices to lable.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to add device to label." )  
	} )
	public void addDeviceLabel(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,
			@ApiParam(value = "id of label.", required = true) @PathParam("labelid") String labelId,
			@ApiParam(value = "which action we perform move/copy.", required = true) @PathParam("action") String action,
			@ApiParam(value = "list of devices.", required = true) List<String> listDeviceIds)

	{
		mAddDeviceLabel(authToken, labelId, listDeviceIds, action);
	}

	private void mAddDeviceLabel(String authToken, String labelId,  List<String> deviceIds, String action)
	{
		try {
			//CHECK AUTH TOKEN...
		String userId = 	new GrpcAuthHelper().checkAuthorization(authToken);
			new Labels().addDeviceLabel(labelId, deviceIds, action);
			//insert activity
			Map<String, Object> map = new HashMap<>();
			map.put("labelId", labelId);
			map.put("action", action);
			map.put("deviceIds", deviceIds);
			new ActivityLogs().insert(userId, ActivityOperation.addDeviceLabel.name(), new Gson().toJson(map));
			Map<String, Object> resultMap=new HashMap<>();
			resultMap.put(Constant.DATA, true);

			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);
		} catch (Exception e) {
			PALogger.ERROR(e);	
			if(e.getMessage().equals(Constant.UNAUTHORIZED)) {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			} else {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to add device to label.", "Unable to add device to label.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			PALogger.ERROR(e);	
		}
	}

	private void mUpdateDeviceLabel(String authToken, String labelId, String deviceId)
	{
		try {
			//CHECK AUTH TOKEN...
		String userId =	new GrpcAuthHelper().checkAuthorization(authToken);

			DeviceVO deviceVO = new Labels().updateDeviceLabel(labelId, deviceId);
			
			//insert activity
			Map<String, Object> map = new HashMap<>();
			map.put("labelId", labelId);
			map.put("deviceId", deviceId);
			new ActivityLogs().insert(userId, ActivityOperation.updateDeviceLabel.name(), new Gson().toJson(map));
			Map<String, Object> resultMap=new HashMap<>();
			resultMap.put(Constant.DATA, deviceVO);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);

		} catch (Exception e) {
			PALogger.ERROR(e);	
			if(e.getMessage().equals(Constant.UNAUTHORIZED)) {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			} else {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to update device label.", "Unable to update device label.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			PALogger.ERROR(e);	
		}
	}

	/** Method processing HTTP POST requests, producing "application/json" MIME media type.
	 * <p>
	 * This method require labelId and device id to add device to particular label.
	 * LabelVO require these properties (labelName, parentLabelId, userId)
	 * </p>
	 * @param labelVO object of LabelVO type.
	 * @param httpHeaders
	 * @return Json string
	 * @throws Exception 
	 */ 
	@DELETE
	@Consumes({MediaType.APPLICATION_JSON})
	@Path("lid/{labelid}/did/{deviceid}")
	@ApiOperation( value = "add device to label.",
	notes = "delete Device from lable.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to delete device to label." )  
	} )
	public void deleteDeviceFromLabel(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,
			@ApiParam(value = "id of label.", required = true) @PathParam("labelid") String labelId,
			@ApiParam(value = "id of device.", required = true) @PathParam("deviceid") String deviceId)
	{
		mDeleteDeviceFromLabel(authToken, deviceId, labelId);
	}

	private void mDeleteDeviceFromLabel(String authToken, String deviceId, String labelId)
	{
		try {
			//CHECK AUTH TOKEN...
			String userId = new GrpcAuthHelper().checkAuthorization(authToken);

			boolean isSuccess = new Labels().deleteDeviceFromLabel(deviceId, labelId);
			//insert activity
			Map<String, Object> map = new HashMap<>();
			map.put("labelId", labelId);
			map.put("deviceId", deviceId);
			new ActivityLogs().insert(userId, ActivityOperation.deleteDeviceLabel.name(), new Gson().toJson(map));

			ReturnObject.createResponse(Constant.SUCCESS, isSuccess, null, response);

		} catch (Exception e) {
			PALogger.ERROR(e);	
			if(e.getMessage().equals(Constant.UNAUTHORIZED)) {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			} else {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to delete device to label.", "Unable to add device to label.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			PALogger.ERROR(e);	
		}
	}
}
