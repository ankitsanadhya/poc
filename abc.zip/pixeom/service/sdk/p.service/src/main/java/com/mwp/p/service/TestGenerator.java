/** 
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com) 
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL 
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC. 
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD 
 * IN STRICTEST CONFIDENCE. 
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */ 

package com.mwp.p.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import com.mwp.logger.PALogger;
import com.mwp.p.dal.engine.PortalDatabaseEngine;

public class TestGenerator {

	public static void main(String[] args)
	{
//		int start=Integer.parseInt(args[0]);
//		int end=Integer.parseInt(args[1]);
//		for (int i = start; i <= end; i++) {
//			try
//			{
//				int deviceId = i;
//				String mac = UUID.randomUUID().toString();
//				String name = UUID.randomUUID().toString();
//				String nodeId = "n_" + deviceId ;
//
//				//PS start 
//
//				List<String> queries =   new  ArrayList<>();
//				String nativeAppId = "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36";
//				String deviceQuery =  "INSERT INTO devices ( "
//						+ " deviceId,"
//						+ " userId,"
//						+ " platformId,"
//						+ " deviceStatus,"
//						+ " deviceName, "
//						+ " deviceType )" + 
//						" VALUES ( '" 
//						+ deviceId  
//						+ "' , '6f40d06b626741019534a4fef6dd6a97',"
//						+ " '7dd8b77ff34e4ad4a8e10a93a94d8102',"
//						+ " 0,"
//						+ " '" + name + "',"
//						+ " 0 ) "
//						+ " ON DUPLICATE KEY UPDATE userId = '6f40d06b626741019534a4fef6dd6a97', platformId = '7dd8b77ff34e4ad4a8e10a93a94d8102',"
//						+ " deviceName = '" + deviceId + "', deviceStatus = 0";
//
//
//				//PS end
//				String machineId = "Win32";
//				String nodeQuery =  "INSERT INTO nodes ( "
//						+ "nodeId,"
//						+ " deviceName, "
//						+ " macAddress,"
//						+ " hostName,"
//						+ " machineId,"
//						+ " nativeAppId,"
//						+ " deviceRole,"
//						+ " deviceId )"
//						+ " VALUES"
//						+ " ( '"+nodeId+"', "
//						+ "'" + name+ "' , "
//						+ "'" + mac + "' , "
//						+ "'DeepakPurbia0',"
//						+ " '"+machineId+"',"
//						+ " '" + nativeAppId + "',"
//						+ " 1, "
//						+ "'" + deviceId + "'"
//						+ ") ON DUPLICATE KEY UPDATE machineId = '"+machineId+"', hostName = 'DeepakPurbia0', macAddress = '"+mac+"'";
//
//
//				
//				String discoveryQuery = "INSERT INTO `discoverydetails` (`sDeviceID`,"
//						+ " `sRingID`, `sMasterID`, `nNodeStatus`, `sIPAddress`, `sLocalIPAddress`, `sChatInputChannel`,"
//						+ " `sChatOutputChannel`,"
//						+ " `sChatSubscriptionChannel`, `sNodeCommunicationPort`, `sOpenStackPort`,`sKeyStonePort`, `sTomcatPort`, "
//						+ "`sPort1`, `sPort2`, `sPort3`, `sPort4`, `sPort5`, " 
//						+ "`sRURLTomcatPort`, `sRURLKeystonePort`,`sRAddress`,"
//						+ "`nStatus`,`sConnectURL`,`nAdult`,`dHBRdate`,`sRelayServerID`,"
//						+ "`sNetworkType`) VALUES ('"+ 
//						nodeId + "', "
//						+ "'672c0eb331f74728b9c318478863cd88', "
//						+ "'7dd8b77ff34e4ad4a8e10a93a94d8102', "
//						+ "'" + 0 + "',"
//						+ "'core73.pixeom.net,10.20.0.1',"
//						+ "'core73.pixeom.net,10.20.0.1',"
//						+ " '0',"
//						+ " '" + mac + "',"
//						+ " 'DeepakPurbia0',"
//						+ " 'DeepakPurbia0',"
//						+ " 'DeepakPurbia0', "
//						+ " 'DeepakPurbia0',"
//						+ " 'DeepakPurbia0',"
//						+ " 'DeepakPurbia0',"
//						+ " 'Win32', "
//						+ " 'DeepakPurbia0', "
//						+ " 'DeepakPurbia0',"  
//						+ " '0',"
//						+ " 'DeepakPurbia0',"
//						+ " 'DeepakPurbia0',"
//						+ " 'DeepakPurbia0',"
//						+ " '1', "
//						+ " '0', "
//						+ " '0',"  
//						+ " now() ,"
//						+"'0',"
//						+"'0')";
//				queries.add(deviceQuery);
//				queries.add(nodeQuery);
//				queries.add(discoveryQuery);
//				
//				PortalDatabaseEngine.getInstance().getConnection().executeUpdatesInTransaction(queries);
//				PALogger.INFO("data inserted.");
//			}
//			catch (SQLException e)
//			{
//				PALogger.ERROR(""+e.getMessage());				
//				PALogger.ERROR(e);	
//			}
//		}
	}
}










