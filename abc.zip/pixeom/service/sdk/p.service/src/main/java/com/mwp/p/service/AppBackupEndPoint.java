/** 
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com) 
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL 
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC. 
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD 
 * IN STRICTEST CONFIDENCE. 
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */ 

package com.mwp.p.service;

import java.util.Base64;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.constraints.Min;
import javax.ws.rs.Consumes;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.HttpMethod;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.mwp.common.AuthHelper;
import com.mwp.common.Client;
import com.mwp.common.CredProvider;
import com.mwp.common.ReturnObject;
import com.mwp.common.StringFunctions;
import com.mwp.common.constant.Constant;
import com.mwp.common.constant.ErrorMessage;
import com.mwp.common.enums.AppBackupTaskStatus;
import com.mwp.common.enums.CommandEnum;
import com.mwp.common.enums.FilterKeysEnum;
import com.mwp.common.enums.FilterType;
import com.mwp.common.enums.ValueType;
import com.mwp.common.vo.AppBackupTaskVOPortal;
import com.mwp.common.vo.ApplicationUserVO;
import com.mwp.common.vo.AuthorizationsVO;
import com.mwp.common.vo.DeviceVO;
import com.mwp.common.vo.ErrorVo;
import com.mwp.common.vo.FilterObject;
import com.mwp.logger.PALogger;
import com.mwp.p.authhelper.GrpcAuthHelper;
import com.mwp.p.common.Constants;
import com.mwp.p.dal.engine.AppBackupTaskEngine;
import com.mwp.p.framework.ActivityLogs;
import com.mwp.p.framework.AppBackupSync;
import com.mwp.p.framework.Applications;
import com.mwp.p.framework.Devices;
import com.mwp.p.framework.MinioBackups;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
/**
 * Class manage minio backup.
 * @author PS
 */
@Path("/backup")
@Api(value = "/backup", produces = MediaType.APPLICATION_JSON)
public class AppBackupEndPoint {
	@Context
	private HttpServletResponse response;
	@Context
	private HttpServletRequest request;

	@POST
	@Path("/init")
	@Produces({ MediaType.APPLICATION_JSON })
	@ApiOperation( value = "Layout initial structure to allow syncing backup of applications.", notes = "Layout initial structure to allow syncing backup of applications.")
	@ApiResponses
	( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION ),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Application user not exits." ),
	} )
	public void initBackup(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken ,
			@ApiParam(value="Cluster Id", required= true)@QueryParam("clusterid") String clusterId)
	{
		mInitBackup(authToken,clusterId);

	}

	@POST
	@Path("/complete")
	@Produces({ MediaType.APPLICATION_JSON })
	@ApiOperation( value = "On backup complete call portal will sync Cluster minio into it's database.", 
	notes = "Database entries will allow filtering and sorting of the backups without reading files in MINIO.")
	@ApiResponses
	( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION ),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Application user not exits." ),
	} )
	public void completeBackup(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken ,
			@ApiParam(value="Cluster Id", required= true)@QueryParam("clusterid") String clusterId)
	{
		mCompleteBackup(authToken,clusterId);

	}

	@GET	
	@ApiOperation(value = "", notes = "get backups.", response = String.class, responseContainer = "String")
	@ApiResponses({
		@ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to list backups.")
	})
	@Path("pages/{pageno}")
	public void  list(@ApiParam(value = "Authorization token", required = true) @HeaderParam("Authorization") String authToken,
			@ApiParam(value = "requested page no for list application.", required = false) @Min(1) @PathParam("pageno") @DefaultValue("1") long pageNo,
			@ApiParam(value = "requested page size number of element return in a list application.", required = false) @Min(1) @QueryParam("pagesize") @DefaultValue("20") long pageSize,
			@ApiParam(value = "Filter Object", required = true) @QueryParam("filters") String filters,
			@ApiParam(value = "Authorization token", required = true) @QueryParam("sizePerApp") @DefaultValue("0") int sizePerApp) {	
		try {

			AuthorizationsVO authorized = null;
			if(!StringFunctions.isNullOrWhitespace(authToken) && authToken.toLowerCase().startsWith(Constant.JWT_BEARER.toLowerCase())) {
				authorized = new AuthHelper().checkJwtToken(authToken, response);
			} else {
				authorized = new GrpcAuthHelper().getAuthorizationsVO(authToken);
			}

			if(authorized != null) {
				List<FilterObject> filtersObject = new LinkedList<>();
				if(!StringFunctions.isNullOrWhitespace(filters)) {				
					filtersObject = new Gson().fromJson(filters,
							new TypeToken<LinkedList<FilterObject>>() {
					}.getType());			
				}

				List<DeviceVO> clusters = new Devices().listKubenetesClusterForUser(authorized.getUserId());

				Map<String, Object> resultMap = new HashMap<>();
				if(clusters.isEmpty()) {
					Map<String, Object> listBackups = new HashMap<>();
					resultMap.put(Constant.DATA, listBackups);	
				} else {

					List<String> clusterIds = new LinkedList<>();

					for (DeviceVO deviceVO : clusters) {
						clusterIds.add(deviceVO.getDeviceId());
					}

					if(filtersObject == null) {
						filtersObject = new LinkedList<>();
					}
					FilterObject statusFilter = new FilterObject();
					statusFilter.setFilterType(FilterType.FILTER);
					statusFilter.setFilterkey(FilterKeysEnum.Status);
					statusFilter.setValueType(ValueType.Single);
					statusFilter.setStartValue(AppBackupTaskStatus.ACTIVE.getStatusValue() + "");

					filtersObject.add(statusFilter);

					Map<String, Object> listBackups = new AppBackupTaskEngine().list(clusterIds, filtersObject, sizePerApp, pageNo, pageSize);

					resultMap.put(Constant.DATA, listBackups);
				}

				ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);
			} else {
				//DB- Added as response was created twice as in error scenario response is already assigned with proper content inside  checkJwtToken function
					return;
			}
		} catch (Exception e) {
			PALogger.ERROR(e);
			if(e.getMessage().equals(Constant.UNAUTHORIZED)) {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			} else {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e.getMessage(), e.getMessage());
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
		}
	}
	
	@GET	
	@Path("appid/{appId}")
	@ApiOperation(value = "", notes = "get all backups.", response = String.class, responseContainer = "String")
	@ApiResponses({
		@ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to list backups.")})
	public void  listBackupsOfApp(@ApiParam(value = "Authorization token", required = true) @HeaderParam("Authorization") String authToken,
			@ApiParam(value = "application id which backup to be listed", required = true) @PathParam("appId") String appId) {	
		try{
			AuthorizationsVO authVO = new GrpcAuthHelper().getAuthorizationsVO(authToken);

			List<AppBackupTaskVOPortal> listBackups = new MinioBackups().ListAllBackupsOfApplicationForCluster(authVO, null, appId);

			Map<String, Object> resultMap = new HashMap<>();
			resultMap.put(Constant.DATA, listBackups);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);
		}
		catch (Exception e) 
		{
			if(e.getMessage().equals(Constant.UNAUTHORIZED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						e.getMessage(), e.getMessage());
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			PALogger.ERROR(e);	
		}
	}

	@POST
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/restore/devicelist{schedule:(/schedule/[^/]+?)?}")
	@ApiOperation(value = "method execute operation command (install/uninstall/update).", notes = "method execute operation command (install/uninstall/update).", response = String.class, responseContainer = "String")
	@ApiResponses({
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to execute."),
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
	})
	public void executeAll(
			Map<String, Object> mapObject,	
			@ApiParam(value = "schedule", required = false) @PathParam("schedule") String scheduleTicks,
			@ApiParam(value = "Authorization token", required = true) @HeaderParam("Authorization") String authToken) 
	{

		String appBackupTaskVOPortalStr = new Gson().toJson(mapObject.get("appBackupTaskVOPortal"));
		AppBackupTaskVOPortal appBackupTaskVOPortal = new Gson().fromJson(appBackupTaskVOPortalStr, new TypeToken<AppBackupTaskVOPortal>(){}.getType());

		String deviceIdsStr = new Gson().toJson(mapObject.get("deviceIds"));
		List<String> deviceIds = new Gson().fromJson(deviceIdsStr, new TypeToken<List<String>>(){}.getType());

		mExecuteAll(authToken, appBackupTaskVOPortal.getAppBackupTaskVO().getApplicationId(), deviceIds,CommandEnum.restoreApplicationBackup.name(), appBackupTaskVOPortal.getAppBackupTaskVO().getAppVersionId(),scheduleTicks,appBackupTaskVOPortal);
	}

	/**
	 * 
	 * @param authToken
	 * @param applicationId
	 * @param deviceId
	 * @param operation
	 * @param versionId
	 * @param scheduleTicks If null then executes right now, else long ticks at time when it needs to be scheduled
	 */

	private void mExecuteAll(String authToken,String applicationId,List<String> deviceIds,String operation,String versionId, String scheduleTicksValue, 
			AppBackupTaskVOPortal appBackupTaskVOPortal) 
	{
		try 
		{
			// CHECK AUTH TOKEN...
			// Execute that operation if user has device or not.
			AuthorizationsVO authorizationsVO = new GrpcAuthHelper().getAuthorizationsVO(authToken);
			//DB - Old logic when installation notification is to be sent directly
			Applications applications=new Applications();
			long scheduleTicks = 0;

			List<String> resourceIds = null;

			Map<String, String>	 deviceOwners = new Devices().getDevicesOwner(deviceIds);
			if(!StringFunctions.isNullOrWhitespace(scheduleTicksValue))
			{
				scheduleTicks = Long.parseLong(scheduleTicksValue.split("/")[2]);

				for (String deviceId : deviceIds) 
				{
					applications.scheduleAppRestoreOperation(deviceOwners.get(deviceId), applicationId, deviceId, operation, versionId, scheduleTicks,null, false, appBackupTaskVOPortal, resourceIds);	
				}
			}
			else{
				applications.scheduleAppRestoreOperationAll(deviceOwners, applicationId, deviceIds, operation, versionId,null, false,appBackupTaskVOPortal, resourceIds);
			}

			//add in activity log
			HashMap<String, Object> map = new HashMap<>();
			map.put("ApplicationId", applicationId);
			map.put("DeviceIds", deviceIds);
			//here operation is same as in ActivityOperationEnum
			new ActivityLogs().insert(authorizationsVO.getUserId(),operation, new Gson().toJson(map));


		}  catch (Exception e) {
			PALogger.ERROR(e);	
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			//#HDV_01_1
			else if(e.getMessage().equals(Constant.VERSIONNOTAVAILABLE) || e.getMessage().equals(Constant.APPISNOTAVAILABLE)) 
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR ,e.getMessage(), e.getMessage());
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else{
				ErrorVo errorVo = new ErrorVo(
						HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"Unable to submit job.",
						"");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,
						response);
			}

		}

	}

	/**
	 * method used to initialize minio on portal i.e. create user in minio cloud and create bucket for backup
	 * @param authToken Edge's JWT token
	 */
	private void mInitBackup(String authToken, String clusterId) {
		try {
			/**
			 *  CHECK AUTH TOKEN... and get userId	
			 */
			AuthorizationsVO authVO = new AuthHelper().checkJwtToken(authToken, response);

			if(authVO == null)//DB- Added as response was created twice as in error scenario response is already assigned with proper content inside  checkJwtToken function
				return;

			String userId = authVO.getUserId();

			ApplicationUserVO portalUserVO = getAppUserFromAuth(userId);			

			// Check response status and read data
			if (portalUserVO != null) {

				/**
				 * Getting jwt keys to use as password for user 
				 */
				String publicKey = Base64.getEncoder().encodeToString(portalUserVO.getJwtPublicKey().getBytes());

				MinioBackups minioBackups = new MinioBackups();
				/**
				 * 1. Create minio user
				 */
				minioBackups.CreateMinioUser(userId, publicKey);


				/**
				 * 2. Create minio bucket  for cluster Id
				 */
				minioBackups.CreateMinioBucket(clusterId);

				Map<String, Object> resultMap = new HashMap<>();
				resultMap.put(Constant.DATA, MinioBackups.getMinioVO().getUrl());				
				ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);
			} else {
				throw new Exception(ErrorMessage.USER_NOT_FOUND);
			}
		} catch (Exception e) {
			PALogger.ERROR(e);
			if(e.getMessage().equals(Constant.UNAUTHORIZED)) {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			} else {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e.getMessage(), e.getMessage());
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
		}
	}	

	/**
	 * Method is used to notify portal that edge has completed the sync of backups, 
	 * on this call portal will sync minio into it's database    
	 * @param authToken Edge's JWT token
	 * @param clusterId for which backup is completed
	 */
	private void mCompleteBackup(String authToken, String clusterId) {
		try {
			/**
			 *  CHECK AUTH TOKEN... and get userId	
			 */
			AuthorizationsVO authVO = new AuthHelper().checkJwtToken(authToken, response);

			if(authVO == null)//DB- Added as response was created twice as in error scenario response is already assigned with proper content inside  checkJwtToken function
				return;
			
			//Create new table for cluster sync 
			//Mark cluster name in new table to sync, if it's already there and is running status add new entry 
			//Minio one level listing folder name is backup name
			//Read the backup file name and update in DB
			//

			AppBackupSync appBackupSync = new AppBackupSync();
			appBackupSync.addSync(authVO, clusterId);

			ReturnObject.createResponse(Constant.SUCCESS, "", null, response);
		} catch (Exception e)  {
			PALogger.ERROR(e);
			if(e.getMessage().equals(Constant.UNAUTHORIZED)) {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			} else {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e.getMessage(), e.getMessage());
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
		}
	}	

	private ApplicationUserVO getAppUserFromAuth(String userId) throws Exception {
		HashMap<Object,Object> queryParam = new HashMap<>();
		queryParam.put("setJwtKey", "true");

		String authorizationHeader = "basic " +  new String(Base64.getEncoder().encode((Constants.PORTAL_APPLICATION_ID + ":" + new CredProvider().getPortalAppSecKey()).getBytes()));

		String result= Client.callServer(Constants.AUTH_SERVER_IP_PORT, Constants.AUTH_SERVICE_NAME, "applications", HttpMethod.GET, Constants.PORTAL_APPLICATION_ID +"/user/"+ userId, queryParam,null, authorizationHeader);

		HashMap<String, String> data = new Gson().fromJson(result, HashMap.class);
		String userGson = new Gson().toJson(data.get("data"));
		ApplicationUserVO portalUser = Client.getGson().fromJson(userGson, ApplicationUserVO.class);
		return portalUser;
	}
}
