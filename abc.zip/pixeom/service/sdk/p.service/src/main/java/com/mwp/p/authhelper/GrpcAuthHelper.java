/** 
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com) 
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL 
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC. 
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD 
 * IN STRICTEST CONFIDENCE. 
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */ 

package com.mwp.p.authhelper;

import org.apache.commons.lang3.StringUtils;

import com.mwp.common.constant.Constant;
import com.mwp.common.vo.AuthorizationsVO;
import com.mwp.grpc.auth.AuthGrpcClient;

/**
 * 
 * This class contains the logic of authorize a client request
 *
 */
public class GrpcAuthHelper {

	/**
	 * This method is used to authorize client request
	 * @param token : client token 
	 * @return
	 * @throws Exception
	 */
	public String checkAuthorization(String token) throws Exception  {
		return mCheckAuthorization(token);
	}

	/**
	 * This method is used to get {@link AuthorizationsVO} for a client request
	 * @param token : client token
	 * @param authServerUrl : url of authorization server 
	 * @return
	 * @throws Exception
	 */
	public AuthorizationsVO getAuthorizationsVO(String token) throws Exception  {
		return mGetAuthorizationsVO(token);
	}

	private String mCheckAuthorization(String token) throws Exception {
		AuthorizationsVO authorizationsVO = mGetAuthorizationsVO(token);
		return authorizationsVO.getUserId();

	}

	private AuthorizationsVO mGetAuthorizationsVO(String token) throws Exception {

		if(StringUtils.isEmpty(token))
			throw new Exception(Constant.UNAUTHORIZED);

		if(!token.toLowerCase().startsWith(Constant.BEARER) && !token.toLowerCase().startsWith("basic ") && !token.toLowerCase().startsWith("jwt ")) {

			token = Constant.BEARER +token;
		}
		return AuthGrpcClient.getInstance().validateToken(token);

	}

}