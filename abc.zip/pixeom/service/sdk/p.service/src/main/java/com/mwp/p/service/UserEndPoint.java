/** 
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com) 
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL 
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC. 
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD 
 * IN STRICTEST CONFIDENCE. 
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */ 

package com.mwp.p.service;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import com.google.gson.Gson;
import com.mwp.common.Client;
import com.mwp.common.ReturnObject;
import com.mwp.common.Utils;
import com.mwp.common.constant.Constant;
import com.mwp.common.vo.ApplicationUserVO;
import com.mwp.common.vo.ErrorVo;
import com.mwp.common.vo.UsersVO;
import com.mwp.logger.PALogger;
import com.mwp.p.authhelper.GrpcAuthHelper;
import com.mwp.p.common.Constants;
import com.sun.research.ws.wadl.HTTPMethods;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
//description = "Class manage user, return user detail information, subscribe - unsubscribe developer, return user profile path."
@Path("/user")
@Api(value = "/user", produces = MediaType.APPLICATION_JSON)
public class UserEndPoint {
	@Context
	private HttpServletResponse response;
	@Context
	private HttpServletRequest request;

	@GET
	@Produces({ MediaType.APPLICATION_JSON })
	@Path("/self")
	@ApiOperation( value = "Find user detail with userId and applicationId.", notes = "Find user by email and its password.", response = UsersVO.class )
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "User with such email doesn't exists" ),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to get user detail" )
	} )
	public void getUser(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken){
		mGetUser(authToken);
	}

	private void mGetUser(String authToken)
	{
		try {
			// CHECK AUTH TOKEN...
			new GrpcAuthHelper().checkAuthorization(authToken);

			Map<String, Object> hashObject = new HashMap<>();
			String result = Client.callServer(Constants.AUTH_SERVER_IP_PORT, Constants.AUTH_SERVICE_NAME, "user", HTTPMethods.GET.name(), "self", null, null, Constant.BEARER + authToken);
			HashMap<String, String> data =  new Gson().fromJson(result, HashMap.class);
			String userGson = new Gson().toJson(data.get(Constant.DATA));
			ApplicationUserVO portalUser = Client.getGson().fromJson(userGson, ApplicationUserVO.class);
			hashObject.put(Constant.DATA,portalUser);
			ReturnObject.createResponse(Constant.SUCCESS, hashObject, null, response);

		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"Unable to get user detail", "Unable to get user detail");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			PALogger.ERROR(e);	
		}
	}

	/** Method processing HTTP PUT requests, producing "application/json" MIME media type.
	 * <p>
	 * This method returns user profile.
	 * <p>
	 * @param Redirect url
	 * @param Authtoken
	 * @return Json string
	 */
	@GET
	@Produces({ MediaType.APPLICATION_JSON })
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/profile/redirecturl/{path}")
	@ApiOperation( value = "Get profile url.", notes = "Get profile url.")
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_BAD_REQUEST, message = "user profile not available." )			 
	} )
	public void profile(@ApiParam( value = "Redirect url", required = true ) @PathParam("path") String redirecturl,
			@ApiParam(value = "Authorization token", required = true) @HeaderParam("Authorization") String authToken)
	{
		try {			
			new GrpcAuthHelper().checkAuthorization(authToken);
			String loginIp = Utils.constructBaseUri(request);
			StringBuilder builder =new StringBuilder();	

			builder.append(loginIp).append("a.service/userprofile.jsp?redirecturl=").append(redirecturl).append("&authToken=").append(authToken).append("&client_id=").append(Constants.PORTAL_APPLICATION_ID);

			Map<String, Object> resultMap=new HashMap<>();
			resultMap.put("data", builder.toString());
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);
		} catch (Exception e1) {
			PALogger.ERROR(e1);
			if(e1.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_BAD_REQUEST ,"user profile not available.", "user profile not available.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
		}
	}


	@PUT
	@Path("/subscribeDeveloper")
	@Produces({ MediaType.APPLICATION_JSON })
	@ApiOperation( value = "marks a user as developer", notes = "Marks a user as developer")
	@ApiResponses
	( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION ),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Application user not exits." ),
	} )
	public void subscribeDeveloper(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken)
	{
		mSubscribeUnsubscribeDeveloper(true, authToken);
	}

	@PUT
	@Path("/unsubscribeDeveloper")
	@Produces({ MediaType.APPLICATION_JSON })
	@ApiOperation( value = "unmarks a user as developer", notes = "Unmarks a user as developer")
	@ApiResponses
	( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION ),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Application user not exits." ),
	} )
	public void unsubscribeDeveloper(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken)
	{
		mSubscribeUnsubscribeDeveloper(false, authToken);
	}

	/**
	 * method used to mark/unmark user as developer
	 * @param becomeDeveloper
	 * @param authToken
	 */
	private void mSubscribeUnsubscribeDeveloper(boolean becomeDeveloper,String authToken)
	{
		try {
			// CHECK AUTH TOKEN...
			new GrpcAuthHelper().checkAuthorization(authToken);

			String methodName= "subscribeDeveloper";
			if(!becomeDeveloper)
				methodName= "unsubscribeDeveloper";
			Client.callServer(Constants.AUTH_SERVER_IP_PORT,Constants.AUTH_SERVICE_NAME, "applications/" + Constants.PORTAL_APPLICATION_ID + "/user",  HTTPMethods.PUT.name(), methodName, null, null, Constant.BEARER + authToken);
			ReturnObject.createResponse(Constant.SUCCESS, null, null, response);

		} catch (Exception e) 
		{
			if(e.getMessage().equals(Constant.UNAUTHORIZED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						e.getMessage(), e.getMessage());
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			PALogger.ERROR(e);	
		}
	}
}
