/** 
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com) 
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL 
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC. 
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD 
 * IN STRICTEST CONFIDENCE. 
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */ 

package com.mwp.p.service;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;

import com.mwp.common.ReturnObject;
import com.mwp.common.constant.Constant;
import com.mwp.common.enums.SortKeysEnum;
import com.mwp.common.vo.ErrorVo;
import com.mwp.logger.PALogger;
import com.mwp.p.framework.SortOrder;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/** <h1>SortsEndpoint</h1>
 * Class hosted at the URI path "/sorts"
 * <p>
 * Class manage filters of application.
 * </p>
 * @author akh
 * @version 0.0.1
 * @since   2016-08-30 
 */

//description = "Class manage sorts orders." 
@Path("/sorts")
@Api( value = "/sorts")
public class SortsEndpoint {
	@Context
	private HttpServletResponse response;

	/**
	 * Method processing HTTP GET requests, producing "application/json" MIME media-type.
	 * 
	 * <p> This method gives list of sort orders.</p>
	 * 
	 * @param httpHeaders
	 * @return String that will be send back as a response of type json.
	 */
	@GET
	@Consumes("application/json")
	@Produces("application/json")
	@ApiOperation( value = "List of sort orders", 
	notes = "List of sort orders.", 
	response = String.class, responseContainer = "String")
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to list sort."),
	} )
	public void listSort(){// removed authToken -authorization not required.
		mListSort();
	}

	private void mListSort( ) {

		try {
			SortOrder sortOrder=new SortOrder();				
			Map<String, Object> resultMap = new HashMap<>();
			resultMap.put(Constant.DATA,  sortOrder.getAllSortOrder());
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null,response);

		} catch (Exception e) {
			PALogger.ERROR(e);	
			ErrorVo errorVo = new ErrorVo(
					HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
					"Unable to list sort.",
					"Unable to list sort.");
			ReturnObject.createResponse(Constant.FAILURE, null, errorVo,
					response);		
		}

	}
	
	/**
	 * Method processing HTTP GET requests, producing "application/json" MIME media-type.
	 * 
	 * <p> This method gives list of sort orders.</p>
	 * 
	 * @param httpHeaders
	 * @return String that will be send back as a response of type json.
	 */
	@GET
	@Consumes("application/json")
	@Produces("application/json")
	@Path("/device")
	@ApiOperation( value = "List of default device sort orders", 
	notes = "List of default device sort orders.", 
	response = String.class, responseContainer = "String")
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to list sort.")
	} )
	public void listSortForDevice(){// removed authToken -authorization not required.
		mListSortForDevice();
	}

	private void mListSortForDevice() {

		try {				
			Map<String, Object> resultMap = new HashMap<>();
			resultMap.put(Constant.DATA, Arrays.asList(SortKeysEnum.values()));
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null,response);

		} catch (Exception e) {
			PALogger.ERROR(e);	
			ErrorVo errorVo = new ErrorVo(
					HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
					"Unable to list sort.",
					"Unable to list sort.");
			ReturnObject.createResponse(Constant.FAILURE, null, errorVo,
					response);		
		}

	}
}
