/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.service;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import com.google.gson.Gson;
import com.mwp.common.AuthHelper;
import com.mwp.common.ReturnObject;
import com.mwp.common.constant.Constant;
import com.mwp.common.enums.ActivityOperation;
import com.mwp.common.vo.AuthorizationsVO;
import com.mwp.common.vo.ErrorVo;
import com.mwp.logger.PALogger;
import com.mwp.p.authhelper.GrpcAuthHelper;
import com.mwp.p.common.Constants;
import com.mwp.p.framework.ActivityLogs;
import com.mwp.p.framework.BoxStatics;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Path("/statics")
@Api(value = "/statics", produces = MediaType.APPLICATION_JSON)
public class BoxStaticEndPoint {
	@Context
	private HttpServletResponse response;

	@POST
	@Path("{deviceId}")
	@ApiOperation(value = "Insert statics.", notes = "Insert statics to database.", response = String.class, responseContainer = "String")
	@ApiResponses({
		@ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to insert statics.")})
	public void add(@ApiParam(value = "applicationId which we want executed.", required = true) @PathParam("deviceId") String deviceId, 
			Map<String, Object> statics,
			@ApiParam(value = "Authorization token", required = true) @HeaderParam("Authorization") String authToken) {

		insertStatics(deviceId, new Gson().toJson(statics),  authToken);
	}

	private void insertStatics(String deviceId , String statics, String authToken){
		BoxStatics boxStatics = new BoxStatics();
		try {

			AuthorizationsVO authvo;
			if(authToken.toLowerCase().startsWith(Constant.JWT_BEARER.toLowerCase())) {

				authvo = new AuthHelper().checkJwtToken(authToken, response);
			}
			else{
				authvo = new AuthorizationsVO();
				authvo.setUserId(new GrpcAuthHelper().checkAuthorization(authToken));
			}
		
			boxStatics.insert(deviceId, statics);
			Map<String, String> map = new HashMap<>();
			map.put("deviceid", deviceId); 
			new ActivityLogs().insert(authvo.getUserId(), ActivityOperation.insertStatistics.name(), new Gson().toJson(map));
		} catch (Exception e) {
			PALogger.ERROR(e);	
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);

			} else if(e.getMessage().equals(Constant.NOTPERMITTED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , Constants.UNABLE_TO_GET_BOX_STATICS_LIST, Constants.UNABLE_TO_GET_BOX_STATICS_LIST);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
		}
	}

	@GET
	@Path("{deviceId}")
	@ApiOperation(value = "", notes = "", response = String.class, responseContainer = "String")
	@ApiResponses({
		@ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = Constants.UNABLE_TO_GET_BOX_STATICS_LIST)})
	public void list(@ApiParam(value = "applicationId which we want executed.", required = true) @PathParam("deviceId") String deviceId, 
			@ApiParam(value = "Authorization token", required = true) @HeaderParam("Authorization") String authToken) {
		mList(deviceId, authToken);
	}

	private void mList(String deviceId , String authToken){
		BoxStatics boxStatics = new BoxStatics();
		try {
			new GrpcAuthHelper().checkAuthorization(authToken);
			Map<String, Object> resultMap = new HashMap<>();
			resultMap.put(Constant.DATA, boxStatics.list(deviceId));
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);
		} catch (Exception e) {
			PALogger.ERROR(e);	
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);

			} else if(e.getMessage().equals(Constant.NOTPERMITTED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , ".", Constants.UNABLE_TO_GET_BOX_STATICS_LIST);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
		}
	}
}
