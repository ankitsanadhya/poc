/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import javax.validation.ValidationException;
import javax.validation.constraints.NotNull;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import com.mwp.common.ReturnObject;
import com.mwp.common.constant.Constant;
import com.mwp.common.constant.PermissionResourceKeys;
import com.mwp.common.constant.PermissionResources;
import com.mwp.common.vo.AuthorizationsVO;
import com.mwp.common.vo.ErrorVo;
import com.mwp.logger.PALogger;
import com.mwp.p.authhelper.GrpcAuthHelper;
import com.mwp.p.common.AdminPermissionCheck;
import com.mwp.p.common.vo.CompanyInfoVO;
import com.mwp.p.framework.Company;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/** <h1>CategoriesEndpoint</h1>
 * Class hosted at the URI path "/company"
 * <p>
 * Class manage company, return List of top category according to application which are most installed by user,
 * list of category according to paging, gives category detail according to requested categoryId,
 * add/update category status/name, List of categories according to requested search text, list default category.
 * </p>
 * @author akh
 * @version 0.0.1
 * @since   2016-08-30 
 */
@Path("/company")
@Api( value = "/company", produces=MediaType.APPLICATION_JSON )
public class CompanyEndpoint {
	@Context
	private HttpServletResponse response;

	@GET
	@Consumes({MediaType.APPLICATION_JSON})
	@ApiOperation( value = "List companies", 
	notes = "List companies.", 
	response = HashMap.class)
	@ApiResponses( { 
		@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to get list of companies.")
	} )
	public void list(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken){
		mList(authToken);
	}

	@GET
	@Consumes({MediaType.APPLICATION_JSON})
	@ApiOperation( value = "get company by Id.", 
	notes = "get company by Id.", 
	response = HashMap.class)
	@ApiResponses( { 
		@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to get company by Id.")
	} )
	@Path("/{companyid}")
	public void get(@NotNull @PathParam("companyid") String companyId, @ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken){
		mGet(authToken, companyId);
	}

	@GET
	@Consumes({MediaType.APPLICATION_JSON})
	@ApiOperation( value = "Check if company exist.", 
	notes = "check if company exist by name.", 
	response = HashMap.class)
	@ApiResponses( { 
		@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to check companies.")
	} )
	@Path("/{name}/exits")
	public void isCompanyExits(@NotNull @PathParam("name") String companyName, @ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken){
		mIsCompanyExits(authToken, companyName);
	}

	@POST
	@Consumes({MediaType.APPLICATION_JSON})
	@ApiOperation( value = "add category.", 
	notes = "add category object, if not exist with same name in db.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to add company.")		 			 
	} )
	public void add(@ApiParam(value = "updated category object.", required = true) @Valid @NotNull CompanyInfoVO companyInfoVO,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken) throws ValidationException {
		mAdd(authToken, companyInfoVO);
	}

	/** Method processing HTTP PUT requests, producing "application/json" MIME media type.
	 * <p>
	 * This method update category status/name which id specified in category object,
	 * </p>
	 * @param categoryVO updated category object which we update in db.
	 * @param httpHeaders
	 * @return Json string
	 * @throws Exception 
	 */
	@PUT
	@Consumes({MediaType.APPLICATION_JSON})
	@ApiOperation( value = "update category.", 
	notes = "update category status/name which id specified in category object.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to update company.")	 			 
	} )
	public void update(@ApiParam(value = "updated category object.", required = true)  @Valid @NotNull CompanyInfoVO companyInfoVO,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken) throws ValidationException {
		mUpdate(authToken, companyInfoVO);
	}

	/** Method processing HTTP DELETE requests, producing "application/json" MIME media type.
	 * <p>
	 * This method change category status = 'SUSPENDED' in category db.
	 * </p>
	 * @param categoryId of category which we want to remove.
	 * @param httpHeaders
	 * @return
	 * @throws Exception 
	 */
	@DELETE
	@Consumes({MediaType.APPLICATION_JSON})
	@Path("/{id}")
	@ApiOperation( value = "remove category.", 
	notes = "remove category change status = 'SUSPENDED' in db.")
	@ApiResponses( {
		@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to delete company.") 			 
	} )
	public void delete(@ApiParam(value = "requested categoryId for getting detail of category.", required = true) @NotNull @PathParam("id") String companyId,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken) throws ValidationException {
		mDelete(authToken, companyId);
	}


	private void mDelete(String authToken, String companyId)
	{
		final String COMPANY_CAN_NOT_BE_DELETED = "Company can not be deleted.";

		try {
			//CHECK AUTH TOKEN...
			new GrpcAuthHelper().checkAuthorization(authToken);
			AuthorizationsVO authorizationsVO = new GrpcAuthHelper().getAuthorizationsVO(authToken);

			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_PROJECTS));
			AdminPermissionCheck.checkAdminPermission(authorizationsVO, lstPermissions, true);

			Company company = new Company();

			Map<String, Object> resultMap=new HashMap<>();
			resultMap.put(Constant.DATA, company.delete(companyId, authorizationsVO.getUserId()));
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);

		} catch (Exception e) {
			PALogger.ERROR(e);	
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else if(e.getMessage().equals(COMPANY_CAN_NOT_BE_DELETED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , COMPANY_CAN_NOT_BE_DELETED, COMPANY_CAN_NOT_BE_DELETED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			} else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , COMPANY_CAN_NOT_BE_DELETED, e.getMessage());
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}

		}
	}

	private void mList(String authToken)
	{
		try {
			//CHECK AUTH TOKEN...
			new GrpcAuthHelper().checkAuthorization(authToken);
			AuthorizationsVO authorizationsVO = new GrpcAuthHelper().getAuthorizationsVO(authToken);
			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_PROJECTS));
			AdminPermissionCheck.checkAdminPermission(authorizationsVO, lstPermissions, true);

			Company company = new Company();

			Map<String, Object> resultMap = new HashMap<>();
			resultMap.put(Constant.DATA, company.list(authorizationsVO.getUserId()));
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);

		} catch (Exception e) {
			PALogger.ERROR(e);	
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to fatch company.", e.getMessage());
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}

		}
	}

	private void mGet(String authToken, String companyId)
	{
		try {
			//CHECK AUTH TOKEN...
			new GrpcAuthHelper().checkAuthorization(authToken);
			AuthorizationsVO authorizationsVO = new GrpcAuthHelper().getAuthorizationsVO(authToken);
			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_PROJECTS));
			AdminPermissionCheck.checkAdminPermission(authorizationsVO, lstPermissions, true);

			Company company = new Company();

			Map<String, Object> resultMap = new HashMap<>();
			resultMap.put(Constant.DATA, company.get(companyId, authorizationsVO.getUserId()));
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);

		} catch (Exception e) {
			PALogger.ERROR(e);	
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to fatch company", e.getMessage());
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}

		}
	}

	private void mIsCompanyExits(String authToken, String companyName)
	{
		try {
			//CHECK AUTH TOKEN...
			new GrpcAuthHelper().checkAuthorization(authToken);
			AuthorizationsVO authorizationsVO = new GrpcAuthHelper().getAuthorizationsVO(authToken);
			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_PROJECTS));
			AdminPermissionCheck.checkAdminPermission(authorizationsVO, lstPermissions, true);

			Company company = new Company();

			Map<String, Object> resultMap = new HashMap<>();
			resultMap.put(Constant.DATA, company.isCompanyExits(companyName, authorizationsVO.getUserId()));
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);
		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to fatch company.", e.getMessage());
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			PALogger.ERROR(e);	
		}
	}

	private void mAdd(String authToken, CompanyInfoVO companyInfoVO)
	{
		final String COMPANY_WITH_SAME_NAME_ALREADY_EXISTS = "Company with same name already exists.";
		try {
			//CHECK AUTH TOKEN...
			new GrpcAuthHelper().checkAuthorization(authToken);
			AuthorizationsVO authorizationsVO = new GrpcAuthHelper().getAuthorizationsVO(authToken);
			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_PROJECTS));
			AdminPermissionCheck.checkAdminPermission(authorizationsVO, lstPermissions, true);

			Company company = new Company();

			companyInfoVO.setUserId(authorizationsVO.getUserId());

			Map<String, Object> resultMap = new HashMap<>();
			resultMap.put(Constant.DATA, company.add(companyInfoVO));
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);
		} catch (Exception e) {
			PALogger.ERROR(e);	
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else if(e.getMessage().equals(COMPANY_WITH_SAME_NAME_ALREADY_EXISTS)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , COMPANY_WITH_SAME_NAME_ALREADY_EXISTS, COMPANY_WITH_SAME_NAME_ALREADY_EXISTS);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			} 
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to add company.", e.getMessage());
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
		}
	}

	private void mUpdate(String authToken, CompanyInfoVO companyInfoVO)
	{
		try {
			//CHECK AUTH TOKEN...
			new GrpcAuthHelper().checkAuthorization(authToken);
			AuthorizationsVO authorizationsVO = new GrpcAuthHelper().getAuthorizationsVO(authToken);
			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_PROJECTS));
			AdminPermissionCheck.checkAdminPermission(authorizationsVO, lstPermissions, true);

			Company company = new Company();

			Map<String, Object> resultMap = new HashMap<>();
			resultMap.put(Constant.DATA, company.update(companyInfoVO, authorizationsVO.getUserId()));
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);

		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to edit company.", e.getMessage());
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			PALogger.ERROR(e);	
		}
	}

}
