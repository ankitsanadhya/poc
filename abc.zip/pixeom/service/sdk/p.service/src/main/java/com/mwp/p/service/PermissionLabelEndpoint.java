/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.mwp.p.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import com.google.gson.Gson;
import com.mwp.common.Client;
import com.mwp.common.ReturnObject;
import com.mwp.common.StringFunctions;
import com.mwp.common.constant.Constant;
import com.mwp.common.enums.RoleEnum;
import com.mwp.common.vo.AuthorizationsVO;
import com.mwp.common.vo.ErrorVo;
import com.mwp.common.vo.PermissionLabelVO;
import com.mwp.logger.PALogger;
import com.mwp.p.authhelper.GrpcAuthHelper;
import com.mwp.p.common.Constants;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Path("/permissionlabel")
@Api(value = "/permissionlabel")
public class PermissionLabelEndpoint {

	@Context
	private HttpServletResponse response;
	

	@POST
	@Consumes({ MediaType.APPLICATION_JSON })
	@Produces({ MediaType.APPLICATION_JSON })
	@Path("permission")
	@ApiOperation( value = "Add permisison label ", notes = "Add permisison label")
	@ApiResponses
	( {
		@ApiResponse( code = HttpServletResponse.SC_CREATED, message = "Permission label added successfully" )
	} )
	public void addPermissionLabel(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,
			@ApiParam(value = "This is object type", required = true) List<PermissionLabelVO> labelLst) 
	{
		mAddLabel(authToken,labelLst,false);
	}
	
	@POST
	@Consumes({ MediaType.APPLICATION_JSON })
	@Produces({ MediaType.APPLICATION_JSON })
	@Path("role")
	@ApiOperation( value = "Add role label ", notes = "Add role label")
	@ApiResponses
	( {
		@ApiResponse( code = HttpServletResponse.SC_CREATED, message = "Role label added successfully" )
	} )
	public void addRoleLabel(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,
			@ApiParam(value = "This is object type", required = true) List<PermissionLabelVO> labelLst) 
	{
		mAddLabel(authToken,labelLst,true);
	}
	
	@DELETE
	@Produces({ MediaType.APPLICATION_JSON })
	@Path("permission")
	@ApiOperation( value = "Delete  label", notes = "Delete  label")
	@ApiResponses
	( {
		@ApiResponse( code = HttpServletResponse.SC_OK, message = "Permission label deleted successfully" ),
		@ApiResponse( code = HttpServletResponse.SC_NOT_FOUND, message = "Permission label does not exsits")
	} )
	public void deleteLabel(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,
			@ApiParam(value = "Permission Id", required = true ) @PathParam( "permissionid" ) final String permissionid,
			@ApiParam(value = "label key and value", required = true) @QueryParam("label") String labels)
	{
		mDelete(authToken,labels,false);
	} 
	
	@DELETE
	@Produces({ MediaType.APPLICATION_JSON })
	@Path("role")
	@ApiOperation( value = "Delete role label", notes = "Delete role label")
	@ApiResponses
	( {
		@ApiResponse( code = HttpServletResponse.SC_OK, message = "Role label deleted successfully" ),
		@ApiResponse( code = HttpServletResponse.SC_NOT_FOUND, message = "Role label does not exsits")
	} )
	public void deleteRoleLabel(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,
			@ApiParam( value = "Role Id", required = true ) @PathParam( "roleid" ) final String roleId,
			@ApiParam(value = "label key and value", required = true) @QueryParam("label") String labels)
	{
		mDelete(authToken, labels,true);
	} 
	
	private void  mDelete(String authToken, String labels, boolean isRole) {
		try {
			// CHECK AUTH TOKEN...
			AuthorizationsVO authvo = new GrpcAuthHelper().getAuthorizationsVO(authToken);
			if(authvo.getRole()!=RoleEnum.Admin)
				throw new Exception(Constant.NOTPERMITTED);
			
		
			Map<Object, Object> labelMap =new HashMap<>();
			if(!StringFunctions.isNullOrWhitespace(labels))
				labelMap.put("label", labels);
			
			String action ;
			if(isRole)
				action = "role";
			else
				action =  "permission";
			
			
			String result = Client.callServer(Constants.AUTH_SERVER_IP_PORT,Constants.AUTH_SERVICE_NAME,"permissionlabel", "DELETE", action,labelMap, null, Constant.BEARER + authToken);
			ReturnObject.createResponse(Constant.SUCCESS, new Gson().fromJson(result, Map.class), null, response);

		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"Unable to delete label ", "Unable to delete label");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			PALogger.ERROR(e);	
		}
	}

	
	private void  mAddLabel(String authToken, List<PermissionLabelVO> labelLst, boolean isRole) {
		try {
			// CHECK AUTH TOKEN...
			AuthorizationsVO authvo = new GrpcAuthHelper().getAuthorizationsVO(authToken);
			
			if(authvo.getRole()!=RoleEnum.Admin)
				throw new Exception(Constant.NOTPERMITTED);
			
			
			
			String action ;
			if(isRole)
				action = "role";
			else
				action =  "permission";
			
			
			String result = Client.callServer(Constants.AUTH_SERVER_IP_PORT,Constants.AUTH_SERVICE_NAME,"permissionlabel", "POST", action,null, labelLst, Constant.BEARER + authToken);
			ReturnObject.createResponse(Constant.SUCCESS, new Gson().fromJson(result, Map.class), null, response);

		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"Unable to add label ", "Unable to add label");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			PALogger.ERROR(e);	
		}
	}
}
