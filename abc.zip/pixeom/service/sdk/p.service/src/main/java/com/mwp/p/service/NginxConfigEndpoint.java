/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.service;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Consumes;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import com.mwp.common.ReturnObject;
import com.mwp.common.StringFunctions;
import com.mwp.common.constant.Constant;
import com.mwp.common.vo.ErrorVo;
import com.mwp.common.yamlparser.NginxConfig;
import com.mwp.logger.PALogger;
import com.mwp.p.authhelper.GrpcAuthHelper;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Path("nginx-config")
public class NginxConfigEndpoint {

	@Context
	private HttpServletResponse response;

	@POST
	@Consumes({MediaType.APPLICATION_JSON})
	@ApiOperation( value = "Create Nginx config file location filter text", notes = "Create Nginx config file location filter text", response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to create Nginx file text" )	 
	} )
	public void createConfigText(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,
			@ApiParam(value = "add network object.", required = true) NginxConfig nginxConfig) {
		mCreateConfigText(authToken, nginxConfig);
	}

	private void mCreateConfigText(String authToken, NginxConfig nginxConfig) {
		try {
			//CHECK AUTH TOKEN...
			new GrpcAuthHelper().getAuthorizationsVO(authToken);
			
			// templates to create nginx configuration for the NginxConfig
			String nginx_template_both_equal = "location /PROXY_NAME_HERE {\n"
					+ "	proxy_pass PROTOCOL_HERE://CONTAINER_IP_HERE:CONTAINER_PORT_HERE; \n" 
					+ "	proxy_http_version 1.1;\n" 
					+ "	proxy_set_header Upgrade $http_upgrade;\n" 
					+ "	proxy_set_header Connection \"upgrade\";\n"+ "}";

			String nginx_template_both_diff_empty_target = "location ~* ^/PROXY_NAME_HEREDO_PROXY_SLASHES?(?<baseuri>.*) {\n"
					+ "	rewrite /PROXY_NAME_HERE/(.*) /$1 break; \n" + "	rewrite /PROXY_NAME_HERE / break; \n"
					+ "	proxy_pass PROTOCOL_HERE://CONTAINER_IP_HERE:CONTAINER_PORT_HERE; \n" 
					+ "	proxy_http_version 1.1;\n" 
					+ "	proxy_set_header Upgrade $http_upgrade;\n" 
					+ "	proxy_set_header Connection \"upgrade\";\n"+ "}";


			String nginx_template_both_diff_with_target = "location ~* ^/PROXY_NAME_HEREDO_PROXY_SLASHES?(?<baseuri>.*) {\n"
					+ "	rewrite /PROXY_NAME_HERE/(.*) /REWRITE_TARGET_HERE/$1 break; \n"
					+ "	proxy_pass PROTOCOL_HERE://CONTAINER_IP_HERE:CONTAINER_PORT_HERE; \n"
					+ "	proxy_http_version 1.1;\n" 
					+ "	proxy_set_header Upgrade $http_upgrade;\n" 
					+ "	proxy_set_header Connection \"upgrade\";\n"+ "}";


			// Remove start slash is any
			String proxyname = StringFunctions.Trimstart(nginxConfig.getName(), "/");
			// If ProxyName doce not contains last / add optional slash
			// param
			String proxySlashes = (nginxConfig.getName().endsWith("/")) ? "" : "\\/";
			// Remove Start slash from rewrite target
			String rewriteTarget = StringFunctions.Trimstart(nginxConfig.getRewriteTarget(), "/");
			// Make protoco string to lower case
			String protocol = nginxConfig.getProtocol().toLowerCase();
			String port = nginxConfig.getPort();

			// Choose template file according to reverse proxy configs
			String template = "";
			if (nginxConfig.getName().equals(nginxConfig.getRewriteTarget())) {
				template = nginx_template_both_equal;
			} else if ("/".equals(nginxConfig.getRewriteTarget())) {
				template = nginx_template_both_diff_empty_target;
			} else {
				template = nginx_template_both_diff_with_target;
			}

			// Replace place holders in template file with required values
			template = template.replace("PROXY_NAME_HERE", proxyname);
			template = template.replace("DO_PROXY_SLASHES", proxySlashes);
			template = template.replace("REWRITE_TARGET_HERE", rewriteTarget);
			template = template.replace("PROTOCOL_HERE", protocol);
			template = template.replace("CONTAINER_PORT_HERE", port);

			// Remove "//" with "/"
			template = template.replace("//(.*)", "/(.*)");

			Map<String, Object> resultMap = new HashMap<>();
			resultMap.put(Constant.DATA, template);

			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);

		} catch (Exception e) {
			PALogger.ERROR(e);
			if(e.getMessage().equals(Constant.UNAUTHORIZED)) {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			} else {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to create Nginx config file location filter.", e);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
		}
	}
}