/** 
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com) 
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL 
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC. 
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD 
 * IN STRICTEST CONFIDENCE. 
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */ 

package com.mwp.p.application.context;

import java.io.File;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

import org.apache.commons.io.FileUtils;

import com.mwp.common.constant.Constant;
import com.mwp.jobRunner.ScheduledJobInitializer;
import com.mwp.logger.PALogger;
import com.mwp.p.common.Constants;


@WebListener
public class PortalServiceServletContextListener implements ServletContextListener
{

	@Override
	public void contextDestroyed(ServletContextEvent arg0) {
		PALogger.INFO("PortalServiceServletContextListener destroyed");

	}

	@Override
	public void contextInitialized(ServletContextEvent arg0) {
		PALogger.INFO("PortalServiceServletContextListener starting");
	
		//Delete all download links on server start
		try {
			String downloadLinksFolder = Constants.PORTAL_CACHE_PATH + Constants.DOWNLOAD_ASSETS_FOLDER_NAME + Constant.localFileSeparator + "links" + Constant.localFileSeparator;
			FileUtils.cleanDirectory(new File(downloadLinksFolder));
		} catch (Exception e) 
		{
			PALogger.ERROR(e);	
		}

		if(!Constants.isRunningOnCluster())
		{
			ScheduledJobInitializer.getInstance().init();
		}
		ScheduledJobInitializer.getInstance().runStartup();		
		PALogger.INFO("PortalServiceServletContextListener started");

	}

}
