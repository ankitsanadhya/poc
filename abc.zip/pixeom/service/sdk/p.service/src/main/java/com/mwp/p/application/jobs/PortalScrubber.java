/** 
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com) 
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL 
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC. 
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD 
 * IN STRICTEST CONFIDENCE. 
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */ 

package com.mwp.p.application.jobs;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.mwp.common.builder.SqlQueryBuilder;
import com.mwp.common.enums.Status;
import com.mwp.common.interfaces.IScheduledJob;
import com.mwp.common.vo.ApplicationPlatformVO;
import com.mwp.common.vo.ApplicationVO;
import com.mwp.common.vo.QueryVO;
import com.mwp.logger.PALogger;
import com.mwp.p.common.Constants;
import com.mwp.p.common.vo.ProjectVO;
import com.mwp.p.dal.engine.ApplicationsEngine;
import com.mwp.p.dal.engine.PortalDatabaseEngine;
import com.mwp.p.dal.engine.ProjectsEngine;
import com.mwp.p.dal.engine.VersionEngine;
import com.mwp.p.framework.docker.RegistryClient;


/**
 * This class run a thread regularly in a time interval and delete garbage collection like deleted apps,projects and versions etc.;
 * @author root
 *
 */
public class PortalScrubber implements IScheduledJob
{
	// property used for specifying the interval in which scrub thread runs.
	private static final long SCRUB_INTERVAL = 300000; //5 Minute
	static PortalScrubber portalscrubService;

	/**
	 * Method used for getting Deleted project,application as well as application version.
	 * @throws Exception
	 */

	public void init()
	{
		boolean isProcessRunning=false;
		while(true)
		{
			try
			{

				if(isProcessRunning)
					return;
				isProcessRunning=true;
				// Call Method for getting  and deleting project,application as well as application version which are deleted.
				removeDeleteProject();
				removeDeleteApps();
				isProcessRunning=false;

			}catch(Exception e)
			{
				isProcessRunning=false;
				PALogger.ERROR(e);	
			}
			finally
			{

				try {
					Thread.sleep(SCRUB_INTERVAL);
				} catch (InterruptedException e) {
					PALogger.ERROR(e);	
					//Thread.currentThread().interrupt();
				}
			}

		}
	}

	/**
	 * Method for Getting and deleting  project,application as well as application version which are deleted.
	 * @throws SQLException 
	 * @throws Exception
	 */
	private void removeDeleteProject() throws SQLException  
	{
		List<QueryVO> executeQueries = new ArrayList<>();

		// Getting the list of projectVo which are deleted.
		List<ProjectVO> projectVOs = new ProjectsEngine().listProjectByStaus(Status.DELETED);

		// Flag - is app-images and version deleted successfully
		boolean deleted = false;

		for (ProjectVO projectVO : projectVOs) {
			// Re-Init flag as false - mark true if all steps success
			deleted = false;

			try {

				// Getting the list of applications which are deleted.
				List<ApplicationVO> applicationVOs = new ProjectsEngine().listAppsOfDelete(projectVO.getProjectId());

				for (ApplicationVO applicationVO : applicationVOs) {
					deleteRepoFromDockerHub(applicationVO);

					// Getting the list of queries versions which are deleted.
					VersionEngine versionEngine = new VersionEngine();

					List<String> quries = versionEngine.deleteVersion();
					QueryVO queryVO = new SqlQueryBuilder(
							PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
									.appendQuery(quries.get(0)).addParameter(applicationVO.getApplicationId()).build();

					executeQueries.add(queryVO);

					queryVO = new SqlQueryBuilder(
							PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
									.appendQuery(quries.get(1)).addParameter(applicationVO.getApplicationId()).build();

					executeQueries.add(queryVO);

					queryVO = new SqlQueryBuilder(
							PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
									.appendQuery(quries.get(2)).addParameter(applicationVO.getApplicationId()).build();

					executeQueries.add(queryVO);
				}

				// All inner steps success mark deleted
				deleted = true;
			} catch (Exception e) {
				PALogger.ERROR(e);
			}

			// if deleted - delete project with app - else it will retry in next
			// iteration
			if (deleted) {
				QueryVO queryVO = new SqlQueryBuilder(
						PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
								.appendQuery(new ApplicationsEngine().deleteAppFromDb("")).addParameter("").build();
				executeQueries.add(queryVO);

				queryVO = new SqlQueryBuilder(
						PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
								.appendQuery(new ProjectsEngine().deleteProjectFromDb().get(0))
								.addParameter(projectVO.getProjectId()).build();
				executeQueries.add(queryVO);

			}
		}

		// Delete them
		PortalDatabaseEngine.getInstance().getConnection().executeUpdatesInTransaction(executeQueries);
	}


	private void removeDeleteApps() throws SQLException
	{
		List<QueryVO> executeQueries = new ArrayList<>();

		List<ApplicationVO> applicationVOs;
		// Getting the list of applications which are deleted.
		applicationVOs = new ProjectsEngine().listAppsOfDelete("");

		// Flag if app-versions deleted successfully
		boolean deleted = false;
		for (ApplicationVO applicationVO : applicationVOs) {
			try {
				// Reinit for new iteration
				deleted = false;

				deleteRepoFromDockerHub(applicationVO);

				// Getting the list of versions which are deleted.
				VersionEngine versionEngine = new VersionEngine();
				
				List<String> quries = versionEngine.deleteVersion();
				QueryVO queryVO = new SqlQueryBuilder(
						PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
								.appendQuery(quries.get(0)).addParameter(applicationVO.getApplicationId())
								.build();
				
				executeQueries.add(queryVO);
				
				queryVO = new SqlQueryBuilder(
						PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
								.appendQuery(quries.get(1)).addParameter(applicationVO.getApplicationId())
								.build();
				
				executeQueries.add(queryVO);
				
				queryVO = new SqlQueryBuilder(
						PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
								.appendQuery(quries.get(2)).addParameter(applicationVO.getApplicationId())
								.build();
				
				executeQueries.add(queryVO);
				
				// All success - mark deleted
				deleted = true;
			} catch (Exception e) {
				PALogger.ERROR(e);
			}

		}

		// if deleted - delete project with app - else it will retry in next
		// iteration
		if (deleted) {
			QueryVO queryVO = new SqlQueryBuilder(
					PortalDatabaseEngine.getInstance().getConnection().getIdentifierQuoteString())
							.appendQuery(new ApplicationsEngine().deleteAppFromDb("")).addParameter("")
							.build();
			executeQueries.add(queryVO);
		}

		PortalDatabaseEngine.getInstance().getConnection().executeUpdatesInTransaction(executeQueries);
	}


	/**
	 * Delete sequence -> Repo have images
	 * 	Images have versions(Tags)
	 *  Delete all tags.
	 *  Than Docker garbage collector will delete the non tagged images.
	 * @param applicationVO
	 * @throws IOException 
	 * @throws ParseException 
	 * @throws KeyStoreException 
	 * @throws NoSuchAlgorithmException 
	 * @throws KeyManagementException 
	 * @throws Exception
	 */
	private void deleteRepoFromDockerHub(ApplicationVO applicationVO) throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException, ParseException, IOException  {


		//admin:p1xadmin -- PortalToken:appId.

		String creds=Constants.PORTAL_USER_ID+":"+applicationVO.getApplicationId();
		Base64.getEncoder().encodeToString(creds.getBytes());

		List<String> imagesInApp = new ArrayList<>();

		RegistryClient registryClient = new  RegistryClient(Constants.getPLATEFORM_REPO());
		JSONParser parser = new JSONParser();
		final int dataSize = 50;


		String nextMarkerImages = "";
		do {
			

			JSONObject obj = (JSONObject) parser.parse(registryClient.getAllRepositories(dataSize, nextMarkerImages));

			List<String> images = (List<String>) obj.get("repositories");

			for (String image : images) {
				for (ApplicationPlatformVO platformVO : applicationVO.getPlatFormList()) {
					if(image.startsWith(platformVO.getRepositoryName())) {
						imagesInApp.add(image);
					}
				}
			}

			if(dataSize <= images.size()) {
				nextMarkerImages = images.get(dataSize - 1);
			} else {
				nextMarkerImages = "";
			}
		} while (!"".equals(nextMarkerImages));

		for (String imagePath : imagesInApp) {
			
			List<String> tags;
			try {
				JSONObject obj = (JSONObject) parser.parse(registryClient.getVersions(imagePath));

				tags= (List<String>) obj.get("tags");
			} 
			catch (Exception e) 
			{
				JSONObject obj = (JSONObject) parser.parse(e.getMessage());
				JSONArray jsonArray= (JSONArray)obj.get("errors");
				JSONObject element=(JSONObject)jsonArray.get(0);
				if(element.get("code").toString().equals("NAME_UNKNOWN"))
					continue;
				else
					throw e;

			}
			if(tags!=null)
			{
				for (String tag : tags) {
					registryClient.deleteImage(imagePath, tag);
				}
			}

		}
	}

}