/** 
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com) 
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL 
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC. 
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD 
 * IN STRICTEST CONFIDENCE. 
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */ 

package com.mwp.p.service;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.google.gson.internal.LinkedTreeMap;
import com.mwp.common.Client;
import com.mwp.common.CredProvider;
import com.mwp.common.ReturnObject;
import com.mwp.common.StringFunctions;
import com.mwp.common.Utils;
import com.mwp.common.constant.Constant;
import com.mwp.common.vo.ErrorVo;
import com.mwp.logger.PALogger;
import com.mwp.p.common.Constants;
import com.sun.research.ws.wadl.HTTPMethods;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

// description = "This class use for portal login."
@Path("/login")
@Api(value = "/login")
public class LoginEndpoint {
	@Context
	private HttpServletResponse response;
	@Context
	private HttpServletRequest request;

	@GET
	@Produces({ MediaType.APPLICATION_JSON })
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/{path}")
	@ApiOperation( value = "Return login URL for portal app.", notes = "Return login URL for portal app.")
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION ),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to login." )
	} )
	public void login(@ApiParam( value = "path", required = true ) @PathParam( "path" ) String redirectUrl,
			@ApiParam( value = "codeRequired", required = false ) @QueryParam( "codeRequired" ) boolean isCode)
	{
		mLogin(redirectUrl, isCode);

	}

	private void mLogin(String redirectUrl, boolean isCode) {
		try {

			String loginIp = Utils.constructBaseUri(request);
			StringBuilder builder =new StringBuilder();
			redirectUrl = new String(Base64.getDecoder().decode(redirectUrl.getBytes()));

			redirectUrl = redirectUrl.replace(":/pp", "/pp");

			HashMap<String, String> param = new HashMap<>();
			param.put("redirect_url", redirectUrl);
			param.put("isCode", String.valueOf(isCode));
			builder.append(loginIp).append(com.mwp.p.common.Constants.AUTH_SERVICE_NAME+"/authorize?client_id=").append(Constants.PORTAL_APPLICATION_ID);
			if(isCode){
				builder.append("&response_type=code&redirect_uri=").append(redirectUrl);				
			}else{
				builder.append("&response_type=token&redirect_uri=").append(redirectUrl);
			}
			builder.append("&connect_uri="+loginIp);
			Map<String, Object> resultMap=new HashMap<>();
			resultMap.put(Constant.DATA, builder.toString());
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);


		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"Unable to login", "Unable to login");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			PALogger.ERROR(e);	
		}
	}

	@GET
	@Produces({ MediaType.APPLICATION_JSON })
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("code/{code}/redirecturl/{path}")
	@ApiOperation( value = "Get access token and refresh token along with expiry time.", notes = "OAuth 2 code based authentication - auth code is required to get access token, refresh token and expiry time.")
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_BAD_REQUEST, message = "" )			 
	} )
	public void getAuthCodeUrl(@ApiParam( value = "path", required = true ) @PathParam( "path" ) String redirectUrl, 
			@ApiParam( value = "code", required = true ) @PathParam( "code" ) String code) {

		Map<String, Object> resultMap=new HashMap<>();
		try {
			String loginIp = Constants.AUTH_SERVER_IP_PORT ;
			redirectUrl = new String(Base64.getDecoder().decode(redirectUrl.getBytes()));

			Map<Object,Object> queryParam = new HashMap<>();
			queryParam.put("grant_type", "authorization_code");
			queryParam.put("code", code);
			queryParam.put("client_id", Constants.PORTAL_APPLICATION_ID);
			queryParam.put("client_secret", new CredProvider().getPortalAppSecKey());
			queryParam.put("redirect_uri", redirectUrl);

			String result = Client.callServer(loginIp, "a.service/api", "token", HTTPMethods.POST.name(), "", queryParam, null, "", MediaType.APPLICATION_FORM_URLENCODED_TYPE);

			LinkedTreeMap<String, Object> authMap = (LinkedTreeMap<String, Object>) Client.getGson().fromJson(result, Map.class);

			resultMap.put("data", authMap);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);
		} catch (Exception e1) {
			PALogger.ERROR(e1);	
			ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_BAD_REQUEST , e1.getMessage(), "");
			ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
		}

	}

	@POST
	@Produces({ MediaType.APPLICATION_JSON })
	@Consumes({ MediaType.APPLICATION_JSON })
	@ApiOperation( value = "Secure login provider.", notes = "Check username password from secureLogin file in opt->app_engine folder.")
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Invalid credentials." )			 
	} )
	public void login(String args)
	{
		try {
			mSecureLogin(args);
		} catch (Exception e) {
			PALogger.ERROR(e);	
			ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Invalid credentials.", e);
			ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
		}
	}

	private void mSecureLogin(String args) throws ParseException, IOException {

		//Parse Username and password from JSON file in /opt/app_engine/SecureLogin file.
		JSONParser parser = new JSONParser();
		JSONObject obj = (JSONObject) parser.parse(args);

		String username = obj.get("username").toString();
		String password = obj.get("password").toString();

		//If username or password in empty or null throw error
		if(StringFunctions.isNullOrWhitespace(username) &&
				StringFunctions.isNullOrWhitespace(password)) {
			ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_BAD_REQUEST , "Invalid credentials.", "Username or password is Null or Empty.");
			ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
		} else {

			File f = new File("/opt/app_engine/SecureLogin");

			//If file does not exists -> make secure login pass through i.e. no check 
			if(f.exists()) {
				obj = (JSONObject) parser.parse(new FileReader(f));

				String fusername = obj.get("username").toString();
				String fpassword = obj.get("password").toString();

				//Check REST values with file values. if anything mismatch give error
				if(!fusername.equals(username.trim()) || !fpassword.equals(password.trim())) {
					ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_BAD_REQUEST, "Invalid credentials.", "Invalid credentials.");
					ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
				}
			}

			//Final true response if everything went well above.  
			Map<String, Object> resultMap=new HashMap<>();
			resultMap.put("data", true);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);
		}
	}
}