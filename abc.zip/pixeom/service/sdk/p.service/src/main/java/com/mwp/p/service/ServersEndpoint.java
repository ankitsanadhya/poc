/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.mwp.p.service;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.ValidationException;
import javax.validation.constraints.NotNull;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import com.google.gson.Gson;
import com.mwp.common.ReturnObject;
import com.mwp.common.constant.Constant;
import com.mwp.common.constant.PermissionResourceKeys;
import com.mwp.common.constant.PermissionResources;
import com.mwp.common.enums.ActivityOperation;
import com.mwp.common.enums.RuleType;
import com.mwp.common.vo.AuthorizationsVO;
import com.mwp.common.vo.EmailServersVO;
import com.mwp.common.vo.ErrorVo;
import com.mwp.common.vo.RuleVO;
import com.mwp.logger.PALogger;
import com.mwp.p.authhelper.GrpcAuthHelper;
import com.mwp.p.common.AdminPermissionCheck;
import com.mwp.p.common.Constants;
import com.mwp.p.common.vo.RelayServerVO;
import com.mwp.p.framework.ActivityLogs;
import com.mwp.p.framework.EmailServers;
import com.mwp.p.framework.RelayServers;
import com.mwp.p.framework.Rule;
import com.mwp.p.framework.RuleTriggerLogs;
import com.mwp.p.framework.SupportRelayServer;
//description = "Class  list,add,edit relay severs,supportrelay servers,email server."
@Path("/servers")
@Api(value = "/servers", produces = MediaType.APPLICATION_JSON)
public class ServersEndpoint
{
	@Context
	private HttpServletResponse response;
	@Context
	private HttpServletRequest request;

	@GET
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/relay")
	@ApiOperation(value = "List relay servers", notes = "List relay server", response = HashMap.class)
	@ApiResponses({
			@ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to list relay server.") })
	public void listRelayServers(@ApiParam(value = "Authorization token", required = true) @HeaderParam("Authorization") String authToken)
			throws ValidationException {
		mListRelayServer(authToken);
	}
	
	@POST
	@Produces({ MediaType.APPLICATION_JSON })
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/relay")
	@ApiOperation( value = "Add relay server", notes = "Add relay server")
	@ApiResponses
	( {
		@ApiResponse( code = HttpServletResponse.SC_CREATED, message = "Relay server added successfully" ),
		@ApiResponse( code = HttpServletResponse.SC_CONFLICT, message = "Relay server already exists")
	} )
	public void addRelayServer(@ApiParam(value = "Authorization token", required = true) @HeaderParam("Authorization") String authToken,
			@ApiParam(value = "relay server object", required = true) RelayServerVO relayServerVo) 
	{
		mAddRelayServer(authToken, relayServerVo);
	}	
	
	@PUT
	@Produces({ MediaType.APPLICATION_JSON })
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/relay/{serverid}")
	@ApiOperation( value = "Add relay server", notes = "Add relay server")
	@ApiResponses
	( {
		@ApiResponse( code = HttpServletResponse.SC_CREATED, message = "Relay server updated successfully" )
	} )
	public void updateRelayServer(@ApiParam(value = "Authorization token", required = true) @HeaderParam("Authorization") String authToken,
			@ApiParam(value = "relay server id for update.", required = true) @PathParam("serverid") String serverid,
			@ApiParam(value = "relay server object", required = true) RelayServerVO relayServerVo) 
	{
		mUpdateRelayServer(authToken, relayServerVo);
	}
	
	@DELETE
	@Consumes("application/json")
	@Produces("application/json")
	@Path("/relay/{serverid}")
	@ApiOperation( value = "delete relay server .", 
	notes = "delete relay server.")
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to delete relay server.")			 
	} )
	public void deleteRelayServer(@ApiParam( value = "relay serverid.", required = true ) @PathParam("serverid") @NotNull String serverid,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken) throws ValidationException {
		mDeleteRelayServer(authToken, serverid);
	}
	

	@GET
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/supportrelay")
	@ApiOperation(value = "List support relay servers", notes = "List support relay server", response = HashMap.class)
	@ApiResponses({
			@ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to list support relay server.") })
	public void listSupportRelayServers(@ApiParam(value = "Authorization token", required = true) @HeaderParam("Authorization") String authToken)
			throws ValidationException {
		mListSupportRelayServer(authToken);
	}
	
	@GET
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/podrelay")
	@ApiOperation(value = "List support relay servers", notes = "List support relay server", response = HashMap.class)
	@ApiResponses({
			@ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to list support relay server.") })
	public void getPodRelayServers(@ApiParam(value = "Authorization token", required = true) @HeaderParam("Authorization") String authToken)
			throws ValidationException {
		getRelayServerPodDetails(authToken);
	}
	
	@POST
	@Produces({ MediaType.APPLICATION_JSON })
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/supportrelay")
	@ApiOperation( value = "Add support relay server", notes = "Add support relay server")
	@ApiResponses
	( {
		@ApiResponse( code = HttpServletResponse.SC_CREATED, message = "Support relay server added successfully" ),
		@ApiResponse( code = HttpServletResponse.SC_CONFLICT, message = "Support relay server already exists")
	} )
	public void addSupportRelayServer(@ApiParam(value = "Authorization token", required = true) @HeaderParam("Authorization") String authToken,
			@ApiParam(value = "support relay server object", required = true) RelayServerVO relayServerVo) 
	{
		mAddSupportRelayServer(authToken, relayServerVo);
	}	
	
	@PUT
	@Produces({ MediaType.APPLICATION_JSON })
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/supportrelay/{serverid}")
	@ApiOperation( value = "update support relay server", notes = "update support relay server")
	@ApiResponses
	( {
		@ApiResponse( code = HttpServletResponse.SC_CREATED, message = "support relay server updated successfully" )
	} )
	public void UpdateSupportRelayServer(@ApiParam(value = "Authorization token", required = true) @HeaderParam("Authorization") String authToken,
			@ApiParam(value = "relay server id for update.", required = true) @PathParam("serverid") String serverid,
			@ApiParam(value = "relay server object", required = true) RelayServerVO relayServerVo) 
	{
		mUpdateSupportRelayServer(authToken, relayServerVo);
	}	
	
	@DELETE
	@Consumes("application/json")
	@Produces("application/json")
	@Path("/supportrelay/{serverid}")
	@ApiOperation( value = "delete support relay server .", 
	notes = "delete support relay server.")
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to delete support relay server.")			 
	} )
	public void deleteSupportRelayServer(@ApiParam( value = "support relay serverid.", required = true ) @PathParam("serverid") @NotNull String serverid,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken) throws ValidationException {
		mDeleteSupportRelayServer(authToken, serverid);
	}


	@GET
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/email")
	@ApiOperation(value = "List email servers", notes = "List email server", response = HashMap.class)
	@ApiResponses({
			@ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to list email server.") })
	public void listEmailServers(@ApiParam(value = "Authorization token", required = true) @HeaderParam("Authorization") String authToken)
			throws ValidationException {
		mListEmailServer(authToken);
	}
	
	@POST
	@Produces({ MediaType.APPLICATION_JSON })
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/email")
	@ApiOperation( value = "Add email server", notes = "Add email server")
	@ApiResponses
	( {
		@ApiResponse( code = HttpServletResponse.SC_CREATED, message = "email server added successfully" ),
		@ApiResponse( code = HttpServletResponse.SC_CONFLICT, message = "email server already exists")
	} )
	public void addEmailServer(@ApiParam(value = "Authorization token", required = true) @HeaderParam("Authorization") String authToken,
			@ApiParam(value = "relay server object", required = true) EmailServersVO emailServerVo) 
	{
		mAddEmailServer(authToken, emailServerVo);
	}	
	
	@PUT
	@Produces({ MediaType.APPLICATION_JSON })
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/email/{serverid}")
	@ApiOperation( value = "update email server", notes = "update email server")
	@ApiResponses
	( {
		@ApiResponse( code = HttpServletResponse.SC_CREATED, message = "email server updated successfully" )
	} )
	public void updateEmailServer(@ApiParam(value = "Authorization token", required = true) @HeaderParam("Authorization") String authToken,
			@ApiParam(value = "email server id for update.", required = true) @PathParam("serverid") String serverid,
			@ApiParam(value = "email server object", required = true) EmailServersVO emailServerVo) 
	{
		mUpdateEmailServer(authToken, emailServerVo);
	}
	
	@DELETE
	@Consumes("application/json")
	@Produces("application/json")
	@Path("/email/{serverid}")
	@ApiOperation( value = "delete email server .", 
	notes = "delete email server.")
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to delete email server.")			 
	} )
	public void deleteEmailServer(@ApiParam( value = "email serverid.", required = true ) @PathParam("serverid") @NotNull String serverid,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken) throws ValidationException {
		mDeleteEmailServer(authToken, serverid);
	}
	

	@GET
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/rule")
	@ApiOperation(value = "List rules", notes = "List rules", response = HashMap.class)
	@ApiResponses({
			@ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to list rules.") })
	public void listRules(@ApiParam(value = "Authorization token", required = true) @HeaderParam("Authorization") String authToken)
			throws ValidationException {
		mListRules(authToken);
	}
	
	
	@GET
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/rule/{ruleid}")
	@ApiOperation(value = "List rules", notes = "List rules", response = HashMap.class)
	@ApiResponses({
			@ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to list rules.") })
	public void getRule(@ApiParam(value = "Authorization token", required = true) @HeaderParam("Authorization") String authToken,
			@ApiParam(value = "rule id for update.", required = true) @PathParam("ruleid") String ruleid)throws ValidationException {
		mgetRule(authToken, ruleid);
	}
	

	

	@POST
	@Produces({ MediaType.APPLICATION_JSON })
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/rule")
	@ApiOperation( value = "Add rule", notes = "Add rule")
	@ApiResponses
	( {
		@ApiResponse( code = HttpServletResponse.SC_CREATED, message = "rule added successfully" ),
		@ApiResponse( code = HttpServletResponse.SC_CONFLICT, message = "rule already exists")
	} )
	public void addRule(@ApiParam(value = "Authorization token", required = true) @HeaderParam("Authorization") String authToken,
			@ApiParam(value = "rule object", required = true) RuleVO rulevo) 
	{
		mAddRule(authToken, rulevo);
	}	
	
	@PUT
	@Produces({ MediaType.APPLICATION_JSON })
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/rule/{ruleid}")
	@ApiOperation( value = "update rule", notes = "update rule")
	@ApiResponses
	( {
		@ApiResponse( code = HttpServletResponse.SC_CREATED, message = "rule updated successfully" )
	} )
	public void updateRule(@ApiParam(value = "Authorization token", required = true) @HeaderParam("Authorization") String authToken,
			@ApiParam(value = "rule id for update.", required = true) @PathParam("ruleid") String ruleid,
			@ApiParam(value = "rule object", required = true) RuleVO ruleVo) 
	{
		mUpdateRule(authToken, ruleVo,ruleid);
	}
	
	

	@DELETE
	@Consumes("application/json")
	@Produces("application/json")
	@Path("/rule/{ruleid}")
	@ApiOperation( value = "delete rule.", 
	notes = "delete rule.")
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to delete rule.")			 
	} )
	public void deleteRule(@ApiParam( value = "ruleid.", required = true ) @PathParam("ruleid") @NotNull String ruleid,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken) throws ValidationException {
		mDeleteRule(authToken, ruleid);
	}
	
	@GET
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/rulelogs/{servertype}")
	@ApiOperation(value = "List rule trigger logs", notes = "List rule trigger logs", response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to get List rule trigger logs.")
	} )
	public void listLogs(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,
			@ApiParam(value = "server type", required = false) @PathParam("servertype") @DefaultValue("1") int servertype)
	{
		mListRuleTriggerLogs(authToken, servertype);
	}
	
	@GET
	@Path("/rulelogs")
	@ApiOperation(value = "List rule trigger logs", notes = "List rule trigger logs", response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to get List rule trigger logs.")
	} )
	public void listRuleLogs(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken)
	{
		mListRuleTriggerLogs(authToken);
	}
	
	
	private void mAddRule(String authToken, RuleVO rulevo) {
		
		try {
			// CHECK AUTH TOKEN...
			AuthorizationsVO authvo = new GrpcAuthHelper().getAuthorizationsVO(authToken);

			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.SERVER_RULE_ADD));
			AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, true);

			RuleVO result = new Rule().insert(rulevo);
			//insert activity
			new ActivityLogs().insert(authvo.getUserId(), ActivityOperation.addRule.name(), new Gson().toJson(rulevo));
			Map<String, Object> resultMap = new HashMap<>();
			resultMap.put(Constant.DATA, result);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);
		} 
		catch (Exception e) 
		{
			PALogger.ERROR(e);
			if(e.getMessage().equals(Constant.UNAUTHORIZED)) {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_METHOD_NOT_ALLOWED , Constant.NOT_ALLOWED, Constant.NOT_ALLOWED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().contains("Duplicate entry"))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Rule type already exist.", "Rule type already exist.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e.getMessage(),
						e.getMessage());
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}

		}
		
	}
	
	private void mUpdateRule(String authToken, RuleVO ruleVo, String ruleid) {
		try {
			// CHECK AUTH TOKEN...
			AuthorizationsVO authvo = new GrpcAuthHelper().getAuthorizationsVO(authToken);

			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.SERVER_RULE_EDIT));
			AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, true);

			RuleVO result = new Rule().update(ruleid, ruleVo.getRuleValue());
			
			//insert activity
			new ActivityLogs().insert(authvo.getUserId(), ActivityOperation.updateRule.name(), new Gson().toJson(ruleVo));
			Map<String, Object> resultMap = new HashMap<>();
			resultMap.put(Constant.DATA, result);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);
		} 
		catch (Exception e) 
		{
			PALogger.ERROR(e);
			if(e.getMessage().equals(Constant.UNAUTHORIZED)) {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_METHOD_NOT_ALLOWED , Constant.NOT_ALLOWED, Constant.NOT_ALLOWED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e.getMessage(),
						e.getMessage());
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}

		}
		
	}
	
	private void mListRules(String authToken) {
		try {
			// CHECK AUTH TOKEN...
				AuthorizationsVO authvo = new GrpcAuthHelper().getAuthorizationsVO(authToken);
	
				List<String> lstPermissions = new ArrayList<>();
				lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.SERVER_RULE_LIST));
				AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, true);

			List<RuleVO> result = new Rule().listsAll();
			
			Map<String, Object> resultMap = new HashMap<>();
			resultMap.put(Constant.DATA, result);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);
		} 
		catch (Exception e) 
		{
			PALogger.ERROR(e);
			if(e.getMessage().equals(Constant.UNAUTHORIZED)) {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_METHOD_NOT_ALLOWED , Constant.NOT_ALLOWED, Constant.NOT_ALLOWED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e.getMessage(),
						e.getMessage());
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}

		}
	}
	
	private void mListRuleTriggerLogs(String authToken, int serverType)
	{
		try 
		{
			//CHECK AUTH TOKEN...
			new GrpcAuthHelper().checkAuthorization(authToken);
			ReturnObject.createResponse(Constant.SUCCESS, new RuleTriggerLogs().list(RuleType.GetEnum(serverType) ), null, response);
		} 
		catch (Exception e) 
		{
			PALogger.ERROR(e);	
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, e);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to list Rule Trigger Logs.", e);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			PALogger.ERROR(e);	
		}
		
	}
	
	private void mListRuleTriggerLogs(String authToken)
	{
		try 
		{
			//CHECK AUTH TOKEN...
			new GrpcAuthHelper().checkAuthorization(authToken);
			ReturnObject.createResponse(Constant.SUCCESS, new RuleTriggerLogs().list(), null, response);
		} 
		catch (Exception e) 
		{
			PALogger.ERROR(e);	
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, e);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to list Rule Trigger Logs.", e);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			PALogger.ERROR(e);	
		}
		
	}
	
	private void mgetRule(String authToken, String ruleID) {
		try {
			// CHECK AUTH TOKEN...
			AuthorizationsVO authvo = new GrpcAuthHelper().getAuthorizationsVO(authToken);

			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.SERVER_RULE_LIST));
			AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, true);

			RuleVO result = new Rule().get(ruleID);
			
			Map<String, Object> resultMap = new HashMap<>();
			resultMap.put(Constant.DATA, result);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);
		} 
		catch (Exception e) 
		{
			PALogger.ERROR(e);
			if(e.getMessage().equals(Constant.UNAUTHORIZED)) {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_METHOD_NOT_ALLOWED , Constant.NOT_ALLOWED, Constant.NOT_ALLOWED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e.getMessage(),
						e.getMessage());
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}

		}
	}

	private void mListRelayServer(String authToken) 
	{
		try {
			// CHECK AUTH TOKEN...
			AuthorizationsVO authvo = new GrpcAuthHelper().getAuthorizationsVO(authToken);

			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.SERVER_LIST));
			AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, true);

			List<RelayServerVO> result = new RelayServers().listsAllRelayServer(true);
			
			Map<String, Object> resultMap = new HashMap<>();
			resultMap.put(Constant.DATA, result);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);
		} 
		catch (Exception e) 
		{
			PALogger.ERROR(e);
			if(e.getMessage().equals(Constant.UNAUTHORIZED)) {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_METHOD_NOT_ALLOWED , Constant.NOT_ALLOWED, Constant.NOT_ALLOWED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e.getMessage(),
						e.getMessage());
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}

		}
	}
	
	private void mAddRelayServer(String authToken,RelayServerVO relayServerVo) 
	{
		try {
			// CHECK AUTH TOKEN...
			AuthorizationsVO authvo = new GrpcAuthHelper().getAuthorizationsVO(authToken);

			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.SERVER_ADD));
			AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, true);

			RelayServerVO  result = new RelayServers().insertRelayServer(relayServerVo, true);//Checking for admin user then oonly calling this function so passing true.-PS
			
			//insert activity
			new ActivityLogs().insert(authvo.getUserId(), ActivityOperation.addRelayServer.name(), new Gson().toJson(relayServerVo));
			Map<String, Object> resultMap = new HashMap<>();
			resultMap.put(Constant.DATA, result);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);
		} 
		catch (Exception e) 
		{
			PALogger.ERROR(e);
			if(e.getMessage().equals(Constant.UNAUTHORIZED)) {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_METHOD_NOT_ALLOWED , Constant.NOT_ALLOWED, Constant.NOT_ALLOWED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e.getMessage(),
						e.getMessage());
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}

		}
	}

	private void mUpdateRelayServer(String authToken, RelayServerVO relayServerVo) 
	{
		try {
			// CHECK AUTH TOKEN...
			AuthorizationsVO authvo = new GrpcAuthHelper().getAuthorizationsVO(authToken);

			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.SERVER_EDIT));
			AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, true);

			RelayServerVO  result = new RelayServers().updateRelayServer(relayServerVo, true);
			//insert activity
			new ActivityLogs().insert(authvo.getUserId(), ActivityOperation.updateRelayServer.name(), new Gson().toJson(relayServerVo));
			Map<String, Object> resultMap = new HashMap<>();
			resultMap.put(Constant.DATA, result);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);
		} 
		catch (Exception e) 
		{
			PALogger.ERROR(e);
			if(e.getMessage().equals(Constant.UNAUTHORIZED)) {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_METHOD_NOT_ALLOWED , Constant.NOT_ALLOWED, Constant.NOT_ALLOWED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e.getMessage(),
						e.getMessage());
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}

		}
	}
	
	private void mDeleteRule(String authToken, String ruleId) 
	{
		try {
			// CHECK AUTH TOKEN...
			AuthorizationsVO authvo = new GrpcAuthHelper().getAuthorizationsVO(authToken);

			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.SERVER_RULE_DELETE));
			AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, true);

			new Rule().delete(ruleId);
			//insert activity
			Map<String, Object> map = new HashMap<>();
			map.put("ruleId", ruleId);

			new ActivityLogs().insert(authvo.getUserId(), ActivityOperation.deleteRule.name(), new Gson().toJson(map));
			ReturnObject.createResponse(Constant.SUCCESS, null, null, response);
		} 
		catch (Exception e) 
		{
			PALogger.ERROR(e);
			if(e.getMessage().equals(Constant.UNAUTHORIZED)) {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_METHOD_NOT_ALLOWED , Constant.NOT_ALLOWED, Constant.NOT_ALLOWED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e.getMessage(),
						e.getMessage());
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}

		}
	}
	
	
	private void mDeleteRelayServer(String authToken, String serverid) 
	{
		try {
			// CHECK AUTH TOKEN...
			AuthorizationsVO authvo = new GrpcAuthHelper().getAuthorizationsVO(authToken);

			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.SERVER_DELETE));
			AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, true);

			new RelayServers().deleteRelayServer(serverid);
			//insert activity
			Map<String, Object> map = new HashMap<>();
			map.put("serverId", serverid);

			new ActivityLogs().insert(authvo.getUserId(), ActivityOperation.deleteRelayServer.name(), new Gson().toJson(map));
			
			ReturnObject.createResponse(Constant.SUCCESS, null, null, response);
		} 
		catch (Exception e) 
		{
			PALogger.ERROR(e);
			if(e.getMessage().equals(Constant.UNAUTHORIZED)) {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_METHOD_NOT_ALLOWED , Constant.NOT_ALLOWED, Constant.NOT_ALLOWED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e.getMessage(),
						e.getMessage());
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}

		}
	}
	
	
	private void mListSupportRelayServer(String authToken) 
	{
		try {
			// CHECK AUTH TOKEN...
			AuthorizationsVO authvo = new GrpcAuthHelper().getAuthorizationsVO(authToken);

			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.SERVER_LIST));
			AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, true);

			List<RelayServerVO> result = new SupportRelayServer().listsAllSupportRelayServer(true);
			
			Map<String, Object> resultMap = new HashMap<>();
			resultMap.put(Constant.DATA, result);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);
		} 
		catch (Exception e) 
		{
			PALogger.ERROR(e);
			if(e.getMessage().equals(Constant.UNAUTHORIZED)) {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_METHOD_NOT_ALLOWED , Constant.NOT_ALLOWED, Constant.NOT_ALLOWED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e.getMessage(),
						e.getMessage());
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}

		}
	}
	
	private void mAddSupportRelayServer(String authToken,RelayServerVO relayServerVo) 
	{
		try {
			// CHECK AUTH TOKEN...
			AuthorizationsVO authvo = new GrpcAuthHelper().getAuthorizationsVO(authToken);

			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.SERVER_ADD));
			AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, true);

			RelayServerVO  result = new SupportRelayServer().insertSupportRelayServer(relayServerVo, true);
			//insert activity
			new ActivityLogs().insert(authvo.getUserId(), ActivityOperation.addSupportRelayServer.name(), new Gson().toJson(relayServerVo));
			Map<String, Object> resultMap = new HashMap<>();
			resultMap.put(Constant.DATA, result);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);
		} 
		catch (Exception e) 
		{
			PALogger.ERROR(e);
			if(e.getMessage().equals(Constant.UNAUTHORIZED)) {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_METHOD_NOT_ALLOWED , Constant.NOT_ALLOWED, Constant.NOT_ALLOWED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,e.getMessage(),
						e.getMessage());
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}

		}
	}

	private void mUpdateSupportRelayServer(String authToken, RelayServerVO relayServerVo) 
	{
		try {
			// CHECK AUTH TOKEN...
			AuthorizationsVO authvo = new GrpcAuthHelper().getAuthorizationsVO(authToken);

			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.SERVER_EDIT));
			AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, true);

			RelayServerVO  result = new SupportRelayServer().updateSupportRelayServer(relayServerVo, true);
			//insert activity
			new ActivityLogs().insert(authvo.getUserId(), ActivityOperation.updateSupportRelayServer.name(), new Gson().toJson(relayServerVo));
			Map<String, Object> resultMap = new HashMap<>();
			resultMap.put(Constant.DATA, result);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);
		} 
		catch (Exception e) 
		{
			PALogger.ERROR(e);
			if(e.getMessage().equals(Constant.UNAUTHORIZED)) {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_METHOD_NOT_ALLOWED , Constant.NOT_ALLOWED, Constant.NOT_ALLOWED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e.getMessage(),
						e.getMessage());
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}

		}
	}
	
	private void mDeleteSupportRelayServer(String authToken, String serverid) 
	{
		try {
			// CHECK AUTH TOKEN...
			AuthorizationsVO authvo = new GrpcAuthHelper().getAuthorizationsVO(authToken);

			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.SERVER_DELETE));
			AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, true);

			new SupportRelayServer().deleteSupportRelayServer(serverid);
			//insert activity
			Map<String, Object> map = new HashMap<>();
			map.put("serverId", serverid);

			new ActivityLogs().insert(authvo.getUserId(), ActivityOperation.deleteSupportRelayServer.name(), new Gson().toJson(map));
			
			ReturnObject.createResponse(Constant.SUCCESS, null, null, response);
		} 
		catch (Exception e) 
		{
			PALogger.ERROR(e);
			if(e.getMessage().equals(Constant.UNAUTHORIZED)) {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_METHOD_NOT_ALLOWED , Constant.NOT_ALLOWED, Constant.NOT_ALLOWED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e.getMessage(),
						e.getMessage());
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}

		}
	}
	
	private void mListEmailServer(String authToken) 
	{
		try {
			// CHECK AUTH TOKEN...
			AuthorizationsVO authvo = new GrpcAuthHelper().getAuthorizationsVO(authToken);

			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.SERVER_LIST));
			AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, true);

			List<EmailServersVO> result = new EmailServers().listsAll(true);
			
			Map<String, Object> resultMap = new HashMap<>();
			resultMap.put(Constant.DATA, result);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);
		} 
		catch (Exception e) 
		{
			PALogger.ERROR(e);
			if(e.getMessage().equals(Constant.UNAUTHORIZED)) {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_METHOD_NOT_ALLOWED , Constant.NOT_ALLOWED, Constant.NOT_ALLOWED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e.getMessage(),
						e.getMessage());
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}

		}
	}
	
	private void mAddEmailServer(String authToken,EmailServersVO emailServerVo) 
	{
		try {
			// CHECK AUTH TOKEN...
			AuthorizationsVO authvo = new GrpcAuthHelper().getAuthorizationsVO(authToken);
			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.SERVER_ADD));
			AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, true);

			EmailServersVO  result = new EmailServers().insert(emailServerVo);
			//insert activity
			new ActivityLogs().insert(authvo.getUserId(), ActivityOperation.addEmailServer.name(), new Gson().toJson(emailServerVo));
			Map<String, Object> resultMap = new HashMap<>();
			resultMap.put(Constant.DATA, result);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);
		} 
		catch (Exception e) 
		{
			PALogger.ERROR(e);
			if(e.getMessage().equals(Constant.UNAUTHORIZED)) {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_METHOD_NOT_ALLOWED , Constant.NOT_ALLOWED, Constant.NOT_ALLOWED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e.getMessage(),
						e.getMessage());
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}

		}
	}

	private void mUpdateEmailServer(String authToken, EmailServersVO emailServerVo) 
	{
		try {
			// CHECK AUTH TOKEN...
			AuthorizationsVO authvo = new GrpcAuthHelper().getAuthorizationsVO(authToken);

			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.SERVER_EDIT));
			AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, true);

			EmailServersVO  result = new EmailServers().update(emailServerVo);
			//insert activity
			new ActivityLogs().insert(authvo.getUserId(), ActivityOperation.updateEmailServer.name(), new Gson().toJson(emailServerVo));
			Map<String, Object> resultMap = new HashMap<>();
			resultMap.put(Constant.DATA, result);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);
		} 
		catch (Exception e) 
		{
			PALogger.ERROR(e);
			if(e.getMessage().equals(Constant.UNAUTHORIZED)) {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_METHOD_NOT_ALLOWED , Constant.NOT_ALLOWED, Constant.NOT_ALLOWED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e.getMessage(),
						e.getMessage());
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}

		}
	}
	
	
	private void mDeleteEmailServer(String authToken, String serverId) 
	{
		try {
			// CHECK AUTH TOKEN...
			AuthorizationsVO authvo = new GrpcAuthHelper().getAuthorizationsVO(authToken);

			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.SERVER_DELETE));
			AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, true);

			new EmailServers().delete(serverId);
			//insert activity
			Map<String, Object> map = new HashMap<>();
			map.put("serverId", serverId);

			new ActivityLogs().insert(authvo.getUserId(), ActivityOperation.deleteEmailServer.name(), new Gson().toJson(map));
			ReturnObject.createResponse(Constant.SUCCESS, null, null, response);
		} 
		catch (Exception e) 
		{
			PALogger.ERROR(e);
			if(e.getMessage().equals(Constant.UNAUTHORIZED)) {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_METHOD_NOT_ALLOWED , Constant.NOT_ALLOWED, Constant.NOT_ALLOWED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e.getMessage(),
						e.getMessage());
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}

		}
	}
	
	
	private void getRelayServerPodDetails(String authToken) 
	{
		try {
			// CHECK AUTH TOKEN...
			AuthorizationsVO authvo = new GrpcAuthHelper().getAuthorizationsVO(authToken);

			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.SERVER_LIST));
			AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, true);

			Map<String,String> result = new RelayServers().getRelayServerPodDetails();
			
			Map<String, Object> resultMap = new HashMap<>();
			resultMap.put(Constant.DATA, result);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);
		} 
		catch (Exception e) 
		{
			PALogger.ERROR(e);
			if(e.getMessage().equals(Constant.UNAUTHORIZED)) {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_METHOD_NOT_ALLOWED , "Not allowed.", "Not allowed.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e.getMessage(),
						e.getMessage());
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}

		}
	}

}
