/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.mwp.grpc.auth;


import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpServletResponse;

import com.mwp.common.Client;
import com.mwp.common.constant.Constant;
import com.mwp.common.vo.AuthorizationsVO;
import com.mwp.common.vo.ErrorVo;
import com.mwp.grpc.auth.AuthorizationGrpc.AuthorizationBlockingStub;
import com.mwp.logger.PALogger;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.StatusRuntimeException;

public class AuthGrpcClient {

	ManagedChannel channel;
	AuthorizationBlockingStub blockingStub;


	private static AuthGrpcClient instance;
	private static Object lockInstance =  new Object();

	public static AuthGrpcClient getInstance(){
		if(instance == null)
		{
			return mGetInstance();
		}
		return instance;
	}

	private static AuthGrpcClient mGetInstance() {
		synchronized (lockInstance) {


			if(instance == null)
			{
				instance = new AuthGrpcClient("localhost", 55000);
			}
			return instance;
		}
	}

	private AuthGrpcClient(String host, int port) 
	{
		//DB - Added executor as per https://github.com/grpc/grpc-java/issues/2358 to solve memory leaks		
		this.channel = ManagedChannelBuilder.forAddress(host, port).executor(Executors.newFixedThreadPool(50))
				.usePlaintext()
				.build();
		blockingStub = AuthorizationGrpc.newBlockingStub(channel);

	}

	public AuthorizationsVO validateToken(String authToken) throws Exception {

		try
		{
			AuthRequest request = AuthRequest.newBuilder().setAuthtoken(authToken).build();
			AuthResponse response = blockingStub.validateToken(request);
			return Client.getGson().fromJson(response.getAuthvo(), AuthorizationsVO.class);

		}
		catch(StatusRuntimeException ex)
		{
			PALogger.ERROR(ex);
			if(ex.getCause() instanceof java.net.ConnectException)
			{
				throw new Exception("Unable to communicate with auth service");
			}
			else
			{
				ErrorVo err = Client.getGson().fromJson(ex.getStatus().getDescription(), ErrorVo.class);
				if(err.getCode() == HttpServletResponse.SC_INTERNAL_SERVER_ERROR) {
					throw new Exception(err.getMessage());
				} else {
					throw new Exception(Constant.UNAUTHORIZED);
				}
			}
		}
	}

	public void shutdown() throws InterruptedException{
		this.channel.shutdown().awaitTermination(5, TimeUnit.SECONDS);
	}
}
