/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.mwp.p.service;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import javax.validation.ValidationException;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.mwp.common.ReturnObject;
import com.mwp.common.StringFunctions;
import com.mwp.common.constant.Constant;
import com.mwp.common.constant.ErrorMessage;
import com.mwp.common.enums.ActivityOperation;
import com.mwp.common.vo.AuthorizationsVO;
import com.mwp.common.vo.ErrorVo;
import com.mwp.common.vo.FilterObject;
import com.mwp.common.vo.NetworkVO;
import com.mwp.logger.PALogger;
import com.mwp.p.authhelper.GrpcAuthHelper;
import com.mwp.p.framework.ActivityLogs;
import com.mwp.p.framework.Network;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

// description = "This class is used for network setup."
@Path("/network")
@Api(value = "/network")
public class NetworkEndpoint 
{

	@Context
	private HttpServletResponse response;
	
	@POST
	@Consumes({MediaType.APPLICATION_JSON})
	@ApiOperation( value = "add network.",
	notes = "add network.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to add network." )	 
	} )
	public void addNetwork(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,
			@ApiParam(value = "add network object.", required = true) NetworkVO networkObj) 
	{
		mCreateNetwork(authToken, networkObj);
	}

	@GET
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/searchnetwork/pages/{pageno}")
	@ApiOperation(value = "List network using requested search  param", notes = "List of network according to requested search  param", response = HashMap.class)
	@ApiResponses({
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to search network.")
	})
	public void searchNetwork
	(
			@ApiParam(value = "requested page no for list devcie.", required = false) @Min(1) @PathParam("pageno") @DefaultValue("1") int pageNo,
			@ApiParam(value = "requested page size number of element return in a list network.", required = false) @Min(1) @QueryParam("pagesize") @DefaultValue("5") int pageSize,
			@ApiParam(value = "FilterObject", required = false) @QueryParam("filters") String filters,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken) throws ValidationException{
		mListNetworkFilter(authToken, filters, pageNo, pageSize);
	}
	
	@DELETE
	@Consumes({MediaType.APPLICATION_JSON})
	@Path("/{networkid}")
	@ApiOperation( value = "delete network.",
	notes = "delete network.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_NOT_FOUND, message = "Requested network not found." ),
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to delete network.")
	} )
	public void deleteNetwork(@ApiParam(value = "id of network.", required = true) @PathParam("networkid") String networkId,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken) {
		mDelete(authToken, networkId);
	}
	
	@PUT
	@Consumes({MediaType.APPLICATION_JSON})
	@Path("/{networkid}")
	@ApiOperation( value = "update network.",
	notes = "update network.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to update network name.") 
	} )
	public void updateNetworkName(@ApiParam(value = "id of network.", required = true) @PathParam("networkid") String networkId,
			@ApiParam(value = "new name.", required = true)  @Valid @NotNull String networkName,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken) 
	{
		mUpdate(authToken, networkId, networkName);
	}
	
	public void mCreateNetwork(String authToken, NetworkVO networkObj)
	{
		try
		{
			//CHECK AUTH TOKEN...
			String userId = new GrpcAuthHelper().checkAuthorization(authToken);
			Network net = new Network();
			NetworkVO netVo =	net.createNetwork(networkObj.getNetworkName(), userId, networkObj.getNetworkType());
			Map<String, Object> resultMap = new HashMap<>();
			resultMap.put(Constant.DATA, netVo);

			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);

		} catch (Exception e) {
			PALogger.ERROR(e);
			if(e.getMessage().equals(Constant.UNAUTHORIZED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(ErrorMessage.NETWORK_EXIST))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , e.getMessage(), e.getMessage());
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to add new network.", "Unable to add network.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
		}
	}
	
    public void  mListNetworkFilter(String authToken,String filters,long pageNo, int pageSize)
	{
		try
		{
			//CHECK AUTH TOKEN...
			AuthorizationsVO authorizationsVO = new GrpcAuthHelper().getAuthorizationsVO(authToken);

			List<FilterObject> filtersObject = null;
			if(!StringFunctions.isNullOrWhitespace(filters))
			{
				filtersObject = new Gson().fromJson(filters,new TypeToken<List<FilterObject>>() {}.getType());
			}
			Network net = new Network();
			Map<String, Object> resultMap = net.listNetworkFilter(filtersObject, pageNo, pageSize, authorizationsVO.getUserId());
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null,response);
		}  
		catch (Exception e)
		{
			PALogger.ERROR(e);	
			if(e.getMessage().equals(Constant.UNAUTHORIZED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else {
			ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,"Unable to list network.","Unable to list network.");
			ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);	
			PALogger.ERROR(e);	
			}

		}
	}
	
    public void mDelete(String authToken ,String networkId)
	{
		try
		{

			String userId = new GrpcAuthHelper().checkAuthorization(authToken);
			Network net = new Network();
			net.delete(networkId);
			//insert activity
			Map<String, String> map = new HashMap<>();
			map.put("networkId", networkId);
			new ActivityLogs().insert(userId, ActivityOperation.deleteNetwork.name(), new Gson().toJson(map));

			ReturnObject.createResponse(Constant.SUCCESS, null, null, response);
		}  
		catch (Exception e)
		{
			PALogger.ERROR(e);	
			if(e.getMessage().equals(Constant.UNAUTHORIZED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else {
			ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,"Unable to delete network.","Unable to delete network.");
			ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);	
			PALogger.ERROR(e);	
			}

		}
	
	}
	
    public void mUpdate(String authToken, String networkId,String networkName)
	{
		try
		{

			String userId = new GrpcAuthHelper().checkAuthorization(authToken);
			Network net = new Network();
			net.update(networkId, networkName);
			//insert activity
			Map<String, Object> map = new HashMap<>();
			map.put("networkId", networkId);
			map.put("networkName", networkName);

			new ActivityLogs().insert(userId, ActivityOperation.editNetwork.name(), new Gson().toJson(map));

			ReturnObject.createResponse(Constant.SUCCESS, null, null, response);
		}  
		catch (Exception e)
		{
			PALogger.ERROR(e);	
			if(e.getMessage().equals(Constant.UNAUTHORIZED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else {
			ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,"Unable to update network name.","Unable to update network name.");
			ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);	
			PALogger.ERROR(e);	
			}

		}
	}

	public void linkApp(String authToken,String appId,String networkId)throws SQLException
	{
		try
		{

			String userId = new GrpcAuthHelper().checkAuthorization(authToken);
			Network net = new Network();
			net.linkApp(appId, networkId);
			//insert activity
			Map<String, Object> map = new HashMap<>();
			map.put("networkId", networkId);
			map.put("appId", appId);

			new ActivityLogs().insert(userId, ActivityOperation.linkApp.name(), new Gson().toJson(map));
			ReturnObject.createResponse(Constant.SUCCESS, null, null, response);
		}  
		catch (Exception e)
		{
			PALogger.ERROR(e);	
			if(e.getMessage().equals(Constant.UNAUTHORIZED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else {
			ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,"Unable to link app in network.","Unable to link app in network.");
			ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);	
			PALogger.ERROR(e);	
			}

		}
	}
}
