/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.mwp.p.service;

import java.io.IOException;
import java.lang.reflect.Type;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.ValidationException;
import javax.validation.constraints.Min;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.HttpMethod;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.mwp.common.Client;
import com.mwp.common.ReturnObject;
import com.mwp.common.StringFunctions;
import com.mwp.common.constant.Constant;
import com.mwp.common.constant.PermissionResourceKeys;
import com.mwp.common.constant.PermissionResources;
import com.mwp.common.enums.ActivityOperation;
import com.mwp.common.enums.MessageType;
import com.mwp.common.enums.NotificationType;
import com.mwp.common.enums.OwnershipEnum;
import com.mwp.common.enums.RoleEnum;
import com.mwp.common.enums.UserStatusEnum;
import com.mwp.common.vo.ApplicationUserVO;
import com.mwp.common.vo.AuthorizationsVO;
import com.mwp.common.vo.ErrorVo;
import com.mwp.common.vo.FilterObject;
import com.mwp.common.vo.UsersVO;
import com.mwp.logger.PALogger;
import com.mwp.p.authhelper.GrpcAuthHelper;
import com.mwp.p.common.AdminPermissionCheck;
import com.mwp.p.common.Constants;
import com.mwp.p.common.enums.PortalDBEnum.SETTINGS_KEY;
import com.mwp.p.framework.ActivityLogs;
import com.mwp.p.framework.Alerts;
import com.mwp.p.framework.Applications;
import com.mwp.p.framework.Devices;
import com.mwp.p.framework.Settings;
import com.sun.research.ws.wadl.HTTPMethods;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Path("/admin")
@Api(value = "/admin", produces = MediaType.APPLICATION_JSON, description = "Class  list devices, list application of devices.")
public class AdminEndpoint {
	@Context
	private HttpServletResponse response;
	@Context
	private HttpServletRequest request;

	@GET
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/edgecore/pages/{pageno}")
	@ApiOperation(value = "List devices using requested search text param", notes = "List of devcies according to requested search text param", response = HashMap.class)
	@ApiResponses({
		@ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to search of devices.") })
	public void listEdgeCore(
			@ApiParam(value = "requested page no for list devcies.", required = false) @Min(1) @PathParam("pageno") @DefaultValue("1") int pageNo,
			@ApiParam(value = "requested page size number of element return in a list device.", required = false) @Min(1) @QueryParam("pagesize") @DefaultValue("5") int pageSize,
			@ApiParam(value = "FilterObject", required = false) @QueryParam("filters") String filters,
			@ApiParam(value = "Authorization token", required = true) @HeaderParam("Authorization") String authToken,
			@ApiParam(value = "List of user ids", required = false) HashMap<String, Object> bodyContent)
					throws ValidationException {
		mListEdgeCore(authToken, pageNo, pageSize, filters,bodyContent);
	}


	@GET
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/apps/pages/{pageno}")
	@ApiOperation(value = "List application using requested search text param", notes = "List of application according to requested search text param", response = HashMap.class)
	@ApiResponses({
		@ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to search applications.")})
	public void listApplication(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,
			@ApiParam(value = "requested page no for list application.", required = false) @Min(1) @PathParam("pageno") @DefaultValue("1") int pageNo,
			@ApiParam(value = "requested page size number of element return in a list application.", required = false) @Min(1) @QueryParam("pagesize") @DefaultValue("5") int pageSize,
			@ApiParam(value = "FilterObject", required = false) @QueryParam("filters") String filters) throws ValidationException{
		mListApplication(authToken,pageNo, pageSize, filters);
	}

	@GET
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/versions/pages/{pageno}")
	@ApiOperation(value = "List application using requested search text param", notes = "List of application according to requested search text param", response = HashMap.class)
	@ApiResponses({
		@ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to search applications.")})
	public void listVersions(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,
			@ApiParam(value = "requested page no for list application.", required = false) @Min(1) @PathParam("pageno") @DefaultValue("1") int pageNo,
			@ApiParam(value = "requested page size number of element return in a list application.", required = false) @Min(1) @QueryParam("pagesize") @DefaultValue("5") int pageSize) throws ValidationException{
		mListVersion(authToken,pageNo, pageSize);
	}



	@GET
	@Produces({ MediaType.APPLICATION_JSON })
	@Path("/user/count")
	@ApiOperation( value = "get user count according to user status", notes = "get user count according to user status.", response = UsersVO.class )
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_NO_CONTENT, message = "User  doesn't exists" )			 
	} )
	public void getUserCount(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken){

		mGetUserCount(authToken);

	}
	@PUT
	@Produces({ MediaType.APPLICATION_JSON })
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/user/suspend")
	public void suspendUser(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,@ApiParam(value = "list of user to suspend", required = true)  List<String> appUserIds) 
	{
		mSuspendResumeUser(authToken,appUserIds, UserStatusEnum.Suspended);
	}

	@PUT
	@Produces({ MediaType.APPLICATION_JSON })
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/user/resume")
	public void resumeUser(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,@ApiParam(value = "list of user to resume", required = true)  List<String> appUserIds) 
	{
		mSuspendResumeUser(authToken,appUserIds, UserStatusEnum.Approved);
	}
	
	@PUT
	@Produces({ MediaType.APPLICATION_JSON })
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/markApproved/{userId}/")
	public void markApproved(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,
			@ApiParam( value = "User id whose path going to be changed.", required = true ) @PathParam("userId") final String userId) 
	{
		mMarkApproved(authToken,userId);
	}
	@GET
	@Produces({ MediaType.APPLICATION_JSON })
	@Path("/apps/count")
	@ApiOperation( value = "get app count according to app status", notes = "get app count according to app status.", response = UsersVO.class )
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_NO_CONTENT, message = "app  doesn't exists" )			 
	} )
	public void getAppCount(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken){

		mGetAppCount(authToken);

	}

	@GET
	@Produces({ MediaType.APPLICATION_JSON })
	@Path("/edgecore/count")
	@ApiOperation( value = "get device count according to  status", notes = "get device count according to status.", response = UsersVO.class )
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_NO_CONTENT, message = "device  doesn't exists" )			 
	} )
	public void getEdgecoreCount(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken){

		mgetEdgeCoreCount(authToken);

	}

	@PUT
	@Produces({ MediaType.APPLICATION_JSON })
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/logs")
	public void updateLogSettings(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,@ApiParam(value = "list of log levels and their status", required = true)  HashMap<String,Boolean> logSettings) 
	{
		mLogSettings(authToken,logSettings);
	}

	@GET
	@Produces({ MediaType.APPLICATION_JSON })
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/settings")
	public void getSettings(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,@ApiParam(value = "list of log levels and their status", required = true)  HashMap<String,Boolean> logSettings) 
	{
		mGetSettings(authToken);
	}


	@GET
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/alerts/pages/{pageno}")
	@ApiOperation(value = "List alerts according to filters", notes = "List alerts according to filters", response = HashMap.class)
	@ApiResponses({
		@ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to search of devices.") })
	public void listAlerts(
			@ApiParam(value = "requested page no for list alerts.", required = false) @Min(1) @PathParam("pageno") @DefaultValue("1") int pageNo,
			@ApiParam(value = "requested page size number of element return in a list alerts.", required = false) @Min(1) @QueryParam("pagesize") @DefaultValue("5") int pageSize,
			@ApiParam(value = "FilterObject", required = false) @QueryParam("filters") String filters,
			@ApiParam(value = "Authorization token", required = true) @HeaderParam("Authorization") String authToken)
					throws ValidationException {
		mListAlerts(authToken, pageNo, pageSize, filters);
	}

	/**
	 * Method processing HTTP GET requests, producing "application/json" MIME
	 * media-type.
	 * 
	 * <p>
	 * This method gives List of activity according to requested search text.
	 * </p>
	 * 
	 * @param pageNo
	 *            request previous page information.
	 * @param pageSize
	 *            request number of activities give in one call.
	 * @param filters
	 *            filter object with filter type,keys,search value, sort order etc
	 * @param httpHeaders
	 * @return String that will be send back as a response of type json.
	 */
	@GET
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/activity/pages/{pageno}")
	@ApiOperation(value = "List activities using requested filter", notes = "List activities using requested filter", response = HashMap.class)
	@ApiResponses({
		@ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to search activity.")})
	public void listActivity(
			@ApiParam(value = "requested page no for list activity.", required = false) @Min(1) @PathParam("pageno") @DefaultValue("1") int pageNo,
			@ApiParam(value = "requested page size number of element return in a list activity.", required = false) @Min(1) @QueryParam("pagesize") @DefaultValue("5") int pageSize,
			@ApiParam(value = "FilterObject", required = false) @QueryParam("filters") String filters,
			@ApiParam(value = "Authorization token", required = true) @HeaderParam("Authorization") String authToken) throws ValidationException{
		mListActivity(pageNo, pageSize, filters,authToken);
	}


	@DELETE
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/activity/days/{days}")
	@ApiOperation(value = "Delete activities older than given no of days",
	notes = "Delete activities older than given no of days",
	response = HashMap.class)
	@ApiResponses({
		@ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to delete activity.")})
	public void deleteActivity(
			@ApiParam(value = "requested page no for list activity.", required = true)  @PathParam("days") int noOfDays,
			@ApiParam(value = "Authorization token", required = true) @HeaderParam("Authorization") String authToken) throws ValidationException{
		mDeleteActivity(noOfDays,authToken);
	}


	private void mListEdgeCore(String authToken, int pageNo, int pageSize, String filters, HashMap<String, Object> bodyContent) {
		try {
			// CHECK AUTH TOKEN...
			AuthorizationsVO authvo = new GrpcAuthHelper().getAuthorizationsVO(authToken);

			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.APPLIANCES_LIST));
			AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, true);

			List<FilterObject> filtersObject = null;
			if (!StringFunctions.isNullOrWhitespace(filters)) {
				filtersObject = new Gson().fromJson(filters, new TypeToken<ArrayList<FilterObject>>() {
				}.getType());
			}
			Devices device = new Devices();
			String userId="";
			if(bodyContent != null && bodyContent.containsKey("userId"))
				userId = bodyContent.get("userId").toString();
			Map<String, Object> resultMap = device.listDeviceFilter(userId, pageNo, pageSize, filtersObject, false,OwnershipEnum.None,null);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);
		} 
		catch (Exception e) 
		{
			PALogger.ERROR(e);
			if(e.getMessage().equals(Constant.UNAUTHORIZED)) {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_METHOD_NOT_ALLOWED , Constant.NOT_ALLOWED , Constant.NOT_ALLOWED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Unable to Appliance.",
						"Unable to Appliance.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}

		}
	}

	private void mListApplication(String authToken,int pageNo, int pageSize,String filters) {
		try {
			AuthorizationsVO authvo = new GrpcAuthHelper().getAuthorizationsVO(authToken);

			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.APP_LIST));
			AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, true);
			List<FilterObject> filtersObject = null;
			if(!StringFunctions.isNullOrWhitespace(filters)) 
			{
				filtersObject = new Gson().fromJson(filters,new TypeToken<ArrayList<FilterObject>>() {}.getType());
			}
			Applications applications = new Applications();
			Map<String, Object> resultMap = applications.searchApps(pageNo,pageSize, filtersObject,true);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null,response);
		}  catch (Exception e) 
		{
			PALogger.ERROR(e);	

			if(e.getMessage().equals(Constant.UNAUTHORIZED)) {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_METHOD_NOT_ALLOWED , Constant.NOT_ALLOWED, Constant.NOT_ALLOWED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else
			{

				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, Constants.UNABLE_TO_LIST_APPLICATIONS, Constants.UNABLE_TO_LIST_APPLICATIONS);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);	
			}	

		}
	}

	public static void main(String[] args) 
	{
		AdminEndpoint a= new AdminEndpoint();
		//d4138645dc94c2ee1f27afd98d7bf070
		//d5d9c60031b2310554012e33d91cbcc6
		//c879263e5a145e215ec3f44ea7088dbb
		a.mListVersion("c879263e5a145e215ec3f44ea7088dbb", 1, 10);
	}
	private void mListVersion(String authToken,int pageNo, int pageSize) {
		try 
		{
			AuthorizationsVO authvo = new GrpcAuthHelper().getAuthorizationsVO(authToken);
			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.APP_VERSION_LIST));
			AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, true);


			Applications applications = new Applications();
			Map<String, Object> resultMap = applications.listAllLatestVersion(pageNo, pageSize);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null,response);
		}  catch (Exception e) 
		{
			PALogger.ERROR(e);	

			if(e.getMessage().equals(Constant.UNAUTHORIZED)) {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_METHOD_NOT_ALLOWED , Constant.NOT_ALLOWED, Constant.NOT_ALLOWED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,Constants.UNABLE_TO_LIST_APPLICATIONS,Constants.UNABLE_TO_LIST_APPLICATIONS);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);	
			}	

		}
	}

	private void mGetUserCount( String authToken){
		try
		{

			AuthorizationsVO authvo = new GrpcAuthHelper().getAuthorizationsVO(authToken);

			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.USER_LIST));
			AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, true);
			String result = Client.callServer(Constants.AUTH_SERVER_IP_PORT, Constants.AUTH_SERVICE_NAME, "user", HTTPMethods.GET.name(), "count", null, null, Constant.BEARER + authToken);
			HashMap<String, String> data =  new Gson().fromJson(result, HashMap.class);
			ReturnObject.createResponse(Constant.SUCCESS, data, null, response);
		} catch (Exception e) 
		{
			PALogger.ERROR(e);
			if(e.getMessage().equals(Constant.UNAUTHORIZED)) {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_METHOD_NOT_ALLOWED , Constant.NOT_ALLOWED, Constant.NOT_ALLOWED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e.getMessage(),
						e.getMessage());
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
		}

	}

	private void mGetAppCount(String authToken) 
	{
		try {
			AuthorizationsVO authvo = new GrpcAuthHelper().getAuthorizationsVO(authToken);

			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.APP_LIST));
			AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, true);

			Applications applications = new Applications();
			List<Map<String, String>> data = applications.getCount();
			ReturnObject.createResponse(Constant.SUCCESS, data, null,response);
		}  catch (Exception e) 
		{

			PALogger.ERROR(e);
			if(e.getMessage().equals(Constant.UNAUTHORIZED)) {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_METHOD_NOT_ALLOWED , Constant.NOT_ALLOWED, Constant.NOT_ALLOWED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e.getMessage(),
						e.getMessage());
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
		}
	}

	private void mgetEdgeCoreCount(String authToken) 
	{
		try {
			AuthorizationsVO authvo = new GrpcAuthHelper().getAuthorizationsVO(authToken);

			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.APPLIANCES_LIST));
			AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, true);
			Devices device = new Devices();
			List<HashMap<String, String>> data = device.getCount();
			ReturnObject.createResponse(Constant.SUCCESS, data, null,response);
		}  catch (Exception e) 
		{

			PALogger.ERROR(e);
			if(e.getMessage().equals(Constant.UNAUTHORIZED)) {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_METHOD_NOT_ALLOWED , Constant.NOT_ALLOWED, Constant.NOT_ALLOWED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e.getMessage(),
						e.getMessage());
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
		}
	}
	private void mSuspendResumeUser( String authToken,List<String> appUserIds,UserStatusEnum status){
		try
		{
			AuthorizationsVO authvo = new GrpcAuthHelper().getAuthorizationsVO(authToken);

			List<String> lstPermissions = new ArrayList<>();
			if(status.name().equals(UserStatusEnum.Suspended.name()))
				lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.USER_SUSPEND));
			else
				lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.USER_RESUME));

			AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, true);
			if(appUserIds != null && !appUserIds.isEmpty())
			{

				ActivityOperation activityOpr = ActivityOperation.resumeUser;
				String operation = "resume";
				if(status.ordinal() == UserStatusEnum.Suspended.ordinal())
				{
					operation = "suspend";
					activityOpr =ActivityOperation.suspendUser;
				}

				Client.callServer(Constants.AUTH_SERVER_IP_PORT, Constants.AUTH_SERVICE_NAME, "user", HTTPMethods.PUT.name(), operation, null, appUserIds, Constant.BEARER + authToken);

				//add in activity log
				Map<String, Object> map = new HashMap<>();
				map.put("appUserIds", appUserIds);
				new ActivityLogs().insert(authvo.getUserId(),activityOpr.name(), new Gson().toJson(map));

				appUserIds.add(authvo.getUserId());
				//Get all auth user object for list appuserIds to insert in alter message -PS 
				Map<String, ApplicationUserVO> hashUsers =  getAllAuthUser(authToken, appUserIds);

				Alerts alert= new Alerts();
				HashMap<String, String> user = new HashMap<>();
				for(String userid : appUserIds)
				{
					user.put("AppUserId",userid);
					user.put("UserId",authvo.getUserId());
					user.put("UserStatus",status.name());

					String action = "resumed";
					if(status.ordinal() == UserStatusEnum.Suspended.ordinal())
						action = "suspended";

					ApplicationUserVO userVO = hashUsers.get(userid);
					ApplicationUserVO adminUserVO = hashUsers.get(authvo.getUserId());
					String msg = userVO.getFirstName() + " " +  userVO.getLastName() + "(" + userVO.getEmailId() + ")" + action + " by " + adminUserVO.getFirstName() + " " +  adminUserVO.getLastName() + "(" + adminUserVO.getEmailId() + ")";
					alert.add(NotificationType.Info,user ,MessageType.UsersLog,msg);
				}

			}
			ReturnObject.createResponse(Constant.SUCCESS, null, null, response);
		} catch (Exception e) 
		{
			PALogger.ERROR(e);
			if(e.getMessage().equals(Constant.UNAUTHORIZED)) {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_METHOD_NOT_ALLOWED , Constant.NOT_ALLOWED, Constant.NOT_ALLOWED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e.getMessage(),
						e.getMessage());
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
		}

	}

	private void mLogSettings(String authToken, Map<String, Boolean> logSettings) {
		try{
			AuthorizationsVO authvo = new GrpcAuthHelper().getAuthorizationsVO(authToken);
			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.SETTINGS_UPDATE));
			AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, true);
			EnumMap<SETTINGS_KEY, String> settings = new EnumMap<>(SETTINGS_KEY.class);

			for (Map.Entry<String,Boolean> entry : logSettings.entrySet()) 
			{
				SETTINGS_KEY key = SETTINGS_KEY.valueOf(entry.getKey());
				String value = entry.getValue().toString();
				switch (key) {
				case logLevelError:
					settings.put(key, value);
					break;
				case logLevelInfo:
					settings.put(key, value);
					break;
				case logLevelTrace:
					settings.put(key, value);
					break;
				case logLevelWarn:
					settings.put(key, value);
					break;
				default:
					break;
				}						
			}
			if(settings.size() > 0)
				new Settings().setSettingsValues(settings);
			new ActivityLogs().insert(authvo.getUserId(), ActivityOperation.updateLogSettings.name(),new Gson().toJson(logSettings));
		}catch(Exception e){
			PALogger.ERROR(e);
			if(e.getMessage().equals(Constant.UNAUTHORIZED)) {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_METHOD_NOT_ALLOWED , Constant.NOT_ALLOWED, Constant.NOT_ALLOWED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e.getMessage(), e.getMessage());
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
		}

	}

	private void mGetSettings(String authToken){
		try {
			AuthorizationsVO authvo = new GrpcAuthHelper().getAuthorizationsVO(authToken);

			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.SETTINGS_LIST));
			AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, true);
			Map<String, Object> resultMap = new HashMap<>();
			resultMap.put(Constant.DATA, new Settings().getSettings());			
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null,response);
		}  catch (Exception e) 
		{

			PALogger.ERROR(e);
			if(e.getMessage().equals(Constant.UNAUTHORIZED)) {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_METHOD_NOT_ALLOWED , Constant.NOT_ALLOWED, Constant.NOT_ALLOWED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e.getMessage(),
						e.getMessage());
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
		}
	}

	private void mListAlerts(String authToken,int pageNo, int pageSize,String filters) 
	{
		try {
			new GrpcAuthHelper().getAuthorizationsVO(authToken);
			List<FilterObject> filtersObject = null;
			if(!StringFunctions.isNullOrWhitespace(filters)) 
			{
				filtersObject = new Gson().fromJson(filters,new TypeToken<ArrayList<FilterObject>>() {}.getType());
			}
			Alerts alerts = new Alerts();
			Map<String, Object> result = alerts.listFilterAlerts(filtersObject, pageNo, pageSize);
			ReturnObject.createResponse(Constant.SUCCESS, result, null,response);
		}  catch (Exception e) 
		{
			PALogger.ERROR(e);
			if(e.getMessage().equals(Constant.UNAUTHORIZED)) 
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_METHOD_NOT_ALLOWED , Constant.NOT_ALLOWED, Constant.NOT_ALLOWED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,"Unable to list alerts.","Unable to list alerts.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);		
			}

		}
	}


	private Map<String, ApplicationUserVO> getAllAuthUser(String authToken, List<String> appUserIds) throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException, IOException  {

		PALogger.INFO("**************************Rest callt a.service***********************");
		String result= Client.callServer(Constants.AUTH_SERVER_IP_PORT, Constants.AUTH_SERVICE_NAME, "applications", HttpMethod.PUT, Constants.PORTAL_APPLICATION_ID +"/user/list/specificusers/", null,appUserIds, Constant.BEARER+ authToken);

		PALogger.INFO("**************************Rest callt a.service***********************DONE =>"+result);
		Map<String, Object> responseMap = Client.getGson().fromJson(result, Hashtable.class);
		Object dataObj = responseMap.get("data");

		String dataStr = Client.getGson().toJson(dataObj);
		PALogger.INFO("**************************Rest callt a.service***********************DONE =>"+dataStr);

		Type type =  new TypeToken<HashMap<String, ApplicationUserVO>>(){}.getType();
		return 	 new Gson().fromJson(dataStr, type);

	}
	private void mListActivity(int pageNo, int pageSize,String filters,String authToken) 
	{
		try 
		{
			AuthorizationsVO authvo = new GrpcAuthHelper().getAuthorizationsVO(authToken);
			if( authvo.getRole() != RoleEnum.Admin) 
			{
				throw new Exception(Constant.UNAUTHORIZED);
			}

			List<FilterObject> filtersObject = null;
			if(!StringFunctions.isNullOrWhitespace(filters))
			{
				filtersObject = new Gson().fromJson(filters,new TypeToken<ArrayList<FilterObject>>() {}.getType());		
			}

			ActivityLogs logs = new ActivityLogs();
			Map<String, Object> resultMap = logs.listByFilter(pageNo, pageSize, filtersObject);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null,response);
		}
		catch (Exception e) 
		{
			PALogger.ERROR(e);
			if(e.getMessage().equals(Constant.UNAUTHORIZED)) 
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_METHOD_NOT_ALLOWED , Constant.NOT_ALLOWED, Constant.NOT_ALLOWED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else
			{
				ErrorVo errorVo = new ErrorVo(
						HttpServletResponse.SC_INTERNAL_SERVER_ERROR,"Unable to list activity.","Unable to list activity.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,
						response);	
			}

		}
	}

	private void mDeleteActivity(int noOfDays,String authToken) 
	{
		try 
		{
			AuthorizationsVO authvo = new GrpcAuthHelper().getAuthorizationsVO(authToken);
			if( authvo.getRole() != RoleEnum.Admin) 
			{
				throw new Exception(Constant.UNAUTHORIZED);
			}

			ActivityLogs logs = new ActivityLogs();
			logs.purgeActivity(noOfDays);
			ReturnObject.createResponse(Constant.SUCCESS, null, null,response);
		}
		catch (Exception e) 
		{
			PALogger.ERROR(e);
			if(e.getMessage().equals(Constant.UNAUTHORIZED)) 
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_METHOD_NOT_ALLOWED , Constant.NOT_ALLOWED, Constant.NOT_ALLOWED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else
			{
				ErrorVo errorVo = new ErrorVo(
						HttpServletResponse.SC_INTERNAL_SERVER_ERROR,"Unable to delete activity.","Unable to delete activity.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,
						response);	
			}

		}
	}
	
	
	private void mMarkApproved( String authToken,String userId)
	{
		try
		{
			AuthorizationsVO authvo = new GrpcAuthHelper().getAuthorizationsVO(authToken);

			if(authvo.getRole() == RoleEnum.Admin) 
			{
				String result= Client.callServer(Constants.AUTH_SERVER_IP_PORT, Constants.AUTH_SERVICE_NAME, "applications", HttpMethod.PUT, Constants.PORTAL_APPLICATION_ID  +   "/user/"+userId+"/markApproved", null, null, "bearer "+authToken);
				HashMap<String, Object> data = new Gson().fromJson(result, HashMap.class);
				ReturnObject.createResponse(Constant.SUCCESS, data, null, response);
			}
			else
			{
				throw new Exception(Constant.NOTPERMITTED);
			}
			
			
		} catch (Exception e) 
		{
			PALogger.ERROR(e);
			if(e.getMessage().equals(Constant.UNAUTHORIZED)) {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_METHOD_NOT_ALLOWED , "Not allowed.", "Not allowed.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e.getMessage(),
						e.getMessage());
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
		}

	}
}
