/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.service;

import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MultivaluedMap;

import com.mwp.common.Client;
import com.mwp.common.StringFunctions;
import com.mwp.logger.PALogger;
import com.mwp.p.framework.docker.DockerWebToken;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponses;

//description = "Docker registery server will call this command to, generates the oauth token to verify pull/push action."
@Path("/token")
@Api(value = "/token")
public class DockerWebTokenEndPoint {

	@Context
	private HttpServletResponse response;
	@Context
	private HttpServletRequest request;
	@Context
	private HttpHeaders httpHeaders;

	@GET
	@ApiOperation( value = "Docker registery server call this, return token understandable by docker.", notes = "@see https://docs.docker.com/v1.7/registry/spec/auth/token/.")
	@ApiResponses( {		 
	} )
	public String token(@ApiParam( value = "scope", required = true ) @QueryParam( "scope" ) String scope, 
			@ApiParam( value = "service", required = true ) @QueryParam( "service" ) String service)
	{

		String authToken = "";
		String appId = "";

		/**
		 * Docker sends token in header. It is the same header we sent via Remote API.
		 * 
		 * Token is in format same as Basic Auth i.e
		 * base64(authtoken:appid)
		 */
		MultivaluedMap<String, String> header = httpHeaders.getRequestHeaders();
		if(header.containsKey("authorization")) {
			String basicToken = header.get("authorization").get(0).trim();
			basicToken = basicToken.replace("Basic", "").trim();
			basicToken = basicToken.replace("basic", "").trim();
			basicToken = basicToken.replace("BASIC", "").trim();
			basicToken = new String(Base64.getDecoder().decode(basicToken.getBytes()));

			String[] basicTokenArr = basicToken.split(":");

			appId  = basicTokenArr[0].trim();
			authToken = basicTokenArr[1].trim();
		}

		if(StringFunctions.isNullOrWhitespace(authToken))
		{
			//Printed the warning instead of printing the same stack trace repeatedly in logs - DB
			PALogger.WARN("Empty Auth Token recieved in function \"token\" of class \"DockerWebTokenEndPoint\" ");
			return "";
		}
		
		return mToken(scope, service, authToken, appId);
	}


	@POST
	@ApiOperation( value = "Docker registery server call this, return token understandable by docker.", notes = "@see https://docs.docker.com/v1.7/registry/spec/auth/token/.")
	@ApiResponses( {
//		@ApiResponse( code = HttpServletResponse.SC_NOT_FOUND, message = "" )			 
	} )
	public String tokenPush(@ApiParam( value = "scope", required = true ) @FormParam( "scope" ) String scope,
			@ApiParam( value = "service", required = true ) @FormParam( "service" ) String service,
			@ApiParam( value = "refresh_token", required = true ) @FormParam( "refresh_token" ) String refreshToken)
	{
		//client_id=docker&grant_type=refresh_token&refresh_token=naresh%3Atank&scope=repository%3Anaresh%2Fubuntu-python-ntk%3Apush%2Cpull&service=Pixeom+Docker+Registry

		String[] refreshTokenArr = refreshToken.split(":");
		String appId = refreshTokenArr[0];
		String authToken = refreshTokenArr[1];

		return mToken(scope, service, authToken, appId);
	}

	private String mToken(String scope, String service, String authToken, String appId) {
		try {


			DockerWebToken dwt = new DockerWebToken();	
			String token = dwt.generateDockerAuthToken(scope, service, authToken, appId ,response);

			Map<String, Object> map = new HashMap<>();
			map.put("token", token);

			return Client.getGson().toJson(map);

		} catch (Exception e) {
			PALogger.ERROR(e);	
		}

		return "";
	}
}