/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.service;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.ValidationException;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;

import org.glassfish.jersey.media.multipart.BodyPartEntity;
import org.glassfish.jersey.media.multipart.FormDataBodyPart;
import org.glassfish.jersey.media.multipart.FormDataContentDisposition;
import org.glassfish.jersey.media.multipart.FormDataParam;

import com.google.gson.Gson;
import com.mwp.common.AuthHelper;
import com.mwp.common.Client;
import com.mwp.common.Common;
import com.mwp.common.Mailer;
import com.mwp.common.ReturnObject;
import com.mwp.common.StringFunctions;
import com.mwp.common.constant.Constant;
import com.mwp.common.vo.ApplicationUserVO;
import com.mwp.common.vo.EmailServersVO;
import com.mwp.common.vo.ErrorVo;
import com.mwp.logger.PALogger;
import com.mwp.p.authhelper.GrpcAuthHelper;
import com.mwp.p.common.Constants;
import com.mwp.p.framework.EmailServers;
import com.sun.research.ws.wadl.HTTPMethods;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Path("/emailserver")
@Api(value = "/emailserver", produces = MediaType.APPLICATION_JSON)
public class EmailServerEndpoint 
{
	@Context
	private HttpServletResponse response;
	@Context
	private HttpHeaders httpHeaders;
	@Context
	private HttpServletRequest request;


	@GET
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/list")
	@ApiOperation(value = "List email servers", notes = "List email server", response = HashMap.class)
	@ApiResponses({
		@ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to list email server.") })
	public void listEmailServers(@ApiParam(value = "Authorization token", required = true) @HeaderParam("Authorization") String authToken)
			throws ValidationException {
		mListEmailServer(authToken);
	}

	@POST
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	@ApiResponses
	( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to upload file.")			 
	} )
	public void sendFeedback(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,
			@FormDataParam("message") String message,
			@FormDataParam("files") List<FormDataBodyPart> bodyParts,
			@FormDataParam("files") FormDataContentDisposition bodyDisposition) {
		/* Save multiple files */
		List<String> attachment = new ArrayList<>();
		if(bodyParts != null) {
			for (int i = 0; i < bodyParts.size(); i++) {
				/*
				 * Casting FormDataBodyPart to BodyPartEntity, which can give us
				 * InputStream for uploaded file
				 */
				BodyPartEntity bodyPartEntity = (BodyPartEntity) bodyParts.get(i).getEntity();
				String fileName = bodyParts.get(i).getContentDisposition().getFileName();

				String filePath = saveFile(bodyPartEntity.getInputStream(), fileName);

				attachment.add(filePath);
			}
		}
		// Send email 
		mSendFeedBackEmail(authToken, "Feedback", message, attachment);
	}

	@POST
	@Path("send-mail")
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	@ApiResponses
	( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to upload file.")			 
	} )
	public void sendMail(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,
			@FormDataParam("sender") String sender,
			@FormDataParam("receivers") List<String> receivers,
			@FormDataParam("subject") String subject,
			@FormDataParam("body") String body,
			@FormDataParam("ccReceivers") List<String> ccReceivers,
			@FormDataParam("bccReceivers") List<String> bccReceivers,
			@FormDataParam("contentType") String contentType,
			@FormDataParam("logoPath") String logoPath,
			@FormDataParam("files") List<FormDataBodyPart> bodyParts,
			@FormDataParam("files") FormDataContentDisposition bodyDisposition) {
		/* Save multiple files */
		List<String> attachments = new ArrayList<>();
		if(bodyParts != null) {
			for (int i = 0; i < bodyParts.size(); i++) {
				/*
				 * Casting FormDataBodyPart to BodyPartEntity, which can give us
				 * InputStream for uploaded file
				 */
				BodyPartEntity bodyPartEntity = (BodyPartEntity) bodyParts.get(i).getEntity();
				String fileName = bodyParts.get(i).getContentDisposition().getFileName();

				String filePath = saveFile(bodyPartEntity.getInputStream(), fileName);

				attachments.add(filePath);
			}
		}

		mSendMail(authToken, sender, receivers, subject, body, ccReceivers, bccReceivers, attachments, contentType, logoPath);
	}

	private void mListEmailServer(String authToken) 
	{
		try {			
			// CHECK AUTH TOKEN...
			new GrpcAuthHelper().checkAuthorization(authToken);

			List<EmailServersVO> result = new EmailServers().listsAllOrderByPriority();

			Map<String, Object> resultMap = new HashMap<>();
			resultMap.put(Constant.DATA, result);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);
		} 
		catch (Exception e) 
		{
			PALogger.ERROR(e);
			if(e.getMessage().equals(Constant.UNAUTHORIZED)) {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_METHOD_NOT_ALLOWED , Constant.NOT_ALLOWED, Constant.NOT_ALLOWED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e.getMessage(),
						e.getMessage());
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}

		}
	}

	private String saveFile(InputStream file, String name) {
		try {
			String filePath = Constants.PORTAL_CACHE_PATH + "support"  + Constant.localFileSeparator + Common.getRandomId() + Constant.localFileSeparator;

			new File(filePath).mkdirs();

			filePath += name;

			java.nio.file.Path path = FileSystems.getDefault().getPath(filePath);
			/* Save InputStream as file */
			Files.copy(file, path);

			return filePath;
		} catch (IOException ie) {
			PALogger.ERROR(ie);	
		}

		return "";
	}

	private void mSendFeedBackEmail(String authToken, String subject, String message, List<String> attachments){
		try {
			new GrpcAuthHelper().checkAuthorization(authToken);

			HashMap<String, String> data =  new Gson().fromJson(Client.callServer(Constants.AUTH_SERVER_IP_PORT, Constants.AUTH_SERVICE_NAME, "user", HTTPMethods.GET.name(), "self", null, null, Constant.BEARER + authToken), HashMap.class);
			ApplicationUserVO portalUser = Client.getGson().fromJson(new Gson().toJson(data.get(Constant.DATA)), ApplicationUserVO.class);
			String receiverEmailId = "";

			/**
			 * List email servers by priority to send mail
			 */
			List<EmailServersVO> listEmailServer = new EmailServers().listsAllOrderByPriority();
			new Mailer(listEmailServer).sendTechMail(portalUser.getEmailId(), receiverEmailId, subject, message, attachments,0);

		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			} else {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Unable to get user detail", "Unable to get user detail"); 
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			PALogger.ERROR(e);	
		}
	}

	private void mSendMail(String authToken, String sender, List<String> receivers, String subject, String body, List<String> ccReceivers, List<String> bccReceivers, List<String> attachments, String contentType, String logoPath) {
		try {
			Object authorized = null;
			if(!StringFunctions.isNullOrWhitespace(authToken) && authToken.toLowerCase().startsWith(Constant.JWT_BEARER.toLowerCase())) {
				authorized = new AuthHelper().checkJwtToken(authToken, response);
			}else{
				authorized = new GrpcAuthHelper().getAuthorizationsVO(authToken);
			}

			if(authorized != null) {
				/**
				 * List email servers by priority to send mail
				 */
				List<EmailServersVO> listEmailServer = new EmailServers().listsAllOrderByPriority();
				new Mailer(listEmailServer).SendPlainMail(sender, receivers, subject, body, ccReceivers, bccReceivers, attachments, contentType);
			}
		} catch (Exception e) {
			PALogger.ERROR(e);
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			} else {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Unable to get user detail", "Unable to get user detail"); 
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
		}
	}



}
