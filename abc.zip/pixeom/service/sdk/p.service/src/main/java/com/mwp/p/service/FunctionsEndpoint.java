/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.service;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.management.InstanceAlreadyExistsException;
import javax.servlet.http.HttpServletResponse;
import javax.validation.constraints.NotNull;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import org.glassfish.jersey.media.multipart.FormDataContentDisposition;
import org.glassfish.jersey.media.multipart.FormDataParam;

import com.google.gson.Gson;
import com.mwp.common.AuthHelper;
import com.mwp.common.ReturnObject;
import com.mwp.common.StringFunctions;
import com.mwp.common.constant.Constant;
import com.mwp.common.constant.PermissionResourceKeys;
import com.mwp.common.constant.PermissionResources;
import com.mwp.common.vo.AuthorizationsVO;
import com.mwp.common.vo.ErrorVo;
import com.mwp.common.vo.FunctionVO;
import com.mwp.common.vo.FunctionVersionVO;
import com.mwp.logger.PALogger;
import com.mwp.p.authhelper.GrpcAuthHelper;
import com.mwp.p.common.AdminPermissionCheck;
import com.mwp.p.framework.Functions;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * <h1>FunctionsEndpoint</h1> Class hosted at the URI path "/functions"
 * <p>
 * Class manage function, return list of function, list of function version
 * Add/Delete function and function version.
 * give details of function.
 * </p>
 * 
 * @author akh
 * @version 0.0.1
 * @since 2017-06-23
 */
// description = "Class manage functions, return list of functions, list of function version, Add/Delete function and function version, give details of function."
@Path("/functions")
@Api(value = "/functions", produces = MediaType.APPLICATION_JSON)
public class FunctionsEndpoint {

	@Context
	private HttpServletResponse response;

	//	List functions with versions - list all functions(along with versions - EXCLUDE BODY) of the logged-in user
	//	GET /functions 
	/**
	 * Method processing HTTP GET requests, producing "application/json" MIME
	 * media-type.
	 * 
	 * <p>
	 * List functions with versions
	 * - list all functions(along with versions - EXCLUDE BODY) of the logged-in user
	 * </p>
	 * 
	 * @param httpHeaders
	 * @return String that will be send back as a response of type json.
	 */
	@GET
	@Consumes({ MediaType.APPLICATION_JSON })
	@ApiOperation(value = "List functions with versions", notes = "List functions with versions(EXCLUDE BODY)", response = HashMap.class)
	@ApiResponses({
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to get List functions with versions.")
		})
	public void listAllFunctions(@ApiParam(value = "Authorization token", required =true) @HeaderParam("Authorization") String authToken) {
		mListAllFunctions(authToken);
	}



	/**
	 * Method processing HTTP GET requests, producing "application/json" MIME
	 * media-type.
	 * 
	 * <p>
	 * Get function details with versions
	 * - details, its associated apps and services inside apps, versions(EXCLUDE BODY)
	 * </p>
	 * 
	 * @param httpHeaders
	 * @return String that will be send back as a response of type json.
	 */
	@GET
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/{functionid}")
	@ApiOperation(value = "Get function details with versions", 
	notes = "Get function details, its associated apps and services inside apps, versions(EXCLUDE BODY)", response = HashMap.class)
	@ApiResponses({
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to get function.")
		})
	public void getFunctionDetails(@ApiParam(value = "Authorization token", required =true) @HeaderParam("Authorization") String authToken,
			@ApiParam(value = "functionid of function which details required.", required = true)  @PathParam("functionid") @NotNull String functionId) {
		mGetFunctionDetails(authToken, functionId);
	}

	//List versions of a function (EXCLUDE BODY)
	//	GET /functions/{function id}/version
	/**
	 * Method processing HTTP GET requests, producing "application/json" MIME
	 * media-type.
	 * 
	 * <p>
	 * List versions of a function (EXCLUDE BODY)
	 * </p>
	 * 
	 * @param httpHeaders
	 * @return String that will be send back as a response of type json.
	 */
	@GET
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/{functionid}/versions")
	@ApiOperation(value = "List versions of a function (EXCLUDE BODY)", 
	notes = "List versions of a function (EXCLUDE BODY)", response = HashMap.class)
	@ApiResponses({
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to get List versions of a function (EXCLUDE BODY).")
		})
	public void listVersion(@ApiParam(value = "Authorization token", required =true) @HeaderParam("Authorization") String authToken,
			@ApiParam(value = "functionid of function which details required.", required = true)  @PathParam("functionid") @NotNull String functionId){
		mListFunctionVersion(authToken, functionId);
	}


	/**
	 * Method processing HTTP GET requests, producing "application/json" MIME
	 * media-type.
	 * 
	 * <p>
	 * Get a function version
	 * - get all details of the specified version of the specified function (INCLUDE BODY).
	 * </p>
	 * 
	 * @param httpHeaders
	 * @return String that will be send back as a response of type json.
	 */
	@GET
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/{functionid}/versions/{versionid}")
	@ApiOperation(value = "Get all details of the specified version of the specified function (INCLUDE BODY)", 
	notes = "Get all details of the specified version of the specified function (INCLUDE BODY)", response = HashMap.class)
	@ApiResponses({
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to get List application's docker event logs.")
		})
	public void getFunctionVersion(@ApiParam(value = "Authorization token", required =true) @HeaderParam("Authorization") String authToken,
			@ApiParam(value = "functionid of function which details required.", required = true)  @PathParam("functionid") @NotNull String functionId,
			@ApiParam(value = "versionid of version.", required = true)  @PathParam("versionid") @NotNull String versionId){
		mGetFunctionVersion(authToken, functionId, versionId);
	}

	/**
	 * Method processing HTTP GET requests, producing "application/json" MIME
	 * media-type.
	 * 
	 * <p>
	 * Get a function version
	 * - get all details of the specified versions of the specified function (INCLUDE BODY).
	 * </p>
	 * 
	 * @param httpHeaders
	 * @return String that will be send back as a response of type json.
	 */
	@GET
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/versions")
	@ApiOperation(value = "Get all details of the specified versions (INCLUDE BODY)", 
	notes = "Get all details of the specified versions(INCLUDE BODY)", response = HashMap.class)
	@ApiResponses({
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to get Get all details of the specified versions(INCLUDE BODY).")
		})
	public void getFunctionVersions(@ApiParam(value = "Authorization token", required =true) @HeaderParam("Authorization") String authToken,
			@ApiParam(value = "comma seperated lis of versionids.", required = true)  @QueryParam("versionids") @NotNull String versionIds){
		mGetFunctionVersion(authToken, versionIds);
	}

	//	Create Function - create a function and first version for the specified function.
	//	POST /functions
	//			function name
	//			version 
	//			function body
	//		return function id

	/**
	 * Method processing HTTP POST requests, producing "application/json" MIME
	 * media type.
	 * <p>
	 * function and first version for the specified function.
	 * <p>
	 * 
	 * @param applicationId
	 *            A unique id of application.
	 * @param deviceId
	 *            A unique id of device.
	 * @param operation
	 *            Application command (install/uninstall/update)
	 * @param httpHeaders
	 * @return Json string
	 * @throws Exception
	 */
	@POST
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	@Produces(MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Creats a new function and first version for the specified function.", notes = "Creats a new function and first version for the specified function.", response = String.class, responseContainer = "String")
	@ApiResponses({
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to add function.")
		})
	public void createFunction(@HeaderParam("Authorization") String authToken,
			@ApiParam(value = "FunctionVO class json object.", required = true) @FormDataParam("function") String functionStr,
			@FormDataParam("zip") InputStream fileStream,
			@FormDataParam("zip") FormDataContentDisposition fileInfo) {

		FunctionVO function = new Gson().fromJson(functionStr, FunctionVO.class);
		mAddFunction(authToken, function, fileStream, fileInfo);
	}


	//Create Function Version - create version of the function specified.
	//	POST /functions
	//			function id
	//			version
	//			function body
	//		return function version id
	/**
	 * Method processing HTTP POST requests, producing "application/json" MIME
	 * media type.
	 * <p>
	 * function and first version for the specified function.
	 * <p>
	 * 
	 * @param applicationId
	 *            A unique id of application.
	 * @param deviceId
	 *            A unique id of device.
	 * @param operation
	 *            Application command (install/uninstall/update)
	 * @param httpHeaders
	 * @return Json string
	 * @throws Exception
	 */
	@POST
	@Path("{functionid}/versions")
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	@Produces(MediaType.APPLICATION_JSON)
	@ApiOperation(value = "create a function and first version for the specified function.", notes = "create a function and first version for the specified function.", response = String.class, responseContainer = "String")
	@ApiResponses({
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to create a function and first version for the specified function.")
		})
	public void createFunctionVersion(@ApiParam(value = "Authorization token", required = true) @HeaderParam("Authorization") String authToken,
			@ApiParam(value = "functionid of function which details required.", required = true)  @PathParam("functionid") @NotNull String functionId,
			@ApiParam(value = "toExecute.", required = true) @FormDataParam("toExecute") String toExecute,
			@FormDataParam("zip") InputStream fileStream,
			@FormDataParam("zip") FormDataContentDisposition fileInfo) {

		mAddFunctionVersion(authToken, functionId, toExecute, fileStream, fileInfo);
	}

	

	/**
	 * Method processing HTTP GET requests, producing "application/json" MIME
	 * media-type.
	 * 
	 * <p>
	 * Delete a function.
	 * - get all details of the specified version of the specified function (INCLUDE BODY).
	 * </p>
	 * 
	 * @param httpHeaders
	 * @return String that will be send back as a response of type json.
	 */
	@DELETE
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/{functionid}")
	@ApiOperation(value = "delete function by function id", 
	notes = "delete function by function id", response = HashMap.class)
	@ApiResponses({
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to delete function by function id.")
		})
	public void deleteFunction(@ApiParam(value = "Authorization token", required =true) @HeaderParam("Authorization") String authToken,
			@ApiParam(value = "functionid of function which details required.", required = true)  @PathParam("functionid") @NotNull String functionId){
		mDeleteFunction(authToken, functionId);
	}


	
	/**
	 * Method processing HTTP GET requests, producing "application/json" MIME
	 * media-type.
	 * 
	 * <p>
	 * Delete a function.
	 * - get all details of the specified version of the specified function (INCLUDE BODY).
	 * </p>
	 * 
	 * @param httpHeaders
	 * @return String that will be send back as a response of type json.
	 */
	@DELETE
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/{functionid}/versions/{versionId}")
	@ApiOperation(value = "", 
	notes = "delete function of version by function id ,version id", response = HashMap.class)
	@ApiResponses({
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to delete function of version by function id ,version id.")
		})
	public void deleteFunctionVersion(@ApiParam(value = "Authorization token", required =true) @HeaderParam("Authorization") String authToken,
			@ApiParam(value = "functionid of function which details required.", required = true)  @PathParam("functionid") @NotNull String functionId,
			@ApiParam(value = "versionid of version.", required = true)  @PathParam("versionId") @NotNull String versionId){
		mDeleteFunctionVersion(authToken, functionId, versionId);
	}

	private void mListAllFunctions(String authToken) {
		try {
			AuthorizationsVO authvo = new GrpcAuthHelper().getAuthorizationsVO(authToken);
			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_FUNCTIONS));
			AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, true);
			Functions functions = new Functions();
			List<FunctionVO> listFunction = functions.listAllFunctions(authvo.getUserId());
			Map<String, Object> resultMap = new HashMap<>();
			resultMap.put(Constant.DATA, listFunction);

			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null,response);
		} catch (Exception e) {
			PALogger.ERROR(e);	
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Unable to get functions.", "Unable to get functions");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
		}
	}

	private void mGetFunctionDetails(String authToken, String functionId) {
		try {
			AuthorizationsVO authvo =	new GrpcAuthHelper().getAuthorizationsVO(authToken);
			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_FUNCTIONS));
			AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, true);
			Functions functions = new Functions();
			FunctionVO functionVO = functions.getFunction(functionId);

			if(StringFunctions.isNullOrWhitespace(functionVO.getFunctionId()) || !functionVO.getUserId().equals(authvo.getUserId())) {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_FORBIDDEN, "You are not authorized to access this resource.","Unable to get functions");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);					
			} else {
				Map<String, Object> resultMap = new HashMap<>();
				resultMap.put(Constant.DATA, functionVO);
				ReturnObject.createResponse(Constant.SUCCESS, resultMap, null,response);
			}
		} 
		catch (Exception e) {
			PALogger.ERROR(e);	
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			} 
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Unable to get functions.", "Unable to get functions");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
		}
	}

	private void mListFunctionVersion(String authToken, String functionId) {
		try {
			AuthorizationsVO authvo;
			if(authToken.toLowerCase().startsWith(Constant.JWT_BEARER.toLowerCase())) {

				authvo = new AuthHelper().checkJwtToken(authToken, response);
			}
			else{
				authvo =	new GrpcAuthHelper().getAuthorizationsVO(authToken);
			}

			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_FUNCTIONS));
			AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, true);
			Functions functions = new Functions();
			FunctionVO functionVO = functions.getFunction(functionId);

			if(StringFunctions.isNullOrWhitespace(functionVO.getFunctionId()) || !functionVO.getUserId().equals(authvo.getUserId())) {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_FORBIDDEN, "You are not authorized to access this resource.","Unable to get functions");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);					
			} else {
				List<FunctionVersionVO> listFunctionVersions = functions.listAllVersion(functionId);

				functionVO.getVersions().addAll(listFunctionVersions);

				Map<String, Object> resultMap = new HashMap<>();
				resultMap.put(Constant.DATA, functionVO);
				ReturnObject.createResponse(Constant.SUCCESS, resultMap, null,response);
			}
		} catch (Exception e) {
			PALogger.ERROR(e);	
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Unable to get functions.", "Unable to get functions");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
		}
	}

	private void mGetFunctionVersion(String authToken, String functionId, String versionId) {
		try {
			AuthorizationsVO authvo = new GrpcAuthHelper().getAuthorizationsVO(authToken);
			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_FUNCTIONS));
			AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, true);
			Functions functions = new Functions();
			FunctionVO functionVO = functions.getFunction(functionId, versionId,authvo.getUserId());
			
			if(functionVO == null){
				throw new Exception(Constant.NOTFOUND);
			}
			

				Map<String, Object> resultMap = new HashMap<>();
				resultMap.put(Constant.DATA, functionVO.getVersions().get(0));
				ReturnObject.createResponse(Constant.SUCCESS, resultMap, null,response);
		
		} catch (Exception e) {
			PALogger.ERROR(e);	
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTFOUND)) {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_NOT_FOUND, "Function not found.", "");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Unable to get functions.", "Unable to get functions");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
		}
	}

	private void mGetFunctionVersion(String authToken, String versionIds) {
		try {
			AuthorizationsVO authvo = new GrpcAuthHelper().getAuthorizationsVO(authToken);
			 List<String> lstPermissions = new ArrayList<>();
				lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_FUNCTIONS));
				AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, true);
			Functions functions = new Functions();
			List<FunctionVersionVO> functionVO = functions.getFunctionVersions(versionIds);

			Map<String, Object> resultMap = new HashMap<>();
			resultMap.put(Constant.DATA, functionVO);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null,response);

		} catch (Exception e) {
			PALogger.ERROR(e);	
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			} 
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Unable to get functions.", "Unable to get functions");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
		}
	}

	private void mAddFunction(String authToken, FunctionVO functionVO, InputStream fileStream, FormDataContentDisposition fileInfo) {
		try {
			AuthorizationsVO authvo =	new GrpcAuthHelper().getAuthorizationsVO(authToken);
			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_FUNCTIONS));
			AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, true);
			functionVO.setUserId(authvo.getUserId());

			Functions functions = new Functions();
			functionVO = functions.addFunction(functionVO, fileStream, fileInfo.getFileName());
			Map<String, Object> resultMap = new HashMap<>();
			resultMap.put(Constant.DATA, functionVO);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null,response);
		} 
		catch (InstanceAlreadyExistsException ex) 
		{
			PALogger.ERROR(ex);	
			ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, ex.getMessage(), ex);
			ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
		}
		catch (Exception e) 
		{
		
			PALogger.ERROR(e);	

			 if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			} 
			 else if(e.getMessage().equals(Constant.NOTPERMITTED))
				{
					ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
					ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
				}
			 else {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Unable to add function", e);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
		}
	}

	private void mAddFunctionVersion(String authToken, String functionId, String toExecute, InputStream fileStream, FormDataContentDisposition fileInfo) {
		try {
			AuthorizationsVO authvo =	new GrpcAuthHelper().getAuthorizationsVO(authToken);
			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_FUNCTIONS));
			AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, true);
			Functions functions = new Functions();
			FunctionVO functionVO = functions.getFunction(functionId);

			if(StringFunctions.isNullOrWhitespace(functionVO.getFunctionId()) || !functionVO.getUserId().equals(authvo.getUserId())) {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_FORBIDDEN, "You are not authorized to access this resource.","Unable to get functions");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);					
			} else {
				FunctionVersionVO versionVO = new FunctionVersionVO();
				versionVO.setToExecute(toExecute);
				versionVO.setFunctionId(functionId);
				versionVO = functions.addFunctionVersion(versionVO, fileStream, fileInfo.getFileName());
				Map<String, Object> resultMap = new HashMap<>();
				resultMap.put(Constant.DATA, versionVO);
				ReturnObject.createResponse(Constant.SUCCESS, resultMap, null,response);
			}
		} catch (Exception e) {
			PALogger.ERROR(e);	
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Unable to get functions.", "Unable to get functions");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
		}
	}

	private void mDeleteFunction(String authToken, String functionId) {
		try {
			AuthorizationsVO authvo = new GrpcAuthHelper().getAuthorizationsVO(authToken);
			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_FUNCTIONS));
			AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, true);
			Functions functions = new Functions();
			FunctionVO functionVO = functions.getFunction(functionId);

			if(StringFunctions.isNullOrWhitespace(functionVO.getFunctionId()) || !functionVO.getUserId().equals(authvo.getUserId())) {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_FORBIDDEN, "You are not authorized to access this resource.","Unable to get functions");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);					
			} else {
				functionId = functions.deleteFunction(functionId);
				Map<String, Object> resultMap = new HashMap<>();
				resultMap.put(Constant.DATA, functionId);
				ReturnObject.createResponse(Constant.SUCCESS, resultMap, null,response);
			}
		} catch (Exception e) {
			PALogger.ERROR(e);	
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Unable to get functions.", "Unable to get functions");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
		}
	}

	private void mDeleteFunctionVersion(String authToken, String functionId, String versionId) {
		try {
			AuthorizationsVO authvo =	new GrpcAuthHelper().getAuthorizationsVO(authToken);
			List<String> lstPermissions = new ArrayList<>();
			lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_FUNCTIONS));
			AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, true);
			Functions functions = new Functions();
			FunctionVO functionVO = functions.getFunction(functionId);

			if(StringFunctions.isNullOrWhitespace(functionVO.getFunctionId()) || !functionVO.getUserId().equals(authvo.getUserId())) {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_FORBIDDEN, "You are not authorized to access this resource.","Unable to get functions");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);					
			} else {
				functionId = functions.deleteFunctionVersion(functionId, versionId);
				Map<String, Object> resultMap = new HashMap<>();
				resultMap.put(Constant.DATA, functionId);
				ReturnObject.createResponse(Constant.SUCCESS, resultMap, null,response);
			}
		} catch (Exception e) {
			PALogger.ERROR(e);	
			if(e.getMessage().equals(Constant.UNAUTHORIZED)) {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Unable to get functions.", "Unable to get functions");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
		}

	}
}
