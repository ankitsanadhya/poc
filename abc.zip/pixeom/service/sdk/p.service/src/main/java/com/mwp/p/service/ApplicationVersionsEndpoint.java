/**
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.mwp.p.service;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Type;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.NotAuthorizedException;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import org.apache.commons.fileupload.FileItemIterator;
import org.apache.commons.fileupload.FileItemStream;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.fileupload.util.Streams;
import org.apache.commons.io.FileUtils;
import org.glassfish.jersey.media.multipart.BodyPartEntity;
import org.glassfish.jersey.media.multipart.FormDataBodyPart;
import org.glassfish.jersey.media.multipart.FormDataContentDisposition;
import org.glassfish.jersey.media.multipart.FormDataParam;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.mwp.common.Common;
import com.mwp.common.CredProvider;
import com.mwp.common.ReturnObject;
import com.mwp.common.StringFunctions;
import com.mwp.common.TempFiles;
import com.mwp.common.Utils;
import com.mwp.common.constant.Constant;
import com.mwp.common.constant.PermissionResourceKeys;
import com.mwp.common.constant.PermissionResources;
import com.mwp.common.enums.ActivityOperation;
import com.mwp.common.enums.ApplicationDefaultType;
import com.mwp.common.enums.ResourceKindEnum;
import com.mwp.common.enums.StatusEnum.VERSION_STATUS;
import com.mwp.common.k8sparser.K8sBase;
import com.mwp.common.k8sparser.K8sContainerBase;
import com.mwp.common.k8sparser.K8sContainers;
import com.mwp.common.k8sparser.K8sCronJob;
import com.mwp.common.k8sparser.K8sPod;
import com.mwp.common.k8sparser.K8sPodsKinds;
import com.mwp.common.k8sparser.K8syamlParser;
import com.mwp.common.vo.AppResourceVO;
import com.mwp.common.vo.ApplicationVO;
import com.mwp.common.vo.AuthorizationsVO;
import com.mwp.common.vo.ErrorVo;
import com.mwp.common.vo.VersionVO;
import com.mwp.common.yamlparser.ComposeVO;
import com.mwp.common.yamlparser.SecretVo;
import com.mwp.common.yamlparser.SectionVO;
import com.mwp.common.yamlparser.YamlParser;
import com.mwp.common.yamlparser.YmlAuthConfig;
import com.mwp.logger.PALogger;
import com.mwp.p.authhelper.GrpcAuthHelper;
import com.mwp.p.common.Constants;
import com.mwp.p.common.vo.AppTypeVO;
import com.mwp.p.dal.engine.DeveloperApplicationsEngine;
import com.mwp.p.dal.engine.VersionEngine;
import com.mwp.p.framework.ActivityLogs;
import com.mwp.p.framework.Applications;
import com.mwp.p.framework.DeveloperApplications;
import com.mwp.p.framework.PortalFileUpload;
import com.mwp.p.framework.Versions;
import com.mwp.p.utility.Utility;
import com.pa.crypto.FileEncryptionDecryption;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

//description = "This class provide version management commands."
@Path("/apps/{appid}/versions")
@Api( value = "/versions",produces=MediaType.APPLICATION_JSON)
public class ApplicationVersionsEndpoint {
	@Context
	private HttpServletResponse response;

	@GET
	@Consumes("application/json")
	@Produces("application/json")
	@ApiOperation( value = "list versions of application.", 
	notes = "list versions of application.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_NOT_FOUND, message = "Application version with such appId doesn't exists." ),	
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "AUnable to list application versions." )
	} )
	public void listVersion(@ApiParam(value = "id of application.", required = true) @PathParam("appid") String appId,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken) {
		mlistVersion(authToken, appId);
	}

	/**
	 * Method processing HTTP GET requests, producing "application/json" MIME media-type.
	 * 
	 * <p> 
	 * This method return detail of developer application (listVersion, versionDetail).
	 * </p>  
	 * @param appId - id of developer application. 
	 * @param versionId - application required versionId which info we want to get.
	 * @param httpHeaders
	 * @return
	 */
	@GET
	@Consumes({MediaType.APPLICATION_JSON})
	@Path("/{versionid}")
	@ApiOperation( value = "version details application", 
	notes = "return version details of developer application.", 
	response = VersionVO.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_NOT_FOUND, message = "Application detail doesn't exists."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to get version details." )
	})
	public void getVersionDetails(@ApiParam(value = "id of application.", required = true) @PathParam("appid") String appId,
			@ApiParam(value = "versionid of application.", required = true) @PathParam("versionid") String versionId,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken){

		mGetVersionDetails(authToken,appId,versionId);

	}

	/**
	 * Method processing HTTP GET requests, producing "application/json" MIME media-type.
	 * 
	 * <p> 
	 * This method return detail of developer application (listVersion, versionDetail).
	 * </p>  
	 * @param appId - id of developer application. 
	 * @param versionId - application required versionId which info we want to get.
	 * @param httpHeaders
	 * @return
	 */
	@GET
	@Consumes({MediaType.APPLICATION_JSON})
	@Path("/{version}/exist/{appplatformid}")
	@ApiOperation( value = "check version details application", 
	notes = "return version details of developer application.", 
	response = VersionVO.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_BAD_REQUEST, message = "Version already exists."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to get version details." )
	} )
	public void checkVersionExist(@ApiParam(value = "id of application.", required = true) @PathParam("appid") String appId,
			@ApiParam(value = "version of application.", required = true) @PathParam("version") String versionNumber,
			@ApiParam(value = "repositoryId of application.", required = true) @PathParam("appplatformid") String appPlatformId,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken){

		mCheckVersionExist(authToken, appId, appPlatformId, versionNumber);

	}

	@POST	
	@ApiOperation( value = "Create application", 
	notes = "create app of developer application.", 
	response = VersionVO.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_BAD_REQUEST, message = "Invalid composer file provided."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to add app version details." )
	} )
	public void createAppVersion(@Context HttpServletRequest uploadedInputStream,
			@ApiParam(value = "id of application.", required = true) @PathParam("appid") String appId,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken) 
	{
		mCreateAppVersion(authToken, appId, uploadedInputStream);
	}



	/** Method processing HTTP POST requests, producing "application/json" MIME media type.
	 * <p>
	 * This method publish developer application detail.
	 * <p>
	 * @param appId - id of developer application. 
	 * @param versionId - application required versionId which info we want to get.
	 * @param httpHeaders
	 * @return Json string
	 * @throws Exception 
	 */
	@POST
	@Consumes({MediaType.APPLICATION_JSON})
	@Path("/{versionid}/publish")
	@ApiOperation( value = "publish developer application detail.", 
	notes = "publish developer application detail.", 
	response = String.class, responseContainer = "String")
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_NOT_FOUND, message = "Application detail doesn't exists."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to get app version details." )
	} )
	public void publish(@ApiParam(value = "id of application.", required = true) @PathParam("appid") String appId,
			@ApiParam(value = "versionid of application.", required = true) @PathParam("versionid") String versionId,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken) {
		mPublish(authToken,appId,versionId);
	}

	/**
	 * Method processing HTTP GET requests, producing "application/json" MIME
	 * media-type.
	 * 
	 * <p>
	 * This method gives application detail according to requested
	 * applicationId.
	 * </p>
	 * 
	 * @param appversionid
	 * @param httpHeaders
	 * @return
	 */
	@PUT
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/{appversionid}")
	@ApiOperation(value = "Change application detail according to requested applicationId.", notes = "change application status according to requested applicationId.", response = HashMap.class)
	@ApiResponses({
		@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse(code = HttpServletResponse.SC_NOT_FOUND, message = "Application with such appid doesn't exists."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to get app version details." )
	})
	public void changeAppVersionStatus(@ApiParam(value = "id of application.", required = true) @PathParam("appid") String appId,
			@ApiParam(value = "appversionid of applicationversion.", required = true) @PathParam("appversionid") String appVersionId,
			@ApiParam( value = "status", required = true ) @QueryParam("status") String status,
			@ApiParam(value = "Authorization token", required = true) @HeaderParam("Authorization") String authToken) {
		mChangeAppVersionStatus(authToken, appVersionId, status,appId);
	}


	@GET
	@Consumes({MediaType.APPLICATION_JSON})
	@Path("/{versionid}/images")
	@ApiOperation( value = "list images of app version", 
	notes = "return images of app version.", 
	response = ComposeVO.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_NOT_FOUND, message = "Version not found."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to list images of app version."),
	} )
	public void getImagesOfAppVersion(@ApiParam(value = "id of application.", required = true) @PathParam("appid") String appId,
			@ApiParam(value = "versionid of application.", required = true) @PathParam("versionid") String versionId,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken){

		mGetImagesOfAppVersion(authToken, appId, versionId);
	}

	@POST	
	@Path("/{versionid}/uploadsecrets")
	@ApiOperation( value = "Upload secret file", 
	notes = "Upload secret file of aplication version.", 
	response = VersionVO.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_BAD_REQUEST, message = "Invalid composer file provided."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to add app version details." )
	} )
	public void uploadAppSecret(
			@Context HttpServletRequest uploadedInputStream,
			@ApiParam(value = "id of application.", required = true) @PathParam("appid") String appId,
			@ApiParam(value = "versionid of application.", required = true) @PathParam("versionid") String versionId,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken) 
	{
		mUploadAppVersionSecret(authToken, appId, versionId, uploadedInputStream,Constants.SECRET);
	}


	@POST	
	@Path("/{versionid}/uploadconfigs")
	@ApiOperation( value = "Upload secret file", 
	notes = "Upload config file of aplication version.", 
	response = VersionVO.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_BAD_REQUEST, message = "Invalid composer file provided."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to add app version details." )
	} )
	public void uploadAppConfig(
			@Context HttpServletRequest uploadedInputStream,
			@ApiParam(value = "id of application.", required = true) @PathParam("appid") String appId,
			@ApiParam(value = "versionid of application.", required = true) @PathParam("versionid") String versionId,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken) 
	{
		mUploadAppVersionSecret(authToken, appId, versionId, uploadedInputStream,"config");
	}



	@POST	
	@Path("/{versionid}/secrets")
	@ApiOperation( value = "Upload secret file", 
	notes = "Upload secret file of aplication version.", 
	response = VersionVO.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_BAD_REQUEST, message = "Invalid composer file provided."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to add app version details." )
	} )
	public void uploadAppSecret(@FormDataParam("files") List<FormDataBodyPart> uploadedInputStream,
			@FormDataParam("files") FormDataContentDisposition bodyDisposition,
			@ApiParam(value = "id of application.", required = true) @PathParam("appid") String appId,
			@ApiParam(value = "versionid of application.", required = true) @PathParam("versionid") String versionId,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken) 
	{
		mUploadAppVersionSecret(authToken, appId, versionId, uploadedInputStream,Constants.SECRET);
	}


	@POST	
	@Path("/{versionid}/configs")
	@ApiOperation( value = "Upload secret file", 
	notes = "Upload config file of aplication version.", 
	response = VersionVO.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_BAD_REQUEST, message = "Invalid composer file provided."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to add app version details." )
	} )
	public void uploadAppConfig(@FormDataParam("files") List<FormDataBodyPart> uploadedInputStream,
			@FormDataParam("files") FormDataContentDisposition bodyDisposition,
			@ApiParam(value = "id of application.", required = true) @PathParam("appid") String appId,
			@ApiParam(value = "versionid of application.", required = true) @PathParam("versionid") String versionId,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken) 
	{
		mUploadAppVersionSecret(authToken, appId, versionId, uploadedInputStream,"config");
	}


	@GET
	@Consumes({MediaType.APPLICATION_JSON})
	@Path("/{versionid}/secrets")
	@ApiOperation( value = "list images of app version", 
	notes = "return images of app version.", 
	response = ComposeVO.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = "Unauthorized."),
		@ApiResponse( code = HttpServletResponse.SC_NOT_FOUND, message = "Version not found."),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to list images of app version."),
	} )
	public void getAppSecrets(@ApiParam(value = "id of application.", required = true) @PathParam("appid") String appId,
			@ApiParam(value = "versionid of application.", required = true) @PathParam("versionid") String versionId,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken){

		mGetAppSecret(authToken, appId, versionId);
	}



	private void mUploadAppVersionSecret(String authToken, String appId,String appVersionId, List<FormDataBodyPart> uploadedInputStream,String folderName ) 
	{

		Map<String, String> inputstreaHash= new HashMap<>();
		Map<String,Object> resultMap = new HashMap<>();
		String tempFolderPath = TempFiles.getTempFolderPath();
		try {

			AuthorizationsVO authVo = new GrpcAuthHelper().getAuthorizationsVO(authToken);
			Applications applications = new Applications(); 
			//AKH_01_1
			String appOwnerId = applications.getUserIdOfApp(appId);

			if(!appOwnerId.equals(authVo.getUserId()) && folderName.equals(Constants.SECRET))
				Utility.checkPermission(authVo.getGroupPermissions(), PermissionResources.getString(PermissionResourceKeys.APP_VERSION_CREATE), appId);


			if(uploadedInputStream != null) {
				for (int i = 0; i < uploadedInputStream.size(); i++) {
					/*
					 * Casting FormDataBodyPart to BodyPartEntity, which can give us
					 * InputStream for uploaded file
					 */
					BodyPartEntity bodyPartEntity = (BodyPartEntity) uploadedInputStream.get(i).getEntity();
					String fileName = uploadedInputStream.get(i).getContentDisposition().getFileName();
					String tempfilepath = new PortalFileUpload().inputStreamToFile(bodyPartEntity.getInputStream(), tempFolderPath + fileName);
					inputstreaHash.put(fileName, tempfilepath);
				}
				PortalFileUpload pfu = new PortalFileUpload();
				String secretpath=appVersionId+Constant.localFileSeparator+folderName;
				String uploadBasePath = Constants.PORTAL_FILES_PATH+Constants.PORTAL_YML_FOLDER_NAME+Constant.localFileSeparator+secretpath+Constant.localFileSeparator;
				File file = new File(uploadBasePath);
				if(!file.exists()) {

					file.mkdirs();
				}
				resultMap = pfu.uploadAttachmentInline(inputstreaHash,uploadBasePath, true, false);
			}

			if(resultMap.size() > 0){
				Map<String,Object> data = new HashMap<>();
				data.put(Constant.DATA, resultMap);
				ReturnObject.createResponse(Constant.SUCCESS, data, null, response);
			}else{
				throw new Exception(folderName+" upload failed.");
			}

		}catch (Exception e) {
			PALogger.ERROR(e);	
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			} 
			else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to upload "+folderName, "Unable to upload "+folderName);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			PALogger.ERROR(e);	
		} finally {
			FileUtils.deleteQuietly(new File(tempFolderPath));
		}
	}



	private void mUploadAppVersionSecret(String authToken, String appId,String appVersionId, HttpServletRequest uploadedInputStream,String folderName ) 
	{

		Map<String, String> inputstreaHash= new HashMap<>();

		ServletFileUpload fileUpload = new ServletFileUpload();

		Map<String,Object> resultMap = new HashMap<>();
		ArrayList<String> ListTempFolderPath = new ArrayList<>(); 
		try {

			AuthorizationsVO authVo = new GrpcAuthHelper().getAuthorizationsVO(authToken);
			Applications applications = new Applications(); 
			//AKH_01_1
			String appOwnerId = applications.getUserIdOfApp(appId);

			if(!appOwnerId.equals(authVo.getUserId()) && folderName.equals(Constants.SECRET))
				Utility.checkPermission(authVo.getGroupPermissions(), PermissionResources.getString(PermissionResourceKeys.APP_VERSION_CREATE), appId);

			String secretpath=appVersionId+Constant.localFileSeparator+folderName;
			String uploadBasePath = Constants.PORTAL_FILES_PATH+Constants.PORTAL_YML_FOLDER_NAME+Constant.localFileSeparator+secretpath+Constant.localFileSeparator;



			if(uploadedInputStream != null) {


				if(ServletFileUpload.isMultipartContent(uploadedInputStream))
				{
					FileItemIterator items = fileUpload.getItemIterator(uploadedInputStream);
					while (items.hasNext())
					{
						FileItemStream item = items.next();
						if (!item.isFormField()) 
						{
							try(InputStream inputstream = item.openStream()){
								String tempFolderPath = TempFiles.getTempFolderPath(); //handle multiple secret and config case
								ListTempFolderPath.add(tempFolderPath);
								String tempfilepath = new PortalFileUpload().inputStreamToFile(inputstream, tempFolderPath + item.getName());
								String secretnamePath=uploadBasePath+item.getFieldName();
								File file = new File(secretnamePath);
								if(!file.exists()) {

									file.mkdirs();
								}
								inputstreaHash.put(item.getFieldName()+Constant.localFileSeparator+item.getName(), tempfilepath);
							}
						}

					}
				}
				PortalFileUpload pfu = new PortalFileUpload();
				resultMap = pfu.uploadAttachmentInline(inputstreaHash,uploadBasePath, true , false);
			}

			if(resultMap.size() > 0){
				//add activity log in db
				ActivityOperation operation = ActivityOperation.addAppVersionConfig;
				if(folderName.equals(Constants.SECRET))
					operation = ActivityOperation.addAppVersionSecret;
				HashMap<String, String> map = new HashMap<>();
				map.put("applicationId", appId);
				map.put("appVersionId", appVersionId);
				new ActivityLogs().insert(authVo.getUserId(),operation.name(), new Gson().toJson(map));

				Map<String,Object> data = new HashMap<>();
				data.put(Constant.DATA, resultMap);
				ReturnObject.createResponse(Constant.SUCCESS, data, null, response);
			}else{
				throw new Exception(folderName+" upload failed.");
			}

		}catch (Exception e) {
			PALogger.ERROR(e);	
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			} 
			else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to upload "+folderName, "Unable to upload "+folderName);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			PALogger.ERROR(e);	
		}
		finally {
			for (String tempfilePath : ListTempFolderPath) {
				FileUtils.deleteQuietly(new File(tempfilePath));
			}

		}
	}




	private void mlistVersion(String authToken, String appId) {
		try {
			// CHECK AUTH TOKEN...
			// Execute that operation if user is owner of that application.
			AuthorizationsVO authVo=new GrpcAuthHelper().getAuthorizationsVO(authToken);

			Applications applications=new Applications();
			//AKH_01_1
			String appOwnerId = applications.getUserIdOfApp(appId);
			List<VersionVO> versionVOs ;
			if (!StringFunctions.isNullOrWhitespace(appOwnerId)) {
				if (appOwnerId.equals(authVo.getUserId())) {
					versionVOs = new Applications()
							.listVersionOfApplication(appId, authVo.getUserId());

				} else {

					List<String> lstPermissions = new ArrayList<>();
					lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.APP_VERSION_PUBLISH));
					lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.APP_VERSION_INSTALL));
					lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.APP_VERSION_CREATE));
					lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.APP_VERSION_UNPUBLISH));
					Utility.checkPermission(authVo.getGroupPermissions(),lstPermissions, appId, false);

					versionVOs = new VersionEngine().getVersionsOfGroupApp(appId,authVo, "", "", null);
				}
				Map<String, Object> resultMap = new HashMap<>();
				resultMap.put(Constant.DATA, versionVOs);
				ReturnObject.createResponse(Constant.SUCCESS, resultMap,
						null, response);
			}
			else{
				//if Application not found for given application Id then throw NOTFOUND exception. 
				throw new Exception(Constant.NOTFOUND);
			}


		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);

			}else if(e.getMessage().equals(Constant.NOTFOUND)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_NOT_FOUND , "Application not found", "No application found with requested application Id");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"Unable to list application versions.", "Unable to list application versions.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			PALogger.ERROR(e);	
		}

	}


	private void mChangeAppVersionStatus(String authToken, String appVersionId, String status,String appId) {
		try {

			// Execute the opearion if Owner of the app OR push OR publish on the app
			AuthorizationsVO authVo=new GrpcAuthHelper().getAuthorizationsVO(authToken);
			Applications applications=new Applications();
			//AKH_01_1
			String appOwnerId = applications.getUserIdOfApp(appId);
			if (appOwnerId != null) {
				if (!appOwnerId.equals(authVo.getUserId())) {
					if (VERSION_STATUS.valueOf(status).equals(
							VERSION_STATUS.UPLOADING)
							|| VERSION_STATUS.valueOf(status).equals(
									VERSION_STATUS.REVIEWPENDING)
							|| VERSION_STATUS.valueOf(status).equals(
									VERSION_STATUS.REVIEWED) // Add Review Process for Check Permission of Revied Process.
							|| VERSION_STATUS.valueOf(status).equals(
									VERSION_STATUS.LIVE)
							|| VERSION_STATUS.valueOf(status).equals(       // Client can change version status for deleted version also. 
									VERSION_STATUS.DELETED )
							|| VERSION_STATUS.valueOf(status).equals(
									VERSION_STATUS.OLDRELEASED)) {
						if (VERSION_STATUS.valueOf(status).equals(
								VERSION_STATUS.UPLOADING)
								|| VERSION_STATUS.valueOf(status).equals(
										VERSION_STATUS.REVIEWPENDING)
								|| VERSION_STATUS.valueOf(status).equals(
										VERSION_STATUS.REVIEWED)
								|| VERSION_STATUS.valueOf(status).equals(       // Client can change version status for deleted version also. 
										VERSION_STATUS.DELETED ))
							Utility.checkPermission(
									authVo.getGroupPermissions(),
									PermissionResources.getString(PermissionResourceKeys.APP_VERSION_CREATE), appId);
						else if (VERSION_STATUS.valueOf(status).equals(
								VERSION_STATUS.OLDRELEASED)) {
							Utility.checkPermission(
									authVo.getGroupPermissions(),
									PermissionResources.getString(PermissionResourceKeys.APP_VERSION_UNPUBLISH), appId);
						}
						else
							Utility.checkPermission(
									authVo.getGroupPermissions(),
									PermissionResources.getString(PermissionResourceKeys.APP_VERSION_PUBLISH), appId);
					} else {
						throw new Exception(Constant.NOTPERMITTED);
					}
				}

				Map<String, Object> resultMap = new HashMap<>();
				new Versions().changeAppVersionStatus(appId,appVersionId, status);

				//add in activity table
				HashMap<String, String> map = new HashMap<>();
				map.put("applicationId", appId);
				map.put("appVersionId", appVersionId);
				map.put("status", status);
				new ActivityLogs().insert(authVo.getUserId(),ActivityOperation.updateAppVersionStatus.name(), new Gson().toJson(map));

				resultMap.put(Constant.DATA, status);
				ReturnObject.createResponse(Constant.SUCCESS, resultMap, null,
						response);
			}
			else
			{
				//if Application not found for given application Id then throw NOTFOUND exception. 
				throw new Exception(Constant.NOTFOUND);
			}
		} catch (NotAuthorizedException e) {
			ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED,
					"Unauthorized.", Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
			ReturnObject.createResponse(Constant.FAILURE, null, errorVo,
					response);
		}
		catch (Exception e) {
			if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTFOUND))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_NOT_FOUND,
						"Application not found", "No application found with requested app ID");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			else if(!StringFunctions.isNullOrWhitespace(e.getMessage()) && e.getMessage().equals("Version is already deleted.")){
				ErrorVo errorVo = new ErrorVo(
						HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						e.getMessage(),
						e.getMessage());
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,
						response);
			}
			else
			{
				ErrorVo errorVo = new ErrorVo(
						HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"Unable to get application detail.",
						"Unable to get application detail");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,
						response);
			}
			PALogger.ERROR(e);	
		}
	}

	private void mCreateAppVersion(String authToken, String appId, HttpServletRequest uploadedInputStream) {
		Map<String, String> formItems=new HashMap<>();
		Map<String, String> inputstreamHash= new HashMap<>();
		ServletFileUpload fileUpload = new ServletFileUpload();
		String projectId = "";
		VersionVO versionVO = null;
		List<AppResourceVO> resourceVOs = null;
		Map<String,Object> resultMap = new HashMap<>();
		try {
			//CHECK AUTH TOKEN...
			AuthorizationsVO authVo = new GrpcAuthHelper().getAuthorizationsVO(authToken);
			Applications applications = new Applications(); 
			//AKH_01_1
			String appOwnerId = applications.getUserIdOfApp(appId);
			if(!appOwnerId.equals(authVo.getUserId())){
				Utility.checkPermission(authVo.getGroupPermissions(), PermissionResources.getString(PermissionResourceKeys.APP_VERSION_CREATE), appId);
			}

			ApplicationVO appvo = new Applications().getApplicationBasicDetail(appId);
			List<AppTypeVO> types = new DeveloperApplications().getAllAppType();
			ApplicationDefaultType type = ApplicationDefaultType.dockercompose;
			for (AppTypeVO appTypeVO : types) {
				if(appvo.getAppTypeId().equals(appTypeVO.getTypeId())){
					type =  ApplicationDefaultType.valueOf(appTypeVO.getType());
				}
			}

			String appVersionId = Common.getRandomId();
			String yamlTempFilePath = "";
			if(ServletFileUpload.isMultipartContent(uploadedInputStream)) {
				FileItemIterator items = fileUpload.getItemIterator(uploadedInputStream);

				while (items.hasNext()) {
					FileItemStream item = items.next();
					if (!item.isFormField()) {
						try(InputStream inputstream = item.openStream()){
							String tempfilepath = new PortalFileUpload().inputStreamToFile(inputstream, TempFiles.getTempFolderPath() + item.getName());
							inputstreamHash.put(item.getFieldName(), tempfilepath);
						}
					} else {
						try(InputStream fieldValue= item.openStream()){
							formItems.put(item.getFieldName(), Streams.asString(fieldValue));
						}
					}
				}

				//AKH_02
				projectId = formItems.get("projectid");
				versionVO = new Gson().fromJson(formItems.get("version"), VersionVO.class);

				if(formItems.containsKey("resources")) {
					Type listAppResourcesType =  new TypeToken<ArrayList<AppResourceVO>>(){}.getType();
					resourceVOs = new Gson().fromJson(formItems.get("resources"), listAppResourcesType);
				} else {
					resourceVOs = new ArrayList<>();
				}

				if(inputstreamHash.containsKey("file")) {
					AppResourceVO appResourceVO = new AppResourceVO();
					appResourceVO.setAppId(appId);
					appResourceVO.setEncrypted(true);
					appResourceVO.setFieldName("file");
					appResourceVO.setKind(ResourceKindEnum.appYaml);
					appResourceVO.setServiceName("");

					resourceVOs.add(appResourceVO);
				}

				String uploadResourceBasePath = Constants.PORTAL_FILES_PATH+Constants.PORTAL_APP_FOLDER_NAME+Constant.localFileSeparator+appId+ Constant.localFileSeparator;
				String uploadBasePath = Constants.PORTAL_FILES_PATH+Constants.PORTAL_YML_FOLDER_NAME+Constant.localFileSeparator+appVersionId+ Constant.localFileSeparator;
				for (AppResourceVO appResourceVO : resourceVOs) {
					appResourceVO.setAppId(appId);
					appResourceVO.setAppResourceId(Common.getRandomId());
					if(appResourceVO.getKind() == ResourceKindEnum.appYaml) {
						appResourceVO.setEncrypted(true);
						appResourceVO.setFilePath(uploadBasePath + appResourceVO.getKind().getFolderName() + new File(inputstreamHash.get(appResourceVO.getFieldName())).getName());
						versionVO.setConfigYmlPath(appResourceVO.getFilePath());

						//Needed in docker compose validation
						yamlTempFilePath = inputstreamHash.get(appResourceVO.getFieldName());

						//Needed to support old publisher apps
						resultMap.put("imagePath", versionVO.getConfigYmlPath());
					} else {
						appResourceVO.setFilePath(inputstreamHash.get(appResourceVO.getFieldName()));

						if(!Utility.validateResource(type, appResourceVO)) {
							throw new Error("Invalid " + appResourceVO.getKind().getDisplayName() + " file provided for " + appResourceVO.getServiceName() + " service.");
						}

						appResourceVO.setFilePath(uploadResourceBasePath + appResourceVO.getKind().getFolderName() + appResourceVO.getAppResourceId() + Constant.localFileSeparator + new File(inputstreamHash.get(appResourceVO.getFieldName())).getName());
					}
				}
			}

			versionVO.setAppId(appId);
			versionVO.setVersionId(appVersionId);

			Versions versionobj =  new Versions();
			if(type == ApplicationDefaultType.kubernetes) {
				versionVO = versionobj.createK8sAppVersion(projectId, versionVO, resourceVOs);
			} else {
				versionVO = versionobj.createAppVersion(projectId, versionVO, resourceVOs, yamlTempFilePath);
			}

			new PortalFileUpload().uploadAppResources(resourceVOs, inputstreamHash);

			//add in activity table
			new ActivityLogs().insert(authVo.getUserId(),ActivityOperation.createAppVersion.name(), new Gson().toJson(versionVO));

			resultMap.put(Constant.DATA, versionVO);
			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);
		} catch (Error e) {
			ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , e.getMessage(), e.getMessage());
			ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
		} catch (Exception e) {
			PALogger.ERROR(e);
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			} else if(e.getMessage().contains("Invalid composer file")) {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_BAD_REQUEST , "Invalid composer file provided.", "Invalid composer file provided.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			} else if(e.getMessage().contains(Constants.VERSION_ALREADY_EXISTS)) {
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_BAD_REQUEST , Constants.VERSION_ALREADY_EXISTS, Constants.VERSION_ALREADY_EXISTS);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to add version.", "Unable to add version.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
		} finally {
			for (Entry<String, String> tempFiles : inputstreamHash.entrySet()) {
				FileUtils.deleteQuietly(new File(tempFiles.getValue()).getParentFile());
			}
		}

	}

	private void mGetVersionDetails(String authToken, String appId,String versionId) {
		try {
			//CHECK AUTH TOKEN...
			new GrpcAuthHelper().checkAuthorization(authToken);

			VersionVO ver =  new DeveloperApplications().getVersionDetails(appId, versionId);
			if (ver!=null) {
				Map<String, Object> resultMap = new HashMap<>();
				resultMap.put(Constant.DATA, ver);
				ReturnObject.createResponse(Constant.SUCCESS, resultMap, null,
						response);
			}
			else
			{
				throw new Exception(Constant.NOTFOUND);
			}

		}catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else if(e.getMessage().equals(Constant.NOTFOUND)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_NOT_FOUND , "Version not found.", "No version found with requested app ID");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to get version details.", "Unable to get version details.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			PALogger.ERROR(e);	
		}

	}

	private void mCheckVersionExist(String authToken, String appId, String appPlatformId,
			String versionNumber) {
		try {
			//CHECK AUTH TOKEN...
			new GrpcAuthHelper().checkAuthorization(authToken);

			boolean exist =  new Versions().checkVersionExist(appId, appPlatformId, versionNumber);
			if (!exist) {
				Map<String, Object> resultMap = new HashMap<>();
				resultMap.put(Constant.DATA, versionNumber);
				ReturnObject.createResponse(Constant.SUCCESS, resultMap, null,response);
			}else{
				throw new Exception(Constant.NOTPERMITTED);
			}

		}catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else if(e.getMessage().equals(Constant.NOTPERMITTED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_BAD_REQUEST, "Version already exists.", "Version already exists.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to get version details.", "Unable to get version details.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			PALogger.ERROR(e);	
		}

	}

	private void mPublish(String authToken, String appId, String versionId) {

		mChangeAppVersionStatus(authToken, versionId, VERSION_STATUS.LIVE.name(),appId);


	}

	private void mGetImagesOfAppVersion(String authToken, String appId, String versionId) {
		try {
			//CHECK AUTH TOKEN...
			AuthorizationsVO authVo = new GrpcAuthHelper().getAuthorizationsVO(authToken);

			Applications applications=new Applications();

			String appOwnerId = applications.getUserIdOfApp(appId);
			if(!appOwnerId.equals(authVo.getUserId())){
				Utility.checkPermission(authVo.getGroupPermissions(), PermissionResources.getString(PermissionResourceKeys.APP_VERSION_INSTALL), appId);
			}

			VersionVO ver =  new DeveloperApplications().getVersionDetails(appId, versionId);
			if (ver!=null) {

				PortalFileUpload pfu = new PortalFileUpload();
				Map<String, Object> resultMap = new HashMap<>();
				List<String> images = new ArrayList<>();
				if(ver.getConfigYmlPath().endsWith(".tar"))
				{
					String filePath = pfu.getBasePath(Constants.PORTAL_YML_FOLDER_NAME, versionId) + ver.getConfigYmlPath().substring(ver.getConfigYmlPath().lastIndexOf('/') + 1);
					String filenameFromPortal=filePath.substring(filePath.lastIndexOf('/')+1);
					String filenameWithoutExtension = filenameFromPortal.substring(0,filenameFromPortal.lastIndexOf(".tar"));

					String yamlTmpFolderPath = pfu.getBasePath(Constants.PORTAL_YML_FOLDER_NAME, versionId) + "tmp/"+ filenameWithoutExtension + "/";
					new File(yamlTmpFolderPath).mkdirs();
					Utils.extarctTar(filePath, yamlTmpFolderPath);


					File tmpfolder = new File(yamlTmpFolderPath);
					if(tmpfolder.exists()) 
					{
						//parse old  yml file
						K8syamlParser kyamlParser; 
						ArrayList<File> arrayList = new ArrayList<>(Arrays.asList(tmpfolder.listFiles())); 

						ArrayList<String> lst =  (ArrayList<String>) arrayList.stream()
								.map(File::getAbsolutePath)
								.collect(Collectors.toList());


						kyamlParser = new K8syamlParser(lst);//tmp folderpath
						Map<String, List<K8sBase>> oldYamlList = kyamlParser.GetYamlobjects();
						final String dockerIOSlash = "docker.io/" ;
						for (Map.Entry<String, List<K8sBase>> entry : oldYamlList.entrySet()) {

							for (K8sBase oldkBase : entry.getValue()) 
							{
								String yamlKind = oldkBase.getKind();
								switch (yamlKind)
								{
								case	K8sPodsKinds.Deployment:
								case	K8sPodsKinds.ReplicaSet:
								case	K8sPodsKinds.ReplicationController:
								case	K8sPodsKinds.StatefulSet:
								case	K8sPodsKinds.DaemonSet:
								case	K8sPodsKinds.Job:
									K8sContainerBase deply= (K8sContainerBase)oldkBase;
									for (K8sContainers containers : deply.getSpec().getTemplate().getSpec().getContainers()) 
									{
										if(containers.getImage() != null)
										{
											if(containers.getImage().indexOf('/') == -1)
												images.add(dockerIOSlash + containers.getImage());
											else
												images.add(containers.getImage());
										}

									}
									break;
								case	K8sPodsKinds.CronJob:
									K8sCronJob cronJobs= (K8sCronJob)oldkBase;

									for (K8sContainers containers : cronJobs.getSpec().getJobTemplate().getSpec().getTemplate().getSpec().getContainers()) 
									{
										if(containers.getImage() != null)
										{
											if(containers.getImage().contains(Constants.getPLATEFORM_REPO()))
												images.add(containers.getImage());
											else
												images.add(dockerIOSlash + containers.getImage());
										}
									}
									break;
								case	K8sPodsKinds.Pod:
									K8sPod pod = (K8sPod)oldkBase;
									for (K8sContainers containers : pod.getSpec().getContainers()) 
									{
										if(containers.getImage() != null)
										{
											if(containers.getImage().contains(Constants.getPLATEFORM_REPO()))
												images.add(containers.getImage());
											else
												images.add(dockerIOSlash + containers.getImage());
										}
									}
									break;

								default:
									break;
								}
							}
						}

						FileUtils.deleteDirectory(tmpfolder);

					}


				}
				else
				{
					String filePath = pfu.getBasePath(Constants.PORTAL_YML_FOLDER_NAME, versionId) + Constant.localFileSeparator + ver.getConfigYmlPath().substring(ver.getConfigYmlPath().lastIndexOf('/'));
					ComposeVO composeVo = YamlParser.parse(filePath);

					images = (composeVo.getServices().values()).stream()
							.map(SectionVO::getImage)
							.collect(Collectors.toList());
				}

				resultMap.put(Constant.DATA, images);
				ReturnObject.createResponse(Constant.SUCCESS, resultMap, null,response);

			}
			else
			{
				throw new Exception(Constant.NOTFOUND);
			}

		}catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else if(e.getMessage().equals(Constant.NOTFOUND)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_NOT_FOUND , "Version not found.", "No version found with requested app ID");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to list images of app version.", "Unable to list images of app version.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			PALogger.ERROR(e);	
		}

	}


	private void mGetAppSecret(String authToken, String appId, String versionId) {
		try {
			// CHECK AUTH TOKEN...
			// Execute that operation if user is owner of that application.
			AuthorizationsVO authVo=new GrpcAuthHelper().getAuthorizationsVO(authToken);



			Applications applications=new Applications();

			String appOwnerId = applications.getUserIdOfApp(appId);
			List<SecretVo> serviceKeys;

			if (!StringFunctions.isNullOrWhitespace(appOwnerId)) 
			{
				if (appOwnerId.equals(authVo.getUserId()))
				{
					serviceKeys =   getSecret(appId,versionId);

				} 
				else 
				{
					List<String> lstPermissions = new ArrayList<>();
					lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.APP_SECRET_LIST));
					Utility.checkPermission(authVo.getGroupPermissions(),lstPermissions, appId, false);
					serviceKeys =   getSecret(appId,versionId);
				}


				Map<String, Object> resultMap = new HashMap<>();
				resultMap.put(Constant.DATA, serviceKeys);
				ReturnObject.createResponse(Constant.SUCCESS, resultMap,null, response);

			}


		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);

			}else if(e.getMessage().equals(Constant.NOTFOUND)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_NOT_FOUND , "secret not found", "No secret  found for requested application Id");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"Unable to list application secret keys.", "Unable to list application secret keys.");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			PALogger.ERROR(e);	
		}

	}


	private  List<SecretVo>  getSecret(String appId,String versionId) throws SQLException, IOException{

		DeveloperApplicationsEngine applicationsEngine = new DeveloperApplicationsEngine();
		VersionVO versionVO =  applicationsEngine.getVersionDetails(appId, versionId);
		String composePath = versionVO.getConfigYmlPath();

		List<SecretVo>   secretKeys= new ArrayList<>();
		String tempFolderPath = TempFiles.getTempFolderPath();
		try {
			String tempDecPath = tempFolderPath + versionId+"Dec";
			FileEncryptionDecryption.Decrypt_File(composePath, tempDecPath, new CredProvider().getEcnKey());

			ComposeVO composeVO= YamlParser.parse(tempDecPath);

			for (Entry<String, SectionVO> sectionEntry : composeVO.getServices().entrySet()) {


				SectionVO sectionVO =sectionEntry.getValue();

				YmlAuthConfig authConfig = new Gson().fromJson(sectionVO.getParsedLabels().get("com_mwp_conf_services"),YmlAuthConfig.class);

				if(authConfig.isSecret())
				{


					for (SecretVo secretVo : authConfig.getSecrets()) {  

						boolean found =false;

						for (SecretVo secretVo1 : secretKeys) 
						{
							if(secretVo1.getKey().equals(secretVo.getKey()))
								found = true;
						}
						if(!found)
							secretKeys.add(secretVo);
					}
				}
			}

		} finally {
			FileUtils.deleteQuietly(new File(tempFolderPath));
		}
		return secretKeys;
	}




}

/**
 * History of check-in or issue resolved
 * 
 * 01 - 12-10-2016 
 * AKH_01_1
 * Use getUserIdOfApp instead of getAppDetail because we only require userId of application. 
 * 
 * 02 - 14-11-2016 AKH_02
 * change param field use versionVO because we need more property to set like restRedirectUrl, redirectUrl, redirectType and redirectSection from UI in applicationVersion,
 * so we remove other param which exist in versionVO object and getting from UI and versionId and configFilePath set after create.
 */
