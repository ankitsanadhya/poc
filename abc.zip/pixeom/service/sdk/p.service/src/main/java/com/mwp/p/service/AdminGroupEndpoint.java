/*
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com)
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC.
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD
 * IN STRICTEST CONFIDENCE.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.mwp.p.service;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import javax.validation.ValidationException;
import javax.validation.constraints.NotNull;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import com.mwp.common.Client;
import com.mwp.common.ReturnObject;
import com.mwp.common.StringFunctions;
import com.mwp.common.constant.Constant;
import com.mwp.common.constant.PermissionResourceKeys;
import com.mwp.common.constant.PermissionResources;
import com.mwp.common.enums.RoleEnum;
import com.mwp.common.vo.AuthorizationsVO;
import com.mwp.common.vo.CodeVO;
import com.mwp.common.vo.ErrorVo;
import com.mwp.common.vo.GroupsVO;
import com.mwp.logger.PALogger;
import com.mwp.p.authhelper.GrpcAuthHelper;
import com.mwp.p.common.AdminPermissionCheck;
import com.mwp.p.common.Constants;
import com.mwp.p.common.enums.ResourceType;
import com.mwp.p.common.vo.DownloadResourceVO;
import com.mwp.p.framework.Download;
import com.mwp.p.framework.Groups;
import com.sun.research.ws.wadl.HTTPMethods;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Path("/admingroups")
@Api( value = "/admingroups",  
description = "Class manage admin group, manage create/update/delete group info." )
public class AdminGroupEndpoint 
{
	@Context
	private HttpServletResponse response;
	/** Method processing HTTP POST requests, producing "application/json" MIME media type.
	 * <p>
	 * This method create group application.
	 * <p>
	 * @param groupVO object details of group
	 * @param httpHeaders 
	 * @return Json string
	 * @throws Exception 
	 */
	@POST
	@Consumes("application/json")
	@Produces("application/json")
	@ApiOperation( value = "create group application.", 
	notes = "create group application.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED , message = Constant.NOTPERMITTED ),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to create group.")
	} )
	public void createGroup(@ApiParam(value = "GroupVO class object.", required = true)  @Valid @NotNull GroupsVO groupVO,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken) throws ValidationException
	{
		GroupCommon grp = new GroupCommon();
		grp.mCreateGroup(authToken, groupVO, true,response);
	}
	/** Method processing HTTP PUT requests, producing "application/json" MIME media type.
	 * <p>
	 * This method update group information.
	 * <p>
	 * @param groupVO object details of group
	 * @param httpHeaders 
	 * @return Json string
	 * @throws Exception 
	 */
	@PUT
	@Consumes("application/json")
	@Produces("application/json")
	@Path("/{id}")
	@ApiOperation( value = "update group application.", 
	notes = "update group application.", 
	response = HashMap.class)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to update group.")			 
	} )
	public void editGroup(@ApiParam( value = "group id.", required = true ) @PathParam("id")  @ NotNull String groupId,
			@ApiParam(value = "GroupVO class object.", required = true) @NotNull @Valid GroupsVO groupVO,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken) throws ValidationException {
		GroupCommon grp = new GroupCommon();
		grp.mEditGroup(authToken, groupVO,true,response);
	}

	/** Method processing HTTP DELETE requests, producing "application/json" MIME media type.
	 * <p>
	 * This method delete group info from db.
	 * <p>
	 * @param groupId a unique id of group.
	 * @param httpHeaders
	 * @return
	 * @throws Exception 
	 */
	@DELETE
	@Consumes("application/json")
	@Produces("application/json")
	@Path("/{id}")
	@ApiOperation( value = "delete group detail.", 
	notes = "delete group info from db.")
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to delete group.")			 
	} )
	public void deleteGroup(@ApiParam( value = "group id.", required = true ) @PathParam("id") @NotNull String groupId,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken) throws ValidationException {
		GroupCommon grp = new GroupCommon();
		grp.mDeleteGroup(authToken, groupId,true,"admin",response);
	}
	
	/** Method processing HTTP PUT requests, producing "application/json" MIME media type.
	 * <p>
	 * This method remove member/user from group.
	 * <p>
	 * @param groupId a unique id of group.
	 * @param userId a unique id of member.
	 * @param httpHeaders
	 * @return Json string
	 * @throws Exception 
	 */
	@DELETE
	@Consumes("application/json")
	@Produces("application/json")
	@Path("/{id}/members/{userid}")
	@ApiOperation( value = "remove member from group.", 
	notes = "remove member from group.", 
	response = String.class, responseContainer = "String")
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to remove member from group." )	 
	} )
	public void removeMemberFromGroup(@ApiParam( value = "group id.", required = true ) @NotNull @PathParam("id") String groupId,
			@ApiParam( value = "user id.", required = true ) @NotNull @PathParam("userid") String userId,
			@ApiParam( value = "group id.", required = true )  HashMap<String, Boolean> appIds,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken) throws ValidationException{
		GroupCommon grp = new GroupCommon();
		grp.mRemoveMemberFromGroup(authToken,groupId,userId,true,response);

	}

	/** Method processing HTTP POST requests, producing "application/json" MIME media type.
	 * <p>
	 * This method invite member on group.
	 * <p>
	 * @param groupId a unique id of group.
	 * @param emails list of comma separated email's.
	 * @param httpHeaders
	 * @return Json string
	 * @throws Exception 
	 */
	@POST
	@Produces({ MediaType.APPLICATION_JSON })
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/code")
	@ApiOperation( value = "invite member on group.", 
	notes = "invite member on group.", 
	response = String.class, responseContainer = "String")
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to invite member." )	 
	} )
	public void invite(@ApiParam(value = "Code object", required = true)  @Valid @NotNull CodeVO codeVo,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken) throws ValidationException{
		GroupCommon grp = new GroupCommon();
		grp.mInvite(authToken, codeVo,true,response);

	}
	
	/**
	 * 
	 * @param codeVo
	 */
	@PUT
	@Produces({ MediaType.APPLICATION_JSON })
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/{id}/code")
	@ApiOperation( value = "Edit code", notes = "Edit code")
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION ),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to update code.")
	} )
	public void editCode(@ApiParam( value = "group id.", required = true ) @PathParam("id") String groupId,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,
			@ApiParam(value = "Code object", required = true)  @NotNull @Valid CodeVO codeVo)throws ValidationException{
		GroupCommon grp = new GroupCommon();
		grp.mEditCode(authToken, codeVo,true,response);
	}
	

	/**
	 * This method for delete code.
	 * @param codeId
	 * @return
	 */
	@DELETE
	@Produces({ MediaType.APPLICATION_JSON })
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/code/{codeId}")
	@ApiOperation( value = "Delete code", notes = "Delete code")
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION ),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to delete code.")
	} )
	public void deleteCode(@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken,
			@ApiParam( value = "Code Id", required = true ) @NotNull @PathParam( "codeId" ) final String codeId)throws ValidationException{
		GroupCommon grp = new GroupCommon();
		grp.mDeleteCode(authToken,codeId,true,response);
	}
	
	@POST
	@Produces({ MediaType.APPLICATION_JSON })
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/{id}/resource")
	@ApiOperation( value = "add resource to group.", 
	notes = "add resource to group.")
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = Constant.NOTPERMITTED ),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message =  "Unable to add resource to group.")		 
	} )
	public void addResourcesToGroup(@ApiParam( value = "group id.", required = true ) @PathParam("id") @NotNull String groupId,
			@ApiParam( value = "resource id and type.", required = true )  Map<String,String> resourceIdTypeMap,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken) throws ValidationException{
		mAddResourceToGroup(authToken, resourceIdTypeMap, groupId);		
	}

	@PUT
	@Produces({ MediaType.APPLICATION_JSON })
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/{id}/resource/{resourceid}")
	@ApiOperation( value = "remove resource from group.", 
	notes = "remove resource from group." 
			)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = Constant.NOTPERMITTED),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to remove resource from group." )	 
	} )
	public void removeResourceFromGroup(@ApiParam( value = "group id.", required = true ) @PathParam("id") @NotNull String groupId,
			@ApiParam( value = "resource id.", required = true ) @PathParam("resourceid") String resourceId,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken)throws ValidationException {
		mRemoveResourceFromGroup(authToken, resourceId, groupId);

	}
	
	@DELETE
	@Produces({ MediaType.APPLICATION_JSON })
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/{id}/resource/")
	@ApiOperation( value = "remove multiple resources from group.", 
	notes = "remove multiple resources from group." 
			)
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = Constant.NOTPERMITTED),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message = "Unable to remove resource from group." )	 
	} )
	public void removeMUltipleResourcesFromGroup(@ApiParam( value = "group id.", required = true ) @PathParam("id") @NotNull String groupId,
			@ApiParam( value = "resource ids.", required = true ) List<String> resourceIds,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken)throws ValidationException {
		mRemoveMultipleResourcesFromGroup(authToken, resourceIds, groupId);

	}

	@GET
	@Produces({ MediaType.APPLICATION_JSON })
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/{id}/resource")
	@ApiOperation( value = "list resource of group.", 
	notes = "list resource of group.")
	@ApiResponses( {
		@ApiResponse( code = HttpServletResponse.SC_UNAUTHORIZED, message = Constant.NOTPERMITTED ),
		@ApiResponse( code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message =  "Unable to list resource of group.")		 
	} )
	public void listGroupResources(@ApiParam( value = "group id.", required = true ) @PathParam("id") @NotNull String groupId,
			@ApiParam(value = "resource type.", required = false) @NotNull @QueryParam("resourceType") String resourceType,
			@ApiParam(value="Authorization token",required=true)@HeaderParam("Authorization") String authToken) throws ValidationException{
		mListGroupResources(authToken, groupId, resourceType);		
	}


	private void mRemoveResourceFromGroup(String authToken, String resourceId, String groupId) {
		try {
			// Execute that operation if user is owner of that group.
			AuthorizationsVO authvo = new GrpcAuthHelper().getAuthorizationsVO(authToken);
			if( authvo.getRole() != RoleEnum.Admin) 
			{
				throw new Exception(Constant.UNAUTHORIZED);
			}
			String userId=authvo.getUserId();
			String result = Client.callServer(Constants.AUTH_SERVER_IP_PORT,Constants.AUTH_SERVICE_NAME, Constants.GROUP,  HTTPMethods.GET.name(), groupId, null, null, Constant.BEARER + authToken);
			GroupsVO groupsVo = Client.parseResult(result, GroupsVO.class);

			
				if (groupsVo != null && groupsVo.getAppUserId().equals(userId)) 
				{
					Groups groups = new Groups();
					groups.removeResourceFromGroup(resourceId, groupId);
					Map<String, Object> resultMap = new HashMap<>();
					resultMap.put(Constant.DATA, groupId);
					ReturnObject.createResponse(Constant.SUCCESS, resultMap,
							null, response);
				} else {
					throw new Exception(Constant.NOTPERMITTED);
				}
			
			

		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						Constants.UNABLE_TO_REMOVE_RESOURCE_FROM_GROUP, Constants.UNABLE_TO_REMOVE_RESOURCE_FROM_GROUP);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			PALogger.ERROR(e);	
		}
	}
	
	private void mRemoveMultipleResourcesFromGroup(String authToken, List<String> resourceIds, String groupId) {
		try {
			// Execute that operation if user is owner of that group.
			AuthorizationsVO authvo = new GrpcAuthHelper().getAuthorizationsVO(authToken);
			if( authvo.getRole() != RoleEnum.Admin) 
			{
				throw new Exception(Constant.UNAUTHORIZED);
			}
			String userId=authvo.getUserId();
			String result = Client.callServer(Constants.AUTH_SERVER_IP_PORT,Constants.AUTH_SERVICE_NAME, Constants.GROUP,  HTTPMethods.GET.name(), groupId, null, null, Constant.BEARER + authToken);
			GroupsVO groupsVo = Client.parseResult(result, GroupsVO.class);

			
				if (groupsVo != null && groupsVo.getAppUserId().equals(userId)) 
				{
					Groups groups = new Groups();
					groups.removeResourceFromGroup(resourceIds, groupId);
					Map<String, Object> resultMap = new HashMap<>();
					resultMap.put(Constant.DATA, groupId);
					ReturnObject.createResponse(Constant.SUCCESS, resultMap,
							null, response);
				} else {
					throw new Exception(Constant.NOTPERMITTED);
				}
			
			

		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						Constants.UNABLE_TO_REMOVE_RESOURCE_FROM_GROUP, Constants.UNABLE_TO_REMOVE_RESOURCE_FROM_GROUP);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			PALogger.ERROR(e);	
		}
	}
	

	/**
	 * 
	 * @param authToken
	 * @param resourceIdTypeMap hashmap with resourceId as key; and resource type as value
	 * @param groupId
	 */
	private void mAddResourceToGroup(String authToken,Map<String, String>  resourceIdTypeMap, String groupId)
	{
		try {
			//CHECK AUTH TOKEN...
			// Execute that operation if user is owner of that group.
			AuthorizationsVO authvo = new GrpcAuthHelper().getAuthorizationsVO(authToken);
//			
			if( authvo.getRole() != RoleEnum.Admin) 
			{
				throw new Exception(Constant.UNAUTHORIZED);
			}
			
			String userId=authvo.getUserId();
			String result = Client.callServer(Constants.AUTH_SERVER_IP_PORT,Constants.AUTH_SERVICE_NAME, Constants.GROUP,  HTTPMethods.GET.name(), groupId, null, null, Constant.BEARER + authToken);
			GroupsVO groupsVo= Client.parseResult(result, GroupsVO.class);
			
			if(groupsVo != null && groupsVo.getAppUserId().equals(userId))
			{
				
					Groups groups = new Groups();
					for (Map.Entry<String, String> resourceIdType : resourceIdTypeMap.entrySet())
					{
					
						groups.addResourceToGroup(resourceIdType.getKey(), groupId, ResourceType.valueOf(resourceIdType.getValue()));
					}
				
					Map<String, Object> resultMap = new HashMap<>();
					resultMap.put(Constant.DATA, groups.listGroupEdgeCore(groupId));
					ReturnObject.createResponse(Constant.SUCCESS, resultMap,
							null, response);
			}
			else
			{
				throw new Exception(Constant.NOTPERMITTED);
			}

		} catch (Exception e) {
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"Unable to add resource to group", "Unable to add resource to group");
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo,response);
			}
			PALogger.ERROR(e);	
		}
	}
	private void mListGroupResources(String authToken, String groupId, String resourceType) {
		try {

			AuthorizationsVO authvo = new GrpcAuthHelper().getAuthorizationsVO(authToken);
		
			List<DownloadResourceVO> rtrnLst;
			
			if(authvo.getRole() !=RoleEnum.Admin) 
			{
				List<String> lstPermissions = new ArrayList<>();
				if(!StringFunctions.isNullOrWhitespace(resourceType))
				{
					if(resourceType.equals(ResourceType.software.name()))
						lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_SOFTWARE));
					else if(resourceType.equals(ResourceType.document.name()))
						lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_DOCS));
					else 
					{
						throw new Exception(Constant.NOTPERMITTED);
					}
				}
				else
				{
					lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_DOCS));
					lstPermissions.add(PermissionResources.getString(PermissionResourceKeys.PORTAL_SOFTWARE));
				}
				
				AdminPermissionCheck.checkAdminPermission(authvo, lstPermissions, true);
			}
			ArrayList<String> groupIds= new ArrayList<>();
			groupIds.add(groupId);
			rtrnLst = new Download().listResoucesInGroups(groupIds, resourceType);

			Map<String, Object> resultMap = new HashMap<>();
			resultMap.put(Constant.DATA, rtrnLst);

			ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, response);


		} catch (Exception e) {
			
			PALogger.ERROR(e);	
			ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , "Unable to list resource", e);
			if(e.getMessage().equals(Constant.UNAUTHORIZED))
			{
				errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , Constant.REQUEST_REQUIRES_HTTP_AUTHENTICATION, ".");
			} 
			else if(e.getMessage().equals(Constant.NOTPERMITTED))
			{
				 errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
			}
			ReturnObject.createResponse(Constant.FAILURE, null, errorVo, response);
		}
	}

}
