/** 
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com) 
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL 
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC. 
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD 
 * IN STRICTEST CONFIDENCE. 
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */

package com.mwp.p.wss;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;
import javax.websocket.EndpointConfig;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.ServerEndpoint;

//import org.eclipse.jetty.websocket.common.WebSocketSession;
//import org.eclipse.jetty.websocket.jsr356.JsrSession;

import com.google.gson.Gson;
import com.mwp.common.AuthHelper;
import com.mwp.common.ReturnObject;
import com.mwp.common.constant.Constant;
import com.mwp.common.vo.ErrorVo;
import com.mwp.logger.PALogger;

@ServerEndpoint(value = "/routerip", configurator = GetHttpSessionConfigurator.class)
public class RouterIpEP {
	private String ipAddress;
	@OnMessage
	public String onMessage(String message, Session session) {
		return redirectmethod(message, session);

	}

	@OnOpen
	public void onOpen(Session session, EndpointConfig config) {


		this.ipAddress  = config.getUserProperties().get("ipAddress").toString();

	}

	private String redirectmethod(String message, Session session){

		Map<String, Object> data = new Gson().fromJson(message, Map.class);

		try{
			return mGetInternetRouterIP(data.get("AuthToken").toString(), session);

		}
		catch(Exception ex)
		{
			PALogger.ERROR(ex);
			ex.printStackTrace();
		}
		return "";

	}

	private String mGetInternetRouterIP(String authToken, Session session) {
		try {
			// CHECK AUTH TOKEN...
			Object authResult =  new AuthHelper().checkJwtToken(authToken); 
			if(authResult instanceof String)
				return (String)authResult;
			String ipReal = this.ipAddress; 
			PALogger.INFO("mGetInternetRouterIP - "+ipReal);
			Map<String, Object>  resultMap =  new HashMap<>();
			resultMap.put("IPReal", ipReal);
			resultMap.put("Status", Constant.SUCCESS);
			return ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, null);

		} catch (Exception e) {

			return handleException(e,  "internet router ip not found.");
		}
	}

	public static String handleException(Exception e, String message) 
	{
		PALogger.ERROR(e);

		ErrorVo errorVo = null;
		if(e.getMessage()!=null) 
		{
			if(e.getMessage().equals(Constant.UNAUTHORIZED)){
				errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , "Request requires HTTP authentication.", "Request requires HTTP authentication.");				
			}			
			else if( e.getMessage().equals(Constant.NOTPERMITTED))
			{
				errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);				
			}
			else if(e.getMessage().equals(Constant.NOTFOUND)){
				errorVo = new ErrorVo(HttpServletResponse.SC_NOT_FOUND , message, message);				
			}
			else {
				errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , message, message);
			}
		}		
		else {
			errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR , message, message);
		}

		return ReturnObject.createResponse(Constant.FAILURE, null, errorVo, null);

	}

}

