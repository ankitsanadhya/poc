/** 
 * Copyright (c) 2018-2099, PIXEOM, INC. (http://www.pixeom.com) 
 * All rights reserved.  PIXEOM HIGHLY CONFIDENTIAL 
 * THIS IS PROPRIETARY SOFTWARE OWNED BY PIXEOM, INC. 
 * THE SOURCE CODE IS PROVIDED ONLY UNDER NDA AND SHOULD BE HELD 
 * IN STRICTEST CONFIDENCE. 
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED. IN NO EVENT SHALL PIXEOM, INC. OR ITS CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */
package com.mwp.p.wss;

import java.util.Map;

import javax.servlet.http.HttpServletResponse;
import javax.websocket.OnMessage;
import javax.websocket.Session;
import javax.websocket.server.ServerEndpoint;

import com.google.gson.Gson;
import com.mwp.common.AuthHelper;
import com.mwp.common.ReturnObject;
import com.mwp.common.StringFunctions;
import com.mwp.common.constant.Constant;
import com.mwp.common.vo.ErrorVo;
import com.mwp.logger.PALogger;
import com.mwp.p.framework.Devices;

@ServerEndpoint(value = "/checkuniqueid")
public class CheckUniqueIdEP {

	@OnMessage
	public String onMessage(String message, Session session) {

		return redirectmethod(message, session);

	}


	private String redirectmethod(String message, Session session){

		Map<String, Object> data = new Gson().fromJson(message, Map.class);

		try{
				return mCheckUniqueId(data.get("AuthToken").toString(), data.get("productId").toString(),data.get("hostName").toString());

		}
		catch(Exception ex)
		{
			PALogger.ERROR(ex);
			ex.printStackTrace();
		}
		return "";

	}



	private String mCheckUniqueId(String authToken, String productId,String hostName) {
		try {
			Object authResult =  new AuthHelper().checkJwtToken(authToken); 
			if(authResult instanceof String)
				return (String)authResult;
			if(StringFunctions.isNullOrWhitespace(productId))
				throw new IllegalArgumentException("productId is required.");
			Map<String, Object>  resultMap = new Devices().isProductIDUnique(productId, hostName);
			return  ReturnObject.createResponse(Constant.SUCCESS, resultMap, null, null);
		} catch (Exception e) {
			PALogger.ERROR(e);	
			if( e.getMessage()!=null && e.getMessage().equals(Constant.UNAUTHORIZED)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED , "Request requires HTTP authentication.", "Request requires HTTP authentication.");
				return ReturnObject.createResponse(Constant.FAILURE, null, errorVo, null);
			}
			else if( e.getMessage()!=null && e.getMessage().equals(Constant.NOTFOUND)){
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_NOT_FOUND , "validationInfo not found", "No validationInfo found with requested application Id");
				return ReturnObject.createResponse(Constant.FAILURE, null, errorVo, null);
			}
			else if( e.getMessage()!=null && e.getMessage().equals(Constant.NOTPERMITTED))
			{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_UNAUTHORIZED ,Constant.NOTPERMITTED, Constant.NOTPERMITTED);
				return ReturnObject.createResponse(Constant.FAILURE, null, errorVo, null);
			}
			else{
				ErrorVo errorVo = new ErrorVo(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						e.getMessage(), e.getMessage());
				return ReturnObject.createResponse(Constant.FAILURE, null, errorVo,null);
			}
		}
	}

	
}

