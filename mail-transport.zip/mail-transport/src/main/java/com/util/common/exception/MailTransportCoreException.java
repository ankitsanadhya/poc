package com.util.common.exception;

/**
 * The Class LimitCoreException.
 * Will be parent class of all the exceptions which will be thrown by classes of Core package.
 * 
 * @author F342952
 */
public class MailTransportCoreException extends Exception {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -7576745387985847359L;

	/**
	 * Instantiates a new limit core exception.
	 */
	public MailTransportCoreException() {
		super();
	}

	/**
	 * Instantiates a new limit core exception.
	 * 
	 * @param message
	 *            the message
	 */
	public MailTransportCoreException(final String message) {
		super(message);
	}

	/**
	 * Instantiates a new limit core exception.
	 * 
	 * @param cause
	 *            the cause
	 */
	public MailTransportCoreException(final Throwable cause) {
		super(cause);
	}

	/**
	 * Instantiates a new limit core exception.
	 * 
	 * @param message
	 *            the message
	 * @param cause
	 *            the cause
	 */
	public MailTransportCoreException(final String message, final Throwable cause) {
		super(message, cause);
	}

}
