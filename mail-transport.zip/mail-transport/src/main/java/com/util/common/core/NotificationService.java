package com.util.common.core;

import java.util.Map;

import com.util.common.bean.EmailNotification;
import com.util.common.exception.MailNotificationException;
import com.util.common.exception.MailTransportCoreException;

/**
 * The Class NotificationService.
 * 
 * @author 285221 - Ankit Sanadhya
 */
public interface NotificationService {

	/**
	 * This method is used to create string from message template.
	 * 
	 * @param templateLocation
	 *            the template location
	 * @param parameters
	 *            the parameters
	 * @return the string
	 * @throws LimitCoreException
	 *             the limit core exception
	 */
	String createEmail(final String templateLocation, final Map<String, Object> parameters) throws MailTransportCoreException;

	/**
	 * Send email.
	 *
	 * @param emailNotification the email notification
	 * @param fileName the file name
	 * @throws LimitNotificationException the limit notification exception
	 */
	void sendEmail(final EmailNotification emailNotification, String fileName) throws MailNotificationException;

}
