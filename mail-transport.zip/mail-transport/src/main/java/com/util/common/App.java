package com.util.common;

import java.util.HashMap;
import java.util.Map;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

import com.util.common.bean.EmailNotification;
import com.util.common.core.NotificationService;
import com.util.common.exception.MailNotificationException;

public class App {

	public static void main(String args[]) {

		EmailNotification mail = new EmailNotification();
		mail.setMailFrom("ankitsanadhya44@gmail.com");
		mail.setMailTo("ankush.sanadhya@gmail.com");
		mail.setMailSubject("Shut Up");

		Map<String, Object> model = new HashMap<String, Object>();
		model.put("firstName", "Ankush");
		model.put("lastName", "Sanadhya");
		model.put("location", "Pune");
		model.put("signature", "www.cogni.com");
		mail.setModel(model);

		AbstractApplicationContext context = new AnnotationConfigApplicationContext(
				AppConfig.class);
		NotificationService mailService = (NotificationService) context.getBean("mailService");
		try {
			mailService.sendEmail(mail, null);
		} catch (MailNotificationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		context.close();
	}

}
