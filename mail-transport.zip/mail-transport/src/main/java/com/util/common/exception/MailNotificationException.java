package com.util.common.exception;

/**
 * The Class LimitNotificationException.
 * Will be rasied if there is some problem in email sending code.
 * 
 * @author F342952
 */
public class MailNotificationException extends Exception {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -7020340470807599496L;

	/**
	 * Instantiates a new limit notification exception.
	 */
	public MailNotificationException() {
		super();
	}

	/**
	 * Instantiates a new limit notification exception.
	 * 
	 * @param message
	 *            the message
	 */
	public MailNotificationException(final String message) {
		super(message);
	}

	/**
	 * Instantiates a new limit notification exception.
	 * 
	 * @param cause
	 *            the cause
	 */
	public MailNotificationException(final Throwable cause) {
		super(cause);
	}

	/**
	 * Instantiates a new limit notification exception.
	 * 
	 * @param message
	 *            the message
	 * @param cause
	 *            the cause
	 */
	public MailNotificationException(final String message, final Throwable cause) {
		super(message, cause);
	}

}
