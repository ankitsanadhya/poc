/**
 * 
 */
package com.jpmorgan.rubi.xml.utils.dto;


/**
 * @author Ankit
 */
public class RubiXmlControllerDTO {

	private String inputDirectory;
	private String tagName;
	private String newTagName;
	private String attributeName;
	private String attributeValue;
	private String tagTextValue;
	private String insertBeforeTag;
	private String submitButton;
	private String xpathOfTag;

	/**
	 * @return the inputDirectory
	 */
	public String getInputDirectory() {
		return inputDirectory;
	}

	/**
	 * @param inputDirectory
	 *            the inputDirectory to set
	 */
	public void setInputDirectory(String inputDirectory) {
		this.inputDirectory = inputDirectory;
	}

	/**
	 * @return the tagName
	 */
	public String getTagName() {
		return tagName;
	}

	/**
	 * @param tagName
	 *            the tagName to set
	 */
	public void setTagName(String tagName) {
		this.tagName = tagName;
	}

	/**
	 * @return the newTagName
	 */
	public String getNewTagName() {
		return newTagName;
	}

	/**
	 * @param newTagName
	 *            the newTagName to set
	 */
	public void setNewTagName(String newTagName) {
		this.newTagName = newTagName;
	}

	/**
	 * @return the attributeName
	 */
	public String getAttributeName() {
		return attributeName;
	}

	/**
	 * @param attributeName
	 *            the attributeName to set
	 */
	public void setAttributeName(String attributeName) {
		this.attributeName = attributeName;
	}

	/**
	 * @return the attributeValue
	 */
	public String getAttributeValue() {
		return attributeValue;
	}

	/**
	 * @param attributeValue
	 *            the attributeValue to set
	 */
	public void setAttributeValue(String attributeValue) {
		this.attributeValue = attributeValue;
	}

	/**
	 * @return the tagTextValue
	 */
	public String getTagTextValue() {
		return tagTextValue;
	}

	/**
	 * @param tagTextValue
	 *            the tagTextValue to set
	 */
	public void setTagTextValue(String tagTextValue) {
		this.tagTextValue = tagTextValue;
	}

	/**
	 * @return the insertBeforeTag
	 */
	public String getInsertBeforeTag() {
		return insertBeforeTag;
	}

	/**
	 * @param insertBeforeTag
	 *            the insertBeforeTag to set
	 */
	public void setInsertBeforeTag(String insertBeforeTag) {
		this.insertBeforeTag = insertBeforeTag;
	}

	/**
	 * @return the submitButton
	 */
	public String getSubmitButton() {
		return submitButton;
	}

	/**
	 * @param string
	 *            the submitButton to set
	 */
	public void setSubmitButton(String string) {
		submitButton = string;
	}

	/**
	 * @return the xpathOfTag
	 */
	public String getXpathOfTag() {
		return xpathOfTag;
	}

	/**
	 * @param xpathOfTag
	 *            the xpathOfTag to set
	 */
	public void setXpathOfTag(String xpathOfTag) {
		this.xpathOfTag = xpathOfTag;
	}

	// private List<String> deleteList;
	// private List<String> nodeReplaceList;
	// private List<String> nodeValueUpdateList;

}
