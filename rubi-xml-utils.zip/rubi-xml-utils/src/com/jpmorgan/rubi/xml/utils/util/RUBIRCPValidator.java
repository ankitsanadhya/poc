package com.jpmorgan.rubi.xml.utils.util;

import java.util.Collection;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * This class has utility methods to validate the given input. author r329686
 */
public final class RUBIRCPValidator {

    /**
     * Method to check if passed object is null.
     * 
     * @param <T>
     *            the generic type
     * @param object
     *            Object.
     * @return A boolean value.
     */
    public static <T> boolean isNull(final T object) {
	boolean flag = false;
	if (object == null) {
	    flag = true;
	}
	return flag;
    }

    /**
     * Method to check if passed object is empty. Valid for String,
     * StringBuffer, String[], Object[], List, Map, Set.
     * 
     * @param <T>
     *            the generic type
     * @param object
     *            Object.
     * @return A boolean value.
     */
    public static <T> boolean isEmpty(final T object) {
	boolean flag = false;
	if (!isNull(object)) {
	    if (object instanceof String) {
		if ((((String) object).trim().length() == 0)
			|| ((String) object).trim().equalsIgnoreCase("null")) {
		    flag = true;
		}
	    } else if (object instanceof Collection) {
		if (((Collection) object).isEmpty()) {
		    flag = true;
		}
	    } else if (object instanceof String[]) {
		if (((String[]) object).length == 0) {
		    flag = true;
		}
	    } else if (object instanceof StringBuffer) {
		if (((StringBuffer) object).toString().trim().length() == 0) {
		    flag = true;
		}
	    } else if (object instanceof Object[]) {
		if (((Object[]) object).length == 0) {
		    flag = true;
		}
	    } else if (object instanceof Map) {
		if (((Map) object).isEmpty()) {
		    flag = true;
		}
	    }
	} else {
	    flag = true;
	}
	return flag;
    }

    /**
     * Method to check if passed objects are equal. Valid for String, Integer,
     * Long, Float, Double, BigDecimal, Date, Boolean and
     * 
     * @param <T>
     *            the generic type
     * @param firstObject
     *            first object which needs to be checked with second object
     * @param secondObject
     *            second object which compares with first object.
     * @return boolean object.
     */
    public static <T> boolean isEqual(final T firstObject, final T secondObject) {
	boolean flag = false;
	if (!isNull(firstObject) && !isNull(secondObject)) {
	    if ((firstObject instanceof String)
		    && (secondObject instanceof String)) {
		flag = ((String) firstObject).trim().equalsIgnoreCase(
			((String) secondObject).trim());
	    } else {
		flag = firstObject.equals(secondObject);
	    }
	}
	return flag;
    }

    /**
     * Method to check if passed string is a number.
     * 
     * @param strNumber
     *            Number string.
     * @return A boolean value.
     */
    public static boolean isNumber(final String strNumber) {
	final Pattern patter = Pattern
		.compile(RubiLimitClientConstants.NUMBER_PATTERN);
	final Matcher matcher = patter.matcher(strNumber);
	return matcher.matches();

    }

    /**
     * Method to check if the passed value has only alphabets.
     * 
     * @param string
     *            to be checked.
     * @return A boolean value.
     */
    public static boolean isAllAlphabet(final String string) {
	boolean flag = true;
	if (!isEmpty(string)) {
	    for (final Character ch : string.toCharArray()) {
		if (!Character.isLetter(ch) || Character.isSpaceChar(ch)) {
		    flag = false;
		    break;
		}
	    }
	}
	return flag;
    }

    /**
     * Method to check if the passed value has only alphabets and space.
     * 
     * @param string
     *            to be checked.
     * @return A boolean value.
     */
    public static boolean isAllAlphabetAndSpace(final String string) {
	boolean flag = false;
	if (!isEmpty(string)) {
	    final Pattern patter = Pattern
		    .compile(RubiLimitClientConstants.ALPHANUMERIC_WS);
	    final Matcher matcher = patter.matcher(string);
	    flag = matcher.matches();
	}
	return flag;

    }

    /**
     * Method to check if the passed value is alpha numeric. *
     * 
     * @param string
     *            to be checked.
     * @return A boolean value.
     */
    public static boolean isAllAlphaNumeric(final String string) {
	boolean flag = true;
	if (!isEmpty(string)) {
	    for (final Character ch : string.toCharArray()) {
		if (!Character.isLetter(ch) || Character.isDigit(ch)) {
		    flag = false;
		    break;
		}
	    }
	}
	return flag;
    }

    /**
     * This method is used to check if the given value has special character.
     * 
     * @param searchText
     *            object of <code>String</code> needs to be check.
     * @return boolean value.
     */
    public static boolean isSpecialCharacter(final String searchText) {
	final Pattern patter = Pattern
		.compile(RubiLimitClientConstants.ALL_SPECIAL_CHARS);
	final Matcher matcher = patter.matcher(searchText);
	return matcher.matches();
    }

    /**
     * Checks if is special character for search by spn.
     * 
     * @param searchText
     *            the search text
     * @return true, if is special character for search by spn
     */
    public static boolean isSpecialCharacterForSearchBySPN(
	    final String searchText) {
	final Pattern patter = Pattern
		.compile(RubiLimitClientConstants.SPECIAL_CHARS_FOR_SEARCH);
	final Matcher matcher = patter.matcher(searchText);
	return matcher.matches();
    }

    /**
     * This method is used to check the bpv value is decimal numeric value.
     * 
     * @param bpvValue
     *            object of <code>String</code> needs to be check.
     * @return booleanc
     */
    public static boolean isValidBpvValue(final String bpvValue) {
	final Pattern patter = Pattern
		.compile(RubiLimitClientConstants.LIMIT_VALUE_PATTERN);
	final Matcher matcher = patter.matcher(bpvValue);
	return matcher.matches();

    }

    /**
     * Checks if is valid bpv value for non-STP.
     * 
     * @param bpvValue
     *            the bpv value
     * @return true, if is valid bpv value for non-STP.
     */
    public static boolean isValidBpvValueForNonStp(final String bpvValue) {

	final Pattern pattern = Pattern
		.compile(RubiLimitClientConstants.NON_STP_LIMIT_VALUE_PATTERN);
	final Matcher matcher = pattern.matcher(bpvValue);

	return matcher.matches();

    }

    // Changes for jira - IBTRGOC-870
    public static boolean isValidThreshold(final String value) {
	final int valueInt = new Integer(value).intValue();
	// Changes for Defect # GRSTM-9483
	if ((valueInt > 0) && (valueInt <= 100)) {
	    return true;
	} else {
	    return false;
	}
    }

    /**
     * This method is used to check the threshold value.
     * 
     * @param bpvValue
     *            object of <code>String</code> needs to be check.
     * @return boolean
     */
    public static boolean isValidThresholdValue(final String bpvValue) {
	final Pattern patter = Pattern
		.compile(RubiLimitClientConstants.THRESHOLD_VALUE_PATTERN);
	final Matcher matcher = patter.matcher(bpvValue);
	return matcher.matches();

    }

    /**
     * Checks if is valid tenor month.
     * 
     * @param value
     *            the value
     * @return true, if is valid tenor month
     */
    public static boolean isValidTenorMonth(final String tenorStartValue,
	    final String tenorEndValue) {
	final int tenorStartMonth = new Integer(tenorStartValue).intValue();
	final int tenorEndMonth = new Integer(tenorEndValue).intValue();
	if ((tenorStartMonth >= 0) && (tenorStartMonth <= 599)
		&& (tenorEndMonth >= 0) && (tenorEndMonth <= 600)
		&& (tenorStartMonth < tenorEndMonth)) {
	    return true;
	} else {
	    return false;
	}
    }

    /**
     * Checks if is equal case sensitive.
     * 
     * @param <T>
     *            the generic type
     * @param firstObject
     *            the first object
     * @param secondObject
     *            the second object
     * @return true, if is equal case sensitive
     */
    public static <T> boolean isEqualCaseSensitive(final T firstObject,
	    final T secondObject) {
	boolean flag = false;
	if (!isNull(firstObject) && !isNull(secondObject)) {
	    if ((firstObject instanceof String)
		    && (secondObject instanceof String)) {
		flag = ((String) firstObject).trim().equals(
			((String) secondObject).trim());
	    } else {
		flag = firstObject.equals(secondObject);
	    }
	}
	return flag;
    }

    public static boolean isAlphanumeric(final String string) {
	final Pattern patter = Pattern
		.compile(RubiLimitClientConstants.ALPHANUMERIC_REG_EX);
	final Matcher matcher = patter.matcher(string);
	return matcher.matches();
    }

    public static boolean isAlphanumericWithSingleSpace(final String string) {
	final Pattern patter = Pattern
		.compile(RubiLimitClientConstants.ALPHANUMERIC_SINGLESPACE);
	final Matcher matcher = patter.matcher(string);
	return matcher.matches();
    }

    public static boolean isLCHTradeId(final String string) {
	final Pattern patter = Pattern
		.compile(RubiLimitClientConstants.LCH_TRADE_ID_REG_EX);
	final Matcher matcher = patter.matcher(string);
	return matcher.matches();
    }

    public static boolean isFCMTradeId(final String string) {
	final Pattern patter = Pattern
		.compile(RubiLimitClientConstants.FCM_TRADE_ID_REG_EX);
	final Matcher matcher = patter.matcher(string);
	return matcher.matches();
    }

    public static boolean isValidPercentage(final String bpvValue) {
	final Pattern patter = Pattern
		.compile("^100$|^\\d{0,2}(\\.\\d{1,1})? *%?$");
	final Matcher matcher = patter.matcher(bpvValue);
	return matcher.matches();

    }
}
