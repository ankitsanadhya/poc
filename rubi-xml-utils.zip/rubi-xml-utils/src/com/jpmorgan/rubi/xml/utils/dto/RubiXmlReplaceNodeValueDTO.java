package com.jpmorgan.rubi.xml.utils.dto;

import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;

public class RubiXmlReplaceNodeValueDTO {

	private Label InputDirLabel;
	private Label nodeNameLabel;
	private Label nodeTextValueLabel;
	private Label xpathLabel;
	private Label totalNumberOfXml;
	private Label noOfUpdatedFile;
	private Label nodeNotFoundNo;
	private Label noOfScemaValidationFailed;

	private Text totalNumberOfXmlText;
	private Text noOfUpdatedFileText;
	private Text nodeNotFoundNoText;
	private Text noOfScemaValidationFailedText;
	private Text inputDirText;
	private Text nodeNameText;
	private Text nodeTextValueText;
	private Text xpathText;

	private Button updateNodeValueButton;

	/**
	 * @return the inputDirLabel
	 */
	public Label getInputDirLabel() {
		return InputDirLabel;
	}

	/**
	 * @param inputDirLabel
	 *            the inputDirLabel to set
	 */
	public void setInputDirLabel(Label inputDirLabel) {
		InputDirLabel = inputDirLabel;
	}

	/**
	 * @return the nodeNameLabel
	 */
	public Label getNodeNameLabel() {
		return nodeNameLabel;
	}

	/**
	 * @param nodeNameLabel
	 *            the nodeNameLabel to set
	 */
	public void setNodeNameLabel(Label nodeNameLabel) {
		this.nodeNameLabel = nodeNameLabel;
	}

	/**
	 * @return the nodeTextValueLabel
	 */
	public Label getNodeTextValueLabel() {
		return nodeTextValueLabel;
	}

	/**
	 * @param nodeTextValueLabel
	 *            the nodeTextValueLabel to set
	 */
	public void setNodeTextValueLabel(Label nodeTextValueLabel) {
		this.nodeTextValueLabel = nodeTextValueLabel;
	}

	/**
	 * @return the xpathLabel
	 */
	public Label getXpathLabel() {
		return xpathLabel;
	}

	/**
	 * @param xpathLabel
	 *            the xpathLabel to set
	 */
	public void setXpathLabel(Label xpathLabel) {
		this.xpathLabel = xpathLabel;
	}

	/**
	 * @return the inputDirText
	 */
	public Text getInputDirText() {
		return inputDirText;
	}

	/**
	 * @param inputDirText
	 *            the inputDirText to set
	 */
	public void setInputDirText(Text inputDirText) {
		this.inputDirText = inputDirText;
	}

	/**
	 * @return the nodeNameText
	 */
	public Text getNodeNameText() {
		return nodeNameText;
	}

	/**
	 * @param nodeNameText
	 *            the nodeNameText to set
	 */
	public void setNodeNameText(Text nodeNameText) {
		this.nodeNameText = nodeNameText;
	}

	/**
	 * @return the nodeTextValueText
	 */
	public Text getNodeTextValueText() {
		return nodeTextValueText;
	}

	/**
	 * @param nodeTextValueText
	 *            the nodeTextValueText to set
	 */
	public void setNodeTextValueText(Text nodeTextValueText) {
		this.nodeTextValueText = nodeTextValueText;
	}

	/**
	 * @return the xpathText
	 */
	public Text getXpathText() {
		return xpathText;
	}

	/**
	 * @param xpathText
	 *            the xpathText to set
	 */
	public void setXpathText(Text xpathText) {
		this.xpathText = xpathText;
	}

	/**
	 * @return the updateNodeValueButton
	 */
	public Button getUpdateNodeValueButton() {
		return updateNodeValueButton;
	}

	/**
	 * @param updateNodeValueButton
	 *            the updateNodeValueButton to set
	 */
	public void setUpdateNodeValueButton(Button updateNodeValueButton) {
		this.updateNodeValueButton = updateNodeValueButton;
	}

	/**
	 * @return the totalNumberOfXml
	 */
	public Label getTotalNumberOfXml() {
		return totalNumberOfXml;
	}

	/**
	 * @param totalNumberOfXml
	 *            the totalNumberOfXml to set
	 */
	public void setTotalNumberOfXml(Label totalNumberOfXml) {
		this.totalNumberOfXml = totalNumberOfXml;
	}

	/**
	 * @return the noOfUpdatedFile
	 */
	public Label getNoOfUpdatedFile() {
		return noOfUpdatedFile;
	}

	/**
	 * @param noOfUpdatedFile
	 *            the noOfUpdatedFile to set
	 */
	public void setNoOfUpdatedFile(Label noOfUpdatedFile) {
		this.noOfUpdatedFile = noOfUpdatedFile;
	}

	/**
	 * @return the nodeNotFoundNo
	 */
	public Label getNodeNotFoundNo() {
		return nodeNotFoundNo;
	}

	/**
	 * @param nodeNotFoundNo
	 *            the nodeNotFoundNo to set
	 */
	public void setNodeNotFoundNo(Label nodeNotFoundNo) {
		this.nodeNotFoundNo = nodeNotFoundNo;
	}

	/**
	 * @return the noOfScemaValidationFailed
	 */
	public Label getNoOfScemaValidationFailed() {
		return noOfScemaValidationFailed;
	}

	/**
	 * @param noOfScemaValidationFailed
	 *            the noOfScemaValidationFailed to set
	 */
	public void setNoOfScemaValidationFailed(Label noOfScemaValidationFailed) {
		this.noOfScemaValidationFailed = noOfScemaValidationFailed;
	}

	/**
	 * @return the totalNumberOfXmlText
	 */
	public Text getTotalNumberOfXmlText() {
		return totalNumberOfXmlText;
	}

	/**
	 * @param totalNumberOfXmlText
	 *            the totalNumberOfXmlText to set
	 */
	public void setTotalNumberOfXmlText(Text totalNumberOfXmlText) {
		this.totalNumberOfXmlText = totalNumberOfXmlText;
	}

	/**
	 * @return the noOfUpdatedFileText
	 */
	public Text getNoOfUpdatedFileText() {
		return noOfUpdatedFileText;
	}

	/**
	 * @param noOfUpdatedFileText
	 *            the noOfUpdatedFileText to set
	 */
	public void setNoOfUpdatedFileText(Text noOfUpdatedFileText) {
		this.noOfUpdatedFileText = noOfUpdatedFileText;
	}

	/**
	 * @return the nodeNotFoundNoText
	 */
	public Text getNodeNotFoundNoText() {
		return nodeNotFoundNoText;
	}

	/**
	 * @param nodeNotFoundNoText
	 *            the nodeNotFoundNoText to set
	 */
	public void setNodeNotFoundNoText(Text nodeNotFoundNoText) {
		this.nodeNotFoundNoText = nodeNotFoundNoText;
	}

	/**
	 * @return the noOfScemaValidationFailedText
	 */
	public Text getNoOfScemaValidationFailedText() {
		return noOfScemaValidationFailedText;
	}

	/**
	 * @param noOfScemaValidationFailedText
	 *            the noOfScemaValidationFailedText to set
	 */
	public void setNoOfScemaValidationFailedText(Text noOfScemaValidationFailedText) {
		this.noOfScemaValidationFailedText = noOfScemaValidationFailedText;
	}

}
