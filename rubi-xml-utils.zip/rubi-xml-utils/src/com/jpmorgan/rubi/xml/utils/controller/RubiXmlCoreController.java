package com.jpmorgan.rubi.xml.utils.controller;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.jpmorgan.rubi.xml.utils.dto.RubiXmlControllerDTO;

public class RubiXmlCoreController {
	private List<String> errorFileList = new ArrayList<String>();
	private int totalFileCounter = 0;
	private int updatedFileCounter = 0;
	private int nodeNotFoundFileCounter = 0;
	private static String message = null;
	int infectedFileSize = 0;

	public static List<String> logFolderDetail(String parentFolderDirectory) {
		String result;
		String _result[];

		result = recurseInDirFrom(parentFolderDirectory);

		_result = result.split(File.separatorChar + "|");

		return Arrays.asList(_result);
	}

	public void xmlController(RubiXmlControllerDTO rubiXmlControllerDTO) throws IOException, ParserConfigurationException {
		List<String> listOfFolder = null;
		final String parentDir = rubiXmlControllerDTO.getInputDirectory();

		listOfFolder = logFolderDetail(parentDir);

		final Iterator<String> listIterator = listOfFolder.iterator();
		while (listIterator.hasNext()) {
			final String path = listIterator.next();

			if (path.contains(".xml") && !path.contains(".svn")) {
				totalFileCounter = totalFileCounter + 1;
				final String currentDirectoryPath = path;

				final DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
				final DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
				Document doc = null;
				try {
					doc = docBuilder.parse(currentDirectoryPath);
					final String str = rubiXmlControllerDTO.getSubmitButton();
					if (str.equalsIgnoreCase("Insert Tag")) {
						final String rootTagName = rubiXmlControllerDTO.getTagName();
						final String insertTagBefore = rubiXmlControllerDTO.getInsertBeforeTag();
						final String newTagName = rubiXmlControllerDTO.getNewTagName();
						final String newTagAttributeName = rubiXmlControllerDTO.getAttributeName();
						final String newTagAttributeValue = rubiXmlControllerDTO.getAttributeValue();
						final String nodeTextValue = rubiXmlControllerDTO.getTagTextValue();
						final String xpathValue = rubiXmlControllerDTO.getXpathOfTag();
						insertNodeInXml(rootTagName, insertTagBefore, doc, currentDirectoryPath, newTagName, newTagAttributeName,
								newTagAttributeValue, nodeTextValue, xpathValue);

					}

					if (str.equalsIgnoreCase("Replace Tag")) {
						final String nodeToReplace = rubiXmlControllerDTO.getTagName();
						final String newTagName = rubiXmlControllerDTO.getNewTagName();
						final String xpathValue = rubiXmlControllerDTO.getXpathOfTag();
						replaceNodeInXml(nodeToReplace, newTagName, doc, currentDirectoryPath, xpathValue);
					}

					if (str.equalsIgnoreCase("Replace Tag Value")) {
						final String nodeToReplaceValue = rubiXmlControllerDTO.getTagName();
						final String textValue = rubiXmlControllerDTO.getTagTextValue();
						final String xpathValue = rubiXmlControllerDTO.getXpathOfTag();
						replaceNodeValueInXml(nodeToReplaceValue, doc, currentDirectoryPath, textValue, xpathValue);
					}

					if (str.equalsIgnoreCase("Delete Tag")) {
						final String nodeToDelete = rubiXmlControllerDTO.getTagName();
						final String xpathValue = rubiXmlControllerDTO.getXpathOfTag();
						deleteNodeInXml(nodeToDelete, doc, currentDirectoryPath, xpathValue);
					}

				} catch (final SAXException e) {
					System.out.println("SAX Exception : " + e.getMessage());
				}
			}

		}
		System.out.println("Total No Of Files:" + totalFileCounter);
		System.out.println("Node not Found in File:" + nodeNotFoundFileCounter);
		updatedFileCounter = totalFileCounter - nodeNotFoundFileCounter;
		System.out.println("No of updated file:" + updatedFileCounter);
		System.out.println("No Of Infected Files :" + infectedFileSize);

	}

	private static String recurseInDirFrom(String parentFolderDirectory) {
		File file;
		String list[];
		String result = parentFolderDirectory;
		file = new File(parentFolderDirectory);
		if (file.isDirectory()) {
			list = file.list();
			for (final String element : list) {
				if (element.contains("$RECYCLE.BIN")) {
					// message = "Please Enter Valid Directory";
				} else {
					result = result + "|" + recurseInDirFrom(parentFolderDirectory + File.separatorChar + element);
				}
			}
		}
		return result;
	}

	private void insertNodeInXml(String rootTagName, String insertTagBefore, Document doc, String currentDirectoryPath, String newTagName,
			String newTagAttributeName, String newTagAttributeValue, String nodeTextValue, String xpathValue) {
		try {
			final NodeList rootTagElement = doc.getElementsByTagName(rootTagName);
			final int noOfRootNode = rootTagElement.getLength();
			if (noOfRootNode == 0) {
				nodeNotFoundFileCounter = nodeNotFoundFileCounter + 1;
			}
			if (noOfRootNode == 1) {
				for (int i = 0; i < noOfRootNode; i++) {
					final NodeList insertBeforeNode = (NodeList) doc.getElementsByTagName(insertTagBefore).item(0);
					if (insertBeforeNode != null) {
						final Element newTagElement = doc.createElement(newTagName);
						if (!newTagAttributeName.equalsIgnoreCase("") && !newTagAttributeValue.equalsIgnoreCase("")) {
							newTagElement.setAttribute(newTagAttributeName, newTagAttributeValue);
						}
						newTagElement.appendChild(doc.createTextNode(nodeTextValue));
						rootTagElement.item(i).insertBefore(newTagElement, (Node) insertBeforeNode);
						writeInXmlFile(doc, currentDirectoryPath);
					} else {
						final Element newTagElement = doc.createElement(newTagName);
						if (!newTagAttributeName.equalsIgnoreCase("") && !newTagAttributeValue.equalsIgnoreCase("")) {
							newTagElement.setAttribute(newTagAttributeName, newTagAttributeValue);
						}
						newTagElement.appendChild(doc.createTextNode(nodeTextValue));
						rootTagElement.item(i).insertBefore(newTagElement, null);
						writeInXmlFile(doc, currentDirectoryPath);
					}
				}
			}
		} catch (final Exception e) {
			System.out.println(e.getMessage());
		}
	}

	private void replaceNodeInXml(String nodeToReplace, String newCustomTag, Document doc, String currentDirectoryPath, String xpathValue) {
		try {
			final NodeList nodes = doc.getElementsByTagName(nodeToReplace);
			if (nodes != null) {
				final int nodeCount = nodes.getLength();
				if (nodeCount == 0) {
					nodeNotFoundFileCounter = nodeNotFoundFileCounter + 1;
				}
				final int remainingNodeCount = 0;
				for (int nuberOfNodes = 0; nuberOfNodes < nodeCount; nuberOfNodes++) {
					if (nodes.item(remainingNodeCount) instanceof Element) {
						final Element elem = (Element) nodes.item(remainingNodeCount);
						doc.renameNode(elem, "test", newCustomTag);
						removeNameSapaceAttribute(doc, newCustomTag, currentDirectoryPath);
						writeInXmlFile(doc, currentDirectoryPath);
					}
				}
			}

			if (!xpathValue.isEmpty() && xpathValue != null) {
				doc.getDocumentElement().normalize();
				XPathFactory xpathFactory = XPathFactory.newInstance();
				// XPath to find empty text nodes.
				String xpath = xpathValue;
				XPathExpression xpathExp = xpathFactory.newXPath().compile(xpath);
				NodeList nodeList = (NodeList) xpathExp.evaluate(doc, XPathConstants.NODESET);
				final int noOfNode = nodeList.getLength();
				for (int j = 0; j < noOfNode; j++) {
					Element elem = (Element) nodeList.item(j);
					doc.renameNode(elem, "", newCustomTag);
					writeInXmlFile(doc, currentDirectoryPath);
				}
			}

		} catch (final Exception e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
		} finally {
			// TODO: handle exception
		}

	}

	/**
	 * This method is to update trade attribute.
	 * 
	 * @param document
	 *            the document
	 * @param currentDirectoryPath
	 */
	public void removeNameSapaceAttribute(final Document document, final String newCustomTag, String currentDirectoryPath) {
		final NodeList newCustomTagList = document.getElementsByTagName(newCustomTag);
		int listOfNode = newCustomTagList.getLength();
		for (int j = 0; j < listOfNode; j++) {
			Node node = newCustomTagList.item(0);
			if (node != null) {
				Element element = (Element) node;
				if (element.getAttributeNode("xmlns") != null) {
					Node n = element.removeAttributeNode(element.getAttributeNode("xmlns"));
					System.out.println(n);
				}
			}
		}
	}

	// ****** Replace Node value *******//
	private void replaceNodeValueInXml(String nodeValueReplace, Document doc, String currentDirectoryPath, String textValue, String xpathValue) {
		final NodeList nodes = doc.getElementsByTagName(nodeValueReplace);
		if (nodes != null) {
			final int nodeCount = nodes.getLength();
			if (nodeCount == 0) {
				nodeNotFoundFileCounter = nodeNotFoundFileCounter + 1;
			}
			for (int nuberOfNodes = 0; nuberOfNodes < nodeCount; nuberOfNodes++) {
				if (nodes.item(nuberOfNodes) instanceof Element) {
					final Element elem = (Element) nodes.item(nuberOfNodes);
					elem.setTextContent(textValue);
					writeInXmlFile(doc, currentDirectoryPath);
				}
			}
		}

		if (!xpathValue.isEmpty() && xpathValue != null) {
			doc.getDocumentElement().normalize();
			XPathFactory xpathFactory = XPathFactory.newInstance();
			// XPath to find empty text nodes.
			String xpath = xpathValue;
			XPathExpression xpathExp;
			try {
				xpathExp = xpathFactory.newXPath().compile(xpath);
				NodeList nodeList = (NodeList) xpathExp.evaluate(doc, XPathConstants.NODESET);
				final int noOfNode = nodeList.getLength();
				for (int j = 0; j < noOfNode; j++) {
					Element elem = (Element) nodeList.item(j);
					elem.setTextContent(textValue);
					writeInXmlFile(doc, currentDirectoryPath);
				}
			} catch (XPathExpressionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}

	public void deleteNodeInXml(String nodeToDelete, Document doc, String currentDirectoryPath, String xpathValue) {
		try {
			final NodeList nodes = doc.getElementsByTagName(nodeToDelete);
			if (nodes != null) {
				final int nodeCount = nodes.getLength();
				if (nodeCount == 0) {
					nodeNotFoundFileCounter = nodeNotFoundFileCounter + 1;
				}
				final int remainingNodeCount = 0;
				for (int nuberOfNodes = 0; nuberOfNodes < nodeCount; nuberOfNodes++) {
					if (nodes.item(remainingNodeCount) instanceof Element) {
						final Node elem = nodes.item(remainingNodeCount);
						elem.getParentNode().removeChild(elem);
						writeInXmlFile(doc, currentDirectoryPath);
					}
				}
			}

			if (!xpathValue.isEmpty() && xpathValue != null) {
				doc.getDocumentElement().normalize();
				XPathFactory xpathFactory = XPathFactory.newInstance();
				// XPath to find empty text nodes.
				String xpath = xpathValue;
				XPathExpression xpathExp;
				try {
					xpathExp = xpathFactory.newXPath().compile(xpath);
					NodeList nodeList = (NodeList) xpathExp.evaluate(doc, XPathConstants.NODESET);
					final int noOfNode = nodeList.getLength();
					for (int j = 0; j < noOfNode; j++) {
						Element elem = (Element) nodeList.item(j);
						elem.getParentNode().removeChild(elem);
						writeInXmlFile(doc, currentDirectoryPath);
					}
				} catch (XPathExpressionException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		} catch (final Exception e) {
			// TODO: handle exception
		} finally {
			// TODO: handle exception
		}
	}

	private void writeInXmlFile(Document doc, String currentDirectoryPath) {
		final TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer = null;
		Source xmlFile = null;
		try {
			transformer = transformerFactory.newTransformer();
		} catch (final TransformerConfigurationException e) {
			System.out.println("Transformer Configuration Exception : " + e.getMessage());
		}
		final DOMSource source = new DOMSource(doc);
		final StreamResult result = new StreamResult(new File(currentDirectoryPath));
		try {
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			transformer.transform(source, result);
			/* remove xmlns declaration */
			URL schemaFile = this.getClass().getClassLoader().getResource("/src/com/jpmorgan/rubi/xml/utils/IBML-1-79-0.xsd");
			xmlFile = new StreamSource(new File(currentDirectoryPath));
			SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
			Schema schema = schemaFactory.newSchema(schemaFile);
			Validator validator = schema.newValidator();
			validator.validate(xmlFile);
			System.out.println(xmlFile.getSystemId() + " is valid");
		} catch (final TransformerException e) {
			System.out.println("Transformer Configuration Exception : " + e.getMessage());
		} catch (SAXException e) {
			String errorFileName = xmlFile.getSystemId();
			errorFileList.add(errorFileName);
			System.out.println(xmlFile.getSystemId() + " is NOT valid");
			System.out.println("Reason: " + e.getLocalizedMessage());
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			infectedFileSize = errorFileList.size();
		}
	}

	/**
	 * @return the errorFileList
	 */
	public List<String> getErrorFileList() {
		return errorFileList;
	}

	/**
	 * @param errorFileList
	 *            the errorFileList to set
	 */
	public void setErrorFileList(List<String> errorFileList) {
		this.errorFileList = errorFileList;
	}

	/**
	 * @return the totalFileCounter
	 */
	public int getTotalFileCounter() {
		return totalFileCounter;
	}

	/**
	 * @param totalFileCounter
	 *            the totalFileCounter to set
	 */
	public void setTotalFileCounter(int totalFileCounter) {
		this.totalFileCounter = totalFileCounter;
	}

	/**
	 * @return the updatedFileCounter
	 */
	public int getUpdatedFileCounter() {
		return updatedFileCounter;
	}

	/**
	 * @param updatedFileCounter
	 *            the updatedFileCounter to set
	 */
	public void setUpdatedFileCounter(int updatedFileCounter) {
		this.updatedFileCounter = updatedFileCounter;
	}

	/**
	 * @return the nodeNotFoundFileCounter
	 */
	public int getNodeNotFoundFileCounter() {
		return nodeNotFoundFileCounter;
	}

	/**
	 * @param nodeNotFoundFileCounter
	 *            the nodeNotFoundFileCounter to set
	 */
	public void setNodeNotFoundFileCounter(int nodeNotFoundFileCounter) {
		this.nodeNotFoundFileCounter = nodeNotFoundFileCounter;
	}

	/**
	 * @return the infectedFileSize
	 */
	public int getInfectedFileSize() {
		return infectedFileSize;
	}

	/**
	 * @param infectedFileSize
	 *            the infectedFileSize to set
	 */
	public void setInfectedFileSize(int infectedFileSize) {
		this.infectedFileSize = infectedFileSize;
	}

	/**
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}

	/**
	 * @param message
	 *            the message to set
	 */
	public void setMessage(String message) {
		RubiXmlCoreController.message = message;
	}

}
