package com.jpmorgan.rubi.xml.utils.util;

import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.TableViewerColumn;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.ui.forms.widgets.Section;

/**
 * @author 285221
 */
public class RubiLimitCommonComponent {
	private RubiLimitCommonComponent() {

	}

	// Create Label
	public static Label createLabel(final Group group, final int width, final String setText, final int horizontalAlignment,
			final int verticalAlignment, final boolean grabExcessHorizontalSpace, final boolean grabExcessVerticalSpace, final int horizontalSpan,
			final int verticalSpan, final Composite body) {
		final Label label = new Label(group, SWT.NONE);
		label.setBackground(body.getBackground());
		final GridData labelGD =
				new GridData(horizontalAlignment, verticalAlignment, grabExcessHorizontalSpace, grabExcessVerticalSpace, horizontalSpan, verticalSpan);
		labelGD.widthHint = width;
		label.setLayoutData(labelGD);
		label.setText(setText);
		return label;
	}

	// Create Button
	public static Button createButton(final Composite composite, final Group group, final String buttonName, final int width,
			final int horizontalAlignment, final int verticalAlignment, final boolean grabExcessHorizontalSpace,
			final boolean grabExcessVerticalSpace, final int horizontalSpan, final int verticalSpan, final int buttonStyle,
			final FormToolkit formToolkit) {
		final Button button;
		if (composite == null) {
			button = formToolkit.createButton(group, buttonName, buttonStyle);
		} else {
			button = formToolkit.createButton(composite, buttonName, buttonStyle);
		}
		final GridData buttonGD =
				new GridData(horizontalAlignment, verticalAlignment, grabExcessHorizontalSpace, grabExcessVerticalSpace, horizontalSpan, verticalSpan);
		buttonGD.widthHint = width;
		button.setLayoutData(buttonGD);
		return button;
	}

	// Create Tabel
	public static Table createTable(final Group group, final String[] tableHeader, final int[] tableBounds, final boolean setHeaderVisible,
			final boolean setLinesVisible, final int width, final int height, final int tableStyle, final int tableViewerStyle,
			final boolean columnMovable, final boolean columnResizeable, final int horizontalAlignment, final int verticalAlignment,
			final boolean grabExcessHorizontalSpace, final boolean grabExcessVerticalSpace, final int horizontalSpan, final int verticalSpan,
			final Font boldFont) {
		final TableViewer tableViewer = new TableViewer(group, SWT.SINGLE | SWT.FULL_SELECTION | SWT.H_SCROLL | SWT.V_SCROLL);
		final String[] header = tableHeader;
		final int[] bounds = tableBounds;
		final int length = header.length;
		for (int i = 0; i < length; i++) {
			final TableViewerColumn column = new TableViewerColumn(tableViewer, tableViewerStyle);
			column.getColumn().setText(header[i]);
			column.getColumn().setWidth(bounds[i]);
			column.getColumn().setMoveable(columnMovable);
			column.getColumn().setResizable(columnResizeable);
		}

		final Table table = tableViewer.getTable();

		final GridData tableGD =
				new GridData(horizontalAlignment, verticalAlignment, grabExcessHorizontalSpace, grabExcessVerticalSpace, horizontalSpan, verticalSpan);
		tableGD.widthHint = width;
		tableGD.heightHint = height;

		table.setLayoutData(tableGD);
		table.setHeaderVisible(setHeaderVisible);
		table.setLinesVisible(setLinesVisible);

		final TableItem item = new TableItem(table, tableStyle);
		item.setText(header);
		item.setGrayed(true);
		item.setFont(boldFont);
		return table;
	}

	// Create Group Function
	public static Group createGroup(final int noOfColumns, final String textGroup, final int width, final int hieght, final boolean setVisibility,
			final Composite body, final int groupStyle, final FormToolkit formToolkit) {
		final Group group = new Group(body, groupStyle);

		final GridLayout groupLayout = new GridLayout();
		groupLayout.numColumns = noOfColumns;
		group.setLayout(groupLayout);
		group.setText(textGroup);

		final GridData groupGD = new GridData(width, hieght);
		group.setLayoutData(groupGD);

		group.setVisible(setVisibility);
		formToolkit.adapt(group);
		return group;
	}

	// Create Group Function for Section
	public static Group createGroupInSection(final int noOfColumns, final String textGroup, final int width, final int height, final Section section,
			final int groupSectionStyle, final boolean setVisibility, final FormToolkit formToolkit) {
		final Group sectionGroup = new Group(section, groupSectionStyle);

		final GridLayout sectionGroupLayout = new GridLayout();
		sectionGroupLayout.numColumns = noOfColumns;
		sectionGroup.setLayout(sectionGroupLayout);

		section.setClient(sectionGroup); // Set Group into section

		final GridData scenarioSummaryGroupGD = new GridData(width, height);
		sectionGroup.setLayoutData(scenarioSummaryGroupGD);

		sectionGroup.setVisible(setVisibility);
		formToolkit.adapt(sectionGroup);
		return sectionGroup;
	}

	// Create Composite
	public static Composite createComposite(final Composite body, final Group group, final int noOFColumns, final boolean columnsWidth,
			final int width, final int height, final boolean setVisibility, final int compositeStyle) {
		final Composite composite = new Composite(body, compositeStyle);
		final GridLayout compositeLayout = new GridLayout(noOFColumns, columnsWidth);
		composite.setLayout(compositeLayout);
		final GridData compositeGD = new GridData(width, height);
		composite.setLayoutData(compositeGD);
		composite.setBackground(body.getBackground());

		composite.setVisible(setVisibility);
		return composite;
	}

	public static final Combo createCombo(final Group group, final int comboStyle, final int horizontalAlignment, final int verticalAlignment,
			final boolean grabExcessHorizontalSpace, final boolean grabExcessVerticalSpace, final int horizontalSpan, final int verticalSpan,
			final boolean setVisibility, final Composite body, final int width, final int hieght) {
		final Combo combo;
		if (body == null) {
			combo = new Combo(group, comboStyle);
		} else {
			combo = new Combo(body, comboStyle);
		}
		final GridData comboGD =
				new GridData(horizontalAlignment, verticalAlignment, grabExcessHorizontalSpace, grabExcessVerticalSpace, horizontalSpan, verticalSpan);
		comboGD.heightHint = hieght;
		comboGD.widthHint = width;
		combo.setLayoutData(comboGD);
		return combo;
	}

	public static final Text createTextBox(final FormToolkit formToolkit, final Group group, final String textName, final int style, final int width,
			final int horizontalAlignment, final int verticalAlignment, final boolean grabExcessHorizontalSpace,
			final boolean grabExcessVerticalSpace, final int horizontalSpan, final int verticalSpan) {
		final Text text = formToolkit.createText(group, textName, style);
		final GridData textGD =
				new GridData(horizontalAlignment, verticalAlignment, grabExcessHorizontalSpace, grabExcessVerticalSpace, horizontalSpan, verticalSpan);
		textGD.widthHint = width;
		text.setLayoutData(textGD);
		return text;
	}

	public static Section createSection(final String setSectionName, final int width, final int height, final FormToolkit formToolkit,
			final Composite body, final int style, final Font boldFont, final boolean setVisibility, final boolean setExpansion) {
		final Section section = formToolkit.createSection(body, style);
		section.setText(setSectionName);
		section.setFont(boldFont);
		section.setExpanded(setExpansion);
		section.setVisible(setVisibility);
		final GridData sectionGD = new GridData(width, height);
		section.setLayoutData(sectionGD);
		return section;
	}
}
