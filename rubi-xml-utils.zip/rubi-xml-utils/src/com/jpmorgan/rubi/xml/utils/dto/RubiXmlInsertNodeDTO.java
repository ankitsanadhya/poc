package com.jpmorgan.rubi.xml.utils.dto;

import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;

public class RubiXmlInsertNodeDTO {

	private Label inputDirLabel;
	private Label rootNodeLabel;
	private Label newNodeNameLebel;
	private Label nodeValueLabel;
	private Label attributeNameLabel;
	private Label attributeValueLabel;
	private Label insertBeforeNodeLabel;
	private Label xpathLabel;
	private Label totalNumberOfXml;
	private Label noOfUpdatedFile;
	private Label nodeNotFoundNo;
	private Label noOfScemaValidationFailed;

	private Text inputDirText;
	private Text rootNodeText;
	private Text newNodeNameText;
	private Text nodeValueText;
	private Text attributeNameText;
	private Text attributeValueText;
	private Text insertBeforeNodeText;
	private Text xpathText;
	private Text totalNumberOfXmlText;
	private Text noOfUpdatedFileText;
	private Text nodeNotFoundNoText;
	private Text noOfScemaValidationFailedText;

	private Button insertButton;

	/**
	 * @return the inputDirLabel
	 */
	public Label getInputDirLabel() {
		return inputDirLabel;
	}

	/**
	 * @param inputDirLabel
	 *            the inputDirLabel to set
	 */
	public void setInputDirLabel(Label inputDirLabel) {
		this.inputDirLabel = inputDirLabel;
	}

	/**
	 * @return the rootNodeLabel
	 */
	public Label getRootNodeLabel() {
		return rootNodeLabel;
	}

	/**
	 * @param rootNodeLabel
	 *            the rootNodeLabel to set
	 */
	public void setRootNodeLabel(Label rootNodeLabel) {
		this.rootNodeLabel = rootNodeLabel;
	}

	/**
	 * @return the newNodeNameLebel
	 */
	public Label getNewNodeNameLebel() {
		return newNodeNameLebel;
	}

	/**
	 * @param newNodeNameLebel
	 *            the newNodeNameLebel to set
	 */
	public void setNewNodeNameLebel(Label newNodeNameLebel) {
		this.newNodeNameLebel = newNodeNameLebel;
	}

	/**
	 * @return the nodeValueLabel
	 */
	public Label getNodeValueLabel() {
		return nodeValueLabel;
	}

	/**
	 * @param nodeValueLabel
	 *            the nodeValueLabel to set
	 */
	public void setNodeValueLabel(Label nodeValueLabel) {
		this.nodeValueLabel = nodeValueLabel;
	}

	/**
	 * @return the attributeNameLabel
	 */
	public Label getAttributeNameLabel() {
		return attributeNameLabel;
	}

	/**
	 * @param attributeNameLabel
	 *            the attributeNameLabel to set
	 */
	public void setAttributeNameLabel(Label attributeNameLabel) {
		this.attributeNameLabel = attributeNameLabel;
	}

	/**
	 * @return the attributeValueLabel
	 */
	public Label getAttributeValueLabel() {
		return attributeValueLabel;
	}

	/**
	 * @param attributeValueLabel
	 *            the attributeValueLabel to set
	 */
	public void setAttributeValueLabel(Label attributeValueLabel) {
		this.attributeValueLabel = attributeValueLabel;
	}

	/**
	 * @return the insertBeforeNodeLabel
	 */
	public Label getInsertBeforeNodeLabel() {
		return insertBeforeNodeLabel;
	}

	/**
	 * @param insertBeforeNodeLabel
	 *            the insertBeforeNodeLabel to set
	 */
	public void setInsertBeforeNodeLabel(Label insertBeforeNodeLabel) {
		this.insertBeforeNodeLabel = insertBeforeNodeLabel;
	}

	/**
	 * @return the xpathLabel
	 */
	public Label getXpathLabel() {
		return xpathLabel;
	}

	/**
	 * @param xpathLabel
	 *            the xpathLabel to set
	 */
	public void setXpathLabel(Label xpathLabel) {
		this.xpathLabel = xpathLabel;
	}

	/**
	 * @return the inputDirText
	 */
	public Text getInputDirText() {
		return inputDirText;
	}

	/**
	 * @param inputDirText
	 *            the inputDirText to set
	 */
	public void setInputDirText(Text inputDirText) {
		this.inputDirText = inputDirText;
	}

	/**
	 * @return the rootNodeText
	 */
	public Text getRootNodeText() {
		return rootNodeText;
	}

	/**
	 * @param rootNodeText
	 *            the rootNodeText to set
	 */
	public void setRootNodeText(Text rootNodeText) {
		this.rootNodeText = rootNodeText;
	}

	/**
	 * @return the newNodeNameText
	 */
	public Text getNewNodeNameText() {
		return newNodeNameText;
	}

	/**
	 * @param newNodeNameText
	 *            the newNodeNameText to set
	 */
	public void setNewNodeNameText(Text newNodeNameText) {
		this.newNodeNameText = newNodeNameText;
	}

	/**
	 * @return the nodeValueText
	 */
	public Text getNodeValueText() {
		return nodeValueText;
	}

	/**
	 * @param nodeValueText
	 *            the nodeValueText to set
	 */
	public void setNodeValueText(Text nodeValueText) {
		this.nodeValueText = nodeValueText;
	}

	/**
	 * @return the attributeNameText
	 */
	public Text getAttributeNameText() {
		return attributeNameText;
	}

	/**
	 * @param attributeNameText
	 *            the attributeNameText to set
	 */
	public void setAttributeNameText(Text attributeNameText) {
		this.attributeNameText = attributeNameText;
	}

	/**
	 * @return the attributeValueText
	 */
	public Text getAttributeValueText() {
		return attributeValueText;
	}

	/**
	 * @param attributeValueText
	 *            the attributeValueText to set
	 */
	public void setAttributeValueText(Text attributeValueText) {
		this.attributeValueText = attributeValueText;
	}

	/**
	 * @return the insertBeforeNodeText
	 */
	public Text getInsertBeforeNodeText() {
		return insertBeforeNodeText;
	}

	/**
	 * @param insertBeforeNodeText
	 *            the insertBeforeNodeText to set
	 */
	public void setInsertBeforeNodeText(Text insertBeforeNodeText) {
		this.insertBeforeNodeText = insertBeforeNodeText;
	}

	/**
	 * @return the xpathText
	 */
	public Text getXpathText() {
		return xpathText;
	}

	/**
	 * @param xpathText
	 *            the xpathText to set
	 */
	public void setXpathText(Text xpathText) {
		this.xpathText = xpathText;
	}

	/**
	 * @return the insertButton
	 */
	public Button getInsertButton() {
		return insertButton;
	}

	/**
	 * @param insertButton
	 *            the insertButton to set
	 */
	public void setInsertButton(Button insertButton) {
		this.insertButton = insertButton;
	}

	/**
	 * @return the totalNumberOfXml
	 */
	public Label getTotalNumberOfXml() {
		return totalNumberOfXml;
	}

	/**
	 * @param totalNumberOfXml
	 *            the totalNumberOfXml to set
	 */
	public void setTotalNumberOfXml(Label totalNumberOfXml) {
		this.totalNumberOfXml = totalNumberOfXml;
	}

	/**
	 * @return the noOfUpdatedFile
	 */
	public Label getNoOfUpdatedFile() {
		return noOfUpdatedFile;
	}

	/**
	 * @param noOfUpdatedFile
	 *            the noOfUpdatedFile to set
	 */
	public void setNoOfUpdatedFile(Label noOfUpdatedFile) {
		this.noOfUpdatedFile = noOfUpdatedFile;
	}

	/**
	 * @return the nodeNotFoundNo
	 */
	public Label getNodeNotFoundNo() {
		return nodeNotFoundNo;
	}

	/**
	 * @param nodeNotFoundNo
	 *            the nodeNotFoundNo to set
	 */
	public void setNodeNotFoundNo(Label nodeNotFoundNo) {
		this.nodeNotFoundNo = nodeNotFoundNo;
	}

	/**
	 * @return the noOfScemaValidationFailed
	 */
	public Label getNoOfScemaValidationFailed() {
		return noOfScemaValidationFailed;
	}

	/**
	 * @param noOfScemaValidationFailed
	 *            the noOfScemaValidationFailed to set
	 */
	public void setNoOfScemaValidationFailed(Label noOfScemaValidationFailed) {
		this.noOfScemaValidationFailed = noOfScemaValidationFailed;
	}

	/**
	 * @return the totalNumberOfXmlText
	 */
	public Text getTotalNumberOfXmlText() {
		return totalNumberOfXmlText;
	}

	/**
	 * @param totalNumberOfXmlText
	 *            the totalNumberOfXmlText to set
	 */
	public void setTotalNumberOfXmlText(Text totalNumberOfXmlText) {
		this.totalNumberOfXmlText = totalNumberOfXmlText;
	}

	/**
	 * @return the noOfUpdatedFileText
	 */
	public Text getNoOfUpdatedFileText() {
		return noOfUpdatedFileText;
	}

	/**
	 * @param noOfUpdatedFileText
	 *            the noOfUpdatedFileText to set
	 */
	public void setNoOfUpdatedFileText(Text noOfUpdatedFileText) {
		this.noOfUpdatedFileText = noOfUpdatedFileText;
	}

	/**
	 * @return the nodeNotFoundNoText
	 */
	public Text getNodeNotFoundNoText() {
		return nodeNotFoundNoText;
	}

	/**
	 * @param nodeNotFoundNoText
	 *            the nodeNotFoundNoText to set
	 */
	public void setNodeNotFoundNoText(Text nodeNotFoundNoText) {
		this.nodeNotFoundNoText = nodeNotFoundNoText;
	}

	/**
	 * @return the noOfScemaValidationFailedText
	 */
	public Text getNoOfScemaValidationFailedText() {
		return noOfScemaValidationFailedText;
	}

	/**
	 * @param noOfScemaValidationFailedText
	 *            the noOfScemaValidationFailedText to set
	 */
	public void setNoOfScemaValidationFailedText(Text noOfScemaValidationFailedText) {
		this.noOfScemaValidationFailedText = noOfScemaValidationFailedText;
	}

}
