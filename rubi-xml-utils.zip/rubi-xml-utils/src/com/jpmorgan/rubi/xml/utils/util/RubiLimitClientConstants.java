package com.jpmorgan.rubi.xml.utils.util;

/**
 * This class defines the constants.
 * 
 * @author r329686
 */
public class RubiLimitClientConstants {

    /** The Constant SAVE_SUCCESSFUL_MESSAGE. */
    public static final String SAVE_SUCCESSFUL_MESSAGE = "Limit Saved Successfully";

    /** The Constant THRESHOLD_SAVE_SUCCESSFUL_MESSAGE. */
    public static final String THRESHOLD_SAVE_SUCCESSFUL_MESSAGE = "Threshold Saved Successfully";

    /** The Constant DELETE_SUCCESSFUL_MESSAGE. */
    public static final String DELETE_SUCCESSFUL_MESSAGE = "Limit Deleted Successfully";

    /** The Constant SEARCHTEXT_ERROR_MESSAGE. */
    public static final String SEARCHTEXT_ERROR_MESSAGE = "Please enter search criteria";

    /** The Constant SEARCHTEXT_NUMERIC_ERROR_MESSAGE. */
    public static final String SEARCHTEXT_NUMERIC_ERROR_MESSAGE = "Please enter a numeric value when searching by SPN";

    /** The Constant SEARCHTEXT_CHARACTER_ERROR_MESSAGE. */
    public static final String SEARCHTEXT_CHARACTER_ERROR_MESSAGE = "Please enter an alphanumeric value when searching by counterparty name";

    public static final String SEARCHTEXT_CHARACTER_LEGAL_ENTITY_ERROR_MESSAGE = "Please enter an alphanumeric value when searching by Legal Entity Hierarchy name";

    /** The Constant NO_RECORDS_FOUND. */
    public static final String NO_RECORDS_FOUND = "No counterparties found";

    /** The Constant NO_ACTIVE_SCENARIO_FOUND. */
    public static final String NO_ACTIVE_SCENARIO_FOUND = "No Active Scenarios found for this Counterparty";

    /** The Constant TABLE_ROW_SELECTION_ERROR_MESSAGE. */
    public static final String TABLE_ROW_SELECTION_ERROR_MESSAGE = "Please select a counterparty from the results set";

    /** The Constant PAST_RECORD_EDIT_ERROR_MESSAGE. */
    public static final String PAST_RECORD_EDIT_ERROR_MESSAGE = "You cannot edit the past/effective date limit. If you need to change the limit with effect from today, Please click 'Add New Limit For Selected SPN";

    /** The Constant ALL_SPECIAL_CHARS. */
    public static final String ALL_SPECIAL_CHARS = "[!@#$%'^&*()~'<>/?;:|{}+=`*]*";

    public static final String SPECIAL_CHARS_FOR_SEARCH = "[!@#$'^&*()~'<>/?;:|{}+=`*-]*";

    public static final String SPECIAL_CHARS_FOR_SEARCH_BY_NAME = "[A-Za-z0-9!@#$'^&*()~'<>/?;:|{}+=`*-]*";

    public static final String ALPHANUMERIC_REG_EX = "[0-9A-Za-z]+";

    public static final String LCH_TRADE_ID_REG_EX = "LCH[0-9]+";

    public static final String FCM_TRADE_ID_REG_EX = "FCM[0-9]+";

    /** The Constant DATE_FORMAT. */
    public static final String DATE_FORMAT = "dd/MM/yyyy";

    /** The Constant DATE_FORMAT_YYYYMMDDHHMMSS. */
    public static final String DATE_FORMAT_YYYYMMDDHHMMSS = "yyyy-MM-dd hh:mm:ss";

    /** The Constant DATE_FORMAT_MMDDYY. */
    public static final String DATE_FORMAT_YYYYMMDD = "yyyy-MM-dd";

    public static final String DATE_FORMAT_DDMMYYYY_HHMMSS = "dd/MM/yyyy   HH:mm:ss";

    /** The Constant DELETE_ERROR_MESSAGE. */
    public static final String DELETE_ERROR_MESSAGE = "You cannot delete active limit setup";

    /** The Constant DATE_MIN_FORMAT. */
    public static final String DATE_MIN_FORMAT = "dd:hh:mm:ss/MM/yyyy";

    /** The Constant NUMBER_PATTERN. */
    public static final String NUMBER_PATTERN = "[0-9]*";

    /** The Constant LIMIT_VALUE_PATTERN. */
    public static final String LIMIT_VALUE_PATTERN = "(\\d{1,19}(\\.\\d{1,14})?$)";

    /** The Constant EDIT_RECORD_ERROR. */
    public static final String EDIT_RECORD_ERROR = "You cannot edit limit with effective date prior to today. If you need to change the limit with effect from today, please click 'Add New Limit for selected SPN'.";

    /** The Constant EDIT_NON_EXISTING_RECORD_ERROR. */
    public static final String EDIT_NON_EXISTING_RECORD_ERROR = "No limit set for this counterparty. If you need to change the limit with effect from today, please click 'Add New Limit for selected SPN'.";

    public static final String CD_EDIT_NON_EXISTING_RECORD_ERROR = "No limit set for this counterparty. If you need to change the limit with effect from today, please click 'Add New Limit'.";

    public static final String EDIT_NON_EXISTING_RECORD_LE_ERROR = "No limit set for this Legal Entity Hierarchy. If you need to change the limit with effect from today, please click 'Add New Limit'.";

    public static final String VIEW_NON_EXISTING_RECORD_ERROR = "No limit set for this counterparty";

    public static final String NON_EXISTING_RECORD_LE_ERROR = "No limit set for this Legal Entity Hierarchy";

    /** The Constant NON_EXISTING_RECORD_DELETE_ERROR. */
    public static final String NON_EXISTING_RECORD_DELETE_ERROR = "No limit set for this counterparty";

    /** The Constant PAST_DATE_ADD_ERROR. */
    public static final String PAST_DATE_ADD_ERROR = "Limit cannot be set for date in past";

    /** The Constant VIEW_TITLE. */
    public static final String VIEW_TITLE = "Limit Utilisation Intra-Day at Trade Level";

    /** The Constant SEARCH_LEVEL. */
    public static final String SEARCH_LEVEL = "Search Counter Party";

    /** The Constant ERROR_LABEL. */
    public static final String ERROR_LABEL = "Error";

    /** The Constant NUMERIC_VALUE_ERROR. */
    public static final String NUMERIC_VALUE_ERROR = "Please enter numeric value for SPN";

    /** The Constant NON_STP_BPV_LIMIT_SETUP. */
    public static final String NON_STP_BPV_LIMIT_SETUP = "Limit Utilisation Adjustment";

    /** The Constant CCY_TENOR_LEVEL_REPORT. */
    public static final String CCY_TENOR_LEVEL_REPORT = "Currency and Tenor Level Report";

    /** The Constant TRADE_LEVEL_REPORT. */
    public static final String TRADE_LEVEL_REPORT = "Trade Level Report";

    /** The Constant UTILISATION_AT_COUNTERPARTY_LEVEL_REPORT. */
    public static final String UTILISATION_AT_COUNTERPARTY_LEVEL_REPORT = "Utilisation at Counterparty Level Report";

    /** The Constant HISTORICAL_REPORTING. */
    public static final String HISTORICAL_REPORTING = "Historical Reporting";

    /** The Constant HISTORICAL. */
    public static final String HISTORICAL = "Historical";

    /** The Constant INTRADAY. */
    public static final String INTRADAY = "Intraday";

    /** The Constant INTRADAY_TRADE_LEVEL_REPORT. */
    public static final String INTRADAY_TRADE_LEVEL_REPORT = "Trade Level Report";

    /** The Constant LIMIT_SETUP_MAIN_MENU. */
    public static final String LIMIT_SETUP_MAIN_MENU = "Limits Setup";

    /** The Constant REPORT_MAIN_MENU. */
    public static final String REPORT_MAIN_MENU = "Limits Reports";

    /** The Constant MAV_BPV_LIMIT_SETUP. */
    public static final String MAV_BPV_LIMIT_SETUP = "Limit Maintenance";

    /** The Constant LIMITSETUP_ID. */
    public static final String LIMITSETUP_ID = "com.jpmorgan.rubi.limit.view.SetUpBPVLimitView";

    /** The Constant LIMITSETUP_HEADER. */
    public static final String LIMITSETUP_HEADER = "Limit Maintenance";

    /** The Constant THRESHOLD_HEADER. */
    public static final String THRESHOLD_HEADER = "Utilisation Warning Threshold";

    /** The Constant LIMITSETUP_SEARCH_HEADER. */
    public static final String LIMITSETUP_SEARCH_HEADER = "Counterparty Search";

    /** The Constant LIMITSETUP_SEARCH_HEADER. */
    public static final String THRESHOLD_MAIN_HEADER = "Threshold Maintenance";

    /** The Constant TABLE_TITLE. */
    public static final String[] TABLE_TITLE = { "Counterparty Name", "SPN",
	    "Counterparty Type", "Linked Party", "Linked SPN", "Scenario",
	    "Calc Method", "Limit Value (USD)", "Effective Date (dd/mm/yyyy)" };

    /** The Constant ADD_BUTTON_NAME. */
    public static final String ADD_BUTTON_NAME = "Add New Limit for Selected SPN";

    /** The Constant EDIT_BUTTON_NAME. */
    public static final String EDIT_BUTTON_NAME = "Edit Selected Limit";

    /** The Constant DELETE_BUTTON_NAME. */
    public static final String DELETE_BUTTON_NAME = "Delete Selected Limit";

    /** The Constant SAVE_BUTTON_NAME. */
    public static final String SAVE_BUTTON_NAME = "Save Limit";

    /** The Constant CANCEL_BUTTON_NAME. */
    public static final String CANCEL_BUTTON_NAME = "Cancel";

    /** The Constant REQUIRED_FIELD_ERROR. */
    public static final String REQUIRED_FIELD_ERROR = "Mandatory fields cannot be empty";

    /** The Constant EQD_LIMIT_VALUE_ERROR. */
    public static final String EQD_LIMIT_VALUE_ERROR = "Limit must be a positive whole number";

    // Added one more variable for # GRSTM-9483
    /** Constant for Threshold screen. */
    public static final String REQUIRED_FIELD_ERROR_THRESHOLD = "Please enter value for Threshold";

    /** The Constant EXISTING_RECORD_ERROR. */
    public static final String EXISTING_RECORD_ERROR = "Limit already exists for the counterparty for this effective date. If you need to change the limit with effect from this date, please click 'Edit Selected Limit'";

    /** The Constant LIMIT_VALUE_ERROR. */
    public static final String LIMIT_VALUE_ERROR = "Please enter numeric value for BPV limit";

    // Changes for Defect # GRSTM-9483
    /** The Constant THRESHOLD_VALUE_ERROR. */
    public static final String THRESHOLD_VALUE_ERROR = "Please enter numeric value for Threshold, and should be between 1 - 100.";

    /** The Constant DELETE_MESSAGE. */
    public static final String DELETE_MESSAGE = "The Limit selected is being used for today's Limit Utilisation calculation. Are you sure you wish to delete this Limit?";

    /** The Constant ACTIVE_FLAG. */
    public static final String ACTIVE_FLAG = "Y";

    /** The Constant CREATED_BY. */
    public static final String CREATED_BY = "SYSTEM";

    /** The Constant MODIFIED_BY. */
    public static final String MODIFIED_BY = "SYSTEM";

    /** The Constant CURVE_VALUE. */
    public static final String CURVE_VALUE = "CURVE";

    /** The Constant DIRECTIONAL_VALUE. */
    public static final String DIRECTIONAL_VALUE = "DIRECTIONAL";

    /** The Constant BPV_CURVE_VALUE. */
    public static final String BPV_CURVE_VALUE = "BPV - Curve";

    /** The Constant BPV_DIRECTIONAL_VALUE. */
    public static final String BPV_DIRECTIONAL_VALUE = "BPV - Directional";

    /** The Constant LIMIT_SERVICE_HTTP_INVOKER. */
    public static final String LIMIT_SERVICE_HTTP_INVOKER = "limitServiceHttpInvoker";

    /** The Constant LIMIT_ENTITLEMENT_SERVICE_HTTP_INVOKER. */
    public static final String LIMIT_ENTITLEMENT_SERVICE_HTTP_INVOKER = "limitEntitlementServiceHttpInvoker";

    /** The Constant SYSTEM. */
    public static final String SYSTEM = "SYSTEM";

    /** The Constant YES_FLAG. */
    public static final String YES_FLAG = "Y";

    /** The Constant EMPTY_STRING. */
    public static final String EMPTY_STRING = "";

    /** The Constant INDEX_ZERO. */
    public static final int INDEX_ZERO = 0;

    /** The Constant INDEX_ONE. */
    public static final int INDEX_ONE = 1;

    /** The Constant SEARCH_LABEL. */
    public static final String SEARCH_LABEL = "Search for Counterparty";

    /** The Constant ENTER_THRESHOLD_LABEL. */
    public static final String ENTER_THRESHOLD_LABEL = "Enter Threshold Value";

    /** The Constant SEARCH_COMBOBOX_VALUE. */
    public static final String[] SEARCH_COMBOBOX_VALUE = { "Name", "SPN" };

    /** The Constant SEARCH_BUTTON_NAME. */
    public static final String SEARCH_BUTTON_NAME = "Search";

    /** The Constant COUNTERPARTY_DETAIL_LABEL. */
    public static final String COUNTERPARTY_DETAIL_LABEL = "Counterparty Details **";

    /** The Constant COUNTERPARTY_DETAIL_LABEL. */
    public static final String LIMIT_CURRENCY_LABEL = "Limit Currency*";

    /** The Constant DIRECTION_LABEL. */
    public static final String DIRECTION_LABEL = "Direction*";

    /** The Constant SCENARIO_LABEL. */
    public static final String SCENARIO_LABEL = "Scenario*";

    /** The Constant ADD_EDIT_LABEL. */
    public static final String ADD_EDIT_LABEL = "Add/Edit Limit Setup";

    /** The Constant SPN_LABEL. */
    public static final String SPN_LABEL = "SPN";

    /** The Constant COUNTERPARTY_NAME_LABEL. */
    public static final String COUNTERPARTY_NAME_LABEL = "Counterparty Name";

    /** The Constant COUNTERPARTY_TYPE_LABEL. */
    public static final String COUNTERPARTY_TYPE_LABEL = "Counterparty Type";

    public static final String LEGAL_ENTITY_HIERARCHY_LABEL = "Legal Entity Hierarchy";

    /** The Constant LEGAL_ENTITY. */
    public static final String LEGAL_ENTITY = "Legal Entity";

    /** The Constant LIMIT_TYPE_LABEL. */
    public static final String LIMIT_TYPE_LABEL = "Limit Type*";

    /** The Constant LIMIT_TYPE_COMBO. */
    public static final String[] LIMIT_TYPE_COMBO = { "--Select", "BPV-CURVE",
	    "BPV-DIRECTIONAL" };

    /** The Constant LIMIT_VALUE_LABEL. */
    public static final String LIMIT_VALUE_LABEL = "Limit Value (USD)*";

    /** The Constant EFFECTIVE_DATE_LABEL. */
    public static final String EFFECTIVE_DATE_LABEL = "Effective Date (dd/mm/yyyy)*";

    public static final String TRADE_EFFECTIVE_DATE_LABEL = "Trade Effective Date (dd/MM/yyyy)*";

    /** The Constant ALPHANUMERIC_WS. */
    public static final String ALPHANUMERIC_WS = "[A-Za-z0-9@\"#\'&$|%\\*(),_./-[ \t\n\r]*]*";

    /** The Constant ALPHANUMERIC_SINGLESPACE. */
    public static final String ALPHANUMERIC_SINGLESPACE = "[A-Za-z0-9]+( [A-Za-z0-9]*)*";

    /** The Constant ZERO_STRING. */
    public static final String ZERO_STRING = "0";

    /** The Constant INFORMATION_LABEL. */
    public static final String INFORMATION_LABEL = "Information";

    /** The Constant LIMIT_ADJUSTMENT. */
    public static final String LIMIT_ADJUSTMENT = "Limit Adjustment";

    /** The Constant Notional LIMIT_ADJUSTMENT. */
    public static final String NOTIONAL_LIMIT_ADJUSTMENT = "Notional Limit Adjustment";

    /** The Constant BPV LIMIT_ADJUSTMENT. */
    public static final String BPV_LIMIT_ADJUSTMENT = "BPV Limit Adjustment";

    /** The Constant CURRENCY. */
    public static final String CURRENCY = "Currency";

    /** The Constant CURRENCY. */
    public static final String REGION = "Region";

    /** The Constant EMPTY_ERROR. */
    public static final String EMPTY_ERROR = "Search text cannot be empty";

    /** The Constant CCY_ADD_ERROR. */
    public static final String CCY_ADD_ERROR = "Please select currency to add";

    /** The Constant SCENARIO_ADD_ERROR. */
    public static final String SCENARIO_ADD_ERROR = "Please select scenario to add";

    /** The Constant REGION_ADD_ERROR. */
    public static final String REGION_ADD_ERROR = "Please select region to add";

    /** The Constant CCY_SCENARIO_ADD_ERROR. */
    public static final String CCY_SCENARIO_ADD_ERROR = "Please select currency, scenario and region to add";

    /** The Constant TEN_YEAR_TENOR_BUCKET. */
    public static final String TEN_YEAR_TENOR_BUCKET = "10-20y";

    // Constants for UC 10
    /** The Constant INSTRUCTION_LINE. */
    public static final String INSTRUCTION_LINE = " Select Currency and Region to add rows, then enter BPV (USD) for each tenor bucket";

    /** The Constant INSTRUCTION_LINE. */
    public static final String INSTRUCTION_LINE_NOTIONAL = " Select Product, JPM Position, EMC/DMC and Currency to add rows, then enter Notional(USD) for tenor buckets.";

    /** The Constant DELETE_CONFIRM_MESSAGE. */
    public static final String DELETE_CONFIRM_MESSAGE = "Are you sure you want to delete selected limit?";

    /** The Constant LIMIT_EDIT_MESSAGE. */
    public static final String LIMIT_EDIT_MESSAGE = "You cannot edit effective limit";

    /** The Constant REPORT_TABLE_HEADERS. */
    public static final String[] REPORT_TABLE_HEADERS = { "Counterparty Name",
	    "SPN", "Counterparty Type" };

    /** The Constant REPORT_HEADER. */
    public static final String REPORT_HEADER = "Trade Level Report";

    /** The Constant EXPORT_BUTTON. */
    public static final String EXPORT_BUTTON = "Export";

    /** The Constant COUNTERPARTY_LABEL. */
    public static final String COUNTERPARTY_LABEL = "Counterparty:";

    /** The Constant DIRECTIONAL_LIMIT. */
    public static final String DIRECTIONAL_LIMIT = "Directional Limit: ";

    /** The Constant SOD_DIRECTIONAL_BPV. */
    public static final String SOD_DIRECTIONAL_BPV = "Start of Day Directional BPV :";

    /** The Constant SOD_CURVE_BPV. */
    public static final String SOD_CURVE_BPV = "Start of Day Curve BPV :";

    /** The Constant CUREVE_LIMIT. */
    public static final String CUREVE_LIMIT = "Curve Limit: ";

    /** The Constant OBTAINED_DATE. */
    public static final String OBTAINED_DATE = "Obtained (dd/mm/yyyy) : ";

    /** The Constant ERROR_LEVEL. */
    public static final String ERROR_LEVEL = "Error ";

    /** The Constant REPORT_TABLE_TITLE_BPV. */
    public static final String[] REPORT_TABLE_TITLE_BPV = { "External ID",
	    "Trade Action", "Trade Type", "Product", "Notional", "Currency",
	    "BPV (Trade Currency)", "FX Rate", "BPV (USD)",
	    "FX Rates Obtained  " };
    /** The Constant REPORT_TABLE_TITLE_BPV_SCENARIO. */
    public static final String[] REPORT_TABLE_TITLE_BPV_SCENARIO = {
	    "External ID", "SPN", "Trade Action", "Trade Type", "Product",
	    "Notional", "Currency", "BPV (Trade Currency)", "FX Rate",
	    "BPV (USD)", "FX Rates Obtained  " };

    /** The Constant REPORT_TABLE_TITLE_NOTIONAL_SCENARIO. */
    public static final String[] REPORT_TABLE_TITLE_NOTIONAL_SCENARIO = {
	    "External ID", "SPN", "Trade Action", "Trade Type", "Product",
	    "Currency", "Tenor", "Notional", "FX Rate", "Notional (USD)",
	    " Netted Notional (USD)", "FX Rates Obtained  " };

    /** The Constant REPORT_TABLE_TITLE_NOTIONAL. */
    public static final String[] REPORT_TABLE_TITLE_NOTIONAL = { "External ID",
	    "Trade Action", "Trade Type", "Product", "Tenor", "Notional",
	    "Currency", "FX Rate", "Notional (USD)", "FX Rates Obtained  " };

    /** The Constant ADJUSTMENT_SUCCESS_MSG. */
    public static final String ADJUSTMENT_SUCCESS_MSG = "Limit Adjustment saved successfully";

    // Constants for UC 5

    /** The Constant CCY_TRNOR_REPORT_SCREEN_TEXT. */
    public static final String CCY_TRNOR_REPORT_SCREEN_TEXT = "Limit Utilisation Intra-Day at Currency and Tenor Level";

    /** The Constant CP_SEARCH_GROUP_TEXT. */
    public static final String CP_SEARCH_GROUP_TEXT = "Counterparty Search";

    /** The Constant CP_DEATIL_GROUP_TEXT. */
    public static final String CP_DEATIL_GROUP_TEXT = "Counterparty Details";

    /** The Constant DISPLAY_REPORT_BUTTON_NAME. */
    public static final String DISPLAY_REPORT_BUTTON_NAME = "Display Report";

    /** The Constant CCY_TRNOR_REPORT_SECTION_TEXT. */
    public static final String NOTIONAL_CCY_TRNOR_REPORT_SECTION_TEXT = "Total (including Intra-Day and Notional Adjustments)                        ";

    /** The Constant CCY_TRNOR_REPORT_SECTION_TEXT. */
    public static final String CCY_TRNOR_REPORT_SECTION_TEXT = "Total BPV (including Start of Day, Intra-Day and BPV Adjustments)                        ";

    /** The Constant DIRECTIONAL_TOTAL. */
    public static final String DIRECTIONAL_TOTAL = "BPV Total";

    /** The Constant CURVE_RISK. */
    public static final String CURVE_RISK = "Total Curve Risk";

    /** The Constant TOTAL. */
    public static final String TOTAL = "Total";

    /** The Constant SOD_DIRECTIONAL_BPV_TEXT. */
    public static final String SOD_DIRECTIONAL_BPV_TEXT = "Start of Day Directional BPV:";

    /** The Constant SOD_CURVE_BPV_TEXT. */
    public static final String SOD_CURVE_BPV_TEXT = "Start of Day Curve BPV:";

    /** The Constant CURVE_LIMIT_TEXT. */
    public static final String CURVE_LIMIT_TEXT = "Curve Limit:";

    /** The Constant DIRECTIONAL_LIMIT_TEXT. */
    public static final String DIRECTIONAL_LIMIT_TEXT = "Directional Limit:";

    /** The Constant OBTAINED_DATE_FORMAT. */
    public static final String OBTAINED_DATE_FORMAT = "HH:mm dd/MM/yyyy";

    /** The Constant NO_LIMIT_ERROR_FOR_REPORT. */
    public static final String NO_LIMIT_ERROR_FOR_REPORT = "No Limits information to report for selected Counterparty";

    /** The Constant CLIENT_EXCEPTION. */
    public static final String CLIENT_EXCEPTION = "Application error, please contact system administrator";

    /** The Constant MANDATORY_LABEL. */
    public static final String MANDATORY_LABEL = "* = mandatory";

    /** The Constant SAVE_CONFIRM_MESSAGE. */
    public static final String SAVE_CONFIRM_MESSAGE = "Are you sure you want to Save?";

    /** The Constant HYPHEN_STRING. */
    public static final String HYPHEN_STRING = "-";

    /** The Constant CCY_TRNOR_REPORT_POPUP_TEXT. */
    public static final String CCY_TRNOR_REPORT_POPUP_TEXT = "Currency and Tenor Level Report";

    /** The Constant INACTIVE_CURVE_IMIT. */
    public static final String INACTIVE_CURVE_IMIT = "The Limit you have selected is the only curve limit in place for this counterparty. Are you sure you wish to delete?";

    /** The Constant INACTIVE_DIRECTIONAL_IMIT. */
    public static final String INACTIVE_DIRECTIONAL_IMIT = "The Limit you have selected is the only directional limit in place for this counterparty. Are you sure you wish to delete?";

    /** The Constant INACTIVE_CURVE_DIRECTIONAL_IMIT. */
    public static final String INACTIVE_CURVE_DIRECTIONAL_IMIT = "The Limit you have selected is the only limit in place for this counterparty and limit type. Are you sure you wish to delete?";

    /** The Constant ACTIVE_ONE_CURVE_LIMIT. */
    public static final String ACTIVE_ONE_CURVE_LIMIT = "The Limit you have selected is being used for today's Limit Utilisation calculations and is the only curve limit in place for this counterparty. Are you sure you wish to delete?";

    /** The Constant ACTIVE_ONE_DIRECTIONAL_LIMIT. */
    public static final String ACTIVE_ONE_DIRECTIONAL_LIMIT = "The Limit you have selected is being used for today's Limit Utilisation calculations and is the only directional limit in place for this counterparty. Are you sure you wish to delete?";

    /** ********** Added for validation message. */

    /** The Constant ACTIVE_ONE_CURVE_LIMIT. */
    public static final String ACTIVE_ONE_CURVE_PB_LIMIT = "The Limit you have selected is being used for today's Limit Utilisation calculations and is the only PB Only BPV - Curve limit in place for this counterparty. Are you sure you wish to delete?";

    /** The Constant ACTIVE_ONE_DIRECTIONAL_LIMIT. */
    public static final String ACTIVE_ONE_DIRECTIONAL_PB_LIMIT = "The Limit you have selected is being used for today's Limit Utilisation calculations and is the only PB Only BPV - Directional limit in place for this counterparty. Are you sure you wish to delete?";

    /** The Constant ACTIVE_ONE_CURVE_LIMIT. */
    public static final String ACTIVE_ONE_CURVE_CC_LIMIT = "The Limit you have selected is being used for today's Limit Utilisation calculations and is the only CC Only BPV - Curve limit in place for this counterparty. Are you sure you wish to delete?";

    /** The Constant ACTIVE_ONE_DIRECTIONAL_LIMIT. */
    public static final String ACTIVE_ONE_DIRECTIONAL_CC_LIMIT = "The Limit you have selected is being used for today's Limit Utilisation calculations and is the only CC Only BPV - Directional limit in place for this counterparty. Are you sure you wish to delete?";

    /** The Constant ACTIVE_ONE_CURVE_LIMIT. */
    public static final String ACTIVE_ONE_CURVE_PBANDCC_LIMIT = "The Limit you have selected is being used for today's Limit Utilisation calculations and is the only PB && CC BPV - Curve limit in place for this counterparty. Are you sure you wish to delete?";

    /** The Constant ACTIVE_ONE_DIRECTIONAL_LIMIT. */
    public static final String ACTIVE_ONE_DIRECTIONAL_PBANDCC_LIMIT = "The Limit you have selected is being used for today's Limit Utilisation calculations and is the only PB && CC BPV - Directional limit in place for this counterparty. Are you sure you wish to delete?";

    /** The Constant ACTIVE_ONE_CURVE_LIMIT. */
    public static final String INACTIVE_ONE_CURVE_PB_LIMIT = "The Limit you have selected is the only PB Only BPV - Curve limit in place for this counterparty. Are you sure you wish to delete?";

    /** The Constant ACTIVE_ONE_DIRECTIONAL_LIMIT. */
    public static final String INACTIVE_ONE_DIRECTIONAL_PB_LIMIT = "The Limit you have selected is the only PB Only BPV - Directional limit in place for this counterparty. Are you sure you wish to delete?";

    /** The Constant ACTIVE_ONE_CURVE_LIMIT. */
    public static final String INACTIVE_ONE_CURVE_CC_LIMIT = "The Limit you have selected is the only CC Only BPV - Curve limit in place for this counterparty. Are you sure you wish to delete?";

    /** The Constant ACTIVE_ONE_DIRECTIONAL_LIMIT. */
    public static final String INACTIVE_ONE_DIRECTIONAL_CC_LIMIT = "The Limit you have selected is the only CC Only BPV - Directional limit in place for this counterparty. Are you sure you wish to delete?";

    /** The Constant ACTIVE_ONE_CURVE_LIMIT. */
    public static final String INACTIVE_ONE_CURVE_PBANDCC_LIMIT = "The Limit you have selected is the only PB && CC BPV - Curve limit in place for this counterparty. Are you sure you wish to delete?";

    /** The Constant ACTIVE_ONE_DIRECTIONAL_LIMIT. */
    public static final String INACTIVE_ONE_DIRECTIONAL_PBANDCC_LIMIT = "The Limit you have selected is the only PB && CC BPV - Directional limit in place for this counterparty. Are you sure you wish to delete?";

    /*
     * Added for validation message
     */
    /** The Constant ACTIVE_CURVE_DIRECTIONAL_LIMIT. */
    public static final String ACTIVE_CURVE_DIRECTIONAL_LIMIT = "The Limit you have selected is being used for today's Limit Utilisation calculations and is the only limit in place for this counterparty and limit type. Are you sure you wish to delete?";

    /** The Constant TABLE_ROW_SELECTION_ERROR_MESSAGE. */
    public static final String CCY_TENOR_SELECTION_ERROR_MESSAGE = "Please select a CCY-Tenor from the results set";

    /** The Date Constant. */
    public static final String DATE = "Date";

    /** Report Error message. */
    public static final String NO_REPORT_INFORMATION = "No Limits information to report for selected Counterparty";

    /** The Constant COMMA_TEXT. */
    public static final String COMMA_STRING = ",";

    /** The Constant SPN_LABEL for report. */
    public static final String REPORT_SPN_LABEL = "SPN:";

    /** The Constant for report for no data . */
    public static final String REPORT_HYPHEN = "-";

    /** The Constant for report Direction limit . */
    public static final String REPORT_DIRECTIONALLIMIT_LABEL = "Directional Limit:";

    /** The Constant for report Direction risk . */
    public static final String REPORT_DIRECTIONARISK_LABEL = "Today's Trades Directional Risk";

    /** The Constant for report BPV ADJUSTMENT . */
    public static final String REPORT_BPVADJUSTMENT_LABEL = "BPV Adjustment";

    /** The Constant for report Total Directional Risk . */
    public static final String REPORT_TOTAL_DIRECTIONALRISK = "Total Directional Risk";

    /** The Constant for report Total Directional Risk Utilization. */
    public static final String REPORT_DIRECTIONALRISK_UTILIZATION = "Total Directional Risk % Utilisation";

    /** The Constant for report CURVE LIMIT . */
    public static final String REPORT_CURVELIMIT_LABEL = "Curve Limit:";

    /** The Constant for report Curve risk . */
    public static final String REPORT_CURVERISK_LABEL = "Today's Trades Curve Risk";

    /** The Constant for report Total Curve Risk . */
    public static final String REPORT_TOTAL_CURVERISK_LABEL = "Total Curve Risk";

    /** The Constant for report Total Curve Risk . */
    public static final String REPORT_CURVERISK_UTILIZATION = "Total Curve Risk % Utilisation";

    /** The Constant for report Total Curve Risk . */
    public static final String REPORT_TODAYS_TRADES_LABEL = "Today's Trades :";

    /** The Constant NON_STP_LIMIT_VALUE_PATTERN. */
    public static final String NON_STP_LIMIT_VALUE_PATTERN = "((^[-+]?[0-9]*(\\.\\d{1,14})?$))";

    /** The Constant SAVE_BUTTON_LABEL. */
    public static final String SAVE_BUTTON_LABEL = "Save";

    /** The Constant EDIT_BUTTON_LABEL. */
    public static final String EDIT_BUTTON_LABEL = "Edit";

    /** Constant for view. */
    public static final String BPV_UTILISATION_ID = "com.jpmorgan.rubi.limit.view.CounterpartyLevelBPVUtilisationView";

    /** Constant for headerview. */
    public static final String BPV_UTILISATION_HEADER = "BPV Utilisation at Counterparty level";

    /** The Constant BPV_UTILISATION_AT_COUNTERPARTY_LEVEL. */
    public static final String BPV_UTILISATION_COUNTERPARTY_LEVEL_REPORT = "Utilisation at Counterparty Level";

    /** The Constant bpv utilisation. */
    public static final String BPV_UTILISATION = "Utilisation by Counterparty";

    public static final String CD_BPV_UTILISATION = "Limit Utilisation by Counterparty";

    /** The Constant goTo. */
    public static final String GO_TO_LABEL = "Go To Page";

    /** The Constant total pages. */
    public static final String TOTAL_PAGES_LABEL = "Total Pages";

    /** The Constant BPV_UTILISATION_TABLE_TITLE. */
    public static final String[] BPV_UTILISATION_TABLE_TITLE = {
	    "Counterparty Type", "Linked Party", "Linked SPN", "Scenario",
	    "Calc. Method", "% Limit Utilised", "Limit", "SOD Total",
	    "Intra-day Total", "Adjustment Total" };

    /** The Constant current page. */
    public static final String CURRENT_PAGE = "Current Page";

    /** The Constant PAGE NUMBER EXCEPTION EXCEPTION. */
    public static final String PAGE_NUMBER_EXCEPTION = "Please enter page number";

    /** The Constant PAGE NUMBER EXCEPTION EXCEEDS EXCEPTION. */
    public static final String PAGE_NUMBER_EXCEEDS_EXCEPTION = "Entered page number exceeds with total pages";

    /** The Constant GOTO_PAGE_NUMERIC_ERROR_MESSAGE. */
    public static final String GOTO_PAGE_NUMERIC_ERROR_MESSAGE = "Please enter non zero valid numeric value";

    /** The Constant NUMBER_OF_RECORD_PER_PAGE. */
    public static final String NUMBER_OF_RECORD_PER_PAGE = "NUMBER_OF_RECORD_PER_PAGE";

    /** The Constant RED_COLOR_LABEL. */
    public static final String RED_COLOR_LABEL = "100% >= utilisation  ";

    /** The Constant EQD_RED_COLOR_LABEL. */
    public static final String EQD_RED_COLOR_LABEL = "100% > utilisation  ";

    /** The Constant GREEN_COLOR_LABEL. */
    public static final String GREEN_COLOR_LABEL = "% < utilisation";

    /** The Constant AMBER_COLOR_LABEL. */
    public static final String AMBER_COLOR_LABEL = "% >= utilisation   ";

    /** The Constant PREVIOUS_BUTTON. */
    public static final String PREVIOUS_BUTTON = "Previous";

    /** The Constant NEXT_BUTTON. */
    public static final String NEXT_BUTTON = "Next";

    /** The Constant GO_BUTTON. */
    public static final String GO_BUTTON = "Go";

    /** The Constant REFRESH_BUTTON. */
    public static final String REFRESH_BUTTON = "Refresh";

    /** The Constant PARTY_NAME_SORT_FIELD. */
    public static final String PARTY_NAME_SORT_FIELD = "PARTY_NAME";

    /** The Constant PARTY_SPN_SORT_FIELD. */
    public static final String PARTY_SPN_SORT_FIELD = "PARTY_SPN";

    /** The Constant SORT_ORDER_ASC. */
    public static final String SORT_ORDER_ASC = "ASC";

    /** The Constant SORT_ORDER_DESC. */
    public static final String SORT_ORDER_DESC = "DESC";

    /** The Constant COUNTERPARTY_COL_LABEL. */
    public static final String COUNTERPARTY_COL_LABEL = "Counterparty";

    /** The Constant COUNTERPARTY_COL_LABEL. */
    public static final String PARTY_NAME_COL_LABEL = "Party Name";

    /** The Constant SPN_COL_LABEL. */
    public static final String KEY_LABEL = "Key:  ";

    /** The Constant JOB_THRESHOLD_TIME. */
    public static final String JOB_THRESHOLD_TIME = "JOB_THRESHOLD_TIME";

    /** The Constant DASHBOARD_JOB_NAME. */
    public static final String DASHBOARD_JOB_NAME = "Dashboard Job";

    // Jira - IBTRGOC-752
    /** The Constant MESSAGE_NOT_AVAILABLE. */
    public static final String MESSAGE_NOT_AVAILABLE = "Not available";

    /** The Constant SOD_DIRECTIONAL_NOT_AVAILABLE. */
    public static final String SOD_AND_DIRECTIONAL_NOT_AVAILABLE = "Not Calculated as Directional Limit and Start of Day Directional BPV not available";

    /** The Constant SOD_CURVE_NOT_AVAILABLE. */
    public static final String SOD_AND_CURVE_NOT_AVAILABLE = "Not Calculated as Curve Limit and Start of Day Curve BPV not available";

    /** The Constant SOD_DIRECTIONAL_NOT_AVAILABLE. */
    public static final String SOD_DIRECTIONAL_NOT_AVAILABLE = "Not Calculated as Start of Day Directional BPV not available";

    /** The Constant DIRECTIONAL_NOT_AVAILABLE. */
    public static final String DIRECTIONAL_NOT_AVAILABLE = "Not Calculated as Directional Limit not available";

    /** The Constant SOD_CURVE_NOT_AVAILABLE. */
    public static final String SOD_CURVE_NOT_AVAILABLE = "Not Calculated as Start of Day Curve BPV not available";

    /** The Constant CURVE_NOT_AVAILABLE. */
    public static final String CURVE_NOT_AVAILABLE = "Not Calculated as Curve Limit not available";

    public static final String WITHOUT_SOD_CURVE_BPV = "(Without Start of Day Curve BPV)";

    public static final String WITHOUT_SOD_DIRECTIONAL_BPV = "(Without Start of Day Directional BPV)";

    /** The Constant THRESHOLD_SETUP. */
    public static final String THRESHOLD_SETUP = "Utilisation Warning Threshold";

    /** The Constant DASHBOARD_JOB_NAME. */
    public static final String DIRECTIONAL_PERC_UTILISATION = "Direct. Overall % Util.";

    /** The Constant DASHBOARD_JOB_NAME. */
    public static final String CURVE_PERC_UTILISATION = "Curve Overall % Util.";

    /** The Constant Footer message. */
    public static final String FOOTER_MESSAGE = "* Not Available = Insufficient Data. Please see Trade Level Report for details";

    /** The Constant View ID. */
    public static final String DASHBOARD_VIEWID = "com.jpmorgan.rubi.limit.view.CounterpartyLevelBPVUtilisationView";

    /** The Constant THRESHOLD_VALUE_PATTERN. */
    public static final String THRESHOLD_VALUE_PATTERN = "[0-9]*";

    // for JIRA 9521 Real Time Dashboard

    /** The Constant FOOTER_BPV_MESSAGE. */
    public static final String FOOTER_BPV_MESSAGE = "All values in USD";

    // for JIRA 9485
    /** The Constant NUMBER_OF_RESULT_TO_SHOWN_ERROR. */
    public static final String NUMBER_OF_RESULT_TO_SHOWN_ERROR1 = "Total number of records found exceeds ";

    /** The Constant NUMBER_OF_RESULT_TO_SHOWN_ERROR3. */
    public static final String NUMBER_OF_RESULT_TO_SHOWN_ERROR3 = ". Please refine your search criteria.";

    /** The Constant BLANK_SPACE_STRING. */
    public static final String BLANK_SPACE_STRING = " ";

    /** The Constant RESULT_PER_PAGE. */
    public static final String RESULT_PER_PAGE = "RESULT_PER_PAGE";

    /** The Constant CURRENT_THRESHOLD_VALUE_LABEL. */
    public static final String CURRENT_THRESHOLD_VALUE_LABEL = "Current Threshold Value :";

    /** The Constant THRESHOLD_VALUE_LIMIT_ERROR_MSG. */
    public static final String THRESHOLD_VALUE_LIMIT_ERROR_MSG = "Please enter value between 1-100";

    /** The Constant THRESHOLD_VALUE_WHOLE_NO_ERROR_MSG. */
    public static final String THRESHOLD_VALUE_WHOLE_NO_ERROR_MSG = "Please enter Threshold value as a whole number";
    // Added by shilpa
    /** The Constant STARTOFDAY. */
    public static final String STARTOFDAY = "Start of Day ";

    /** The Constant CURVE_BPV. */
    public static final String CURVE_BPV = " Curve BPV";

    /** The Constant DIRECTIONAL_BPV. */
    public static final String DIRECTIONAL_BPV = " Directional BPV";

    /** The Constant CURVE_LIMIT. */
    public static final String CURVE_LIMIT = " Curve Limit";

    /** The Constant DIRECTIONAL_LIMIT_STR. */
    public static final String DIRECTIONAL_LIMIT_STR = " Directional Limit";

    /** The Constant DOT. */
    public static final String DOT = ".";

    /** The Constant NO_DATA. */
    public static final String NO_DATA = "No records selected to delete";

    /** The Constant CCY_TRNOR_REPORT_BOTTOMSECTION_TEXT. */
    public static final String CCY_TRNOR_REPORT_BOTTOMSECTION_TEXT = "Scenario Summary (only includes trades relevant to scenario):";

    /** The Constant START_OF_DAY. */
    public static final String START_OF_DAY = "Start of Day:";

    /** The Constant TOTAL_BPV_USD. */
    public static final String TOTAL_BPV_USD = "Total BPV (USD):";

    /** The Constant TODAY_TRADE. */
    public static final String TODAY_TRADE = "Today's Trades:";

    /** The Constant TRANCHE_INDEX_LABEL. */
    public static final String TRANCHE_INDEX_LABEL = "Tranche Index";

    /** The Constant INSTITUTION_LABEL. */
    public static final String INSTITUTION_LABEL = "Institution *";

    /** The Constant TENOR_MONTHS. */
    public static final String TENOR_MONTHS = "Tenor(Months) *";

    /** The Constant BPV_ADJUSTMENT. */
    public static final String BPV_ADJUSTMENT = "BPV Adjustment:";

    /** The Constant OVERALL_TOTAL. */
    public static final String OVERALL_TOTAL = "Overall Total:";

    /** The Constant BPV_CURVE_TOTAL. */
    public static final String BPV_CURVE_TOTAL = "BPV Curve Total";

    /** The Constant MAX_LIMIT. */
    public static final String MAX_LIMIT = "Limit:";

    /** The Constant PERCENT_UTILISATION. */
    public static final String PERCENT_UTILISATION = "% Utilisation:";

    /** The Constant SUMMARY_REPORT. */
    public static final String SUMMARY_REPORT = "summaryReport";

    /** The Constant SCENARIO_REPORT. */
    public static final String SCENARIO_REPORT = "scenarioReport";

    /** The Constant CALCULATION_METHOD. */
    public static final String CALCULATION_METHOD = "Calculation Method *";

    /** The Constant CALCULATION_METHOD_LABEL. */
    public static final String CALCULATION_METHOD_LABEL = "Calculation Method *";

    /** The Constant SELECT_CALCULATION_METHOD_LABEL. */
    public static final String SELECT_CALCULATION_METHOD_LABEL = "Select Calculation Method *";

    /** The Constant SELECT. */
    public static final String SELECT = "--Select";

    /** The Constant SCENARIO_NAME. */
    public static final String SCENARIO_NAME = "Scenario *";

    /** The Constant SUMMARY_LEVEL_REPORT. */
    public static final String SUMMARY_LEVEL_REPORT = "Summary Level Report";

    /** The Constant SCENARIO_LEVEL_REPORT. */
    public static final String SCENARIO_LEVEL_REPORT = "Scenario Level Report";

    /** The Constant HISTORICAL_REPORT. */
    public static final String HISTORICAL_REPORT = "Historical Report";

    /** The Constant INTRADAY_REPORT. */
    public static final String INTRADAY_REPORT = "Intraday Report";

    /** The Constant DISPLAY_REPORT. */
    public static final String DISPLAY_REPORT = "Display Report";

    /** The Constant SELECT_REPORT. */
    public static final String SELECT_REPORT = "Select Type of Report";

    /** The Constant SELECT_TRADE_LEVEL_REPORT. */
    public static final String SELECT_TRADE_LEVEL_REPORT = "Select Report";

    /** The Constant SCENARIO. */
    public static final String SCENARIO = "Scenario";

    /** The Constant SELECT_SCENARIO. */
    public static final String SELECT_SCENARIO = "Select Scenario *";

    /** The Constant SCENARIO_COLON. */
    public static final String SCENARIO_COLON = "Scenario:";

    /** The Constant CALCULATION_METHOD_COLON. */
    public static final String CALCULATION_METHOD_COLON = "Calculation Method:";

    /** The Constant SCENARIO_SUMMARY. */
    public static final String SCENARIO_SUMMARY = "Scenario Summary (only includes trades relevant to scenario):";

    /** The Constant LIMIT_LABEL. */
    public static final String LIMIT_LABEL = "Limit";

    /** The Constant PERCENTAGE_UTILISATION. */
    public static final String PERCENTAGE_UTILISATION = "% Utilisation";

    /** The Constant NONSTP_TABLE_TITLE. */
    public static final String[] NONSTP_TABLE_TITLE = { "Counterparty Name",
	    "SPN", "Counterparty Type", "Linked Party", "Linked SPN",
	    "Scenario", "Calc Method", "Limit Value (USD)", "Effective Date" };

    /** The Constant PBONLY_CLIENT_EB_ID. */
    public static final String PBONLY_CLIENT_EB_ID = "4";

    /** The Constant PBONLY_CLIENT_EB_ROLLUP_ID. */
    public static final String PBONLY_CLIENT_EB_ROLLUP_ID = "5";

    /** The Constant SEARCH_CRITERIA_INFORMATION. */
    public static final String SEARCH_CRITERIA_INFORMATION = "**All counterparties matching the entered search criteria will be displayed";

    /** The Constant SELECT_LINKED_COUNTERPARTY_BUTTON. */
    public static final String SELECT_LINKED_COUNTERPARTY_BUTTON = "Select Linked Counterparty";

    /** The Constant LINKED_PARTY. */
    public static final String LINKED_PARTY = "Linked Party";

    /** The Constant LINKED_COUNTERPARTY. */
    public static final String LINKED_COUNTERPARTY = "Linked Counterparty";

    public static final String LINKED_COUNTERPARTY_SPN = "Linked Counterparty SPN";

    /** The Constant BPV_GRID. */
    public static final String BPV_GRID = "BPV Grid";

    /** The Constant BPV_LIMIT. */
    public static final String BPV_LIMIT = "BPV Limit";

    /** The Constant NOTIONAL_GRID. */
    public static final String NOTIONAL_GRID = "Notional Grid";

    /** The Constant NOTIONAL_LIMIT. */
    public static final String NOTIONAL_LIMIT = "Notional Limit";

    /** The Constant TENOR_BUCKET. */
    public static final String TENOR_BUCKET = "Tenor Bucket";

    /** The Constant EMC_DMC. */
    public static final String EMC_DMC = "EMC / DMC";

    /** The Constant LIMIT_VALUE_USD. */
    public static final String LIMIT_VALUE_USD = "Limit Value (USD) *";

    /** The Constant SELECT_TENOR_BUCKET. */
    public static final String SELECT_TENOR_BUCKET = "Select Tenor Bucket *";

    /** The Constant SELECT_EMC_DMC. */
    public static final String SELECT_EMC_DMC = "Select EMC / DMC *";

    /** The Constant SELECT_CURRENCY. */
    public static final String SELECT_CURRENCY = "Select Currency *";

    /** The Constant SELECT_REGION. */
    public static final String SELECT_REGION = "Select Region *";

    /** The Constant MANDATORY. */
    public static final String MANDATORY = "*= mandatory";

    /** The Constant CURRENCY_GRP_EMC_ID. */
    public static final String CURRENCY_GRP_EMC_ID = "2";

    /** The Constant ALL. */
    public static final String ALL = "ALL";

    /** The Constant BPV_DIRECTIONAL_VALUE. */
    public static final String NOTIONAL_VALUE = "Notional";

    /** The Constant COUNTERPARTY_DETAIL_LABEL. */
    public static final String COUNTERPARTY_LIMIT_DETAILS_LABEL = "Counterparty Limit Details*";

    /** The Constant PRODUCT. */
    public static final String PRODUCT = "Product";

    /** The Constant CCY_TRNOR_REPORT_SECTION_TEXT_FOR_NOTIONAL. */
    public static final String CCY_TRNOR_REPORT_SECTION_TEXT_FOR_NOTIONAL = "Total Notional (including Intra-Day and Adjustments)                        ";

    /** The Constant ADD. */
    public static final String ADD = "Add";

    /** The Constant DELETE. */
    public static final String DELETE = "Delete";

    /** The Constant JPM_POSITION. */
    public static final String JPM_POSITION = "JPM Position";

    /** The Constant TOTAL_NOTIONAL_USD. */
    public static final String TOTAL_NOTIONAL_USD = "Total Notional (USD):";

    /** The Constant ADJUSTMENT. */
    public static final String ADJUSTMENT = "Adjustment:";

    /**
     * The Constant LIMIT_MAINT_COUNTERPARTY_DETAIL_LABEL.
     */
    public static final String LIMIT_MAINT_COUNTERPARTY_DETAIL_LABEL = "Counterparty Details **";

    /**
     * The Constant LIMIT_VALUE_INPUT_GRID.
     */
    public static final String LIMIT_VALUE_INPUT_GRID = "Limit Value Input";

    /** The Constant SEE_REPROT_MESSAGE. */
    public static final String SEE_REPROT_MESSAGE = "See Trade Report";

    /** The Constant NA_MESSAGE. */
    public static final String NA_MESSAGE = "N/A";

    /** The Constant LIMIT_NOT_BREACHED_MESSAGE. */
    public static final String LIMIT_NOT_BREACHED_MESSAGE = "Limit Not Breached";

    /** The Constant LIMIT_ALMOST_BREACHED_MESSAGE. */
    public static final String LIMIT_ALMOST_BREACHED_MESSAGE = "Limit Almost Breached";

    /** The Constant LIMIT_BREACHED_MESSAGE. */
    public static final String LIMIT_BREACHED_MESSAGE = "Limit Breached";

    /** The Constant EMC. */
    public static final Long EMC = Long.valueOf(2);

    /** The Constant DMC. */
    public static final Long DMC = Long.valueOf(3);

    /** The Constant LIMIT_ADJ_SEARCH_CRITERIA_INFORMATION. */
    public static final String LIMIT_ADJ_SEARCH_CRITERIA_INFORMATION = "** All active limits of counterparties matching the entered search criteria set in the Limit Maintenance screen will be displayed";

    /**
     * The Constant VIEW_BUTTON_NAME.
     */
    public static final String VIEW_BUTTON_NAME = "View Selected Limit";

    /** The Constant SELECT_PRODUCT. */
    public static final String SELECT_PRODUCT = "Select Product";

    /** The Constant SELECT_JPM_POSITION. */
    public static final String SELECT_JPM_POSITION = "Select JPM Position";

    /** The Constant TODAYS_TRADES_NETTED. */
    public static final String TODAYS_TRADES_NETTED = "Today's Trades (Netted):";

    /** The Constant ADJUSTMENT_NETTED. */
    public static final String ADJUSTMENT_NETTED = "Adjustment(Netted):";

    /** The Constant OVERALL_TOTAL_NETTED. */
    public static final String OVERALL_TOTAL_NETTED = "Overall Total(Netted):";

    /** The Constant LINKEDPARTY_TABLE_TITLE. */
    public static final String[] LINKEDPARTY_TABLE_TITLE = { "Tenor Bucket",
	    "EMC/DMC", "Currency", "Limit Value(USD)", "Current Total(USD)",
	    "Netted Total(USD)", "% Utilisation" };

    /** The Constant NOTIONAL_TOTAL. */
    public static final String NOTIONAL_TOTAL = "Notional Total";

    /** The Constant NOTIONAL_USD. */
    public static final String NOTIONAL_USD = "Notional (USD)";

    /** The Constant BPV_USD. */
    public static final String BPV_USD = "BPV (USD)";

    /** The Constant INSTRUCTION_LINE. */
    public static final String INSTRUCTION_LINE_LIMIT_SETUP_NOTIONAL = " Select Tenor Bucket , EMC/DMC and Currency to add rows, then enter Limit Value (USD) for tenor buckets.";

    /** The Constant PRIMARY_PARTY_EB_ERROR. */
    public static final String PRIMARY_PARTY_EB_ERROR = "Please select a Client SPN first. For Client-EB or Client-EB Rollup limits you must select the Client first, and then choose EB/s as your Linked Party";

    /** The Constant PRIMARY_PARTY_BLOCK_ERROR. */
    public static final String PRIMARY_PARTY_BLOCK_ERROR = "Please select a Block SPN first. From there you will be able to select Block � All Child Roll-up' which will mean all children of the select block roll-up.";

    /** The Constant PRIMARY_PARTY_SINGLE_FUND_ERROR. */
    public static final String PRIMARY_PARTY_SINGLE_FUND_ERROR = "Please select a Single Fund SPN first. From there you will be able to select Single Fund - Single Fund Roll-up' which will mean child of the selected single fund roll-up.";

    public static final String BLOCK_CLIENT = "BlockClient";
    /** The Constant TRADE_LEVEL_ADJUSTMENT_ID. */
    public static final String TRADE_LEVEL_ADJUSTMENT_ID = "com.jpmorgan.rubi.limit.view.TradeLevelAdjustmentView";

    /** The Constant TRADE_SEARCH_HEADER. */
    public static final String TRADE_SEARCH_HEADER = "Trade Id Search";

    /** The Constant TRADE_SEARCH_LABEL. */
    public static final String TRADE_SEARCH_LABEL = "Search Trade";

    /** The Constant DEACTIVATE_TRADES_HEADER. */
    public static final String DEACTIVATE_TRADES_HEADER = "Deactivate Trades";

    /** The Constant TRADE_TABLE_COLUMN_HEADERS. */
    public static final String[] TRADE_TABLE_COLUMN_HEADERS = { "Trade Id",
	    "Status", "Trade Date", "User Id", "Deactivated Date and Time" };

    /**
     * The Constant DISPLAY_TRADE_DETAIL_LABEL.
     */
    public static final String DISPLAY_TRADE_DETAIL_LABEL = "Display Trade Id's";

    /** The Constant TRADE_DETAILS_BUTTON_NAME. */
    public static final String TRADE_DETAILS_BUTTON_NAME = "Trade Details";

    /** The Constant TRADE_DETAILS_LABEL. */
    public static final String TRADE_DETAILS_LABEL = "Trade Details";

    /** The Constant TRADE_ID_LABEL. */
    public static final String TRADE_ID_LABEL = "Trade Id :";

    /** The Constant PRODUCT_LABEL. */
    public static final String PRODUCT_LABEL = "Product :";

    /** The Constant PRODUCT_TYPE_LABEL. */
    public static final String PRODUCT_TYPE_LABEL = "Product Type*";

    /** The Constant CURRENCY_LABEL. */
    public static final String CURRENCY_LABEL = "Currency :";

    /** The Constant TRADE_DETAILS_COUNTERPARTY_LABEL. */
    public static final String TRADE_DETAILS_COUNTERPARTY_LABEL = "Counterparties :";

    /** The Constant ACTION_NOTES_LABEL. */
    public static final String ACTION_NOTES_LABEL = "Action Notes :";

    /** The Constant DEACTIVATE_TRADE_BUTTON_NAME. */
    public static final String DEACTIVATE_TRADE_BUTTON_NAME = "Deactivate Trade";

    /**
     * The Constant TRADE_LEVEL_ADJUSTMENT.
     */
    public static final String TRADE_LEVEL_ADJUSTMENT = "Trade Level Adjustment";

    /** The Constant TRADE_TABLE_ROW_SELECTION_ERROR_MESSAGE. */
    public static final String TRADE_TABLE_ROW_SELECTION_ERROR_MESSAGE = "Please select a trade from the results set";

    /** The Constant BATCH_PROCESS_ID. */
    public static final String BATCH_PROCESS_ID = "com.jpmorgan.rubi.limit.view.BatchProcessView";

    /** The Constant BATCH_PROCESS_STATUS. */
    public static final String BATCH_PROCESS_STATUS = "Batch Process Status";

    /** The Constant TRADE_ID_SEVEN_DIGIT. */
    public static final String TRADE_ID_SEVEN_DIGIT = "Please enter numeric value with in 7 digit";

    /** The Constant NO_MATCHING_TRADE. */
    public static final String NO_MATCHING_TRADE = "No trade could be found with ID entered";

    /** The Constant ACTION_NOTE. */
    public static final String ACTION_NOTE = "Please enter Action note";

    /** The Constant TRADE_ID_ALPHANUMERIC_MESSAGE. */
    public static final String TRADE_ID_ALPHANUMERIC_MESSAGE = "Please enter an alphanumeric value only";

    /** The Constant NOTIONAL_LABEL. */
    public static final String NOTIONAL_LABEL = "Notional :";

    /** The Constant BULK_LIMIT_UPLOAD_HEADER. */
    public static final String BULK_LIMIT_UPLOAD_HEADER = "Bulk Upload Limits:";

    /** The Constant BULK_LIMIT_MAIN_UPLOAD_HEADER. */
    public static final String BULK_LIMIT_MAIN_UPLOAD_HEADER = "Upload Bulk Limit File";

    /** The Constant SELECT_FILE_LABEL. */
    public static final String SELECT_FILE_LABEL = "Choose file to upload:";

    /** The Constant SELECT_FILE_ERROR. */
    public static final String SELECT_FILE_ERROR = "Please Select a File To Upload";

    /** The Constant RISK_VALUES_TITLE. */
    public static final String[] RISK_VALUES_TITLE = { "Type", "Tenor Bucket",
	    "Tenor", "Value", "Currency", "FX Rate", "Limit Value",
	    "Limit Currency" };

    /** The Constant RISK_VALUES_PER_TENOR_TITLE. */
    public static final String[] RISK_VALUES_PER_TENOR_TITLE = { "Type",
	    "Tenor Bucket", "Value", "Currency", "FX Rate", "Limit Value",
	    "Limit Currency" };

    /** The Constant BPV_LABEL. */
    public static final String BPV_LABEL = "BPV";

    /** The Constant USD_LABEL. */
    public static final String USD_LABEL = "USD";

    /** The Constant RISK_VALUES. */
    public static final String RISK_VALUES = "Risk Values:";

    /** The Constant RISK_PER_TENOR_BUCKET. */
    public static final String RISK_PER_TENOR_BUCKET = "Risk per Tenor Bucket:";

    /** The Constant CLOSE_BUTTON_NAME. */
    public static final String CLOSE_BUTTON_NAME = "Close";

    /** The Constant CLICK_TOOLTIP. */
    public static final String CLICK_TOOLTIP = "Click to see full details";

    /** The Constant NA. */
    public static final String NA = "N/A";

    /** The Constant CD_LIMITSETUP_SEARCH_HEADER. */
    public static final String CD_LIMITSETUP_SEARCH_HEADER = "Search Criteria";

    /** The Constant SECONDARY_COUNTERPARTY_NAME. */
    public static final String SECONDARY_COUNTERPARTY_NAME = "Secondary Counterparty Name";

    /** The Constant SECONDARY_COUNTERPARTY_SPN. */
    public static final String SECONDARY_COUNTERPARTY_SPN = "Secondary Counterparty SPN";

    /** The Constant SECONDARY_COUNTERPARTY. */
    public static final String SECONDARY_COUNTERPARTY = "Secondary Counterparty(s)";

    public static final String SINGLE_SECONDARY_COUNTERPARTY = "Secondary Counterparty";

    /** The Constant LIMIT_BUCKET_VALUES. */
    public static final String LIMIT_BUCKET_VALUES = "Limit Bucket Values";

    /** The Constant SELECT_SECONDARY_COUNTERPARTY. */
    public static final String SELECT_SECONDARY_COUNTERPARTY_BUTTON = "Select Secondary Counterparty(s)";

    public static final String SELECT_SINGLE_SECONDARY_COUNTERPARTY_BUTTON = "Select Secondary Counterparty";

    /** The Constant ADD_BUTTON_NAME. */
    public static final String CD_ADD_BUTTON_NAME = "Add New Limit";

    /** The Constant CD_COUNTERPARTY_NAME_LABEL. */
    public static final String CD_COUNTERPARTY_NAME_LABEL = "Counterparty/L.E Hierarchy Name";

    /** The Constant TENOR_MONTHS_RANGE_ERROR. */
    public static final String TENOR_MONTHS_RANGE_ERROR = "Tenor(Months) value provided in 1st text box should always be smaller than 2nd text box and values should be between 0 to 600.";

    /** The Constant TENOR_MONTHS_MAXIMUM_TENOR_ERROR. */
    public static final String TENOR_MONTHS_MAXIMUM_TENOR_ERROR = "Please enter values between 0 to 600.";

    /** The Constant TENOR_BUCKET_AMOUNT_ERROR. */
    public static final String TENOR_BUCKET_AMOUNT_ERROR = " is not valid number.";

    /** The Constant LIMIT_BUCKET_ALREADY_ADDED. */
    public static final String LIMIT_BUCKET_ALREADY_ADDED = "Limit Bucket has already been added";

    /** The Constant LIMIT_BUCKET_AMOUNT_EMPTY_ERROR. */
    public static final String LIMIT_BUCKET_AMOUNT_EMPTY_ERROR = "Amount field under Limit Bucket cannot be empty. Please add numeric value.";

    /** The Constant SECONDARY_COUNTERPARTY_ERROR. */
    public static final String SECONDARY_COUNTERPARTY_ERROR = "Secondary Counterparty(s) is mandatory for this scenario";

    /** The Constant TENOR_VALUE_NUMERIC_ERROR. */
    public static final String TENOR_VALUE_NUMERIC_ERROR = "Please enter numeric value for Tenor(months)";

    /** The Constant POOLED_PRODUCT_NAME_MANDATORY_ERROR. */
    public static final String POOLED_PRODUCT_NAME_MANDATORY_ERROR = "Please enter Pooled Product Name.";

    /** The Constant POOLED_PRODUCT_NAME_ALPHANUMERIC_ERROR. */
    public static final String POOLED_PRODUCT_NAME_ALPHANUMERIC_ERROR = "Please enter an alphanumeric value for Pooled Product Name.";

    /** The Constant POOLED_PRODUCT_SELECTED_PRODUCT_ERROR. */
    public static final String POOLED_PRODUCT_SELECTED_PRODUCT_ERROR = "Selected Product(s) cannot be empty.";

    /** The Constant POOLED_PRODUCT_SAVE_MSG. */
    public static final String POOLED_PRODUCT_SAVE_MSG = "Pooled Product saved successfully.";

    /** The Constant POOLED_PRODUCT_SELECT_ERROR. */
    public static final String POOLED_PRODUCT_SELECT_ERROR = "Please select a Pooled Product from the table.";

    /** The Constant POOLED_PRODUCT_DELETE_CONFIRM. */
    public static final String POOLED_PRODUCT_DELETE_CONFIRM = "Are you sure you want to delete selected Pooled Product?";

    /** The Constant POOLED_PRODUCT_DELETE_MSG. */
    public static final String POOLED_PRODUCT_DELETE_MSG = "Pooled Product deleted successfully.";

    /** The Constant POOLED_PRODUCT_REMOVE_MSG. */
    public static final String POOLED_PRODUCT_REMOVE_MSG = "Cannot remove the products from Pooled Product.It is already utilized in Limit calculations.";

    /** The Constant VIEW_LABEL. */
    public static final String VIEW_LABEL = "View Limit Setup";

    public static final String CD_LIMIT_UTILISATION__ADJUSTMENT = "Limit Utilisation Adjustment";

    /** The Constant CD_LIMIT_UTILISATION_ADJUSTMENT_ID. */
    public static final String CD_LIMIT_UTILISATION_ADJUSTMENT_ID = "com.jpmorgan.rubi.limit.view.CDNonStpLimitAdjustmentView";

    public static final String TERMINATION_DATE_LABEL = "Trade Termination Date(dd/MM/yyyy)*";

    public static final String SELECT_SECONDARY_COUNTERPARTY_ERROR = "Secondary couterparty cannot be selected. Please check scenario selected for the current counterparty in Limit Maintenance view.";

    /** The constant TRADE_SUMMARY_ADJUSTMENT_TABLE */
    public static final String[] TRADE_SUMMARY_ADJUSTMENT_TABLE = { "Trade Id",
	    "Trade Effective Date", "Trade Termination Date",
	    "Notional of Trade", "Institution", "Secondary Counterparty ",
	    "Trade CCY", "Direction", "Product Type", "Tranche Index",
	    "Tranche", "Authoriser", "Reason" };

    /** The Constant EFFECTIVE_DATE_LABEL. */
    public static final String EFFECTIVE_DATE_TABLE_LABEL = "Effective Date";

    /** The Constant EFFECTIVE_DATE_LABEL. */
    public static final String EQD_EFFECTIVE_DATE_TABLE_LABEL = "Effective Date (dd/mm/yyyy)*";

    /** The Constant CALCULATION_METHOD_TABLE_LABEL. */
    public static final String CALCULATION_METHOD_TABLE_LABEL = "Calc Method";

    /** The Constant ONE_CLIENT_RADIO_SELECTION_MESSAGE. */
    public static final String ONE_CLIENT_RADIO_SELECTION_MESSAGE = "You can select only one client. To select more than one clients, use \"Multiple Clients\" option";

    /** The Constant MULTIPLE_CLIENT_RADIO_SELECTION_MESSAGE. */
    public static final String MULTIPLE_CLIENT_RADIO_SELECTION_MESSAGE =
    // "You can select maximum 15 clients. To select more than 15 clients, use \"All Clients\" option.";
    "The maximum number of clients that can be selected is 15 when running a report for \"Multiple Clients\". To select more than 15 clients, "
	    + "use \"All Clients\" option.";

    public static final String[] TODAYS_TRADE_TABLE_TITLES = { "Client Name",
	    "Party Type", "Client SPN", "Block Client Name",
	    "Block Client SPN", "Calc Method", "Trade ID", "Notional",
	    "Notional Amount (USD)", "Trade Currency", "FX Rate",
	    "Product Type", "Tenor (months)", "Tranche Index", "Tranche",
	    "Instrument ID", "Instrument Name", "Red Code",
	    "Fixed Rate/Spread", "Direction", "Upfront Fee", "Upfront Fee%",
	    "Trade Date", "Buyer Party", "Seller Party", "Linked Party SPN",
	    "TimeStamp Received", "Client", "Client-Secondary Counterparty",
	    "Client-Secondary Counterparty Rollup", "Legal Entity Rollup",
	    "Legal Entity-Secondary Counterparty",
	    "Legal Entity-Secondary Counterparty Rollup" };

    public static final String[] SCENARIO_SUMMARY_TABLE_TITLES = {
	    "Counterparty Name", "Scenario", "Institution", "Calc Method",
	    "Limit", "Limit Currency", "Direction", "Product Type", "Tenor",
	    "Tranche Index", "Tranche", "Intra-day Total", "Adjustment Total",
	    "Current Total", "% Utilisation", "Scenario Total",
	    "Linked Counterparty Name", "Linked Counterparty SPN" };

    /** The Constant TYPE_OF_REPORT. */
    public static final String TYPE_OF_REPORT_LABEL = "Type of Report";

    /** The Constant CLIENT_SELECTION. */
    public static final String CLIENT_SELECTION_LABEL = "Client Selection";

    /** The Constant CLIENT_SEARCH. */
    public static final String CLIENT_SEARCH_LABEL = "Client Search";

    /** The Constant RESULTS. */
    public static final String RESULTS_LABEL = "Results";

    /** The Constant PARTY_NAME. */
    public static final String PARTY_NAME_LABEL = "Party Name";

    /** The Constant TRADELEVELREPORT_SEARCHTEXT_CHARACTER_ERROR_MESSAGE. */
    public static final String TRADELEVELREPORT_SEARCHTEXT_CHARACTER_ERROR_MESSAGE = "Please enter an alphanumeric value when searching by name";

    /** The Constant PARTY_ALREADY_SELECTED. */
    public static final String PARTY_ALREADY_SELECTED = "The party is already selected.";

    /** The Constant REASON_TEXT_LABEL. */
    public static final String REASON_TEXT_LABEL = "Please enter an Alphanumeric value ";
    /** The Constant PAST_DATE_ADD_ERROR. */
    public static final String LIMIT_PAST_DATE_ADD_ERROR = "Limit Adjustment cannot be set for date in past";

    /** The Constant EQD_LIMIT_SETUP_TABLE_TITLE. */
    public static final String[] EQD_LIMIT_SETUP_TABLE_TITLE = {
	    "Counterparty Name", "SPN", "Counterparty Type", "Scenario",
	    "Calc Method", "Limit Value (USD)", "Effective Date (dd/mm/yyyy)",
	    "Updated By", "Updated Date" };

    /** The Constant DIRECTION_LABEL. */
    public static final String LIMIT_SETUP_TYPE = "Limit Setup Type*";

    /** The Constant AGGREGATE_NUM_OF_OPTIONS_BASED. */
    public static final String AGGREGATE_NUM_OF_OPTIONS_BASED = "Number Of Options Limit";

    /** The Constant NOTIONAL_LIMIT. */
    public static final String BOUGHT_AND_SOLD_LIMIT = "Bought and Sold Premium Limit";

    /** The Constant DELTA_MARKET_LIMIT. */
    public static final String DELTA_MARKET_LIMIT = "Delta Market Value Limit";

    /** The Constant STRESS_TEST_LIMIT. */
    public static final String STRESS_TEST_LIMIT = "Stress-Test Limit";

    /** The Constant PREMIUM. */
    public static final String PREMIUM = "Premium *";

    /** The Constant PREMIUM. */
    public static final String PREMIUM_LABLE = "Premium:";

    /** The Constant NUM_OF_OPTION_LABLE. */
    public static final String NUM_OF_OPTION_LABLE = "Num of Option:";

    /** The Constant LIMIT_VALUE_USD. */
    public static final String LIMIT_VALUE = "Limit Value (USD)";

    /** The Constant UTILISATION_COUNTERPARTY_LEVEL. */
    public static final String UTILISATION_COUNTERPARTY_LEVEL = "Utilisation at Counterparty Level";

    /** The Constant UTILISATION_COUNTERPARTY_LEVEL. */
    public static final String UTILISATION_COUNTERPARTY_LEVEL_ID = "com.jpmorgan.rubi.limit.view.EQDCounterpartyLevelUtilisationPopUp";

    public static final String CD_UTILISATION_COUNTERPARTY_LEVEL_ID = "com.jpmorgan.rubi.limit.view.CDCounterpartyLevelUtilisationView";

    /** The Constant REQUIRED_FIELD_ERROR. */
    public static final String REQUIRED_FIELD_ERROR_TEST = "Please add Limit adjustments using Add button";

    /**
     * The Constant EQUITIES_CONSOLIDATED
     */
    public static final String EQUITIES_CONSOLIDATED = "Equities Consolidated";

    /** The Constant EQD_NUM_OF_OPTION_TRADE_LEVEL_REPORT_TABLE_TITLE. */
    public static final String[] EQD_NUM_OF_OPTION_TRADE_LEVEL_REPORT_TABLE_TITLE = {
	    "External ID", "Trade Action", "Trade Date", "Product", "B/S",
	    "Option Type", "Currency", "No. of Options", "Recieved Date",
	    "Underlying", "Strike", "Multiplier", "Style", "Expiry Date",
	    "RACS Family ID" };

    /** The Constant EQD_BS_PREMIUM_TRADE_LEVEL_REPORT_TABLE_TITLE. */
    public static final String[] EQD_BS_PREMIUM_TRADE_LEVEL_REPORT_TABLE_TITLE = {
	    "External ID", "Trade Action", "Trade Date", "Product", "B/S",
	    "Option Type", "Currency", "FX Rate", "FX Rate Obtained",
	    "Premium", "Premium in USD", "Total Premium",
	    "Total Premium in USD", "Recieved Date", "Underlying", "Strike",
	    "Multiplier", "Style", "Expiry Date", "RACS Family ID" };

    /** The Constant EQD_DELTA_MARKET_VALUE_TRADE_LEVEL_REPORT_TABLE_TITLE. */
    public static final String[] EQD_DELTA_MARKET_VALUE_TRADE_LEVEL_REPORT_TABLE_TITLE = {
	    "External ID", "Trade Action", "Trade Date", "Product", "B/S",
	    "Option Type", "Currency", "FX Rate", "FX Rate Obtained", "Delta",
	    "Recieved Date", "Underlying", "Strike", "Multiplier", "Style",
	    "Expiry Date", "RACS Family ID" };

    /** The Constant EQD_STRESS_TRADE_LEVEL_REPORT_TABLE_TITLE. */
    public static final String[] EQD_STRESS_TRADE_LEVEL_REPORT_TABLE_TITLE = {
	    "External ID", "Trade Action", "Trade Date", "Product", "B/S",
	    "Option Type", "Currency", "FX Rate", "FX Rate Obtained", "Stress",
	    "Recieved Date", "Underlying", "Strike", "Multiplier", "Style",
	    "Expiry Date", "RACS Family ID" };

    /** The Constant SUMMARY_REPORT_TRADE_LEVEL_REPORT_TABLE_TITLE. */
    public static final String[] SUMMARY_REPORT_TRADE_LEVEL_REPORT_TABLE_TITLE = {
	    "External ID", "Trade Action", "Trade Date", "Product", "B/S",
	    "Option Type", "No. of Options", "Currency", "Premium", "FX Rate",
	    "Premium in USD", "Total Premium in USD", "FX Rate Obtained",
	    "Recieved Date", "Underlying", "Strike", "Multiplier", "Style",
	    "Expiry Date", "RACS Family ID", "Delta" };

    /** The Constant TODAY_DAILY_BAOUGHT_AND_SOLD_TRADE. */
    public static final String TODAY_DAILY_BAOUGHT_AND_SOLD_TRADE = "Today's Bought And Sold Trades:";

    /** The Constant OVERALL_DAILY_BAOUGHT_AND_SOLD_TOTAL. */
    public static final String OVERALL_DAILY_BAOUGHT_AND_SOLD_TOTAL = "Overall Bought And Sold Total:";

    /** The Constant START_OF_DAY_DELTA_MARKET_VALUE. */
    public static final String START_OF_DAY_DELTA_MARKET_VALUE = "Start Of Day Delta Market Value:";

    /** The Constant TODAY_DELTA_MARKET_VALUE_TRADE. */
    public static final String TODAY_DELTA_MARKET_VALUE_TRADE = "Today's Delta Market Value Trades:";

    /** The Constant OVERALL_DELTA_MARKET_VALUE_TOTAL. */
    public static final String OVERALL_DELTA_MARKET_VALUE_TOTAL = "Overall Delta Market Value Total:";

    /** The Constant NO_TRADE_REPORT. */
    public static final String NO_TRADE_REPORT = "No trades to report.";

    public static final String TIME_RECEIVED = "Time Received:";
    /** The Constant LONG. */
    public static final String LONG = "Long";

    /** The Constant SHORT. */
    public static final String SHORT = "Short";

    /** The Constant BUYER. */
    public static final String BUYER = "B";

    /** The Constant SELLER. */
    public static final String SELLER = "S";

    /** The Constant OVERALL_NUM_OF_OPTIONS_TOTAL. */
    public static final String OVERALL_NUM_OF_OPTIONS_TOTAL = "Overall Number Of Options Total:";

    /** The Constant TODAY_NUM_OF_OPTIONS_TRADE. */
    public static final String TODAY_NUM_OF_OPTIONS_TRADE = "Today's Number Of Options Trades:";

    /** The Constant REPLACE_LEADING_ZERO. */
    public static final String REPLACE_LEADING_ZERO = "^0+(?!$)";

    /** The Constant BULK_UPLOAD_LIMIT. */
    public static final String BULK_UPLOAD_LIMIT = "Bulk Upload Limits";

    /** The Constant ONE_POOLED_PRODUCT_ERROR. */
    public static final String ONE_POOLED_PRODUCT_ERROR = "Cannot save a pooled product with a single product";

    /** The Constant ONE_CLIENT. */
    public static final String ONE_CLIENT = "One Client";

    /** The Constant MULITPLE_CLIENT. */
    public static final String MULTIPLE_CLIENTS = "Multiple Clients";

    /** The Constant ALL_CLIENTS. */
    public static final String ALL_CLIENTS = "All Clients";

    /** The Constant CALCULATION_ADJUSTMENT. */
    public static final String CALCULATION_ADJUSTMENT = "Calculation Adjustment";

    /** The Constant COUNTERPARTY_SEARCH. */
    public static final String COUNTERPARTY_SEARCH = "Counterparty Search";

    public static final String COUNTERPARTY_SEARCH_LABEL = "Search for Counterparty";

    /** The Constant SAVE_SUCCESSFUL_MESSAGE. */
    public static final String NLE_COMPOSITION_SAVE_SUCCESSFUL = "Net Liquidating Equity Composition Saved Successfully";

    /** The Constant NLE_COMPOSITION_SELECTION. */
    public static final String NLE_COMPOSITION_SELECTION = "Please select the Net Liquidating Equity Composition";

    /** The Constant NLE_COMPOSITION_DEFAULT_SETTING. */
    public static final String NLE_COMPOSITION_DEFAULT_SETTING = "Default Composition includes, Liquidating Equity and Haircut";

    /** The Constant LIQUIDATING_EQUITY. */
    public static final String LIQUIDATING_EQUITY = "Liquidating Equity:";

    /** The Constant FUTURE_EQUITY. */
    public static final String FUTURE_EQUITY = "Future Equity:";

    /** The Constant HAIRCUT. */
    public static final String HAIRCUT = "Haircut:";

    /** The Constant NLE_COMPOSITION_LABEL. */
    public static final String NLE_COMPOSITION_LABEL = "Net Liquidating Equity Composition : ";

    /** The Constant NLE_COMPOSITION_LABEL. */
    public static final String NLE_COMPOSITION_HEADER = "Net Liquidating Equity Composition";

    /** The Constant NLE_COMPOSITION_EXISTS. */
    public static final String NLE_COMPOSITION_EXISTS = "NLE Composition already exists for the selected counterparty";

    /** The Constant NLE_COMPOSITION_DOES_NOT_EXISTS. */
    public static final String NLE_COMPOSITION_DOES_NOT_EXISTS = "NLE Composition does not exists for the selected counterparty";

    /** The Constant YES. */
    public static final String YES = "Yes";

    /** The Constant NO. */
    public static final String NO = "No";

    /** The Constant QUESTION_EXISTING_BUCKET. */
    public static final String QUESTION_EXISTING_BUCKET = "Do you want to add existing buckets ?";

    // GRSTM-23218
    /** The Constant CFT_CONFIGURATION. */
    public static final String CFT_CONFIGURATION = "CFT Configuration";

    /** The Constant CFT_DASHBOARD_STATUS. */
    public static final String CFT_DASHBOARD_STATUS = "CFT Dashboard Configuration";

    /** The Constant CFT_DASHBOARD_STATUS_EDIT. */
    public static final String CFT_DASHBOARD_STATUS_EDIT = "Update CFT Configuration";

    /** The Constant CFT_LIMIT_DASHBOARD. */
    public static final String CFT_LIMIT_DASHBOARD = "CFT Limit DashBoard ";

    /** The Constant CFT_TRADE_DASHBOARD. */
    public static final String CFT_TRADE_DASHBOARD = "CFT Trade DashBoard ";

    /** The Constant SAVE_CFT_CONFIGURATION. */
    public static final String SAVE_CFT_CONFIGURATION = "CFT Configuration Saved Successfully";

    /** The Constant COUNTERPARTY_NAME_LABEL. */
    public static final String UNDERLYING_LABEL = "Underlying*";

    /** The Constant SOD_OF_DAY_TOTAL. */
    public static final String SOD_OF_DAY_TOTAL = "Start of Day Total:";

    /** The Constant TOTAL_NLE_VALUE. */
    public static final String TOTAL_NLE_VALUE = "Total NLE Value:";

    /** The Constant UTILISATION_TABLE_TITLE_BNS. */
    public static final String[] UTILISATION_TABLE_TITLE_BNS = { "Limit Type",
	    "Premium", "Currency", "Limit Value (USD)", "Current Total (USD)",
	    "% Utilisation" };

    /** The Constant UTILISATION_TABLE_TITLE_DNS. */
    public static final String[] UTILISATION_TABLE_TITLE_DNS = { "Limit Type",
	    "Currency", "Limit Value (USD)", "Current Total (USD)",
	    "% Utilisation" };

    public static final String[] STRESS_VALUES_TITLE = { "I-20, V+100",
	    "I-15, V+75", "I-10, V+50", "I -5, V+25", "I +5, V-10",
	    "I+10, V-15", "I+15, V-20", "I+20, V-20" };

    public static final String COPY_EXISTING_LIMIT_BUCKET = "Copy Limit to New";

    public static final String CACHE_MANAGER_VIEW = "Cache Manager View";

    public static final String EQD_LIMIT_UTILISATION__ADJUSTMENT = "Limit Utilisation Adjustment";

    public static final String UPLOAD_RACS_ADJUSTMENT_FILE = "Upload RACS Adjustment File";

    /** The Constant SUMMARY_LEVEL_REPORT. */
    public static final String COUNTERPARTY_LEVEL_UTILISATION_REPORT = "Current Utilisation Report";

    /** The Constant SUMMARY_LEVEL_REPORT. */
    public static final String COUNTERPARTY_LEVEL_HISTORICAL_UTILISATION_REPORT = "Historical Utilisation Report";

    public static final String REPORT_DATE = "Report Date ";

}
